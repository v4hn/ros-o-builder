
"use strict";

let AssocTF = require('./AssocTF.js')
let SetDynamicTF = require('./SetDynamicTF.js')
let DeleteTF = require('./DeleteTF.js')
let DissocTF = require('./DissocTF.js')

module.exports = {
  AssocTF: AssocTF,
  SetDynamicTF: SetDynamicTF,
  DeleteTF: DeleteTF,
  DissocTF: DissocTF,
};
