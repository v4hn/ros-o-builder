
"use strict";

let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');
let JointStatistics = require('./JointStatistics.js');

module.exports = {
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  SwitchControllerResult: SwitchControllerResult,
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerActionResult: SwitchControllerActionResult,
  ActuatorStatistics: ActuatorStatistics,
  MechanismStatistics: MechanismStatistics,
  ControllerStatistics: ControllerStatistics,
  JointStatistics: JointStatistics,
};
