# generated from rosbuild/env-hooks/10.rosbuild.sh.em

# env variables in installspace
if [ -z "$CATKIN_ENV_HOOK_WORKSPACE" ]; then
  CATKIN_ENV_HOOK_WORKSPACE="/opt/ros/one"
fi
export ROS_ROOT="$CATKIN_ENV_HOOK_WORKSPACE/share/ros"
