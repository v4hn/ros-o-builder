
"use strict";

let DiscreteParameterEstimation = require('./DiscreteParameterEstimation.js')
let LinearGaussianStructureEstimation = require('./LinearGaussianStructureEstimation.js')
let DiscreteStructureEstimation = require('./DiscreteStructureEstimation.js')
let DiscreteQuery = require('./DiscreteQuery.js')
let LinearGaussianParameterEstimation = require('./LinearGaussianParameterEstimation.js')

module.exports = {
  DiscreteParameterEstimation: DiscreteParameterEstimation,
  LinearGaussianStructureEstimation: LinearGaussianStructureEstimation,
  DiscreteStructureEstimation: DiscreteStructureEstimation,
  DiscreteQuery: DiscreteQuery,
  LinearGaussianParameterEstimation: LinearGaussianParameterEstimation,
};
