(cl:in-package laser_cb_detector-msg)
(cl:export '())