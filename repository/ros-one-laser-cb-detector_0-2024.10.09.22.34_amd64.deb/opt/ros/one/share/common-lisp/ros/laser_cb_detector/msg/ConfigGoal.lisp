; Auto-generated. Do not edit!


(cl:in-package laser_cb_detector-msg)


;//! \htmlinclude ConfigGoal.msg.html

(cl:defclass <ConfigGoal> (roslisp-msg-protocol:ros-message)
  ((num_x
    :reader num_x
    :initarg :num_x
    :type cl:integer
    :initform 0)
   (num_y
    :reader num_y
    :initarg :num_y
    :type cl:integer
    :initform 0)
   (spacing_x
    :reader spacing_x
    :initarg :spacing_x
    :type cl:float
    :initform 0.0)
   (spacing_y
    :reader spacing_y
    :initarg :spacing_y
    :type cl:float
    :initform 0.0)
   (width_scaling
    :reader width_scaling
    :initarg :width_scaling
    :type cl:float
    :initform 0.0)
   (height_scaling
    :reader height_scaling
    :initarg :height_scaling
    :type cl:float
    :initform 0.0)
   (min_intensity
    :reader min_intensity
    :initarg :min_intensity
    :type cl:float
    :initform 0.0)
   (max_intensity
    :reader max_intensity
    :initarg :max_intensity
    :type cl:float
    :initform 0.0)
   (subpixel_window
    :reader subpixel_window
    :initarg :subpixel_window
    :type cl:integer
    :initform 0)
   (subpixel_zero_zone
    :reader subpixel_zero_zone
    :initarg :subpixel_zero_zone
    :type cl:integer
    :initform 0)
   (flip_horizontal
    :reader flip_horizontal
    :initarg :flip_horizontal
    :type cl:fixnum
    :initform 0))
)

(cl:defclass ConfigGoal (<ConfigGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ConfigGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ConfigGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name laser_cb_detector-msg:<ConfigGoal> is deprecated: use laser_cb_detector-msg:ConfigGoal instead.")))

(cl:ensure-generic-function 'num_x-val :lambda-list '(m))
(cl:defmethod num_x-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:num_x-val is deprecated.  Use laser_cb_detector-msg:num_x instead.")
  (num_x m))

(cl:ensure-generic-function 'num_y-val :lambda-list '(m))
(cl:defmethod num_y-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:num_y-val is deprecated.  Use laser_cb_detector-msg:num_y instead.")
  (num_y m))

(cl:ensure-generic-function 'spacing_x-val :lambda-list '(m))
(cl:defmethod spacing_x-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:spacing_x-val is deprecated.  Use laser_cb_detector-msg:spacing_x instead.")
  (spacing_x m))

(cl:ensure-generic-function 'spacing_y-val :lambda-list '(m))
(cl:defmethod spacing_y-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:spacing_y-val is deprecated.  Use laser_cb_detector-msg:spacing_y instead.")
  (spacing_y m))

(cl:ensure-generic-function 'width_scaling-val :lambda-list '(m))
(cl:defmethod width_scaling-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:width_scaling-val is deprecated.  Use laser_cb_detector-msg:width_scaling instead.")
  (width_scaling m))

(cl:ensure-generic-function 'height_scaling-val :lambda-list '(m))
(cl:defmethod height_scaling-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:height_scaling-val is deprecated.  Use laser_cb_detector-msg:height_scaling instead.")
  (height_scaling m))

(cl:ensure-generic-function 'min_intensity-val :lambda-list '(m))
(cl:defmethod min_intensity-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:min_intensity-val is deprecated.  Use laser_cb_detector-msg:min_intensity instead.")
  (min_intensity m))

(cl:ensure-generic-function 'max_intensity-val :lambda-list '(m))
(cl:defmethod max_intensity-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:max_intensity-val is deprecated.  Use laser_cb_detector-msg:max_intensity instead.")
  (max_intensity m))

(cl:ensure-generic-function 'subpixel_window-val :lambda-list '(m))
(cl:defmethod subpixel_window-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:subpixel_window-val is deprecated.  Use laser_cb_detector-msg:subpixel_window instead.")
  (subpixel_window m))

(cl:ensure-generic-function 'subpixel_zero_zone-val :lambda-list '(m))
(cl:defmethod subpixel_zero_zone-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:subpixel_zero_zone-val is deprecated.  Use laser_cb_detector-msg:subpixel_zero_zone instead.")
  (subpixel_zero_zone m))

(cl:ensure-generic-function 'flip_horizontal-val :lambda-list '(m))
(cl:defmethod flip_horizontal-val ((m <ConfigGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader laser_cb_detector-msg:flip_horizontal-val is deprecated.  Use laser_cb_detector-msg:flip_horizontal instead.")
  (flip_horizontal m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ConfigGoal>) ostream)
  "Serializes a message object of type '<ConfigGoal>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'num_x)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'num_x)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'num_x)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'num_x)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'num_y)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'num_y)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'num_y)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'num_y)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'spacing_x))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'spacing_y))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'width_scaling))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'height_scaling))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'min_intensity))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'max_intensity))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'subpixel_window)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'subpixel_window)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'subpixel_window)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'subpixel_window)) ostream)
  (cl:let* ((signed (cl:slot-value msg 'subpixel_zero_zone)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'flip_horizontal)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ConfigGoal>) istream)
  "Deserializes a message object of type '<ConfigGoal>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'num_x)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'num_x)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'num_x)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'num_x)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'num_y)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'num_y)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'num_y)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'num_y)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'spacing_x) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'spacing_y) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'width_scaling) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'height_scaling) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'min_intensity) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'max_intensity) (roslisp-utils:decode-single-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'subpixel_window)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'subpixel_window)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'subpixel_window)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'subpixel_window)) (cl:read-byte istream))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'subpixel_zero_zone) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'flip_horizontal)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ConfigGoal>)))
  "Returns string type for a message object of type '<ConfigGoal>"
  "laser_cb_detector/ConfigGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ConfigGoal)))
  "Returns string type for a message object of type 'ConfigGoal"
  "laser_cb_detector/ConfigGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ConfigGoal>)))
  "Returns md5sum for a message object of type '<ConfigGoal>"
  "d592564bc71ebb8458e3d0d3a079d731")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ConfigGoal)))
  "Returns md5sum for a message object of type 'ConfigGoal"
  "d592564bc71ebb8458e3d0d3a079d731")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ConfigGoal>)))
  "Returns full string definition for message of type '<ConfigGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%uint32 num_x     # Number of checkerboard corners in the X direction~%uint32 num_y     # Number of corners in the Y direction~%float32 spacing_x  # Spacing between corners in the X direction (meters)~%float32 spacing_y  # Spacing between corners in the Y direction (meters)~%~%# Specify how many times we want to upsample the image.~%#  This is often useful for detecting small checkerboards far away~%float32 width_scaling~%float32 height_scaling~%~%# Specifiy how intensity maps into a uint8. A specified window of~%#   intensities is linearly scaled to 0-255~%float32 min_intensity~%float32 max_intensity~%~%# Configure openCV's subpixel corner detector~%uint32 subpixel_window~%int32  subpixel_zero_zone~%~%# Specify if we need to flip snapshot image model. This is usually necessary~%# when the laser scans from right to left, since this is the opposite of images,~%# which are normally indexed left to right~%uint8 flip_horizontal~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ConfigGoal)))
  "Returns full string definition for message of type 'ConfigGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%uint32 num_x     # Number of checkerboard corners in the X direction~%uint32 num_y     # Number of corners in the Y direction~%float32 spacing_x  # Spacing between corners in the X direction (meters)~%float32 spacing_y  # Spacing between corners in the Y direction (meters)~%~%# Specify how many times we want to upsample the image.~%#  This is often useful for detecting small checkerboards far away~%float32 width_scaling~%float32 height_scaling~%~%# Specifiy how intensity maps into a uint8. A specified window of~%#   intensities is linearly scaled to 0-255~%float32 min_intensity~%float32 max_intensity~%~%# Configure openCV's subpixel corner detector~%uint32 subpixel_window~%int32  subpixel_zero_zone~%~%# Specify if we need to flip snapshot image model. This is usually necessary~%# when the laser scans from right to left, since this is the opposite of images,~%# which are normally indexed left to right~%uint8 flip_horizontal~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ConfigGoal>))
  (cl:+ 0
     4
     4
     4
     4
     4
     4
     4
     4
     4
     4
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ConfigGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'ConfigGoal
    (cl:cons ':num_x (num_x msg))
    (cl:cons ':num_y (num_y msg))
    (cl:cons ':spacing_x (spacing_x msg))
    (cl:cons ':spacing_y (spacing_y msg))
    (cl:cons ':width_scaling (width_scaling msg))
    (cl:cons ':height_scaling (height_scaling msg))
    (cl:cons ':min_intensity (min_intensity msg))
    (cl:cons ':max_intensity (max_intensity msg))
    (cl:cons ':subpixel_window (subpixel_window msg))
    (cl:cons ':subpixel_zero_zone (subpixel_zero_zone msg))
    (cl:cons ':flip_horizontal (flip_horizontal msg))
))
