(cl:in-package laser_cb_detector-msg)
(cl:export '(ACTION_GOAL-VAL
          ACTION_GOAL
          ACTION_RESULT-VAL
          ACTION_RESULT
          ACTION_FEEDBACK-VAL
          ACTION_FEEDBACK
))