
"use strict";

let StopApp = require('./StopApp.js')
let GetInstallationState = require('./GetInstallationState.js')
let StartApp = require('./StartApp.js')
let InstallApp = require('./InstallApp.js')
let GetAppDetails = require('./GetAppDetails.js')
let ListApps = require('./ListApps.js')
let UninstallApp = require('./UninstallApp.js')

module.exports = {
  StopApp: StopApp,
  GetInstallationState: GetInstallationState,
  StartApp: StartApp,
  InstallApp: InstallApp,
  GetAppDetails: GetAppDetails,
  ListApps: ListApps,
  UninstallApp: UninstallApp,
};
