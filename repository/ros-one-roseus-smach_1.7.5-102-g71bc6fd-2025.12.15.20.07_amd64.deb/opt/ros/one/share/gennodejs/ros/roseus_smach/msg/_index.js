
"use strict";

let Multiply10Result = require('./Multiply10Result.js');
let Sub5Feedback = require('./Sub5Feedback.js');
let Sub5Goal = require('./Sub5Goal.js');
let Multiply10ActionResult = require('./Multiply10ActionResult.js');
let Multiply10ActionGoal = require('./Multiply10ActionGoal.js');
let Sub5ActionResult = require('./Sub5ActionResult.js');
let Sub5Action = require('./Sub5Action.js');
let Multiply10ActionFeedback = require('./Multiply10ActionFeedback.js');
let Sub5Result = require('./Sub5Result.js');
let Multiply10Feedback = require('./Multiply10Feedback.js');
let Multiply10Goal = require('./Multiply10Goal.js');
let Multiply10Action = require('./Multiply10Action.js');
let Sub5ActionGoal = require('./Sub5ActionGoal.js');
let Sub5ActionFeedback = require('./Sub5ActionFeedback.js');

module.exports = {
  Multiply10Result: Multiply10Result,
  Sub5Feedback: Sub5Feedback,
  Sub5Goal: Sub5Goal,
  Multiply10ActionResult: Multiply10ActionResult,
  Multiply10ActionGoal: Multiply10ActionGoal,
  Sub5ActionResult: Sub5ActionResult,
  Sub5Action: Sub5Action,
  Multiply10ActionFeedback: Multiply10ActionFeedback,
  Sub5Result: Sub5Result,
  Multiply10Feedback: Multiply10Feedback,
  Multiply10Goal: Multiply10Goal,
  Multiply10Action: Multiply10Action,
  Sub5ActionGoal: Sub5ActionGoal,
  Sub5ActionFeedback: Sub5ActionFeedback,
};
