
"use strict";

let DeleteTF = require('./DeleteTF.js')
let AssocTF = require('./AssocTF.js')
let SetDynamicTF = require('./SetDynamicTF.js')
let DissocTF = require('./DissocTF.js')

module.exports = {
  DeleteTF: DeleteTF,
  AssocTF: AssocTF,
  SetDynamicTF: SetDynamicTF,
  DissocTF: DissocTF,
};
