#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "hpp-fcl::hpp-fcl" for configuration "None"
set_property(TARGET hpp-fcl::hpp-fcl APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(hpp-fcl::hpp-fcl PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "assimp::assimp"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libhpp-fcl.so"
  IMPORTED_SONAME_NONE "libhpp-fcl.so"
  )

list(APPEND _cmake_import_check_targets hpp-fcl::hpp-fcl )
list(APPEND _cmake_import_check_files_for_hpp-fcl::hpp-fcl "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libhpp-fcl.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
