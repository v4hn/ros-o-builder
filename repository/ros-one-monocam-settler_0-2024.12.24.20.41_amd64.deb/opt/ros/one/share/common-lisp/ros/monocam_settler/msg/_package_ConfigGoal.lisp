(cl:in-package monocam_settler-msg)
(cl:export '(TOLERANCE-VAL
          TOLERANCE
          IGNORE_FAILURES-VAL
          IGNORE_FAILURES
          MAX_STEP-VAL
          MAX_STEP
          CACHE_SIZE-VAL
          CACHE_SIZE
))