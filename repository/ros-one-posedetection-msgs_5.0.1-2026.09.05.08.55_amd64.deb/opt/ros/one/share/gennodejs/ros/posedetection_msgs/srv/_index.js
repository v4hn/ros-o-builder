
"use strict";

let Feature1DDetect = require('./Feature1DDetect.js')
let Feature0DDetect = require('./Feature0DDetect.js')
let Detect = require('./Detect.js')
let TargetObj = require('./TargetObj.js')

module.exports = {
  Feature1DDetect: Feature1DDetect,
  Feature0DDetect: Feature0DDetect,
  Detect: Detect,
  TargetObj: TargetObj,
};
