
"use strict";

let GetRobotMode = require('./GetRobotMode.js')
let GetSafetyMode = require('./GetSafetyMode.js')
let GetLoadedProgram = require('./GetLoadedProgram.js')
let IsProgramSaved = require('./IsProgramSaved.js')
let RawRequest = require('./RawRequest.js')
let IsInRemoteControl = require('./IsInRemoteControl.js')
let IsProgramRunning = require('./IsProgramRunning.js')
let GetProgramState = require('./GetProgramState.js')
let Popup = require('./Popup.js')
let AddToLog = require('./AddToLog.js')
let Load = require('./Load.js')

module.exports = {
  GetRobotMode: GetRobotMode,
  GetSafetyMode: GetSafetyMode,
  GetLoadedProgram: GetLoadedProgram,
  IsProgramSaved: IsProgramSaved,
  RawRequest: RawRequest,
  IsInRemoteControl: IsInRemoteControl,
  IsProgramRunning: IsProgramRunning,
  GetProgramState: GetProgramState,
  Popup: Popup,
  AddToLog: AddToLog,
  Load: Load,
};
