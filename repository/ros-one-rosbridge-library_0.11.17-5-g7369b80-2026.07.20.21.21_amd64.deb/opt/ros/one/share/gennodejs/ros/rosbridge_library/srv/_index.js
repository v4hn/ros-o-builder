
"use strict";

let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let SendBytes = require('./SendBytes.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestNestedService = require('./TestNestedService.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestEmpty = require('./TestEmpty.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')

module.exports = {
  TestRequestAndResponse: TestRequestAndResponse,
  SendBytes: SendBytes,
  TestResponseOnly: TestResponseOnly,
  TestNestedService: TestNestedService,
  TestMultipleRequestFields: TestMultipleRequestFields,
  AddTwoInts: AddTwoInts,
  TestRequestOnly: TestRequestOnly,
  TestEmpty: TestEmpty,
  TestArrayRequest: TestArrayRequest,
  TestMultipleResponseFields: TestMultipleResponseFields,
};
