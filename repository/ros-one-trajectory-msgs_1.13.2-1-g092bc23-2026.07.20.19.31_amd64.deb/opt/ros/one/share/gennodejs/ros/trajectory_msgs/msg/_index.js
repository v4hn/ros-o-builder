
"use strict";

let MultiDOFJointTrajectory = require('./MultiDOFJointTrajectory.js');
let MultiDOFJointTrajectoryPoint = require('./MultiDOFJointTrajectoryPoint.js');
let JointTrajectory = require('./JointTrajectory.js');
let JointTrajectoryPoint = require('./JointTrajectoryPoint.js');

module.exports = {
  MultiDOFJointTrajectory: MultiDOFJointTrajectory,
  MultiDOFJointTrajectoryPoint: MultiDOFJointTrajectoryPoint,
  JointTrajectory: JointTrajectory,
  JointTrajectoryPoint: JointTrajectoryPoint,
};
