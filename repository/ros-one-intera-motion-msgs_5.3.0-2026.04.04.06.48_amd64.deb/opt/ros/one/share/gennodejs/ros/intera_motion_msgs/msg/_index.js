
"use strict";

let WaypointOptions = require('./WaypointOptions.js');
let TrackingOptions = require('./TrackingOptions.js');
let Trajectory = require('./Trajectory.js');
let JointTrackingError = require('./JointTrackingError.js');
let EndpointTrackingError = require('./EndpointTrackingError.js');
let InterpolatedPath = require('./InterpolatedPath.js');
let MotionStatus = require('./MotionStatus.js');
let TrajectoryOptions = require('./TrajectoryOptions.js');
let WaypointSimple = require('./WaypointSimple.js');
let Waypoint = require('./Waypoint.js');
let TrajectoryAnalysis = require('./TrajectoryAnalysis.js');
let MotionCommandActionResult = require('./MotionCommandActionResult.js');
let MotionCommandFeedback = require('./MotionCommandFeedback.js');
let MotionCommandAction = require('./MotionCommandAction.js');
let MotionCommandActionFeedback = require('./MotionCommandActionFeedback.js');
let MotionCommandResult = require('./MotionCommandResult.js');
let MotionCommandActionGoal = require('./MotionCommandActionGoal.js');
let MotionCommandGoal = require('./MotionCommandGoal.js');

module.exports = {
  WaypointOptions: WaypointOptions,
  TrackingOptions: TrackingOptions,
  Trajectory: Trajectory,
  JointTrackingError: JointTrackingError,
  EndpointTrackingError: EndpointTrackingError,
  InterpolatedPath: InterpolatedPath,
  MotionStatus: MotionStatus,
  TrajectoryOptions: TrajectoryOptions,
  WaypointSimple: WaypointSimple,
  Waypoint: Waypoint,
  TrajectoryAnalysis: TrajectoryAnalysis,
  MotionCommandActionResult: MotionCommandActionResult,
  MotionCommandFeedback: MotionCommandFeedback,
  MotionCommandAction: MotionCommandAction,
  MotionCommandActionFeedback: MotionCommandActionFeedback,
  MotionCommandResult: MotionCommandResult,
  MotionCommandActionGoal: MotionCommandActionGoal,
  MotionCommandGoal: MotionCommandGoal,
};
