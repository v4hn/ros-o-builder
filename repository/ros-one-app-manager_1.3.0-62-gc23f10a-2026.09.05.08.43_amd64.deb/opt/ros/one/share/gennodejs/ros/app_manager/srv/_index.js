
"use strict";

let GetInstallationState = require('./GetInstallationState.js')
let StopApp = require('./StopApp.js')
let UninstallApp = require('./UninstallApp.js')
let StartApp = require('./StartApp.js')
let ListApps = require('./ListApps.js')
let GetAppDetails = require('./GetAppDetails.js')
let InstallApp = require('./InstallApp.js')

module.exports = {
  GetInstallationState: GetInstallationState,
  StopApp: StopApp,
  UninstallApp: UninstallApp,
  StartApp: StartApp,
  ListApps: ListApps,
  GetAppDetails: GetAppDetails,
  InstallApp: InstallApp,
};
