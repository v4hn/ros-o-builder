
"use strict";

let GetMap2 = require('./GetMap2.js')
let SetLabel = require('./SetLabel.js')
let AddLink = require('./AddLink.js')
let ListLabels = require('./ListLabels.js')
let GlobalBundleAdjustment = require('./GlobalBundleAdjustment.js')
let GetPlan = require('./GetPlan.js')
let CleanupLocalGrids = require('./CleanupLocalGrids.js')
let GetNodesInRadius = require('./GetNodesInRadius.js')
let LoadDatabase = require('./LoadDatabase.js')
let PublishMap = require('./PublishMap.js')
let ResetPose = require('./ResetPose.js')
let DetectMoreLoopClosures = require('./DetectMoreLoopClosures.js')
let SetGoal = require('./SetGoal.js')
let RemoveLabel = require('./RemoveLabel.js')
let GetMap = require('./GetMap.js')
let GetNodeData = require('./GetNodeData.js')

module.exports = {
  GetMap2: GetMap2,
  SetLabel: SetLabel,
  AddLink: AddLink,
  ListLabels: ListLabels,
  GlobalBundleAdjustment: GlobalBundleAdjustment,
  GetPlan: GetPlan,
  CleanupLocalGrids: CleanupLocalGrids,
  GetNodesInRadius: GetNodesInRadius,
  LoadDatabase: LoadDatabase,
  PublishMap: PublishMap,
  ResetPose: ResetPose,
  DetectMoreLoopClosures: DetectMoreLoopClosures,
  SetGoal: SetGoal,
  RemoveLabel: RemoveLabel,
  GetMap: GetMap,
  GetNodeData: GetNodeData,
};
