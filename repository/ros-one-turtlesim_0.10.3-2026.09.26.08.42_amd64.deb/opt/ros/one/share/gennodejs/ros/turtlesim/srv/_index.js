
"use strict";

let SetPen = require('./SetPen.js')
let TeleportAbsolute = require('./TeleportAbsolute.js')
let TeleportRelative = require('./TeleportRelative.js')
let Spawn = require('./Spawn.js')
let Kill = require('./Kill.js')

module.exports = {
  SetPen: SetPen,
  TeleportAbsolute: TeleportAbsolute,
  TeleportRelative: TeleportRelative,
  Spawn: Spawn,
  Kill: Kill,
};
