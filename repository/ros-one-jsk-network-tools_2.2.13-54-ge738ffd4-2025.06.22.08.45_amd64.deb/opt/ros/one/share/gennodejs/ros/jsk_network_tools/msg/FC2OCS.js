// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class FC2OCS {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.joint_angles = null;
      this.lhand_force = null;
      this.rhand_force = null;
      this.lfoot_force = null;
      this.rfoot_force = null;
      this.servo_state = null;
    }
    else {
      if (initObj.hasOwnProperty('joint_angles')) {
        this.joint_angles = initObj.joint_angles
      }
      else {
        this.joint_angles = new Array(32).fill(0);
      }
      if (initObj.hasOwnProperty('lhand_force')) {
        this.lhand_force = initObj.lhand_force
      }
      else {
        this.lhand_force = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('rhand_force')) {
        this.rhand_force = initObj.rhand_force
      }
      else {
        this.rhand_force = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('lfoot_force')) {
        this.lfoot_force = initObj.lfoot_force
      }
      else {
        this.lfoot_force = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('rfoot_force')) {
        this.rfoot_force = initObj.rfoot_force
      }
      else {
        this.rfoot_force = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('servo_state')) {
        this.servo_state = initObj.servo_state
      }
      else {
        this.servo_state = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FC2OCS
    // Check that the constant length array field [joint_angles] has the right length
    if (obj.joint_angles.length !== 32) {
      throw new Error('Unable to serialize array field joint_angles - length must be 32')
    }
    // Serialize message field [joint_angles]
    bufferOffset = _arraySerializer.uint8(obj.joint_angles, buffer, bufferOffset, 32);
    // Check that the constant length array field [lhand_force] has the right length
    if (obj.lhand_force.length !== 6) {
      throw new Error('Unable to serialize array field lhand_force - length must be 6')
    }
    // Serialize message field [lhand_force]
    bufferOffset = _arraySerializer.uint8(obj.lhand_force, buffer, bufferOffset, 6);
    // Check that the constant length array field [rhand_force] has the right length
    if (obj.rhand_force.length !== 6) {
      throw new Error('Unable to serialize array field rhand_force - length must be 6')
    }
    // Serialize message field [rhand_force]
    bufferOffset = _arraySerializer.uint8(obj.rhand_force, buffer, bufferOffset, 6);
    // Check that the constant length array field [lfoot_force] has the right length
    if (obj.lfoot_force.length !== 6) {
      throw new Error('Unable to serialize array field lfoot_force - length must be 6')
    }
    // Serialize message field [lfoot_force]
    bufferOffset = _arraySerializer.uint8(obj.lfoot_force, buffer, bufferOffset, 6);
    // Check that the constant length array field [rfoot_force] has the right length
    if (obj.rfoot_force.length !== 6) {
      throw new Error('Unable to serialize array field rfoot_force - length must be 6')
    }
    // Serialize message field [rfoot_force]
    bufferOffset = _arraySerializer.uint8(obj.rfoot_force, buffer, bufferOffset, 6);
    // Serialize message field [servo_state]
    bufferOffset = _serializer.bool(obj.servo_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FC2OCS
    let len;
    let data = new FC2OCS(null);
    // Deserialize message field [joint_angles]
    data.joint_angles = _arrayDeserializer.uint8(buffer, bufferOffset, 32)
    // Deserialize message field [lhand_force]
    data.lhand_force = _arrayDeserializer.uint8(buffer, bufferOffset, 6)
    // Deserialize message field [rhand_force]
    data.rhand_force = _arrayDeserializer.uint8(buffer, bufferOffset, 6)
    // Deserialize message field [lfoot_force]
    data.lfoot_force = _arrayDeserializer.uint8(buffer, bufferOffset, 6)
    // Deserialize message field [rfoot_force]
    data.rfoot_force = _arrayDeserializer.uint8(buffer, bufferOffset, 6)
    // Deserialize message field [servo_state]
    data.servo_state = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 57;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/FC2OCS';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7a556e2b1084dcaa36eeac7b2f905853';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # A message from FC to OSC.
    # There is are several limitations
    # 1. no nested fields is allowed.
    # 2. no variable length array is allowed.
    # 3. string is not supported.
    # 4. duration and time are not supported.
    
    uint8[32] joint_angles
    uint8[6] lhand_force
    uint8[6] rhand_force
    uint8[6] lfoot_force
    uint8[6] rfoot_force
    bool servo_state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FC2OCS(null);
    if (msg.joint_angles !== undefined) {
      resolved.joint_angles = msg.joint_angles;
    }
    else {
      resolved.joint_angles = new Array(32).fill(0)
    }

    if (msg.lhand_force !== undefined) {
      resolved.lhand_force = msg.lhand_force;
    }
    else {
      resolved.lhand_force = new Array(6).fill(0)
    }

    if (msg.rhand_force !== undefined) {
      resolved.rhand_force = msg.rhand_force;
    }
    else {
      resolved.rhand_force = new Array(6).fill(0)
    }

    if (msg.lfoot_force !== undefined) {
      resolved.lfoot_force = msg.lfoot_force;
    }
    else {
      resolved.lfoot_force = new Array(6).fill(0)
    }

    if (msg.rfoot_force !== undefined) {
      resolved.rfoot_force = msg.rfoot_force;
    }
    else {
      resolved.rfoot_force = new Array(6).fill(0)
    }

    if (msg.servo_state !== undefined) {
      resolved.servo_state = msg.servo_state;
    }
    else {
      resolved.servo_state = false
    }

    return resolved;
    }
};

module.exports = FC2OCS;
