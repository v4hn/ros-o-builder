
"use strict";

let DissocTF = require('./DissocTF.js')
let DeleteTF = require('./DeleteTF.js')
let AssocTF = require('./AssocTF.js')
let SetDynamicTF = require('./SetDynamicTF.js')

module.exports = {
  DissocTF: DissocTF,
  DeleteTF: DeleteTF,
  AssocTF: AssocTF,
  SetDynamicTF: SetDynamicTF,
};
