
"use strict";

let Vertices = require('./Vertices.js');
let ModelCoefficients = require('./ModelCoefficients.js');
let PolygonMesh = require('./PolygonMesh.js');
let PointIndices = require('./PointIndices.js');

module.exports = {
  Vertices: Vertices,
  ModelCoefficients: ModelCoefficients,
  PolygonMesh: PolygonMesh,
  PointIndices: PointIndices,
};
