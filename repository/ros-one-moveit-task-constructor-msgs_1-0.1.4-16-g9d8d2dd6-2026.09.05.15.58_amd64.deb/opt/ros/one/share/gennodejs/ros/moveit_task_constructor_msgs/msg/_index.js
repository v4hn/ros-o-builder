
"use strict";

let Solution = require('./Solution.js');
let SubTrajectory = require('./SubTrajectory.js');
let StageStatistics = require('./StageStatistics.js');
let SubSolution = require('./SubSolution.js');
let StageDescription = require('./StageDescription.js');
let Property = require('./Property.js');
let SolutionInfo = require('./SolutionInfo.js');
let TaskStatistics = require('./TaskStatistics.js');
let TrajectoryExecutionInfo = require('./TrajectoryExecutionInfo.js');
let TaskDescription = require('./TaskDescription.js');
let ExecuteTaskSolutionFeedback = require('./ExecuteTaskSolutionFeedback.js');
let ExecuteTaskSolutionAction = require('./ExecuteTaskSolutionAction.js');
let ExecuteTaskSolutionGoal = require('./ExecuteTaskSolutionGoal.js');
let ExecuteTaskSolutionResult = require('./ExecuteTaskSolutionResult.js');
let ExecuteTaskSolutionActionFeedback = require('./ExecuteTaskSolutionActionFeedback.js');
let ExecuteTaskSolutionActionGoal = require('./ExecuteTaskSolutionActionGoal.js');
let ExecuteTaskSolutionActionResult = require('./ExecuteTaskSolutionActionResult.js');

module.exports = {
  Solution: Solution,
  SubTrajectory: SubTrajectory,
  StageStatistics: StageStatistics,
  SubSolution: SubSolution,
  StageDescription: StageDescription,
  Property: Property,
  SolutionInfo: SolutionInfo,
  TaskStatistics: TaskStatistics,
  TrajectoryExecutionInfo: TrajectoryExecutionInfo,
  TaskDescription: TaskDescription,
  ExecuteTaskSolutionFeedback: ExecuteTaskSolutionFeedback,
  ExecuteTaskSolutionAction: ExecuteTaskSolutionAction,
  ExecuteTaskSolutionGoal: ExecuteTaskSolutionGoal,
  ExecuteTaskSolutionResult: ExecuteTaskSolutionResult,
  ExecuteTaskSolutionActionFeedback: ExecuteTaskSolutionActionFeedback,
  ExecuteTaskSolutionActionGoal: ExecuteTaskSolutionActionGoal,
  ExecuteTaskSolutionActionResult: ExecuteTaskSolutionActionResult,
};
