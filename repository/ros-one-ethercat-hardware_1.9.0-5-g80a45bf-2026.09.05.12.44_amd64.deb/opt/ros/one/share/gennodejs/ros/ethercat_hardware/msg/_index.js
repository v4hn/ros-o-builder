
"use strict";

let ActuatorInfo = require('./ActuatorInfo.js');
let MotorTrace = require('./MotorTrace.js');
let RawFTDataSample = require('./RawFTDataSample.js');
let BoardInfo = require('./BoardInfo.js');
let RawFTData = require('./RawFTData.js');
let MotorTemperature = require('./MotorTemperature.js');
let MotorTraceSample = require('./MotorTraceSample.js');

module.exports = {
  ActuatorInfo: ActuatorInfo,
  MotorTrace: MotorTrace,
  RawFTDataSample: RawFTDataSample,
  BoardInfo: BoardInfo,
  RawFTData: RawFTData,
  MotorTemperature: MotorTemperature,
  MotorTraceSample: MotorTraceSample,
};
