
"use strict";

let SoftProcessorFirmwareRead = require('./SoftProcessorFirmwareRead.js')
let SoftProcessorReset = require('./SoftProcessorReset.js')
let SoftProcessorFirmwareWrite = require('./SoftProcessorFirmwareWrite.js')

module.exports = {
  SoftProcessorFirmwareRead: SoftProcessorFirmwareRead,
  SoftProcessorReset: SoftProcessorReset,
  SoftProcessorFirmwareWrite: SoftProcessorFirmwareWrite,
};
