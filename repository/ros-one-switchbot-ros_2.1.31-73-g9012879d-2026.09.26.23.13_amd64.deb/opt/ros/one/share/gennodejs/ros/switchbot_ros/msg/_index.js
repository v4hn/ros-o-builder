
"use strict";

let DeviceArray = require('./DeviceArray.js');
let Device = require('./Device.js');
let Bot = require('./Bot.js');
let MeterProCO2 = require('./MeterProCO2.js');
let Hub2 = require('./Hub2.js');
let StripLight = require('./StripLight.js');
let PlugMini = require('./PlugMini.js');
let Meter = require('./Meter.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');

module.exports = {
  DeviceArray: DeviceArray,
  Device: Device,
  Bot: Bot,
  MeterProCO2: MeterProCO2,
  Hub2: Hub2,
  StripLight: StripLight,
  PlugMini: PlugMini,
  Meter: Meter,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
  SwitchBotCommandAction: SwitchBotCommandAction,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
};
