
"use strict";

let InstallApp = require('./InstallApp.js')
let GetAppDetails = require('./GetAppDetails.js')
let StopApp = require('./StopApp.js')
let StartApp = require('./StartApp.js')
let UninstallApp = require('./UninstallApp.js')
let GetInstallationState = require('./GetInstallationState.js')
let ListApps = require('./ListApps.js')

module.exports = {
  InstallApp: InstallApp,
  GetAppDetails: GetAppDetails,
  StopApp: StopApp,
  StartApp: StartApp,
  UninstallApp: UninstallApp,
  GetInstallationState: GetInstallationState,
  ListApps: ListApps,
};
