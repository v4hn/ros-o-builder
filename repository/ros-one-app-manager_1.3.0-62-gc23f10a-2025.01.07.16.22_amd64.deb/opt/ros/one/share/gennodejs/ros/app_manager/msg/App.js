// Auto-generated. Do not edit!

// (in-package app_manager.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Icon = require('./Icon.js');
let ClientApp = require('./ClientApp.js');

//-----------------------------------------------------------

class App {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.display_name = null;
      this.icon = null;
      this.client_apps = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('display_name')) {
        this.display_name = initObj.display_name
      }
      else {
        this.display_name = '';
      }
      if (initObj.hasOwnProperty('icon')) {
        this.icon = initObj.icon
      }
      else {
        this.icon = new Icon();
      }
      if (initObj.hasOwnProperty('client_apps')) {
        this.client_apps = initObj.client_apps
      }
      else {
        this.client_apps = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type App
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [display_name]
    bufferOffset = _serializer.string(obj.display_name, buffer, bufferOffset);
    // Serialize message field [icon]
    bufferOffset = Icon.serialize(obj.icon, buffer, bufferOffset);
    // Serialize message field [client_apps]
    // Serialize the length for message field [client_apps]
    bufferOffset = _serializer.uint32(obj.client_apps.length, buffer, bufferOffset);
    obj.client_apps.forEach((val) => {
      bufferOffset = ClientApp.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type App
    let len;
    let data = new App(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [display_name]
    data.display_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [icon]
    data.icon = Icon.deserialize(buffer, bufferOffset);
    // Deserialize message field [client_apps]
    // Deserialize array length for message field [client_apps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.client_apps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.client_apps[i] = ClientApp.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    length += _getByteLength(object.display_name);
    length += Icon.getMessageSize(object.icon);
    object.client_apps.forEach((val) => {
      length += ClientApp.getMessageSize(val);
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'app_manager/App';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '643c1db5f71b615a47789ff5e190811e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # app name
    string name
    # user-friendly display name of application
    string display_name
    # icon for showing app
    Icon icon
    # ordered list (by preference) of client applications to interact with this robot app.  
    ClientApp[] client_apps
    
    ================================================================================
    MSG: app_manager/Icon
    # Image data format.  "jpeg" or "png"
    string format
    
    # Image data.
    uint8[] data
    
    ================================================================================
    MSG: app_manager/ClientApp
    # like "android" or "web" or "linux"
    string client_type
    
    # like "intent = ros.android.teleop" and "accelerometer = true", used to choose which ClientApp to use
    KeyValue[] manager_data
    
    # parameters which just get passed through to the client app.
    KeyValue[] app_data
    
    ================================================================================
    MSG: app_manager/KeyValue
    string key
    string value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new App(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.display_name !== undefined) {
      resolved.display_name = msg.display_name;
    }
    else {
      resolved.display_name = ''
    }

    if (msg.icon !== undefined) {
      resolved.icon = Icon.Resolve(msg.icon)
    }
    else {
      resolved.icon = new Icon()
    }

    if (msg.client_apps !== undefined) {
      resolved.client_apps = new Array(msg.client_apps.length);
      for (let i = 0; i < resolved.client_apps.length; ++i) {
        resolved.client_apps[i] = ClientApp.Resolve(msg.client_apps[i]);
      }
    }
    else {
      resolved.client_apps = []
    }

    return resolved;
    }
};

module.exports = App;
