
"use strict";

let SetGoal = require('./SetGoal.js')
let DetectMoreLoopClosures = require('./DetectMoreLoopClosures.js')
let ListLabels = require('./ListLabels.js')
let GetPlan = require('./GetPlan.js')
let ResetPose = require('./ResetPose.js')
let GetNodeData = require('./GetNodeData.js')
let SetLabel = require('./SetLabel.js')
let GetMap2 = require('./GetMap2.js')
let GetMap = require('./GetMap.js')
let GetNodesInRadius = require('./GetNodesInRadius.js')
let GlobalBundleAdjustment = require('./GlobalBundleAdjustment.js')
let RemoveLabel = require('./RemoveLabel.js')
let CleanupLocalGrids = require('./CleanupLocalGrids.js')
let LoadDatabase = require('./LoadDatabase.js')
let AddLink = require('./AddLink.js')
let PublishMap = require('./PublishMap.js')

module.exports = {
  SetGoal: SetGoal,
  DetectMoreLoopClosures: DetectMoreLoopClosures,
  ListLabels: ListLabels,
  GetPlan: GetPlan,
  ResetPose: ResetPose,
  GetNodeData: GetNodeData,
  SetLabel: SetLabel,
  GetMap2: GetMap2,
  GetMap: GetMap,
  GetNodesInRadius: GetNodesInRadius,
  GlobalBundleAdjustment: GlobalBundleAdjustment,
  RemoveLabel: RemoveLabel,
  CleanupLocalGrids: CleanupLocalGrids,
  LoadDatabase: LoadDatabase,
  AddLink: AddLink,
  PublishMap: PublishMap,
};
