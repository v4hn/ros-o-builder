
"use strict";

let AndroidSensor = require('./AndroidSensor.js');
let Touch = require('./Touch.js');
let MagneticField = require('./MagneticField.js');
let Gravity = require('./Gravity.js');
let SlackMessage = require('./SlackMessage.js');
let VoiceMessage = require('./VoiceMessage.js');
let Tablet = require('./Tablet.js');
let DeviceSensor = require('./DeviceSensor.js');
let TouchEvent = require('./TouchEvent.js');
let MultiTouch = require('./MultiTouch.js');
let Action = require('./Action.js');

module.exports = {
  AndroidSensor: AndroidSensor,
  Touch: Touch,
  MagneticField: MagneticField,
  Gravity: Gravity,
  SlackMessage: SlackMessage,
  VoiceMessage: VoiceMessage,
  Tablet: Tablet,
  DeviceSensor: DeviceSensor,
  TouchEvent: TouchEvent,
  MultiTouch: MultiTouch,
  Action: Action,
};
