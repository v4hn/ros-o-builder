
;;; Recursively add relevant load paths
(let ((default-directory "/opt/ros/one/share/emacs/site-lisp"))
  (cond ((file-directory-p default-directory)
         (setq load-path
               (append
                (let ((load-path (copy-sequence load-path))) ;; Shadow
                  (append
                   (copy-sequence (normal-top-level-add-to-load-path '(".")))
                   (normal-top-level-add-subdirs-to-load-path)))
               load-path)))
        (t
         (message-box "Can't find the .el files!
Did you forget to install the ros_emacs_utils packages?
If so, run \"catkin_make install\" in your catkin workspace
or, if you prefer to only install the specific package,
run \"catkin_make install --pkg PACKAGE\" where PACKAGE is
rosemacs, slime_wrapper, slime_ros and roslisp_repl."))))

;;; Default modes list. Mostly there to make sure Yasnippets work.
;;; Will overwrite the settings from your emacs init file, so be careful...
(setq auto-mode-alist
      (append '(("\\.C$"       . c++-mode)
                ("\\.cc$"      . c++-mode)
                ("\\.c$"       . c-mode)
                ("\\.h$"       . c++-mode)
                ("makefile$"   . makefile-mode)
                ("Makefile$"   . makefile-mode)
                ("\\.asd"      . lisp-mode)
                ("\\.launch"   . xml-mode)) auto-mode-alist))

;;; Yasnippets: templates for standard structures. E.g. wgh TAB in a *.h file.
(if (require 'yasnippet nil 'noerror)
    (progn
      (add-to-list 'yas-snippet-dirs "/opt/ros/one/share/emacs/site-lisp/snippets")
      (yas-global-mode 1))
  (message "Yasnippet library is not installed. You can install it, e.g., with ELPA."))

;;; Load / set up rosemacs
(require 'rosemacs)
(invoke-rosemacs)
(global-set-key "\C-x\C-r" ros-keymap)

(provide 'rosemacs-config)
