
"use strict";

let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetPointMap = require('./GetPointMap.js')
let SaveMap = require('./SaveMap.js')
let SetMapProjections = require('./SetMapProjections.js')
let GetMapROI = require('./GetMapROI.js')
let GetPointMapROI = require('./GetPointMapROI.js')

module.exports = {
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetPointMap: GetPointMap,
  SaveMap: SaveMap,
  SetMapProjections: SetMapProjections,
  GetMapROI: GetMapROI,
  GetPointMapROI: GetPointMapROI,
};
