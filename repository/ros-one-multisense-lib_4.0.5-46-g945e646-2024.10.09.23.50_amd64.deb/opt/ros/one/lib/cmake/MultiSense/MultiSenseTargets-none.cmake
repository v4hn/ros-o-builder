#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "MultiSense" for configuration "None"
set_property(TARGET MultiSense APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(MultiSense PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/libMultiSense.so.6.0.0"
  IMPORTED_SONAME_NONE "libMultiSense.so.6.0.0"
  )

list(APPEND _cmake_import_check_targets MultiSense )
list(APPEND _cmake_import_check_files_for_MultiSense "${_IMPORT_PREFIX}/lib/libMultiSense.so.6.0.0" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
