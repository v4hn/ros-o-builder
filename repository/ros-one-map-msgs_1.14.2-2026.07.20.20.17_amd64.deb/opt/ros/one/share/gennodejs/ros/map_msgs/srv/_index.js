
"use strict";

let GetPointMap = require('./GetPointMap.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let SetMapProjections = require('./SetMapProjections.js')
let GetMapROI = require('./GetMapROI.js')
let SaveMap = require('./SaveMap.js')
let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')

module.exports = {
  GetPointMap: GetPointMap,
  GetPointMapROI: GetPointMapROI,
  SetMapProjections: SetMapProjections,
  GetMapROI: GetMapROI,
  SaveMap: SaveMap,
  ProjectedMapsInfo: ProjectedMapsInfo,
};
