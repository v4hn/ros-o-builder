
"use strict";

let Meter = require('./Meter.js');
let Device = require('./Device.js');
let StripLight = require('./StripLight.js');
let MeterProCO2 = require('./MeterProCO2.js');
let Bot = require('./Bot.js');
let DeviceArray = require('./DeviceArray.js');
let PlugMini = require('./PlugMini.js');
let Hub2 = require('./Hub2.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');

module.exports = {
  Meter: Meter,
  Device: Device,
  StripLight: StripLight,
  MeterProCO2: MeterProCO2,
  Bot: Bot,
  DeviceArray: DeviceArray,
  PlugMini: PlugMini,
  Hub2: Hub2,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandAction: SwitchBotCommandAction,
};
