
"use strict";

let TestHeader = require('./TestHeader.js');
let TestChar = require('./TestChar.js');
let TestHeaderTwo = require('./TestHeaderTwo.js');
let TestTimeArray = require('./TestTimeArray.js');
let TestUInt8 = require('./TestUInt8.js');
let TestHeaderArray = require('./TestHeaderArray.js');
let Num = require('./Num.js');
let TestDurationArray = require('./TestDurationArray.js');
let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');

module.exports = {
  TestHeader: TestHeader,
  TestChar: TestChar,
  TestHeaderTwo: TestHeaderTwo,
  TestTimeArray: TestTimeArray,
  TestUInt8: TestUInt8,
  TestHeaderArray: TestHeaderArray,
  Num: Num,
  TestDurationArray: TestDurationArray,
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
};
