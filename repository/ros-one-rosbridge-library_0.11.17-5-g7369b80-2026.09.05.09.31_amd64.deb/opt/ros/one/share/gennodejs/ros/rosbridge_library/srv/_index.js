
"use strict";

let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestNestedService = require('./TestNestedService.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestEmpty = require('./TestEmpty.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let SendBytes = require('./SendBytes.js')

module.exports = {
  TestRequestAndResponse: TestRequestAndResponse,
  TestNestedService: TestNestedService,
  TestArrayRequest: TestArrayRequest,
  TestEmpty: TestEmpty,
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestRequestOnly: TestRequestOnly,
  AddTwoInts: AddTwoInts,
  TestResponseOnly: TestResponseOnly,
  SendBytes: SendBytes,
};
