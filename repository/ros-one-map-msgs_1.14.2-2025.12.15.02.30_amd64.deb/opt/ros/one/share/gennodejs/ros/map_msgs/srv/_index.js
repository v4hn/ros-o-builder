
"use strict";

let GetMapROI = require('./GetMapROI.js')
let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let SetMapProjections = require('./SetMapProjections.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let SaveMap = require('./SaveMap.js')
let GetPointMap = require('./GetPointMap.js')

module.exports = {
  GetMapROI: GetMapROI,
  ProjectedMapsInfo: ProjectedMapsInfo,
  SetMapProjections: SetMapProjections,
  GetPointMapROI: GetPointMapROI,
  SaveMap: SaveMap,
  GetPointMap: GetPointMap,
};
