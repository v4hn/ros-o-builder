
"use strict";

let Char = require('./Char.js');
let ColorRGBA = require('./ColorRGBA.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let Byte = require('./Byte.js');
let Float64MultiArray = require('./Float64MultiArray.js');
let Float32 = require('./Float32.js');
let Empty = require('./Empty.js');
let Bool = require('./Bool.js');
let Int32 = require('./Int32.js');
let UInt32 = require('./UInt32.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let Float64 = require('./Float64.js');
let Header = require('./Header.js');
let Duration = require('./Duration.js');
let Int8 = require('./Int8.js');
let Int16 = require('./Int16.js');
let Int64 = require('./Int64.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let UInt16 = require('./UInt16.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let UInt64 = require('./UInt64.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let UInt8 = require('./UInt8.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let String = require('./String.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Time = require('./Time.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Int8MultiArray = require('./Int8MultiArray.js');

module.exports = {
  Char: Char,
  ColorRGBA: ColorRGBA,
  Int16MultiArray: Int16MultiArray,
  Byte: Byte,
  Float64MultiArray: Float64MultiArray,
  Float32: Float32,
  Empty: Empty,
  Bool: Bool,
  Int32: Int32,
  UInt32: UInt32,
  MultiArrayLayout: MultiArrayLayout,
  Float64: Float64,
  Header: Header,
  Duration: Duration,
  Int8: Int8,
  Int16: Int16,
  Int64: Int64,
  Float32MultiArray: Float32MultiArray,
  Int64MultiArray: Int64MultiArray,
  UInt16: UInt16,
  UInt8MultiArray: UInt8MultiArray,
  UInt64: UInt64,
  ByteMultiArray: ByteMultiArray,
  UInt16MultiArray: UInt16MultiArray,
  UInt8: UInt8,
  Int32MultiArray: Int32MultiArray,
  UInt64MultiArray: UInt64MultiArray,
  String: String,
  MultiArrayDimension: MultiArrayDimension,
  Time: Time,
  UInt32MultiArray: UInt32MultiArray,
  Int8MultiArray: Int8MultiArray,
};
