
"use strict";

let TestUInt8 = require('./TestUInt8.js');
let TestHeaderTwo = require('./TestHeaderTwo.js');
let Num = require('./Num.js');
let TestHeaderArray = require('./TestHeaderArray.js');
let TestDurationArray = require('./TestDurationArray.js');
let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');
let TestHeader = require('./TestHeader.js');
let TestTimeArray = require('./TestTimeArray.js');
let TestChar = require('./TestChar.js');

module.exports = {
  TestUInt8: TestUInt8,
  TestHeaderTwo: TestHeaderTwo,
  Num: Num,
  TestHeaderArray: TestHeaderArray,
  TestDurationArray: TestDurationArray,
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
  TestHeader: TestHeader,
  TestTimeArray: TestTimeArray,
  TestChar: TestChar,
};
