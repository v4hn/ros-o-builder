# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${rostwitter_DIR}/.." "msg" rostwitter_MSG_INCLUDE_DIRS UNIQUE)
set(rostwitter_MSG_DEPENDENCIES actionlib_msgs)
