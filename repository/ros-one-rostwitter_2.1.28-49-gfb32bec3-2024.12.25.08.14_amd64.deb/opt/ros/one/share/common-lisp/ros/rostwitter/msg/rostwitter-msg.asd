
(cl:in-package :asdf)

(defsystem "rostwitter-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :actionlib_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "TweetAction" :depends-on ("_package_TweetAction"))
    (:file "_package_TweetAction" :depends-on ("_package"))
    (:file "TweetActionFeedback" :depends-on ("_package_TweetActionFeedback"))
    (:file "_package_TweetActionFeedback" :depends-on ("_package"))
    (:file "TweetActionGoal" :depends-on ("_package_TweetActionGoal"))
    (:file "_package_TweetActionGoal" :depends-on ("_package"))
    (:file "TweetActionResult" :depends-on ("_package_TweetActionResult"))
    (:file "_package_TweetActionResult" :depends-on ("_package"))
    (:file "TweetFeedback" :depends-on ("_package_TweetFeedback"))
    (:file "_package_TweetFeedback" :depends-on ("_package"))
    (:file "TweetGoal" :depends-on ("_package_TweetGoal"))
    (:file "_package_TweetGoal" :depends-on ("_package"))
    (:file "TweetResult" :depends-on ("_package_TweetResult"))
    (:file "_package_TweetResult" :depends-on ("_package"))
  ))