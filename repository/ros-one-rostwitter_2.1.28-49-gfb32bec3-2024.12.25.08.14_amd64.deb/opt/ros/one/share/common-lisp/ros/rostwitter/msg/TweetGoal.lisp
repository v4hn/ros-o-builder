; Auto-generated. Do not edit!


(cl:in-package rostwitter-msg)


;//! \htmlinclude TweetGoal.msg.html

(cl:defclass <TweetGoal> (roslisp-msg-protocol:ros-message)
  ((image
    :reader image
    :initarg :image
    :type cl:boolean
    :initform cl:nil)
   (image_topic_name
    :reader image_topic_name
    :initarg :image_topic_name
    :type cl:string
    :initform "")
   (speak
    :reader speak
    :initarg :speak
    :type cl:boolean
    :initform cl:nil)
   (text
    :reader text
    :initarg :text
    :type cl:string
    :initform "")
   (warning
    :reader warning
    :initarg :warning
    :type cl:boolean
    :initform cl:nil)
   (warning_time
    :reader warning_time
    :initarg :warning_time
    :type cl:fixnum
    :initform 0))
)

(cl:defclass TweetGoal (<TweetGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TweetGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TweetGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rostwitter-msg:<TweetGoal> is deprecated: use rostwitter-msg:TweetGoal instead.")))

(cl:ensure-generic-function 'image-val :lambda-list '(m))
(cl:defmethod image-val ((m <TweetGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rostwitter-msg:image-val is deprecated.  Use rostwitter-msg:image instead.")
  (image m))

(cl:ensure-generic-function 'image_topic_name-val :lambda-list '(m))
(cl:defmethod image_topic_name-val ((m <TweetGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rostwitter-msg:image_topic_name-val is deprecated.  Use rostwitter-msg:image_topic_name instead.")
  (image_topic_name m))

(cl:ensure-generic-function 'speak-val :lambda-list '(m))
(cl:defmethod speak-val ((m <TweetGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rostwitter-msg:speak-val is deprecated.  Use rostwitter-msg:speak instead.")
  (speak m))

(cl:ensure-generic-function 'text-val :lambda-list '(m))
(cl:defmethod text-val ((m <TweetGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rostwitter-msg:text-val is deprecated.  Use rostwitter-msg:text instead.")
  (text m))

(cl:ensure-generic-function 'warning-val :lambda-list '(m))
(cl:defmethod warning-val ((m <TweetGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rostwitter-msg:warning-val is deprecated.  Use rostwitter-msg:warning instead.")
  (warning m))

(cl:ensure-generic-function 'warning_time-val :lambda-list '(m))
(cl:defmethod warning_time-val ((m <TweetGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rostwitter-msg:warning_time-val is deprecated.  Use rostwitter-msg:warning_time instead.")
  (warning_time m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TweetGoal>) ostream)
  "Serializes a message object of type '<TweetGoal>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'image) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'image_topic_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'image_topic_name))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'speak) 1 0)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'text))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'text))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'warning) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'warning_time)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TweetGoal>) istream)
  "Deserializes a message object of type '<TweetGoal>"
    (cl:setf (cl:slot-value msg 'image) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'image_topic_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'image_topic_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'speak) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'text) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'text) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'warning) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'warning_time)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TweetGoal>)))
  "Returns string type for a message object of type '<TweetGoal>"
  "rostwitter/TweetGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TweetGoal)))
  "Returns string type for a message object of type 'TweetGoal"
  "rostwitter/TweetGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TweetGoal>)))
  "Returns md5sum for a message object of type '<TweetGoal>"
  "577f0283150a250e0ca629c7c0d07aa9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TweetGoal)))
  "Returns md5sum for a message object of type 'TweetGoal"
  "577f0283150a250e0ca629c7c0d07aa9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TweetGoal>)))
  "Returns full string definition for message of type '<TweetGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%bool image~%string image_topic_name~%bool speak~%string text~%bool warning~%uint8 warning_time~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TweetGoal)))
  "Returns full string definition for message of type 'TweetGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%bool image~%string image_topic_name~%bool speak~%string text~%bool warning~%uint8 warning_time~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TweetGoal>))
  (cl:+ 0
     1
     4 (cl:length (cl:slot-value msg 'image_topic_name))
     1
     4 (cl:length (cl:slot-value msg 'text))
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TweetGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'TweetGoal
    (cl:cons ':image (image msg))
    (cl:cons ':image_topic_name (image_topic_name msg))
    (cl:cons ':speak (speak msg))
    (cl:cons ':text (text msg))
    (cl:cons ':warning (warning msg))
    (cl:cons ':warning_time (warning_time msg))
))
