
"use strict";

let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');

module.exports = {
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorGoal: FaceDetectorGoal,
};
