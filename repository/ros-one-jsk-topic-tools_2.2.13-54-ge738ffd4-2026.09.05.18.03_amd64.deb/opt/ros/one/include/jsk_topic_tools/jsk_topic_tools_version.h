// -*- mode: c++ -*-
/*********************************************************************
 * Software License Agreement (BSD License)
 *
 *  Copyright (c) 2022, JSK Lab
 *  All rights reserved.
 *
 *  Redistribution and use in source and binary forms, with or without
 *  modification, are permitted provided that the following conditions
 *  are met:
 *
 *   * Redistributions of source code must retain the above copyright
 *     notice, this list of conditions and the following disclaimer.
 *   * Redistributions in binary form must reproduce the above
 *     copyright notice, this list of conditions and the following
 *     disclaimer in the documentation and/or other materials provided
 *     with the distribution.
 *   * Neither the name of the JSK Lab nor the names of its
 *     contributors may be used to endorse or promote products derived
 *     from this software without specific prior written permission.
 *
 *  THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS
 *  "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, BUT NOT
 *  LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS
 *  FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE
 *  COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT,
 *  INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES (INCLUDING,
 *  BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES;
 *  LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER
 *  CAUSED AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT
 *  LIABILITY, OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN
 *  ANY WAY OUT OF THE USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE
 *  POSSIBILITY OF SUCH DAMAGE.
 *********************************************************************/

#ifndef JSK_TOPIC_TOOLS_VERSION_
#define JSK_TOPIC_TOOLS_VERSION_

#define JSK_TOPIC_TOOLS_VERSION_MAJOR 2
#define JSK_TOPIC_TOOLS_VERSION_MINOR 2
#define JSK_TOPIC_TOOLS_VERSION_PATCH 16
#define JSK_TOPIC_TOOLS_VERSION_COMBINED(major, minor, patch) (((major) << 20) | ((minor) << 10) | (patch))
#define JSK_TOPIC_TOOLS_VERSION JSK_TOPIC_TOOLS_VERSION_COMBINED(JSK_TOPIC_TOOLS_VERSION_MAJOR, JSK_TOPIC_TOOLS_VERSION_MINOR, JSK_TOPIC_TOOLS_VERSION_PATCH)

#define JSK_TOPIC_TOOLS_GE(major1, minor1, patch1, major2, minor2, patch2) (JSK_TOPIC_TOOLS_VERSION_COMBINED(major1, minor1, patch1) >= JSK_TOPIC_TOOLS_VERSION_COMBINED(major2, minor2, patch2))
#define JSK_TOPIC_TOOLS_MINIMUM(major, minor, patch) JSK_TOPIC_TOOLS_GE(JSK_TOPIC_TOOLS_VERSION_MAJOR, JSK_TOPIC_TOOLS_VERSION_MINOR, JSK_TOPIC_TOOLS_VERSION_PATCH, major, minor, patch)

#endif
