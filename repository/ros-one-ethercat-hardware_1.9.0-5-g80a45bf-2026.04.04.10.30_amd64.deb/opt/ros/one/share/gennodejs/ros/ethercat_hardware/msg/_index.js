
"use strict";

let MotorTemperature = require('./MotorTemperature.js');
let RawFTDataSample = require('./RawFTDataSample.js');
let BoardInfo = require('./BoardInfo.js');
let ActuatorInfo = require('./ActuatorInfo.js');
let MotorTraceSample = require('./MotorTraceSample.js');
let MotorTrace = require('./MotorTrace.js');
let RawFTData = require('./RawFTData.js');

module.exports = {
  MotorTemperature: MotorTemperature,
  RawFTDataSample: RawFTDataSample,
  BoardInfo: BoardInfo,
  ActuatorInfo: ActuatorInfo,
  MotorTraceSample: MotorTraceSample,
  MotorTrace: MotorTrace,
  RawFTData: RawFTData,
};
