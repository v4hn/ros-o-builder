
"use strict";

let SoftProcessorFirmwareWrite = require('./SoftProcessorFirmwareWrite.js')
let SoftProcessorReset = require('./SoftProcessorReset.js')
let SoftProcessorFirmwareRead = require('./SoftProcessorFirmwareRead.js')

module.exports = {
  SoftProcessorFirmwareWrite: SoftProcessorFirmwareWrite,
  SoftProcessorReset: SoftProcessorReset,
  SoftProcessorFirmwareRead: SoftProcessorFirmwareRead,
};
