
"use strict";

let VoiceMessage = require('./VoiceMessage.js');
let DeviceSensor = require('./DeviceSensor.js');
let MagneticField = require('./MagneticField.js');
let Action = require('./Action.js');
let SlackMessage = require('./SlackMessage.js');
let MultiTouch = require('./MultiTouch.js');
let Gravity = require('./Gravity.js');
let Touch = require('./Touch.js');
let AndroidSensor = require('./AndroidSensor.js');
let Tablet = require('./Tablet.js');
let TouchEvent = require('./TouchEvent.js');

module.exports = {
  VoiceMessage: VoiceMessage,
  DeviceSensor: DeviceSensor,
  MagneticField: MagneticField,
  Action: Action,
  SlackMessage: SlackMessage,
  MultiTouch: MultiTouch,
  Gravity: Gravity,
  Touch: Touch,
  AndroidSensor: AndroidSensor,
  Tablet: Tablet,
  TouchEvent: TouchEvent,
};
