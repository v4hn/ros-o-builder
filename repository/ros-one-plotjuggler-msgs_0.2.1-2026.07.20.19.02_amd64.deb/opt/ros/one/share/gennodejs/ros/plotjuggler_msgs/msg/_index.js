
"use strict";

let DataPoint = require('./DataPoint.js');
let DataPoints = require('./DataPoints.js');
let StatisticsNames = require('./StatisticsNames.js');
let Dictionary = require('./Dictionary.js');
let StatisticsValues = require('./StatisticsValues.js');

module.exports = {
  DataPoint: DataPoint,
  DataPoints: DataPoints,
  StatisticsNames: StatisticsNames,
  Dictionary: Dictionary,
  StatisticsValues: StatisticsValues,
};
