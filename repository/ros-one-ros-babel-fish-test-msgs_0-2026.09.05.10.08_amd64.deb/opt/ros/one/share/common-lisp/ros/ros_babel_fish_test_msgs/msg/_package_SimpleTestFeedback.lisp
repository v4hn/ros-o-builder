(cl:in-package ros_babel_fish_test_msgs-msg)
(cl:export '(FEEDBACK-VAL
          FEEDBACK
))