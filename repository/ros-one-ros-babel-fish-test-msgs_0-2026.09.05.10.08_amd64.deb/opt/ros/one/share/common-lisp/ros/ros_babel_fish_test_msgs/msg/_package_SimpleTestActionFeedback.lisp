(cl:in-package ros_babel_fish_test_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          FEEDBACK-VAL
          FEEDBACK
))