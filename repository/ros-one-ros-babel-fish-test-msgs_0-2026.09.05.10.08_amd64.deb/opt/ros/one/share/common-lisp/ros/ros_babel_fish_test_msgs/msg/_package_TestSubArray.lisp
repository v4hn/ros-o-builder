(cl:in-package ros_babel_fish_test_msgs-msg)
(cl:export '(INTS-VAL
          INTS
          STRINGS-VAL
          STRINGS
          TIMES-VAL
          TIMES
))