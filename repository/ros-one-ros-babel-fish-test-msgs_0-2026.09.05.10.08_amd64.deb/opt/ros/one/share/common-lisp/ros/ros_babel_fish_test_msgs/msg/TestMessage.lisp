; Auto-generated. Do not edit!


(cl:in-package ros_babel_fish_test_msgs-msg)


;//! \htmlinclude TestMessage.msg.html

(cl:defclass <TestMessage> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (b
    :reader b
    :initarg :b
    :type cl:boolean
    :initform cl:nil)
   (ui8
    :reader ui8
    :initarg :ui8
    :type cl:fixnum
    :initform 0)
   (ui16
    :reader ui16
    :initarg :ui16
    :type cl:fixnum
    :initform 0)
   (ui32
    :reader ui32
    :initarg :ui32
    :type cl:integer
    :initform 0)
   (ui64
    :reader ui64
    :initarg :ui64
    :type cl:integer
    :initform 0)
   (i8
    :reader i8
    :initarg :i8
    :type cl:fixnum
    :initform 0)
   (i16
    :reader i16
    :initarg :i16
    :type cl:fixnum
    :initform 0)
   (i32
    :reader i32
    :initarg :i32
    :type cl:integer
    :initform 0)
   (i64
    :reader i64
    :initarg :i64
    :type cl:integer
    :initform 0)
   (f32
    :reader f32
    :initarg :f32
    :type cl:float
    :initform 0.0)
   (f64
    :reader f64
    :initarg :f64
    :type cl:float
    :initform 0.0)
   (str
    :reader str
    :initarg :str
    :type cl:string
    :initform "")
   (t
    :reader t
    :initarg :t
    :type cl:real
    :initform 0)
   (d
    :reader d
    :initarg :d
    :type cl:real
    :initform 0)
   (point_arr
    :reader point_arr
    :initarg :point_arr
    :type (cl:vector geometry_msgs-msg:Point)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Point :initial-element (cl:make-instance 'geometry_msgs-msg:Point))))
)

(cl:defclass TestMessage (<TestMessage>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TestMessage>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TestMessage)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ros_babel_fish_test_msgs-msg:<TestMessage> is deprecated: use ros_babel_fish_test_msgs-msg:TestMessage instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:header-val is deprecated.  Use ros_babel_fish_test_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'b-val :lambda-list '(m))
(cl:defmethod b-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:b-val is deprecated.  Use ros_babel_fish_test_msgs-msg:b instead.")
  (b m))

(cl:ensure-generic-function 'ui8-val :lambda-list '(m))
(cl:defmethod ui8-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:ui8-val is deprecated.  Use ros_babel_fish_test_msgs-msg:ui8 instead.")
  (ui8 m))

(cl:ensure-generic-function 'ui16-val :lambda-list '(m))
(cl:defmethod ui16-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:ui16-val is deprecated.  Use ros_babel_fish_test_msgs-msg:ui16 instead.")
  (ui16 m))

(cl:ensure-generic-function 'ui32-val :lambda-list '(m))
(cl:defmethod ui32-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:ui32-val is deprecated.  Use ros_babel_fish_test_msgs-msg:ui32 instead.")
  (ui32 m))

(cl:ensure-generic-function 'ui64-val :lambda-list '(m))
(cl:defmethod ui64-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:ui64-val is deprecated.  Use ros_babel_fish_test_msgs-msg:ui64 instead.")
  (ui64 m))

(cl:ensure-generic-function 'i8-val :lambda-list '(m))
(cl:defmethod i8-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:i8-val is deprecated.  Use ros_babel_fish_test_msgs-msg:i8 instead.")
  (i8 m))

(cl:ensure-generic-function 'i16-val :lambda-list '(m))
(cl:defmethod i16-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:i16-val is deprecated.  Use ros_babel_fish_test_msgs-msg:i16 instead.")
  (i16 m))

(cl:ensure-generic-function 'i32-val :lambda-list '(m))
(cl:defmethod i32-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:i32-val is deprecated.  Use ros_babel_fish_test_msgs-msg:i32 instead.")
  (i32 m))

(cl:ensure-generic-function 'i64-val :lambda-list '(m))
(cl:defmethod i64-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:i64-val is deprecated.  Use ros_babel_fish_test_msgs-msg:i64 instead.")
  (i64 m))

(cl:ensure-generic-function 'f32-val :lambda-list '(m))
(cl:defmethod f32-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:f32-val is deprecated.  Use ros_babel_fish_test_msgs-msg:f32 instead.")
  (f32 m))

(cl:ensure-generic-function 'f64-val :lambda-list '(m))
(cl:defmethod f64-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:f64-val is deprecated.  Use ros_babel_fish_test_msgs-msg:f64 instead.")
  (f64 m))

(cl:ensure-generic-function 'str-val :lambda-list '(m))
(cl:defmethod str-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:str-val is deprecated.  Use ros_babel_fish_test_msgs-msg:str instead.")
  (str m))

(cl:ensure-generic-function 't-val :lambda-list '(m))
(cl:defmethod t-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:t-val is deprecated.  Use ros_babel_fish_test_msgs-msg:t instead.")
  (t m))

(cl:ensure-generic-function 'd-val :lambda-list '(m))
(cl:defmethod d-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:d-val is deprecated.  Use ros_babel_fish_test_msgs-msg:d instead.")
  (d m))

(cl:ensure-generic-function 'point_arr-val :lambda-list '(m))
(cl:defmethod point_arr-val ((m <TestMessage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ros_babel_fish_test_msgs-msg:point_arr-val is deprecated.  Use ros_babel_fish_test_msgs-msg:point_arr instead.")
  (point_arr m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<TestMessage>)))
    "Constants for message type '<TestMessage>"
  '((:FLAG1 . True)
    (:FLAG2 . False)
    (:FLAG3 . True)
    (:FLAG4 . False))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'TestMessage)))
    "Constants for message type 'TestMessage"
  '((:FLAG1 . True)
    (:FLAG2 . False)
    (:FLAG3 . True)
    (:FLAG4 . False))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TestMessage>) ostream)
  "Serializes a message object of type '<TestMessage>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'b) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui8)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui16)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ui16)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui32)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ui32)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'ui32)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'ui32)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'ui64)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'ui64)) ostream)
  (cl:let* ((signed (cl:slot-value msg 'i8)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'i16)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'i32)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:let* ((signed (cl:slot-value msg 'i64)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 18446744073709551616) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'f32))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'f64))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'str))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'str))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 't)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 't) (cl:floor (cl:slot-value msg 't)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'd)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'd) (cl:floor (cl:slot-value msg 'd)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'point_arr))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'point_arr))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TestMessage>) istream)
  "Deserializes a message object of type '<TestMessage>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:setf (cl:slot-value msg 'b) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui8)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui16)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ui16)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui32)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ui32)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'ui32)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'ui32)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'ui64)) (cl:read-byte istream))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'i8) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'i16) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'i32) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'i64) (cl:if (cl:< unsigned 9223372036854775808) unsigned (cl:- unsigned 18446744073709551616))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'f32) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'f64) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'str) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'str) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 't) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'd) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'point_arr) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'point_arr)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Point))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TestMessage>)))
  "Returns string type for a message object of type '<TestMessage>"
  "ros_babel_fish_test_msgs/TestMessage")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TestMessage)))
  "Returns string type for a message object of type 'TestMessage"
  "ros_babel_fish_test_msgs/TestMessage")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TestMessage>)))
  "Returns md5sum for a message object of type '<TestMessage>"
  "3d5931b1835a6d921ed35d5d2d59b889")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TestMessage)))
  "Returns md5sum for a message object of type 'TestMessage"
  "3d5931b1835a6d921ed35d5d2d59b889")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TestMessage>)))
  "Returns full string definition for message of type '<TestMessage>"
  (cl:format cl:nil "Header header~%bool b~%uint8 ui8~%uint16 ui16~%uint32 ui32~%uint64 ui64~%int8 i8~%int16 i16~%int32 i32~%~%int64 i64~%float32 f32 # Comment~%float64 f64#Also a comment but closer~%string str## Two comment signs # and a third~%time t~%duration d~%geometry_msgs/Point[] point_arr # more comment~%~%bool FLAG1 =1~%bool FLAG2= 0~%bool FLAG3=True~%bool FLAG4 = False~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TestMessage)))
  "Returns full string definition for message of type 'TestMessage"
  (cl:format cl:nil "Header header~%bool b~%uint8 ui8~%uint16 ui16~%uint32 ui32~%uint64 ui64~%int8 i8~%int16 i16~%int32 i32~%~%int64 i64~%float32 f32 # Comment~%float64 f64#Also a comment but closer~%string str## Two comment signs # and a third~%time t~%duration d~%geometry_msgs/Point[] point_arr # more comment~%~%bool FLAG1 =1~%bool FLAG2= 0~%bool FLAG3=True~%bool FLAG4 = False~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TestMessage>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     1
     1
     2
     4
     8
     1
     2
     4
     8
     4
     8
     4 (cl:length (cl:slot-value msg 'str))
     8
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'point_arr) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TestMessage>))
  "Converts a ROS message object to a list"
  (cl:list 'TestMessage
    (cl:cons ':header (header msg))
    (cl:cons ':b (b msg))
    (cl:cons ':ui8 (ui8 msg))
    (cl:cons ':ui16 (ui16 msg))
    (cl:cons ':ui32 (ui32 msg))
    (cl:cons ':ui64 (ui64 msg))
    (cl:cons ':i8 (i8 msg))
    (cl:cons ':i16 (i16 msg))
    (cl:cons ':i32 (i32 msg))
    (cl:cons ':i64 (i64 msg))
    (cl:cons ':f32 (f32 msg))
    (cl:cons ':f64 (f64 msg))
    (cl:cons ':str (str msg))
    (cl:cons ':t (t msg))
    (cl:cons ':d (d msg))
    (cl:cons ':point_arr (point_arr msg))
))
