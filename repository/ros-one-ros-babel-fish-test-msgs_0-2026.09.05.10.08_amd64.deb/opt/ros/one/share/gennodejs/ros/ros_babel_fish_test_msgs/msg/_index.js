
"use strict";

let TestMessage = require('./TestMessage.js');
let TestArray = require('./TestArray.js');
let TestSubArray = require('./TestSubArray.js');
let SimpleTestActionGoal = require('./SimpleTestActionGoal.js');
let SimpleTestActionFeedback = require('./SimpleTestActionFeedback.js');
let SimpleTestGoal = require('./SimpleTestGoal.js');
let SimpleTestFeedback = require('./SimpleTestFeedback.js');
let SimpleTestActionResult = require('./SimpleTestActionResult.js');
let SimpleTestAction = require('./SimpleTestAction.js');
let SimpleTestResult = require('./SimpleTestResult.js');

module.exports = {
  TestMessage: TestMessage,
  TestArray: TestArray,
  TestSubArray: TestSubArray,
  SimpleTestActionGoal: SimpleTestActionGoal,
  SimpleTestActionFeedback: SimpleTestActionFeedback,
  SimpleTestGoal: SimpleTestGoal,
  SimpleTestFeedback: SimpleTestFeedback,
  SimpleTestActionResult: SimpleTestActionResult,
  SimpleTestAction: SimpleTestAction,
  SimpleTestResult: SimpleTestResult,
};
