# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${ros_babel_fish_test_msgs_DIR}/.." "msg;msg" ros_babel_fish_test_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(ros_babel_fish_test_msgs_MSG_DEPENDENCIES actionlib_msgs;std_msgs;geometry_msgs)
