set(ros_babel_fish_test_msgs_MESSAGE_FILES "msg/TestArray.msg;msg/TestMessage.msg;msg/TestSubArray.msg;msg/SimpleTestAction.msg;msg/SimpleTestActionGoal.msg;msg/SimpleTestActionResult.msg;msg/SimpleTestActionFeedback.msg;msg/SimpleTestGoal.msg;msg/SimpleTestResult.msg;msg/SimpleTestFeedback.msg")
set(ros_babel_fish_test_msgs_SERVICE_FILES "")
