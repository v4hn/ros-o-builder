
"use strict";

let SetParam = require('./SetParam.js')
let MongoInsert = require('./MongoInsert.js')
let MongoUpdate = require('./MongoUpdate.js')
let GetParam = require('./GetParam.js')
let MongoFind = require('./MongoFind.js')

module.exports = {
  SetParam: SetParam,
  MongoInsert: MongoInsert,
  MongoUpdate: MongoUpdate,
  GetParam: GetParam,
  MongoFind: MongoFind,
};
