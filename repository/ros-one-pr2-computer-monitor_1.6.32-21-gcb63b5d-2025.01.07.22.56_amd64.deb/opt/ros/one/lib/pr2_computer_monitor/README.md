This is the indigo code, and will not work correctly on a precise machine
