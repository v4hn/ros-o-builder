// Auto-generated. Do not edit!

// (in-package cras_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetColorRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.color = null;
    }
    else {
      if (initObj.hasOwnProperty('color')) {
        this.color = initObj.color
      }
      else {
        this.color = new std_msgs.msg.ColorRGBA();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetColorRequest
    // Serialize message field [color]
    bufferOffset = std_msgs.msg.ColorRGBA.serialize(obj.color, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetColorRequest
    let len;
    let data = new SetColorRequest(null);
    // Deserialize message field [color]
    data.color = std_msgs.msg.ColorRGBA.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 16;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cras_msgs/SetColorRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3e04b62b1b39cd97e873789f0bb130e7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Set color of e.g. a color light (RGB LED, OLED...).
    
    std_msgs/ColorRGBA color  # The requested color. All channels values 0.0 - 1.0.
                              # If this denotes the color of a (LED) light, black means either no light or actual
                              # black if the device can produce it.
                              # Some devices may use alpha e.g. as backlight intensity or as visual preview alpha,
                              # so rather set it to 1.0 if you don't know.
    
    ================================================================================
    MSG: std_msgs/ColorRGBA
    float32 r
    float32 g
    float32 b
    float32 a
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetColorRequest(null);
    if (msg.color !== undefined) {
      resolved.color = std_msgs.msg.ColorRGBA.Resolve(msg.color)
    }
    else {
      resolved.color = new std_msgs.msg.ColorRGBA()
    }

    return resolved;
    }
};

class SetColorResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetColorResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetColorResponse
    let len;
    let data = new SetColorResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cras_msgs/SetColorResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # If a failure occurs, the service server should throw an exception.
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetColorResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: SetColorRequest,
  Response: SetColorResponse,
  md5sum() { return '3e04b62b1b39cd97e873789f0bb130e7'; },
  datatype() { return 'cras_msgs/SetColor'; }
};
