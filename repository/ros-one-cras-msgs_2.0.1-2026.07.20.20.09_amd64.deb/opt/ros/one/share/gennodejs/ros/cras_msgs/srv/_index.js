
"use strict";

let SetBrightness = require('./SetBrightness.js')
let SetColor = require('./SetColor.js')

module.exports = {
  SetBrightness: SetBrightness,
  SetColor: SetColor,
};
