
"use strict";

let Brightness = require('./Brightness.js');
let PowerSwitchState = require('./PowerSwitchState.js');
let PowerStamped = require('./PowerStamped.js');
let Heartbeat = require('./Heartbeat.js');
let ColorRGBAStamped = require('./ColorRGBAStamped.js');
let ElectricCurrentStamped = require('./ElectricCurrentStamped.js');
let PowerSwitchStateStamped = require('./PowerSwitchStateStamped.js');
let BrightnessStamped = require('./BrightnessStamped.js');
let ElectricCurrent = require('./ElectricCurrent.js');
let VoltageStamped = require('./VoltageStamped.js');
let Voltage = require('./Voltage.js');
let Power = require('./Power.js');
let ElectricCurrentMeasurement = require('./ElectricCurrentMeasurement.js');
let PowerMeasurement = require('./PowerMeasurement.js');
let VoltageMeasurement = require('./VoltageMeasurement.js');

module.exports = {
  Brightness: Brightness,
  PowerSwitchState: PowerSwitchState,
  PowerStamped: PowerStamped,
  Heartbeat: Heartbeat,
  ColorRGBAStamped: ColorRGBAStamped,
  ElectricCurrentStamped: ElectricCurrentStamped,
  PowerSwitchStateStamped: PowerSwitchStateStamped,
  BrightnessStamped: BrightnessStamped,
  ElectricCurrent: ElectricCurrent,
  VoltageStamped: VoltageStamped,
  Voltage: Voltage,
  Power: Power,
  ElectricCurrentMeasurement: ElectricCurrentMeasurement,
  PowerMeasurement: PowerMeasurement,
  VoltageMeasurement: VoltageMeasurement,
};
