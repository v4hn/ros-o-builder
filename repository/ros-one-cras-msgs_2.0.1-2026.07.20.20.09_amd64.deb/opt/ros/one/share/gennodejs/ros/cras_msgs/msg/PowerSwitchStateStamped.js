// Auto-generated. Do not edit!

// (in-package cras_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PowerSwitchState = require('./PowerSwitchState.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class PowerSwitchStateStamped {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.state = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('state')) {
        this.state = initObj.state
      }
      else {
        this.state = new PowerSwitchState();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PowerSwitchStateStamped
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [state]
    bufferOffset = PowerSwitchState.serialize(obj.state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PowerSwitchStateStamped
    let len;
    let data = new PowerSwitchStateStamped(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [state]
    data.state = PowerSwitchState.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cras_msgs/PowerSwitchStateStamped';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '288534a6596dc59cac36ed7b6ded41de';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # State of a power switch (a relay, a transistor, FET...).
    
    std_msgs/Header header  # stamp is the time the power switch state was measured.
                            # frame_id is the location of the power switch (does not need to be TF frame).
    PowerSwitchState state  # State of the power switch light.
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: cras_msgs/PowerSwitchState
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # State of a power switch (a relay, a transistor, FET...).
     
    bool on  # If true, the power switch is on, i.e. the electric path is connected.
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PowerSwitchStateStamped(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.state !== undefined) {
      resolved.state = PowerSwitchState.Resolve(msg.state)
    }
    else {
      resolved.state = new PowerSwitchState()
    }

    return resolved;
    }
};

module.exports = PowerSwitchStateStamped;
