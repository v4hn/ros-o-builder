// Auto-generated. Do not edit!

// (in-package cras_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let VoltageMeasurement = require('./VoltageMeasurement.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class VoltageStamped {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.measurement = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('measurement')) {
        this.measurement = initObj.measurement
      }
      else {
        this.measurement = new VoltageMeasurement();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type VoltageStamped
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [measurement]
    bufferOffset = VoltageMeasurement.serialize(obj.measurement, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type VoltageStamped
    let len;
    let data = new VoltageStamped(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [measurement]
    data.measurement = VoltageMeasurement.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cras_msgs/VoltageStamped';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '7ad151ea5b22b0a4a593a740a69427c9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Single voltage measurement.
    
    std_msgs/Header header  # stamp is the time the voltage was measured.
                            # frame_id is the location of the voltage measurement (does not need to be a TF frame).
    VoltageMeasurement measurement  # The measured voltage.
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: cras_msgs/VoltageMeasurement
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Single voltage measurement.
     
    Voltage data  # Voltage value.
    float64 variance  # Variance of the measurement (in Volt^2). If not known or relevant, use 0.
    duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.
    
    ================================================================================
    MSG: cras_msgs/Voltage
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Single voltage value.
     
    float64 voltage  # Voltage value (in Volts).
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new VoltageStamped(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.measurement !== undefined) {
      resolved.measurement = VoltageMeasurement.Resolve(msg.measurement)
    }
    else {
      resolved.measurement = new VoltageMeasurement()
    }

    return resolved;
    }
};

module.exports = VoltageStamped;
