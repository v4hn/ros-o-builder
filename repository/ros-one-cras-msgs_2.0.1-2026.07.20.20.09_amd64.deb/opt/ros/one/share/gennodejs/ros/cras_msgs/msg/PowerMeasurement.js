// Auto-generated. Do not edit!

// (in-package cras_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Power = require('./Power.js');

//-----------------------------------------------------------

class PowerMeasurement {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.data = null;
      this.variance = null;
      this.sample_duration = null;
    }
    else {
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = new Power();
      }
      if (initObj.hasOwnProperty('variance')) {
        this.variance = initObj.variance
      }
      else {
        this.variance = 0.0;
      }
      if (initObj.hasOwnProperty('sample_duration')) {
        this.sample_duration = initObj.sample_duration
      }
      else {
        this.sample_duration = {secs: 0, nsecs: 0};
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PowerMeasurement
    // Serialize message field [data]
    bufferOffset = Power.serialize(obj.data, buffer, bufferOffset);
    // Serialize message field [variance]
    bufferOffset = _serializer.float64(obj.variance, buffer, bufferOffset);
    // Serialize message field [sample_duration]
    bufferOffset = _serializer.duration(obj.sample_duration, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PowerMeasurement
    let len;
    let data = new PowerMeasurement(null);
    // Deserialize message field [data]
    data.data = Power.deserialize(buffer, bufferOffset);
    // Deserialize message field [variance]
    data.variance = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sample_duration]
    data.sample_duration = _deserializer.duration(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cras_msgs/PowerMeasurement';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'acef8a11a2a0421c98a65e6fc99a2fd1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Single power measurement.
     
    Power data  # Power value.
    float64 variance  # Variance of the measurement (in Watt^2). If not known or relevant, use 0.
    duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.
    
    ================================================================================
    MSG: cras_msgs/Power
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Mechanical or electrical power value.
     
    float64 power  # Power value (in Watts).
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PowerMeasurement(null);
    if (msg.data !== undefined) {
      resolved.data = Power.Resolve(msg.data)
    }
    else {
      resolved.data = new Power()
    }

    if (msg.variance !== undefined) {
      resolved.variance = msg.variance;
    }
    else {
      resolved.variance = 0.0
    }

    if (msg.sample_duration !== undefined) {
      resolved.sample_duration = msg.sample_duration;
    }
    else {
      resolved.sample_duration = {secs: 0, nsecs: 0}
    }

    return resolved;
    }
};

module.exports = PowerMeasurement;
