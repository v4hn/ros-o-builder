// Auto-generated. Do not edit!

// (in-package cras_msgs.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Brightness = require('../msg/Brightness.js');

//-----------------------------------------------------------


//-----------------------------------------------------------

class SetBrightnessRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.value = null;
    }
    else {
      if (initObj.hasOwnProperty('value')) {
        this.value = initObj.value
      }
      else {
        this.value = new Brightness();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetBrightnessRequest
    // Serialize message field [value]
    bufferOffset = Brightness.serialize(obj.value, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetBrightnessRequest
    let len;
    let data = new SetBrightnessRequest(null);
    // Deserialize message field [value]
    data.value = Brightness.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cras_msgs/SetBrightnessRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2e29c05fe08ad1a62cdddbfafe2a17d9';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Set the brightness of e.g. a dimmable light.
    
    Brightness value  # The requested brightness.
    
    ================================================================================
    MSG: cras_msgs/Brightness
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Brightness of e.g. a dimmable light (LED, OLED, ...).
     
    float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetBrightnessRequest(null);
    if (msg.value !== undefined) {
      resolved.value = Brightness.Resolve(msg.value)
    }
    else {
      resolved.value = new Brightness()
    }

    return resolved;
    }
};

class SetBrightnessResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SetBrightnessResponse
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SetBrightnessResponse
    let len;
    let data = new SetBrightnessResponse(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'cras_msgs/SetBrightnessResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # If a failure occurs, the service server should throw an exception.
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SetBrightnessResponse(null);
    return resolved;
    }
};

module.exports = {
  Request: SetBrightnessRequest,
  Response: SetBrightnessResponse,
  md5sum() { return '2e29c05fe08ad1a62cdddbfafe2a17d9'; },
  datatype() { return 'cras_msgs/SetBrightness'; }
};
