// Auto-generated. Do not edit!

// (in-package cras_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ElectricCurrentMeasurement = require('./ElectricCurrentMeasurement.js');
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class ElectricCurrentStamped {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.measurement = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('measurement')) {
        this.measurement = initObj.measurement
      }
      else {
        this.measurement = new ElectricCurrentMeasurement();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ElectricCurrentStamped
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [measurement]
    bufferOffset = ElectricCurrentMeasurement.serialize(obj.measurement, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ElectricCurrentStamped
    let len;
    let data = new ElectricCurrentStamped(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [measurement]
    data.measurement = ElectricCurrentMeasurement.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'cras_msgs/ElectricCurrentStamped';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '232a3dbde3aa71d360b0bb56bd05bf05';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
    
    # Single stamped electric current measurement.
    
    std_msgs/Header header  # stamp is the time the current was measured.
                            # frame_id is the location of the current measurement (does not need to be a TF frame).
    ElectricCurrentMeasurement measurement  # The measured current.
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: cras_msgs/ElectricCurrentMeasurement
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
     
    # Single electric current measurement.
     
    ElectricCurrent data  # Current value.
    float64 variance  # Variance of the measurement (in Amperes^2). If not known or relevant, use 0.
    duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.
    
    ================================================================================
    MSG: cras_msgs/ElectricCurrent
    # SPDX-License-Identifier: BSD-3-Clause
    # SPDX-FileCopyrightText: Czech Technical University in Prague
     
    # Single electric current value.
     
    float64 current  # Current value (in Amperes).
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ElectricCurrentStamped(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.measurement !== undefined) {
      resolved.measurement = ElectricCurrentMeasurement.Resolve(msg.measurement)
    }
    else {
      resolved.measurement = new ElectricCurrentMeasurement()
    }

    return resolved;
    }
};

module.exports = ElectricCurrentStamped;
