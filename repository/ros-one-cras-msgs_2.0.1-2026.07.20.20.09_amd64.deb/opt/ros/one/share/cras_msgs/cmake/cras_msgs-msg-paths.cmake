# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${cras_msgs_DIR}/.." "msg;msg" cras_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(cras_msgs_MSG_DEPENDENCIES std_msgs)
