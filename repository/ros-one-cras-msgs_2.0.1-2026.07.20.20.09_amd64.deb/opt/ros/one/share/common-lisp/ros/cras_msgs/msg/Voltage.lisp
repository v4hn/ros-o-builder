; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude Voltage.msg.html

(cl:defclass <Voltage> (roslisp-msg-protocol:ros-message)
  ((voltage
    :reader voltage
    :initarg :voltage
    :type cl:float
    :initform 0.0))
)

(cl:defclass Voltage (<Voltage>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Voltage>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Voltage)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<Voltage> is deprecated: use cras_msgs-msg:Voltage instead.")))

(cl:ensure-generic-function 'voltage-val :lambda-list '(m))
(cl:defmethod voltage-val ((m <Voltage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:voltage-val is deprecated.  Use cras_msgs-msg:voltage instead.")
  (voltage m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Voltage>) ostream)
  "Serializes a message object of type '<Voltage>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'voltage))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Voltage>) istream)
  "Deserializes a message object of type '<Voltage>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'voltage) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Voltage>)))
  "Returns string type for a message object of type '<Voltage>"
  "cras_msgs/Voltage")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Voltage)))
  "Returns string type for a message object of type 'Voltage"
  "cras_msgs/Voltage")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Voltage>)))
  "Returns md5sum for a message object of type '<Voltage>"
  "cd1e97d74e6d797b46bc5a51e820e6ae")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Voltage)))
  "Returns md5sum for a message object of type 'Voltage"
  "cd1e97d74e6d797b46bc5a51e820e6ae")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Voltage>)))
  "Returns full string definition for message of type '<Voltage>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage value.~% ~%float64 voltage  # Voltage value (in Volts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Voltage)))
  "Returns full string definition for message of type 'Voltage"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage value.~% ~%float64 voltage  # Voltage value (in Volts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Voltage>))
  (cl:+ 0
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Voltage>))
  "Converts a ROS message object to a list"
  (cl:list 'Voltage
    (cl:cons ':voltage (voltage msg))
))
