(cl:in-package cras_msgs-srv)
(cl:export '(COLOR-VAL
          COLOR
))