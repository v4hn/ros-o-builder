(cl:in-package cras_msgs-msg)
(cl:export '(CURRENT-VAL
          CURRENT
))