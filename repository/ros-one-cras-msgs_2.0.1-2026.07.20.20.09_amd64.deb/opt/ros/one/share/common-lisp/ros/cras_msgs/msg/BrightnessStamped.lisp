; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude BrightnessStamped.msg.html

(cl:defclass <BrightnessStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (value
    :reader value
    :initarg :value
    :type cras_msgs-msg:Brightness
    :initform (cl:make-instance 'cras_msgs-msg:Brightness)))
)

(cl:defclass BrightnessStamped (<BrightnessStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <BrightnessStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'BrightnessStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<BrightnessStamped> is deprecated: use cras_msgs-msg:BrightnessStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <BrightnessStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:header-val is deprecated.  Use cras_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'value-val :lambda-list '(m))
(cl:defmethod value-val ((m <BrightnessStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:value-val is deprecated.  Use cras_msgs-msg:value instead.")
  (value m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <BrightnessStamped>) ostream)
  "Serializes a message object of type '<BrightnessStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'value) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <BrightnessStamped>) istream)
  "Deserializes a message object of type '<BrightnessStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'value) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<BrightnessStamped>)))
  "Returns string type for a message object of type '<BrightnessStamped>"
  "cras_msgs/BrightnessStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'BrightnessStamped)))
  "Returns string type for a message object of type 'BrightnessStamped"
  "cras_msgs/BrightnessStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<BrightnessStamped>)))
  "Returns md5sum for a message object of type '<BrightnessStamped>"
  "cb7f413966f1eb0d2fd911d0cba22e90")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'BrightnessStamped)))
  "Returns md5sum for a message object of type 'BrightnessStamped"
  "cb7f413966f1eb0d2fd911d0cba22e90")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<BrightnessStamped>)))
  "Returns full string definition for message of type '<BrightnessStamped>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~%~%std_msgs/Header header  # stamp is the time the brightness was measured.~%                        # frame_id is the location of the measurement (does not need to be TF frame, but it is recommended).~%Brightness value  # Brightness.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/Brightness~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~% ~%float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'BrightnessStamped)))
  "Returns full string definition for message of type 'BrightnessStamped"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~%~%std_msgs/Header header  # stamp is the time the brightness was measured.~%                        # frame_id is the location of the measurement (does not need to be TF frame, but it is recommended).~%Brightness value  # Brightness.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/Brightness~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~% ~%float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <BrightnessStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'value))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <BrightnessStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'BrightnessStamped
    (cl:cons ':header (header msg))
    (cl:cons ':value (value msg))
))
