; Auto-generated. Do not edit!


(cl:in-package cras_msgs-srv)


;//! \htmlinclude SetColor-request.msg.html

(cl:defclass <SetColor-request> (roslisp-msg-protocol:ros-message)
  ((color
    :reader color
    :initarg :color
    :type std_msgs-msg:ColorRGBA
    :initform (cl:make-instance 'std_msgs-msg:ColorRGBA)))
)

(cl:defclass SetColor-request (<SetColor-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetColor-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetColor-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-srv:<SetColor-request> is deprecated: use cras_msgs-srv:SetColor-request instead.")))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <SetColor-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-srv:color-val is deprecated.  Use cras_msgs-srv:color instead.")
  (color m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetColor-request>) ostream)
  "Serializes a message object of type '<SetColor-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetColor-request>) istream)
  "Deserializes a message object of type '<SetColor-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetColor-request>)))
  "Returns string type for a service object of type '<SetColor-request>"
  "cras_msgs/SetColorRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetColor-request)))
  "Returns string type for a service object of type 'SetColor-request"
  "cras_msgs/SetColorRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetColor-request>)))
  "Returns md5sum for a message object of type '<SetColor-request>"
  "3e04b62b1b39cd97e873789f0bb130e7")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetColor-request)))
  "Returns md5sum for a message object of type 'SetColor-request"
  "3e04b62b1b39cd97e873789f0bb130e7")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetColor-request>)))
  "Returns full string definition for message of type '<SetColor-request>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Set color of e.g. a color light (RGB LED, OLED...).~%~%std_msgs/ColorRGBA color  # The requested color. All channels values 0.0 - 1.0.~%                          # If this denotes the color of a (LED) light, black means either no light or actual~%                          # black if the device can produce it.~%                          # Some devices may use alpha e.g. as backlight intensity or as visual preview alpha,~%                          # so rather set it to 1.0 if you don't know.~%~%================================================================================~%MSG: std_msgs/ColorRGBA~%float32 r~%float32 g~%float32 b~%float32 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetColor-request)))
  "Returns full string definition for message of type 'SetColor-request"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Set color of e.g. a color light (RGB LED, OLED...).~%~%std_msgs/ColorRGBA color  # The requested color. All channels values 0.0 - 1.0.~%                          # If this denotes the color of a (LED) light, black means either no light or actual~%                          # black if the device can produce it.~%                          # Some devices may use alpha e.g. as backlight intensity or as visual preview alpha,~%                          # so rather set it to 1.0 if you don't know.~%~%================================================================================~%MSG: std_msgs/ColorRGBA~%float32 r~%float32 g~%float32 b~%float32 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetColor-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetColor-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetColor-request
    (cl:cons ':color (color msg))
))
;//! \htmlinclude SetColor-response.msg.html

(cl:defclass <SetColor-response> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass SetColor-response (<SetColor-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetColor-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetColor-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-srv:<SetColor-response> is deprecated: use cras_msgs-srv:SetColor-response instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetColor-response>) ostream)
  "Serializes a message object of type '<SetColor-response>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetColor-response>) istream)
  "Deserializes a message object of type '<SetColor-response>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetColor-response>)))
  "Returns string type for a service object of type '<SetColor-response>"
  "cras_msgs/SetColorResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetColor-response)))
  "Returns string type for a service object of type 'SetColor-response"
  "cras_msgs/SetColorResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetColor-response>)))
  "Returns md5sum for a message object of type '<SetColor-response>"
  "3e04b62b1b39cd97e873789f0bb130e7")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetColor-response)))
  "Returns md5sum for a message object of type 'SetColor-response"
  "3e04b62b1b39cd97e873789f0bb130e7")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetColor-response>)))
  "Returns full string definition for message of type '<SetColor-response>"
  (cl:format cl:nil "# If a failure occurs, the service server should throw an exception.~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetColor-response)))
  "Returns full string definition for message of type 'SetColor-response"
  (cl:format cl:nil "# If a failure occurs, the service server should throw an exception.~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetColor-response>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetColor-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetColor-response
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetColor)))
  'SetColor-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetColor)))
  'SetColor-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetColor)))
  "Returns string type for a service object of type '<SetColor>"
  "cras_msgs/SetColor")