(cl:in-package cras_msgs-msg)
(cl:export '(BRIGHTNESS-VAL
          BRIGHTNESS
))