; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude Brightness.msg.html

(cl:defclass <Brightness> (roslisp-msg-protocol:ros-message)
  ((brightness
    :reader brightness
    :initarg :brightness
    :type cl:float
    :initform 0.0))
)

(cl:defclass Brightness (<Brightness>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Brightness>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Brightness)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<Brightness> is deprecated: use cras_msgs-msg:Brightness instead.")))

(cl:ensure-generic-function 'brightness-val :lambda-list '(m))
(cl:defmethod brightness-val ((m <Brightness>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:brightness-val is deprecated.  Use cras_msgs-msg:brightness instead.")
  (brightness m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Brightness>) ostream)
  "Serializes a message object of type '<Brightness>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'brightness))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Brightness>) istream)
  "Deserializes a message object of type '<Brightness>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'brightness) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Brightness>)))
  "Returns string type for a message object of type '<Brightness>"
  "cras_msgs/Brightness")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Brightness)))
  "Returns string type for a message object of type 'Brightness"
  "cras_msgs/Brightness")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Brightness>)))
  "Returns md5sum for a message object of type '<Brightness>"
  "b9d8ec49eff2b364d8cb9e2334f00029")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Brightness)))
  "Returns md5sum for a message object of type 'Brightness"
  "b9d8ec49eff2b364d8cb9e2334f00029")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Brightness>)))
  "Returns full string definition for message of type '<Brightness>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~% ~%float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Brightness)))
  "Returns full string definition for message of type 'Brightness"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~% ~%float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Brightness>))
  (cl:+ 0
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Brightness>))
  "Converts a ROS message object to a list"
  (cl:list 'Brightness
    (cl:cons ':brightness (brightness msg))
))
