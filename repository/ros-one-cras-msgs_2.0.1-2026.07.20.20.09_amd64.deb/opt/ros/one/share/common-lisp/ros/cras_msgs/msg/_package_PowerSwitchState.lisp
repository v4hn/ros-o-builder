(cl:in-package cras_msgs-msg)
(cl:export '(ON-VAL
          ON
))