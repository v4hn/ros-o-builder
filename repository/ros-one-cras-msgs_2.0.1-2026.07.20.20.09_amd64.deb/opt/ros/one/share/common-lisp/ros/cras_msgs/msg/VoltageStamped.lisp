; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude VoltageStamped.msg.html

(cl:defclass <VoltageStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (measurement
    :reader measurement
    :initarg :measurement
    :type cras_msgs-msg:VoltageMeasurement
    :initform (cl:make-instance 'cras_msgs-msg:VoltageMeasurement)))
)

(cl:defclass VoltageStamped (<VoltageStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <VoltageStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'VoltageStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<VoltageStamped> is deprecated: use cras_msgs-msg:VoltageStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <VoltageStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:header-val is deprecated.  Use cras_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'measurement-val :lambda-list '(m))
(cl:defmethod measurement-val ((m <VoltageStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:measurement-val is deprecated.  Use cras_msgs-msg:measurement instead.")
  (measurement m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <VoltageStamped>) ostream)
  "Serializes a message object of type '<VoltageStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'measurement) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <VoltageStamped>) istream)
  "Deserializes a message object of type '<VoltageStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'measurement) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<VoltageStamped>)))
  "Returns string type for a message object of type '<VoltageStamped>"
  "cras_msgs/VoltageStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'VoltageStamped)))
  "Returns string type for a message object of type 'VoltageStamped"
  "cras_msgs/VoltageStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<VoltageStamped>)))
  "Returns md5sum for a message object of type '<VoltageStamped>"
  "7ad151ea5b22b0a4a593a740a69427c9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'VoltageStamped)))
  "Returns md5sum for a message object of type 'VoltageStamped"
  "7ad151ea5b22b0a4a593a740a69427c9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<VoltageStamped>)))
  "Returns full string definition for message of type '<VoltageStamped>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage measurement.~%~%std_msgs/Header header  # stamp is the time the voltage was measured.~%                        # frame_id is the location of the voltage measurement (does not need to be a TF frame).~%VoltageMeasurement measurement  # The measured voltage.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/VoltageMeasurement~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage measurement.~% ~%Voltage data  # Voltage value.~%float64 variance  # Variance of the measurement (in Volt^2). If not known or relevant, use 0.~%duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.~%~%================================================================================~%MSG: cras_msgs/Voltage~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage value.~% ~%float64 voltage  # Voltage value (in Volts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'VoltageStamped)))
  "Returns full string definition for message of type 'VoltageStamped"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage measurement.~%~%std_msgs/Header header  # stamp is the time the voltage was measured.~%                        # frame_id is the location of the voltage measurement (does not need to be a TF frame).~%VoltageMeasurement measurement  # The measured voltage.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/VoltageMeasurement~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage measurement.~% ~%Voltage data  # Voltage value.~%float64 variance  # Variance of the measurement (in Volt^2). If not known or relevant, use 0.~%duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.~%~%================================================================================~%MSG: cras_msgs/Voltage~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage value.~% ~%float64 voltage  # Voltage value (in Volts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <VoltageStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'measurement))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <VoltageStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'VoltageStamped
    (cl:cons ':header (header msg))
    (cl:cons ':measurement (measurement msg))
))
