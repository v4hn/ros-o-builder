(cl:in-package cras_msgs-srv)
(cl:export '(VALUE-VAL
          VALUE
))