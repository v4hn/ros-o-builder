; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude ColorRGBAStamped.msg.html

(cl:defclass <ColorRGBAStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (value
    :reader value
    :initarg :value
    :type std_msgs-msg:ColorRGBA
    :initform (cl:make-instance 'std_msgs-msg:ColorRGBA)))
)

(cl:defclass ColorRGBAStamped (<ColorRGBAStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ColorRGBAStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ColorRGBAStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<ColorRGBAStamped> is deprecated: use cras_msgs-msg:ColorRGBAStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <ColorRGBAStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:header-val is deprecated.  Use cras_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'value-val :lambda-list '(m))
(cl:defmethod value-val ((m <ColorRGBAStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:value-val is deprecated.  Use cras_msgs-msg:value instead.")
  (value m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ColorRGBAStamped>) ostream)
  "Serializes a message object of type '<ColorRGBAStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'value) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ColorRGBAStamped>) istream)
  "Deserializes a message object of type '<ColorRGBAStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'value) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ColorRGBAStamped>)))
  "Returns string type for a message object of type '<ColorRGBAStamped>"
  "cras_msgs/ColorRGBAStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ColorRGBAStamped)))
  "Returns string type for a message object of type 'ColorRGBAStamped"
  "cras_msgs/ColorRGBAStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ColorRGBAStamped>)))
  "Returns md5sum for a message object of type '<ColorRGBAStamped>"
  "f3f6e19839cedc5680f6512ebc591816")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ColorRGBAStamped)))
  "Returns md5sum for a message object of type 'ColorRGBAStamped"
  "f3f6e19839cedc5680f6512ebc591816")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ColorRGBAStamped>)))
  "Returns full string definition for message of type '<ColorRGBAStamped>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# The color e.g. of an object or of a light like RGB LED, OLED, ...~%~%std_msgs/Header header  # stamp is the time the color was measured.~%                        # frame_id is the location of the measurement (does not need to be TF frame, but it is recommended).~%std_msgs/ColorRGBA value  # The color.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: std_msgs/ColorRGBA~%float32 r~%float32 g~%float32 b~%float32 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ColorRGBAStamped)))
  "Returns full string definition for message of type 'ColorRGBAStamped"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# The color e.g. of an object or of a light like RGB LED, OLED, ...~%~%std_msgs/Header header  # stamp is the time the color was measured.~%                        # frame_id is the location of the measurement (does not need to be TF frame, but it is recommended).~%std_msgs/ColorRGBA value  # The color.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: std_msgs/ColorRGBA~%float32 r~%float32 g~%float32 b~%float32 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ColorRGBAStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'value))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ColorRGBAStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'ColorRGBAStamped
    (cl:cons ':header (header msg))
    (cl:cons ':value (value msg))
))
