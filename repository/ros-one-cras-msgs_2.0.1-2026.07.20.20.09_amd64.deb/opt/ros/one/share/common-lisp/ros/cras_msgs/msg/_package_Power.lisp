(cl:in-package cras_msgs-msg)
(cl:export '(POWER-VAL
          POWER
))