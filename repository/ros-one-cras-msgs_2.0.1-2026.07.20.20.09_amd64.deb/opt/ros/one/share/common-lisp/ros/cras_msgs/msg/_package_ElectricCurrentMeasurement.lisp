(cl:in-package cras_msgs-msg)
(cl:export '(DATA-VAL
          DATA
          VARIANCE-VAL
          VARIANCE
          SAMPLE_DURATION-VAL
          SAMPLE_DURATION
))