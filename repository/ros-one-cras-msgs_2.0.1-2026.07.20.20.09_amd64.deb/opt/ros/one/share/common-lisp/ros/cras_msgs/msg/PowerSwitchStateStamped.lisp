; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude PowerSwitchStateStamped.msg.html

(cl:defclass <PowerSwitchStateStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (state
    :reader state
    :initarg :state
    :type cras_msgs-msg:PowerSwitchState
    :initform (cl:make-instance 'cras_msgs-msg:PowerSwitchState)))
)

(cl:defclass PowerSwitchStateStamped (<PowerSwitchStateStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PowerSwitchStateStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PowerSwitchStateStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<PowerSwitchStateStamped> is deprecated: use cras_msgs-msg:PowerSwitchStateStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <PowerSwitchStateStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:header-val is deprecated.  Use cras_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'state-val :lambda-list '(m))
(cl:defmethod state-val ((m <PowerSwitchStateStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:state-val is deprecated.  Use cras_msgs-msg:state instead.")
  (state m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PowerSwitchStateStamped>) ostream)
  "Serializes a message object of type '<PowerSwitchStateStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'state) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PowerSwitchStateStamped>) istream)
  "Deserializes a message object of type '<PowerSwitchStateStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'state) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PowerSwitchStateStamped>)))
  "Returns string type for a message object of type '<PowerSwitchStateStamped>"
  "cras_msgs/PowerSwitchStateStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PowerSwitchStateStamped)))
  "Returns string type for a message object of type 'PowerSwitchStateStamped"
  "cras_msgs/PowerSwitchStateStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PowerSwitchStateStamped>)))
  "Returns md5sum for a message object of type '<PowerSwitchStateStamped>"
  "288534a6596dc59cac36ed7b6ded41de")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PowerSwitchStateStamped)))
  "Returns md5sum for a message object of type 'PowerSwitchStateStamped"
  "288534a6596dc59cac36ed7b6ded41de")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PowerSwitchStateStamped>)))
  "Returns full string definition for message of type '<PowerSwitchStateStamped>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# State of a power switch (a relay, a transistor, FET...).~%~%std_msgs/Header header  # stamp is the time the power switch state was measured.~%                        # frame_id is the location of the power switch (does not need to be TF frame).~%PowerSwitchState state  # State of the power switch light.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/PowerSwitchState~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# State of a power switch (a relay, a transistor, FET...).~% ~%bool on  # If true, the power switch is on, i.e. the electric path is connected.~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PowerSwitchStateStamped)))
  "Returns full string definition for message of type 'PowerSwitchStateStamped"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# State of a power switch (a relay, a transistor, FET...).~%~%std_msgs/Header header  # stamp is the time the power switch state was measured.~%                        # frame_id is the location of the power switch (does not need to be TF frame).~%PowerSwitchState state  # State of the power switch light.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/PowerSwitchState~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# State of a power switch (a relay, a transistor, FET...).~% ~%bool on  # If true, the power switch is on, i.e. the electric path is connected.~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PowerSwitchStateStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'state))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PowerSwitchStateStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'PowerSwitchStateStamped
    (cl:cons ':header (header msg))
    (cl:cons ':state (state msg))
))
