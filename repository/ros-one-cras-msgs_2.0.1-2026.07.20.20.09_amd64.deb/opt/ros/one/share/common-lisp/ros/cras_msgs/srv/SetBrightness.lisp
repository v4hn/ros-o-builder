; Auto-generated. Do not edit!


(cl:in-package cras_msgs-srv)


;//! \htmlinclude SetBrightness-request.msg.html

(cl:defclass <SetBrightness-request> (roslisp-msg-protocol:ros-message)
  ((value
    :reader value
    :initarg :value
    :type cras_msgs-msg:Brightness
    :initform (cl:make-instance 'cras_msgs-msg:Brightness)))
)

(cl:defclass SetBrightness-request (<SetBrightness-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetBrightness-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetBrightness-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-srv:<SetBrightness-request> is deprecated: use cras_msgs-srv:SetBrightness-request instead.")))

(cl:ensure-generic-function 'value-val :lambda-list '(m))
(cl:defmethod value-val ((m <SetBrightness-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-srv:value-val is deprecated.  Use cras_msgs-srv:value instead.")
  (value m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetBrightness-request>) ostream)
  "Serializes a message object of type '<SetBrightness-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'value) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetBrightness-request>) istream)
  "Deserializes a message object of type '<SetBrightness-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'value) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetBrightness-request>)))
  "Returns string type for a service object of type '<SetBrightness-request>"
  "cras_msgs/SetBrightnessRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetBrightness-request)))
  "Returns string type for a service object of type 'SetBrightness-request"
  "cras_msgs/SetBrightnessRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetBrightness-request>)))
  "Returns md5sum for a message object of type '<SetBrightness-request>"
  "2e29c05fe08ad1a62cdddbfafe2a17d9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetBrightness-request)))
  "Returns md5sum for a message object of type 'SetBrightness-request"
  "2e29c05fe08ad1a62cdddbfafe2a17d9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetBrightness-request>)))
  "Returns full string definition for message of type '<SetBrightness-request>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Set the brightness of e.g. a dimmable light.~%~%Brightness value  # The requested brightness.~%~%================================================================================~%MSG: cras_msgs/Brightness~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~% ~%float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetBrightness-request)))
  "Returns full string definition for message of type 'SetBrightness-request"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Set the brightness of e.g. a dimmable light.~%~%Brightness value  # The requested brightness.~%~%================================================================================~%MSG: cras_msgs/Brightness~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Brightness of e.g. a dimmable light (LED, OLED, ...).~% ~%float64 brightness  # Ratio of the brightness to the maximum brightness (0.0 - 1.0).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetBrightness-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'value))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetBrightness-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetBrightness-request
    (cl:cons ':value (value msg))
))
;//! \htmlinclude SetBrightness-response.msg.html

(cl:defclass <SetBrightness-response> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass SetBrightness-response (<SetBrightness-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetBrightness-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetBrightness-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-srv:<SetBrightness-response> is deprecated: use cras_msgs-srv:SetBrightness-response instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetBrightness-response>) ostream)
  "Serializes a message object of type '<SetBrightness-response>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetBrightness-response>) istream)
  "Deserializes a message object of type '<SetBrightness-response>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetBrightness-response>)))
  "Returns string type for a service object of type '<SetBrightness-response>"
  "cras_msgs/SetBrightnessResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetBrightness-response)))
  "Returns string type for a service object of type 'SetBrightness-response"
  "cras_msgs/SetBrightnessResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetBrightness-response>)))
  "Returns md5sum for a message object of type '<SetBrightness-response>"
  "2e29c05fe08ad1a62cdddbfafe2a17d9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetBrightness-response)))
  "Returns md5sum for a message object of type 'SetBrightness-response"
  "2e29c05fe08ad1a62cdddbfafe2a17d9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetBrightness-response>)))
  "Returns full string definition for message of type '<SetBrightness-response>"
  (cl:format cl:nil "# If a failure occurs, the service server should throw an exception.~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetBrightness-response)))
  "Returns full string definition for message of type 'SetBrightness-response"
  (cl:format cl:nil "# If a failure occurs, the service server should throw an exception.~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetBrightness-response>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetBrightness-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetBrightness-response
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetBrightness)))
  'SetBrightness-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetBrightness)))
  'SetBrightness-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetBrightness)))
  "Returns string type for a service object of type '<SetBrightness>"
  "cras_msgs/SetBrightness")