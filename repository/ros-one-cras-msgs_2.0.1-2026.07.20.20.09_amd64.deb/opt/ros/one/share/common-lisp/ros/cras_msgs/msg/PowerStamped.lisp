; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude PowerStamped.msg.html

(cl:defclass <PowerStamped> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (measurement
    :reader measurement
    :initarg :measurement
    :type cras_msgs-msg:PowerMeasurement
    :initform (cl:make-instance 'cras_msgs-msg:PowerMeasurement)))
)

(cl:defclass PowerStamped (<PowerStamped>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PowerStamped>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PowerStamped)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<PowerStamped> is deprecated: use cras_msgs-msg:PowerStamped instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <PowerStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:header-val is deprecated.  Use cras_msgs-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'measurement-val :lambda-list '(m))
(cl:defmethod measurement-val ((m <PowerStamped>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:measurement-val is deprecated.  Use cras_msgs-msg:measurement instead.")
  (measurement m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PowerStamped>) ostream)
  "Serializes a message object of type '<PowerStamped>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'measurement) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PowerStamped>) istream)
  "Deserializes a message object of type '<PowerStamped>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'measurement) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PowerStamped>)))
  "Returns string type for a message object of type '<PowerStamped>"
  "cras_msgs/PowerStamped")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PowerStamped)))
  "Returns string type for a message object of type 'PowerStamped"
  "cras_msgs/PowerStamped")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PowerStamped>)))
  "Returns md5sum for a message object of type '<PowerStamped>"
  "69b489648cafe5476da94b5597101535")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PowerStamped)))
  "Returns md5sum for a message object of type 'PowerStamped"
  "69b489648cafe5476da94b5597101535")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PowerStamped>)))
  "Returns full string definition for message of type '<PowerStamped>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single power measurement.~%~%std_msgs/Header header  # stamp is the time the power was measured.~%                        # frame_id is the location of the power measurement (does not need to be a TF frame).~%PowerMeasurement measurement  # The measured power.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/PowerMeasurement~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single power measurement.~% ~%Power data  # Power value.~%float64 variance  # Variance of the measurement (in Watt^2). If not known or relevant, use 0.~%duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.~%~%================================================================================~%MSG: cras_msgs/Power~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Mechanical or electrical power value.~% ~%float64 power  # Power value (in Watts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PowerStamped)))
  "Returns full string definition for message of type 'PowerStamped"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single power measurement.~%~%std_msgs/Header header  # stamp is the time the power was measured.~%                        # frame_id is the location of the power measurement (does not need to be a TF frame).~%PowerMeasurement measurement  # The measured power.~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: cras_msgs/PowerMeasurement~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single power measurement.~% ~%Power data  # Power value.~%float64 variance  # Variance of the measurement (in Watt^2). If not known or relevant, use 0.~%duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.~%~%================================================================================~%MSG: cras_msgs/Power~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Mechanical or electrical power value.~% ~%float64 power  # Power value (in Watts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PowerStamped>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'measurement))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PowerStamped>))
  "Converts a ROS message object to a list"
  (cl:list 'PowerStamped
    (cl:cons ':header (header msg))
    (cl:cons ':measurement (measurement msg))
))
