; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude VoltageMeasurement.msg.html

(cl:defclass <VoltageMeasurement> (roslisp-msg-protocol:ros-message)
  ((data
    :reader data
    :initarg :data
    :type cras_msgs-msg:Voltage
    :initform (cl:make-instance 'cras_msgs-msg:Voltage))
   (variance
    :reader variance
    :initarg :variance
    :type cl:float
    :initform 0.0)
   (sample_duration
    :reader sample_duration
    :initarg :sample_duration
    :type cl:real
    :initform 0))
)

(cl:defclass VoltageMeasurement (<VoltageMeasurement>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <VoltageMeasurement>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'VoltageMeasurement)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<VoltageMeasurement> is deprecated: use cras_msgs-msg:VoltageMeasurement instead.")))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <VoltageMeasurement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:data-val is deprecated.  Use cras_msgs-msg:data instead.")
  (data m))

(cl:ensure-generic-function 'variance-val :lambda-list '(m))
(cl:defmethod variance-val ((m <VoltageMeasurement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:variance-val is deprecated.  Use cras_msgs-msg:variance instead.")
  (variance m))

(cl:ensure-generic-function 'sample_duration-val :lambda-list '(m))
(cl:defmethod sample_duration-val ((m <VoltageMeasurement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:sample_duration-val is deprecated.  Use cras_msgs-msg:sample_duration instead.")
  (sample_duration m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <VoltageMeasurement>) ostream)
  "Serializes a message object of type '<VoltageMeasurement>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'data) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'variance))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'sample_duration)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'sample_duration) (cl:floor (cl:slot-value msg 'sample_duration)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <VoltageMeasurement>) istream)
  "Deserializes a message object of type '<VoltageMeasurement>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'data) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'variance) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'sample_duration) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<VoltageMeasurement>)))
  "Returns string type for a message object of type '<VoltageMeasurement>"
  "cras_msgs/VoltageMeasurement")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'VoltageMeasurement)))
  "Returns string type for a message object of type 'VoltageMeasurement"
  "cras_msgs/VoltageMeasurement")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<VoltageMeasurement>)))
  "Returns md5sum for a message object of type '<VoltageMeasurement>"
  "1faf27aef6dead9c2ca7907095470c28")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'VoltageMeasurement)))
  "Returns md5sum for a message object of type 'VoltageMeasurement"
  "1faf27aef6dead9c2ca7907095470c28")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<VoltageMeasurement>)))
  "Returns full string definition for message of type '<VoltageMeasurement>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage measurement.~% ~%Voltage data  # Voltage value.~%float64 variance  # Variance of the measurement (in Volt^2). If not known or relevant, use 0.~%duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.~%~%================================================================================~%MSG: cras_msgs/Voltage~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage value.~% ~%float64 voltage  # Voltage value (in Volts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'VoltageMeasurement)))
  "Returns full string definition for message of type 'VoltageMeasurement"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage measurement.~% ~%Voltage data  # Voltage value.~%float64 variance  # Variance of the measurement (in Volt^2). If not known or relevant, use 0.~%duration sample_duration  # Duration of the measurement. If not known or relevant, use 0.~%~%================================================================================~%MSG: cras_msgs/Voltage~%# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# Single voltage value.~% ~%float64 voltage  # Voltage value (in Volts).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <VoltageMeasurement>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'data))
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <VoltageMeasurement>))
  "Converts a ROS message object to a list"
  (cl:list 'VoltageMeasurement
    (cl:cons ':data (data msg))
    (cl:cons ':variance (variance msg))
    (cl:cons ':sample_duration (sample_duration msg))
))
