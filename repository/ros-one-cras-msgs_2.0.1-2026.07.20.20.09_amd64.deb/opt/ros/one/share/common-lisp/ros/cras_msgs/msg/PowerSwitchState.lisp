; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude PowerSwitchState.msg.html

(cl:defclass <PowerSwitchState> (roslisp-msg-protocol:ros-message)
  ((on
    :reader on
    :initarg :on
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass PowerSwitchState (<PowerSwitchState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PowerSwitchState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PowerSwitchState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<PowerSwitchState> is deprecated: use cras_msgs-msg:PowerSwitchState instead.")))

(cl:ensure-generic-function 'on-val :lambda-list '(m))
(cl:defmethod on-val ((m <PowerSwitchState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:on-val is deprecated.  Use cras_msgs-msg:on instead.")
  (on m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PowerSwitchState>) ostream)
  "Serializes a message object of type '<PowerSwitchState>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'on) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PowerSwitchState>) istream)
  "Deserializes a message object of type '<PowerSwitchState>"
    (cl:setf (cl:slot-value msg 'on) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PowerSwitchState>)))
  "Returns string type for a message object of type '<PowerSwitchState>"
  "cras_msgs/PowerSwitchState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PowerSwitchState)))
  "Returns string type for a message object of type 'PowerSwitchState"
  "cras_msgs/PowerSwitchState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PowerSwitchState>)))
  "Returns md5sum for a message object of type '<PowerSwitchState>"
  "74983d2ffe4877de8ae30b7a94625c41")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PowerSwitchState)))
  "Returns md5sum for a message object of type 'PowerSwitchState"
  "74983d2ffe4877de8ae30b7a94625c41")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PowerSwitchState>)))
  "Returns full string definition for message of type '<PowerSwitchState>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# State of a power switch (a relay, a transistor, FET...).~% ~%bool on  # If true, the power switch is on, i.e. the electric path is connected.~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PowerSwitchState)))
  "Returns full string definition for message of type 'PowerSwitchState"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~%~%# State of a power switch (a relay, a transistor, FET...).~% ~%bool on  # If true, the power switch is on, i.e. the electric path is connected.~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PowerSwitchState>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PowerSwitchState>))
  "Converts a ROS message object to a list"
  (cl:list 'PowerSwitchState
    (cl:cons ':on (on msg))
))
