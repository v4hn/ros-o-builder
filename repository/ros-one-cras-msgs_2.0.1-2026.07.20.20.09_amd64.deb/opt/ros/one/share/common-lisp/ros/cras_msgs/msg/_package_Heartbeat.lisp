(cl:in-package cras_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
))