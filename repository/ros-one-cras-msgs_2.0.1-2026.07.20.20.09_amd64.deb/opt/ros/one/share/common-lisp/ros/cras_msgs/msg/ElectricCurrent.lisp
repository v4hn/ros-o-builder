; Auto-generated. Do not edit!


(cl:in-package cras_msgs-msg)


;//! \htmlinclude ElectricCurrent.msg.html

(cl:defclass <ElectricCurrent> (roslisp-msg-protocol:ros-message)
  ((current
    :reader current
    :initarg :current
    :type cl:float
    :initform 0.0))
)

(cl:defclass ElectricCurrent (<ElectricCurrent>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ElectricCurrent>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ElectricCurrent)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name cras_msgs-msg:<ElectricCurrent> is deprecated: use cras_msgs-msg:ElectricCurrent instead.")))

(cl:ensure-generic-function 'current-val :lambda-list '(m))
(cl:defmethod current-val ((m <ElectricCurrent>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader cras_msgs-msg:current-val is deprecated.  Use cras_msgs-msg:current instead.")
  (current m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ElectricCurrent>) ostream)
  "Serializes a message object of type '<ElectricCurrent>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'current))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ElectricCurrent>) istream)
  "Deserializes a message object of type '<ElectricCurrent>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'current) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ElectricCurrent>)))
  "Returns string type for a message object of type '<ElectricCurrent>"
  "cras_msgs/ElectricCurrent")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ElectricCurrent)))
  "Returns string type for a message object of type 'ElectricCurrent"
  "cras_msgs/ElectricCurrent")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ElectricCurrent>)))
  "Returns md5sum for a message object of type '<ElectricCurrent>"
  "ca4d0ba43a70fe6e37b76accdbf3ef40")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ElectricCurrent)))
  "Returns md5sum for a message object of type 'ElectricCurrent"
  "ca4d0ba43a70fe6e37b76accdbf3ef40")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ElectricCurrent>)))
  "Returns full string definition for message of type '<ElectricCurrent>"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~% ~%# Single electric current value.~% ~%float64 current  # Current value (in Amperes).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ElectricCurrent)))
  "Returns full string definition for message of type 'ElectricCurrent"
  (cl:format cl:nil "# SPDX-License-Identifier: BSD-3-Clause~%# SPDX-FileCopyrightText: Czech Technical University in Prague~% ~%# Single electric current value.~% ~%float64 current  # Current value (in Amperes).~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ElectricCurrent>))
  (cl:+ 0
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ElectricCurrent>))
  "Converts a ROS message object to a list"
  (cl:list 'ElectricCurrent
    (cl:cons ':current (current msg))
))
