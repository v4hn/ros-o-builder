(cl:in-package cras_msgs-msg)
(cl:export '(VOLTAGE-VAL
          VOLTAGE
))