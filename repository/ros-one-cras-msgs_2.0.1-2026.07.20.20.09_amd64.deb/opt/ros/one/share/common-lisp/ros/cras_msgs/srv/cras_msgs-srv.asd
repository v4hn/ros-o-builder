
(cl:in-package :asdf)

(defsystem "cras_msgs-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :cras_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "SetBrightness" :depends-on ("_package_SetBrightness"))
    (:file "_package_SetBrightness" :depends-on ("_package"))
    (:file "SetColor" :depends-on ("_package_SetColor"))
    (:file "_package_SetColor" :depends-on ("_package"))
  ))