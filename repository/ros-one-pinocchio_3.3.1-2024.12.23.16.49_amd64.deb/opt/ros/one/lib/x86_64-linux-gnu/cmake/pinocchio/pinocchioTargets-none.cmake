#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "pinocchio::pinocchio_default" for configuration "None"
set_property(TARGET pinocchio::pinocchio_default APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(pinocchio::pinocchio_default PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpinocchio_default.so.3.3.1"
  IMPORTED_SONAME_NONE "libpinocchio_default.so.3.3.1"
  )

list(APPEND _cmake_import_check_targets pinocchio::pinocchio_default )
list(APPEND _cmake_import_check_files_for_pinocchio::pinocchio_default "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpinocchio_default.so.3.3.1" )

# Import target "pinocchio::pinocchio_parsers" for configuration "None"
set_property(TARGET pinocchio::pinocchio_parsers APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(pinocchio::pinocchio_parsers PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpinocchio_parsers.so.3.3.1"
  IMPORTED_SONAME_NONE "libpinocchio_parsers.so.3.3.1"
  )

list(APPEND _cmake_import_check_targets pinocchio::pinocchio_parsers )
list(APPEND _cmake_import_check_files_for_pinocchio::pinocchio_parsers "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpinocchio_parsers.so.3.3.1" )

# Import target "pinocchio::pinocchio_python_parser" for configuration "None"
set_property(TARGET pinocchio::pinocchio_python_parser APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(pinocchio::pinocchio_python_parser PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpinocchio_python_parser.so.3.3.1"
  IMPORTED_SONAME_NONE "libpinocchio_python_parser.so.3.3.1"
  )

list(APPEND _cmake_import_check_targets pinocchio::pinocchio_python_parser )
list(APPEND _cmake_import_check_files_for_pinocchio::pinocchio_python_parser "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/libpinocchio_python_parser.so.3.3.1" )

# Import target "pinocchio::pinocchio_pywrap_default" for configuration "None"
set_property(TARGET pinocchio::pinocchio_pywrap_default APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(pinocchio::pinocchio_pywrap_default PROPERTIES
  IMPORTED_LOCATION_NONE "/opt/ros/one/lib/python3/dist-packages/pinocchio/pinocchio_pywrap_default.cpython-312-x86_64-linux-gnu.so.3.3.1"
  IMPORTED_SONAME_NONE "pinocchio_pywrap_default.cpython-312-x86_64-linux-gnu.so.3.3.1"
  )

list(APPEND _cmake_import_check_targets pinocchio::pinocchio_pywrap_default )
list(APPEND _cmake_import_check_files_for_pinocchio::pinocchio_pywrap_default "/opt/ros/one/lib/python3/dist-packages/pinocchio/pinocchio_pywrap_default.cpython-312-x86_64-linux-gnu.so.3.3.1" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
