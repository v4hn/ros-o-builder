
"use strict";

let MongoUpdateMsg = require('./MongoUpdateMsg.js')
let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')
let MongoDeleteMsg = require('./MongoDeleteMsg.js')
let MongoInsertMsg = require('./MongoInsertMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')

module.exports = {
  MongoUpdateMsg: MongoUpdateMsg,
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
  MongoDeleteMsg: MongoDeleteMsg,
  MongoInsertMsg: MongoInsertMsg,
  MongoQueryMsg: MongoQueryMsg,
};
