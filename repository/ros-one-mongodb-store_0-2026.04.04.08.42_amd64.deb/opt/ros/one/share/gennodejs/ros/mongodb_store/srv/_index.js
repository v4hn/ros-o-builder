
"use strict";

let MongoUpdate = require('./MongoUpdate.js')
let MongoFind = require('./MongoFind.js')
let SetParam = require('./SetParam.js')
let MongoInsert = require('./MongoInsert.js')
let GetParam = require('./GetParam.js')

module.exports = {
  MongoUpdate: MongoUpdate,
  MongoFind: MongoFind,
  SetParam: SetParam,
  MongoInsert: MongoInsert,
  GetParam: GetParam,
};
