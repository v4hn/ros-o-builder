
"use strict";

let ConfigFeedback = require('./ConfigFeedback.js');
let ConfigActionResult = require('./ConfigActionResult.js');
let ConfigActionFeedback = require('./ConfigActionFeedback.js');
let ConfigAction = require('./ConfigAction.js');
let ConfigActionGoal = require('./ConfigActionGoal.js');
let ConfigResult = require('./ConfigResult.js');
let ConfigGoal = require('./ConfigGoal.js');
let ImagePoint = require('./ImagePoint.js');
let ObjectInImage = require('./ObjectInImage.js');

module.exports = {
  ConfigFeedback: ConfigFeedback,
  ConfigActionResult: ConfigActionResult,
  ConfigActionFeedback: ConfigActionFeedback,
  ConfigAction: ConfigAction,
  ConfigActionGoal: ConfigActionGoal,
  ConfigResult: ConfigResult,
  ConfigGoal: ConfigGoal,
  ImagePoint: ImagePoint,
  ObjectInImage: ObjectInImage,
};
