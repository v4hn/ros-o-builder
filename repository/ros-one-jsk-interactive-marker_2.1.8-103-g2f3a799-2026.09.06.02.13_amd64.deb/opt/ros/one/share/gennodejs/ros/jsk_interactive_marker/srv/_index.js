
"use strict";

let IndexRequest = require('./IndexRequest.js')
let GetType = require('./GetType.js')
let SetMarkerDimensions = require('./SetMarkerDimensions.js')
let GetTransformableMarkerColor = require('./GetTransformableMarkerColor.js')
let SetTransformableMarkerColor = require('./SetTransformableMarkerColor.js')
let SnapFootPrint = require('./SnapFootPrint.js')
let SetTransformableMarkerPose = require('./SetTransformableMarkerPose.js')
let SetHeuristic = require('./SetHeuristic.js')
let GetMarkerDimensions = require('./GetMarkerDimensions.js')
let GetTransformableMarkerExistence = require('./GetTransformableMarkerExistence.js')
let RemoveParentMarker = require('./RemoveParentMarker.js')
let SetTransformableMarkerFocus = require('./SetTransformableMarkerFocus.js')
let GetJointState = require('./GetJointState.js')
let SetPose = require('./SetPose.js')
let GetTransformableMarkerPose = require('./GetTransformableMarkerPose.js')
let GetTransformableMarkerFocus = require('./GetTransformableMarkerFocus.js')
let SetParentMarker = require('./SetParentMarker.js')
let MarkerSetPose = require('./MarkerSetPose.js')

module.exports = {
  IndexRequest: IndexRequest,
  GetType: GetType,
  SetMarkerDimensions: SetMarkerDimensions,
  GetTransformableMarkerColor: GetTransformableMarkerColor,
  SetTransformableMarkerColor: SetTransformableMarkerColor,
  SnapFootPrint: SnapFootPrint,
  SetTransformableMarkerPose: SetTransformableMarkerPose,
  SetHeuristic: SetHeuristic,
  GetMarkerDimensions: GetMarkerDimensions,
  GetTransformableMarkerExistence: GetTransformableMarkerExistence,
  RemoveParentMarker: RemoveParentMarker,
  SetTransformableMarkerFocus: SetTransformableMarkerFocus,
  GetJointState: GetJointState,
  SetPose: SetPose,
  GetTransformableMarkerPose: GetTransformableMarkerPose,
  GetTransformableMarkerFocus: GetTransformableMarkerFocus,
  SetParentMarker: SetParentMarker,
  MarkerSetPose: MarkerSetPose,
};
