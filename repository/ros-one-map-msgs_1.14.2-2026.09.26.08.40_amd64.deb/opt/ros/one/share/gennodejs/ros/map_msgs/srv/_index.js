
"use strict";

let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let SaveMap = require('./SaveMap.js')
let SetMapProjections = require('./SetMapProjections.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let GetMapROI = require('./GetMapROI.js')
let GetPointMap = require('./GetPointMap.js')

module.exports = {
  ProjectedMapsInfo: ProjectedMapsInfo,
  SaveMap: SaveMap,
  SetMapProjections: SetMapProjections,
  GetPointMapROI: GetPointMapROI,
  GetMapROI: GetMapROI,
  GetPointMap: GetPointMap,
};
