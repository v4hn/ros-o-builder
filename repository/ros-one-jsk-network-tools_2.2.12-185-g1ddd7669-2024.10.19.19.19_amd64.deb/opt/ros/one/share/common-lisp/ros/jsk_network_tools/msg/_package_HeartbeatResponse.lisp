(cl:in-package jsk_network_tools-msg)
(cl:export '(HEADER-VAL
          HEADER
          HEARTBEAT-VAL
          HEARTBEAT
))