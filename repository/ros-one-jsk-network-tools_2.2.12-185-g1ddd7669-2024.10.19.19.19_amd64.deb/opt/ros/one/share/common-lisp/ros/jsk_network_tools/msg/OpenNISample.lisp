; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude OpenNISample.msg.html

(cl:defclass <OpenNISample> (roslisp-msg-protocol:ros-message)
  ((camera__rgb__image_rect_color
    :reader camera__rgb__image_rect_color
    :initarg :camera__rgb__image_rect_color
    :type sensor_msgs-msg:Image
    :initform (cl:make-instance 'sensor_msgs-msg:Image))
   (camera__depth_registered__points
    :reader camera__depth_registered__points
    :initarg :camera__depth_registered__points
    :type sensor_msgs-msg:PointCloud2
    :initform (cl:make-instance 'sensor_msgs-msg:PointCloud2)))
)

(cl:defclass OpenNISample (<OpenNISample>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <OpenNISample>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'OpenNISample)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<OpenNISample> is deprecated: use jsk_network_tools-msg:OpenNISample instead.")))

(cl:ensure-generic-function 'camera__rgb__image_rect_color-val :lambda-list '(m))
(cl:defmethod camera__rgb__image_rect_color-val ((m <OpenNISample>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:camera__rgb__image_rect_color-val is deprecated.  Use jsk_network_tools-msg:camera__rgb__image_rect_color instead.")
  (camera__rgb__image_rect_color m))

(cl:ensure-generic-function 'camera__depth_registered__points-val :lambda-list '(m))
(cl:defmethod camera__depth_registered__points-val ((m <OpenNISample>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:camera__depth_registered__points-val is deprecated.  Use jsk_network_tools-msg:camera__depth_registered__points instead.")
  (camera__depth_registered__points m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <OpenNISample>) ostream)
  "Serializes a message object of type '<OpenNISample>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'camera__rgb__image_rect_color) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'camera__depth_registered__points) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <OpenNISample>) istream)
  "Deserializes a message object of type '<OpenNISample>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'camera__rgb__image_rect_color) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'camera__depth_registered__points) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<OpenNISample>)))
  "Returns string type for a message object of type '<OpenNISample>"
  "jsk_network_tools/OpenNISample")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'OpenNISample)))
  "Returns string type for a message object of type 'OpenNISample"
  "jsk_network_tools/OpenNISample")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<OpenNISample>)))
  "Returns md5sum for a message object of type '<OpenNISample>"
  "c998c0df481d0ad4598a2534cadda5d1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'OpenNISample)))
  "Returns md5sum for a message object of type 'OpenNISample"
  "c998c0df481d0ad4598a2534cadda5d1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<OpenNISample>)))
  "Returns full string definition for message of type '<OpenNISample>"
  (cl:format cl:nil "sensor_msgs/Image camera__rgb__image_rect_color~%sensor_msgs/PointCloud2 camera__depth_registered__points~%~%================================================================================~%MSG: sensor_msgs/Image~%# This message contains an uncompressed image~%# (0, 0) is at top-left corner of image~%#~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%                     # If the frame_id here and the frame_id of the CameraInfo~%                     # message associated with the image conflict~%                     # the behavior is undefined~%~%uint32 height         # image height, that is, number of rows~%uint32 width          # image width, that is, number of columns~%~%# The legal values for encoding are in file src/image_encodings.cpp~%# If you want to standardize a new string format, join~%# ros-users@lists.sourceforge.net and send an email proposing a new encoding.~%~%string encoding       # Encoding of pixels -- channel meaning, ordering, size~%                      # taken from the list of strings in include/sensor_msgs/image_encodings.h~%~%uint8 is_bigendian    # is this data bigendian?~%uint32 step           # Full row length in bytes~%uint8[] data          # actual matrix data, size is (step * rows)~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: sensor_msgs/PointCloud2~%# This message holds a collection of N-dimensional points, which may~%# contain additional information such as normals, intensity, etc. The~%# point data is stored as a binary blob, its layout described by the~%# contents of the \"fields\" array.~%~%# The point cloud data may be organized 2d (image-like) or 1d~%# (unordered). Point clouds organized as 2d images may be produced by~%# camera depth sensors such as stereo or time-of-flight.~%~%# Time of sensor data acquisition, and the coordinate frame ID (for 3d~%# points).~%Header header~%~%# 2D structure of the point cloud. If the cloud is unordered, height is~%# 1 and width is the length of the point cloud.~%uint32 height~%uint32 width~%~%# Describes the channels and their layout in the binary data blob.~%PointField[] fields~%~%bool    is_bigendian # Is this data bigendian?~%uint32  point_step   # Length of a point in bytes~%uint32  row_step     # Length of a row in bytes~%uint8[] data         # Actual point data, size is (row_step*height)~%~%bool is_dense        # True if there are no invalid points~%~%================================================================================~%MSG: sensor_msgs/PointField~%# This message holds the description of one point entry in the~%# PointCloud2 message format.~%uint8 INT8    = 1~%uint8 UINT8   = 2~%uint8 INT16   = 3~%uint8 UINT16  = 4~%uint8 INT32   = 5~%uint8 UINT32  = 6~%uint8 FLOAT32 = 7~%uint8 FLOAT64 = 8~%~%string name      # Name of field~%uint32 offset    # Offset from start of point struct~%uint8  datatype  # Datatype enumeration, see above~%uint32 count     # How many elements in the field~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'OpenNISample)))
  "Returns full string definition for message of type 'OpenNISample"
  (cl:format cl:nil "sensor_msgs/Image camera__rgb__image_rect_color~%sensor_msgs/PointCloud2 camera__depth_registered__points~%~%================================================================================~%MSG: sensor_msgs/Image~%# This message contains an uncompressed image~%# (0, 0) is at top-left corner of image~%#~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%                     # If the frame_id here and the frame_id of the CameraInfo~%                     # message associated with the image conflict~%                     # the behavior is undefined~%~%uint32 height         # image height, that is, number of rows~%uint32 width          # image width, that is, number of columns~%~%# The legal values for encoding are in file src/image_encodings.cpp~%# If you want to standardize a new string format, join~%# ros-users@lists.sourceforge.net and send an email proposing a new encoding.~%~%string encoding       # Encoding of pixels -- channel meaning, ordering, size~%                      # taken from the list of strings in include/sensor_msgs/image_encodings.h~%~%uint8 is_bigendian    # is this data bigendian?~%uint32 step           # Full row length in bytes~%uint8[] data          # actual matrix data, size is (step * rows)~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: sensor_msgs/PointCloud2~%# This message holds a collection of N-dimensional points, which may~%# contain additional information such as normals, intensity, etc. The~%# point data is stored as a binary blob, its layout described by the~%# contents of the \"fields\" array.~%~%# The point cloud data may be organized 2d (image-like) or 1d~%# (unordered). Point clouds organized as 2d images may be produced by~%# camera depth sensors such as stereo or time-of-flight.~%~%# Time of sensor data acquisition, and the coordinate frame ID (for 3d~%# points).~%Header header~%~%# 2D structure of the point cloud. If the cloud is unordered, height is~%# 1 and width is the length of the point cloud.~%uint32 height~%uint32 width~%~%# Describes the channels and their layout in the binary data blob.~%PointField[] fields~%~%bool    is_bigendian # Is this data bigendian?~%uint32  point_step   # Length of a point in bytes~%uint32  row_step     # Length of a row in bytes~%uint8[] data         # Actual point data, size is (row_step*height)~%~%bool is_dense        # True if there are no invalid points~%~%================================================================================~%MSG: sensor_msgs/PointField~%# This message holds the description of one point entry in the~%# PointCloud2 message format.~%uint8 INT8    = 1~%uint8 UINT8   = 2~%uint8 INT16   = 3~%uint8 UINT16  = 4~%uint8 INT32   = 5~%uint8 UINT32  = 6~%uint8 FLOAT32 = 7~%uint8 FLOAT64 = 8~%~%string name      # Name of field~%uint32 offset    # Offset from start of point struct~%uint8  datatype  # Datatype enumeration, see above~%uint32 count     # How many elements in the field~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <OpenNISample>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'camera__rgb__image_rect_color))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'camera__depth_registered__points))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <OpenNISample>))
  "Converts a ROS message object to a list"
  (cl:list 'OpenNISample
    (cl:cons ':camera__rgb__image_rect_color (camera__rgb__image_rect_color msg))
    (cl:cons ':camera__depth_registered__points (camera__depth_registered__points msg))
))
