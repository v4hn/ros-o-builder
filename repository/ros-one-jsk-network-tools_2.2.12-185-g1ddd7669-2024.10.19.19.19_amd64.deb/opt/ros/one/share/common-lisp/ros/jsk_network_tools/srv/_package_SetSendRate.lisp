(cl:in-package jsk_network_tools-srv)
(cl:export '(RATE-VAL
          RATE
          OK-VAL
          OK
))