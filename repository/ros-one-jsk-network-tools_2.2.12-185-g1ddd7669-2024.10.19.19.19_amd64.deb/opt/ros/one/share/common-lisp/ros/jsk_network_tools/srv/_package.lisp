(cl:defpackage jsk_network_tools-srv
  (:use )
  (:export
   "SETSENDRATE"
   "<SETSENDRATE-REQUEST>"
   "SETSENDRATE-REQUEST"
   "<SETSENDRATE-RESPONSE>"
   "SETSENDRATE-RESPONSE"
  ))

