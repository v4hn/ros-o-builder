; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude AllTypeTest.msg.html

(cl:defclass <AllTypeTest> (roslisp-msg-protocol:ros-message)
  ((bool_atom
    :reader bool_atom
    :initarg :bool_atom
    :type cl:boolean
    :initform cl:nil)
   (bool_array
    :reader bool_array
    :initarg :bool_array
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 4 :element-type 'cl:boolean :initial-element cl:nil))
   (uint8_atom
    :reader uint8_atom
    :initarg :uint8_atom
    :type cl:fixnum
    :initform 0)
   (uint8_array
    :reader uint8_array
    :initarg :uint8_array
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 4 :element-type 'cl:fixnum :initial-element 0))
   (int8_atom
    :reader int8_atom
    :initarg :int8_atom
    :type cl:fixnum
    :initform 0)
   (int8_array
    :reader int8_array
    :initarg :int8_array
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 4 :element-type 'cl:fixnum :initial-element 0))
   (uint16_atom
    :reader uint16_atom
    :initarg :uint16_atom
    :type cl:fixnum
    :initform 0)
   (uint16_array
    :reader uint16_array
    :initarg :uint16_array
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 4 :element-type 'cl:fixnum :initial-element 0))
   (int32_atom
    :reader int32_atom
    :initarg :int32_atom
    :type cl:integer
    :initform 0)
   (int32_array
    :reader int32_array
    :initarg :int32_array
    :type (cl:vector cl:integer)
   :initform (cl:make-array 4 :element-type 'cl:integer :initial-element 0))
   (uint32_atom
    :reader uint32_atom
    :initarg :uint32_atom
    :type cl:integer
    :initform 0)
   (uint32_array
    :reader uint32_array
    :initarg :uint32_array
    :type (cl:vector cl:integer)
   :initform (cl:make-array 4 :element-type 'cl:integer :initial-element 0))
   (int64_atom
    :reader int64_atom
    :initarg :int64_atom
    :type cl:integer
    :initform 0)
   (int64_array
    :reader int64_array
    :initarg :int64_array
    :type (cl:vector cl:integer)
   :initform (cl:make-array 4 :element-type 'cl:integer :initial-element 0))
   (uint64_atom
    :reader uint64_atom
    :initarg :uint64_atom
    :type cl:integer
    :initform 0)
   (uint64_array
    :reader uint64_array
    :initarg :uint64_array
    :type (cl:vector cl:integer)
   :initform (cl:make-array 4 :element-type 'cl:integer :initial-element 0))
   (float32_atom
    :reader float32_atom
    :initarg :float32_atom
    :type cl:float
    :initform 0.0)
   (float32_array
    :reader float32_array
    :initarg :float32_array
    :type (cl:vector cl:float)
   :initform (cl:make-array 4 :element-type 'cl:float :initial-element 0.0))
   (float64_atom
    :reader float64_atom
    :initarg :float64_atom
    :type cl:float
    :initform 0.0)
   (float64_array
    :reader float64_array
    :initarg :float64_array
    :type (cl:vector cl:float)
   :initform (cl:make-array 4 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass AllTypeTest (<AllTypeTest>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AllTypeTest>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AllTypeTest)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<AllTypeTest> is deprecated: use jsk_network_tools-msg:AllTypeTest instead.")))

(cl:ensure-generic-function 'bool_atom-val :lambda-list '(m))
(cl:defmethod bool_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:bool_atom-val is deprecated.  Use jsk_network_tools-msg:bool_atom instead.")
  (bool_atom m))

(cl:ensure-generic-function 'bool_array-val :lambda-list '(m))
(cl:defmethod bool_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:bool_array-val is deprecated.  Use jsk_network_tools-msg:bool_array instead.")
  (bool_array m))

(cl:ensure-generic-function 'uint8_atom-val :lambda-list '(m))
(cl:defmethod uint8_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint8_atom-val is deprecated.  Use jsk_network_tools-msg:uint8_atom instead.")
  (uint8_atom m))

(cl:ensure-generic-function 'uint8_array-val :lambda-list '(m))
(cl:defmethod uint8_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint8_array-val is deprecated.  Use jsk_network_tools-msg:uint8_array instead.")
  (uint8_array m))

(cl:ensure-generic-function 'int8_atom-val :lambda-list '(m))
(cl:defmethod int8_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:int8_atom-val is deprecated.  Use jsk_network_tools-msg:int8_atom instead.")
  (int8_atom m))

(cl:ensure-generic-function 'int8_array-val :lambda-list '(m))
(cl:defmethod int8_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:int8_array-val is deprecated.  Use jsk_network_tools-msg:int8_array instead.")
  (int8_array m))

(cl:ensure-generic-function 'uint16_atom-val :lambda-list '(m))
(cl:defmethod uint16_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint16_atom-val is deprecated.  Use jsk_network_tools-msg:uint16_atom instead.")
  (uint16_atom m))

(cl:ensure-generic-function 'uint16_array-val :lambda-list '(m))
(cl:defmethod uint16_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint16_array-val is deprecated.  Use jsk_network_tools-msg:uint16_array instead.")
  (uint16_array m))

(cl:ensure-generic-function 'int32_atom-val :lambda-list '(m))
(cl:defmethod int32_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:int32_atom-val is deprecated.  Use jsk_network_tools-msg:int32_atom instead.")
  (int32_atom m))

(cl:ensure-generic-function 'int32_array-val :lambda-list '(m))
(cl:defmethod int32_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:int32_array-val is deprecated.  Use jsk_network_tools-msg:int32_array instead.")
  (int32_array m))

(cl:ensure-generic-function 'uint32_atom-val :lambda-list '(m))
(cl:defmethod uint32_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint32_atom-val is deprecated.  Use jsk_network_tools-msg:uint32_atom instead.")
  (uint32_atom m))

(cl:ensure-generic-function 'uint32_array-val :lambda-list '(m))
(cl:defmethod uint32_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint32_array-val is deprecated.  Use jsk_network_tools-msg:uint32_array instead.")
  (uint32_array m))

(cl:ensure-generic-function 'int64_atom-val :lambda-list '(m))
(cl:defmethod int64_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:int64_atom-val is deprecated.  Use jsk_network_tools-msg:int64_atom instead.")
  (int64_atom m))

(cl:ensure-generic-function 'int64_array-val :lambda-list '(m))
(cl:defmethod int64_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:int64_array-val is deprecated.  Use jsk_network_tools-msg:int64_array instead.")
  (int64_array m))

(cl:ensure-generic-function 'uint64_atom-val :lambda-list '(m))
(cl:defmethod uint64_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint64_atom-val is deprecated.  Use jsk_network_tools-msg:uint64_atom instead.")
  (uint64_atom m))

(cl:ensure-generic-function 'uint64_array-val :lambda-list '(m))
(cl:defmethod uint64_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:uint64_array-val is deprecated.  Use jsk_network_tools-msg:uint64_array instead.")
  (uint64_array m))

(cl:ensure-generic-function 'float32_atom-val :lambda-list '(m))
(cl:defmethod float32_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:float32_atom-val is deprecated.  Use jsk_network_tools-msg:float32_atom instead.")
  (float32_atom m))

(cl:ensure-generic-function 'float32_array-val :lambda-list '(m))
(cl:defmethod float32_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:float32_array-val is deprecated.  Use jsk_network_tools-msg:float32_array instead.")
  (float32_array m))

(cl:ensure-generic-function 'float64_atom-val :lambda-list '(m))
(cl:defmethod float64_atom-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:float64_atom-val is deprecated.  Use jsk_network_tools-msg:float64_atom instead.")
  (float64_atom m))

(cl:ensure-generic-function 'float64_array-val :lambda-list '(m))
(cl:defmethod float64_array-val ((m <AllTypeTest>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:float64_array-val is deprecated.  Use jsk_network_tools-msg:float64_array instead.")
  (float64_array m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AllTypeTest>) ostream)
  "Serializes a message object of type '<AllTypeTest>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'bool_atom) 1 0)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'bool_array))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint8_atom)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'uint8_array))
  (cl:let* ((signed (cl:slot-value msg 'int8_atom)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let* ((signed ele) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    ))
   (cl:slot-value msg 'int8_array))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint16_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'uint16_atom)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'uint16_array))
  (cl:let* ((signed (cl:slot-value msg 'int32_atom)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    )
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let* ((signed ele) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 4294967296) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    ))
   (cl:slot-value msg 'int32_array))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint32_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'uint32_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'uint32_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'uint32_atom)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) ele) ostream))
   (cl:slot-value msg 'uint32_array))
  (cl:let* ((signed (cl:slot-value msg 'int64_atom)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 18446744073709551616) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) unsigned) ostream)
    )
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let* ((signed ele) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 18446744073709551616) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) unsigned) ostream)
    ))
   (cl:slot-value msg 'int64_array))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'uint64_atom)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 32) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 40) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 48) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 56) ele) ostream))
   (cl:slot-value msg 'uint64_array))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'float32_atom))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-single-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)))
   (cl:slot-value msg 'float32_array))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'float64_atom))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'float64_array))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AllTypeTest>) istream)
  "Deserializes a message object of type '<AllTypeTest>"
    (cl:setf (cl:slot-value msg 'bool_atom) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:setf (cl:slot-value msg 'bool_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'bool_array)))
    (cl:dotimes (i 4)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream))))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint8_atom)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'uint8_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'uint8_array)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'int8_atom) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  (cl:setf (cl:slot-value msg 'int8_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'int8_array)))
    (cl:dotimes (i 4)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint16_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'uint16_atom)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'uint16_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'uint16_array)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'int32_atom) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))
  (cl:setf (cl:slot-value msg 'int32_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'int32_array)))
    (cl:dotimes (i 4)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:if (cl:< unsigned 2147483648) unsigned (cl:- unsigned 4294967296))))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint32_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'uint32_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'uint32_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'uint32_atom)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'uint32_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'uint32_array)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'int64_atom) (cl:if (cl:< unsigned 9223372036854775808) unsigned (cl:- unsigned 18446744073709551616))))
  (cl:setf (cl:slot-value msg 'int64_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'int64_array)))
    (cl:dotimes (i 4)
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) unsigned) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:if (cl:< unsigned 9223372036854775808) unsigned (cl:- unsigned 18446744073709551616))))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 32) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 40) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 48) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 56) (cl:slot-value msg 'uint64_atom)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'uint64_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'uint64_array)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 32) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 40) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 48) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 56) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'float32_atom) (roslisp-utils:decode-single-float-bits bits)))
  (cl:setf (cl:slot-value msg 'float32_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'float32_array)))
    (cl:dotimes (i 4)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-single-float-bits bits)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'float64_atom) (roslisp-utils:decode-double-float-bits bits)))
  (cl:setf (cl:slot-value msg 'float64_array) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'float64_array)))
    (cl:dotimes (i 4)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AllTypeTest>)))
  "Returns string type for a message object of type '<AllTypeTest>"
  "jsk_network_tools/AllTypeTest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AllTypeTest)))
  "Returns string type for a message object of type 'AllTypeTest"
  "jsk_network_tools/AllTypeTest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AllTypeTest>)))
  "Returns md5sum for a message object of type '<AllTypeTest>"
  "e38fde731d43d6674bf0d48497971fd6")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AllTypeTest)))
  "Returns md5sum for a message object of type 'AllTypeTest"
  "e38fde731d43d6674bf0d48497971fd6")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AllTypeTest>)))
  "Returns full string definition for message of type '<AllTypeTest>"
  (cl:format cl:nil "bool       bool_atom~%bool[4]    bool_array~%uint8      uint8_atom~%uint8[4]   uint8_array~%int8       int8_atom~%int8[4]    int8_array~%uint16     uint16_atom~%uint16[4]  uint16_array~%int32      int32_atom~%int32[4]   int32_array~%uint32     uint32_atom~%uint32[4]  uint32_array~%int64      int64_atom~%int64[4]   int64_array~%uint64     uint64_atom~%uint64[4]  uint64_array~%float32    float32_atom~%float32[4] float32_array~%float64    float64_atom~%float64[4] float64_array~%~%# int8, not supported~%# string, not supported~%# time, not supported~%# duration, not supported~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AllTypeTest)))
  "Returns full string definition for message of type 'AllTypeTest"
  (cl:format cl:nil "bool       bool_atom~%bool[4]    bool_array~%uint8      uint8_atom~%uint8[4]   uint8_array~%int8       int8_atom~%int8[4]    int8_array~%uint16     uint16_atom~%uint16[4]  uint16_array~%int32      int32_atom~%int32[4]   int32_array~%uint32     uint32_atom~%uint32[4]  uint32_array~%int64      int64_atom~%int64[4]   int64_array~%uint64     uint64_atom~%uint64[4]  uint64_array~%float32    float32_atom~%float32[4] float32_array~%float64    float64_atom~%float64[4] float64_array~%~%# int8, not supported~%# string, not supported~%# time, not supported~%# duration, not supported~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AllTypeTest>))
  (cl:+ 0
     1
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'bool_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     1
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'uint8_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     1
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'int8_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     2
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'uint16_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     4
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'int32_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
     4
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'uint32_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
     8
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'int64_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     8
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'uint64_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'float32_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
     8
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'float64_array) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AllTypeTest>))
  "Converts a ROS message object to a list"
  (cl:list 'AllTypeTest
    (cl:cons ':bool_atom (bool_atom msg))
    (cl:cons ':bool_array (bool_array msg))
    (cl:cons ':uint8_atom (uint8_atom msg))
    (cl:cons ':uint8_array (uint8_array msg))
    (cl:cons ':int8_atom (int8_atom msg))
    (cl:cons ':int8_array (int8_array msg))
    (cl:cons ':uint16_atom (uint16_atom msg))
    (cl:cons ':uint16_array (uint16_array msg))
    (cl:cons ':int32_atom (int32_atom msg))
    (cl:cons ':int32_array (int32_array msg))
    (cl:cons ':uint32_atom (uint32_atom msg))
    (cl:cons ':uint32_array (uint32_array msg))
    (cl:cons ':int64_atom (int64_atom msg))
    (cl:cons ':int64_array (int64_array msg))
    (cl:cons ':uint64_atom (uint64_atom msg))
    (cl:cons ':uint64_array (uint64_array msg))
    (cl:cons ':float32_atom (float32_atom msg))
    (cl:cons ':float32_array (float32_array msg))
    (cl:cons ':float64_atom (float64_atom msg))
    (cl:cons ':float64_array (float64_array msg))
))
