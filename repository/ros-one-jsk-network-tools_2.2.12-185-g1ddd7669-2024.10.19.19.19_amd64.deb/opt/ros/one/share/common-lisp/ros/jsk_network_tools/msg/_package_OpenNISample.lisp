(cl:in-package jsk_network_tools-msg)
(cl:export '(CAMERA__RGB__IMAGE_RECT_COLOR-VAL
          CAMERA__RGB__IMAGE_RECT_COLOR
          CAMERA__DEPTH_REGISTERED__POINTS-VAL
          CAMERA__DEPTH_REGISTERED__POINTS
))