(cl:in-package jsk_network_tools-msg)
(cl:export '(HEADER-VAL
          HEADER
          INTERFACE-VAL
          INTERFACE
          ENABLED-VAL
          ENABLED
          CONNECTED-VAL
          CONNECTED
          SSID-VAL
          SSID
          FREQUENCY-VAL
          FREQUENCY
          ACCESS_POINT-VAL
          ACCESS_POINT
          BITRATE-VAL
          BITRATE
          TX_POWER-VAL
          TX_POWER
          LINK_QUALITY-VAL
          LINK_QUALITY
          SIGNAL_LEVEL-VAL
          SIGNAL_LEVEL
))