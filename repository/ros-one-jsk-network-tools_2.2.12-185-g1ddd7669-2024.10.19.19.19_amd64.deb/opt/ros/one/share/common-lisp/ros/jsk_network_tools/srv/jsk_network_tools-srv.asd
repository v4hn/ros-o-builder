
(cl:in-package :asdf)

(defsystem "jsk_network_tools-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "SetSendRate" :depends-on ("_package_SetSendRate"))
    (:file "_package_SetSendRate" :depends-on ("_package"))
  ))