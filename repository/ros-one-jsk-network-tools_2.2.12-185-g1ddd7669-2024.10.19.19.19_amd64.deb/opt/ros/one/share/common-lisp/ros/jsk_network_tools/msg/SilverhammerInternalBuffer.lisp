; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude SilverhammerInternalBuffer.msg.html

(cl:defclass <SilverhammerInternalBuffer> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (seq_id
    :reader seq_id
    :initarg :seq_id
    :type cl:integer
    :initform 0)
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass SilverhammerInternalBuffer (<SilverhammerInternalBuffer>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SilverhammerInternalBuffer>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SilverhammerInternalBuffer)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<SilverhammerInternalBuffer> is deprecated: use jsk_network_tools-msg:SilverhammerInternalBuffer instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <SilverhammerInternalBuffer>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:header-val is deprecated.  Use jsk_network_tools-msg:header instead.")
  (header m))

(cl:ensure-generic-function 'seq_id-val :lambda-list '(m))
(cl:defmethod seq_id-val ((m <SilverhammerInternalBuffer>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:seq_id-val is deprecated.  Use jsk_network_tools-msg:seq_id instead.")
  (seq_id m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <SilverhammerInternalBuffer>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:data-val is deprecated.  Use jsk_network_tools-msg:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SilverhammerInternalBuffer>) ostream)
  "Serializes a message object of type '<SilverhammerInternalBuffer>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'seq_id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'seq_id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'seq_id)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'seq_id)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SilverhammerInternalBuffer>) istream)
  "Deserializes a message object of type '<SilverhammerInternalBuffer>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'seq_id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'seq_id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'seq_id)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'seq_id)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SilverhammerInternalBuffer>)))
  "Returns string type for a message object of type '<SilverhammerInternalBuffer>"
  "jsk_network_tools/SilverhammerInternalBuffer")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SilverhammerInternalBuffer)))
  "Returns string type for a message object of type 'SilverhammerInternalBuffer"
  "jsk_network_tools/SilverhammerInternalBuffer")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SilverhammerInternalBuffer>)))
  "Returns md5sum for a message object of type '<SilverhammerInternalBuffer>"
  "b0224c297e0e2b6e1ac36f4f9188136f")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SilverhammerInternalBuffer)))
  "Returns md5sum for a message object of type 'SilverhammerInternalBuffer"
  "b0224c297e0e2b6e1ac36f4f9188136f")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SilverhammerInternalBuffer>)))
  "Returns full string definition for message of type '<SilverhammerInternalBuffer>"
  (cl:format cl:nil "Header header~%uint32 seq_id~%uint8[] data~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SilverhammerInternalBuffer)))
  "Returns full string definition for message of type 'SilverhammerInternalBuffer"
  (cl:format cl:nil "Header header~%uint32 seq_id~%uint8[] data~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SilverhammerInternalBuffer>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SilverhammerInternalBuffer>))
  "Converts a ROS message object to a list"
  (cl:list 'SilverhammerInternalBuffer
    (cl:cons ':header (header msg))
    (cl:cons ':seq_id (seq_id msg))
    (cl:cons ':data (data msg))
))
