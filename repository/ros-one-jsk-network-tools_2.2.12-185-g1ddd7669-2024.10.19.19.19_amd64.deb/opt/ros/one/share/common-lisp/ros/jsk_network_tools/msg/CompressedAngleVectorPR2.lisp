; Auto-generated. Do not edit!


(cl:in-package jsk_network_tools-msg)


;//! \htmlinclude CompressedAngleVectorPR2.msg.html

(cl:defclass <CompressedAngleVectorPR2> (roslisp-msg-protocol:ros-message)
  ((angles
    :reader angles
    :initarg :angles
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 17 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass CompressedAngleVectorPR2 (<CompressedAngleVectorPR2>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CompressedAngleVectorPR2>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CompressedAngleVectorPR2)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_network_tools-msg:<CompressedAngleVectorPR2> is deprecated: use jsk_network_tools-msg:CompressedAngleVectorPR2 instead.")))

(cl:ensure-generic-function 'angles-val :lambda-list '(m))
(cl:defmethod angles-val ((m <CompressedAngleVectorPR2>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_network_tools-msg:angles-val is deprecated.  Use jsk_network_tools-msg:angles instead.")
  (angles m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CompressedAngleVectorPR2>) ostream)
  "Serializes a message object of type '<CompressedAngleVectorPR2>"
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'angles))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CompressedAngleVectorPR2>) istream)
  "Deserializes a message object of type '<CompressedAngleVectorPR2>"
  (cl:setf (cl:slot-value msg 'angles) (cl:make-array 17))
  (cl:let ((vals (cl:slot-value msg 'angles)))
    (cl:dotimes (i 17)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CompressedAngleVectorPR2>)))
  "Returns string type for a message object of type '<CompressedAngleVectorPR2>"
  "jsk_network_tools/CompressedAngleVectorPR2")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CompressedAngleVectorPR2)))
  "Returns string type for a message object of type 'CompressedAngleVectorPR2"
  "jsk_network_tools/CompressedAngleVectorPR2")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CompressedAngleVectorPR2>)))
  "Returns md5sum for a message object of type '<CompressedAngleVectorPR2>"
  "41a167b428fc98b1c378a7ba1bae8d54")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CompressedAngleVectorPR2)))
  "Returns md5sum for a message object of type 'CompressedAngleVectorPR2"
  "41a167b428fc98b1c378a7ba1bae8d54")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CompressedAngleVectorPR2>)))
  "Returns full string definition for message of type '<CompressedAngleVectorPR2>"
  (cl:format cl:nil "uint8[17] angles~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CompressedAngleVectorPR2)))
  "Returns full string definition for message of type 'CompressedAngleVectorPR2"
  (cl:format cl:nil "uint8[17] angles~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CompressedAngleVectorPR2>))
  (cl:+ 0
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'angles) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CompressedAngleVectorPR2>))
  "Converts a ROS message object to a list"
  (cl:list 'CompressedAngleVectorPR2
    (cl:cons ':angles (angles msg))
))
