// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class FC2OCSLargeData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.camera__rgb__image_rect_color = null;
      this.joint_state = null;
      this.usb_cam__image_raw = null;
    }
    else {
      if (initObj.hasOwnProperty('camera__rgb__image_rect_color')) {
        this.camera__rgb__image_rect_color = initObj.camera__rgb__image_rect_color
      }
      else {
        this.camera__rgb__image_rect_color = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('joint_state')) {
        this.joint_state = initObj.joint_state
      }
      else {
        this.joint_state = new sensor_msgs.msg.JointState();
      }
      if (initObj.hasOwnProperty('usb_cam__image_raw')) {
        this.usb_cam__image_raw = initObj.usb_cam__image_raw
      }
      else {
        this.usb_cam__image_raw = new sensor_msgs.msg.Image();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FC2OCSLargeData
    // Serialize message field [camera__rgb__image_rect_color]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.camera__rgb__image_rect_color, buffer, bufferOffset);
    // Serialize message field [joint_state]
    bufferOffset = sensor_msgs.msg.JointState.serialize(obj.joint_state, buffer, bufferOffset);
    // Serialize message field [usb_cam__image_raw]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.usb_cam__image_raw, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FC2OCSLargeData
    let len;
    let data = new FC2OCSLargeData(null);
    // Deserialize message field [camera__rgb__image_rect_color]
    data.camera__rgb__image_rect_color = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [joint_state]
    data.joint_state = sensor_msgs.msg.JointState.deserialize(buffer, bufferOffset);
    // Deserialize message field [usb_cam__image_raw]
    data.usb_cam__image_raw = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.Image.getMessageSize(object.camera__rgb__image_rect_color);
    length += sensor_msgs.msg.JointState.getMessageSize(object.joint_state);
    length += sensor_msgs.msg.Image.getMessageSize(object.usb_cam__image_raw);
    return length;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/FC2OCSLargeData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '51c7ca6e66514e69ddd1a156f6a0b404';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # large message from FC to OSC
    # topic name will be automatically generated from
    # field names.
    # the rule is super simple, just replace '__' with '/'
    sensor_msgs/Image camera__rgb__image_rect_color
    sensor_msgs/JointState joint_state
    sensor_msgs/Image usb_cam__image_raw
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of camera
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/JointState
    # This is a message that holds data to describe the state of a set of torque controlled joints. 
    #
    # The state of each joint (revolute or prismatic) is defined by:
    #  * the position of the joint (rad or m),
    #  * the velocity of the joint (rad/s or m/s) and 
    #  * the effort that is applied in the joint (Nm or N).
    #
    # Each joint is uniquely identified by its name
    # The header specifies the time at which the joint states were recorded. All the joint states
    # in one message have to be recorded at the same time.
    #
    # This message consists of a multiple arrays, one for each part of the joint state. 
    # The goal is to make each of the fields optional. When e.g. your joints have no
    # effort associated with them, you can leave the effort array empty. 
    #
    # All arrays in this message should have the same size, or be empty.
    # This is the only way to uniquely associate the joint name with the correct
    # states.
    
    
    Header header
    
    string[] name
    float64[] position
    float64[] velocity
    float64[] effort
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FC2OCSLargeData(null);
    if (msg.camera__rgb__image_rect_color !== undefined) {
      resolved.camera__rgb__image_rect_color = sensor_msgs.msg.Image.Resolve(msg.camera__rgb__image_rect_color)
    }
    else {
      resolved.camera__rgb__image_rect_color = new sensor_msgs.msg.Image()
    }

    if (msg.joint_state !== undefined) {
      resolved.joint_state = sensor_msgs.msg.JointState.Resolve(msg.joint_state)
    }
    else {
      resolved.joint_state = new sensor_msgs.msg.JointState()
    }

    if (msg.usb_cam__image_raw !== undefined) {
      resolved.usb_cam__image_raw = sensor_msgs.msg.Image.Resolve(msg.usb_cam__image_raw)
    }
    else {
      resolved.usb_cam__image_raw = new sensor_msgs.msg.Image()
    }

    return resolved;
    }
};

module.exports = FC2OCSLargeData;
