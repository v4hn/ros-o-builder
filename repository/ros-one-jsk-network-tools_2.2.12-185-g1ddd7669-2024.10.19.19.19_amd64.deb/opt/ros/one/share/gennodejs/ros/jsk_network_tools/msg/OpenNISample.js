// Auto-generated. Do not edit!

// (in-package jsk_network_tools.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let sensor_msgs = _finder('sensor_msgs');

//-----------------------------------------------------------

class OpenNISample {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.camera__rgb__image_rect_color = null;
      this.camera__depth_registered__points = null;
    }
    else {
      if (initObj.hasOwnProperty('camera__rgb__image_rect_color')) {
        this.camera__rgb__image_rect_color = initObj.camera__rgb__image_rect_color
      }
      else {
        this.camera__rgb__image_rect_color = new sensor_msgs.msg.Image();
      }
      if (initObj.hasOwnProperty('camera__depth_registered__points')) {
        this.camera__depth_registered__points = initObj.camera__depth_registered__points
      }
      else {
        this.camera__depth_registered__points = new sensor_msgs.msg.PointCloud2();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type OpenNISample
    // Serialize message field [camera__rgb__image_rect_color]
    bufferOffset = sensor_msgs.msg.Image.serialize(obj.camera__rgb__image_rect_color, buffer, bufferOffset);
    // Serialize message field [camera__depth_registered__points]
    bufferOffset = sensor_msgs.msg.PointCloud2.serialize(obj.camera__depth_registered__points, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type OpenNISample
    let len;
    let data = new OpenNISample(null);
    // Deserialize message field [camera__rgb__image_rect_color]
    data.camera__rgb__image_rect_color = sensor_msgs.msg.Image.deserialize(buffer, bufferOffset);
    // Deserialize message field [camera__depth_registered__points]
    data.camera__depth_registered__points = sensor_msgs.msg.PointCloud2.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += sensor_msgs.msg.Image.getMessageSize(object.camera__rgb__image_rect_color);
    length += sensor_msgs.msg.PointCloud2.getMessageSize(object.camera__depth_registered__points);
    return length;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_network_tools/OpenNISample';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c998c0df481d0ad4598a2534cadda5d1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    sensor_msgs/Image camera__rgb__image_rect_color
    sensor_msgs/PointCloud2 camera__depth_registered__points
    
    ================================================================================
    MSG: sensor_msgs/Image
    # This message contains an uncompressed image
    # (0, 0) is at top-left corner of image
    #
    
    Header header        # Header timestamp should be acquisition time of image
                         # Header frame_id should be optical frame of camera
                         # origin of frame should be optical center of camera
                         # +x should point to the right in the image
                         # +y should point down in the image
                         # +z should point into to plane of the image
                         # If the frame_id here and the frame_id of the CameraInfo
                         # message associated with the image conflict
                         # the behavior is undefined
    
    uint32 height         # image height, that is, number of rows
    uint32 width          # image width, that is, number of columns
    
    # The legal values for encoding are in file src/image_encodings.cpp
    # If you want to standardize a new string format, join
    # ros-users@lists.sourceforge.net and send an email proposing a new encoding.
    
    string encoding       # Encoding of pixels -- channel meaning, ordering, size
                          # taken from the list of strings in include/sensor_msgs/image_encodings.h
    
    uint8 is_bigendian    # is this data bigendian?
    uint32 step           # Full row length in bytes
    uint8[] data          # actual matrix data, size is (step * rows)
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: sensor_msgs/PointCloud2
    # This message holds a collection of N-dimensional points, which may
    # contain additional information such as normals, intensity, etc. The
    # point data is stored as a binary blob, its layout described by the
    # contents of the "fields" array.
    
    # The point cloud data may be organized 2d (image-like) or 1d
    # (unordered). Point clouds organized as 2d images may be produced by
    # camera depth sensors such as stereo or time-of-flight.
    
    # Time of sensor data acquisition, and the coordinate frame ID (for 3d
    # points).
    Header header
    
    # 2D structure of the point cloud. If the cloud is unordered, height is
    # 1 and width is the length of the point cloud.
    uint32 height
    uint32 width
    
    # Describes the channels and their layout in the binary data blob.
    PointField[] fields
    
    bool    is_bigendian # Is this data bigendian?
    uint32  point_step   # Length of a point in bytes
    uint32  row_step     # Length of a row in bytes
    uint8[] data         # Actual point data, size is (row_step*height)
    
    bool is_dense        # True if there are no invalid points
    
    ================================================================================
    MSG: sensor_msgs/PointField
    # This message holds the description of one point entry in the
    # PointCloud2 message format.
    uint8 INT8    = 1
    uint8 UINT8   = 2
    uint8 INT16   = 3
    uint8 UINT16  = 4
    uint8 INT32   = 5
    uint8 UINT32  = 6
    uint8 FLOAT32 = 7
    uint8 FLOAT64 = 8
    
    string name      # Name of field
    uint32 offset    # Offset from start of point struct
    uint8  datatype  # Datatype enumeration, see above
    uint32 count     # How many elements in the field
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new OpenNISample(null);
    if (msg.camera__rgb__image_rect_color !== undefined) {
      resolved.camera__rgb__image_rect_color = sensor_msgs.msg.Image.Resolve(msg.camera__rgb__image_rect_color)
    }
    else {
      resolved.camera__rgb__image_rect_color = new sensor_msgs.msg.Image()
    }

    if (msg.camera__depth_registered__points !== undefined) {
      resolved.camera__depth_registered__points = sensor_msgs.msg.PointCloud2.Resolve(msg.camera__depth_registered__points)
    }
    else {
      resolved.camera__depth_registered__points = new sensor_msgs.msg.PointCloud2()
    }

    return resolved;
    }
};

module.exports = OpenNISample;
