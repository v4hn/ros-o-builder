#!/usr/bin/env python3

from power_switching_tools_ros.power_switching_driver_base import PowerSwitchingDriverBase
import rospy
import serial


class UsbSerialTroubleshooterDriver(PowerSwitchingDriverBase):

    def __init__(self):
        port = rospy.get_param('~port', '/dev/ttyACM0')
        ser_timeout = rospy.get_param('~serial_timeout', None)

        rospy.loginfo('[{}] Port: {}'.format(rospy.get_name(), port))
        # USB-Serial troubleshooter default settings
        self.ser = serial.Serial(
            port,
            baudrate=115200,
            timeout=ser_timeout,
            writeTimeout=ser_timeout,
        )

        super(UsbSerialTroubleshooterDriver, self).__init__()

    def _pwr(self, is_on):
        try:
            self.ser.write('PW={}\r\n'.format(int(is_on)).encode())
        except (serial.SerialTimeoutException, OSError) as e:
            rospy.logerr(
                '[{}] Serial write failed: {}'.format(rospy.get_name(), e))
            rospy.signal_shutdown('Serial write failed')
            return False
        try:
            res = self.ser.read(4)
        except OSError as e:
            rospy.logerr(
                '[{}] Serial read failed: {}'.format(rospy.get_name(), e))
            rospy.signal_shutdown('Serial read failed')
            return False
        if res == b'OK\r\n':
            rospy.loginfo(
                '[{}] Changed power state to {}'.format(
                    rospy.get_name(), is_on))
            return True
        else:
            try:
                res += self.ser.read(3)
            except OSError as e:
                rospy.logerr(
                    '[{}] Serial read failed: {}'.format(rospy.get_name(), e))
                rospy.signal_shutdown('Serial read failed')
            if len(res) != 7:
                rospy.logerr(
                    '[{}] Serial read timeout'.format(rospy.get_name()))
                rospy.signal_shutdown('Serial read timeout')
            else:
                rospy.logerr(
                    '[{}] Return value is {}'.format(
                        rospy.get_name(), res))
                rospy.signal_shutdown('Return value is erroneous')
            return False


if __name__ == '__main__':
    rospy.init_node('usb_serial_troubleshooter_driver')
    app = UsbSerialTroubleshooterDriver()
    rospy.spin()
