
"use strict";

let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let Table = require('./Table.js');
let ObjectType = require('./ObjectType.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let TableArray = require('./TableArray.js');
let RecognizedObject = require('./RecognizedObject.js');
let ObjectInformation = require('./ObjectInformation.js');

module.exports = {
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  Table: Table,
  ObjectType: ObjectType,
  RecognizedObjectArray: RecognizedObjectArray,
  TableArray: TableArray,
  RecognizedObject: RecognizedObject,
  ObjectInformation: ObjectInformation,
};
