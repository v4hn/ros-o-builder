
"use strict";

let TestArrayRequest = require('./TestArrayRequest.js')
let TestEmpty = require('./TestEmpty.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestNestedService = require('./TestNestedService.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let SendBytes = require('./SendBytes.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')

module.exports = {
  TestArrayRequest: TestArrayRequest,
  TestEmpty: TestEmpty,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestRequestOnly: TestRequestOnly,
  TestResponseOnly: TestResponseOnly,
  TestNestedService: TestNestedService,
  AddTwoInts: AddTwoInts,
  TestMultipleResponseFields: TestMultipleResponseFields,
  SendBytes: SendBytes,
  TestRequestAndResponse: TestRequestAndResponse,
};
