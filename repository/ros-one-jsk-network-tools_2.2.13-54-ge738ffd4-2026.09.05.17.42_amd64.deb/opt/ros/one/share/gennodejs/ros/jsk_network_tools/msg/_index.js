
"use strict";

let WifiStatus = require('./WifiStatus.js');
let CompressedAngleVectorPR2 = require('./CompressedAngleVectorPR2.js');
let FC2OCS = require('./FC2OCS.js');
let OCS2FC = require('./OCS2FC.js');
let HeartbeatResponse = require('./HeartbeatResponse.js');
let AllTypeTest = require('./AllTypeTest.js');
let OpenNISample = require('./OpenNISample.js');
let FC2OCSLargeData = require('./FC2OCSLargeData.js');
let SilverhammerInternalBuffer = require('./SilverhammerInternalBuffer.js');
let Heartbeat = require('./Heartbeat.js');

module.exports = {
  WifiStatus: WifiStatus,
  CompressedAngleVectorPR2: CompressedAngleVectorPR2,
  FC2OCS: FC2OCS,
  OCS2FC: OCS2FC,
  HeartbeatResponse: HeartbeatResponse,
  AllTypeTest: AllTypeTest,
  OpenNISample: OpenNISample,
  FC2OCSLargeData: FC2OCSLargeData,
  SilverhammerInternalBuffer: SilverhammerInternalBuffer,
  Heartbeat: Heartbeat,
};
