
"use strict";

let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let RecognizedObject = require('./RecognizedObject.js');
let TableArray = require('./TableArray.js');
let ObjectType = require('./ObjectType.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let Table = require('./Table.js');
let ObjectInformation = require('./ObjectInformation.js');

module.exports = {
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  RecognizedObject: RecognizedObject,
  TableArray: TableArray,
  ObjectType: ObjectType,
  RecognizedObjectArray: RecognizedObjectArray,
  Table: Table,
  ObjectInformation: ObjectInformation,
};
