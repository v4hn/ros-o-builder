
"use strict";

let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let JointStatistics = require('./JointStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');

module.exports = {
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerResult: SwitchControllerResult,
  SwitchControllerActionResult: SwitchControllerActionResult,
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  JointStatistics: JointStatistics,
  MechanismStatistics: MechanismStatistics,
  ActuatorStatistics: ActuatorStatistics,
  ControllerStatistics: ControllerStatistics,
};
