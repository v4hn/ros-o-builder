
"use strict";

let Velocity = require('./Velocity.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeFeedback = require('./ShapeFeedback.js');

module.exports = {
  Velocity: Velocity,
  ShapeActionGoal: ShapeActionGoal,
  ShapeActionResult: ShapeActionResult,
  ShapeGoal: ShapeGoal,
  ShapeAction: ShapeAction,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeResult: ShapeResult,
  ShapeFeedback: ShapeFeedback,
};
