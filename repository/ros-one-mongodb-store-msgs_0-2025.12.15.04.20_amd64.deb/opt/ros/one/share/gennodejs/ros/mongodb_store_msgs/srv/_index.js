
"use strict";

let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')
let MongoDeleteMsg = require('./MongoDeleteMsg.js')
let MongoUpdateMsg = require('./MongoUpdateMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')
let MongoInsertMsg = require('./MongoInsertMsg.js')

module.exports = {
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
  MongoDeleteMsg: MongoDeleteMsg,
  MongoUpdateMsg: MongoUpdateMsg,
  MongoQueryMsg: MongoQueryMsg,
  MongoInsertMsg: MongoInsertMsg,
};
