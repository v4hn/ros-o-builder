# CMake OMPL config module
#
# Usage:
# find_package(ompl  REQUIRED)
# add_library(your_app main.cpp)
# target_link_libraries(your_app PRIVATE ompl::ompl)


####### Expanded from @PACKAGE_INIT@ by configure_package_config_file() #######
####### Any changes to this file will be overwritten by the next CMake run ####
####### The input file was omplConfig.cmake.in                            ########

get_filename_component(PACKAGE_PREFIX_DIR "${CMAKE_CURRENT_LIST_DIR}/../../../" ABSOLUTE)

macro(set_and_check _var _file)
  set(${_var} "${_file}")
  if(NOT EXISTS "${_file}")
    message(FATAL_ERROR "File or directory ${_file} referenced by variable ${_var} does not exist !")
  endif()
endmacro()

####################################################################################

include ("${CMAKE_CURRENT_LIST_DIR}/omplExport.cmake" )
include(CMakeFindDependencyMacro)
find_dependency(Boost REQUIRED COMPONENTS serialization filesystem system)
find_dependency(Eigen3 REQUIRED)

# Add OMPL's find modules to the search path so consumers can also find them.
list(APPEND CMAKE_MODULE_PATH ${CMAKE_CURRENT_LIST_DIR})

if() # if(OMPL_HAVE_FLANN)
    find_dependency(flann REQUIRED)
endif()
# If flann is required at version 1.9.2 minimum, then the below logic is unneeded.
#if(flann_FOUND)
#    if(NOT TARGET flann::flann and TARGET flann)
#        add_library(flann::flann ALIAS flan)
#    endif()
#endif()

if(FALSE) # if(OMPL_EXTENSION_TRIANGLE)
    # If OMPL was build with TRIANGLE support,
    # then it's required to have TRIANGLE to consume OMPL.
    find_dependency(Triangle REQUIRED)
endif()

if(TRUE) # if(Threads_FOUND)
    find_dependency(Threads QUIET)
endif()

if() # if(OMPL_HAVE_SPOT)
    find_dependency(spot MODULE QUIET)
endif()
