
"use strict";

let AprilTagDetection = require('./AprilTagDetection.js');
let AprilTagDetectionArray = require('./AprilTagDetectionArray.js');

module.exports = {
  AprilTagDetection: AprilTagDetection,
  AprilTagDetectionArray: AprilTagDetectionArray,
};
