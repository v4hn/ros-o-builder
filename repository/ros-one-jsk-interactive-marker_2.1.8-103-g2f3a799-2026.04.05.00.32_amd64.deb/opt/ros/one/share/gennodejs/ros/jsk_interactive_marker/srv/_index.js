
"use strict";

let GetTransformableMarkerFocus = require('./GetTransformableMarkerFocus.js')
let GetTransformableMarkerExistence = require('./GetTransformableMarkerExistence.js')
let SetMarkerDimensions = require('./SetMarkerDimensions.js')
let GetType = require('./GetType.js')
let SetTransformableMarkerColor = require('./SetTransformableMarkerColor.js')
let SetHeuristic = require('./SetHeuristic.js')
let SnapFootPrint = require('./SnapFootPrint.js')
let SetTransformableMarkerFocus = require('./SetTransformableMarkerFocus.js')
let GetMarkerDimensions = require('./GetMarkerDimensions.js')
let SetPose = require('./SetPose.js')
let RemoveParentMarker = require('./RemoveParentMarker.js')
let SetParentMarker = require('./SetParentMarker.js')
let GetTransformableMarkerPose = require('./GetTransformableMarkerPose.js')
let MarkerSetPose = require('./MarkerSetPose.js')
let SetTransformableMarkerPose = require('./SetTransformableMarkerPose.js')
let GetTransformableMarkerColor = require('./GetTransformableMarkerColor.js')
let GetJointState = require('./GetJointState.js')
let IndexRequest = require('./IndexRequest.js')

module.exports = {
  GetTransformableMarkerFocus: GetTransformableMarkerFocus,
  GetTransformableMarkerExistence: GetTransformableMarkerExistence,
  SetMarkerDimensions: SetMarkerDimensions,
  GetType: GetType,
  SetTransformableMarkerColor: SetTransformableMarkerColor,
  SetHeuristic: SetHeuristic,
  SnapFootPrint: SnapFootPrint,
  SetTransformableMarkerFocus: SetTransformableMarkerFocus,
  GetMarkerDimensions: GetMarkerDimensions,
  SetPose: SetPose,
  RemoveParentMarker: RemoveParentMarker,
  SetParentMarker: SetParentMarker,
  GetTransformableMarkerPose: GetTransformableMarkerPose,
  MarkerSetPose: MarkerSetPose,
  SetTransformableMarkerPose: SetTransformableMarkerPose,
  GetTransformableMarkerColor: GetTransformableMarkerColor,
  GetJointState: GetJointState,
  IndexRequest: IndexRequest,
};
