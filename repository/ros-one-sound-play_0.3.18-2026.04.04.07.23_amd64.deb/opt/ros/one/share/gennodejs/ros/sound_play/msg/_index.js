
"use strict";

let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestResult: SoundRequestResult,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequest: SoundRequest,
};
