(cl:in-package twist_mux_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          GOAL_ID-VAL
          GOAL_ID
          GOAL-VAL
          GOAL
))