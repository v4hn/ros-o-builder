
"use strict";

let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let JointStatistics = require('./JointStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');

module.exports = {
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  SwitchControllerResult: SwitchControllerResult,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerActionResult: SwitchControllerActionResult,
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  JointStatistics: JointStatistics,
  ControllerStatistics: ControllerStatistics,
  MechanismStatistics: MechanismStatistics,
  ActuatorStatistics: ActuatorStatistics,
};
