
"use strict";

let FibonacciFeedback = require('./FibonacciFeedback.js');
let AveragingGoal = require('./AveragingGoal.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let AveragingResult = require('./AveragingResult.js');
let AveragingAction = require('./AveragingAction.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let FibonacciResult = require('./FibonacciResult.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let FibonacciAction = require('./FibonacciAction.js');

module.exports = {
  FibonacciFeedback: FibonacciFeedback,
  AveragingGoal: AveragingGoal,
  FibonacciGoal: FibonacciGoal,
  FibonacciActionResult: FibonacciActionResult,
  AveragingActionFeedback: AveragingActionFeedback,
  AveragingActionGoal: AveragingActionGoal,
  FibonacciActionFeedback: FibonacciActionFeedback,
  AveragingResult: AveragingResult,
  AveragingAction: AveragingAction,
  AveragingActionResult: AveragingActionResult,
  FibonacciResult: FibonacciResult,
  FibonacciActionGoal: FibonacciActionGoal,
  AveragingFeedback: AveragingFeedback,
  FibonacciAction: FibonacciAction,
};
