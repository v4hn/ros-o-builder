
"use strict";

let PolygonMesh = require('./PolygonMesh.js');
let ModelCoefficients = require('./ModelCoefficients.js');
let Vertices = require('./Vertices.js');
let PointIndices = require('./PointIndices.js');

module.exports = {
  PolygonMesh: PolygonMesh,
  ModelCoefficients: ModelCoefficients,
  Vertices: Vertices,
  PointIndices: PointIndices,
};
