
"use strict";

let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');
let JointStatistics = require('./JointStatistics.js');

module.exports = {
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  SwitchControllerActionResult: SwitchControllerActionResult,
  SwitchControllerResult: SwitchControllerResult,
  ActuatorStatistics: ActuatorStatistics,
  ControllerStatistics: ControllerStatistics,
  MechanismStatistics: MechanismStatistics,
  JointStatistics: JointStatistics,
};
