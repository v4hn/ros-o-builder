
"use strict";

let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetForceMode = require('./SetForceMode.js')
let SetPayload = require('./SetPayload.js')
let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')
let SetIO = require('./SetIO.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')

module.exports = {
  SetAnalogOutput: SetAnalogOutput,
  SetForceMode: SetForceMode,
  SetPayload: SetPayload,
  SetSpeedSliderFraction: SetSpeedSliderFraction,
  SetIO: SetIO,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
};
