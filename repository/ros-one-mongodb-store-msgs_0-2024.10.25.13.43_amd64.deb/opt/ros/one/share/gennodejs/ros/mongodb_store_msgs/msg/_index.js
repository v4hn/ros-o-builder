
"use strict";

let StringPairList = require('./StringPairList.js');
let StringPair = require('./StringPair.js');
let StringList = require('./StringList.js');
let Insert = require('./Insert.js');
let SerialisedMessage = require('./SerialisedMessage.js');
let MoveEntriesGoal = require('./MoveEntriesGoal.js');
let MoveEntriesFeedback = require('./MoveEntriesFeedback.js');
let MoveEntriesActionGoal = require('./MoveEntriesActionGoal.js');
let MoveEntriesActionFeedback = require('./MoveEntriesActionFeedback.js');
let MoveEntriesAction = require('./MoveEntriesAction.js');
let MoveEntriesActionResult = require('./MoveEntriesActionResult.js');
let MoveEntriesResult = require('./MoveEntriesResult.js');

module.exports = {
  StringPairList: StringPairList,
  StringPair: StringPair,
  StringList: StringList,
  Insert: Insert,
  SerialisedMessage: SerialisedMessage,
  MoveEntriesGoal: MoveEntriesGoal,
  MoveEntriesFeedback: MoveEntriesFeedback,
  MoveEntriesActionGoal: MoveEntriesActionGoal,
  MoveEntriesActionFeedback: MoveEntriesActionFeedback,
  MoveEntriesAction: MoveEntriesAction,
  MoveEntriesActionResult: MoveEntriesActionResult,
  MoveEntriesResult: MoveEntriesResult,
};
