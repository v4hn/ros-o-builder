
"use strict";

let MongoUpdateMsg = require('./MongoUpdateMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')
let MongoInsertMsg = require('./MongoInsertMsg.js')
let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')
let MongoDeleteMsg = require('./MongoDeleteMsg.js')

module.exports = {
  MongoUpdateMsg: MongoUpdateMsg,
  MongoQueryMsg: MongoQueryMsg,
  MongoInsertMsg: MongoInsertMsg,
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
  MongoDeleteMsg: MongoDeleteMsg,
};
