//  __  __             _        ______                          _____
// |  \/  |           (_)      |  ____|                        / ____|_     _
// | \  / | __ _  __ _ _  ___  | |__   _ __  _   _ _ __ ___   | |   _| |_ _| |_
// | |\/| |/ _` |/ _` | |/ __| |  __| | '_ \| | | | '_ ` _ \  | |  |_   _|_   _|
// | |  | | (_| | (_| | | (__  | |____| | | | |_| | | | | | | | |____|_|   |_|
// |_|  |_|\__,_|\__, |_|\___| |______|_| |_|\__,_|_| |_| |_|  \_____|
//                __/ | https://github.com/Neargye/magic_enum
//               |___/  version 0.9.8
//
// Licensed under the MIT License <http://opensource.org/licenses/MIT>.
// SPDX-License-Identifier: MIT
// Copyright (c) 2019 - 2026 Daniil Goncharov <neargye@gmail.com>.
// Copyright (c) 2022 - 2023 Bela Schaum <schaumb@gmail.com>.
//
// Permission is hereby  granted, free of charge, to any  person obtaining a copy
// of this software and associated  documentation files (the "Software"), to deal
// in the Software  without restriction, including without  limitation the rights
// to  use, copy,  modify, merge,  publish, distribute,  sublicense, and/or  sell
// copies  of  the Software,  and  to  permit persons  to  whom  the Software  is
// furnished to do so, subject to the following conditions:
//
// The above copyright notice and this permission notice shall be included in all
// copies or substantial portions of the Software.
//
// THE SOFTWARE  IS PROVIDED "AS  IS", WITHOUT WARRANTY  OF ANY KIND,  EXPRESS OR
// IMPLIED,  INCLUDING BUT  NOT  LIMITED TO  THE  WARRANTIES OF  MERCHANTABILITY,
// FITNESS FOR  A PARTICULAR PURPOSE AND  NONINFRINGEMENT. IN NO EVENT  SHALL THE
// AUTHORS  OR COPYRIGHT  HOLDERS  BE  LIABLE FOR  ANY  CLAIM,  DAMAGES OR  OTHER
// LIABILITY, WHETHER IN AN ACTION OF  CONTRACT, TORT OR OTHERWISE, ARISING FROM,
// OUT OF OR IN CONNECTION WITH THE SOFTWARE  OR THE USE OR OTHER DEALINGS IN THE
// SOFTWARE.

#ifndef NEARGYE_MAGIC_ENUM_CONTAINERS_HPP
#define NEARGYE_MAGIC_ENUM_CONTAINERS_HPP

#include "magic_enum.hpp"

#ifndef MAGIC_ENUM_USE_STD_MODULE
#  include <initializer_list>
#  include <ios>
#  include <iterator>
#endif

#if !defined(MAGIC_ENUM_USE_STD_MODULE) && __has_include(<bit>) && (__cplusplus >= 202002L || (defined(_MSVC_LANG) && _MSVC_LANG >= 202002L))
#  include <bit>
#endif

#if (!defined(__cpp_lib_bitops) || (__cpp_lib_bitops < 201907L)) && defined(_MSC_VER) && !defined(__clang__)
#  include <intrin.h>
#  pragma intrinsic(_BitScanForward)
#  pragma intrinsic(_BitScanReverse)
#  ifdef _WIN64
#    pragma intrinsic(_BitScanForward64)
#    pragma intrinsic(_BitScanReverse64)
#  endif
#endif

#if !defined(MAGIC_ENUM_NO_EXCEPTION) && (defined(__cpp_exceptions) || defined(__EXCEPTIONS) || defined(_CPPUNWIND))
#  ifndef MAGIC_ENUM_USE_STD_MODULE
#    include <stdexcept>
#  endif
#  define MAGIC_ENUM_CONTAINERS_THROW(...) throw (__VA_ARGS__)
#else
#  ifndef MAGIC_ENUM_USE_STD_MODULE
#    include <cstdlib>
#  endif
#  define MAGIC_ENUM_CONTAINERS_THROW(...) std::abort()
#endif

namespace magic_enum::containers {

namespace detail {

template <typename T, typename = void>
inline constexpr bool is_transparent_v{};

template <typename T>
inline constexpr bool is_transparent_v<T, std::void_t<typename T::is_transparent>>{true};

template <typename Eq = std::equal_to<>, typename T1, typename T2>
constexpr bool equal(T1&& t1, T2&& t2, Eq&& eq = {}) {
  auto first1 = t1.begin();
  auto last1 = t1.end();
  auto first2 = t2.begin();
  auto last2 = t2.end();

  for (; first1 != last1; ++first1, ++first2) {
    if (first2 == last2 || !eq(*first1, *first2)) {
      return false;
    }
  }
  return first2 == last2;
}

template <typename Cmp = std::less<>, typename T1, typename T2>
constexpr bool lexicographical_compare(T1&& t1, T2&& t2, Cmp&& cmp = {}) {
  auto first1 = t1.begin();
  auto last1 = t1.end();
  auto first2 = t2.begin();
  auto last2 = t2.end();

  // copied from std::lexicographical_compare
  for (; (first1 != last1) && (first2 != last2); ++first1, (void)++first2) {
    if (cmp(*first1, *first2)) {
      return true;
    }
    if (cmp(*first2, *first1)) {
      return false;
    }
  }
  return (first1 == last1) && (first2 != last2);
}

template <typename T>
constexpr std::size_t popcount(T x) noexcept {
#if defined(__cpp_lib_bitops) && __cpp_lib_bitops >= 201907L
  return static_cast<std::size_t>(std::popcount(x));
#else
  std::size_t c = 0;
  while (x > 0) {
    x &= x - 1;
    ++c;
  }
  return c;
#endif
}

namespace impl {

template <typename Cmp = std::less<>, typename ForwardIt, typename E>
constexpr ForwardIt lower_bound(ForwardIt first, ForwardIt last, E&& e, Cmp&& comp = {}) {
  auto count = std::distance(first, last);
  while (count > 0) {
    auto it = first;
    auto step = count / 2;
    std::advance(it, step);
    if (comp(*it, e)) {
      first = ++it;
      count -= step + 1;
    } else {
      count = step;
    }
  }
  return first;
}

} // namespace impl

template <typename Cmp = std::less<>, typename BidirIt, typename E>
constexpr BidirIt upper_bound(BidirIt begin, BidirIt end, E&& e, Cmp&& comp = {}) {
  return impl::lower_bound(std::make_reverse_iterator(end), std::make_reverse_iterator(begin), e, [&comp](auto&& lhs, auto&& rhs) { return comp(rhs, lhs); }).base();
}

template <typename Cmp = std::less<>, typename BidirIt, typename E>
constexpr auto equal_range(BidirIt begin, BidirIt end, E&& e, Cmp&& comp = {}) {
  const auto first = impl::lower_bound(begin, end, e, comp);
  return std::pair{first, detail::upper_bound(first, end, e, comp)};
}

template <typename E = void, typename Cmp = std::less<E>, typename = void>
class indexing {
  [[nodiscard]] static constexpr auto get_indices() noexcept {
    // reverse result index mapping
    std::array<std::size_t, enum_count<E>()> rev_res{};

    // std::iota
    for (std::size_t i = 0; i < enum_count<E>(); ++i) {
      rev_res[i] = i;
    }

    constexpr auto orig_values = enum_values<E>();
    constexpr Cmp cmp{};

    // ~std::sort
    for (std::size_t i = 0; i < enum_count<E>(); ++i) {
      for (std::size_t j = i + 1; j < enum_count<E>(); ++j) {
        if (cmp(orig_values[rev_res[j]], orig_values[rev_res[i]])) {
          auto tmp = rev_res[i];
          rev_res[i] = rev_res[j];
          rev_res[j] = tmp;
        }
      }
    }

    std::array<E, enum_count<E>()> sorted_values{};
    // reverse the sorted indices
    std::array<std::size_t, enum_count<E>()> res{};
    for (std::size_t i = 0; i < enum_count<E>(); ++i) {
      res[rev_res[i]] = i;
      sorted_values[i] = orig_values[rev_res[i]];
    }

    return std::pair{sorted_values, res};
  }

  static constexpr auto indices = get_indices();

 public:
  [[nodiscard]] static constexpr const E* begin() noexcept { return indices.first.data(); }

  [[nodiscard]] static constexpr const E* end() noexcept { return indices.first.data() + indices.first.size(); }

  [[nodiscard]] static constexpr const E* it(std::size_t i) noexcept { return indices.first.data() + i; }

  [[nodiscard]] static constexpr optional<std::size_t> at(E val) noexcept {
    if (auto i = enum_index(val)) {
      return indices.second[*i];
    }
    return {};
  }
};

template <typename E, typename Cmp>
class indexing<E, Cmp, std::enable_if_t<std::is_enum_v<std::decay_t<E>> && (std::is_same_v<Cmp, std::less<E>> || std::is_same_v<Cmp, std::less<>>)>> {
  static constexpr auto& values = enum_values<E>();

 public:
  [[nodiscard]] static constexpr const E* begin() noexcept { return values.data(); }

  [[nodiscard]] static constexpr const E* end() noexcept { return values.data() + values.size(); }

  [[nodiscard]] static constexpr const E* it(std::size_t i) noexcept { return values.data() + i; }

  [[nodiscard]] static constexpr optional<std::size_t> at(E val) noexcept { return enum_index(val); }
};

template <typename Cmp>
struct indexing<void, Cmp, void> {
  using is_transparent = std::true_type;

  template <typename E>
  [[nodiscard]] static constexpr optional<std::size_t> at(E val) noexcept {
    return indexing<E, Cmp>::at(val);
  }
};

template <typename E = void, typename Cmp = std::less<>, typename = void>
struct name_sort_impl {
  [[nodiscard]] constexpr bool operator()(E e1, E e2) const { return Cmp{}(enum_name(e1), enum_name(e2)); }
};

template <typename Cmp>
struct name_sort_impl<void, Cmp> {
  using is_transparent = std::true_type;

  template <typename C = Cmp, typename = void>
  struct FullCmp : C {};

  template <typename C>
  struct FullCmp<C, std::enable_if_t<!std::is_invocable_v<C, string_view, string_view> && std::is_invocable_v<C, char_type, char_type>>> {
    [[nodiscard]] constexpr bool operator()(string_view s1, string_view s2) const { return lexicographical_compare<C>(s1, s2); }
  };

  template <typename T>
  using cmp_arg_t = std::conditional_t<std::is_enum_v<std::decay_t<T>> || std::is_constructible_v<string_view, T>, string_view, T>;

  template <typename T>
  [[nodiscard]] static constexpr decltype(auto) cmp_arg(T&& value) {
    using D = std::decay_t<T>;
    if constexpr (std::is_enum_v<D>) {
      return enum_name(value);
    } else if constexpr (std::is_constructible_v<string_view, T>) {
      return string_view{std::forward<T>(value)};
    } else {
      return std::forward<T>(value);
    }
  }

  template <typename E1, typename E2>
  [[nodiscard]] constexpr std::enable_if_t<
      // at least one of need to be an enum type
      (std::is_enum_v<std::decay_t<E1>> || std::is_enum_v<std::decay_t<E2>>) &&
      // if both is enum, only accept if the same enum
      (!std::is_enum_v<std::decay_t<E1>> || !std::is_enum_v<std::decay_t<E2>> || std::is_same_v<std::decay_t<E1>, std::decay_t<E2>>) &&
      // is invocable with comparator
      (std::is_invocable_r_v<bool, FullCmp<>, cmp_arg_t<E1>, cmp_arg_t<E2>>),
      bool>
  operator()(E1&& e1, E2&& e2) const {
    constexpr FullCmp<> cmp{};
    return cmp(cmp_arg(std::forward<E1>(e1)), cmp_arg(std::forward<E2>(e2)));
  }
};

struct raw_access_t {};

template <typename Parent, typename Iterator, typename Getter, typename Predicate>
struct FilteredIterator {
  Parent parent;
  Iterator first;
  Iterator last;
  Iterator current;
  Getter getter;
  Predicate predicate;

  using iterator_category = std::bidirectional_iterator_tag;
  using reference = std::invoke_result_t<Getter, Parent, Iterator>;
  using value_type = std::remove_cv_t<std::remove_reference_t<reference>>;
  using difference_type = std::ptrdiff_t;
  using pointer = std::add_pointer_t<std::remove_reference_t<reference>>;

  constexpr FilteredIterator() noexcept = default;
  constexpr FilteredIterator(const FilteredIterator&) = default;
  constexpr FilteredIterator& operator=(const FilteredIterator&) = default;
  constexpr FilteredIterator(FilteredIterator&&) noexcept = default;
  constexpr FilteredIterator& operator=(FilteredIterator&&) noexcept = default;

  template <typename OtherParent, typename OtherIterator, typename = std::enable_if_t<std::is_convertible_v<OtherParent, Parent> && std::is_convertible_v<OtherIterator, Iterator>>*>
  constexpr explicit FilteredIterator(const FilteredIterator<OtherParent, OtherIterator, Getter, Predicate>& other)
      : parent(other.parent), first(other.first), last(other.last), current(other.current), getter(other.getter), predicate(other.predicate) {}

  constexpr FilteredIterator(Parent p, Iterator begin, Iterator end, Iterator curr, Getter get = {}, Predicate pred = {})
      : parent(p), first(std::move(begin)), last(std::move(end)), current(std::move(curr)), getter{std::move(get)}, predicate{std::move(pred)} {
    if (current == first && !predicate(parent, current)) {
      ++*this;
    }
  }

  [[nodiscard]] constexpr reference operator*() const { return getter(parent, current); }

  [[nodiscard]] constexpr pointer operator->() const { return std::addressof(**this); }

  constexpr FilteredIterator& operator++() {
    do {
      ++current;
    } while (current != last && !predicate(parent, current));
    return *this;
  }

  [[nodiscard]] constexpr FilteredIterator operator++(int) {
    FilteredIterator cp = *this;
    ++*this;
    return cp;
  }

  constexpr FilteredIterator& operator--() {
    do {
      --current;
    } while (current != first && !predicate(parent, current));
    return *this;
  }

  [[nodiscard]] constexpr FilteredIterator operator--(int) {
    FilteredIterator cp = *this;
    --*this;
    return cp;
  }

  [[nodiscard]] friend constexpr bool operator==(const FilteredIterator& lhs, const FilteredIterator& rhs) { return lhs.current == rhs.current; }

  [[nodiscard]] friend constexpr bool operator!=(const FilteredIterator& lhs, const FilteredIterator& rhs) { return lhs.current != rhs.current; }
};

template <typename T>
constexpr int countr_zero(T x) noexcept {
#if defined(__cpp_lib_bitops) && __cpp_lib_bitops >= 201907L
  return std::countr_zero(x);
#elif defined(_MSC_VER) && !defined(__clang__)
  unsigned long index;
  if constexpr (sizeof(T) <= sizeof(unsigned long)) {
    return _BitScanForward(&index, static_cast<unsigned long>(x)) ? static_cast<int>(index) : static_cast<int>(sizeof(T) * 8);
  } else {
#  ifdef _WIN64
    return _BitScanForward64(&index, static_cast<unsigned __int64>(x)) ? static_cast<int>(index) : static_cast<int>(sizeof(T) * 8);
#  else
    if (_BitScanForward(&index, static_cast<unsigned long>(x))) { return static_cast<int>(index); }
    return _BitScanForward(&index, static_cast<unsigned long>(x >> 32)) ? static_cast<int>(index) + 32 : static_cast<int>(sizeof(T) * 8);
#  endif
  }
#else
  if constexpr (sizeof(T) <= sizeof(unsigned int)) {
    return x ? __builtin_ctz(static_cast<unsigned int>(x)) : static_cast<int>(sizeof(T) * 8);
  } else if constexpr (sizeof(T) <= sizeof(unsigned long)) {
    return x ? __builtin_ctzl(static_cast<unsigned long>(x)) : static_cast<int>(sizeof(T) * 8);
  } else {
    return x ? __builtin_ctzll(static_cast<unsigned long long>(x)) : static_cast<int>(sizeof(T) * 8);
  }
#endif
}

template <typename T>
constexpr int countl_zero(T x) noexcept {
#if defined(__cpp_lib_bitops) && __cpp_lib_bitops >= 201907L
  return std::countl_zero(x);
#elif defined(_MSC_VER) && !defined(__clang__)
  unsigned long index;
  if constexpr (sizeof(T) <= sizeof(unsigned long)) {
    return _BitScanReverse(&index, static_cast<unsigned long>(x)) ? static_cast<int>(sizeof(T) * 8) - static_cast<int>(index) - 1 : static_cast<int>(sizeof(T) * 8);
  } else {
#  ifdef _WIN64
    return _BitScanReverse64(&index, static_cast<unsigned __int64>(x)) ? static_cast<int>(sizeof(T) * 8) - static_cast<int>(index) - 1 : static_cast<int>(sizeof(T) * 8);
#  else
    if (_BitScanReverse(&index, static_cast<unsigned long>(x >> 32))) { return static_cast<int>(sizeof(T) * 8) - static_cast<int>(index) - 33; }
    return _BitScanReverse(&index, static_cast<unsigned long>(x)) ? static_cast<int>(sizeof(T) * 8) - static_cast<int>(index) - 1 : static_cast<int>(sizeof(T) * 8);
#  endif
  }
#else
  // __builtin_clz* counts leading zeros in the promoted type width, not in T.
  // We must subtract the extra bits introduced by zero-extension.
  if constexpr (sizeof(T) <= sizeof(unsigned int)) {
    return x ? __builtin_clz(static_cast<unsigned int>(x)) - static_cast<int>((sizeof(unsigned int) - sizeof(T)) * 8) : static_cast<int>(sizeof(T) * 8);
  } else if constexpr (sizeof(T) <= sizeof(unsigned long)) {
    return x ? __builtin_clzl(static_cast<unsigned long>(x)) - static_cast<int>((sizeof(unsigned long) - sizeof(T)) * 8) : static_cast<int>(sizeof(T) * 8);
  } else {
    return x ? __builtin_clzll(static_cast<unsigned long long>(x)) - static_cast<int>((sizeof(unsigned long long) - sizeof(T)) * 8) : static_cast<int>(sizeof(T) * 8);
  }
#endif
}

template <typename T>
constexpr int bit_width(T x) noexcept {
#if defined(__cpp_lib_int_pow2) && __cpp_lib_int_pow2 >= 202002L
  return std::bit_width(x);
#else
  return std::numeric_limits<T>::digits - countl_zero(x);
#endif
}

template <typename E, typename Index>
constexpr bool valid_indexing() noexcept {
  constexpr std::size_t count = enum_count<E>();
  if constexpr (count == 0) {
    return false;
  } else {
    std::array<bool, count> used_indices{};
    for (const auto value : enum_values<E>()) {
      const auto index = Index::at(value);
      if (!index || *index >= count || used_indices[*index]) {
        return false;
      }
      used_indices[*index] = true;
    }
    return true;
  }
}

} // namespace detail

template <typename E = void>
using name_less = detail::name_sort_impl<E>;

template <typename E = void>
using name_greater = detail::name_sort_impl<E, std::greater<>>;

using name_less_case_insensitive = detail::name_sort_impl<void, magic_enum::detail::case_insensitive<std::less<>>>;

using name_greater_case_insensitive = detail::name_sort_impl<void, magic_enum::detail::case_insensitive<std::greater<>>>;

template <typename E = void>
using default_indexing = detail::indexing<E>;

template <typename Cmp = std::less<>>
using comparator_indexing = detail::indexing<void, Cmp>;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                          ARRAY                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <typename E, typename V, typename Index = default_indexing<E>>
struct array {
  static_assert(std::is_enum_v<E>, "magic_enum::containers::array requires enum type.");
  static_assert(detail::valid_indexing<E, Index>(), "magic_enum::containers::array requires non-empty reflected enum and valid indexing.");

  using index_type = Index;
  using container_type = std::array<V, enum_count<E>()>;

  using value_type = typename container_type::value_type;
  using size_type = typename container_type::size_type;
  using difference_type = typename container_type::difference_type;
  using reference = typename container_type::reference;
  using const_reference = typename container_type::const_reference;
  using pointer = typename container_type::pointer;
  using const_pointer = typename container_type::const_pointer;
  using iterator = typename container_type::iterator;
  using const_iterator = typename container_type::const_iterator;
  using reverse_iterator = typename container_type::reverse_iterator;
  using const_reverse_iterator = typename container_type::const_reverse_iterator;

  constexpr reference at(E pos) {
    if (auto index = index_type::at(pos); index && *index < a.size()) {
      return a[*index];
    }
    MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::array::at: Unrecognized position"));
  }

  constexpr const_reference at(E pos) const {
    if (auto index = index_type::at(pos); index && *index < a.size()) {
      return a[*index];
    }
    MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::array::at: Unrecognized position"));
  }

  [[nodiscard]] constexpr reference operator[](E pos) {
    auto i = index_type::at(pos);
    return MAGIC_ENUM_ASSERT(i && *i < a.size()), a[*i];
  }

  [[nodiscard]] constexpr const_reference operator[](E pos) const {
    auto i = index_type::at(pos);
    return MAGIC_ENUM_ASSERT(i && *i < a.size()), a[*i];
  }

  [[nodiscard]] constexpr reference front() noexcept { return a.front(); }

  [[nodiscard]] constexpr const_reference front() const noexcept { return a.front(); }

  [[nodiscard]] constexpr reference back() noexcept { return a.back(); }

  [[nodiscard]] constexpr const_reference back() const noexcept { return a.back(); }

  [[nodiscard]] constexpr pointer data() noexcept { return a.data(); }

  [[nodiscard]] constexpr const_pointer data() const noexcept { return a.data(); }

  [[nodiscard]] constexpr iterator begin() noexcept { return a.begin(); }

  [[nodiscard]] constexpr const_iterator begin() const noexcept { return a.begin(); }

  [[nodiscard]] constexpr const_iterator cbegin() const noexcept { return a.cbegin(); }

  [[nodiscard]] constexpr iterator end() noexcept { return a.end(); }

  [[nodiscard]] constexpr const_iterator end() const noexcept { return a.end(); }

  [[nodiscard]] constexpr const_iterator cend() const noexcept { return a.cend(); }

  [[nodiscard]] constexpr reverse_iterator rbegin() noexcept { return a.rbegin(); }

  [[nodiscard]] constexpr const_reverse_iterator rbegin() const noexcept { return a.rbegin(); }

  [[nodiscard]] constexpr const_reverse_iterator crbegin() const noexcept { return a.crbegin(); }

  [[nodiscard]] constexpr reverse_iterator rend() noexcept { return a.rend(); }

  [[nodiscard]] constexpr const_reverse_iterator rend() const noexcept { return a.rend(); }

  [[nodiscard]] constexpr const_reverse_iterator crend() const noexcept { return a.crend(); }

  [[nodiscard]] constexpr bool empty() const noexcept { return a.empty(); }

  [[nodiscard]] constexpr size_type size() const noexcept { return a.size(); }

  [[nodiscard]] constexpr size_type max_size() const noexcept { return a.max_size(); }

  constexpr void fill(const V& value) {
    for (auto& v : a) {
      v = value;
    }
  }

  constexpr void swap(array& other) noexcept(std::is_nothrow_move_constructible_v<V> && std::is_nothrow_move_assignable_v<V>) {
    for (std::size_t i = 0; i < a.size(); ++i) {
      auto v = std::move(other.a[i]);
      other.a[i] = std::move(a[i]);
      a[i] = std::move(v);
    }
  }

  [[nodiscard]] friend constexpr bool operator==(const array& a1, const array& a2) { return detail::equal(a1, a2); }

  [[nodiscard]] friend constexpr bool operator!=(const array& a1, const array& a2) { return !detail::equal(a1, a2); }

  [[nodiscard]] friend constexpr bool operator<(const array& a1, const array& a2) { return detail::lexicographical_compare(a1, a2); }

  [[nodiscard]] friend constexpr bool operator<=(const array& a1, const array& a2) { return !detail::lexicographical_compare(a2, a1); }

  [[nodiscard]] friend constexpr bool operator>(const array& a1, const array& a2) { return detail::lexicographical_compare(a2, a1); }

  [[nodiscard]] friend constexpr bool operator>=(const array& a1, const array& a2) { return !detail::lexicographical_compare(a1, a2); }

  container_type a;
};

namespace detail {

template <typename E, typename T, std::size_t N, std::size_t... J>
constexpr array<E, std::remove_cv_t<T>> to_array_impl(T(&a)[N], std::index_sequence<J...>) {
  return {{a[J]...}};
}

template <typename E, typename T, std::size_t N, std::size_t... J>
constexpr array<E, std::remove_cv_t<T>> to_array_impl(T(&&a)[N], std::index_sequence<J...>) {
  return {{std::move(a[J])...}};
}

} // namespace detail

template <typename E, typename T, std::size_t N>
constexpr std::enable_if_t<(enum_count<E>() == N), array<E, std::remove_cv_t<T>>> to_array(T(&a)[N]) {
  return detail::to_array_impl<E>(a, std::make_index_sequence<N>{});
}

template <typename E, typename T, std::size_t N>
constexpr std::enable_if_t<(enum_count<E>() == N), array<E, std::remove_cv_t<T>>> to_array(T(&&a)[N]) {
  return detail::to_array_impl<E>(std::move(a), std::make_index_sequence<N>{});
}

template <typename E, typename... Ts>
constexpr std::enable_if_t<(enum_count<E>() == sizeof...(Ts)), array<E, std::remove_cv_t<std::common_type_t<Ts...>>>> make_array(Ts&&... ts) {
  return {{std::forward<Ts>(ts)...}};
}

inline constexpr detail::raw_access_t raw_access{};

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                         BITSET                                                            //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <typename E, typename Index = default_indexing<E>>
class bitset {
  static_assert(std::is_enum_v<E>, "magic_enum::containers::bitset requires enum type.");
  static_assert(detail::valid_indexing<E, Index>(), "magic_enum::containers::bitset requires non-empty reflected enum and valid indexing.");

  using base_type = std::conditional_t<enum_count<E>() <= 8,  std::uint_least8_t,
                    std::conditional_t<enum_count<E>() <= 16, std::uint_least16_t,
                    std::conditional_t<enum_count<E>() <= 32, std::uint_least32_t,
                                                              std::uint_least64_t>>>;

  static constexpr std::size_t bits_per_base = sizeof(base_type) * 8;
  static constexpr std::size_t base_type_count = (enum_count<E>() > 0 ? (enum_count<E>() - 1) / bits_per_base + 1 : 0);
  static constexpr std::size_t not_interested = base_type_count * bits_per_base - enum_count<E>();
  static constexpr base_type last_value_max = [] {
    if constexpr (not_interested == 0) {
      return (std::numeric_limits<base_type>::max)();
    } else {
      return static_cast<base_type>((base_type{1} << (bits_per_base - not_interested)) - 1);
    }
  }();

  [[nodiscard]] static constexpr base_type bit_mask(std::size_t index) noexcept {
    return static_cast<base_type>(base_type{1} << (index % bits_per_base));
  }

  [[nodiscard]] static constexpr base_type least_significant_bit(base_type value) noexcept {
    MAGIC_ENUM_ASSERT(value != 0);
    return bit_mask(static_cast<std::size_t>(detail::countr_zero(value)));
  }

  template <typename parent_t = bitset*>
  class reference_impl {
    friend class bitset;

    parent_t parent;
    std::size_t num_index;
    base_type bit_index;

    constexpr reference_impl(parent_t p, std::size_t i) noexcept : reference_impl(p, i / bits_per_base, bit_mask(i)) {}

    constexpr reference_impl(parent_t p, std::size_t num, base_type bit) noexcept : parent(p), num_index(num), bit_index(bit) {}

   public:
    constexpr reference_impl& operator=(bool v) noexcept {
      if (v) {
        parent->a[num_index] |= bit_index;
      } else {
        parent->a[num_index] &= ~bit_index;
      }
      return *this;
    }

    constexpr reference_impl& operator=(const reference_impl& v) noexcept {
      if (this == &v) {
        return *this;
      }
      *this = static_cast<bool>(v);
      return *this;
    }

    [[nodiscard]] constexpr operator bool() const noexcept { return (parent->a[num_index] & bit_index) > 0; }

    [[nodiscard]] constexpr bool operator~() const noexcept { return !static_cast<bool>(*this); }

    constexpr reference_impl& flip() noexcept {
      *this = ~*this;
      return *this;
    }
  };

  template <typename T>
  [[nodiscard]] constexpr T to_(detail::raw_access_t) const {
    if constexpr (std::numeric_limits<T>::digits < std::numeric_limits<base_type>::digits) {
      if (a[0] > static_cast<base_type>((std::numeric_limits<T>::max)())) {
        MAGIC_ENUM_CONTAINERS_THROW(std::overflow_error("magic_enum::containers::bitset::to: Cannot represent enum in this type"));
      }
    }
    for (std::size_t i = 1; i < base_type_count; ++i) {
      if (a[i] != 0) {
        MAGIC_ENUM_CONTAINERS_THROW(std::overflow_error("magic_enum::containers::bitset::to: Cannot represent enum in this type"));
      }
    }
    return static_cast<T>(a[0]);
  }

  template <typename parent_t = bitset*>
  class iterator_impl {
    friend class bitset;

    parent_t parent = nullptr;
    std::size_t num_index = 0;
    base_type bit_index = 0;
   public:
    using iterator_category = std::bidirectional_iterator_tag;
    using value_type = E;
    using difference_type = std::ptrdiff_t;
    using pointer = const E*;
    using reference = const E&;

    constexpr iterator_impl() noexcept = default;
    constexpr iterator_impl(const iterator_impl&) noexcept = default;
    constexpr iterator_impl& operator=(const iterator_impl&) noexcept = default;
    constexpr iterator_impl(iterator_impl&&) noexcept = default;
    constexpr iterator_impl& operator=(iterator_impl&&) noexcept = default;

    template <typename OtherParent, typename = std::enable_if_t<std::is_convertible_v<OtherParent, parent_t>>>
    constexpr iterator_impl(const iterator_impl<OtherParent>& other) noexcept
        : parent(other.parent), num_index(other.num_index), bit_index(other.bit_index) {}

   private:
    template <typename OtherParent>
    friend class iterator_impl;
    constexpr iterator_impl(parent_t p, std::size_t i) noexcept : iterator_impl(p, i / bits_per_base, bit_mask(i)) {}

    constexpr iterator_impl(parent_t p, std::size_t num, base_type bit) noexcept : parent(p), num_index(num), bit_index(bit) {}

    [[nodiscard]] static constexpr iterator_impl begin(parent_t p) noexcept {
      for (std::size_t num_index = 0; num_index < base_type_count; ++num_index) {
        if (p->a[num_index] > 0) {
          const auto bit_index = least_significant_bit(p->a[num_index]);
          return iterator_impl(p, num_index, bit_index);
        }
      }
      return end(p);
    }
    [[nodiscard]] static constexpr iterator_impl end(parent_t p) noexcept {
      return iterator_impl(p, enum_count<E>());
    }

   public:
    [[nodiscard]] constexpr reference operator*() const noexcept { return *Index::it(num_index * bits_per_base + static_cast<std::size_t>(detail::countr_zero(bit_index))); }

    [[nodiscard]] constexpr pointer operator->() const noexcept { return std::addressof(**this); }

    constexpr iterator_impl& operator++() noexcept {
      const auto lower_bits = static_cast<base_type>((bit_index << 1) - 1);
      auto remaining_bits = static_cast<base_type>(parent->a[num_index] & static_cast<base_type>(~lower_bits));
      while (remaining_bits == 0 && ++num_index < base_type_count) {
        remaining_bits = parent->a[num_index];
      }
      if (num_index >= base_type_count) {
        return *this = end(parent);
      }
      bit_index = least_significant_bit(remaining_bits);
      return *this;
    }

    [[nodiscard]] constexpr iterator_impl operator++(int) noexcept {
      iterator_impl cp = *this;
      ++*this;
      return cp;
    }

    constexpr iterator_impl& operator--() noexcept {
      base_type search_mask;
      if (num_index >= base_type_count) {
        num_index = base_type_count - 1;
        search_mask = last_value_max;
      } else if (num_index == base_type_count - 1 && bit_index > last_value_max) {
        search_mask = last_value_max;
      } else {
        search_mask = static_cast<base_type>(bit_index - 1);
      }

      auto remaining_bits = static_cast<base_type>(parent->a[num_index] & search_mask);
      while (remaining_bits == 0 && num_index != 0) {
        remaining_bits = parent->a[--num_index];
      }
      if (remaining_bits == 0) {
        num_index = (std::numeric_limits<std::size_t>::max)();
        bit_index = static_cast<base_type>(base_type{1} << (bits_per_base - 1));
        return *this;
      }
      bit_index = static_cast<base_type>(base_type{1} << (detail::bit_width(remaining_bits) - 1));
      return *this;
    }

    [[nodiscard]] constexpr iterator_impl operator--(int) noexcept {
      iterator_impl cp = *this;
      --*this;
      return cp;
    }

    [[nodiscard]] friend constexpr bool operator==(const iterator_impl& lhs, const iterator_impl& rhs) { return lhs.parent == rhs.parent && lhs.num_index == rhs.num_index && lhs.bit_index == rhs.bit_index; }

    [[nodiscard]] friend constexpr bool operator!=(const iterator_impl& lhs, const iterator_impl& rhs) { return !(lhs == rhs); }
  };

 public:
  using index_type = Index;
  using container_type = std::array<base_type, base_type_count>;
  using reference = reference_impl<>;
  using const_reference = reference_impl<const bitset*>;
  using iterator = iterator_impl<>;
  using const_iterator = iterator_impl<const bitset*>;

  constexpr explicit bitset(detail::raw_access_t = raw_access) noexcept : a{{}} {}

  constexpr explicit bitset(detail::raw_access_t, unsigned long long val) : a{{}} {
    if constexpr (enum_count<E>() < std::numeric_limits<unsigned long long>::digits) {
      if ((val >> enum_count<E>()) != 0) {
        MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::bitset::constructor: Upper bit set in raw number"));
      }
    }
    a[0] = static_cast<base_type>(val);
  }

  constexpr explicit bitset(detail::raw_access_t, string_view sv, string_view::size_type pos = 0, string_view::size_type n = string_view::npos, char_type zero = char_type{'0'}, char_type one = char_type{'1'})
      : a{{}} {
    std::size_t i = 0;
    for (auto c : sv.substr(pos, n)) {
      if (c == one) {
        if (i >= enum_count<E>()) {
          MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::bitset::constructor: Upper bit set in raw string"));
        }
        reference{this, i} = true;
      } else if (c != zero) {
        MAGIC_ENUM_CONTAINERS_THROW(std::invalid_argument("magic_enum::containers::bitset::constructor: Unrecognized character in raw string"));
      }
      ++i;
    }
  }

  constexpr explicit bitset(detail::raw_access_t, const char_type* str, std::size_t n = ~std::size_t{0}, char_type zero = char_type{'0'}, char_type one = char_type{'1'})
      : bitset(detail::raw_access_t{}, n == string_view::npos ? string_view{str} : string_view{str, n}, 0, n, zero, one) {}

  constexpr bitset(std::initializer_list<E> starters) : a{{}} {
    if constexpr (magic_enum::detail::subtype_v<E> == magic_enum::detail::enum_subtype::flags) {
      for (auto& f : starters) {
        *this |= bitset(f);
      }
    } else {
      for (auto& f : starters) {
        set(f);
      }
    }
  }
  template <typename V, std::enable_if_t<std::is_same_v<V, E> && magic_enum::detail::subtype_v<V> == magic_enum::detail::enum_subtype::flags, int> = 0>
  constexpr explicit bitset(V starter) : a{{}} {
    auto u = enum_underlying(starter);
    for (E v : enum_values<E>()) {
      if (u == 0) {
        break;
      }
      if (auto ul = enum_underlying(v); (ul & u) != 0) {
        u &= ~ul;
        (*this)[v] = true;
      }
    }
    if (u != 0) {
      MAGIC_ENUM_CONTAINERS_THROW(std::invalid_argument("magic_enum::containers::bitset::constructor: Unrecognized enum value in flag"));
    }
  }

  template <typename Cmp = std::equal_to<>>
  constexpr explicit bitset(string_view sv, Cmp&& cmp = {}, char_type sep = char_type{'|'}) : a{{}} {
    for (std::size_t to = 0; (to = magic_enum::detail::find(sv, sep)) != string_view::npos; sv.remove_prefix(to + 1)) {
      if (auto v = enum_cast<E, magic_enum::detail::subtype_v<E>, Cmp&>(sv.substr(0, to), cmp)) {
        set(*v);
      } else {
        MAGIC_ENUM_CONTAINERS_THROW(std::invalid_argument("magic_enum::containers::bitset::constructor: Unrecognized enum value in string"));
      }
    }
    if (!sv.empty()) {
      if (auto v = enum_cast<E, magic_enum::detail::subtype_v<E>, Cmp&>(sv, cmp)) {
        set(*v);
      } else {
        MAGIC_ENUM_CONTAINERS_THROW(std::invalid_argument("magic_enum::containers::bitset::constructor: Unrecognized enum value in string"));
      }
    }
  }

  [[nodiscard]] friend constexpr bool operator==(const bitset& lhs, const bitset& rhs) noexcept { return detail::equal(lhs.a, rhs.a); }

  [[nodiscard]] friend constexpr bool operator!=(const bitset& lhs, const bitset& rhs) noexcept { return !detail::equal(lhs.a, rhs.a); }

  [[nodiscard]] constexpr bool operator[](E pos) const {
    auto i = index_type::at(pos);
    return MAGIC_ENUM_ASSERT(i && *i < size()), static_cast<bool>(const_reference(this, *i));
  }

  [[nodiscard]] constexpr reference operator[](E pos) {
    auto i = index_type::at(pos);
    return MAGIC_ENUM_ASSERT(i && *i < size()), reference{this, *i};
  }

  [[nodiscard]] constexpr iterator begin() noexcept { return iterator::begin(this); }

  [[nodiscard]] constexpr const_iterator begin() const noexcept { return const_iterator::begin(this); }

  [[nodiscard]] constexpr const_iterator cbegin() const noexcept { return const_iterator::begin(this); }

  [[nodiscard]] constexpr iterator end() noexcept { return iterator::end(this); }

  [[nodiscard]] constexpr const_iterator end() const noexcept { return const_iterator::end(this); }

  [[nodiscard]] constexpr const_iterator cend() const noexcept { return const_iterator::end(this); }

  [[nodiscard]] constexpr const_iterator find(E pos) const noexcept {
    if (auto i = index_type::at(pos); i && *i < size() && static_cast<bool>(const_reference(this, *i))) {
      return const_iterator(this, *i);
    }
    return end();
  }

  [[nodiscard]] constexpr iterator find(E pos) noexcept {
    if (auto i = index_type::at(pos); i && *i < size() && static_cast<bool>(const_reference(this, *i))) {
      return iterator(this, *i);
    }
    return end();
  }

  constexpr bool test(E pos) const {
    if (auto i = index_type::at(pos); i && *i < size()) {
      return static_cast<bool>(const_reference(this, *i));
    }
    MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::bitset::test: Unrecognized position"));
  }

  [[nodiscard]] constexpr bool all() const noexcept {
    for (std::size_t i = 0; i + 1 < base_type_count; ++i) {
      if (a[i] != (std::numeric_limits<base_type>::max)()) {
        return false;
      }
    }
    return a[base_type_count - 1] == last_value_max;
  }

  [[nodiscard]] constexpr bool any() const noexcept {
    for (auto& v : a) {
      if (v > 0) {
        return true;
      }
    }
    return false;
  }

  [[nodiscard]] constexpr bool none() const noexcept { return !any(); }

  [[nodiscard]] constexpr std::size_t count() const noexcept {
    std::size_t c = 0;
    for (auto& v : a) {
      c += detail::popcount(v);
    }
    return c;
  }

  [[nodiscard]] constexpr std::size_t size() const noexcept { return enum_count<E>(); }

  [[nodiscard]] constexpr std::size_t max_size() const noexcept { return enum_count<E>(); }

  constexpr bitset& operator&=(const bitset& other) noexcept {
    for (std::size_t i = 0; i < base_type_count; ++i) {
      a[i] &= other.a[i];
    }
    return *this;
  }

  constexpr bitset& operator|=(const bitset& other) noexcept {
    for (std::size_t i = 0; i < base_type_count; ++i) {
      a[i] |= other.a[i];
    }
    return *this;
  }

  constexpr bitset& operator^=(const bitset& other) noexcept {
    for (std::size_t i = 0; i < base_type_count; ++i) {
      a[i] ^= other.a[i];
    }
    return *this;
  }

  [[nodiscard]] constexpr bitset operator~() const noexcept {
    bitset res = *this;
    res.flip();
    return res;
  }

  constexpr bitset& set() noexcept {
    for (std::size_t i = 0; i + 1 < base_type_count; ++i) {
      a[i] = (std::numeric_limits<base_type>::max)();
    }
    a[base_type_count - 1] = last_value_max;
    return *this;
  }

  constexpr bitset& set(E pos, bool value = true) {
    if (auto i = index_type::at(pos); i && *i < size()) {
      reference{this, *i} = value;
      return *this;
    }
    MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::bitset::set: Unrecognized position"));
  }

  constexpr bitset& reset() noexcept { return *this = bitset{}; }

  constexpr bitset& reset(E pos) {
    if (auto i = index_type::at(pos); i && *i < size()) {
      reference{this, *i} = false;
      return *this;
    }
    MAGIC_ENUM_CONTAINERS_THROW(std::out_of_range("magic_enum::containers::bitset::reset: Unrecognized position"));
  }

  constexpr bitset& flip() noexcept {
    for (auto& value : a) {
      value = static_cast<base_type>(~value);
    }
    a[base_type_count - 1] &= last_value_max;
    return *this;
  }

  [[nodiscard]] friend constexpr bitset operator&(const bitset& lhs, const bitset& rhs) noexcept {
    bitset cp = lhs;
    cp &= rhs;
    return cp;
  }

  [[nodiscard]] friend constexpr bitset operator|(const bitset& lhs, const bitset& rhs) noexcept {
    bitset cp = lhs;
    cp |= rhs;
    return cp;
  }

  [[nodiscard]] friend constexpr bitset operator^(const bitset& lhs, const bitset& rhs) noexcept {
    bitset cp = lhs;
    cp ^= rhs;
    return cp;
  }

  template <typename V = E>
  [[nodiscard]] constexpr explicit operator std::enable_if_t<magic_enum::detail::subtype_v<V> == magic_enum::detail::enum_subtype::flags, E>() const {
    underlying_type_t<E> res = 0;
    for (const auto value : *this) {
      res |= enum_underlying(value);
    }
    return static_cast<E>(res);
  }

  [[nodiscard]] string to_string(char_type sep = char_type{'|'}) const {
    string name;

    for (const auto& e : enum_values<E>()) {
      if (test(e)) {
        if (!name.empty()) {
          name.append(1, sep);
        }
        auto n = enum_name(e);
        name.append(n.data(), n.size());
      }
    }
    return name;
  }

  [[nodiscard]] string to_string(detail::raw_access_t, char_type zero = char_type{'0'}, char_type one = char_type{'1'}) const {
    string name;
    name.reserve(size());
    for (std::size_t i = 0; i < size(); ++i) {
      name.append(1, const_reference{this, i} ? one : zero);
    }
    return name;
  }

  [[nodiscard]] constexpr unsigned long long to_ullong(detail::raw_access_t raw) const { return to_<unsigned long long>(raw); }

  [[nodiscard]] constexpr unsigned long to_ulong(detail::raw_access_t raw) const { return to_<unsigned long>(raw); }

  template <typename Traits>
  friend std::basic_ostream<char_type, Traits>& operator<<(std::basic_ostream<char_type, Traits>& o, const bitset& bs) {
    const auto s = bs.to_string();
    return o.write(s.data(), static_cast<std::streamsize>(s.size()));
  }

  template <typename Traits>
  friend std::basic_istream<char_type, Traits>& operator>>(std::basic_istream<char_type, Traits>& i, bitset& bs) {
    std::basic_string<char_type, Traits> s;
    if (i >> s; !s.empty()) {
      bs = bitset(string_view{s.data(), s.size()});
    }
    return i;
  }

 private:
  container_type a;
};

template <typename V, int = 0>
explicit bitset(V starter) -> bitset<V>;

///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
//                                                           SET                                                             //
///////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////////
template <typename E, typename Cmp = std::less<E>>
class set {
  using index_type = detail::indexing<E, Cmp>;
  struct Getter {
    constexpr const E& operator()(const set*, const E* p) const noexcept { return *p; }
  };
  struct Predicate {
    constexpr bool operator()(const set* h, const E* e) const noexcept { return h->a[*e]; }
  };

 public:
  using container_type = bitset<E, index_type>;
  using key_type = E;
  using value_type = E;
  using size_type = std::size_t;
  using difference_type = std::ptrdiff_t;
  using key_compare = Cmp;
  using value_compare = Cmp;
  using reference = value_type&;
  using const_reference = const value_type&;
  using pointer = value_type*;
  using const_pointer = const value_type*;
  using iterator = detail::FilteredIterator<const set*, const E*, Getter, Predicate>;
  using const_iterator = detail::FilteredIterator<const set*, const E*, Getter, Predicate>;
  using reverse_iterator = std::reverse_iterator<iterator>;
  using const_reverse_iterator = std::reverse_iterator<const_iterator>;

  constexpr set() noexcept = default;

  template <typename InputIt>
  constexpr set(InputIt first, InputIt last) {
    while (first != last) {
      insert(*first++);
    }
  }

  constexpr set(std::initializer_list<E> ilist) {
    for (auto e : ilist) {
      insert(e);
    }
  }
  template <typename V, std::enable_if_t<std::is_same_v<V, E> && magic_enum::detail::subtype_v<V> == magic_enum::detail::enum_subtype::flags, int> = 0>
  constexpr explicit set(V starter) {
    auto u = enum_underlying(starter);
    for (E v : enum_values<E>()) {
      if ((enum_underlying(v) & u) != 0) {
        insert(v);
      }
    }
  }

  constexpr set(const set&) noexcept = default;
  constexpr set(set&&) noexcept = default;

  constexpr set& operator=(const set&) noexcept = default;
  constexpr set& operator=(set&&) noexcept = default;
  constexpr set& operator=(std::initializer_list<E> ilist) {
    clear();
    for (auto e : ilist) {
      insert(e);
    }
    return *this;
  }

  constexpr const_iterator begin() const noexcept {
    return const_iterator{this, index_type::begin(), index_type::end(), index_type::begin()};
  }

  constexpr const_iterator end() const noexcept {
    return const_iterator{this, index_type::begin(), index_type::end(), index_type::end()};
  }

  constexpr const_iterator cbegin() const noexcept { return begin(); }

  constexpr const_iterator cend() const noexcept { return end(); }

  constexpr const_reverse_iterator rbegin() const noexcept { return {end()}; }

  constexpr const_reverse_iterator rend() const noexcept { return {begin()}; }

  constexpr const_reverse_iterator crbegin() const noexcept { return rbegin(); }

  constexpr const_reverse_iterator crend() const noexcept { return rend(); }

  [[nodiscard]] constexpr bool empty() const noexcept { return s == 0; }

  [[nodiscard]] constexpr size_type size() const noexcept { return s; }

  [[nodiscard]] constexpr size_type max_size() const noexcept { return a.max_size(); }

  constexpr void clear() noexcept {
    a.reset();
    s = 0;
  }

  constexpr std::pair<iterator, bool> insert(const value_type& value) noexcept {
    if (auto i = index_type::at(value)) {
      auto ref = a[value];
      const bool res = !ref;
      if (res) {
        ref = true;
        ++s;
      }

      return {iterator{this, index_type::begin(), index_type::end(), index_type::it(*i)}, res};
    }
    return {end(), false};
  }

  constexpr std::pair<iterator, bool> insert(value_type&& value) noexcept { return insert(value); }

  constexpr iterator insert(const_iterator, const value_type& value) noexcept { return insert(value).first; }

  constexpr iterator insert(const_iterator hint, value_type&& value) noexcept { return insert(hint, value); }

  template <typename InputIt>
  constexpr void insert(InputIt first, InputIt last) {
    while (first != last) {
      insert(*first++);
    }
  }

  constexpr void insert(std::initializer_list<value_type> ilist) noexcept {
    for (auto v : ilist) {
      insert(v);
    }
  }

  template <typename... Args>
  constexpr std::pair<iterator, bool> emplace(Args&&... args) {
    return insert(value_type{std::forward<Args>(args)...});
  }

  template <typename... Args>
  constexpr iterator emplace_hint(const_iterator, Args&&... args) {
    return emplace(std::forward<Args>(args)...).first;
  }

  constexpr iterator erase(const_iterator pos) noexcept {
    erase(*pos++);
    return pos;
  }

  constexpr iterator erase(const_iterator first, const_iterator last) noexcept {
    while (first != last) {
      first = erase(first);
    }
    return first;
  }

  constexpr size_type erase(const key_type& key) noexcept {
    if (index_type::at(key)) {
      auto ref = a[key];
      const bool res = ref;
      if (res) {
        --s;
      }
      ref = false;
      return res;
    }
    return 0;
  }

  template <typename K, typename KC = key_compare>
  constexpr std::enable_if_t<detail::is_transparent_v<KC> && !std::is_same_v<std::decay_t<K>, key_type>, size_type> erase(K&& x) {
    size_type c = 0;
    for (auto [first, last] = detail::equal_range(index_type::begin(), index_type::end(), x, key_compare{}); first != last;) {
      c += erase(*first++);
    }
    return c;
  }

  void swap(set& other) noexcept {
    std::swap(a, other.a);
    std::swap(s, other.s);
  }

  [[nodiscard]] constexpr size_type count(const key_type& key) const noexcept { return a.find(key) != a.end(); }

  template <typename K, typename KC = key_compare>
  [[nodiscard]] constexpr std::enable_if_t<detail::is_transparent_v<KC>, size_type> count(const K& x) const {
    size_type c = 0;
    for (auto [first, last] = detail::equal_range(index_type::begin(), index_type::end(), x, key_compare{}); first != last; ++first) {
      c += a.test(*first);
    }
    return c;
  }

  [[nodiscard]] constexpr const_iterator find(const key_type& key) const noexcept {
    if (auto i = index_type::at(key); i && a.test(key)) {
      return const_iterator{this, index_type::begin(), index_type::end(), index_type::it(*i)};
    }
    return end();
  }

  template <typename K, typename KC = key_compare>
  [[nodiscard]] constexpr std::enable_if_t<detail::is_transparent_v<KC>, const_iterator> find(const K& x) const {
    for (auto [first, last] = detail::equal_range(index_type::begin(), index_type::end(), x, key_compare{}); first != last; ++first) {
      if (a.test(*first)) {
        return const_iterator{this, index_type::begin(), index_type::end(), first};
      }
    }
    return end();
  }

  [[nodiscard]] constexpr bool contains(const key_type& key) const noexcept { return count(key) > 0; }

  template <typename K, typename KC = key_compare>
  [[nodiscard]] constexpr std::enable_if_t<detail::is_transparent_v<KC>, bool> contains(const K& x) const {
    return find(x) != end();
  }

 private:
  [[nodiscard]] constexpr const_iterator iterator_at_or_after(const E* it) const noexcept {
    while (it != index_type::end() && !a.test(*it)) {
      ++it;
    }
    return const_iterator{this, index_type::begin(), index_type::end(), it};
  }

 public:
  [[nodiscard]] constexpr std::pair<const_iterator, const_iterator> equal_range(const key_type& key) const {
    return {lower_bound(key), upper_bound(key)};
  }

  template <typename K, typename KC = key_compare>
  [[nodiscard]] constexpr std::enable_if_t<detail::is_transparent_v<KC>, std::pair<const_iterator, const_iterator>> equal_range(const K& x) const {
    return {lower_bound(x), upper_bound(x)};
  }

  [[nodiscard]] constexpr const_iterator lower_bound(const key_type& key) const {
    return iterator_at_or_after(detail::impl::lower_bound(index_type::begin(), index_type::end(), key, key_compare{}));
  }

  template <typename K, typename KC = key_compare>
  [[nodiscard]] constexpr std::enable_if_t<detail::is_transparent_v<KC>, const_iterator> lower_bound(const K& x) const {
    return iterator_at_or_after(detail::impl::lower_bound(index_type::begin(), index_type::end(), x, key_compare{}));
  }

  [[nodiscard]] constexpr const_iterator upper_bound(const key_type& key) const {
    return iterator_at_or_after(detail::upper_bound(index_type::begin(), index_type::end(), key, key_compare{}));
  }

  template <typename K, typename KC = key_compare>
  [[nodiscard]] constexpr std::enable_if_t<detail::is_transparent_v<KC>, const_iterator> upper_bound(const K& x) const {
    return iterator_at_or_after(detail::upper_bound(index_type::begin(), index_type::end(), x, key_compare{}));
  }

  [[nodiscard]] constexpr key_compare key_comp() const { return {}; }

  [[nodiscard]] constexpr value_compare value_comp() const { return {}; }

  [[nodiscard]] constexpr friend bool operator==(const set& lhs, const set& rhs) noexcept { return lhs.a == rhs.a; }

  [[nodiscard]] constexpr friend bool operator!=(const set& lhs, const set& rhs) noexcept { return lhs.a != rhs.a; }

  [[nodiscard]] constexpr friend bool operator<(const set& lhs, const set& rhs) {
    return detail::lexicographical_compare(lhs, rhs);
  }

  [[nodiscard]] constexpr friend bool operator<=(const set& lhs, const set& rhs) { return !(rhs < lhs); }

  [[nodiscard]] constexpr friend bool operator>(const set& lhs, const set& rhs) { return rhs < lhs; }

  [[nodiscard]] constexpr friend bool operator>=(const set& lhs, const set& rhs) { return !(lhs < rhs); }

  template <typename Pred>
  size_type erase_if(Pred pred) {
    auto old_size = size();
    for (auto i = begin(), last = end(); i != last;) {
      if (pred(*i)) {
        i = erase(i);
      } else {
        ++i;
      }
    }
    return old_size - size();
  }

 private:
  container_type a;
  std::size_t s = 0;
};

template <typename V, int = 0>
explicit set(V starter) -> set<V>;

template <auto J, typename E, typename V, typename Index>
constexpr std::enable_if_t<(std::is_integral_v<decltype(J)> && J < enum_count<E>()), V&> get(array<E, V, Index>& a) noexcept {
  return a.a[J];
}

template <auto J, typename E, typename V, typename Index>
constexpr std::enable_if_t<(std::is_integral_v<decltype(J)> && J < enum_count<E>()), V&&> get(array<E, V, Index>&& a) noexcept {
  return std::move(a.a[J]);
}

template <auto J, typename E, typename V, typename Index>
constexpr std::enable_if_t<(std::is_integral_v<decltype(J)> && J < enum_count<E>()), const V&> get(const array<E, V, Index>& a) noexcept {
  return a.a[J];
}

template <auto J, typename E, typename V, typename Index>
constexpr std::enable_if_t<(std::is_integral_v<decltype(J)> && J < enum_count<E>()), const V&&> get(const array<E, V, Index>&& a) noexcept {
  return std::move(a.a[J]);
}

template <auto Enum, typename E, typename V, typename Index>
constexpr std::enable_if_t<std::is_same_v<decltype(Enum), E> && enum_contains(Enum), V&> get(array<E, V, Index>& a) {
  return a[Enum];
}

template <auto Enum, typename E, typename V, typename Index>
constexpr std::enable_if_t<std::is_same_v<decltype(Enum), E> && enum_contains(Enum), V&&> get(array<E, V, Index>&& a) {
  return std::move(a[Enum]);
}

template <auto Enum, typename E, typename V, typename Index>
constexpr std::enable_if_t<std::is_same_v<decltype(Enum), E> && enum_contains(Enum), const V&> get(const array<E, V, Index>& a) {
  return a[Enum];
}

template <auto Enum, typename E, typename V, typename Index>
constexpr std::enable_if_t<std::is_same_v<decltype(Enum), E> && enum_contains(Enum), const V&&> get(const array<E, V, Index>&& a) {
  return std::move(a[Enum]);
}

} // namespace magic_enum::containers

template <typename E, typename Index>
struct std::hash<magic_enum::containers::bitset<E, Index>> {
  std::size_t operator()(const magic_enum::containers::bitset<E, Index>& bs) const noexcept {
    if constexpr (magic_enum::enum_count<E>() <= sizeof(unsigned long long) * 8) {
      return std::hash<unsigned long long>{}(bs.to_ullong(magic_enum::containers::raw_access));
    } else {
      unsigned long long low_bits = 0;
      std::size_t seed = 0;
      bool has_high_bits = false;
      for (const auto value : bs) {
        const auto index = Index::at(value);
        MAGIC_ENUM_ASSERT(index);
        if (*index < sizeof(low_bits) * 8) {
          low_bits |= 1ULL << *index;
        } else {
          if (!has_high_bits) {
            seed = std::hash<unsigned long long>{}(low_bits);
            has_high_bits = true;
          }
          const auto index_hash = std::hash<std::size_t>{}(*index);
          seed ^= index_hash + std::size_t{0x9e3779b9U} + (seed << 6) + (seed >> 2);
        }
      }
      return has_high_bits ? seed : std::hash<unsigned long long>{}(low_bits);
    }
  }
};

#undef MAGIC_ENUM_CONTAINERS_THROW

#endif // NEARGYE_MAGIC_ENUM_CONTAINERS_HPP
