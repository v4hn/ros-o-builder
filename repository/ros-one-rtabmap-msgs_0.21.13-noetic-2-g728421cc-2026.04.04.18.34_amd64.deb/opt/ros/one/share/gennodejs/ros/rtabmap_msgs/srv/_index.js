
"use strict";

let GetMap2 = require('./GetMap2.js')
let LoadDatabase = require('./LoadDatabase.js')
let SetLabel = require('./SetLabel.js')
let GetPlan = require('./GetPlan.js')
let SetGoal = require('./SetGoal.js')
let CleanupLocalGrids = require('./CleanupLocalGrids.js')
let GetNodeData = require('./GetNodeData.js')
let DetectMoreLoopClosures = require('./DetectMoreLoopClosures.js')
let ListLabels = require('./ListLabels.js')
let GetMap = require('./GetMap.js')
let GetNodesInRadius = require('./GetNodesInRadius.js')
let GlobalBundleAdjustment = require('./GlobalBundleAdjustment.js')
let AddLink = require('./AddLink.js')
let PublishMap = require('./PublishMap.js')
let ResetPose = require('./ResetPose.js')
let RemoveLabel = require('./RemoveLabel.js')

module.exports = {
  GetMap2: GetMap2,
  LoadDatabase: LoadDatabase,
  SetLabel: SetLabel,
  GetPlan: GetPlan,
  SetGoal: SetGoal,
  CleanupLocalGrids: CleanupLocalGrids,
  GetNodeData: GetNodeData,
  DetectMoreLoopClosures: DetectMoreLoopClosures,
  ListLabels: ListLabels,
  GetMap: GetMap,
  GetNodesInRadius: GetNodesInRadius,
  GlobalBundleAdjustment: GlobalBundleAdjustment,
  AddLink: AddLink,
  PublishMap: PublishMap,
  ResetPose: ResetPose,
  RemoveLabel: RemoveLabel,
};
