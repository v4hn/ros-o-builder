
"use strict";

let Feature1DDetect = require('./Feature1DDetect.js')
let TargetObj = require('./TargetObj.js')
let Feature0DDetect = require('./Feature0DDetect.js')
let Detect = require('./Detect.js')

module.exports = {
  Feature1DDetect: Feature1DDetect,
  TargetObj: TargetObj,
  Feature0DDetect: Feature0DDetect,
  Detect: Detect,
};
