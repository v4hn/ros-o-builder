
"use strict";

let RestartController = require('./RestartController.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetSpeed = require('./SetSpeed.js')
let TorqueEnable = require('./TorqueEnable.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let StartController = require('./StartController.js')
let StopController = require('./StopController.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')

module.exports = {
  RestartController: RestartController,
  SetCompliancePunch: SetCompliancePunch,
  SetSpeed: SetSpeed,
  TorqueEnable: TorqueEnable,
  SetTorqueLimit: SetTorqueLimit,
  SetComplianceSlope: SetComplianceSlope,
  StartController: StartController,
  StopController: StopController,
  SetComplianceMargin: SetComplianceMargin,
};
