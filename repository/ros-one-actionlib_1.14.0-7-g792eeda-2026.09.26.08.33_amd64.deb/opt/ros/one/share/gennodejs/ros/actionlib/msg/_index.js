
"use strict";

let TestGoal = require('./TestGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestResult = require('./TestResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestActionResult = require('./TestActionResult.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestAction = require('./TestAction.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestAction = require('./TestRequestAction.js');

module.exports = {
  TestGoal: TestGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestResult: TestResult,
  TwoIntsGoal: TwoIntsGoal,
  TestFeedback: TestFeedback,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestRequestGoal: TestRequestGoal,
  TestRequestActionResult: TestRequestActionResult,
  TestRequestActionGoal: TestRequestActionGoal,
  TestActionFeedback: TestActionFeedback,
  TwoIntsAction: TwoIntsAction,
  TestActionResult: TestActionResult,
  TestActionGoal: TestActionGoal,
  TestRequestFeedback: TestRequestFeedback,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestRequestResult: TestRequestResult,
  TwoIntsResult: TwoIntsResult,
  TestAction: TestAction,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestAction: TestRequestAction,
};
