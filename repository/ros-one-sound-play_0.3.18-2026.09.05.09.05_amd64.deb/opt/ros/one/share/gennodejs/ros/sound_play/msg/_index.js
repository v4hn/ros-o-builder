
"use strict";

let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestResult: SoundRequestResult,
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequest: SoundRequest,
};
