
"use strict";

let Voltage = require('./Voltage.js');
let ElectricCurrentStamped = require('./ElectricCurrentStamped.js');
let Brightness = require('./Brightness.js');
let Power = require('./Power.js');
let PowerStamped = require('./PowerStamped.js');
let PowerSwitchStateStamped = require('./PowerSwitchStateStamped.js');
let BrightnessStamped = require('./BrightnessStamped.js');
let ElectricCurrent = require('./ElectricCurrent.js');
let VoltageStamped = require('./VoltageStamped.js');
let ColorRGBAStamped = require('./ColorRGBAStamped.js');
let PowerSwitchState = require('./PowerSwitchState.js');
let Heartbeat = require('./Heartbeat.js');
let ElectricCurrentMeasurement = require('./ElectricCurrentMeasurement.js');
let VoltageMeasurement = require('./VoltageMeasurement.js');
let PowerMeasurement = require('./PowerMeasurement.js');

module.exports = {
  Voltage: Voltage,
  ElectricCurrentStamped: ElectricCurrentStamped,
  Brightness: Brightness,
  Power: Power,
  PowerStamped: PowerStamped,
  PowerSwitchStateStamped: PowerSwitchStateStamped,
  BrightnessStamped: BrightnessStamped,
  ElectricCurrent: ElectricCurrent,
  VoltageStamped: VoltageStamped,
  ColorRGBAStamped: ColorRGBAStamped,
  PowerSwitchState: PowerSwitchState,
  Heartbeat: Heartbeat,
  ElectricCurrentMeasurement: ElectricCurrentMeasurement,
  VoltageMeasurement: VoltageMeasurement,
  PowerMeasurement: PowerMeasurement,
};
