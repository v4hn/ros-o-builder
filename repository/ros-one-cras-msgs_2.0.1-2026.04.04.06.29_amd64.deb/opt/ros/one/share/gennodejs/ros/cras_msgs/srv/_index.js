
"use strict";

let SetColor = require('./SetColor.js')
let SetBrightness = require('./SetBrightness.js')

module.exports = {
  SetColor: SetColor,
  SetBrightness: SetBrightness,
};
