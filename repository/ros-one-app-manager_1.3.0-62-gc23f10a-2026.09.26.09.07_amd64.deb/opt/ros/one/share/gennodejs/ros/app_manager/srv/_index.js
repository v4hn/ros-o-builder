
"use strict";

let StopApp = require('./StopApp.js')
let InstallApp = require('./InstallApp.js')
let GetInstallationState = require('./GetInstallationState.js')
let UninstallApp = require('./UninstallApp.js')
let ListApps = require('./ListApps.js')
let StartApp = require('./StartApp.js')
let GetAppDetails = require('./GetAppDetails.js')

module.exports = {
  StopApp: StopApp,
  InstallApp: InstallApp,
  GetInstallationState: GetInstallationState,
  UninstallApp: UninstallApp,
  ListApps: ListApps,
  StartApp: StartApp,
  GetAppDetails: GetAppDetails,
};
