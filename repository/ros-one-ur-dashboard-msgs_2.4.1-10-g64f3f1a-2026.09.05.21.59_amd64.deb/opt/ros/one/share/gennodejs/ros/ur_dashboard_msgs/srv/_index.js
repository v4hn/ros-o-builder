
"use strict";

let IsProgramSaved = require('./IsProgramSaved.js')
let GetLoadedProgram = require('./GetLoadedProgram.js')
let AddToLog = require('./AddToLog.js')
let RawRequest = require('./RawRequest.js')
let GetProgramState = require('./GetProgramState.js')
let IsInRemoteControl = require('./IsInRemoteControl.js')
let GetRobotMode = require('./GetRobotMode.js')
let Popup = require('./Popup.js')
let GetSafetyMode = require('./GetSafetyMode.js')
let Load = require('./Load.js')
let IsProgramRunning = require('./IsProgramRunning.js')

module.exports = {
  IsProgramSaved: IsProgramSaved,
  GetLoadedProgram: GetLoadedProgram,
  AddToLog: AddToLog,
  RawRequest: RawRequest,
  GetProgramState: GetProgramState,
  IsInRemoteControl: IsInRemoteControl,
  GetRobotMode: GetRobotMode,
  Popup: Popup,
  GetSafetyMode: GetSafetyMode,
  Load: Load,
  IsProgramRunning: IsProgramRunning,
};
