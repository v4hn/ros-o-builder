
"use strict";

let Velocity = require('./Velocity.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeFeedback = require('./ShapeFeedback.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');

module.exports = {
  Velocity: Velocity,
  ShapeGoal: ShapeGoal,
  ShapeResult: ShapeResult,
  ShapeAction: ShapeAction,
  ShapeActionResult: ShapeActionResult,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeFeedback: ShapeFeedback,
  ShapeActionGoal: ShapeActionGoal,
};
