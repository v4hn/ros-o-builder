
"use strict";

let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestNestedService = require('./TestNestedService.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let SendBytes = require('./SendBytes.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestEmpty = require('./TestEmpty.js')
let TestRequestOnly = require('./TestRequestOnly.js')

module.exports = {
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestNestedService: TestNestedService,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestResponseOnly: TestResponseOnly,
  TestRequestAndResponse: TestRequestAndResponse,
  SendBytes: SendBytes,
  AddTwoInts: AddTwoInts,
  TestArrayRequest: TestArrayRequest,
  TestEmpty: TestEmpty,
  TestRequestOnly: TestRequestOnly,
};
