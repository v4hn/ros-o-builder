
"use strict";

let PickupActionFeedback = require('./PickupActionFeedback.js');
let MoveGroupSequenceAction = require('./MoveGroupSequenceAction.js');
let ExecuteTrajectoryAction = require('./ExecuteTrajectoryAction.js');
let MoveGroupGoal = require('./MoveGroupGoal.js');
let ExecuteTrajectoryActionGoal = require('./ExecuteTrajectoryActionGoal.js');
let MoveGroupSequenceFeedback = require('./MoveGroupSequenceFeedback.js');
let PlaceResult = require('./PlaceResult.js');
let MoveGroupSequenceActionFeedback = require('./MoveGroupSequenceActionFeedback.js');
let MoveGroupAction = require('./MoveGroupAction.js');
let PickupAction = require('./PickupAction.js');
let PickupGoal = require('./PickupGoal.js');
let ExecuteTrajectoryResult = require('./ExecuteTrajectoryResult.js');
let ExecuteTrajectoryGoal = require('./ExecuteTrajectoryGoal.js');
let PickupActionResult = require('./PickupActionResult.js');
let PlaceActionFeedback = require('./PlaceActionFeedback.js');
let PlaceActionGoal = require('./PlaceActionGoal.js');
let PickupActionGoal = require('./PickupActionGoal.js');
let MoveGroupSequenceGoal = require('./MoveGroupSequenceGoal.js');
let ExecuteTrajectoryFeedback = require('./ExecuteTrajectoryFeedback.js');
let PlaceFeedback = require('./PlaceFeedback.js');
let PickupFeedback = require('./PickupFeedback.js');
let MoveGroupActionGoal = require('./MoveGroupActionGoal.js');
let MoveGroupSequenceResult = require('./MoveGroupSequenceResult.js');
let PlaceGoal = require('./PlaceGoal.js');
let MoveGroupFeedback = require('./MoveGroupFeedback.js');
let MoveGroupSequenceActionResult = require('./MoveGroupSequenceActionResult.js');
let PickupResult = require('./PickupResult.js');
let PlaceAction = require('./PlaceAction.js');
let ExecuteTrajectoryActionFeedback = require('./ExecuteTrajectoryActionFeedback.js');
let MoveGroupResult = require('./MoveGroupResult.js');
let ExecuteTrajectoryActionResult = require('./ExecuteTrajectoryActionResult.js');
let MoveGroupSequenceActionGoal = require('./MoveGroupSequenceActionGoal.js');
let MoveGroupActionFeedback = require('./MoveGroupActionFeedback.js');
let PlaceActionResult = require('./PlaceActionResult.js');
let MoveGroupActionResult = require('./MoveGroupActionResult.js');
let LinkScale = require('./LinkScale.js');
let OrientationConstraint = require('./OrientationConstraint.js');
let PlanningOptions = require('./PlanningOptions.js');
let JointConstraint = require('./JointConstraint.js');
let CollisionObject = require('./CollisionObject.js');
let ConstraintEvalResult = require('./ConstraintEvalResult.js');
let CartesianTrajectoryPoint = require('./CartesianTrajectoryPoint.js');
let PlannerParams = require('./PlannerParams.js');
let Constraints = require('./Constraints.js');
let GenericTrajectory = require('./GenericTrajectory.js');
let PositionIKRequest = require('./PositionIKRequest.js');
let PlaceLocation = require('./PlaceLocation.js');
let MotionPlanRequest = require('./MotionPlanRequest.js');
let DisplayRobotState = require('./DisplayRobotState.js');
let PlanningScene = require('./PlanningScene.js');
let AllowedCollisionMatrix = require('./AllowedCollisionMatrix.js');
let PlannerInterfaceDescription = require('./PlannerInterfaceDescription.js');
let LinkPadding = require('./LinkPadding.js');
let PlanningSceneComponents = require('./PlanningSceneComponents.js');
let CostSource = require('./CostSource.js');
let GripperTranslation = require('./GripperTranslation.js');
let JointLimits = require('./JointLimits.js');
let VisibilityConstraint = require('./VisibilityConstraint.js');
let RobotTrajectory = require('./RobotTrajectory.js');
let CartesianPoint = require('./CartesianPoint.js');
let ObjectColor = require('./ObjectColor.js');
let MotionPlanDetailedResponse = require('./MotionPlanDetailedResponse.js');
let WorkspaceParameters = require('./WorkspaceParameters.js');
let TrajectoryConstraints = require('./TrajectoryConstraints.js');
let MotionSequenceResponse = require('./MotionSequenceResponse.js');
let AttachedCollisionObject = require('./AttachedCollisionObject.js');
let BoundingVolume = require('./BoundingVolume.js');
let RobotState = require('./RobotState.js');
let DisplayTrajectory = require('./DisplayTrajectory.js');
let PlanningSceneWorld = require('./PlanningSceneWorld.js');
let CartesianTrajectory = require('./CartesianTrajectory.js');
let ContactInformation = require('./ContactInformation.js');
let Grasp = require('./Grasp.js');
let KinematicSolverInfo = require('./KinematicSolverInfo.js');
let MotionPlanResponse = require('./MotionPlanResponse.js');
let MoveItErrorCodes = require('./MoveItErrorCodes.js');
let AllowedCollisionEntry = require('./AllowedCollisionEntry.js');
let MotionSequenceRequest = require('./MotionSequenceRequest.js');
let OrientedBoundingBox = require('./OrientedBoundingBox.js');
let MotionSequenceItem = require('./MotionSequenceItem.js');
let PositionConstraint = require('./PositionConstraint.js');

module.exports = {
  PickupActionFeedback: PickupActionFeedback,
  MoveGroupSequenceAction: MoveGroupSequenceAction,
  ExecuteTrajectoryAction: ExecuteTrajectoryAction,
  MoveGroupGoal: MoveGroupGoal,
  ExecuteTrajectoryActionGoal: ExecuteTrajectoryActionGoal,
  MoveGroupSequenceFeedback: MoveGroupSequenceFeedback,
  PlaceResult: PlaceResult,
  MoveGroupSequenceActionFeedback: MoveGroupSequenceActionFeedback,
  MoveGroupAction: MoveGroupAction,
  PickupAction: PickupAction,
  PickupGoal: PickupGoal,
  ExecuteTrajectoryResult: ExecuteTrajectoryResult,
  ExecuteTrajectoryGoal: ExecuteTrajectoryGoal,
  PickupActionResult: PickupActionResult,
  PlaceActionFeedback: PlaceActionFeedback,
  PlaceActionGoal: PlaceActionGoal,
  PickupActionGoal: PickupActionGoal,
  MoveGroupSequenceGoal: MoveGroupSequenceGoal,
  ExecuteTrajectoryFeedback: ExecuteTrajectoryFeedback,
  PlaceFeedback: PlaceFeedback,
  PickupFeedback: PickupFeedback,
  MoveGroupActionGoal: MoveGroupActionGoal,
  MoveGroupSequenceResult: MoveGroupSequenceResult,
  PlaceGoal: PlaceGoal,
  MoveGroupFeedback: MoveGroupFeedback,
  MoveGroupSequenceActionResult: MoveGroupSequenceActionResult,
  PickupResult: PickupResult,
  PlaceAction: PlaceAction,
  ExecuteTrajectoryActionFeedback: ExecuteTrajectoryActionFeedback,
  MoveGroupResult: MoveGroupResult,
  ExecuteTrajectoryActionResult: ExecuteTrajectoryActionResult,
  MoveGroupSequenceActionGoal: MoveGroupSequenceActionGoal,
  MoveGroupActionFeedback: MoveGroupActionFeedback,
  PlaceActionResult: PlaceActionResult,
  MoveGroupActionResult: MoveGroupActionResult,
  LinkScale: LinkScale,
  OrientationConstraint: OrientationConstraint,
  PlanningOptions: PlanningOptions,
  JointConstraint: JointConstraint,
  CollisionObject: CollisionObject,
  ConstraintEvalResult: ConstraintEvalResult,
  CartesianTrajectoryPoint: CartesianTrajectoryPoint,
  PlannerParams: PlannerParams,
  Constraints: Constraints,
  GenericTrajectory: GenericTrajectory,
  PositionIKRequest: PositionIKRequest,
  PlaceLocation: PlaceLocation,
  MotionPlanRequest: MotionPlanRequest,
  DisplayRobotState: DisplayRobotState,
  PlanningScene: PlanningScene,
  AllowedCollisionMatrix: AllowedCollisionMatrix,
  PlannerInterfaceDescription: PlannerInterfaceDescription,
  LinkPadding: LinkPadding,
  PlanningSceneComponents: PlanningSceneComponents,
  CostSource: CostSource,
  GripperTranslation: GripperTranslation,
  JointLimits: JointLimits,
  VisibilityConstraint: VisibilityConstraint,
  RobotTrajectory: RobotTrajectory,
  CartesianPoint: CartesianPoint,
  ObjectColor: ObjectColor,
  MotionPlanDetailedResponse: MotionPlanDetailedResponse,
  WorkspaceParameters: WorkspaceParameters,
  TrajectoryConstraints: TrajectoryConstraints,
  MotionSequenceResponse: MotionSequenceResponse,
  AttachedCollisionObject: AttachedCollisionObject,
  BoundingVolume: BoundingVolume,
  RobotState: RobotState,
  DisplayTrajectory: DisplayTrajectory,
  PlanningSceneWorld: PlanningSceneWorld,
  CartesianTrajectory: CartesianTrajectory,
  ContactInformation: ContactInformation,
  Grasp: Grasp,
  KinematicSolverInfo: KinematicSolverInfo,
  MotionPlanResponse: MotionPlanResponse,
  MoveItErrorCodes: MoveItErrorCodes,
  AllowedCollisionEntry: AllowedCollisionEntry,
  MotionSequenceRequest: MotionSequenceRequest,
  OrientedBoundingBox: OrientedBoundingBox,
  MotionSequenceItem: MotionSequenceItem,
  PositionConstraint: PositionConstraint,
};
