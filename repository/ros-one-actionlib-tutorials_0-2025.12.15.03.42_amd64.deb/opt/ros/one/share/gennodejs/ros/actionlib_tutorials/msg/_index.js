
"use strict";

let AveragingAction = require('./AveragingAction.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let AveragingGoal = require('./AveragingGoal.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let FibonacciAction = require('./FibonacciAction.js');
let AveragingResult = require('./AveragingResult.js');
let FibonacciResult = require('./FibonacciResult.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let FibonacciGoal = require('./FibonacciGoal.js');

module.exports = {
  AveragingAction: AveragingAction,
  AveragingActionResult: AveragingActionResult,
  AveragingGoal: AveragingGoal,
  AveragingActionGoal: AveragingActionGoal,
  FibonacciActionFeedback: FibonacciActionFeedback,
  AveragingActionFeedback: AveragingActionFeedback,
  FibonacciFeedback: FibonacciFeedback,
  AveragingFeedback: AveragingFeedback,
  FibonacciActionGoal: FibonacciActionGoal,
  FibonacciAction: FibonacciAction,
  AveragingResult: AveragingResult,
  FibonacciResult: FibonacciResult,
  FibonacciActionResult: FibonacciActionResult,
  FibonacciGoal: FibonacciGoal,
};
