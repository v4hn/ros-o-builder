
"use strict";

let TestAction = require('./TestAction.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestResult = require('./TestResult.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestActionResult = require('./TestActionResult.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');

module.exports = {
  TestAction: TestAction,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestRequestGoal: TestRequestGoal,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestActionResult: TestRequestActionResult,
  TestFeedback: TestFeedback,
  TwoIntsAction: TwoIntsAction,
  TwoIntsResult: TwoIntsResult,
  TestRequestResult: TestRequestResult,
  TestResult: TestResult,
  TestRequestAction: TestRequestAction,
  TestActionFeedback: TestActionFeedback,
  TestActionResult: TestActionResult,
  TestGoal: TestGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestActionGoal: TestActionGoal,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TwoIntsActionResult: TwoIntsActionResult,
  TwoIntsGoal: TwoIntsGoal,
  TestRequestFeedback: TestRequestFeedback,
};
