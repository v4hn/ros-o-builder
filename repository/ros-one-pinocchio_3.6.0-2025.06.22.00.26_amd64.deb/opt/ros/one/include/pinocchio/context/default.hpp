//
// Copyright (c) 2022 INRIA
//

#ifndef __pinocchio_context_default_hpp__
#define __pinocchio_context_default_hpp__

#define PINOCCHIO_SCALAR_TYPE PINOCCHIO_SCALAR_TYPE_DEFAULT

#include "pinocchio/context/generic.hpp"

#undef PINOCCHIO_SCALAR_TYPE
#endif // #ifndef __pinocchio_context_default_hpp__
