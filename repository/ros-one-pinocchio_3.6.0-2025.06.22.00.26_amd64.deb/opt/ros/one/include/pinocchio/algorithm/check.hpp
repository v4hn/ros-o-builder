//
// Copyright (c) 2016-2018 CNRS
//

#ifndef __pinocchio_algorithm_check_hpp__
#define __pinocchio_algorithm_check_hpp__

// This header is provided for backward compatibility
#include "pinocchio/algorithm/check-model.hpp"
#include "pinocchio/algorithm/check-data.hpp"

#endif // __pinocchio_algorithm_check_hpp__
