
"use strict";

let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestResult = require('./TestRequestResult.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestActionResult = require('./TestActionResult.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestResult = require('./TestResult.js');
let TestAction = require('./TestAction.js');

module.exports = {
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestResult: TestRequestResult,
  TestActionFeedback: TestActionFeedback,
  TestRequestAction: TestRequestAction,
  TestFeedback: TestFeedback,
  TwoIntsResult: TwoIntsResult,
  TestRequestFeedback: TestRequestFeedback,
  TwoIntsAction: TwoIntsAction,
  TestActionResult: TestActionResult,
  TestGoal: TestGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestActionResult: TestRequestActionResult,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TwoIntsGoal: TwoIntsGoal,
  TestActionGoal: TestActionGoal,
  TestRequestGoal: TestRequestGoal,
  TestResult: TestResult,
  TestAction: TestAction,
};
