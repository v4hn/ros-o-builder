
"use strict";

let FlowArrayStamped = require('./FlowArrayStamped.js');
let ContourArray = require('./ContourArray.js');
let FaceArray = require('./FaceArray.js');
let FlowStamped = require('./FlowStamped.js');
let Line = require('./Line.js');
let Size = require('./Size.js');
let Face = require('./Face.js');
let RotatedRect = require('./RotatedRect.js');
let CircleArrayStamped = require('./CircleArrayStamped.js');
let Contour = require('./Contour.js');
let ContourArrayStamped = require('./ContourArrayStamped.js');
let RotatedRectArray = require('./RotatedRectArray.js');
let RectArray = require('./RectArray.js');
let RotatedRectStamped = require('./RotatedRectStamped.js');
let CircleArray = require('./CircleArray.js');
let Moment = require('./Moment.js');
let FlowArray = require('./FlowArray.js');
let LineArrayStamped = require('./LineArrayStamped.js');
let Point2D = require('./Point2D.js');
let MomentArray = require('./MomentArray.js');
let Flow = require('./Flow.js');
let RectArrayStamped = require('./RectArrayStamped.js');
let RotatedRectArrayStamped = require('./RotatedRectArrayStamped.js');
let LineArray = require('./LineArray.js');
let Circle = require('./Circle.js');
let MomentArrayStamped = require('./MomentArrayStamped.js');
let Rect = require('./Rect.js');
let FaceArrayStamped = require('./FaceArrayStamped.js');
let Point2DStamped = require('./Point2DStamped.js');
let Point2DArrayStamped = require('./Point2DArrayStamped.js');
let Point2DArray = require('./Point2DArray.js');

module.exports = {
  FlowArrayStamped: FlowArrayStamped,
  ContourArray: ContourArray,
  FaceArray: FaceArray,
  FlowStamped: FlowStamped,
  Line: Line,
  Size: Size,
  Face: Face,
  RotatedRect: RotatedRect,
  CircleArrayStamped: CircleArrayStamped,
  Contour: Contour,
  ContourArrayStamped: ContourArrayStamped,
  RotatedRectArray: RotatedRectArray,
  RectArray: RectArray,
  RotatedRectStamped: RotatedRectStamped,
  CircleArray: CircleArray,
  Moment: Moment,
  FlowArray: FlowArray,
  LineArrayStamped: LineArrayStamped,
  Point2D: Point2D,
  MomentArray: MomentArray,
  Flow: Flow,
  RectArrayStamped: RectArrayStamped,
  RotatedRectArrayStamped: RotatedRectArrayStamped,
  LineArray: LineArray,
  Circle: Circle,
  MomentArrayStamped: MomentArrayStamped,
  Rect: Rect,
  FaceArrayStamped: FaceArrayStamped,
  Point2DStamped: Point2DStamped,
  Point2DArrayStamped: Point2DArrayStamped,
  Point2DArray: Point2DArray,
};
