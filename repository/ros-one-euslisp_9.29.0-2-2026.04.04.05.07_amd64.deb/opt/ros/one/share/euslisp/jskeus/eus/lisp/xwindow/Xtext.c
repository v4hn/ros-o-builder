/* ./Xtext.c :  entry=Xtext */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Apr 4 05:09:15 UTC 2026) */
#include "eus.h"
#include "Xtext.h"
#pragma init (register_Xtext)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xtext();
extern pointer build_quote_vector();
static int register_Xtext()
  { add_module_initializer("___Xtext", ___Xtext);}

static pointer XtextF2327make_textwindow_stream();
static pointer XtextF2328expand_tab();

/*:create*/
static pointer XtextM2329characterwindow_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XtextRST2331:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XtextKEY2332;
	local[1] = makeint((eusinteger_t)256L);
XtextKEY2332:
	if (n & (1<<1)) goto XtextKEY2333;
	local[2] = makeint((eusinteger_t)256L);
XtextKEY2333:
	if (n & (1<<2)) goto XtextKEY2334;
	local[3] = NIL;
XtextKEY2334:
	if (n & (1<<3)) goto XtextKEY2335;
	local[4] = NIL;
XtextKEY2335:
	if (n & (1<<4)) goto XtextKEY2336;
	local[5] = NIL;
XtextKEY2336:
	if (n & (1<<5)) goto XtextKEY2337;
	local[6] = fqv[1];
XtextKEY2337:
	if (n & (1<<6)) goto XtextKEY2338;
	local[7] = loadglobal(fqv[2]);
XtextKEY2338:
	w = local[3];
	if (!isstring(w)) goto XtextCON2340;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(*ftab[0])(ctx,1,local+8,&ftab[0],fqv[3]); /*font-id*/
	local[8]= w;
	goto XtextCON2339;
XtextCON2340:
	w = local[3];
	if (!numberp(w)) goto XtextCON2341;
	local[8]= local[3];
	goto XtextCON2339;
XtextCON2341:
	local[8]= local[7];
	local[9]= loadglobal(fqv[2]);
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w!=NIL) goto XtextCON2342;
	local[8]= local[7];
	local[9]= loadglobal(fqv[4]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto XtextCON2342;
	local[8]= local[7];
	local[9]= fqv[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	goto XtextCON2339;
XtextCON2342:
	local[8]= loadglobal(fqv[6]);
	goto XtextCON2339;
XtextCON2343:
	local[8]= NIL;
XtextCON2339:
	argv[0]->c.obj.iv[12] = local[8];
	local[8]= fqv[7];
	local[9]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,2,local+8,&ftab[1],fqv[8]); /*textdots*/
	local[8]= w;
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[8];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	argv[0]->c.obj.iv[14] = w;
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	argv[0]->c.obj.iv[13] = w;
	local[9]= local[8];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	argv[0]->c.obj.iv[15] = w;
	w = argv[0]->c.obj.iv[15];
	if (local[5]==NIL) goto XtextCON2345;
	local[8]= makeint((eusinteger_t)4L);
	local[9]= argv[0]->c.obj.iv[13];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[1] = w;
	local[8]= local[1];
	goto XtextCON2344;
XtextCON2345:
	if (local[1]==NIL) goto XtextCON2346;
	local[8]= local[1];
	local[9]= makeint((eusinteger_t)4L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[5] = w;
	local[8]= local[5];
	goto XtextCON2344;
XtextCON2346:
	local[8]= NIL;
XtextCON2344:
	if (local[4]==NIL) goto XtextCON2348;
	local[8]= makeint((eusinteger_t)4L);
	local[9]= argv[0]->c.obj.iv[14];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[2] = w;
	local[8]= local[2];
	goto XtextCON2347;
XtextCON2348:
	if (local[2]==NIL) goto XtextCON2349;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)4L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[4] = w;
	local[8]= local[4];
	goto XtextCON2347;
XtextCON2349:
	local[8]= NIL;
XtextCON2347:
	argv[0]->c.obj.iv[16] = local[4];
	argv[0]->c.obj.iv[17] = local[5];
	local[8]= (pointer)get_sym_func(fqv[9]);
	local[9]= argv[0];
	local[10]= *(ovafptr(argv[1],fqv[10]));
	local[11]= fqv[11];
	local[12]= fqv[12];
	local[13]= local[1];
	local[14]= fqv[13];
	local[15]= local[2];
	local[16]= fqv[14];
	local[17]= local[6];
	local[18]= fqv[5];
	local[19]= local[3];
	local[20]= fqv[15];
	local[21]= local[7];
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)APPLY(ctx,15,local+8); /*apply*/
	local[8]= argv[0]->c.obj.iv[3];
	local[9]= fqv[5];
	local[10]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	w = argv[0];
	local[0]= w;
XtextBLK2330:
	ctx->vsp=local; return(local[0]);}

/*:xy*/
static pointer XtextM2350characterwindow_xy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2354;}
	local[0]= makeint((eusinteger_t)0L);
XtextENT2354:
	if (n>=4) { local[1]=(argv[3]); goto XtextENT2353;}
	local[1]= makeint((eusinteger_t)0L);
XtextENT2353:
XtextENT2352:
	if (n>4) maerror();
	local[2]= makeint((eusinteger_t)2L);
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	argv[0]->c.obj.iv[18] = w;
	local[2]= makeint((eusinteger_t)2L);
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,3,local+2); /*+*/
	argv[0]->c.obj.iv[19] = w;
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
XtextBLK2351:
	ctx->vsp=local; return(local[0]);}

/*:clear-lines*/
static pointer XtextM2355characterwindow_clear_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= fqv[17];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= fqv[18];
	local[5]= makeint((eusinteger_t)2L);
	local[6]= argv[2];
	local[7]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= fqv[12];
	local[7]= argv[0]->c.obj.iv[5];
	local[8]= fqv[13];
	local[9]= argv[0]->c.obj.iv[14];
	local[10]= argv[3];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,10,local+0); /*send*/
	w = argv[3];
	local[0]= w;
XtextBLK2356:
	ctx->vsp=local; return(local[0]);}

/*:put-line*/
static pointer XtextM2357characterwindow_put_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[20];
	local[2]= argv[0]->c.obj.iv[18];
	local[3]= argv[0]->c.obj.iv[19];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
XtextBLK2358:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XtextM2359textwindow_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XtextRST2361:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[21], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XtextKEY2362;
	local[1] = NIL;
XtextKEY2362:
	if (n & (1<<1)) goto XtextKEY2363;
	local[2] = NIL;
XtextKEY2363:
	if (n & (1<<2)) goto XtextKEY2364;
	local[3] = NIL;
XtextKEY2364:
	if (n & (1<<3)) goto XtextKEY2365;
	local[4] = NIL;
XtextKEY2365:
	if (n & (1<<4)) goto XtextKEY2366;
	local[5] = fqv[22];
XtextKEY2366:
	if (n & (1<<5)) goto XtextKEY2367;
	local[6] = NIL;
XtextKEY2367:
	if (n & (1<<6)) goto XtextKEY2368;
	local[7] = NIL;
XtextKEY2368:
	if (n & (1<<7)) goto XtextKEY2369;
	local[8] = NIL;
XtextKEY2369:
	local[9]= (pointer)get_sym_func(fqv[9]);
	local[10]= argv[0];
	local[11]= *(ovafptr(argv[1],fqv[10]));
	local[12]= fqv[11];
	local[13]= fqv[14];
	local[14]= local[5];
	local[15]= local[0];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,7,local+9); /*apply*/
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,1,local+9,&ftab[2],fqv[23]); /*make-string*/
	argv[0]->c.obj.iv[22] = w;
	local[9]= argv[0];
	local[10]= fqv[24];
	local[11]= local[7];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[25];
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	argv[0]->c.obj.iv[27] = NIL;
	local[9]= argv[0]->c.obj.iv[3];
	local[10]= fqv[5];
	local[11]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[26];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= argv[0];
	local[10]= fqv[27];
	local[11]= fqv[28];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	w = argv[0];
	local[0]= w;
XtextBLK2360:
	ctx->vsp=local; return(local[0]);}

/*:set-notify*/
static pointer XtextM2370textwindow_set_notify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[28] = argv[2];
	argv[0]->c.obj.iv[29] = argv[3];
	w = argv[0];
	local[0]= w;
XtextBLK2371:
	ctx->vsp=local; return(local[0]);}

/*:show-cursor*/
static pointer XtextM2372textwindow_show_cursor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[26] = argv[2];
	local[0]= argv[0];
	local[1]= fqv[27];
	if (argv[0]->c.obj.iv[27]==NIL) goto XtextIF2374;
	local[2]= fqv[28];
	goto XtextIF2375;
XtextIF2374:
	local[2]= fqv[29];
XtextIF2375:
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XtextBLK2373:
	ctx->vsp=local; return(local[0]);}

/*:cursor*/
static pointer XtextM2376textwindow_cursor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2379;}
	local[0]= fqv[30];
XtextENT2379:
XtextENT2378:
	if (n>3) maerror();
	if (argv[0]->c.obj.iv[26]==NIL) goto XtextIF2380;
	local[1]= local[0];
	if (fqv[30]==local[1]) goto XtextOR2382;
	local[1]= local[0];
	if (fqv[28]!=local[1]) goto XtextAND2383;
	if (argv[0]->c.obj.iv[27]!=NIL) goto XtextAND2383;
	goto XtextOR2382;
XtextAND2383:
	local[1]= local[0];
	if (fqv[29]!=local[1]) goto XtextAND2384;
	if (argv[0]->c.obj.iv[27]==NIL) goto XtextAND2384;
	goto XtextOR2382;
XtextAND2384:
	goto XtextIF2380;
XtextOR2382:
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[31];
	local[3]= fqv[32];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= loadglobal(fqv[33]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= argv[0]->c.obj.iv[19];
	local[6]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)2L);
	local[7]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,7,local+1,&ftab[3],fqv[34]); /*fillrectangle*/
	argv[0]->c.obj.iv[27] = ((argv[0]->c.obj.iv[27])==NIL?T:NIL);
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[31];
	local[3]= fqv[35];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto XtextIF2381;
XtextIF2380:
	local[1]= NIL;
XtextIF2381:
	w = local[1];
	local[0]= w;
XtextBLK2377:
	ctx->vsp=local; return(local[0]);}

/*:win-row*/
static pointer XtextM2385textwindow_win_row(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
XtextBLK2386:
	ctx->vsp=local; return(local[0]);}

/*:win-col*/
static pointer XtextM2387textwindow_win_col(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[21];
	local[0]= w;
XtextBLK2388:
	ctx->vsp=local; return(local[0]);}

/*:win-row-max*/
static pointer XtextM2389textwindow_win_row_max(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
XtextBLK2390:
	ctx->vsp=local; return(local[0]);}

/*:win-col-max*/
static pointer XtextM2391textwindow_win_col_max(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
XtextBLK2392:
	ctx->vsp=local; return(local[0]);}

/*:xy*/
static pointer XtextM2393textwindow_xy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2397;}
	local[0]= argv[0]->c.obj.iv[20];
XtextENT2397:
	if (n>=4) { local[1]=(argv[3]); goto XtextENT2396;}
	local[1]= argv[0]->c.obj.iv[21];
XtextENT2396:
XtextENT2395:
	if (n>4) maerror();
	local[2]= makeint((eusinteger_t)2L);
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	argv[0]->c.obj.iv[18] = w;
	local[2]= makeint((eusinteger_t)2L);
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,3,local+2); /*+*/
	argv[0]->c.obj.iv[19] = w;
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
XtextBLK2394:
	ctx->vsp=local; return(local[0]);}

/*:goto*/
static pointer XtextM2398textwindow_goto(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XtextENT2401;}
	local[0]= fqv[28];
XtextENT2401:
XtextENT2400:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= fqv[27];
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MAX(ctx,2,local+2); /*max*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	argv[0]->c.obj.iv[20] = w;
	local[1]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= argv[3];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MAX(ctx,2,local+2); /*max*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	argv[0]->c.obj.iv[21] = w;
	local[1]= argv[0];
	local[2]= fqv[27];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
XtextBLK2399:
	ctx->vsp=local; return(local[0]);}

/*:goback*/
static pointer XtextM2402textwindow_goback(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2405;}
	local[0]= fqv[28];
XtextENT2405:
XtextENT2404:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[36];
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAX(ctx,2,local+4); /*max*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XtextBLK2403:
	ctx->vsp=local; return(local[0]);}

/*:advance*/
static pointer XtextM2406textwindow_advance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2409;}
	local[0]= makeint((eusinteger_t)1L);
XtextENT2409:
XtextENT2408:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[21];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[0]->c.obj.iv[21] = w;
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[21];
	local[3]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[0]->c.obj.iv[20] = w;
	local[1]= argv[0]->c.obj.iv[21];
	local[2]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+3;
	w=(pointer)MOD(ctx,2,local+1); /*mod*/
	argv[0]->c.obj.iv[21] = w;
	w = argv[0]->c.obj.iv[21];
	local[0]= w;
XtextBLK2407:
	ctx->vsp=local; return(local[0]);}

/*:scroll*/
static pointer XtextM2410textwindow_scroll(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2413;}
	local[0]= makeint((eusinteger_t)1L);
XtextENT2413:
XtextENT2412:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto XtextCON2415;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto XtextBLK2411;
	goto XtextCON2414;
XtextCON2415:
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto XtextCON2416;
	local[2] = local[0];
	local[3] = makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[16];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[4] = w;
	local[5]= local[4];
	goto XtextCON2414;
XtextCON2416:
	local[2] = makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[3] = w;
	local[4] = makeint((eusinteger_t)0L);
	local[5]= local[4];
	goto XtextCON2414;
XtextCON2417:
	local[5]= NIL;
XtextCON2414:
	local[5]= argv[0]->c.obj.iv[16];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	local[0] = w;
	local[5]= loadglobal(fqv[33]);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= argv[0]->c.obj.iv[2];
	local[8]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)2L);
	local[11]= local[2];
	local[12]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[5];
	local[12]= argv[0]->c.obj.iv[16];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,2,local+12); /*-*/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	local[14]= makeint((eusinteger_t)2L);
	local[15]= local[3];
	local[16]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)PLUS(ctx,2,local+14); /*+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[4])(ctx,10,local+5,&ftab[4],fqv[37]); /*copyarea*/
	local[5]= loadglobal(fqv[33]);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[4];
	local[10]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[5];
	local[10]= local[0];
	local[11]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,7,local+5,&ftab[5],fqv[38]); /*cleararea*/
	local[0]= w;
XtextBLK2411:
	ctx->vsp=local; return(local[0]);}

/*:horizontal-scroll*/
static pointer XtextM2418textwindow_horizontal_scroll(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2421;}
	local[0]= makeint((eusinteger_t)1L);
XtextENT2421:
XtextENT2420:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto XtextCON2423;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto XtextBLK2419;
	goto XtextCON2422;
XtextCON2423:
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto XtextCON2424;
	local[2] = local[0];
	local[3] = makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[4] = w;
	local[5]= local[4];
	goto XtextCON2422;
XtextCON2424:
	local[2] = makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[3] = w;
	local[4] = makeint((eusinteger_t)0L);
	local[5]= local[4];
	goto XtextCON2422;
XtextCON2425:
	local[5]= NIL;
XtextCON2422:
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	local[0] = w;
	local[5]= loadglobal(fqv[33]);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= argv[0]->c.obj.iv[2];
	local[8]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= local[2];
	local[11]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)2L);
	local[11]= argv[0]->c.obj.iv[17];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[6];
	local[13]= makeint((eusinteger_t)2L);
	local[14]= local[3];
	local[15]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(*ftab[4])(ctx,10,local+5,&ftab[4],fqv[37]); /*copyarea*/
	local[5]= loadglobal(fqv[33]);
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[4];
	local[9]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[0];
	local[10]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= argv[0]->c.obj.iv[6];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,7,local+5,&ftab[5],fqv[38]); /*cleararea*/
	local[0]= w;
XtextBLK2419:
	ctx->vsp=local; return(local[0]);}

/*:newline*/
static pointer XtextM2426textwindow_newline(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[21] = makeint((eusinteger_t)0L);
	local[0]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[20] = w;
	local[0]= argv[0]->c.obj.iv[20];
	local[1]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto XtextIF2428;
	local[0]= argv[0];
	local[1]= fqv[39];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[0]->c.obj.iv[20] = w;
	local[0]= argv[0]->c.obj.iv[20];
	goto XtextIF2429;
XtextIF2428:
	local[0]= NIL;
XtextIF2429:
	w = local[0];
	local[0]= w;
XtextBLK2427:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer XtextM2430textwindow_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	argv[0]->c.obj.iv[20] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[21] = makeint((eusinteger_t)0L);
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[28];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = argv[0];
	local[0]= w;
XtextBLK2431:
	ctx->vsp=local; return(local[0]);}

/*:clear-eol*/
static pointer XtextM2432textwindow_clear_eol(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2437;}
	local[0]= argv[0]->c.obj.iv[20];
XtextENT2437:
	if (n>=4) { local[1]=(argv[3]); goto XtextENT2436;}
	local[1]= argv[0]->c.obj.iv[21];
XtextENT2436:
	if (n>=5) { local[2]=(argv[4]); goto XtextENT2435;}
	local[2]= fqv[28];
XtextENT2435:
XtextENT2434:
	if (n>5) maerror();
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= fqv[29];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= fqv[17];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= local[1];
	local[8]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= fqv[18];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[0];
	local[10]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= fqv[12];
	local[10]= argv[0]->c.obj.iv[13];
	local[11]= argv[0]->c.obj.iv[17];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= fqv[13];
	local[12]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,10,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0]= w;
XtextBLK2433:
	ctx->vsp=local; return(local[0]);}

/*:clear-lines*/
static pointer XtextM2438textwindow_clear_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2441;}
	local[0]= argv[0]->c.obj.iv[20];
XtextENT2441:
XtextENT2440:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[27];
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= fqv[17];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= fqv[18];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= local[0];
	local[8]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= fqv[12];
	local[8]= argv[0]->c.obj.iv[5];
	local[9]= fqv[13];
	local[10]= argv[0]->c.obj.iv[14];
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,10,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[27];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
XtextBLK2439:
	ctx->vsp=local; return(local[0]);}

/*:clear-eos*/
static pointer XtextM2442textwindow_clear_eos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2446;}
	local[0]= argv[0]->c.obj.iv[20];
XtextENT2446:
	if (n>=4) { local[1]=(argv[3]); goto XtextENT2445;}
	local[1]= argv[0]->c.obj.iv[21];
XtextENT2445:
XtextENT2444:
	if (n>4) maerror();
	local[2]= argv[0];
	local[3]= fqv[27];
	local[4]= fqv[29];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[40];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[16];
	local[4]= fqv[17];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= fqv[18];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= fqv[12];
	local[9]= argv[0]->c.obj.iv[5];
	local[10]= fqv[13];
	local[11]= argv[0]->c.obj.iv[14];
	local[12]= argv[0]->c.obj.iv[16];
	local[13]= local[0];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,3,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,10,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[27];
	local[4]= fqv[28];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
XtextBLK2443:
	ctx->vsp=local; return(local[0]);}

/*:clear-in-line*/
static pointer XtextM2447textwindow_clear_in_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= fqv[17];
	local[3]= makeint((eusinteger_t)2L);
	local[4]= argv[0]->c.obj.iv[13];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= fqv[18];
	local[5]= makeint((eusinteger_t)2L);
	local[6]= argv[0]->c.obj.iv[14];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	local[6]= fqv[12];
	local[7]= argv[0]->c.obj.iv[13];
	local[8]= argv[4];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= fqv[13];
	local[9]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,10,local+0); /*send*/
	local[0]= w;
XtextBLK2448:
	ctx->vsp=local; return(local[0]);}

/*:clear-text-area*/
static pointer XtextM2449textwindow_clear_text_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto XtextIF2451;
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	goto XtextIF2452;
XtextIF2451:
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
XtextIF2452:
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextIF2453;
	local[0]= argv[0];
	local[1]= fqv[42];
	local[2]= argv[4];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,3,local+2); /*-*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XtextIF2454;
XtextIF2453:
	local[0]= NIL;
XtextIF2454:
	local[0]= argv[4];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto XtextIF2455;
	local[0]= argv[0];
	local[1]= fqv[41];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	goto XtextIF2456;
XtextIF2455:
	local[0]= NIL;
XtextIF2456:
	w = local[0];
	local[0]= w;
XtextBLK2450:
	ctx->vsp=local; return(local[0]);}

/*:putch*/
static pointer XtextM2457textwindow_putch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	local[1]= local[0];
	if (fqv[43]!=local[1]) goto XtextIF2459;
	local[1]= argv[0];
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto XtextIF2460;
XtextIF2459:
	local[1]= local[0];
	if (fqv[45]!=local[1]) goto XtextIF2461;
	local[1]= argv[0];
	local[2]= fqv[36];
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= argv[0]->c.obj.iv[21];
	local[5]= makeint((eusinteger_t)8L);
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)8L);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)8L);
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XtextIF2462;
XtextIF2461:
	if (T==NIL) goto XtextIF2463;
	local[1]= argv[0];
	local[2]= fqv[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[22];
	local[2]= makeint((eusinteger_t)0L);
	w = argv[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.str.chars[i]=intval(w);}
	local[1]= argv[0];
	local[2]= fqv[46];
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[47];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	if (w==NIL) goto XtextIF2465;
	local[1]= argv[0];
	local[2]= fqv[39];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[0]->c.obj.iv[20] = w;
	local[1]= argv[0]->c.obj.iv[20];
	goto XtextIF2466;
XtextIF2465:
	local[1]= NIL;
XtextIF2466:
	local[1]= argv[2];
	goto XtextIF2464;
XtextIF2463:
	local[1]= NIL;
XtextIF2464:
XtextIF2462:
XtextIF2460:
	w = local[1];
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[28];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XtextBLK2458:
	ctx->vsp=local; return(local[0]);}

/*:putstring*/
static pointer XtextM2467textwindow_putstring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2470;}
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
XtextENT2470:
XtextENT2469:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
	local[7]= fqv[27];
	local[8]= fqv[29];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
XtextWHL2471:
	local[6]= local[3];
	w = local[0];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto XtextWHX2472;
	local[6]= argv[0]->c.obj.iv[17];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[1] = w;
	local[6]= makeint((eusinteger_t)10L);
	local[7]= argv[2];
	local[8]= fqv[48];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,4,local+6,&ftab[6],fqv[49]); /*position*/
	local[2] = w;
	local[6]= argv[0]->c.obj.iv[17];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	if (local[2]==NIL) goto XtextIF2474;
	local[7]= local[2];
	goto XtextIF2475;
XtextIF2474:
	local[7]= local[0];
XtextIF2475:
	ctx->vsp=local+8;
	w=(pointer)MIN(ctx,2,local+6); /*min*/
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[40];
	local[8]= argv[0]->c.obj.iv[20];
	local[9]= argv[0]->c.obj.iv[21];
	local[10]= fqv[29];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[19];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[20];
	local[8]= argv[0]->c.obj.iv[18];
	local[9]= argv[0]->c.obj.iv[19];
	local[10]= argv[2];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,7,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[47];
	local[8]= local[4];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	if (local[2]==NIL) goto XtextIF2476;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[44];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto XtextIF2477;
XtextIF2476:
	local[6]= NIL;
XtextIF2477:
	local[3] = local[4];
	goto XtextWHL2471;
XtextWHX2472:
	local[6]= NIL;
XtextBLK2473:
	local[6]= argv[0];
	local[7]= fqv[27];
	local[8]= fqv[28];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[0]= w;
XtextBLK2468:
	ctx->vsp=local; return(local[0]);}

/*:insert*/
static pointer XtextM2478textwindow_insert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[50];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XtextBLK2479:
	ctx->vsp=local; return(local[0]);}

/*:event-row*/
static pointer XtextM2480textwindow_event_row(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= loadglobal(fqv[51]);
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,1,local+3,&ftab[7],fqv[52]); /*event-y*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2481:
	ctx->vsp=local; return(local[0]);}

/*:event-col*/
static pointer XtextM2482textwindow_event_col(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= loadglobal(fqv[51]);
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,1,local+3,&ftab[8],fqv[53]); /*event-x*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2483:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XtextM2484textwindow_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= fqv[29];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2485:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XtextM2486textwindow_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[36];
	local[5]= argv[0];
	local[6]= fqv[54];
	local[7]= loadglobal(fqv[51]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[55];
	local[8]= loadglobal(fqv[51]);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2487:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XtextM2488textwindow_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[56];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)4L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	argv[0]->c.obj.iv[17] = w;
	local[0]= argv[0]->c.obj.iv[6];
	local[1]= makeint((eusinteger_t)4L);
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	argv[0]->c.obj.iv[16] = w;
	local[0]= argv[0];
	local[1]= fqv[36];
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
XtextBLK2489:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer XtextM2490textwindow_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[57]); /*/=*/
	if (w!=NIL) goto XtextOR2494;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[57]); /*/=*/
	if (w!=NIL) goto XtextOR2494;
	goto XtextIF2492;
XtextOR2494:
	local[5]= argv[0];
	local[6]= fqv[56];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto XtextIF2493;
XtextIF2492:
	local[5]= NIL;
XtextIF2493:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2491:
	ctx->vsp=local; return(local[0]);}

/*:echo*/
static pointer XtextM2495textwindow_echo(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[25] = argv[2];
	w = argv[0]->c.obj.iv[25];
	local[0]= w;
XtextBLK2496:
	ctx->vsp=local; return(local[0]);}

/*:getstring*/
static pointer XtextM2497textwindow_getstring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[23];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
	argv[0]->c.obj.iv[24] = makeint((eusinteger_t)0L);
	w = local[0];
	local[0]= w;
XtextBLK2498:
	ctx->vsp=local; return(local[0]);}

/*:enternotify*/
static pointer XtextM2499textwindow_enternotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	if (argv[0]->c.obj.iv[2]==NIL) goto XtextIF2501;
	local[3]= loadglobal(fqv[33]);
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,4,local+3,&ftab[10],fqv[58]); /*setinputfocus*/
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= fqv[28];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XtextIF2502;
XtextIF2501:
	local[3]= NIL;
XtextIF2502:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2500:
	ctx->vsp=local; return(local[0]);}

/*:leavenotify*/
static pointer XtextM2503textwindow_leavenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= fqv[29];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2504:
	ctx->vsp=local; return(local[0]);}

/*:keyrelease*/
static pointer XtextM2505textwindow_keyrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= NIL;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2506:
	ctx->vsp=local; return(local[0]);}

/*:lineenter*/
static pointer XtextM2507textwindow_lineenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2510;}
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
XtextENT2510:
XtextENT2509:
	if (n>4) maerror();
	local[1]= argv[2];
	if (argv[0]->c.obj.iv[23]==local[1]) goto XtextIF2511;
	local[1]= argv[0]->c.obj.iv[23];
	local[2]= argv[2];
	local[3]= fqv[59];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,4,local+1,&ftab[11],fqv[60]); /*replace*/
	local[1]= w;
	goto XtextIF2512;
XtextIF2511:
	local[1]= NIL;
XtextIF2512:
	w = local[1];
	local[0]= w;
XtextBLK2508:
	ctx->vsp=local; return(local[0]);}

/*:keyenter*/
static pointer XtextM2513textwindow_keyenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2516;}
	local[0]= NIL;
XtextENT2516:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
XtextENT2515:
	if (n>4) maerror();
	local[3]= argv[0];
	local[4]= fqv[61];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)10L);
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w==NIL) goto XtextIF2517;
	if (argv[0]->c.obj.iv[28]==NIL) goto XtextIF2517;
	if (argv[0]->c.obj.iv[29]==NIL) goto XtextIF2517;
	local[3]= argv[0]->c.obj.iv[28];
	local[4]= argv[0]->c.obj.iv[29];
	local[5]= loadglobal(fqv[51]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto XtextIF2518;
XtextIF2517:
	local[3]= NIL;
XtextIF2518:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2514:
	ctx->vsp=local; return(local[0]);}

/*:fill*/
static pointer XtextM2519textwindowstream_fill(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XtextBLK2520:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer XtextM2521textwindowstream_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[3];
XtextWHL2523:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto XtextWHX2524;
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= fqv[50];
	local[4]= argv[0]->c.obj.iv[2];
	{ register eusinteger_t i=intval(local[0]);
	  w=makeint(local[4]->c.str.chars[i]);}
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto XtextWHL2523;
XtextWHX2524:
	local[2]= NIL;
XtextBLK2525:
	w = NIL;
	ctx->vsp=local+0;
	w=(*ftab[12])(ctx,0,local+0,&ftab[12],fqv[63]); /*xflush*/
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
XtextBLK2522:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer XtextM2526textwindowstream_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[64];
	local[3]= argv[3];
	local[4]= makeint((eusinteger_t)256L);
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	argv[0]->c.obj.iv[5] = argv[2];
	w = argv[0];
	local[0]= w;
XtextBLK2527:
	ctx->vsp=local; return(local[0]);}

/*make-textwindow-stream*/
static pointer XtextF2327make_textwindow_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[65]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[64];
	local[3]= argv[0];
	local[4]= fqv[66];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
	local[1]= loadglobal(fqv[65]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[64];
	local[4]= argv[0];
	local[5]= fqv[67];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[68]); /*make-two-way-stream*/
	local[0]= w;
XtextBLK2528:
	ctx->vsp=local; return(local[0]);}

/*expand-tab*/
static pointer XtextF2328expand_tab(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto XtextENT2531;}
	local[0]= makeint((eusinteger_t)0L);
XtextENT2531:
XtextENT2530:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)9L);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,2,local+1,&ftab[14],fqv[69]); /*count*/
	local[1]= w;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w==NIL) goto XtextIF2532;
	local[6]= argv[0];
	goto XtextIF2533;
XtextIF2532:
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)8L);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,1,local+6,&ftab[2],fqv[23]); /*make-string*/
	local[5] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
XtextWHL2534:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto XtextWHX2535;
	local[8]= argv[0];
	{ register eusinteger_t i=intval(local[6]);
	  w=makeint(local[8]->c.str.chars[i]);}
	local[2] = w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)9L);
	ctx->vsp=local+10;
	w=(pointer)EQ(ctx,2,local+8); /*eql*/
	if (w==NIL) goto XtextCON2538;
	local[8]= makeint((eusinteger_t)8L);
	local[9]= local[0];
	w = local[3];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	local[10]= makeint((eusinteger_t)8L);
	ctx->vsp=local+11;
	w=(pointer)MOD(ctx,2,local+9); /*mod*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[4] = w;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)32L);
	local[10]= fqv[48];
	local[11]= local[3];
	local[12]= fqv[70];
	local[13]= local[3];
	w = local[4];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[13]= (pointer)((eusinteger_t)local[13] + (eusinteger_t)w);
	ctx->vsp=local+14;
	w=(*ftab[15])(ctx,6,local+8,&ftab[15],fqv[71]); /*fill*/
	local[8]= local[3];
	w = local[4];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[3] = (pointer)((eusinteger_t)local[8] + (eusinteger_t)w);
	local[8]= local[3];
	goto XtextCON2537;
XtextCON2538:
	local[8]= local[5];
	local[9]= local[3];
	w = local[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[9]); v=local[8];
	  v->c.str.chars[i]=intval(w);}
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[3] = w;
	local[8]= local[3];
	goto XtextCON2537;
XtextCON2539:
	local[8]= NIL;
XtextCON2537:
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto XtextWHL2534;
XtextWHX2535:
	local[8]= NIL;
XtextBLK2536:
	w = NIL;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[6]= w;
XtextIF2533:
	w = local[6];
	local[0]= w;
XtextBLK2529:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XtextM2540buffertextwindow_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XtextRST2542:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[9]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[10]));
	local[4]= fqv[11];
	local[5]= fqv[14];
	local[6]= fqv[72];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,7,local+1); /*apply*/
	w = argv[0];
	local[0]= w;
XtextBLK2541:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XtextM2543buffertextwindow_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XtextBLK2544:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer XtextM2545buffertextwindow_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= fqv[74];
	local[2]= T;
	ctx->vsp=local+3;
	w=(*ftab[16])(ctx,3,local+0,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[31] = w;
	local[0]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= fqv[74];
	local[2]= T;
	ctx->vsp=local+3;
	w=(*ftab[16])(ctx,3,local+0,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[32] = w;
	w = argv[0];
	local[0]= w;
XtextBLK2546:
	ctx->vsp=local; return(local[0]);}

/*:refresh-line*/
static pointer XtextM2547buffertextwindow_refresh_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2551;}
	local[0]= argv[0]->c.obj.iv[20];
XtextENT2551:
	if (n>=4) { local[1]=(argv[3]); goto XtextENT2550;}
	local[1]= argv[0]->c.obj.iv[21];
XtextENT2550:
XtextENT2549:
	if (n>4) maerror();
	local[2]= argv[0];
	local[3]= fqv[40];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[19];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= argv[0]->c.obj.iv[19];
	local[6]= argv[0]->c.obj.iv[32];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[0]= w;
XtextBLK2548:
	ctx->vsp=local; return(local[0]);}

/*:refresh*/
static pointer XtextM2552buffertextwindow_refresh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2555;}
	local[0]= makeint((eusinteger_t)0L);
XtextENT2555:
XtextENT2554:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[21];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
XtextWHL2556:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto XtextWHX2557;
	local[5]= argv[0];
	local[6]= fqv[76];
	local[7]= local[3];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto XtextWHL2556;
XtextWHX2557:
	local[5]= NIL;
XtextBLK2558:
	w = NIL;
	argv[0]->c.obj.iv[20] = local[1];
	argv[0]->c.obj.iv[21] = local[2];
	w = argv[0]->c.obj.iv[21];
	local[0]= w;
XtextBLK2553:
	ctx->vsp=local; return(local[0]);}

/*:refresh-in-line*/
static pointer XtextM2559buffertextwindow_refresh_in_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w!=NIL) goto XtextIF2561;
	w = NIL;
	ctx->vsp=local+0;
	local[0]=w;
	goto XtextBLK2560;
	goto XtextIF2562;
XtextIF2561:
	local[0]= NIL;
XtextIF2562:
	local[0]= argv[0];
	local[1]= fqv[19];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[32];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[4];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	argv[4] = w;
	local[1]= argv[0];
	local[2]= fqv[46];
	local[3]= argv[0]->c.obj.iv[18];
	local[4]= argv[0]->c.obj.iv[19];
	local[5]= local[0];
	local[6]= argv[3];
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[0]= w;
XtextBLK2560:
	ctx->vsp=local; return(local[0]);}

/*:refresh-lines*/
static pointer XtextM2563buffertextwindow_refresh_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[2];
XtextWHL2565:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto XtextWHX2566;
	local[2]= argv[3];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w!=NIL) goto XtextIF2568;
	w = NIL;
	ctx->vsp=local+2;
	local[2]=w;
	goto XtextBLK2567;
	goto XtextIF2569;
XtextIF2568:
	local[2]= NIL;
XtextIF2569:
	local[2]= argv[0];
	local[3]= fqv[19];
	local[4]= argv[3];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[46];
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= argv[0]->c.obj.iv[19];
	local[6]= argv[0]->c.obj.iv[32];
	local[7]= argv[3];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto XtextWHL2565;
XtextWHX2566:
	local[2]= NIL;
XtextBLK2567:
	w = NIL;
	local[0]= w;
XtextBLK2564:
	ctx->vsp=local; return(local[0]);}

/*:refresh-area*/
static pointer XtextM2570buffertextwindow_refresh_area(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w!=NIL) goto XtextOR2574;
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto XtextAND2575;
	local[0]= argv[3];
	local[1]= argv[5];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto XtextAND2575;
	goto XtextOR2574;
XtextAND2575:
	goto XtextIF2572;
XtextOR2574:
	local[0]= argv[4];
	local[1]= argv[5];
	local[2]= argv[2];
	local[3]= argv[3];
	argv[2] = local[0];
	argv[3] = local[1];
	argv[4] = local[2];
	argv[5] = local[3];
	w = NIL;
	local[0]= w;
	goto XtextIF2573;
XtextIF2572:
	local[0]= NIL;
XtextIF2573:
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto XtextIF2576;
	local[0]= argv[0];
	local[1]= fqv[77];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	goto XtextIF2577;
XtextIF2576:
	local[0]= argv[0];
	local[1]= fqv[77];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
XtextIF2577:
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextIF2578;
	local[0]= argv[0];
	local[1]= fqv[78];
	local[2]= argv[4];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,3,local+2); /*-*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XtextIF2579;
XtextIF2578:
	local[0]= NIL;
XtextIF2579:
	local[0]= argv[4];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto XtextIF2580;
	local[0]= argv[0];
	local[1]= fqv[77];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,5,local+0); /*send*/
	local[0]= w;
	goto XtextIF2581;
XtextIF2580:
	local[0]= NIL;
XtextIF2581:
	w = local[0];
	local[0]= w;
XtextBLK2571:
	ctx->vsp=local; return(local[0]);}

/*:highlight*/
static pointer XtextM2582buffertextwindow_highlight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	if (argv[2]==NIL) goto XtextIF2584;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[79];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto XtextIF2585;
XtextIF2584:
	local[0]= NIL;
XtextIF2585:
	local[0]= argv[0];
	local[1]= fqv[80];
	local[2]= argv[3];
	local[3]= argv[4];
	local[4]= argv[5];
	local[5]= argv[6];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	if (argv[2]==NIL) goto XtextIF2586;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[79];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto XtextIF2587;
XtextIF2586:
	local[0]= NIL;
XtextIF2587:
	w = local[0];
	local[0]= w;
XtextBLK2583:
	ctx->vsp=local; return(local[0]);}

/*:goto*/
static pointer XtextM2588buffertextwindow_goto(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XtextENT2591;}
	local[0]= fqv[28];
XtextENT2591:
XtextENT2590:
	if (n>5) maerror();
	local[1]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto XtextIF2592;
	local[1]= argv[0]->c.obj.iv[31];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	goto XtextIF2593;
XtextIF2592:
	local[1]= makeint((eusinteger_t)0L);
XtextIF2593:
	argv[3] = local[1];
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[10]));
	local[3]= fqv[36];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,6,local+1); /*send-message*/
	local[0]= w;
XtextBLK2589:
	ctx->vsp=local; return(local[0]);}

/*:line*/
static pointer XtextM2594buffertextwindow_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextIF2596;
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	goto XtextIF2597;
XtextIF2596:
	local[0]= NIL;
XtextIF2597:
	w = local[0];
	local[0]= w;
XtextBLK2595:
	ctx->vsp=local; return(local[0]);}

/*:lines*/
static pointer XtextM2598buffertextwindow_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
XtextBLK2599:
	ctx->vsp=local; return(local[0]);}

/*:nlines*/
static pointer XtextM2600buffertextwindow_nlines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
XtextBLK2601:
	ctx->vsp=local; return(local[0]);}

/*:all-lines*/
static pointer XtextM2602buffertextwindow_all_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
XtextBLK2603:
	ctx->vsp=local; return(local[0]);}

/*:max-line-length*/
static pointer XtextM2604buffertextwindow_max_line_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= (pointer)get_sym_func(fqv[81]);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= loadglobal(fqv[82]);
	local[3]= (pointer)get_sym_func(fqv[83]);
	local[4]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,3,local+2); /*map*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	argv[0]->c.obj.iv[33] = w;
	w = argv[0]->c.obj.iv[33];
	local[0]= w;
XtextBLK2605:
	ctx->vsp=local; return(local[0]);}

/*:read-file*/
static pointer XtextM2606buffertextwindow_read_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[17])(ctx,1,local+0,&ftab[17],fqv[84]); /*open*/
	local[0]= w;
	ctx->vsp=local+1;
	w = makeclosure(codevec,quotevec,XtextUWP2608,env,argv,local);
	local[1]=(pointer)(ctx->protfp); local[2]=w;
	ctx->protfp=(struct protectframe *)(local+1);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	w = NIL;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[0];
	local[6]= NIL;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)READLINE(ctx,3,local+5); /*read-line*/
	local[5]= w;
XtextTAG2610:
	local[6]= local[5];
	if (local[4]!=local[6]) goto XtextIF2611;
	w = NIL;
	ctx->vsp=local+6;
	local[3]=w;
	goto XtextBLK2609;
	goto XtextIF2612;
XtextIF2611:
	local[6]= NIL;
XtextIF2612:
	local[6]= local[5];
	local[7]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+8;
	w=(pointer)VECTOREXPUSH(ctx,2,local+6); /*vector-push-extend*/
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)XtextF2328expand_tab(ctx,1,local+6); /*expand-tab*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[32];
	ctx->vsp=local+8;
	w=(pointer)VECTOREXPUSH(ctx,2,local+6); /*vector-push-extend*/
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[3] = w;
	local[6]= local[0];
	local[7]= NIL;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)READLINE(ctx,3,local+6); /*read-line*/
	local[5] = w;
	ctx->vsp=local+6;
	goto XtextTAG2610;
	w = NIL;
	local[3]= w;
XtextBLK2609:
	w = local[3];
	ctx->vsp=local+3;
	XtextUWP2608(ctx,0,local+3,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = T;
	local[0]= w;
XtextBLK2607:
	ctx->vsp=local; return(local[0]);}

/*:display-line-string*/
static pointer XtextM2613buffertextwindow_display_line_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[86],w);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= T;
XtextWHL2615:
	if (local[6]==NIL) goto XtextWHX2616;
	local[7]= makeint((eusinteger_t)10L);
	local[8]= loadglobal(fqv[86]);
	local[9]= fqv[48];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,4,local+7,&ftab[6],fqv[49]); /*position*/
	local[4] = w;
	if (local[4]!=NIL) goto XtextCON2619;
	local[7]= loadglobal(fqv[86]);
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,2,local+7); /*subseq*/
	local[7]= w;
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[6] = NIL;
	local[7]= local[6];
	goto XtextCON2618;
XtextCON2619:
	local[7]= loadglobal(fqv[86]);
	local[8]= local[5];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	local[7]= local[5];
	goto XtextCON2618;
XtextCON2620:
	local[7]= NIL;
XtextCON2618:
	goto XtextWHL2615;
XtextWHX2616:
	local[7]= NIL;
XtextBLK2617:
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= fqv[87];
	local[9]= local[3];
	local[10]= fqv[74];
	local[11]= T;
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,5,local+7,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[31] = w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= fqv[87];
	local[9]= local[3];
	local[10]= fqv[74];
	local[11]= T;
	ctx->vsp=local+12;
	w=(*ftab[16])(ctx,5,local+7,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[32] = w;
	argv[0]->c.obj.iv[34] = NIL;
	local[7]= argv[0];
	local[8]= fqv[85];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[73];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[3]= T;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2614:
	ctx->vsp=local; return(local[0]);}

/*:display-strings*/
static pointer XtextM2621buffertextwindow_display_strings(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= fqv[87];
	local[2]= argv[2];
	local[3]= fqv[74];
	local[4]= T;
	ctx->vsp=local+5;
	w=(*ftab[16])(ctx,5,local+0,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[31] = w;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	local[1]= fqv[87];
	local[2]= argv[2];
	local[3]= fqv[74];
	local[4]= T;
	ctx->vsp=local+5;
	w=(*ftab[16])(ctx,5,local+0,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[32] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
XtextWHL2623:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto XtextWHX2624;
	local[2]= argv[0]->c.obj.iv[32];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[32];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XtextF2328expand_tab(ctx,1,local+4); /*expand-tab*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto XtextWHL2623;
XtextWHX2624:
	local[2]= NIL;
XtextBLK2625:
	w = NIL;
	argv[0]->c.obj.iv[34] = NIL;
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
XtextBLK2622:
	ctx->vsp=local; return(local[0]);}

/*:insert-string*/
static pointer XtextM2626buffertextwindow_insert_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2629;}
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
XtextENT2629:
XtextENT2628:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[31];
	local[2]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= local[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,1,local+3,&ftab[2],fqv[23]); /*make-string*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= local[3];
	local[5]= local[1];
	local[6]= fqv[59];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,4,local+4,&ftab[11],fqv[60]); /*replace*/
	local[4]= local[3];
	local[5]= argv[2];
	local[6]= fqv[88];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,4,local+4,&ftab[11],fqv[60]); /*replace*/
	local[4]= local[3];
	local[5]= local[1];
	local[6]= fqv[88];
	local[7]= argv[0]->c.obj.iv[21];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= fqv[89];
	local[9]= argv[0]->c.obj.iv[21];
	local[10]= fqv[59];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[11])(ctx,8,local+4,&ftab[11],fqv[60]); /*replace*/
	local[4]= argv[0]->c.obj.iv[31];
	local[5]= argv[0]->c.obj.iv[20];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= argv[0]->c.obj.iv[32];
	local[5]= argv[0]->c.obj.iv[20];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)XtextF2328expand_tab(ctx,1,local+6); /*expand-tab*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= argv[0];
	local[5]= fqv[76];
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[47];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[28];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[0]= w;
XtextBLK2627:
	ctx->vsp=local; return(local[0]);}

/*:insert*/
static pointer XtextM2630buffertextwindow_insert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[23]); /*make-string*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= fqv[29];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[2];
	local[4]= local[0];
	local[5]= fqv[59];
	local[6]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,4,local+3,&ftab[11],fqv[60]); /*replace*/
	local[3]= local[2];
	local[4]= argv[0]->c.obj.iv[21];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[3]= local[2];
	local[4]= local[0];
	local[5]= fqv[88];
	local[6]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	local[7]= fqv[89];
	local[8]= argv[0]->c.obj.iv[21];
	local[9]= fqv[59];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[11])(ctx,8,local+3,&ftab[11],fqv[60]); /*replace*/
	local[3]= argv[0]->c.obj.iv[31];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[3]= argv[0]->c.obj.iv[32];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)XtextF2328expand_tab(ctx,1,local+5); /*expand-tab*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[3]= argv[0];
	local[4]= fqv[47];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[76];
	local[5]= argv[0]->c.obj.iv[20];
	local[6]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+7;
	w=(pointer)SUB1(ctx,1,local+6); /*1-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= argv[0];
	local[4]= fqv[27];
	local[5]= fqv[28];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0]= w;
XtextBLK2631:
	ctx->vsp=local; return(local[0]);}

/*:delete*/
static pointer XtextM2632buffertextwindow_delete(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[21];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto XtextIF2634;
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[27];
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= local[0];
	local[2]= local[0];
	local[3]= fqv[88];
	local[4]= argv[0]->c.obj.iv[21];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= fqv[89];
	local[6]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+7;
	w=(*ftab[11])(ctx,6,local+1,&ftab[11],fqv[60]); /*replace*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[0] = w;
	local[1]= argv[0]->c.obj.iv[31];
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[1]= argv[0]->c.obj.iv[32];
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XtextF2328expand_tab(ctx,1,local+3); /*expand-tab*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[1]= argv[0]->c.obj.iv[21];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	argv[0]->c.obj.iv[21] = w;
	local[1]= argv[0];
	local[2]= fqv[76];
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[27];
	local[3]= fqv[28];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
	goto XtextIF2635;
XtextIF2634:
	local[0]= NIL;
XtextIF2635:
	w = local[0];
	local[0]= w;
XtextBLK2633:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer XtextUWP2608(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[0];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:keyenter*/
static pointer XtextM2636buffertextwindow_keyenter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2639;}
	local[0]= NIL;
XtextENT2639:
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
XtextENT2638:
	if (n>4) maerror();
	local[3]= argv[2];
	local[4]= local[3];
	w = fqv[90];
	if (memq(local[4],w)==NIL) goto XtextIF2640;
	local[4]= argv[0];
	local[5]= fqv[91];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto XtextIF2641;
XtextIF2640:
	local[4]= local[3];
	if (fqv[92]!=local[4]) goto XtextIF2642;
	local[4]= argv[0];
	local[5]= fqv[93];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextIF2643;
XtextIF2642:
	local[4]= local[3];
	if (fqv[94]!=local[4]) goto XtextIF2644;
	local[4]= argv[0];
	local[5]= fqv[73];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto XtextIF2645;
XtextIF2644:
	local[4]= local[3];
	if (fqv[95]!=local[4]) goto XtextIF2646;
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= fqv[96];
	w = NIL;
	ctx->vsp=local+5;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto XtextIF2647;
XtextIF2646:
	local[4]= local[3];
	w = fqv[97];
	if (memq(local[4],w)==NIL) goto XtextIF2648;
	local[4]= argv[0]->c.obj.iv[21];
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto XtextCON2651;
	local[4]= argv[0];
	local[5]= fqv[47];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[93];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextCON2650;
XtextCON2651:
	local[4]= NIL;
XtextCON2650:
	goto XtextIF2649;
XtextIF2648:
	local[4]= local[3];
	if (fqv[98]!=local[4]) goto XtextIF2652;
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[47];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[28];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextIF2653;
XtextIF2652:
	local[4]= local[3];
	w = fqv[99];
	if (memq(local[4],w)==NIL) goto XtextIF2654;
	if (argv[0]->c.obj.iv[28]==NIL) goto XtextIF2656;
	if (argv[0]->c.obj.iv[29]==NIL) goto XtextIF2656;
	local[4]= argv[0]->c.obj.iv[28];
	local[5]= argv[0]->c.obj.iv[29];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextIF2657;
XtextIF2656:
	local[4]= NIL;
XtextIF2657:
	goto XtextIF2655;
XtextIF2654:
	if (T==NIL) goto XtextIF2658;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)32L);
	ctx->vsp=local+6;
	w=(pointer)GREQP(ctx,2,local+4); /*>=*/
	if (w==NIL) goto XtextIF2660;
	local[4]= argv[0];
	local[5]= fqv[61];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextIF2661;
XtextIF2660:
	local[4]= NIL;
XtextIF2661:
	goto XtextIF2659;
XtextIF2658:
	local[4]= NIL;
XtextIF2659:
XtextIF2655:
XtextIF2653:
XtextIF2649:
XtextIF2647:
XtextIF2645:
XtextIF2643:
XtextIF2641:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2637:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XtextM2662buffertextwindow_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	if (argv[0]->c.obj.iv[30]==NIL) goto XtextIF2664;
	if (argv[0]->c.obj.iv[34]==NIL) goto XtextIF2664;
	local[3]= argv[0];
	local[4]= fqv[100];
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[30];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[30];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[34];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[34];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,7,local+3); /*send*/
	local[3]= w;
	goto XtextIF2665;
XtextIF2664:
	local[3]= NIL;
XtextIF2665:
	local[3]= argv[0];
	local[4]= fqv[54];
	local[5]= loadglobal(fqv[51]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[55];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)MKINTVECTOR(ctx,2,local+5); /*integer-vector*/
	argv[0]->c.obj.iv[30] = w;
	argv[0]->c.obj.iv[34] = argv[0]->c.obj.iv[30];
	w = argv[0]->c.obj.iv[34];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2663:
	ctx->vsp=local; return(local[0]);}

/*:region-direction*/
static pointer XtextM2666buffertextwindow_region_direction(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextCON2669;
	local[0]= fqv[101];
	goto XtextCON2668;
XtextCON2669:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto XtextCON2670;
	local[0]= fqv[102];
	goto XtextCON2668;
XtextCON2670:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextCON2671;
	local[0]= fqv[101];
	goto XtextCON2668;
XtextCON2671:
	local[0]= fqv[102];
	goto XtextCON2668;
XtextCON2672:
	local[0]= NIL;
XtextCON2668:
	w = local[0];
	local[0]= w;
XtextBLK2667:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XtextM2673buffertextwindow_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[54];
	local[5]= loadglobal(fqv[51]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[55];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[103];
	local[7]= argv[0]->c.obj.iv[34];
	local[8]= local[3];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[103];
	local[8]= argv[0]->c.obj.iv[34];
	local[9]= local[3];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,5,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[100];
	local[9]= NIL;
	local[10]= argv[0]->c.obj.iv[30];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[30];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[34];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[34];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,7,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[100];
	local[9]= T;
	local[10]= argv[0]->c.obj.iv[30];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[30];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[3];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,7,local+7); /*send*/
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)MKINTVECTOR(ctx,2,local+7); /*integer-vector*/
	argv[0]->c.obj.iv[34] = w;
	w = argv[0]->c.obj.iv[34];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2674:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XtextM2675buffertextwindow_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[54];
	local[5]= loadglobal(fqv[51]);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[55];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[36];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[27];
	local[7]= fqv[28];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2676:
	ctx->vsp=local; return(local[0]);}

/*:selection*/
static pointer XtextM2677buffertextwindow_selection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[30]==NIL) goto XtextIF2679;
	if (argv[0]->c.obj.iv[34]==NIL) goto XtextIF2679;
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[30];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[30];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[34];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[34];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w!=NIL) goto XtextOR2683;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto XtextAND2684;
	local[5]= local[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto XtextAND2684;
	goto XtextOR2683;
XtextAND2684:
	goto XtextIF2681;
XtextOR2683:
	local[5]= local[3];
	local[6]= local[4];
	local[7]= local[1];
	local[8]= local[2];
	local[1] = local[5];
	local[2] = local[6];
	local[3] = local[7];
	local[4] = local[8];
	w = NIL;
	local[5]= w;
	goto XtextIF2682;
XtextIF2681:
	local[5]= NIL;
XtextIF2682:
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto XtextIF2685;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= local[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	local[5]= local[0];
	goto XtextIF2686;
XtextIF2685:
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,2,local+5); /*subseq*/
	local[5]= w;
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	local[5]= local[0];
XtextIF2686:
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SUB1(ctx,1,local+6); /*1-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto XtextIF2687;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[3];
	local[7]= local[1];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,3,local+6); /*-*/
	local[6]= w;
XtextWHL2689:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto XtextWHX2690;
	local[7]= argv[0]->c.obj.iv[31];
	local[8]= local[1];
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,3,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,2,local+7); /*aref*/
	local[7]= w;
	w = local[0];
	ctx->vsp=local+8;
	local[0] = cons(ctx,local[7],w);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto XtextWHL2689;
XtextWHX2690:
	local[7]= NIL;
XtextBLK2691:
	w = NIL;
	local[5]= w;
	goto XtextIF2688;
XtextIF2687:
	local[5]= NIL;
XtextIF2688:
	local[5]= local[3];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto XtextIF2692;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	w = local[0];
	ctx->vsp=local+6;
	local[0] = cons(ctx,local[5],w);
	local[5]= local[0];
	goto XtextIF2693;
XtextIF2692:
	local[5]= NIL;
XtextIF2693:
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)NREVERSE(ctx,1,local+5); /*nreverse*/
	local[0]= w;
	goto XtextIF2680;
XtextIF2679:
	local[0]= NIL;
XtextIF2680:
	w = local[0];
	local[0]= w;
XtextBLK2678:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XtextM2694scrolltextwindow_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XtextRST2696:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[104], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XtextKEY2697;
	local[1] = NIL;
XtextKEY2697:
	if (n & (1<<1)) goto XtextKEY2698;
	local[2] = NIL;
XtextKEY2698:
	local[3]= (pointer)get_sym_func(fqv[9]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[10]));
	local[6]= fqv[11];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	if (local[1]==NIL) goto XtextIF2699;
	local[3]= loadglobal(fqv[105]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[11];
	local[6]= fqv[12];
	local[7]= makeint((eusinteger_t)12L);
	local[8]= fqv[13];
	local[9]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+10;
	w=(pointer)SUB1(ctx,1,local+9); /*1-*/
	local[9]= w;
	local[10]= fqv[15];
	local[11]= argv[0];
	local[12]= fqv[106];
	local[13]= fqv[107];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,10,local+4); /*send*/
	w = local[3];
	argv[0]->c.obj.iv[39] = w;
	local[3]= argv[0]->c.obj.iv[39];
	goto XtextIF2700;
XtextIF2699:
	local[3]= NIL;
XtextIF2700:
	if (local[2]==NIL) goto XtextIF2701;
	local[3]= loadglobal(fqv[108]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[11];
	local[6]= fqv[12];
	if (local[1]==NIL) goto XtextIF2703;
	local[7]= argv[0]->c.obj.iv[5];
	local[8]= argv[0]->c.obj.iv[39];
	local[9]= fqv[12];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)4L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,3,local+7); /*-*/
	local[7]= w;
	goto XtextIF2704;
XtextIF2703:
	local[7]= argv[0]->c.obj.iv[5];
XtextIF2704:
	local[8]= fqv[13];
	local[9]= makeint((eusinteger_t)12L);
	local[10]= fqv[15];
	local[11]= argv[0];
	local[12]= fqv[106];
	local[13]= fqv[109];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,10,local+4); /*send*/
	w = local[3];
	argv[0]->c.obj.iv[40] = w;
	local[3]= argv[0]->c.obj.iv[40];
	goto XtextIF2702;
XtextIF2701:
	local[3]= NIL;
XtextIF2702:
	local[3]= argv[0];
	local[4]= fqv[110];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	w = argv[0];
	local[0]= w;
XtextBLK2695:
	ctx->vsp=local; return(local[0]);}

/*:locate-scroll-bar*/
static pointer XtextM2705scrolltextwindow_locate_scroll_bar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[39]==NIL) goto XtextIF2707;
	local[0]= argv[0]->c.obj.iv[39];
	local[1]= fqv[56];
	local[2]= makeint((eusinteger_t)12L);
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[39];
	local[1]= fqv[111];
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= argv[0]->c.obj.iv[39];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,3,local+2); /*-*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= argv[0]->c.obj.iv[39];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)4L);
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,3,local+0); /*-*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	argv[0]->c.obj.iv[17] = w;
	local[0]= argv[0]->c.obj.iv[17];
	goto XtextIF2708;
XtextIF2707:
	local[0]= NIL;
XtextIF2708:
	if (argv[0]->c.obj.iv[40]==NIL) goto XtextIF2709;
	local[0]= argv[0]->c.obj.iv[40];
	local[1]= fqv[56];
	if (argv[0]->c.obj.iv[39]==NIL) goto XtextIF2711;
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= argv[0]->c.obj.iv[39];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)4L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,3,local+2); /*-*/
	local[2]= w;
	goto XtextIF2712;
XtextIF2711:
	local[2]= argv[0]->c.obj.iv[5];
XtextIF2712:
	local[3]= makeint((eusinteger_t)12L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[40];
	local[1]= fqv[111];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= argv[0]->c.obj.iv[40];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,3,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[6];
	local[1]= argv[0]->c.obj.iv[40];
	local[2]= fqv[13];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,3,local+0); /*-*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	argv[0]->c.obj.iv[16] = w;
	local[0]= argv[0]->c.obj.iv[16];
	goto XtextIF2710;
XtextIF2709:
	local[0]= NIL;
XtextIF2710:
	w = local[0];
	local[0]= w;
XtextBLK2706:
	ctx->vsp=local; return(local[0]);}

/*:goto*/
static pointer XtextM2713scrolltextwindow_goto(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto XtextENT2716;}
	local[0]= fqv[28];
XtextENT2716:
XtextENT2715:
	if (n>5) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[10]));
	local[3]= fqv[36];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,6,local+1); /*send-message*/
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[0]->c.obj.iv[35] = w;
	local[1]= argv[0]->c.obj.iv[21];
	local[2]= argv[0]->c.obj.iv[38];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[0]->c.obj.iv[36] = w;
	w = argv[0]->c.obj.iv[36];
	local[0]= w;
XtextBLK2714:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer XtextM2717scrolltextwindow_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	argv[0]->c.obj.iv[37] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[38] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[35] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[36] = makeint((eusinteger_t)0L);
	local[0]= fqv[112];
	local[1]= fqv[74];
	local[2]= T;
	ctx->vsp=local+3;
	w=(*ftab[16])(ctx,3,local+0,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[31] = w;
	local[0]= fqv[113];
	local[1]= fqv[74];
	local[2]= T;
	ctx->vsp=local+3;
	w=(*ftab[16])(ctx,3,local+0,&ftab[16],fqv[75]); /*make-array*/
	argv[0]->c.obj.iv[32] = w;
	argv[0]->c.obj.iv[41] = NIL;
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
XtextBLK2718:
	ctx->vsp=local; return(local[0]);}

/*:lines*/
static pointer XtextM2719scrolltextwindow_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[31];
	local[0]= w;
XtextBLK2720:
	ctx->vsp=local; return(local[0]);}

/*:refresh*/
static pointer XtextM2721scrolltextwindow_refresh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2725;}
	local[0]= makeint((eusinteger_t)0L);
XtextENT2725:
	if (n>=4) { local[1]=(argv[3]); goto XtextENT2724;}
	local[1]= argv[0]->c.obj.iv[16];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
XtextENT2724:
XtextENT2723:
	if (n>4) maerror();
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= argv[0]->c.obj.iv[21];
	local[4]= argv[0];
	local[5]= fqv[36];
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[10]));
	local[6]= fqv[42];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SENDMESSAGE(ctx,4,local+4); /*send-message*/
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= local[0];
	local[7]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,3,local+5); /*-*/
	local[5]= w;
	local[6]= local[1];
	local[7]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+8;
	w=(pointer)MIN(ctx,3,local+5); /*min*/
	local[5]= w;
XtextWHL2726:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto XtextWHX2727;
	local[6]= argv[0];
	local[7]= fqv[19];
	local[8]= local[0];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= argv[0];
	local[7]= fqv[20];
	local[8]= argv[0]->c.obj.iv[18];
	local[9]= argv[0]->c.obj.iv[19];
	local[10]= argv[0]->c.obj.iv[32];
	local[11]= local[0];
	local[12]= local[4];
	local[13]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,3,local+11); /*+*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,2,local+10); /*aref*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[38];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,6,local+6); /*send*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto XtextWHL2726;
XtextWHX2727:
	local[6]= NIL;
XtextBLK2728:
	w = NIL;
	argv[0]->c.obj.iv[20] = local[2];
	argv[0]->c.obj.iv[21] = local[3];
	local[4]= argv[0];
	local[5]= fqv[19];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[28];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	if (argv[0]->c.obj.iv[41]==NIL) goto XtextIF2729;
	local[4]= argv[0];
	local[5]= fqv[76];
	local[6]= argv[0]->c.obj.iv[41];
	local[7]= T;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto XtextIF2730;
XtextIF2729:
	local[4]= NIL;
XtextIF2730:
	if (argv[0]->c.obj.iv[39]==NIL) goto XtextIF2731;
	local[4]= argv[0]->c.obj.iv[39];
	local[5]= fqv[114];
	local[6]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+9;
	w=(pointer)EUSFLOAT(ctx,1,local+8); /*float*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MIN(ctx,2,local+7); /*min*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto XtextIF2732;
XtextIF2731:
	local[4]= NIL;
XtextIF2732:
	if (argv[0]->c.obj.iv[40]==NIL) goto XtextIF2733;
	local[4]= argv[0]->c.obj.iv[40];
	local[5]= fqv[114];
	local[6]= argv[0]->c.obj.iv[38];
	ctx->vsp=local+7;
	w=(pointer)EUSFLOAT(ctx,1,local+6); /*float*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+8;
	w=(pointer)QUOTIENT(ctx,2,local+6); /*/*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+9;
	w=(pointer)EUSFLOAT(ctx,1,local+8); /*float*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MIN(ctx,2,local+7); /*min*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto XtextIF2734;
XtextIF2733:
	local[4]= NIL;
XtextIF2734:
	w = local[4];
	local[0]= w;
XtextBLK2722:
	ctx->vsp=local; return(local[0]);}

/*:line-in-window-p*/
static pointer XtextM2735scrolltextwindow_line_in_window_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[37];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[37];
	local[3]= argv[0]->c.obj.iv[16];
	local[4]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,3,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	local[0]= w;
XtextBLK2736:
	ctx->vsp=local; return(local[0]);}

/*:refresh-line*/
static pointer XtextM2737scrolltextwindow_refresh_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2740;}
	local[0]= NIL;
XtextENT2740:
XtextENT2739:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
	local[5]= fqv[115];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	if (w==NIL) goto XtextIF2741;
	local[4]= argv[0];
	local[5]= fqv[36];
	local[6]= argv[2];
	local[7]= argv[0]->c.obj.iv[37];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[40];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[19];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (local[0]==NIL) goto XtextCON2744;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[116];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[2] = w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[117];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[3] = w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[116];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[117];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[46];
	local[6]= argv[0]->c.obj.iv[18];
	local[7]= argv[0]->c.obj.iv[19];
	local[8]= argv[0]->c.obj.iv[32];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[38];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[116];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[117];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextCON2743;
XtextCON2744:
	local[4]= argv[0];
	local[5]= fqv[46];
	local[6]= argv[0]->c.obj.iv[18];
	local[7]= argv[0]->c.obj.iv[19];
	local[8]= argv[0]->c.obj.iv[32];
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[38];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	local[4]= w;
	goto XtextCON2743;
XtextCON2745:
	local[4]= NIL;
XtextCON2743:
	goto XtextIF2742;
XtextIF2741:
	local[4]= NIL;
XtextIF2742:
	w = local[4];
	local[0]= w;
XtextBLK2738:
	ctx->vsp=local; return(local[0]);}

/*:locate*/
static pointer XtextM2746scrolltextwindow_locate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	if (w==NIL) goto XtextIF2748;
	argv[0]->c.obj.iv[37] = argv[2];
	local[0]= argv[0];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto XtextIF2749;
XtextIF2748:
	local[0]= NIL;
XtextIF2749:
	w = local[0];
	local[0]= w;
XtextBLK2747:
	ctx->vsp=local; return(local[0]);}

/*:display-selection*/
static pointer XtextM2750scrolltextwindow_display_selection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[41]==NIL) goto XtextIF2752;
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= argv[0]->c.obj.iv[41];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XtextIF2753;
XtextIF2752:
	local[0]= NIL;
XtextIF2753:
	if (argv[2]==NIL) goto XtextIF2754;
	local[0]= argv[0];
	local[1]= fqv[76];
	local[2]= argv[2];
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XtextIF2755;
XtextIF2754:
	local[0]= NIL;
XtextIF2755:
	argv[0]->c.obj.iv[41] = argv[2];
	w = argv[0]->c.obj.iv[41];
	local[0]= w;
XtextBLK2751:
	ctx->vsp=local; return(local[0]);}

/*:selection*/
static pointer XtextM2756scrolltextwindow_selection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[41]==NIL) goto XtextIF2758;
	local[0]= argv[0]->c.obj.iv[31];
	local[1]= argv[0]->c.obj.iv[41];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	goto XtextIF2759;
XtextIF2758:
	local[0]= NIL;
XtextIF2759:
	w = local[0];
	local[0]= w;
XtextBLK2757:
	ctx->vsp=local; return(local[0]);}

/*:scroll-fraction*/
static pointer XtextM2760scrolltextwindow_scroll_fraction(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
XtextBLK2761:
	ctx->vsp=local; return(local[0]);}

/*:horizontal-scroll-fraction*/
static pointer XtextM2762scrolltextwindow_horizontal_scroll_fraction(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[33];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
XtextBLK2763:
	ctx->vsp=local; return(local[0]);}

/*:scroll*/
static pointer XtextM2764scrolltextwindow_scroll(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = argv[2];
	if (!isflt(w)) goto XtextIF2766;
	local[0]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ROUND(ctx,1,local+0); /*round*/
	argv[2] = w;
	local[0]= argv[2];
	goto XtextIF2767;
XtextIF2766:
	local[0]= NIL;
XtextIF2767:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextIF2768;
	local[0]= argv[0]->c.obj.iv[37];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MIN(ctx,2,local+0); /*min*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)MINUS(ctx,1,local+0); /*-*/
	local[0]= w;
	goto XtextIF2769;
XtextIF2768:
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[37];
	local[3]= argv[0]->c.obj.iv[16];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,3,local+1); /*-*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAX(ctx,2,local+0); /*max*/
	local[0]= w;
XtextIF2769:
	argv[2] = local[0];
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[39];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[37];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[37] = w;
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextCON2771;
	local[0]= argv[0];
	local[1]= fqv[73];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)ABS(ctx,1,local+3); /*abs*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XtextCON2770;
XtextCON2771:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto XtextCON2772;
	local[0]= argv[0];
	local[1]= fqv[73];
	local[2]= argv[0]->c.obj.iv[16];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto XtextCON2770;
XtextCON2772:
	local[0]= NIL;
XtextCON2770:
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[28];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XtextBLK2765:
	ctx->vsp=local; return(local[0]);}

/*:horizontal-scroll*/
static pointer XtextM2773scrolltextwindow_horizontal_scroll(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[29];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = argv[2];
	if (!isflt(w)) goto XtextIF2775;
	local[0]= argv[0]->c.obj.iv[33];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ROUND(ctx,1,local+0); /*round*/
	argv[2] = w;
	local[0]= argv[2];
	goto XtextIF2776;
XtextIF2775:
	local[0]= NIL;
XtextIF2776:
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto XtextIF2777;
	local[0]= argv[0]->c.obj.iv[38];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MIN(ctx,2,local+0); /*min*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)MINUS(ctx,1,local+0); /*-*/
	local[0]= w;
	goto XtextIF2778;
XtextIF2777:
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[33];
	local[2]= argv[0]->c.obj.iv[38];
	local[3]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,3,local+1); /*-*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAX(ctx,2,local+0); /*max*/
	local[0]= w;
XtextIF2778:
	argv[2] = local[0];
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[118];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[38];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[38] = w;
	local[0]= argv[0];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[27];
	local[2]= fqv[28];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XtextBLK2774:
	ctx->vsp=local; return(local[0]);}

/*:insert-char*/
static pointer XtextM2779scrolltextwindow_insert_char(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2782;}
	local[0]= T;
XtextENT2782:
XtextENT2781:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[31];
	local[2]= argv[0]->c.obj.iv[35];
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(*ftab[2])(ctx,1,local+3,&ftab[2],fqv[23]); /*make-string*/
	local[3]= w;
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	w = argv[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[5]); v=local[4];
	  v->c.str.chars[i]=intval(w);}
	local[4]= loadglobal(fqv[86]);
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= argv[0]->c.obj.iv[36];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,3,local+5); /*subseq*/
	local[5]= w;
	local[6]= local[3];
	local[7]= local[1];
	local[8]= argv[0]->c.obj.iv[36];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,2,local+7); /*subseq*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,4,local+4); /*concatenate*/
	local[1] = w;
	local[4]= argv[0]->c.obj.iv[31];
	local[5]= argv[0]->c.obj.iv[35];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= argv[0]->c.obj.iv[32];
	local[5]= argv[0]->c.obj.iv[35];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)XtextF2328expand_tab(ctx,1,local+6); /*expand-tab*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	if (local[0]==NIL) goto XtextIF2783;
	local[4]= argv[0];
	local[5]= fqv[76];
	local[6]= argv[0]->c.obj.iv[35];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextIF2784;
XtextIF2783:
	local[4]= NIL;
XtextIF2784:
	local[4]= argv[0];
	local[5]= fqv[47];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	if (local[0]==NIL) goto XtextIF2785;
	local[4]= argv[0];
	local[5]= fqv[27];
	local[6]= fqv[28];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XtextIF2786;
XtextIF2785:
	local[4]= NIL;
XtextIF2786:
	w = local[4];
	local[0]= w;
XtextBLK2780:
	ctx->vsp=local; return(local[0]);}

/*:insert-newline*/
static pointer XtextM2787scrolltextwindow_insert_newline(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XtextENT2790;}
	local[0]= T;
XtextENT2790:
XtextENT2789:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[40];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = NIL;
	local[0]= w;
XtextBLK2788:
	ctx->vsp=local; return(local[0]);}

/*:insert*/
static pointer XtextM2791scrolltextwindow_insert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XtextENT2794;}
	local[0]= T;
XtextENT2794:
XtextENT2793:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[119];
	ctx->vsp=local+3;
	w=(*ftab[18])(ctx,2,local+1,&ftab[18],fqv[120]); /*member*/
	if (w==NIL) goto XtextCON2796;
	local[1]= argv[0];
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto XtextCON2795;
XtextCON2796:
	w = argv[2];
	if (!numberp(w)) goto XtextCON2797;
	local[1]= argv[0];
	local[2]= fqv[122];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto XtextCON2795;
XtextCON2797:
	w = argv[2];
	if (!isstring(w)) goto XtextCON2798;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
XtextWHL2799:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto XtextWHX2800;
	local[3]= argv[0];
	local[4]= fqv[61];
	local[5]= argv[2];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeint(local[5]->c.str.chars[i]);}
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto XtextWHL2799;
XtextWHX2800:
	local[3]= NIL;
XtextBLK2801:
	w = NIL;
	local[1]= w;
	goto XtextCON2795;
XtextCON2798:
	local[1]= NIL;
XtextCON2795:
	w = local[1];
	local[0]= w;
XtextBLK2792:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XtextM2802scrolltextwindow_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[10]));
	local[5]= fqv[123];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,4,local+3); /*send-message*/
	local[3]= argv[0]->c.obj.iv[37];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[38];
	local[5]= argv[0];
	local[6]= fqv[55];
	local[7]= loadglobal(fqv[51]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	argv[0]->c.obj.iv[35] = w;
	local[5]= argv[0]->c.obj.iv[31];
	local[6]= argv[0]->c.obj.iv[35];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	argv[0]->c.obj.iv[36] = w;
	local[5]= argv[0];
	local[6]= fqv[124];
	local[7]= argv[0]->c.obj.iv[35];
	local[8]= argv[0]->c.obj.iv[31];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto XtextIF2804;
	local[7]= argv[0]->c.obj.iv[35];
	goto XtextIF2805;
XtextIF2804:
	local[7]= NIL;
XtextIF2805:
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2803:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XtextM2806scrolltextwindow_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0]->c.obj.iv[37];
	local[4]= argv[0];
	local[5]= fqv[54];
	local[6]= loadglobal(fqv[51]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[38];
	local[5]= argv[0];
	local[6]= fqv[55];
	local[7]= loadglobal(fqv[51]);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[41];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)EQ(ctx,2,local+5); /*eql*/
	if (w==NIL) goto XtextIF2808;
	if (argv[0]->c.obj.iv[28]==NIL) goto XtextIF2808;
	if (argv[0]->c.obj.iv[29]==NIL) goto XtextIF2808;
	local[5]= argv[0]->c.obj.iv[28];
	local[6]= argv[0]->c.obj.iv[29];
	local[7]= argv[0];
	local[8]= fqv[125];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto XtextIF2809;
XtextIF2808:
	local[5]= NIL;
XtextIF2809:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2807:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XtextM2810scrolltextwindow_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[10]));
	local[2]= fqv[56];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[0];
	local[1]= fqv[110];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[73];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XtextBLK2811:
	ctx->vsp=local; return(local[0]);}

/*:configurenotify*/
static pointer XtextM2812scrolltextwindow_configurenotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[51],w);
	local[3]= argv[0];
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[57]); /*/=*/
	if (w!=NIL) goto XtextOR2816;
	local[5]= local[4];
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[57]); /*/=*/
	if (w!=NIL) goto XtextOR2816;
	goto XtextIF2814;
XtextOR2816:
	local[5]= argv[0];
	local[6]= fqv[56];
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto XtextIF2815;
XtextIF2814:
	local[5]= NIL;
XtextIF2815:
	w = local[5];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XtextBLK2813:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xtext(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[126];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= fqv[127];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XtextIF2817;
	local[0]= fqv[128];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[129],w);
	goto XtextIF2818;
XtextIF2817:
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XtextIF2818:
	local[0]= fqv[131];
	local[1]= fqv[132];
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[133]); /*require*/
	local[0]= fqv[134];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[135];
	local[1]= fqv[136];
	local[2]= fqv[135];
	local[3]= fqv[137];
	local[4]= loadglobal(fqv[138]);
	local[5]= fqv[139];
	local[6]= fqv[140];
	local[7]= fqv[141];
	local[8]= NIL;
	local[9]= fqv[142];
	local[10]= NIL;
	local[11]= fqv[143];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[144];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[20])(ctx,13,local+2,&ftab[20],fqv[145]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2329characterwindow_create,fqv[11],fqv[146],fqv[147]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2350characterwindow_xy,fqv[19],fqv[146],fqv[148]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2355characterwindow_clear_lines,fqv[42],fqv[146],fqv[149]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2357characterwindow_put_line,fqv[150],fqv[146],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2359textwindow_create,fqv[11],fqv[138],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2370textwindow_set_notify,fqv[24],fqv[138],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2372textwindow_show_cursor,fqv[25],fqv[138],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2376textwindow_cursor,fqv[27],fqv[138],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2385textwindow_win_row,fqv[156],fqv[138],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2387textwindow_win_col,fqv[158],fqv[138],fqv[159]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2389textwindow_win_row_max,fqv[160],fqv[138],fqv[161]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2391textwindow_win_col_max,fqv[162],fqv[138],fqv[163]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2393textwindow_xy,fqv[19],fqv[138],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2398textwindow_goto,fqv[36],fqv[138],fqv[165]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2402textwindow_goback,fqv[91],fqv[138],fqv[166]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2406textwindow_advance,fqv[47],fqv[138],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2410textwindow_scroll,fqv[39],fqv[138],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2418textwindow_horizontal_scroll,fqv[118],fqv[138],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2426textwindow_newline,fqv[44],fqv[138],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2430textwindow_clear,fqv[26],fqv[138],fqv[171]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2432textwindow_clear_eol,fqv[40],fqv[138],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2438textwindow_clear_lines,fqv[42],fqv[138],fqv[173]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2442textwindow_clear_eos,fqv[174],fqv[138],fqv[175]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2447textwindow_clear_in_line,fqv[41],fqv[138],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2449textwindow_clear_text_area,fqv[177],fqv[138],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2457textwindow_putch,fqv[50],fqv[138],fqv[179]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2467textwindow_putstring,fqv[180],fqv[138],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2478textwindow_insert,fqv[61],fqv[138],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2480textwindow_event_row,fqv[54],fqv[138],fqv[183]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2482textwindow_event_col,fqv[55],fqv[138],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2484textwindow_buttonpress,fqv[123],fqv[138],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2486textwindow_buttonrelease,fqv[186],fqv[138],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2488textwindow_resize,fqv[56],fqv[138],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2490textwindow_configurenotify,fqv[189],fqv[138],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2495textwindow_echo,fqv[191],fqv[138],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2497textwindow_getstring,fqv[62],fqv[138],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2499textwindow_enternotify,fqv[194],fqv[138],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2503textwindow_leavenotify,fqv[196],fqv[138],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2505textwindow_keyrelease,fqv[198],fqv[138],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2507textwindow_lineenter,fqv[200],fqv[138],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2513textwindow_keyenter,fqv[202],fqv[138],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2519textwindowstream_fill,fqv[204],fqv[65],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2521textwindowstream_flush,fqv[206],fqv[65],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2526textwindowstream_init,fqv[64],fqv[65],fqv[208]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[209],module,XtextF2327make_textwindow_stream,fqv[210]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[211],module,XtextF2328expand_tab,fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2540buffertextwindow_create,fqv[11],fqv[213],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2543buffertextwindow_redraw,fqv[215],fqv[213],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2545buffertextwindow_clear,fqv[26],fqv[213],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2547buffertextwindow_refresh_line,fqv[76],fqv[213],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2552buffertextwindow_refresh,fqv[73],fqv[213],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2559buffertextwindow_refresh_in_line,fqv[77],fqv[213],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2563buffertextwindow_refresh_lines,fqv[78],fqv[213],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2570buffertextwindow_refresh_area,fqv[80],fqv[213],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2582buffertextwindow_highlight,fqv[100],fqv[213],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2588buffertextwindow_goto,fqv[36],fqv[213],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2594buffertextwindow_line,fqv[225],fqv[213],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2598buffertextwindow_lines,fqv[227],fqv[213],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2600buffertextwindow_nlines,fqv[229],fqv[213],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2602buffertextwindow_all_lines,fqv[231],fqv[213],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2604buffertextwindow_max_line_length,fqv[85],fqv[213],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2606buffertextwindow_read_file,fqv[234],fqv[213],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2613buffertextwindow_display_line_string,fqv[236],fqv[213],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2621buffertextwindow_display_strings,fqv[238],fqv[213],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2626buffertextwindow_insert_string,fqv[240],fqv[213],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2630buffertextwindow_insert,fqv[61],fqv[213],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2632buffertextwindow_delete,fqv[93],fqv[213],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2636buffertextwindow_keyenter,fqv[202],fqv[213],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2662buffertextwindow_buttonpress,fqv[123],fqv[213],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2666buffertextwindow_region_direction,fqv[103],fqv[213],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2673buffertextwindow_motionnotify,fqv[247],fqv[213],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2675buffertextwindow_buttonrelease,fqv[186],fqv[213],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2677buffertextwindow_selection,fqv[125],fqv[213],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2694scrolltextwindow_create,fqv[11],fqv[251],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2705scrolltextwindow_locate_scroll_bar,fqv[110],fqv[251],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2713scrolltextwindow_goto,fqv[36],fqv[251],fqv[254]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2717scrolltextwindow_clear,fqv[26],fqv[251],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2719scrolltextwindow_lines,fqv[227],fqv[251],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2721scrolltextwindow_refresh,fqv[73],fqv[251],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2735scrolltextwindow_line_in_window_p,fqv[115],fqv[251],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2737scrolltextwindow_refresh_line,fqv[76],fqv[251],fqv[259]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2746scrolltextwindow_locate,fqv[260],fqv[251],fqv[261]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2750scrolltextwindow_display_selection,fqv[124],fqv[251],fqv[262]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2756scrolltextwindow_selection,fqv[125],fqv[251],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2760scrolltextwindow_scroll_fraction,fqv[264],fqv[251],fqv[265]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2762scrolltextwindow_horizontal_scroll_fraction,fqv[266],fqv[251],fqv[267]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2764scrolltextwindow_scroll,fqv[39],fqv[251],fqv[268]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2773scrolltextwindow_horizontal_scroll,fqv[118],fqv[251],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2779scrolltextwindow_insert_char,fqv[122],fqv[251],fqv[270]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2787scrolltextwindow_insert_newline,fqv[121],fqv[251],fqv[271]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2791scrolltextwindow_insert,fqv[61],fqv[251],fqv[272]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2802scrolltextwindow_buttonpress,fqv[123],fqv[251],fqv[273]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2806scrolltextwindow_buttonrelease,fqv[186],fqv[251],fqv[274]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2810scrolltextwindow_resize,fqv[56],fqv[251],fqv[275]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XtextM2812scrolltextwindow_configurenotify,fqv[189],fqv[251],fqv[276]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<21; i++) ftab[i]=fcallx;
}
