char *makedate="Sat Apr 4 05:09:15 UTC 2026";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";
