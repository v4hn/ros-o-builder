/* ./comp.c :  entry=comp */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Apr 4 05:09:15 UTC 2026) */
#include "eus.h"
#include "comp.h"
#pragma init (register_comp)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___comp();
extern pointer build_quote_vector();
static int register_comp()
  { add_module_initializer("___comp", ___comp);}

static pointer compF377compiled_code_p();
static pointer compF378ovafp();
static pointer compF379class_symbolp();
static pointer compF380quoted_symbolp();
static pointer compF381proclaimed_special_p();
static pointer compF382proclaimed_global_p();
static pointer compF383object_variable_names();
static pointer compF384object_variable_type();
static pointer compF385coerce_type();
static pointer compF386check_arg();
static pointer compF387def_function_type();
static pointer compF388dump_function();
static pointer compF389comfile();
static pointer compF390compile_file();
static pointer compF391compile();
static pointer compF392compile_file_if_src_newer();
static pointer compF393comp_file_toplevel();

/*compiled-code-p*/
static pointer compF377compiled_code_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[0]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
compBLK394:
	ctx->vsp=local; return(local[0]);}

/*ovafp*/
static pointer compF378ovafp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	if (local[0]==NIL) goto compAND396;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= (issymbol(w)?T:NIL);
compAND396:
	w = local[0];
	local[0]= w;
compBLK395:
	ctx->vsp=local; return(local[0]);}

/*class-symbolp*/
static pointer compF379class_symbolp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= (issymbol(w)?T:NIL);
	if (local[0]==NIL) goto compAND398;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	local[0]= w;
	if (w==NIL) goto compAND398;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SYMVALUE(ctx,1,local+0); /*symbol-value*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)CLASSP(ctx,1,local+0); /*classp*/
	local[0]= w;
compAND398:
	w = local[0];
	local[0]= w;
compBLK397:
	ctx->vsp=local; return(local[0]);}

/*quoted-symbolp*/
static pointer compF380quoted_symbolp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= (iscons(w)?T:NIL);
	if (local[0]==NIL) goto compAND400;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[0]= ((fqv[1])==(local[0])?T:NIL);
	if (local[0]==NIL) goto compAND400;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= (issymbol(w)?T:NIL);
compAND400:
	w = local[0];
	local[0]= w;
compBLK399:
	ctx->vsp=local; return(local[0]);}

/*proclaimed-special-p*/
static pointer compF381proclaimed_special_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	local[0]= w;
compOR402:
	w = local[0];
	local[0]= w;
compBLK401:
	ctx->vsp=local; return(local[0]);}

/*proclaimed-global-p*/
static pointer compF382proclaimed_global_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
compBLK403:
	ctx->vsp=local; return(local[0]);}

/*object-variable-names*/
static pointer compF383object_variable_names(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	w = argv[0];
	if (!issymbol(w)) goto compIF405;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)SYMVALUE(ctx,1,local+4); /*symbol-value*/
	local[0] = w;
	local[4]= local[0];
	goto compIF406;
compIF405:
	local[0] = argv[0];
	local[4]= local[0];
compIF406:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)CLASSP(ctx,1,local+4); /*classp*/
	if (w==NIL) goto compIF407;
	local[1] = *(ovafptr(local[0],fqv[2]));
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[2] = w;
compWHL409:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)SUB1(ctx,1,local+4); /*1-*/
	local[2] = w;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)GREQP(ctx,2,local+4); /*>=*/
	if (w==NIL) goto compWHX410;
	local[4]= local[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[4]->c.vec.v[i]);}
	local[4]= w;
	w = local[3];
	ctx->vsp=local+5;
	local[3] = cons(ctx,local[4],w);
	goto compWHL409;
compWHX410:
	local[4]= NIL;
compBLK411:
	goto compIF408;
compIF407:
	local[4]= NIL;
compIF408:
	w = local[3];
	local[0]= w;
compBLK404:
	ctx->vsp=local; return(local[0]);}

/*object-variable-type*/
static pointer compF384object_variable_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)CLASSP(ctx,1,local+0); /*classp*/
	if (w!=NIL) goto compIF413;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)compF379class_symbolp(ctx,1,local+0); /*class-symbolp*/
	if (w==NIL) goto compIF415;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SYMVALUE(ctx,1,local+0); /*symbol-value*/
	argv[0] = w;
	local[0]= argv[0];
	goto compIF416;
compIF415:
	local[0]= fqv[3];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
compIF416:
	goto compIF414;
compIF413:
	local[0]= NIL;
compIF414:
	w = argv[1];
	if (!numberp(w)) goto compIF417;
	local[0]= argv[0]->c.obj.iv[5];
	{ register eusinteger_t i=intval(argv[1]);
	  w=(local[0]->c.vec.v[i]);}
	argv[1] = w;
	local[0]= argv[1];
	goto compIF418;
compIF417:
	local[0]= argv[1];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[4]); /*position*/
	local[0]= w;
	if (local[0]!=NIL) goto compIF419;
	local[1]= loadglobal(fqv[5]);
	local[2]= fqv[6];
	local[3]= fqv[7];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF420;
compIF419:
	local[1]= argv[0]->c.obj.iv[5];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[1]->c.vec.v[i]);}
	argv[1] = w;
	local[1]= argv[1];
compIF420:
	w = local[1];
	local[0]= w;
compIF418:
	w = argv[1];
	if (!iscons(w)) goto compIF421;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto compIF422;
compIF421:
	local[0]= argv[1];
compIF422:
	w = local[0];
	local[0]= w;
compBLK412:
	ctx->vsp=local; return(local[0]);}

/*coerce-type*/
static pointer compF385coerce_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[8];
	if (memq(local[0],w)==NIL) goto compCON425;
	local[0]= fqv[9];
	goto compCON424;
compCON425:
	local[0]= argv[0];
	w = fqv[10];
	if (memq(local[0],w)==NIL) goto compCON426;
	local[0]= fqv[11];
	goto compCON424;
compCON426:
	local[0]= argv[0];
	goto compCON424;
compCON427:
	local[0]= NIL;
compCON424:
	w = local[0];
	local[0]= w;
compBLK423:
	ctx->vsp=local; return(local[0]);}

/*check-arg*/
static pointer compF386check_arg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT430;}
	local[0]= fqv[12];
compENT430:
compENT429:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w!=NIL) goto compIF431;
	local[1]= fqv[13];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[14]); /*warn*/
	local[1]= w;
	goto compIF432;
compIF431:
	local[1]= NIL;
compIF432:
	w = local[1];
	local[0]= w;
compBLK428:
	ctx->vsp=local; return(local[0]);}

/*def-function-type*/
static pointer compF387def_function_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[1];
compWHL434:
	if (local[1]==NIL) goto compWHX435;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= argv[0];
	local[4]= fqv[15];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	goto compWHL434;
compWHX435:
	local[2]= NIL;
compBLK436:
	w = NIL;
	local[0]= w;
compBLK433:
	ctx->vsp=local; return(local[0]);}

/*:type*/
static pointer compM437identifier_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT440;}
	local[0]= argv[0]->c.obj.iv[1];
compENT440:
compENT439:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)compF385coerce_type(ctx,1,local+1); /*coerce-type*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
compBLK438:
	ctx->vsp=local; return(local[0]);}

/*:offset*/
static pointer compM441identifier_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT444;}
	local[0]= argv[0]->c.obj.iv[4];
compENT444:
compENT443:
	if (n>3) maerror();
	argv[0]->c.obj.iv[4] = local[0];
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
compBLK442:
	ctx->vsp=local; return(local[0]);}

/*:binding*/
static pointer compM445identifier_binding(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT448;}
	local[0]= argv[0]->c.obj.iv[2];
compENT448:
compENT447:
	if (n>3) maerror();
	argv[0]->c.obj.iv[2] = local[0];
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
compBLK446:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer compM449identifier_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	argv[0]->c.obj.iv[0] = argv[2];
	argv[0]->c.obj.iv[1] = T;
	argv[0]->c.obj.iv[2] = argv[3];
	argv[0]->c.obj.iv[3] = argv[4];
	argv[0]->c.obj.iv[4] = argv[5];
	w = argv[0];
	local[0]= w;
compBLK450:
	ctx->vsp=local; return(local[0]);}

/*:find*/
static pointer compM451identifier_table_find(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto compENT454;}
	local[0]= argv[0]->c.obj.iv[1];
compENT454:
compENT453:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[2]->c.vec.v[i]);}
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASSQ(ctx,2,local+1); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
compBLK452:
	ctx->vsp=local; return(local[0]);}

/*:get*/
static pointer compM455identifier_table_get(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto compENT458;}
	local[0]= argv[0]->c.obj.iv[1];
compENT458:
compENT457:
	if (n>4) maerror();
	local[1]= NIL;
compWHL459:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREQP(ctx,2,local+2); /*>=*/
	if (w==NIL) goto compWHX460;
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[3]->c.vec.v[i]);}
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ASSQ(ctx,2,local+2); /*assq*/
	local[1] = w;
	if (local[1]==NIL) goto compIF462;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+2;
	local[0]=w;
	goto compBLK456;
	goto compIF463;
compIF462:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[0] = w;
	local[2]= local[0];
compIF463:
	goto compWHL459;
compWHX460:
	local[2]= NIL;
compBLK461:
	w = local[2];
	local[0]= w;
compBLK456:
	ctx->vsp=local; return(local[0]);}

/*:enter*/
static pointer compM464identifier_table_enter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto compENT467;}
	local[0]= argv[0]->c.obj.iv[1];
compENT467:
compENT466:
	if (n>4) maerror();
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= local[0];
	local[3]= *(ovafptr(argv[2],fqv[16]));
	w = argv[2];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[4]->c.vec.v[i]);}
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.vec.v[i]=w;}
	w = argv[2];
	local[0]= w;
compBLK465:
	ctx->vsp=local; return(local[0]);}

/*:enter-special*/
static pointer compM468identifier_table_enter_special(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[17];
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
compBLK469:
	ctx->vsp=local; return(local[0]);}

/*:create-frame*/
static pointer compM470identifier_table_create_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
compBLK471:
	ctx->vsp=local; return(local[0]);}

/*:pop-frame*/
static pointer compM472identifier_table_pop_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= argv[0]->c.obj.iv[1];
	w = NIL;
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[1]); v=local[0];
	  v->c.vec.v[i]=w;}
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
compBLK473:
	ctx->vsp=local; return(local[0]);}

/*:clear-frame*/
static pointer compM474identifier_table_clear_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= argv[0]->c.obj.iv[1];
	w = NIL;
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[1]); v=local[0];
	  v->c.vec.v[i]=w;}
	local[0]= w;
compBLK475:
	ctx->vsp=local; return(local[0]);}

/*:level*/
static pointer compM476identifier_table_level(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT479;}
	local[0]= argv[0]->c.obj.iv[1];
compENT479:
compENT478:
	if (n>3) maerror();
	argv[0]->c.obj.iv[1] = local[0];
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
compBLK477:
	ctx->vsp=local; return(local[0]);}

/*:frame*/
static pointer compM480identifier_table_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT483;}
	local[0]= argv[0]->c.obj.iv[1];
compENT483:
compENT482:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[1]->c.vec.v[i]);}
	local[0]= w;
compBLK481:
	ctx->vsp=local; return(local[0]);}

/*:init-frames*/
static pointer compM484identifier_table_init_frames(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[2];
compWHL486:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto compWHX487;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= local[0];
	w = NIL;
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.vec.v[i]=w;}
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto compWHL486;
compWHX487:
	local[2]= NIL;
compBLK488:
	w = NIL;
	argv[0]->c.obj.iv[1] = makeint((eusinteger_t)0L);
	w = argv[0];
	local[0]= w;
compBLK485:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer compM489identifier_table_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT492;}
	local[0]= makeint((eusinteger_t)20L);
compENT492:
compENT491:
	if (n>3) maerror();
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,1,local+1,&ftab[2],fqv[18]); /*make-array*/
	argv[0]->c.obj.iv[0] = w;
	argv[0]->c.obj.iv[1] = makeint((eusinteger_t)0L);
	w = argv[0];
	local[0]= w;
compBLK490:
	ctx->vsp=local; return(local[0]);}

/*:offset*/
static pointer compM493stack_frame_offset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT496;}
	local[0]= NIL;
compENT496:
compENT495:
	if (n>3) maerror();
	if (local[0]==NIL) goto compIF497;
	argv[0]->c.obj.iv[0] = local[0];
	local[1]= argv[0]->c.obj.iv[0];
	goto compIF498;
compIF497:
	local[1]= NIL;
compIF498:
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
compBLK494:
	ctx->vsp=local; return(local[0]);}

/*:special*/
static pointer compM499stack_frame_special(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT502;}
	local[0]= makeint((eusinteger_t)0L);
compENT502:
compENT501:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
compBLK500:
	ctx->vsp=local; return(local[0]);}

/*:local*/
static pointer compM503stack_frame_local(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto compENT506;}
	local[0]= makeint((eusinteger_t)0L);
compENT506:
compENT505:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
compBLK504:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer compM507stack_frame_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[0] = NIL;
	argv[0]->c.obj.iv[1] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[2] = makeint((eusinteger_t)0L);
	w = argv[0];
	local[0]= w;
compBLK508:
	ctx->vsp=local; return(local[0]);}

/*:genlabel*/
static pointer compM509compiler_genlabel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto compENT512;}
	local[0]= fqv[19];
compENT512:
compENT511:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= fqv[20];
	local[3]= argv[0]->c.obj.iv[10];
	local[4]= argv[2];
	local[5]= loadglobal(fqv[21]);
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	storeglobal(fqv[21],w);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,6,local+1); /*format*/
	local[0]= w;
compBLK510:
	ctx->vsp=local; return(local[0]);}

/*:gencname-tail*/
static pointer compM513compiler_gencname_tail(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
compRST515:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[22]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[0]= w;
compBLK514:
	ctx->vsp=local; return(local[0]);}

/*:progn*/
static pointer compM516compiler_progn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]==NIL) goto compIF518;
compWHL520:
	if (argv[2]==NIL) goto compWHX521;
	local[0]= argv[0];
	local[1]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[2];
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[2];
	if (local[0]==NIL) goto compAND523;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[25];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
compAND523:
	goto compWHL520;
compWHX521:
	local[0]= NIL;
compBLK522:
	goto compIF519;
compIF518:
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[26];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
compIF519:
	w = local[0];
	local[0]= w;
compBLK517:
	ctx->vsp=local; return(local[0]);}

/*:eval*/
static pointer compM524compiler_eval(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!issymbol(w)) goto compIF526;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[27]); /*constantp*/
	if (w==NIL) goto compIF526;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)SYMVALUE(ctx,1,local+0); /*symbol-value*/
	local[0]= w;
	w = local[0];
	if (!numberp(w)) goto compCON529;
	argv[2] = local[0];
	local[1]= argv[2];
	goto compCON528;
compCON529:
	local[1]= local[0];
	w = fqv[28];
	if (memq(local[1],w)==NIL) goto compCON530;
	argv[2] = local[0];
	local[1]= argv[2];
	goto compCON528;
compCON530:
	w = local[0];
	if (!issymbol(w)) goto compCON531;
	local[1]= fqv[1];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	argv[2] = w;
	local[1]= argv[2];
	goto compCON528;
compCON531:
	w = local[0];
	if (!isstring(w)) goto compCON532;
	argv[2] = local[0];
	local[1]= argv[2];
	goto compCON528;
compCON532:
	local[1]= NIL;
compCON528:
	w = local[1];
	local[0]= w;
	goto compIF527;
compIF526:
	local[0]= NIL;
compIF527:
	local[0]= argv[2];
	if (T!=local[0]) goto compCON534;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[29];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= fqv[30];
	goto compCON533;
compCON534:
	local[0]= argv[2];
	if (NIL!=local[0]) goto compCON535;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[26];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= NIL;
	goto compCON533;
compCON535:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[31]); /*keywordp*/
	if (w==NIL) goto compCON536;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[32];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[30];
	goto compCON533;
compCON536:
	w = argv[2];
	if (!issymbol(w)) goto compCON537;
	local[0]= argv[0];
	local[1]= fqv[33];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto compCON533;
compCON537:
	w = argv[2];
	if (!isint(w)) goto compCON538;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[34];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[9];
	goto compCON533;
compCON538:
	w = argv[2];
	if (!isflt(w)) goto compCON539;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[35];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[11];
	goto compCON533;
compCON539:
	w = argv[2];
	if (!!iscons(w)) goto compCON540;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[32];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= T;
	goto compCON533;
compCON540:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)compF378ovafp(ctx,1,local+0); /*ovafp*/
	if (w==NIL) goto compCON541;
	local[0]= argv[0];
	local[1]= fqv[36];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto compCON533;
compCON541:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto compCON542;
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= fqv[37];
	local[3]= fqv[38];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto compCON533;
compCON542:
	local[0]= argv[0];
	local[1]= fqv[39];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= local[1];
	local[3]= local[2];
	if (fqv[40]!=local[3]) goto compIF544;
	local[3]= argv[0];
	local[4]= fqv[41];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF545;
compIF544:
	local[3]= local[2];
	if (fqv[42]!=local[3]) goto compIF546;
	local[3]= argv[0];
	local[4]= fqv[43];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF547;
compIF546:
	local[3]= local[2];
	if (fqv[44]!=local[3]) goto compIF548;
	local[3]= argv[0];
	local[4]= fqv[23];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,1,local+5,&ftab[5],fqv[45]); /*macroexpand*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto compIF549;
compIF548:
	local[3]= local[2];
	if (fqv[46]!=local[3]) goto compIF550;
	local[3]= argv[0];
	local[4]= fqv[47];
	local[5]= local[0];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF551;
compIF550:
	if (T==NIL) goto compIF552;
	local[3]= argv[0];
	local[4]= fqv[6];
	local[5]= fqv[48];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF553;
compIF552:
	local[3]= NIL;
compIF553:
compIF551:
compIF549:
compIF547:
compIF545:
	w = local[3];
	local[0]= w;
	goto compCON533;
compCON543:
	local[0]= NIL;
compCON533:
	w = local[0];
	local[0]= w;
compBLK525:
	ctx->vsp=local; return(local[0]);}

/*:get-function*/
static pointer compM554compiler_get_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (issymbol(w)) goto compIF556;
	local[0]= argv[0];
	local[1]= fqv[6];
	local[2]= fqv[49];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto compIF557;
compIF556:
	local[0]= NIL;
compIF557:
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	if (local[0]==NIL) goto compIF558;
	local[1]= local[0];
	goto compIF559;
compIF558:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)FBOUNDP(ctx,1,local+1); /*fboundp*/
	if (w==NIL) goto compCON561;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)SYMFUNC(ctx,1,local+1); /*symbol-function*/
	local[0] = w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[50]); /*compiled-function-p*/
	if (w==NIL) goto compIF562;
	local[1]= argv[2];
	local[2]= local[0]->c.obj.iv[2];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)ASSQ(ctx,2,local+2); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	goto compIF563;
compIF562:
	local[1]= argv[2];
	w = local[0];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
compIF563:
	goto compCON560;
compCON561:
	local[1]= argv[2];
	local[2]= fqv[40];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	goto compCON560;
compCON564:
	local[1]= NIL;
compCON560:
compIF559:
	w = local[1];
	local[0]= w;
compBLK555:
	ctx->vsp=local; return(local[0]);}

/*:call-closure*/
static pointer compM565compiler_call_closure(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (loadglobal(fqv[52])==NIL) goto compIF567;
	local[0]= fqv[47];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)PRINT(ctx,1,local+0); /*print*/
	local[0]= w;
	goto compIF568;
compIF567:
	local[0]= NIL;
compIF568:
	local[0]= NIL;
	local[1]= argv[3];
compWHL569:
	if (local[1]==NIL) goto compWHX570;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto compWHL569;
compWHX570:
	local[2]= NIL;
compBLK571:
	w = NIL;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[53];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,1,local+4,&ftab[7],fqv[54]); /*fourth*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[47];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[55]); /*fifth*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
compBLK566:
	ctx->vsp=local; return(local[0]);}

/*:variable*/
static pointer compM572compiler_variable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[56];
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	if (local[0]==NIL) goto compIF574;
	w = local[0];
	ctx->vsp=local+1;
	local[0]=w;
	goto compBLK573;
	goto compIF575;
compIF574:
	local[1]= NIL;
compIF575:
	local[1]= loadglobal(fqv[57]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[58];
	local[4]= argv[2];
	local[5]= fqv[42];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	local[0] = w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)compF381proclaimed_special_p(ctx,1,local+1); /*proclaimed-special-p*/
	if (w==NIL) goto compCON577;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[59];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compCON576;
compCON577:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)compF382proclaimed_global_p(ctx,1,local+1); /*proclaimed-global-p*/
	if (w==NIL) goto compCON578;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[59];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compCON576;
compCON578:
	local[1]= loadglobal(fqv[60]);
	local[2]= fqv[61];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)27L);
	local[6]= makeint((eusinteger_t)27L);
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,6,local+1); /*format*/
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[17];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compCON576;
compCON579:
	local[1]= NIL;
compCON576:
	w = local[0];
	local[0]= w;
compBLK573:
	ctx->vsp=local; return(local[0]);}

/*:var-binding*/
static pointer compM580compiler_var_binding(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!iscons(w)) goto compIF582;
	local[0]= fqv[62];
	goto compIF583;
compIF582:
	local[0]= argv[0];
	local[1]= fqv[63];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
compIF583:
	w = local[0];
	local[0]= w;
compBLK581:
	ctx->vsp=local; return(local[0]);}

/*:special-variable-p*/
static pointer compM584compiler_special_variable_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[65];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]!=NIL) goto compIF586;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)compF381proclaimed_special_p(ctx,1,local+1); /*proclaimed-special-p*/
	local[1]= w;
	if (w!=NIL) goto compOR588;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)compF382proclaimed_global_p(ctx,1,local+1); /*proclaimed-global-p*/
	local[1]= w;
compOR588:
	goto compIF587;
compIF586:
	local[1]= local[0];
	local[2]= fqv[64];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[1]= ((fqv[42])==(local[1])?T:NIL);
compIF587:
	w = local[1];
	local[0]= w;
compBLK585:
	ctx->vsp=local; return(local[0]);}

/*:enter-variable*/
static pointer compM589compiler_enter_variable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[65];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	if (local[0]!=NIL) goto compIF591;
	local[1]= loadglobal(fqv[57]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[58];
	local[4]= argv[2];
	local[5]= fqv[66];
	local[6]= argv[0]->c.obj.iv[1];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	local[0] = w;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[17];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)compF381proclaimed_special_p(ctx,1,local+1); /*proclaimed-special-p*/
	if (w!=NIL) goto compOR595;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)compF382proclaimed_global_p(ctx,1,local+1); /*proclaimed-global-p*/
	if (w!=NIL) goto compOR595;
	goto compIF593;
compOR595:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[27]); /*constantp*/
	if (w==NIL) goto compIF596;
	local[1]= argv[0];
	local[2]= fqv[6];
	local[3]= fqv[67];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF597;
compIF596:
	local[1]= NIL;
compIF597:
	local[1]= local[0];
	local[2]= fqv[64];
	local[3]= fqv[42];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF594;
compIF593:
	local[1]= NIL;
compIF594:
	goto compIF592;
compIF591:
	local[1]= NIL;
compIF592:
	w = local[0];
	local[0]= w;
compBLK590:
	ctx->vsp=local; return(local[0]);}

/*:bind*/
static pointer compM598compiler_bind(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto compENT601;}
	local[0]= NIL;
compENT601:
compENT600:
	if (n>6) maerror();
	w = argv[2];
	if (issymbol(w)) goto compIF602;
	local[1]= fqv[68];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto compIF603;
compIF602:
	local[1]= NIL;
compIF603:
	local[1]= argv[0];
	local[2]= fqv[69];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[2];
	if (fqv[42]!=local[2]) goto compCON605;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[70];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[3];
	local[3]= local[2];
	if (fqv[71]!=local[3]) goto compIF606;
	if (local[0]==NIL) goto compIF608;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= fqv[72];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto compIF609;
compIF608:
	local[3]= NIL;
compIF609:
	goto compIF607;
compIF606:
	local[3]= local[2];
	if (fqv[73]!=local[3]) goto compIF610;
	local[3]= loadglobal(fqv[24]);
	local[4]= fqv[74];
	local[5]= argv[4];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF611;
compIF610:
	if (T==NIL) goto compIF612;
	local[3]= argv[0];
	local[4]= fqv[6];
	local[5]= fqv[75];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto compIF613;
compIF612:
	local[3]= NIL;
compIF613:
compIF611:
compIF607:
	w = local[3];
	local[2]= argv[4];
	w = argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	argv[0]->c.obj.iv[9] = cons(ctx,local[2],w);
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[76];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compCON604;
compCON605:
	local[2]= argv[3];
	if (fqv[71]!=local[2]) goto compIF615;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[72];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compIF616;
compIF615:
	local[2]= NIL;
compIF616:
	local[2]= argv[3];
	w = local[1];
	w->c.obj.iv[2] = local[2];
	local[2]= argv[4];
	local[3]= local[2];
	w = local[1];
	w->c.obj.iv[4] = local[3];
	goto compCON604;
compCON614:
	local[2]= NIL;
compCON604:
	w = local[1];
	local[0]= w;
compBLK599:
	ctx->vsp=local; return(local[0]);}

/*:create-frame*/
static pointer compM617compiler_create_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[77]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[58];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = local[0];
	local[0]= w;
	w = argv[0]->c.obj.iv[3];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[3] = cons(ctx,local[0],w);
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[78];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= fqv[79];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
compBLK618:
	ctx->vsp=local; return(local[0]);}

/*:delete-frame*/
static pointer compM619compiler_delete_frame(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= local[0]->c.obj.iv[1];
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto compIF621;
	if (argv[2]==NIL) goto compIF623;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[80];
	local[4]= local[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compIF624;
compIF623:
	local[2]= argv[0];
	local[3]= fqv[81];
	local[4]= fqv[82];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
compIF624:
	goto compIF622;
compIF621:
	local[2]= NIL;
compIF622:
	if (argv[2]==NIL) goto compIF625;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[83];
	local[4]= local[0]->c.obj.iv[1];
	local[5]= local[0]->c.obj.iv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto compIF626;
compIF625:
	local[2]= NIL;
compIF626:
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[84];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[79];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
compBLK620:
	ctx->vsp=local; return(local[0]);}

/*:load-ovaf*/
static pointer compM627compiler_load_ovaf(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= local[0];
	w = fqv[85];
	if (memq(local[2],w)!=NIL) goto compIF629;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)SYMVALUE(ctx,1,local+2); /*symbol-value*/
	local[0] = w;
	local[2]= local[0];
	goto compIF630;
compIF629:
	local[2]= NIL;
compIF630:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)CLASSP(ctx,1,local+2); /*classp*/
	if (w==NIL) goto compCON632;
	local[2]= argv[3];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)compF383object_variable_names(ctx,1,local+3); /*object-variable-names*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,2,local+2,&ftab[0],fqv[4]); /*position*/
	local[1] = w;
	w = local[1];
	if (!numberp(w)) goto compIF633;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[86];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compIF634;
compIF633:
	local[2]= argv[0];
	local[3]= fqv[6];
	local[4]= fqv[87];
	local[5]= argv[2];
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= w;
compIF634:
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)compF384object_variable_type(ctx,2,local+2); /*object-variable-type*/
	local[2]= w;
	goto compCON631;
compCON632:
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[36];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= T;
	goto compCON631;
compCON635:
	local[2]= NIL;
compCON631:
	w = local[2];
	local[0]= w;
compBLK628:
	ctx->vsp=local; return(local[0]);}

/*:load-var*/
static pointer compM636compiler_load_var(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!iscons(w)) goto compIF638;
	local[0]= argv[0];
	local[1]= fqv[36];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	w = T;
	ctx->vsp=local+0;
	local[0]=w;
	goto compBLK637;
	goto compIF639;
compIF638:
	local[0]= NIL;
compIF639:
	local[0]= argv[0];
	local[1]= fqv[63];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[2] = w;
	local[0]= *(ovafptr(argv[2],fqv[88]));
	local[1]= local[0];
	w = fqv[89];
	if (memq(local[1],w)==NIL) goto compIF640;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[90];
	local[3]= *(ovafptr(argv[2],fqv[16]));
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF641;
compIF640:
	local[1]= local[0];
	w = fqv[91];
	if (memq(local[1],w)==NIL) goto compIF642;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[53];
	local[3]= *(ovafptr(argv[2],fqv[92]));
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= *(ovafptr(argv[2],fqv[93]));
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF643;
compIF642:
	local[1]= local[0];
	w = fqv[94];
	if (memq(local[1],w)==NIL) goto compIF644;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[74];
	local[3]= *(ovafptr(argv[2],fqv[92]));
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= *(ovafptr(argv[2],fqv[93]));
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF645;
compIF644:
	local[1]= local[0];
	w = fqv[95];
	if (memq(local[1],w)==NIL) goto compIF646;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[96];
	local[3]= *(ovafptr(argv[2],fqv[92]));
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= *(ovafptr(argv[2],fqv[93]));
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF647;
compIF646:
	local[1]= local[0];
	if (fqv[66]!=local[1]) goto compIF648;
	local[1]= argv[0];
	local[2]= fqv[6];
	local[3]= fqv[97];
	local[4]= *(ovafptr(argv[2],fqv[16]));
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF649;
compIF648:
	local[1]= NIL;
compIF649:
compIF647:
compIF645:
compIF643:
compIF641:
	w = local[1];
	local[0]= argv[2];
	local[1]= fqv[98];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
compBLK637:
	ctx->vsp=local; return(local[0]);}

/*:store-ovaf*/
static pointer compM650compiler_store_ovaf(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	w = fqv[99];
	if (memq(local[1],w)!=NIL) goto compIF652;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)SYMVALUE(ctx,1,local+1); /*symbol-value*/
	local[0] = w;
	local[1]= local[0];
	goto compIF653;
compIF652:
	local[1]= NIL;
compIF653:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)CLASSP(ctx,1,local+1); /*classp*/
	if (w==NIL) goto compIF654;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[100];
	local[3]= argv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)compF383object_variable_names(ctx,1,local+4); /*object-variable-names*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[4]); /*position*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF655;
compIF654:
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[101];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
compIF655:
	w = local[1];
	local[0]= w;
compBLK651:
	ctx->vsp=local; return(local[0]);}

/*:store-var*/
static pointer compM656compiler_store_var(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[63];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[2] = w;
	local[0]= *(ovafptr(argv[2],fqv[88]));
	local[1]= local[0];
	w = fqv[102];
	if (memq(local[1],w)==NIL) goto compIF658;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[103];
	local[3]= *(ovafptr(argv[2],fqv[16]));
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF659;
compIF658:
	local[1]= local[0];
	w = fqv[104];
	if (memq(local[1],w)==NIL) goto compIF660;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[105];
	local[3]= *(ovafptr(argv[2],fqv[92]));
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= *(ovafptr(argv[2],fqv[93]));
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF661;
compIF660:
	local[1]= local[0];
	w = fqv[106];
	if (memq(local[1],w)==NIL) goto compIF662;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[107];
	local[3]= *(ovafptr(argv[2],fqv[92]));
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= *(ovafptr(argv[2],fqv[93]));
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF663;
compIF662:
	local[1]= local[0];
	w = fqv[108];
	if (memq(local[1],w)==NIL) goto compIF664;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[109];
	local[3]= *(ovafptr(argv[2],fqv[92]));
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= *(ovafptr(argv[2],fqv[93]));
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF665;
compIF664:
	local[1]= NIL;
compIF665:
compIF663:
compIF661:
compIF659:
	w = local[1];
	local[0]= w;
compBLK657:
	ctx->vsp=local; return(local[0]);}

/*:funcall*/
static pointer compM666compiler_funcall(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	w = fqv[110];
	if (memq(local[3],w)!=NIL) goto compIF668;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,compCLO670,env,argv,local);
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[1] = w;
	local[3]= local[1];
	goto compIF669;
compIF668:
	local[3]= NIL;
compIF669:
	local[3]= argv[2];
	local[4]= local[3];
	w = fqv[111];
	if (memq(local[4],w)==NIL) goto compIF671;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= fqv[112];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[113];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= fqv[30];
	goto compIF672;
compIF671:
	local[4]= local[3];
	w = fqv[114];
	if (memq(local[4],w)==NIL) goto compIF673;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	local[6]= fqv[115];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[116];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= fqv[30];
	goto compIF674;
compIF673:
	local[4]= local[3];
	w = fqv[117];
	if (memq(local[4],w)==NIL) goto compIF675;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	local[6]= fqv[118];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[119];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF676;
compIF675:
	local[4]= local[3];
	w = fqv[120];
	if (memq(local[4],w)==NIL) goto compIF677;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= fqv[121];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isint(w)) goto compCON680;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[122];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= fqv[9];
	goto compCON679;
compCON680:
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isflt(w)) goto compCON681;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= fqv[11];
	goto compCON679;
compCON681:
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= fqv[30];
	goto compCON679;
compCON682:
	local[4]= NIL;
compCON679:
	goto compIF678;
compIF677:
	local[4]= local[3];
	w = fqv[124];
	if (memq(local[4],w)==NIL) goto compIF683;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= fqv[125];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isint(w)) goto compCON686;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[126];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= fqv[9];
	goto compCON685;
compCON686:
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isflt(w)) goto compCON687;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= fqv[11];
	goto compCON685;
compCON687:
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= fqv[30];
	goto compCON685;
compCON688:
	local[4]= NIL;
compCON685:
	goto compIF684;
compIF683:
	local[4]= local[3];
	w = fqv[127];
	if (memq(local[4],w)==NIL) goto compIF689;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[128];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF690;
compIF689:
	local[4]= local[3];
	w = fqv[129];
	if (memq(local[4],w)==NIL) goto compIF691;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[130];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF692;
compIF691:
	local[4]= local[3];
	w = fqv[131];
	if (memq(local[4],w)==NIL) goto compIF693;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[132];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF694;
compIF693:
	local[4]= local[3];
	w = fqv[133];
	if (memq(local[4],w)==NIL) goto compIF695;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[134];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF696;
compIF695:
	local[4]= local[3];
	w = fqv[135];
	if (memq(local[4],w)==NIL) goto compIF697;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[136];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF698;
compIF697:
	local[4]= local[3];
	w = fqv[137];
	if (memq(local[4],w)==NIL) goto compIF699;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[138];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF700;
compIF699:
	local[4]= local[3];
	w = fqv[139];
	if (memq(local[4],w)==NIL) goto compIF701;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[140];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF702;
compIF701:
	local[4]= local[3];
	w = fqv[141];
	if (memq(local[4],w)==NIL) goto compIF703;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	local[6]= fqv[142];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[143];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF704;
compIF703:
	local[4]= local[3];
	w = fqv[144];
	if (memq(local[4],w)==NIL) goto compIF705;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[145];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= T;
	goto compIF706;
compIF705:
	local[4]= local[3];
	w = fqv[146];
	if (memq(local[4],w)==NIL) goto compIF707;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	local[6]= fqv[147];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[148];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF708;
compIF707:
	local[4]= local[3];
	w = fqv[149];
	if (memq(local[4],w)==NIL) goto compIF709;
	local[4]= makeint((eusinteger_t)3L);
	local[5]= local[0];
	local[6]= fqv[150];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[151];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= T;
	goto compIF710;
compIF709:
	local[4]= local[3];
	w = fqv[152];
	if (memq(local[4],w)==NIL) goto compIF711;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[153];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto compIF712;
compIF711:
	local[4]= local[3];
	w = fqv[154];
	if (memq(local[4],w)==NIL) goto compIF713;
	local[4]= makeint((eusinteger_t)3L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[155];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto compIF714;
compIF713:
	local[4]= local[3];
	w = fqv[156];
	if (memq(local[4],w)==NIL) goto compIF715;
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[157];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto compIF716;
compIF715:
	local[4]= local[3];
	w = fqv[158];
	if (memq(local[4],w)==NIL) goto compIF717;
	local[4]= makeint((eusinteger_t)3L);
	local[5]= local[0];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[159];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto compIF718;
compIF717:
	local[4]= local[3];
	w = fqv[160];
	if (memq(local[4],w)==NIL) goto compIF719;
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= fqv[161];
	ctx->vsp=local+7;
	w=(pointer)ASSQ(ctx,2,local+5); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto compIF721;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto compIF722;
compIF721:
	local[4]= argv[0];
	local[5]= fqv[162];
	local[6]= argv[2];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
compIF722:
	goto compIF720;
compIF719:
	local[4]= local[3];
	w = fqv[163];
	if (memq(local[4],w)==NIL) goto compIF723;
	local[4]= argv[0];
	local[5]= fqv[164];
	local[6]= argv[2];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto compIF724;
compIF723:
	local[4]= local[3];
	w = fqv[165];
	if (memq(local[4],w)==NIL) goto compIF725;
	local[4]= makeint((eusinteger_t)3L);
	local[5]= local[0];
	local[6]= fqv[166];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= argv[0];
	local[5]= fqv[167];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto compIF726;
compIF725:
	local[4]= local[3];
	w = fqv[168];
	if (memq(local[4],w)==NIL) goto compIF727;
	local[4]= makeint((eusinteger_t)4L);
	local[5]= local[0];
	local[6]= fqv[169];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	local[4]= argv[0];
	local[5]= fqv[170];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,1,local+9,&ftab[7],fqv[54]); /*fourth*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	local[4]= w;
	goto compIF728;
compIF727:
	local[4]= local[3];
	w = fqv[171];
	if (memq(local[4],w)==NIL) goto compIF729;
	local[4]= makeint((eusinteger_t)1L);
	local[5]= local[0];
	local[6]= fqv[172];
	ctx->vsp=local+7;
	w=(pointer)compF386check_arg(ctx,3,local+4); /*check-arg*/
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)compF385coerce_type(ctx,1,local+4); /*coerce-type*/
	local[4]= w;
	local[5]= fqv[9];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w==NIL) goto compCON732;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[173];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= fqv[9];
	goto compCON731;
compCON732:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)compF385coerce_type(ctx,1,local+4); /*coerce-type*/
	local[4]= w;
	local[5]= fqv[11];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w==NIL) goto compCON733;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[174];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= fqv[11];
	goto compCON731;
compCON733:
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= T;
	goto compCON731;
compCON734:
	local[4]= NIL;
compCON731:
	goto compIF730;
compIF729:
	if (T==NIL) goto compIF735;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[123];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	w = argv[2];
	if (!issymbol(w)) goto compIF737;
	local[4]= argv[2];
	local[5]= fqv[15];
	ctx->vsp=local+6;
	w=(pointer)GETPROP(ctx,2,local+4); /*get*/
	local[4]= w;
	goto compIF738;
compIF737:
	local[4]= T;
compIF738:
	goto compIF736;
compIF735:
	local[4]= NIL;
compIF736:
compIF730:
compIF728:
compIF726:
compIF724:
compIF720:
compIF718:
compIF716:
compIF714:
compIF712:
compIF710:
compIF708:
compIF706:
compIF704:
compIF702:
compIF700:
compIF698:
compIF696:
compIF694:
compIF692:
compIF690:
compIF684:
compIF678:
compIF676:
compIF674:
compIF672:
	w = local[4];
	local[0]= w;
compBLK667:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO670(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[23];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:vector-op*/
static pointer compM739compiler_vector_op(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	w=argv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[2];
	local[2]= fqv[175];
	ctx->vsp=local+3;
	w=(pointer)ASSQ(ctx,2,local+1); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	w = local[0];
	if (!issymbol(w)) goto compIF741;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)BOUNDP(ctx,1,local+2); /*boundp*/
	if (w==NIL) goto compIF741;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)SYMVALUE(ctx,1,local+2); /*symbol-value*/
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)CLASSP(ctx,1,local+2); /*classp*/
	if (w==NIL) goto compIF741;
	local[2]= local[0];
	local[3]= loadglobal(fqv[176]);
	ctx->vsp=local+4;
	w=(pointer)SUBCLASSP(ctx,2,local+2); /*subclassp*/
	if (w==NIL) goto compCON744;
	local[2]= loadglobal(fqv[24]);
	local[3]= local[1];
	local[4]= fqv[9];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= fqv[9];
	goto compCON743;
compCON744:
	local[2]= local[0];
	local[3]= loadglobal(fqv[177]);
	ctx->vsp=local+4;
	w=(pointer)SUBCLASSP(ctx,2,local+2); /*subclassp*/
	if (w==NIL) goto compCON745;
	local[2]= loadglobal(fqv[24]);
	local[3]= local[1];
	local[4]= fqv[178];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= fqv[9];
	goto compCON743;
compCON745:
	local[2]= local[0];
	local[3]= loadglobal(fqv[179]);
	ctx->vsp=local+4;
	w=(pointer)SUBCLASSP(ctx,2,local+2); /*subclassp*/
	if (w==NIL) goto compCON746;
	local[2]= loadglobal(fqv[24]);
	local[3]= local[1];
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= fqv[11];
	goto compCON743;
compCON746:
	local[2]= local[0];
	local[3]= loadglobal(fqv[180]);
	ctx->vsp=local+4;
	w=(pointer)SUBCLASSP(ctx,2,local+2); /*subclassp*/
	if (w==NIL) goto compCON747;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[123];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= fqv[9];
	goto compCON743;
compCON747:
	local[2]= local[0];
	local[3]= loadglobal(fqv[181]);
	ctx->vsp=local+4;
	w=(pointer)SUBCLASSP(ctx,2,local+2); /*subclassp*/
	if (w==NIL) goto compCON748;
	local[2]= loadglobal(fqv[24]);
	local[3]= local[1];
	local[4]= fqv[182];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= T;
	goto compCON743;
compCON748:
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[123];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= T;
	goto compCON743;
compCON749:
	local[2]= NIL;
compCON743:
	goto compIF742;
compIF741:
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[123];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
compIF742:
	w = local[2];
	local[0]= w;
compBLK740:
	ctx->vsp=local; return(local[0]);}

/*:slot*/
static pointer compM750compiler_slot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = argv[4];
	if (numberp(w)) goto compIF752;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)compF379class_symbolp(ctx,1,local+1); /*class-symbolp*/
	if (w==NIL) goto compIF752;
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)compF380quoted_symbolp(ctx,1,local+1); /*quoted-symbolp*/
	if (w==NIL) goto compIF752;
	w=argv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SYMVALUE(ctx,1,local+2); /*symbol-value*/
	local[2]= *(ovafptr(w,fqv[2]));
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[4]); /*position*/
	local[0] = w;
	if (local[0]==NIL) goto compIF752;
	argv[4] = local[0];
	local[1]= argv[4];
	goto compIF753;
compIF752:
	local[1]= NIL;
compIF753:
	w = argv[4];
	if (!numberp(w)) goto compCON755;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[86];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[3];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)compF384object_variable_type(ctx,2,local+1); /*object-variable-type*/
	local[1]= w;
	goto compCON754;
compCON755:
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[123];
	local[3]= fqv[166];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compCON754;
compCON756:
	local[1]= NIL;
compCON754:
	w = local[1];
	local[0]= w;
compBLK751:
	ctx->vsp=local; return(local[0]);}

/*:setslot*/
static pointer compM757compiler_setslot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= NIL;
	w = argv[4];
	if (numberp(w)) goto compIF759;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)compF379class_symbolp(ctx,1,local+1); /*class-symbolp*/
	if (w==NIL) goto compIF759;
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)compF380quoted_symbolp(ctx,1,local+1); /*quoted-symbolp*/
	if (w==NIL) goto compIF759;
	w=argv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SYMVALUE(ctx,1,local+2); /*symbol-value*/
	local[2]= *(ovafptr(w,fqv[2]));
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[4]); /*position*/
	local[0] = w;
	if (local[0]==NIL) goto compIF759;
	argv[4] = local[0];
	local[1]= argv[4];
	goto compIF760;
compIF759:
	local[1]= NIL;
compIF760:
	w = argv[4];
	if (!numberp(w)) goto compCON762;
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[183];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[100];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[3];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)compF384object_variable_type(ctx,2,local+1); /*object-variable-type*/
	local[1]= w;
	goto compCON761;
compCON762:
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[123];
	local[3]= fqv[169];
	local[4]= makeint((eusinteger_t)4L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compCON761;
compCON763:
	local[1]= NIL;
compCON761:
	w = local[1];
	local[0]= w;
compBLK758:
	ctx->vsp=local; return(local[0]);}

/*:arithmetic*/
static pointer compM764compiler_arithmetic(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= loadglobal(fqv[184]);
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto compIF766;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[123];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= T;
	goto compIF767;
compIF766:
	local[0]= argv[2];
	if (fqv[185]!=local[0]) goto compCON769;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,compCLO772,env,argv,local);
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(*ftab[9])(ctx,2,local+0,&ftab[9],fqv[186]); /*every*/
	if (w==NIL) goto compCON771;
	local[0]= argv[3];
	local[1]= local[0];
	w = fqv[187];
	if (memq(local[1],w)==NIL) goto compIF773;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[188];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto compIF774;
compIF773:
	local[1]= local[0];
	w = fqv[189];
	if (memq(local[1],w)==NIL) goto compIF775;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[190];
	local[3]= fqv[185];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF776;
compIF775:
	if (T==NIL) goto compIF777;
compWHL779:
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[3] = w;
	local[1]= argv[3];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto compWHX780;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[190];
	local[3]= fqv[191];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	goto compWHL779;
compWHX780:
	local[1]= NIL;
compBLK781:
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[188];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[190];
	local[3]= fqv[191];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF778;
compIF777:
	local[1]= NIL;
compIF778:
compIF776:
compIF774:
	w = local[1];
	local[0]= fqv[9];
	goto compCON770;
compCON771:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,compCLO783,env,argv,local);
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(*ftab[9])(ctx,2,local+0,&ftab[9],fqv[186]); /*every*/
	if (w==NIL) goto compCON782;
	local[0]= argv[3];
	local[1]= local[0];
	w = fqv[192];
	if (memq(local[1],w)==NIL) goto compIF784;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[193];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto compIF785;
compIF784:
	local[1]= local[0];
	w = fqv[194];
	if (memq(local[1],w)==NIL) goto compIF786;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[195];
	local[3]= fqv[185];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF787;
compIF786:
	if (T==NIL) goto compIF788;
compWHL790:
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[3] = w;
	local[1]= argv[3];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto compWHX791;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[195];
	local[3]= fqv[191];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	goto compWHL790;
compWHX791:
	local[1]= NIL;
compBLK792:
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[193];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[195];
	local[3]= fqv[191];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF789;
compIF788:
	local[1]= NIL;
compIF789:
compIF787:
compIF785:
	w = local[1];
	local[0]= fqv[11];
	goto compCON770;
compCON782:
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[123];
	local[2]= fqv[185];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= T;
	goto compCON770;
compCON793:
	local[0]= NIL;
compCON770:
	goto compCON768;
compCON769:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,compCLO797,env,argv,local);
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(*ftab[9])(ctx,2,local+0,&ftab[9],fqv[186]); /*every*/
	if (w==NIL) goto compCON796;
compWHL798:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[3] = w;
	local[0]= argv[3];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto compWHX799;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[190];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	goto compWHL798;
compWHX799:
	local[0]= NIL;
compBLK800:
	local[0]= fqv[9];
	goto compCON795;
compCON796:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,compCLO802,env,argv,local);
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(*ftab[9])(ctx,2,local+0,&ftab[9],fqv[186]); /*every*/
	if (w==NIL) goto compCON801;
compWHL803:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[3] = w;
	local[0]= argv[3];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto compWHX804;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[195];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	goto compWHL803;
compWHX804:
	local[0]= NIL;
compBLK805:
	local[0]= fqv[11];
	goto compCON795;
compCON801:
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[123];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= T;
	goto compCON795;
compCON806:
	local[0]= NIL;
compCON795:
	goto compCON768;
compCON794:
	local[0]= NIL;
compCON768:
compIF767:
	w = local[0];
	local[0]= w;
compBLK765:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO772(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[196];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO783(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[197];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO797(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[198];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO802(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[199];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:special-form*/
static pointer compM807compiler_special_form(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= local[0];
	w = fqv[200];
	if (memq(local[1],w)==NIL) goto compIF809;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[32];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF810;
compIF809:
	local[1]= local[0];
	w = fqv[201];
	if (memq(local[1],w)==NIL) goto compIF811;
	local[1]= argv[0];
	local[2]= fqv[202];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF812;
compIF811:
	local[1]= local[0];
	w = fqv[203];
	if (memq(local[1],w)==NIL) goto compIF813;
	local[1]= argv[0];
	local[2]= fqv[204];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF814;
compIF813:
	local[1]= local[0];
	w = fqv[205];
	if (memq(local[1],w)==NIL) goto compIF815;
	local[1]= argv[0];
	local[2]= fqv[206];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF816;
compIF815:
	local[1]= local[0];
	w = fqv[207];
	if (memq(local[1],w)==NIL) goto compIF817;
	local[1]= argv[0];
	local[2]= fqv[208];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF818;
compIF817:
	local[1]= local[0];
	w = fqv[209];
	if (memq(local[1],w)==NIL) goto compIF819;
	local[1]= argv[0];
	local[2]= fqv[210];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF820;
compIF819:
	local[1]= local[0];
	w = fqv[211];
	if (memq(local[1],w)==NIL) goto compIF821;
	local[1]= argv[0];
	local[2]= fqv[212];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF822;
compIF821:
	local[1]= local[0];
	w = fqv[213];
	if (memq(local[1],w)==NIL) goto compIF823;
	local[1]= argv[0];
	local[2]= fqv[214];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF824;
compIF823:
	local[1]= local[0];
	w = fqv[215];
	if (memq(local[1],w)==NIL) goto compIF825;
	local[1]= argv[0];
	local[2]= fqv[216];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF826;
compIF825:
	local[1]= local[0];
	w = fqv[217];
	if (memq(local[1],w)==NIL) goto compIF827;
	local[1]= argv[0];
	local[2]= fqv[218];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compIF828;
compIF827:
	local[1]= local[0];
	w = fqv[219];
	if (memq(local[1],w)==NIL) goto compIF829;
	local[1]= argv[0];
	local[2]= fqv[220];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compIF830;
compIF829:
	local[1]= local[0];
	w = fqv[221];
	if (memq(local[1],w)==NIL) goto compIF831;
	local[1]= argv[0];
	local[2]= fqv[222];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compIF832;
compIF831:
	local[1]= local[0];
	w = fqv[223];
	if (memq(local[1],w)==NIL) goto compIF833;
	local[1]= argv[0];
	local[2]= fqv[224];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compIF834;
compIF833:
	local[1]= local[0];
	w = fqv[225];
	if (memq(local[1],w)==NIL) goto compIF835;
	local[1]= argv[0];
	local[2]= fqv[226];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF836;
compIF835:
	local[1]= local[0];
	w = fqv[227];
	if (memq(local[1],w)==NIL) goto compIF837;
	local[1]= argv[0];
	local[2]= fqv[228];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF838;
compIF837:
	local[1]= local[0];
	w = fqv[229];
	if (memq(local[1],w)==NIL) goto compIF839;
	local[1]= argv[0];
	local[2]= fqv[230];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= T;
	goto compIF840;
compIF839:
	local[1]= local[0];
	w = fqv[231];
	if (memq(local[1],w)==NIL) goto compIF841;
	local[1]= argv[0];
	local[2]= fqv[230];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= T;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[1]= T;
	goto compIF842;
compIF841:
	local[1]= local[0];
	w = fqv[232];
	if (memq(local[1],w)==NIL) goto compIF843;
	local[1]= argv[0];
	local[2]= fqv[233];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= T;
	goto compIF844;
compIF843:
	local[1]= local[0];
	w = fqv[234];
	if (memq(local[1],w)==NIL) goto compIF845;
	local[1]= argv[0];
	local[2]= fqv[235];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF846;
compIF845:
	local[1]= local[0];
	w = fqv[236];
	if (memq(local[1],w)==NIL) goto compIF847;
	local[1]= argv[0];
	local[2]= fqv[237];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF848;
compIF847:
	local[1]= local[0];
	w = fqv[238];
	if (memq(local[1],w)==NIL) goto compIF849;
	local[1]= argv[0];
	local[2]= fqv[23];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)compF385coerce_type(ctx,1,local+1); /*coerce-type*/
	local[1]= w;
	goto compIF850;
compIF849:
	local[1]= local[0];
	w = fqv[239];
	if (memq(local[1],w)==NIL) goto compIF851;
	local[1]= argv[0];
	local[2]= fqv[81];
	local[3]= fqv[240];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF852;
compIF851:
	local[1]= local[0];
	w = fqv[241];
	if (memq(local[1],w)==NIL) goto compIF853;
	local[1]= argv[0];
	local[2]= fqv[81];
	local[3]= fqv[242];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF854;
compIF853:
	local[1]= local[0];
	w = fqv[243];
	if (memq(local[1],w)==NIL) goto compIF855;
	local[1]= argv[0];
	local[2]= fqv[81];
	local[3]= fqv[244];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF856;
compIF855:
	local[1]= local[0];
	w = fqv[245];
	if (memq(local[1],w)==NIL) goto compIF857;
	local[1]= argv[0];
	local[2]= fqv[81];
	local[3]= fqv[246];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= T;
	goto compIF858;
compIF857:
	if (T==NIL) goto compIF859;
	local[1]= argv[0];
	local[2]= fqv[6];
	local[3]= fqv[247];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF860;
compIF859:
	local[1]= NIL;
compIF860:
compIF858:
compIF856:
compIF854:
compIF852:
compIF850:
compIF848:
compIF846:
compIF844:
compIF842:
compIF840:
compIF838:
compIF836:
compIF834:
compIF832:
compIF830:
compIF828:
compIF826:
compIF824:
compIF822:
compIF820:
compIF818:
compIF816:
compIF814:
compIF812:
compIF810:
	w = local[1];
	local[0]= w;
compBLK808:
	ctx->vsp=local; return(local[0]);}

/*:conditional-jump*/
static pointer compM861compiler_conditional_jump(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (argv[3]==NIL) goto compIF863;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[248];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto compIF864;
compIF863:
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[249];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
compIF864:
	w = local[0];
	local[0]= w;
compBLK862:
	ctx->vsp=local; return(local[0]);}

/*:evcon*/
static pointer compM865compiler_evcon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[4];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LISTP(ctx,1,local+5); /*listp*/
	if (w==NIL) goto compIF867;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	local[5]= local[1];
	goto compIF868;
compIF867:
	local[5]= NIL;
compIF868:
	w = argv[2];
	if (!iscons(w)) goto compOR871;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	w = makeint((eusinteger_t)1L);
	if ((eusinteger_t)local[5] <= (eusinteger_t)w) goto compOR871;
	goto compCON870;
compOR871:
	local[5]= argv[0];
	local[6]= fqv[23];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[250];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto compCON869;
compCON870:
	local[5]= local[0];
	if (fqv[115]!=local[5]) goto compCON872;
	local[5]= makeint((eusinteger_t)2L);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)compF386check_arg(ctx,3,local+5); /*check-arg*/
	local[5]= argv[0];
	local[6]= fqv[23];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[23];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (argv[4]==NIL) goto compIF873;
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[251];
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto compIF874;
compIF873:
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[252];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
compIF874:
	goto compCON869;
compCON872:
	local[5]= local[0];
	w = fqv[253];
	if (memq(local[5],w)==NIL) goto compCON875;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)compF386check_arg(ctx,3,local+5); /*check-arg*/
	local[5]= argv[0];
	local[6]= fqv[254];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= argv[4];
	local[9]= argv[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= w;
	goto compCON869;
compCON875:
	local[5]= local[0];
	if (fqv[255]!=local[5]) goto compCON876;
	if (argv[4]!=NIL) goto compIF877;
	local[5]= argv[0];
	local[6]= fqv[256];
	local[7]= fqv[257];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[4] = w;
	local[5]= local[4];
	goto compIF878;
compIF877:
	local[5]= NIL;
compIF878:
compWHL879:
	if (local[1]==NIL) goto compWHX880;
	local[5]= argv[0];
	local[6]= fqv[254];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	local[8]= NIL;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	goto compWHL879;
compWHX880:
	local[5]= NIL;
compBLK881:
	if (argv[4]!=NIL) goto compIF882;
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[258];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto compIF883;
compIF882:
	local[5]= NIL;
compIF883:
	goto compCON869;
compCON876:
	local[5]= local[0];
	if (fqv[260]!=local[5]) goto compCON884;
	if (argv[3]!=NIL) goto compIF885;
	local[5]= argv[0];
	local[6]= fqv[256];
	local[7]= fqv[261];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[4] = w;
	local[5]= local[4];
	goto compIF886;
compIF885:
	local[4] = argv[3];
	local[5]= local[4];
compIF886:
compWHL887:
	if (local[1]==NIL) goto compWHX888;
	local[5]= argv[0];
	local[6]= fqv[254];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	local[8]= local[4];
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	goto compWHL887;
compWHX888:
	local[5]= NIL;
compBLK889:
	if (argv[3]!=NIL) goto compIF890;
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[258];
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto compIF891;
compIF890:
	local[5]= NIL;
compIF891:
	goto compCON869;
compCON884:
	local[5]= local[0];
	w = fqv[262];
	if (memq(local[5],w)==NIL) goto compCON892;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)compF386check_arg(ctx,3,local+5); /*check-arg*/
	local[5]= argv[0];
	local[6]= fqv[23];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	if (argv[4]==NIL) goto compIF893;
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[263];
	local[7]= local[0];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto compIF894;
compIF893:
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[264];
	local[7]= local[0];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
compIF894:
	goto compCON869;
compCON892:
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	if (makeint((eusinteger_t)2L)!=local[5]) goto compCON895;
	local[5]= local[0];
	w = fqv[265];
	if (memq(local[5],w)==NIL) goto compCON895;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,compCLO896,env,argv,local);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[2] = w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[266];
	ctx->vsp=local+7;
	w=(*ftab[10])(ctx,2,local+5,&ftab[10],fqv[267]); /*member*/
	if (w==NIL) goto compCON898;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)EQ(ctx,2,local+5); /*eql*/
	if (w==NIL) goto compCON898;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[268];
	ctx->vsp=local+7;
	w=(pointer)ASSQ(ctx,2,local+5); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	if (argv[3]==NIL) goto compCON900;
	local[4] = argv[3];
	local[5]= local[4];
	goto compCON899;
compCON900:
	local[5]= local[0];
	local[6]= fqv[269];
	ctx->vsp=local+7;
	w=(pointer)ASSQ(ctx,2,local+5); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	local[5]= local[0];
	goto compCON899;
compCON901:
	local[5]= NIL;
compCON899:
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[270];
	local[7]= local[3];
	local[8]= local[0];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= w;
	goto compCON897;
compCON898:
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[123];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[250];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto compCON897;
compCON902:
	local[5]= NIL;
compCON897:
	goto compCON869;
compCON895:
	local[5]= argv[0];
	local[6]= fqv[23];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[250];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto compCON869;
compCON903:
	local[5]= NIL;
compCON869:
	w = local[5];
	local[0]= w;
compBLK866:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO896(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[23];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:if*/
static pointer compM904compiler_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[256];
	local[2]= fqv[271];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[256];
	local[3]= fqv[272];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[254];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= NIL;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[258];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[273];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[259];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[259];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
compBLK905:
	ctx->vsp=local; return(local[0]);}

/*:setq*/
static pointer compM906compiler_setq(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]!=NIL) goto compIF908;
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[26];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = T;
	ctx->vsp=local+0;
	local[0]=w;
	goto compBLK907;
	goto compIF909;
compIF908:
	local[0]= NIL;
compIF909:
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
compWHL910:
	if (argv[2]==NIL) goto compWHX911;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	local[2] = NIL;
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[3] = w;
	if (argv[2]!=NIL) goto compIF913;
	local[4]= argv[0];
	local[5]= fqv[274];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	w = fqv[275];
	if (memq(local[4],w)==NIL) goto compIF913;
	local[2] = T;
	local[4]= loadglobal(fqv[24]);
	local[5]= fqv[183];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto compIF914;
compIF913:
	local[4]= NIL;
compIF914:
	w = local[0];
	if (!issymbol(w)) goto compIF915;
	local[4]= argv[0];
	local[5]= fqv[276];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto compIF916;
compIF915:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	if (issymbol(w)) goto compIF917;
	local[4]= argv[0];
	local[5]= fqv[6];
	local[6]= fqv[277];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto compIF918;
compIF917:
	local[4]= NIL;
compIF918:
	local[4]= argv[0];
	local[5]= fqv[101];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
compIF916:
	local[4]= ((argv[2])==NIL?T:NIL);
	if (local[4]==NIL) goto compAND919;
	local[4]= ((local[2])==NIL?T:NIL);
	if (local[4]==NIL) goto compAND919;
	local[4]= argv[0];
	local[5]= fqv[33];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
compAND919:
	goto compWHL910;
compWHX911:
	local[4]= NIL;
compBLK912:
	w = local[3];
	local[0]= w;
compBLK907:
	ctx->vsp=local; return(local[0]);}

/*:let**/
static pointer compM920compiler_let_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[9];
	local[2]= argv[0];
	local[3]= fqv[78];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
compWHL922:
	if (argv[2]==NIL) goto compWHX923;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto compWHX923;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	if (fqv[278]!=local[2]) goto compWHX923;
	local[2]= argv[0];
	local[3]= fqv[279];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto compWHL922;
compWHX923:
	local[2]= NIL;
compBLK924:
	local[2]= NIL;
	local[3]= local[0];
compWHL925:
	if (local[3]==NIL) goto compWHX926;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)LISTP(ctx,1,local+6); /*listp*/
	if (w==NIL) goto compIF928;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	goto compIF929;
compIF928:
	local[6]= NIL;
compIF929:
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[280];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)LISTP(ctx,1,local+6); /*listp*/
	if (w==NIL) goto compIF930;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	goto compIF931;
compIF930:
	local[6]= local[2];
compIF931:
	local[7]= fqv[71];
	local[8]= loadglobal(fqv[24]);
	local[9]= fqv[281];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SUB1(ctx,1,local+8); /*1-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	goto compWHL925;
compWHX926:
	local[4]= NIL;
compBLK927:
	w = NIL;
	local[2]= argv[0];
	local[3]= fqv[235];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	argv[0]->c.obj.iv[9] = local[1];
	local[2]= argv[0];
	local[3]= fqv[282];
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
compBLK921:
	ctx->vsp=local; return(local[0]);}

/*:let*/
static pointer compM932compiler_let(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[9];
	local[5]= argv[0];
	local[6]= fqv[78];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
compWHL934:
	if (argv[2]==NIL) goto compWHX935;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto compWHX935;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	if (fqv[278]!=local[5]) goto compWHX935;
	local[5]= argv[0];
	local[6]= fqv[279];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	goto compWHL934;
compWHX935:
	local[5]= NIL;
compBLK936:
	local[5]= NIL;
	local[6]= local[0];
compWHL937:
	if (local[6]==NIL) goto compWHX938;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= argv[0]->c.obj.iv[0];
	local[8]= fqv[79];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SUB1(ctx,1,local+7); /*1-*/
	argv[0]->c.obj.iv[2] = w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)LISTP(ctx,1,local+7); /*listp*/
	if (w==NIL) goto compIF940;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	goto compIF941;
compIF940:
	local[7]= local[5];
compIF941:
	local[1] = local[7];
	local[7]= argv[0];
	local[8]= fqv[23];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)LISTP(ctx,1,local+9); /*listp*/
	if (w==NIL) goto compIF942;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	goto compIF943;
compIF942:
	local[9]= NIL;
compIF943:
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= loadglobal(fqv[24]);
	local[8]= fqv[281];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SUB1(ctx,1,local+7); /*1-*/
	local[3] = w;
	local[7]= argv[0];
	local[8]= fqv[283];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	if (w==NIL) goto compCON945;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[72];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= local[1];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,2,local+7); /*list*/
	local[7]= w;
	w = local[2];
	ctx->vsp=local+8;
	local[2] = cons(ctx,local[7],w);
	local[7]= local[2];
	goto compCON944;
compCON945:
	local[7]= argv[0];
	local[8]= fqv[280];
	local[9]= local[1];
	local[10]= fqv[71];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	goto compCON944;
compCON946:
	local[7]= NIL;
compCON944:
	goto compWHL937;
compWHX938:
	local[7]= NIL;
compBLK939:
	w = NIL;
	local[5]= NIL;
	local[6]= local[2];
compWHL947:
	if (local[6]==NIL) goto compWHX948;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= loadglobal(fqv[24]);
	local[8]= fqv[281];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[3] = w;
	local[7]= loadglobal(fqv[24]);
	local[8]= fqv[53];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[280];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[71];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	goto compWHL947;
compWHX948:
	local[7]= NIL;
compBLK949:
	w = NIL;
	local[5]= argv[0]->c.obj.iv[0];
	local[6]= fqv[79];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	argv[0]->c.obj.iv[2] = w;
	local[5]= argv[0];
	local[6]= fqv[235];
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	argv[0]->c.obj.iv[9] = local[4];
	local[5]= argv[0];
	local[6]= fqv[282];
	local[7]= T;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[0]= w;
compBLK933:
	ctx->vsp=local; return(local[0]);}

/*:cond*/
static pointer compM950compiler_cond(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
	local[5]= fqv[256];
	local[6]= fqv[284];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
compWHL952:
	if (argv[2]==NIL) goto compWHX953;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[5];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[5]= argv[0];
	local[6]= fqv[256];
	local[7]= fqv[285];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[2] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr!=NIL) goto compCON956;
	local[5]= argv[0];
	local[6]= fqv[23];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[183];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[249];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[25];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto compCON955;
compCON956:
	local[5]= local[1];
	if (T!=local[5]) goto compCON957;
	local[3] = T;
	local[5]= local[3];
	goto compCON955;
compCON957:
	local[5]= argv[0];
	local[6]= fqv[254];
	local[7]= local[1];
	local[8]= NIL;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= w;
	goto compCON955;
compCON958:
	local[5]= NIL;
compCON955:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto compIF959;
	local[5]= argv[0];
	local[6]= fqv[235];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[258];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[273];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	goto compIF960;
compIF959:
	local[5]= NIL;
compIF960:
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	goto compWHL952;
compWHX953:
	local[5]= NIL;
compBLK954:
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[26];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[0]= w;
compBLK951:
	ctx->vsp=local; return(local[0]);}

/*:while*/
static pointer compM961compiler_while(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= argv[0];
	local[3]= fqv[256];
	local[4]= fqv[286];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[256];
	local[5]= fqv[287];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[288];
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[254];
	local[7]= local[0];
	local[8]= NIL;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[235];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[25];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[258];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[26];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= loadglobal(fqv[24]);
	local[6]= fqv[259];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[289];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[0]= w;
compBLK962:
	ctx->vsp=local; return(local[0]);}

/*:and*/
static pointer compM963compiler_and(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[256];
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
compWHL965:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto compWHX966;
	local[1]= argv[0];
	local[2]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[183];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[248];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[25];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	goto compWHL965;
compWHX966:
	local[1]= NIL;
compBLK967:
	local[1]= argv[0];
	local[2]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[259];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
compBLK964:
	ctx->vsp=local; return(local[0]);}

/*:or*/
static pointer compM968compiler_or(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[256];
	local[2]= fqv[291];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
compWHL970:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto compWHX971;
	local[1]= argv[0];
	local[2]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[183];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[249];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[25];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	goto compWHL970;
compWHX971:
	local[1]= NIL;
compBLK972:
	local[1]= argv[0];
	local[2]= fqv[23];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[259];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
compBLK969:
	ctx->vsp=local; return(local[0]);}

/*:catch*/
static pointer compM973compiler_catch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[256];
	local[2]= fqv[292];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[281];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	w = argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[9] = cons(ctx,local[1],w);
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[293];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[235];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[294];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
compBLK974:
	ctx->vsp=local; return(local[0]);}

/*:throw*/
static pointer compM975compiler_throw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[224];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
compBLK976:
	ctx->vsp=local; return(local[0]);}

/*:unwind-protect*/
static pointer compM977compiler_unwind_protect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[256];
	local[2]= fqv[295];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[281];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	w = argv[0]->c.obj.iv[9];
	ctx->vsp=local+3;
	argv[0]->c.obj.iv[9] = cons(ctx,local[2],w);
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[296];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[297];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
	local[2]= argv[0];
	local[3]= fqv[298];
	local[4]= local[0];
	local[5]= fqv[40];
	local[6]= NIL;
	w = argv[3];
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[299];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[300];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.cdr;
	w = local[2];
	local[0]= w;
compBLK978:
	ctx->vsp=local; return(local[0]);}

/*:enter-block*/
static pointer compM979compiler_enter_block(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[281];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[256];
	local[3]= fqv[301];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	w = argv[2];
	if (issymbol(w)) goto compIF981;
	local[2]= argv[0];
	local[3]= fqv[81];
	local[4]= fqv[302];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compIF982;
compIF981:
	local[2]= NIL;
compIF982:
	local[2]= argv[2];
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	w = argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	argv[0]->c.obj.iv[4] = cons(ctx,local[2],w);
	w = local[1];
	local[0]= w;
compBLK980:
	ctx->vsp=local; return(local[0]);}

/*:leave-block*/
static pointer compM983compiler_leave_block(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[4] = (w)->c.cons.cdr;
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
compBLK984:
	ctx->vsp=local; return(local[0]);}

/*:block*/
static pointer compM985compiler_block(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[288];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[2] = w;
	local[0]= argv[0];
	local[1]= fqv[235];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[24]);
	local[1]= fqv[259];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[289];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
compBLK986:
	ctx->vsp=local; return(local[0]);}

/*:return-from*/
static pointer compM987compiler_return_from(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]!=NIL) goto compIF989;
	local[3]= argv[0];
	local[4]= fqv[6];
	local[5]= fqv[303];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF990;
compIF989:
	local[3]= NIL;
compIF990:
	local[3]= argv[0];
	local[4]= fqv[23];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= argv[0]->c.obj.iv[1];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto compIF991;
	local[3]= argv[0];
	local[4]= fqv[6];
	local[5]= fqv[304];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto compIF992;
compIF991:
	local[3]= NIL;
compIF992:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,1,local+3,&ftab[7],fqv[54]); /*fourth*/
	local[2] = w;
	local[3]= argv[0]->c.obj.iv[9];
	if (local[3]==NIL) goto compAND993;
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	local[3]= w;
compAND993:
	local[1] = local[3];
	local[3]= loadglobal(fqv[24]);
	local[4]= fqv[220];
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= loadglobal(fqv[24]);
	local[4]= fqv[258];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0]= w;
compBLK988:
	ctx->vsp=local; return(local[0]);}

/*:tagbody*/
static pointer compM994compiler_tagbody(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[281];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
compWHL996:
	if (local[2]==NIL) goto compWHX997;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	w = local[3];
	if (!!iscons(w)) goto compIF999;
	local[6]= local[3];
	local[7]= argv[0];
	local[8]= fqv[256];
	local[9]= fqv[305];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,3,local+6); /*list*/
	local[6]= w;
	w = argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	argv[0]->c.obj.iv[5] = cons(ctx,local[6],w);
	local[6]= argv[0]->c.obj.iv[5];
	goto compIF1000;
compIF999:
	local[6]= NIL;
compIF1000:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	goto compWHL996;
compWHX997:
	local[6]= NIL;
compBLK998:
compWHL1001:
	if (argv[2]==NIL) goto compWHX1002;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[6];
	local[5] = w;
	w = local[5];
	if (!!iscons(w)) goto compCON1005;
	local[6]= loadglobal(fqv[24]);
	local[7]= fqv[259];
	local[8]= local[5];
	local[9]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+10;
	w=(pointer)ASSQ(ctx,2,local+8); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto compCON1004;
compCON1005:
	local[6]= argv[0];
	local[7]= fqv[23];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= loadglobal(fqv[24]);
	local[7]= fqv[25];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	goto compCON1004;
compCON1006:
	local[6]= NIL;
compCON1004:
	goto compWHL1001;
compWHX1002:
	local[6]= NIL;
compBLK1003:
	local[6]= loadglobal(fqv[24]);
	local[7]= fqv[26];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	argv[0]->c.obj.iv[5] = local[0];
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
compBLK995:
	ctx->vsp=local; return(local[0]);}

/*:go*/
static pointer compM1007compiler_go(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]!=NIL) goto compIF1009;
	local[3]= argv[0];
	local[4]= fqv[6];
	local[5]= fqv[306];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto compIF1010;
compIF1009:
	local[3]= NIL;
compIF1010:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[3]= argv[0]->c.obj.iv[9];
	if (local[3]==NIL) goto compAND1011;
	w=argv[0]->c.obj.iv[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	local[3]= w;
compAND1011:
	local[2] = local[3];
	local[3]= loadglobal(fqv[24]);
	local[4]= fqv[307];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= loadglobal(fqv[24]);
	local[4]= fqv[258];
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[0]= w;
compBLK1008:
	ctx->vsp=local; return(local[0]);}

/*:function*/
static pointer compM1012compiler_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	if (!issymbol(w)) goto compIF1014;
	local[0]= argv[0];
	local[1]= fqv[39];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	if (fqv[46]!=local[1]) goto compIF1016;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[53];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,1,local+5,&ftab[7],fqv[54]); /*fourth*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto compIF1017;
compIF1016:
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[308];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
compIF1017:
	w = local[1];
	local[0]= w;
	goto compIF1015;
compIF1014:
	local[0]= argv[0];
	local[1]= fqv[256];
	local[2]= fqv[309];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[296];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[297];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
	local[2]= argv[0];
	local[3]= fqv[298];
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
compIF1015:
	w = local[0];
	local[0]= w;
compBLK1013:
	ctx->vsp=local; return(local[0]);}

/*:flet*/
static pointer compM1018compiler_flet(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[8];
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= argv[2];
compWHL1020:
	if (local[7]==NIL) goto compWHX1021;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= argv[0];
	local[9]= fqv[256];
	local[10]= fqv[310];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[2] = w;
	local[8]= loadglobal(fqv[24]);
	local[9]= fqv[296];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[46];
	local[10]= loadglobal(fqv[24]);
	local[11]= fqv[281];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SUB1(ctx,1,local+10); /*1-*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[1];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,5,local+8); /*list*/
	local[8]= w;
	w = argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	argv[0]->c.obj.iv[8] = cons(ctx,local[8],w);
	local[8]= argv[0];
	local[9]= fqv[297];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[3] = w;
	local[8]= local[3];
	w = local[4];
	ctx->vsp=local+9;
	local[4] = cons(ctx,local[8],w);
	local[8]= argv[0];
	local[9]= fqv[298];
	local[10]= local[2];
	local[11]= fqv[40];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,3,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	goto compWHL1020;
compWHX1021:
	local[8]= NIL;
compBLK1022:
	w = NIL;
	if (argv[4]==NIL) goto compIF1023;
	local[6]= local[4];
	local[7]= fqv[311];
	local[8]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+9;
	w=(*ftab[11])(ctx,3,local+6,&ftab[11],fqv[312]); /*send-all*/
	local[6]= w;
	goto compIF1024;
compIF1023:
	local[6]= NIL;
compIF1024:
	local[6]= argv[0];
	local[7]= fqv[235];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+8;
	w=(pointer)NTHCDR(ctx,2,local+6); /*nthcdr*/
	argv[0]->c.obj.iv[8] = w;
	local[6]= loadglobal(fqv[24]);
	local[7]= fqv[83];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[0]= w;
compBLK1019:
	ctx->vsp=local; return(local[0]);}

/*:change-flets*/
static pointer compM1025compiler_change_flets(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[8] = argv[2];
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
compBLK1026:
	ctx->vsp=local; return(local[0]);}

/*:declare*/
static pointer compM1027compiler_declare(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[2];
compWHL1029:
	if (local[2]==NIL) goto compWHX1030;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[3];
	if (fqv[42]!=local[4]) goto compIF1032;
	local[4]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
compWHL1034:
	if (local[5]==NIL) goto compWHX1035;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[69];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[0] = w;
	local[6]= fqv[42];
	local[7]= local[6];
	w = local[0];
	w->c.obj.iv[2] = local[7];
	goto compWHL1034;
compWHX1035:
	local[6]= NIL;
compBLK1036:
	w = NIL;
	local[4]= w;
	goto compIF1033;
compIF1032:
	local[4]= local[3];
	if (fqv[313]!=local[4]) goto compIF1037;
	local[4]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
compWHL1039:
	if (local[5]==NIL) goto compWHX1040;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[69];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[0] = w;
	local[6]= local[0];
	local[7]= fqv[98];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	goto compWHL1039;
compWHX1040:
	local[6]= NIL;
compBLK1041:
	w = NIL;
	local[4]= w;
	goto compIF1038;
compIF1037:
	local[4]= local[3];
	if (fqv[314]!=local[4]) goto compIF1042;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	ctx->vsp=local+6;
	w=(pointer)compF387def_function_type(ctx,2,local+4); /*def-function-type*/
	local[4]= w;
	goto compIF1043;
compIF1042:
	local[4]= local[3];
	w = fqv[315];
	if (memq(local[4],w)==NIL) goto compIF1044;
	local[4]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
compWHL1046:
	if (local[5]==NIL) goto compWHX1047;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[69];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[0] = w;
	local[6]= local[0];
	local[7]= fqv[98];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	goto compWHL1046;
compWHX1047:
	local[6]= NIL;
compBLK1048:
	w = NIL;
	local[4]= w;
	goto compIF1045;
compIF1044:
	local[4]= local[3];
	if (fqv[316]!=local[4]) goto compIF1049;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	storeglobal(fqv[317],local[4]);
	goto compIF1050;
compIF1049:
	local[4]= local[3];
	if (fqv[318]!=local[4]) goto compIF1051;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	storeglobal(fqv[184],local[4]);
	goto compIF1052;
compIF1051:
	local[4]= local[3];
	if (fqv[319]!=local[4]) goto compIF1053;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	storeglobal(fqv[320],local[4]);
	goto compIF1054;
compIF1053:
	local[4]= local[3];
	if (fqv[321]!=local[4]) goto compIF1055;
	local[4]= NIL;
	goto compIF1056;
compIF1055:
	local[4]= local[3];
	if (fqv[322]!=local[4]) goto compIF1057;
	local[4]= NIL;
	goto compIF1058;
compIF1057:
	if (T==NIL) goto compIF1059;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)compF379class_symbolp(ctx,1,local+4); /*class-symbolp*/
	if (w==NIL) goto compCON1062;
	local[4]= NIL;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
compWHL1063:
	if (local[5]==NIL) goto compWHX1064;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= argv[0];
	local[7]= fqv[69];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[0] = w;
	local[6]= local[0];
	local[7]= fqv[98];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	goto compWHL1063;
compWHX1064:
	local[6]= NIL;
compBLK1065:
	w = NIL;
	local[4]= w;
	goto compCON1061;
compCON1062:
	local[4]= argv[0];
	local[5]= fqv[81];
	local[6]= fqv[323];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto compCON1061;
compCON1066:
	local[4]= NIL;
compCON1061:
	goto compIF1060;
compIF1059:
	local[4]= NIL;
compIF1060:
compIF1058:
compIF1056:
compIF1054:
compIF1052:
compIF1050:
compIF1045:
compIF1043:
compIF1038:
compIF1033:
	w = local[4];
	goto compWHL1029;
compWHX1030:
	local[3]= NIL;
compBLK1031:
	w = NIL;
	local[0]= w;
compBLK1028:
	ctx->vsp=local; return(local[0]);}

/*:lambda*/
static pointer compM1067compiler_lambda(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= fqv[324];
	w = argv[2];
	local[5]= memq(local[5],w);
	local[6]= fqv[325];
	w = argv[2];
	local[6]= memq(local[6],w);
	local[7]= fqv[326];
	w = argv[2];
	local[7]= memq(local[7],w);
	local[8]= fqv[327];
	w = argv[2];
	local[8]= memq(local[8],w);
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= NIL;
	local[16]= fqv[328];
	w = argv[2];
	local[16]= memq(local[16],w);
	local[17]= argv[0]->c.obj.iv[9];
	local[18]= NIL;
	local[19]= NIL;
	local[20]= local[5];
	if (local[20]!=NIL) goto compCON1069;
compCON1070:
	local[20]= local[6];
	if (local[20]!=NIL) goto compCON1069;
compCON1071:
	local[20]= local[7];
	if (local[20]!=NIL) goto compCON1069;
compCON1072:
	local[20]= local[8];
	if (local[20]!=NIL) goto compCON1069;
compCON1073:
	local[20]= NIL;
compCON1069:
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[20]= w;
	local[21]= argv[2];
	ctx->vsp=local+22;
	w=(pointer)REVERSE(ctx,1,local+21); /*reverse*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)NTHCDR(ctx,2,local+20); /*nthcdr*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)REVERSE(ctx,1,local+20); /*reverse*/
	local[10] = w;
	local[20]= local[6];
	if (local[20]!=NIL) goto compCON1074;
compCON1075:
	local[20]= local[7];
	if (local[20]!=NIL) goto compCON1074;
compCON1076:
	local[20]= local[8];
	if (local[20]!=NIL) goto compCON1074;
compCON1077:
	local[20]= NIL;
compCON1074:
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[20]= w;
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)REVERSE(ctx,1,local+21); /*reverse*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)NTHCDR(ctx,2,local+20); /*nthcdr*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)REVERSE(ctx,1,local+20); /*reverse*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	if (local[6]==NIL) goto compCON1079;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	goto compCON1078;
compCON1079:
	local[20]= NIL;
compCON1078:
	local[6] = local[20];
	local[20]= local[10];
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[2] = w;
	local[20]= local[5];
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[3] = w;
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,compCLO1080,env,argv,local);
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,2,local+20); /*mapcar*/
	local[11] = w;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	local[20]= local[7];
	ctx->vsp=local+21;
	w=(pointer)LENGTH(ctx,1,local+20); /*length*/
	local[4] = w;
	if (local[16]==NIL) goto compIF1081;
	local[20]= local[7];
	local[21]= makeint((eusinteger_t)0L);
	local[22]= local[4];
	ctx->vsp=local+23;
	w=(pointer)SUB1(ctx,1,local+22); /*1-*/
	local[4] = w;
	local[22]= local[4];
	ctx->vsp=local+23;
	w=(pointer)SUBSEQ(ctx,3,local+20); /*subseq*/
	local[7] = w;
	local[20]= local[7];
	goto compIF1082;
compIF1081:
	local[20]= NIL;
compIF1082:
	if (local[5]==NIL) goto compIF1083;
compWHL1085:
	local[20]= local[1];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)LSEQP(ctx,2,local+20); /*<=*/
	if (w==NIL) goto compWHX1086;
	local[20]= argv[0];
	local[21]= fqv[256];
	local[22]= fqv[329];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= w;
	w = local[0];
	ctx->vsp=local+21;
	local[0] = cons(ctx,local[20],w);
	local[20]= local[1];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[1] = w;
	goto compWHL1085;
compWHX1086:
	local[20]= NIL;
compBLK1087:
	goto compIF1084;
compIF1083:
	if (local[6]==NIL) goto compIF1088;
	local[20]= argv[0];
	local[21]= fqv[256];
	local[22]= fqv[330];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	local[0] = w;
	local[20]= local[0];
	goto compIF1089;
compIF1088:
	local[20]= NIL;
compIF1089:
compIF1084:
	ctx->vsp=local+20;
	local[20]= makeclosure(codevec,quotevec,compCLO1090,env,argv,local);
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,2,local+20); /*mapcar*/
	local[5] = w;
	local[20]= argv[0];
	local[21]= fqv[78];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	if (local[7]==NIL) goto compIF1091;
	local[20]= NIL;
	local[21]= NIL;
	local[22]= NIL;
	local[23]= NIL;
	local[24]= local[7];
compWHL1093:
	if (local[24]==NIL) goto compWHX1094;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[25]= (w)->c.cons.car;
	w=local[24];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24] = (w)->c.cons.cdr;
	w = local[25];
	local[23] = w;
	local[25]= local[23];
	ctx->vsp=local+26;
	w=(pointer)LISTP(ctx,1,local+25); /*listp*/
	if (w==NIL) goto compCON1097;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20] = (w)->c.cons.car;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23] = (w)->c.cons.car;
	local[25]= local[23];
	ctx->vsp=local+26;
	w=(pointer)LISTP(ctx,1,local+25); /*listp*/
	if (w==NIL) goto compCON1099;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21] = (w)->c.cons.car;
	w=local[23];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.car;
	local[25]= local[21];
	ctx->vsp=local+26;
	w=(*ftab[4])(ctx,1,local+25,&ftab[4],fqv[31]); /*keywordp*/
	if (w!=NIL) goto compIF1100;
	local[25]= argv[0];
	local[26]= fqv[6];
	local[27]= fqv[331];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[25]= w;
	goto compIF1101;
compIF1100:
	local[25]= NIL;
compIF1101:
	if (local[22]==NIL) goto compAND1104;
	w = local[22];
	if (!issymbol(w)) goto compAND1104;
	goto compIF1102;
compAND1104:
	local[25]= argv[0];
	local[26]= fqv[6];
	local[27]= fqv[332];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[25]= w;
	goto compIF1103;
compIF1102:
	local[25]= NIL;
compIF1103:
	goto compCON1098;
compCON1099:
	local[22] = local[23];
	local[25]= local[22];
	ctx->vsp=local+26;
	w=(*ftab[12])(ctx,1,local+25,&ftab[12],fqv[333]); /*symbol-name*/
	local[25]= w;
	local[26]= loadglobal(fqv[334]);
	ctx->vsp=local+27;
	w=(pointer)INTERN(ctx,2,local+25); /*intern*/
	local[21] = w;
	local[25]= local[21];
	goto compCON1098;
compCON1105:
	local[25]= NIL;
compCON1098:
	goto compCON1096;
compCON1097:
	local[20] = NIL;
	local[22] = local[23];
	local[25]= local[22];
	ctx->vsp=local+26;
	w=(*ftab[12])(ctx,1,local+25,&ftab[12],fqv[333]); /*symbol-name*/
	local[25]= w;
	local[26]= loadglobal(fqv[334]);
	ctx->vsp=local+27;
	w=(pointer)INTERN(ctx,2,local+25); /*intern*/
	local[21] = w;
	local[25]= local[21];
	goto compCON1096;
compCON1106:
	local[25]= NIL;
compCON1096:
	local[25]= local[21];
	w = local[12];
	ctx->vsp=local+26;
	local[12] = cons(ctx,local[25],w);
	local[25]= local[22];
	w = local[9];
	ctx->vsp=local+26;
	local[9] = cons(ctx,local[25],w);
	local[25]= local[20];
	w = local[13];
	ctx->vsp=local+26;
	local[13] = cons(ctx,local[25],w);
	goto compWHL1093;
compWHX1094:
	local[25]= NIL;
compBLK1095:
	w = NIL;
	local[23]= local[12];
	ctx->vsp=local+24;
	w=(pointer)NREVERSE(ctx,1,local+23); /*nreverse*/
	local[23]= local[9];
	ctx->vsp=local+24;
	w=(pointer)NREVERSE(ctx,1,local+23); /*nreverse*/
	local[23]= local[13];
	ctx->vsp=local+24;
	w=(pointer)NREVERSE(ctx,1,local+23); /*nreverse*/
	local[23]= local[12];
	ctx->vsp=local+24;
	w=(pointer)LENGTH(ctx,1,local+23); /*length*/
	local[23]= w;
	w = makeint((eusinteger_t)128L);
	if ((eusinteger_t)local[23] < (eusinteger_t)w) goto compIF1107;
	local[23]= argv[0];
	local[24]= fqv[6];
	local[25]= fqv[335];
	local[26]= local[12];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,4,local+23); /*send*/
	local[23]= w;
	goto compIF1108;
compIF1107:
	local[23]= NIL;
compIF1108:
	w = local[23];
	local[20]= w;
	goto compIF1092;
compIF1091:
	local[20]= NIL;
compIF1092:
compWHL1109:
	if (argv[3]==NIL) goto compWHX1110;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto compWHX1110;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	if (fqv[278]!=local[20]) goto compWHX1110;
	local[20]= argv[0];
	local[21]= fqv[279];
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[3] = (w)->c.cons.cdr;
	w = local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.cdr;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	goto compWHL1109;
compWHX1110:
	local[20]= NIL;
compBLK1111:
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[336];
	local[22]= local[2];
	local[23]= local[3];
	if (local[6]==NIL) goto compIF1112;
	local[24]= makeint((eusinteger_t)1L);
	goto compIF1113;
compIF1112:
	if (local[7]==NIL) goto compIF1114;
	local[24]= local[4];
	goto compIF1115;
compIF1114:
	local[24]= makeint((eusinteger_t)0L);
compIF1115:
compIF1113:
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,4,local+20); /*send*/
	local[1] = makeint((eusinteger_t)0L);
	local[20]= NIL;
	local[21]= local[10];
compWHL1116:
	if (local[21]==NIL) goto compWHX1117;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21] = (w)->c.cons.cdr;
	w = local[22];
	local[20] = w;
	local[22]= argv[0];
	local[23]= fqv[280];
	local[24]= local[20];
	local[25]= fqv[73];
	local[26]= local[1];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,5,local+22); /*send*/
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[1] = w;
	goto compWHL1116;
compWHX1117:
	local[22]= NIL;
compBLK1118:
	w = NIL;
compWHL1119:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto compWHX1120;
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[337];
	local[22]= local[1];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,4,local+20); /*send*/
	local[20]= argv[0];
	local[21]= fqv[23];
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[22];
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[259];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[22];
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= argv[0];
	local[21]= fqv[280];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[22];
	local[22]= w;
	local[23]= fqv[71];
	local[24]= loadglobal(fqv[24]);
	local[25]= fqv[281];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SUB1(ctx,1,local+24); /*1-*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,5,local+20); /*send*/
	local[20]= local[1];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[1] = w;
	goto compWHL1119;
compWHX1120:
	local[20]= NIL;
compBLK1121:
	if (local[0]==NIL) goto compIF1122;
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[259];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[22];
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= w;
	goto compIF1123;
compIF1122:
	local[20]= NIL;
compIF1123:
	if (local[6]==NIL) goto compCON1125;
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[338];
	local[22]= local[2];
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)PLUS(ctx,2,local+22); /*+*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= argv[0];
	local[21]= fqv[280];
	local[22]= local[6];
	local[23]= fqv[71];
	local[24]= loadglobal(fqv[24]);
	local[25]= fqv[281];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,2,local+24); /*send*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SUB1(ctx,1,local+24); /*1-*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,5,local+20); /*send*/
	local[20]= w;
	goto compCON1124;
compCON1125:
	local[20]= local[3];
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)GREATERP(ctx,2,local+20); /*>*/
	if (w==NIL) goto compCON1126;
	if (local[7]!=NIL) goto compCON1126;
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[339];
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= w;
	goto compCON1124;
compCON1126:
	local[20]= NIL;
compCON1124:
	if (local[7]==NIL) goto compIF1127;
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[281];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[14] = w;
	local[20]= loadglobal(fqv[24]);
	local[21]= fqv[340];
	local[22]= local[12];
	local[23]= loadglobal(fqv[181]);
	ctx->vsp=local+24;
	w=(pointer)COERCE(ctx,2,local+22); /*coerce*/
	local[22]= w;
	local[23]= local[2];
	local[24]= local[3];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	local[24]= local[4];
	local[25]= local[16];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,6,local+20); /*send*/
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[4];
compWHL1129:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto compWHX1130;
	local[22]= argv[0];
	local[23]= fqv[256];
	local[24]= fqv[341];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[0] = w;
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[342];
	local[24]= local[20];
	local[25]= local[0];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,4,local+22); /*send*/
	local[22]= argv[0];
	local[23]= fqv[23];
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13] = (w)->c.cons.cdr;
	w = local[24];
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[22];
	local[18] = w;
	local[22]= argv[0];
	local[23]= fqv[283];
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	if (w==NIL) goto compCON1133;
	local[22]= argv[0];
	local[23]= fqv[256];
	local[24]= fqv[343];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[19] = w;
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[258];
	local[24]= local[19];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[259];
	local[24]= local[0];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[273];
	local[24]= makeint((eusinteger_t)1L);
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[53];
	local[24]= local[20];
	local[25]= local[14];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)0L);
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,4,local+22); /*send*/
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[259];
	local[24]= local[19];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= argv[0];
	local[23]= fqv[280];
	local[24]= local[18];
	local[25]= fqv[71];
	local[26]= local[14];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)PLUS(ctx,2,local+26); /*+*/
	local[26]= w;
	local[27]= T;
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,6,local+22); /*send*/
	local[22]= w;
	goto compCON1132;
compCON1133:
	local[22]= argv[0];
	local[23]= fqv[280];
	local[24]= local[18];
	local[25]= fqv[71];
	local[26]= local[14];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)PLUS(ctx,2,local+26); /*+*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,5,local+22); /*send*/
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[105];
	local[24]= local[14];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)0L);
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,4,local+22); /*send*/
	local[22]= loadglobal(fqv[24]);
	local[23]= fqv[259];
	local[24]= local[0];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	goto compCON1132;
compCON1134:
	local[22]= NIL;
compCON1132:
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto compWHL1129;
compWHX1130:
	local[22]= NIL;
compBLK1131:
	w = NIL;
	local[20]= w;
	goto compIF1128;
compIF1127:
	local[20]= NIL;
compIF1128:
	local[20]= NIL;
	local[21]= local[8];
compWHL1135:
	if (local[21]==NIL) goto compWHX1136;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	w=local[21];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21] = (w)->c.cons.cdr;
	w = local[22];
	local[20] = w;
	w = local[20];
	if (!iscons(w)) goto compIF1138;
	local[22]= argv[0];
	local[23]= fqv[23];
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	goto compIF1139;
compIF1138:
	local[22]= argv[0];
	local[23]= fqv[23];
	local[24]= NIL;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
compIF1139:
	local[22]= argv[0];
	local[23]= fqv[280];
	local[24]= local[20];
	ctx->vsp=local+25;
	w=(pointer)LISTP(ctx,1,local+24); /*listp*/
	if (w==NIL) goto compIF1140;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	goto compIF1141;
compIF1140:
	local[24]= local[20];
compIF1141:
	local[25]= fqv[71];
	local[26]= loadglobal(fqv[24]);
	local[27]= fqv[281];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)SUB1(ctx,1,local+26); /*1-*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,5,local+22); /*send*/
	goto compWHL1135;
compWHX1136:
	local[22]= NIL;
compBLK1137:
	w = NIL;
	local[20]= argv[0];
	local[21]= fqv[235];
	local[22]= argv[3];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	argv[0]->c.obj.iv[9] = local[17];
	local[20]= argv[0];
	local[21]= fqv[282];
	local[22]= T;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[0]= w;
compBLK1068:
	ctx->vsp=local; return(local[0]);}

/*:lambda-block*/
static pointer compM1142compiler_lambda_block(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	ctx->vsp=local+0;
	w=(pointer)RUNTIME(ctx,0,local+0); /*unix:runtime*/
	local[0]= w;
	local[1]= NIL;
	if (loadglobal(fqv[344])==NIL) goto compIF1144;
	local[2]= T;
	local[3]= fqv[345];
	local[4]= makeint((eusinteger_t)27L);
	local[5]= argv[2];
	local[6]= makeint((eusinteger_t)27L);
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,5,local+2); /*format*/
	local[2]= w;
	goto compIF1145;
compIF1144:
	local[2]= NIL;
compIF1145:
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,0,local+2); /*finish-output*/
	local[2]= argv[0];
	local[3]= fqv[288];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[1] = w;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[17];
	local[4]= argv[5];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[346];
	local[4]= argv[3];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[259];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[347];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[289];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (loadglobal(fqv[344])==NIL) goto compIF1146;
	local[2]= T;
	local[3]= fqv[348];
	local[4]= makeflt(1.6669999999999990381028e-02);
	ctx->vsp=local+5;
	w=(pointer)RUNTIME(ctx,0,local+5); /*unix:runtime*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto compIF1147;
compIF1146:
	local[2]= NIL;
compIF1147:
	w = argv[5];
	local[0]= w;
compBLK1143:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO1080(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto compIF1148;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto compIF1149;
compIF1148:
	local[0]= NIL;
compIF1149:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compCLO1090(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto compIF1150;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto compIF1151;
compIF1150:
	local[0]= argv[0];
compIF1151:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:def-user-entry*/
static pointer compM1152compiler_def_user_entry(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[349]!=local[0]) goto compIF1154;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= fqv[256];
	local[3]= fqv[350];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,1,local+4,&ftab[13],fqv[22]); /*lisp::gencname-tail*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	local[4]= fqv[351];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[2]= local[0];
	w = loadglobal(fqv[352]);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	storeglobal(fqv[352],local[2]);
	w = local[2];
	local[0]= w;
	goto compIF1155;
compIF1154:
	local[0]= NIL;
compIF1155:
	w = local[0];
	local[0]= w;
compBLK1153:
	ctx->vsp=local; return(local[0]);}

/*:defun*/
static pointer compM1156compiler_defun(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[3];
	local[1]= fqv[351];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
	local[1]= NIL;
	if (local[0]!=NIL) goto compIF1158;
	local[2]= argv[0];
	local[3]= fqv[256];
	local[4]= fqv[353];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
	local[2]= local[0];
	goto compIF1159;
compIF1158:
	local[2]= NIL;
compIF1159:
	local[2]= loadglobal(fqv[317]);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto compIF1160;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= fqv[351];
	ctx->vsp=local+5;
	w=(pointer)PUTPROP(ctx,3,local+2); /*putprop*/
	local[2]= argv[3];
	w = loadglobal(fqv[352]);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	storeglobal(fqv[352],local[2]);
	goto compIF1161;
compIF1160:
	local[2]= NIL;
compIF1161:
	w=argv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isstring(w)) goto compIF1162;
	w=argv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto compIF1162;
	w=argv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[5] = (w)->c.cons.cdr;
	w = local[2];
	local[2]= w;
	goto compIF1163;
compIF1162:
	local[2]= NIL;
	local[3]= fqv[354];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
compIF1163:
	local[1] = local[2];
	local[2]= argv[0];
	local[3]= fqv[355];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= argv[5];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[356];
	local[4]= argv[2];
	local[5]= local[0];
	local[6]= argv[3];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,4,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
compBLK1157:
	ctx->vsp=local; return(local[0]);}

/*:defmethod*/
static pointer compM1164compiler_defmethod(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)compF383object_variable_names(ctx,1,local+7); /*object-variable-names*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= NIL;
	local[10]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	local[11]= argv[0];
	local[12]= fqv[78];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= NIL;
	local[12]= local[7];
compWHL1166:
	if (local[12]==NIL) goto compWHX1167;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12] = (w)->c.cons.cdr;
	w = local[13];
	local[11] = w;
	local[13]= argv[0];
	local[14]= fqv[69];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[9] = w;
	local[13]= fqv[357];
	*(ovafptr(local[9],fqv[88])) = local[13];
	local[13]= local[8];
	*(ovafptr(local[9],fqv[92])) = local[13];
	local[13]= argv[0]->c.obj.iv[1];
	*(ovafptr(local[9],fqv[93])) = local[13];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)SYMVALUE(ctx,1,local+13); /*symbol-value*/
	local[13]= w;
	local[14]= local[11];
	ctx->vsp=local+15;
	w=(pointer)compF384object_variable_type(ctx,2,local+13); /*object-variable-type*/
	local[13]= w;
	local[14]= w;
	*(ovafptr(local[9],fqv[313])) = local[14];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[8] = w;
	goto compWHL1166;
compWHX1167:
	local[13]= NIL;
compBLK1168:
	w = NIL;
compWHL1169:
	if (argv[2]==NIL) goto compWHX1170;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[11];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[11]= fqv[358];
	local[12]= fqv[359];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[2] = cons(ctx,local[11],w);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	local[11]= argv[0];
	local[12]= fqv[256];
	local[13]= fqv[360];
	local[14]= local[6];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(*ftab[13])(ctx,2,local+14,&ftab[13],fqv[22]); /*lisp::gencname-tail*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[4] = w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!isstring(w)) goto compIF1172;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto compIF1172;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[11];
	local[11]= w;
	goto compIF1173;
compIF1172:
	local[11]= NIL;
	local[12]= fqv[361];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
compIF1173:
	local[10] = local[11];
	local[11]= argv[0];
	local[12]= fqv[355];
	local[13]= local[1];
	local[14]= local[2];
	local[15]= local[3];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,6,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[356];
	local[13]= fqv[362];
	local[14]= local[6];
	local[15]= local[1];
	local[16]= local[4];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,5,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	goto compWHL1169;
compWHX1170:
	local[11]= NIL;
compBLK1171:
	local[6] = NIL;
	local[11]= argv[0];
	local[12]= fqv[282];
	local[13]= NIL;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[0]= w;
compBLK1165:
	ctx->vsp=local; return(local[0]);}

/*:add-initcode*/
static pointer compM1174compiler_add_initcode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[7];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[7] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
compBLK1175:
	ctx->vsp=local; return(local[0]);}

/*:add-closure*/
static pointer compM1176compiler_add_closure(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[6];
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[6] = cons(ctx,local[0],w);
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
compBLK1177:
	ctx->vsp=local; return(local[0]);}

/*:closure-level*/
static pointer compM1178compiler_closure_level(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
compBLK1179:
	ctx->vsp=local; return(local[0]);}

/*:compile-a-closure*/
static pointer compM1180compiler_compile_a_closure(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	if (loadglobal(fqv[52])==NIL) goto compIF1182;
	local[0]= T;
	local[1]= fqv[363];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto compIF1183;
compIF1182:
	local[0]= NIL;
compIF1183:
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	argv[0]->c.obj.iv[6] = NIL;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[364];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[17];
	local[4]= argv[2];
	local[5]= fqv[365];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[346];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[347];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[366];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[0]= w;
compBLK1181:
	ctx->vsp=local; return(local[0]);}

/*:compile-closures*/
static pointer compM1184compiler_compile_closures(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+2;
	w=(pointer)REVERSE(ctx,1,local+1); /*reverse*/
	local[1]= w;
compWHL1186:
	if (local[1]==NIL) goto compWHX1187;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[367];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	goto compWHL1186;
compWHX1187:
	local[2]= NIL;
compBLK1188:
	w = NIL;
	argv[0]->c.obj.iv[6] = NIL;
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
compBLK1185:
	ctx->vsp=local; return(local[0]);}

/*:toplevel-eval*/
static pointer compM1189compiler_toplevel_eval(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[6] = NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= local[0];
	local[2]= local[1];
	w = fqv[368];
	if (memq(local[2],w)==NIL) goto compIF1191;
	local[2]= argv[0];
	local[3]= fqv[369];
	local[4]= local[0];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(*ftab[14])(ctx,1,local+7,&ftab[14],fqv[370]); /*cdddr*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[366];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto compIF1192;
compIF1191:
	local[2]= local[1];
	w = fqv[371];
	if (memq(local[2],w)==NIL) goto compIF1193;
	local[2]= argv[0];
	local[3]= fqv[372];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[366];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto compIF1194;
compIF1193:
	local[2]= local[1];
	w = fqv[373];
	if (memq(local[2],w)==NIL) goto compIF1195;
	local[2]= NIL;
	goto compIF1196;
compIF1195:
	if (T==NIL) goto compIF1197;
	local[2]= argv[0];
	local[3]= fqv[356];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compIF1198;
compIF1197:
	local[2]= NIL;
compIF1198:
compIF1196:
compIF1194:
compIF1192:
	w = local[2];
	local[0]= w;
compBLK1190:
	ctx->vsp=local; return(local[0]);}

/*:toplevel*/
static pointer compM1199compiler_toplevel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto compENT1202;}
	local[0]= NIL;
compENT1202:
compENT1201:
	if (n>5) maerror();
	if (local[0]!=NIL) goto compIF1203;
	local[1]= loadglobal(fqv[24]);
	local[2]= fqv[58];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto compIF1204;
compIF1203:
	local[1]= NIL;
compIF1204:
	w = argv[2];
	if (!!iscons(w)) goto compIF1205;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto compBLK1200;
	goto compIF1206;
compIF1205:
	local[1]= NIL;
compIF1206:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,1,local+1,&ftab[15],fqv[374]); /*macro-function*/
	if (w==NIL) goto compIF1207;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[45]); /*macroexpand*/
	argv[2] = w;
	local[1]= argv[2];
	goto compIF1208;
compIF1207:
	local[1]= NIL;
compIF1208:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	if (fqv[375]!=local[1]) goto compCON1210;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= NIL;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
compWHL1211:
	if (local[3]==NIL) goto compWHX1212;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= fqv[376];
	w = local[1];
	if (memq(local[4],w)==NIL) goto compIF1214;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)EVAL(ctx,1,local+4); /*eval*/
	local[4]= w;
	goto compIF1215;
compIF1214:
	local[4]= NIL;
compIF1215:
	local[4]= fqv[377];
	w = local[1];
	if (memq(local[4],w)==NIL) goto compIF1216;
	local[4]= argv[0];
	local[5]= fqv[378];
	local[6]= local[2];
	local[7]= NIL;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	goto compIF1217;
compIF1216:
	local[4]= NIL;
compIF1217:
	goto compWHL1211;
compWHX1212:
	local[4]= NIL;
compBLK1213:
	w = NIL;
	local[1]= w;
	goto compCON1209;
compCON1210:
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	if (fqv[379]!=local[1]) goto compCON1218;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[1];
compWHL1219:
	if (argv[2]==NIL) goto compWHX1220;
	local[1]= argv[0];
	local[2]= fqv[378];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[3];
	local[3]= w;
	local[4]= argv[3];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	goto compWHL1219;
compWHX1220:
	local[1]= NIL;
compBLK1221:
	goto compCON1209;
compCON1218:
	if (argv[3]==NIL) goto compIF1223;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)EVAL(ctx,1,local+1); /*eval*/
	local[1]= w;
	goto compIF1224;
compIF1223:
	local[1]= NIL;
compIF1224:
	if (local[0]==NIL) goto compIF1225;
	local[1]= argv[0];
	local[2]= fqv[380];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto compIF1226;
compIF1225:
	local[1]= argv[0];
	local[2]= fqv[381];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
compIF1226:
	goto compCON1209;
compCON1222:
	local[1]= NIL;
compCON1209:
	w = local[1];
	local[0]= w;
compBLK1200:
	ctx->vsp=local; return(local[0]);}

/*:toplevel-execution*/
static pointer compM1227compiler_toplevel_execution(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= local[0];
	local[2]= local[1];
	if (fqv[349]!=local[2]) goto compIF1229;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[369];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[7])(ctx,1,local+6,&ftab[7],fqv[54]); /*fourth*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= w;
	goto compIF1230;
compIF1229:
	local[2]= local[1];
	if (fqv[382]!=local[2]) goto compIF1231;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[383];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[7])(ctx,1,local+6,&ftab[7],fqv[54]); /*fourth*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= w;
	goto compIF1232;
compIF1231:
	local[2]= local[1];
	if (fqv[362]!=local[2]) goto compIF1233;
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[372];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[7])(ctx,1,local+6,&ftab[7],fqv[54]); /*fourth*/
	local[6]= w;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(*ftab[8])(ctx,1,local+7,&ftab[8],fqv[55]); /*fifth*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	local[2]= w;
	goto compIF1234;
compIF1233:
	if (T==NIL) goto compIF1235;
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= loadglobal(fqv[24]);
	local[3]= fqv[25];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto compIF1236;
compIF1235:
	local[2]= NIL;
compIF1236:
compIF1234:
compIF1232:
compIF1230:
	w = local[2];
	local[0]= w;
compBLK1228:
	ctx->vsp=local; return(local[0]);}

/*:compile-file*/
static pointer compM1237compiler_compile_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[384], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto compKEY1239;
	local[0] = fqv[385];
compKEY1239:
	if (n & (1<<1)) goto compKEY1240;
	local[1] = loadglobal(fqv[317]);
compKEY1240:
	if (n & (1<<2)) goto compKEY1241;
	local[2] = makeint((eusinteger_t)2L);
compKEY1241:
	if (n & (1<<3)) goto compKEY1242;
	local[3] = loadglobal(fqv[184]);
compKEY1242:
	if (n & (1<<4)) goto compKEY1243;
	local[4] = loadglobal(fqv[386]);
compKEY1243:
	if (n & (1<<5)) goto compKEY1244;
	local[5] = loadglobal(fqv[387]);
compKEY1244:
	if (n & (1<<6)) goto compKEY1245;
	local[6] = loadglobal(fqv[344]);
compKEY1245:
	if (n & (1<<7)) goto compKEY1246;
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,1,local+9,&ftab[16],fqv[388]); /*pathname-name*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,1,local+9,&ftab[13],fqv[22]); /*lisp::gencname-tail*/
	local[7] = w;
compKEY1246:
	if (n & (1<<8)) goto compKEY1247;
	local[8] = NIL;
compKEY1247:
	local[9]= local[7];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)8L);
	ctx->vsp=local+12;
	w=(pointer)SUBSEQ(ctx,3,local+9); /*subseq*/
	argv[0]->c.obj.iv[10] = w;
	w = local[2];
	if (!isint(w)) goto compIF1248;
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto compIF1248;
	local[9]= NIL;
	local[10]= fqv[389];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,3,local+9); /*format*/
	local[9]= w;
	storeglobal(fqv[390],w);
	goto compIF1249;
compIF1248:
	local[9]= fqv[391];
	storeglobal(fqv[390],local[9]);
compIF1249:
	storeglobal(fqv[317],local[1]);
	storeglobal(fqv[184],local[3]);
	local[9]= local[6];
	storeglobal(fqv[344],local[9]);
	local[9]= argv[2];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,1,local+9,&ftab[17],fqv[392]); /*pathname*/
	local[9]= w;
	local[10]= fqv[393];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (w!=NIL) goto compIF1250;
	local[9]= fqv[394];
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,1,local+9,&ftab[19],fqv[396]); /*namestring*/
	argv[2] = w;
	local[9]= argv[2];
	goto compIF1251;
compIF1250:
	local[9]= NIL;
compIF1251:
	if (local[8]==NIL) goto compIF1252;
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,1,local+9,&ftab[17],fqv[392]); /*pathname*/
	local[8] = w;
	local[9]= local[8];
	local[10]= argv[2];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[8] = w;
	local[9]= fqv[397];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,2,local+9,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[8] = w;
	local[9]= local[8];
	goto compIF1253;
compIF1252:
	local[9]= NIL;
compIF1253:
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= NIL;
	local[14]= fqv[398];
	local[15]= argv[2];
	ctx->vsp=local+16;
	w=(*ftab[18])(ctx,2,local+14,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[14]= w;
	local[15]= fqv[399];
	local[16]= argv[2];
	ctx->vsp=local+17;
	w=(*ftab[18])(ctx,2,local+15,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[15]= w;
	local[16]= fqv[400];
	local[17]= argv[2];
	ctx->vsp=local+18;
	w=(*ftab[18])(ctx,2,local+16,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[16]= w;
	if (local[8]==NIL) goto compIF1254;
	local[17]= local[8];
	goto compIF1255;
compIF1254:
	local[17]= fqv[401];
	local[18]= argv[2];
	ctx->vsp=local+19;
	w=(*ftab[18])(ctx,2,local+17,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[17]= w;
compIF1255:
	if (local[8]==NIL) goto compIF1256;
	local[18]= fqv[402];
	local[19]= local[8];
	ctx->vsp=local+20;
	w=(*ftab[18])(ctx,2,local+18,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[18]= w;
	goto compIF1257;
compIF1256:
	local[18]= fqv[403];
	local[19]= argv[2];
	ctx->vsp=local+20;
	w=(*ftab[18])(ctx,2,local+18,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[18]= w;
compIF1257:
	if (local[8]==NIL) goto compIF1258;
	local[19]= fqv[404];
	local[20]= local[8];
	ctx->vsp=local+21;
	w=(*ftab[18])(ctx,2,local+19,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[19]= w;
	goto compIF1259;
compIF1258:
	local[19]= fqv[405];
	local[20]= argv[2];
	ctx->vsp=local+21;
	w=(*ftab[18])(ctx,2,local+19,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[19]= w;
compIF1259:
	local[20]= loadglobal(fqv[406]);
	local[21]= argv[2];
	ctx->vsp=local+22;
	w=(*ftab[17])(ctx,1,local+21,&ftab[17],fqv[392]); /*pathname*/
	local[21]= w;
	local[22]= fqv[407];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)2L);
	ctx->vsp=local+23;
	w=(pointer)ACCESS(ctx,2,local+21); /*unix:access*/
	local[21]= w;
	if (T==local[21]) goto compIF1260;
	local[21]= fqv[408];
	local[22]= argv[2];
	local[23]= local[8];
	local[24]= fqv[407];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(*ftab[1])(ctx,3,local+21,&ftab[1],fqv[14]); /*warn*/
	local[21]= fqv[409];
	local[22]= local[8];
	ctx->vsp=local+23;
	w=(*ftab[18])(ctx,2,local+21,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[14] = w;
	local[21]= fqv[410];
	local[22]= local[8];
	ctx->vsp=local+23;
	w=(*ftab[18])(ctx,2,local+21,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[15] = w;
	local[21]= fqv[411];
	local[22]= local[8];
	ctx->vsp=local+23;
	w=(*ftab[18])(ctx,2,local+21,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[16] = w;
	local[21]= local[16];
	goto compIF1261;
compIF1260:
	local[21]= NIL;
compIF1261:
	local[21]= argv[2];
	ctx->vsp=local+22;
	w=(*ftab[20])(ctx,1,local+21,&ftab[20],fqv[412]); /*probe-file*/
	if (w!=NIL) goto compIF1262;
	local[21]= fqv[413];
	local[22]= argv[2];
	ctx->vsp=local+23;
	w=(*ftab[18])(ctx,2,local+21,&ftab[18],fqv[395]); /*merge-pathnames*/
	argv[2] = w;
	local[21]= argv[2];
	ctx->vsp=local+22;
	w=(*ftab[20])(ctx,1,local+21,&ftab[20],fqv[412]); /*probe-file*/
	if (w!=NIL) goto compIF1264;
	local[21]= fqv[414];
	local[22]= argv[2];
	ctx->vsp=local+23;
	w=(pointer)SIGERROR(ctx,2,local+21); /*error*/
	local[21]= w;
	goto compIF1265;
compIF1264:
	local[21]= NIL;
compIF1265:
	goto compIF1263;
compIF1262:
	local[21]= NIL;
compIF1263:
	local[21]= fqv[415];
	local[22]= argv[2];
	ctx->vsp=local+23;
	w=(*ftab[19])(ctx,1,local+22,&ftab[19],fqv[396]); /*namestring*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(*ftab[1])(ctx,2,local+21,&ftab[1],fqv[14]); /*warn*/
	local[21]= argv[2];
	ctx->vsp=local+22;
	w=(*ftab[21])(ctx,1,local+21,&ftab[21],fqv[416]); /*open*/
	local[12] = w;
	local[21]= NIL;
	storeglobal(fqv[352],local[21]);
	if (loadglobal(fqv[417])==NIL) goto compIF1266;
compWHL1268:
	if (T==NIL) goto compWHX1269;
	local[21]= local[12];
	local[22]= NIL;
	local[23]= fqv[418];
	ctx->vsp=local+24;
	w=(pointer)READ(ctx,3,local+21); /*read*/
	local[11] = w;
	local[21]= local[11];
	if (fqv[418]!=local[21]) goto compIF1271;
	w = NIL;
	ctx->vsp=local+21;
	local[21]=w;
	goto compBLK1270;
	goto compIF1272;
compIF1271:
	local[21]= NIL;
compIF1272:
	local[21]= argv[0];
	local[22]= fqv[378];
	local[23]= local[11];
	local[24]= T;
	local[25]= T;
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,5,local+21); /*send*/
	goto compWHL1268;
compWHX1269:
	local[21]= NIL;
compBLK1270:
	local[21]= local[12];
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)LSEEK(ctx,2,local+21); /*unix:lseek*/
	local[21]= w;
	goto compIF1267;
compIF1266:
	local[21]= NIL;
compIF1267:
	local[21]= loadglobal(fqv[352]);
	ctx->vsp=local+22;
	w=(pointer)NREVERSE(ctx,1,local+21); /*nreverse*/
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[419];
	local[23]= argv[2];
	local[24]= local[14];
	local[25]= local[15];
	local[26]= local[7];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,6,local+21); /*send*/
	local[21]= argv[0]->c.obj.iv[0];
	local[22]= fqv[420];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	argv[0]->c.obj.iv[3] = NIL;
	argv[0]->c.obj.iv[2] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[4] = NIL;
	argv[0]->c.obj.iv[7] = NIL;
compWHL1273:
	if (T==NIL) goto compWHX1274;
	local[21]= local[12];
	local[22]= NIL;
	local[23]= fqv[418];
	ctx->vsp=local+24;
	w=(pointer)READ(ctx,3,local+21); /*read*/
	local[11] = w;
	local[21]= local[11];
	if (fqv[418]!=local[21]) goto compIF1276;
	w = NIL;
	ctx->vsp=local+21;
	local[21]=w;
	goto compBLK1275;
	goto compIF1277;
compIF1276:
	local[21]= NIL;
compIF1277:
	local[21]= argv[0];
	local[22]= fqv[378];
	local[23]= local[11];
	local[24]= T;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,4,local+21); /*send*/
	goto compWHL1273;
compWHX1274:
	local[21]= NIL;
compBLK1275:
	local[21]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+22;
	w=(pointer)REVERSE(ctx,1,local+21); /*reverse*/
	argv[0]->c.obj.iv[7] = w;
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[421];
	local[23]= local[7];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,3,local+21); /*send*/
	local[21]= NIL;
	local[22]= argv[0]->c.obj.iv[7];
compWHL1278:
	if (local[22]==NIL) goto compWHX1279;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	local[23]= argv[0];
	local[24]= fqv[422];
	local[25]= local[21];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	goto compWHL1278;
compWHX1279:
	local[23]= NIL;
compBLK1280:
	w = NIL;
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[26];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[347];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= argv[0];
	local[22]= fqv[366];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[423];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[424];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= *(ovafptr(local[20],fqv[425]));
	local[22]= *(ovafptr(local[20],fqv[426]));
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(*ftab[2])(ctx,1,local+23,&ftab[2],fqv[18]); /*make-array*/
	local[23]= w;
	*(ovafptr(local[20],fqv[425])) = local[23];
	local[23]= makeint((eusinteger_t)1L);
	local[24]= local[23];
	*(ovafptr(local[20],fqv[426])) = local[24];
	local[23]= loadglobal(fqv[24]);
	local[24]= fqv[427];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,2,local+23); /*send*/
	local[23]= local[21];
	*(ovafptr(local[20],fqv[425])) = local[23];
	local[23]= local[22];
	local[24]= local[23];
	*(ovafptr(local[20],fqv[426])) = local[24];
	w = local[23];
	local[21]= loadglobal(fqv[24]);
	local[22]= fqv[428];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= local[12];
	ctx->vsp=local+22;
	w=(pointer)CLOSE(ctx,1,local+21); /*close*/
	local[21]= loadglobal(fqv[177]);
	local[22]= loadglobal(fqv[429]);
	local[23]= fqv[430];
	if (local[8]==NIL) goto compIF1281;
	local[24]= loadglobal(fqv[177]);
	local[25]= fqv[431];
	local[26]= local[8];
	ctx->vsp=local+27;
	w=(*ftab[19])(ctx,1,local+26,&ftab[19],fqv[396]); /*namestring*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)CONCATENATE(ctx,3,local+24); /*concatenate*/
	local[24]= w;
	goto compIF1282;
compIF1281:
	local[24]= NIL;
compIF1282:
	local[25]= fqv[432];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1284;
	local[25]= fqv[434];
	goto compCON1283;
compCON1284:
	local[25]= fqv[435];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1285;
	local[25]= fqv[436];
	goto compCON1283;
compCON1285:
	local[25]= fqv[437];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1286;
	local[25]= fqv[438];
	goto compCON1283;
compCON1286:
	local[25]= fqv[439];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1287;
	local[25]= fqv[440];
	goto compCON1283;
compCON1287:
	local[25]= fqv[441];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1288;
	local[25]= fqv[442];
	goto compCON1283;
compCON1288:
	local[25]= fqv[443];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1289;
	local[25]= fqv[444];
	goto compCON1283;
compCON1289:
	local[25]= fqv[445];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1290;
	local[25]= fqv[446];
	goto compCON1283;
compCON1290:
	local[25]= fqv[447];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1291;
	local[25]= fqv[448];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compIF1292;
	local[25]= fqv[449];
	goto compIF1293;
compIF1292:
	local[25]= fqv[450];
compIF1293:
	goto compCON1283;
compCON1291:
	local[25]= fqv[451];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1294;
	local[25]= fqv[452];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1294;
	local[25]= fqv[448];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1296;
	local[25]= fqv[453];
	goto compCON1295;
compCON1296:
	local[25]= fqv[454];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1297;
	local[25]= fqv[455];
	goto compCON1295;
compCON1297:
	local[25]= fqv[456];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1298;
	local[25]= fqv[457];
	goto compCON1295;
compCON1298:
	local[25]= fqv[458];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1299;
	local[25]= fqv[459];
	goto compCON1295;
compCON1299:
	local[25]= fqv[460];
	goto compCON1295;
compCON1300:
	local[25]= NIL;
compCON1295:
	goto compCON1283;
compCON1294:
	local[25]= fqv[451];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1301;
	local[25]= fqv[448];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compIF1302;
	local[25]= fqv[461];
	goto compIF1303;
compIF1302:
	local[25]= fqv[462];
compIF1303:
	goto compCON1283;
compCON1301:
	local[25]= fqv[463];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1304;
	local[25]= fqv[464];
	goto compCON1283;
compCON1304:
	local[25]= fqv[465];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1305;
	local[25]= fqv[466];
	goto compCON1283;
compCON1305:
	local[25]= fqv[467];
	w = loadglobal(fqv[433]);
	if (memq(local[25],w)==NIL) goto compCON1306;
	local[25]= fqv[468];
	goto compCON1283;
compCON1306:
	local[25]= fqv[469];
	ctx->vsp=local+26;
	w=(*ftab[1])(ctx,1,local+25,&ftab[1],fqv[14]); /*warn*/
	local[25]= w;
	goto compCON1283;
compCON1307:
	local[25]= NIL;
compCON1283:
	local[26]= fqv[470];
	w = loadglobal(fqv[433]);
	if (memq(local[26],w)==NIL) goto compCON1309;
	local[26]= fqv[471];
	goto compCON1308;
compCON1309:
	local[26]= fqv[472];
	w = loadglobal(fqv[433]);
	if (memq(local[26],w)==NIL) goto compCON1310;
	local[26]= fqv[473];
	goto compCON1308;
compCON1310:
	local[26]= fqv[474];
	w = loadglobal(fqv[433]);
	if (memq(local[26],w)==NIL) goto compCON1311;
	local[26]= fqv[475];
	goto compCON1308;
compCON1311:
	local[26]= fqv[476];
	goto compCON1308;
compCON1312:
	local[26]= NIL;
compCON1308:
	local[27]= fqv[477];
	w = loadglobal(fqv[433]);
	if (memq(local[27],w)==NIL) goto compIF1313;
	local[27]= fqv[478];
	goto compIF1314;
compIF1313:
	local[27]= NIL;
compIF1314:
	local[28]= fqv[479];
	w = loadglobal(fqv[433]);
	if (memq(local[28],w)==NIL) goto compIF1315;
	local[28]= fqv[480];
	goto compIF1316;
compIF1315:
	local[28]= NIL;
compIF1316:
	local[29]= fqv[481];
	w = loadglobal(fqv[433]);
	if (memq(local[29],w)==NIL) goto compIF1317;
	local[29]= fqv[482];
	goto compIF1318;
compIF1317:
	local[29]= NIL;
compIF1318:
	local[30]= fqv[483];
	w = loadglobal(fqv[433]);
	if (memq(local[30],w)==NIL) goto compIF1319;
	local[30]= fqv[484];
	goto compIF1320;
compIF1319:
	local[30]= NIL;
compIF1320:
	if (local[5]==NIL) goto compIF1321;
	local[31]= fqv[472];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1324;
	local[31]= fqv[485];
	goto compCON1323;
compCON1324:
	local[31]= fqv[465];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1325;
	local[31]= fqv[486];
	goto compCON1323;
compCON1325:
	local[31]= fqv[477];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1326;
	local[31]= fqv[487];
	goto compCON1323;
compCON1326:
	local[31]= fqv[474];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1327;
	local[31]= fqv[488];
	goto compCON1323;
compCON1327:
	local[31]= fqv[451];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1328;
	local[31]= fqv[489];
	goto compCON1323;
compCON1328:
	local[31]= fqv[437];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1329;
	local[31]= fqv[490];
	goto compCON1323;
compCON1329:
	local[31]= fqv[439];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1330;
	local[31]= fqv[491];
	goto compCON1323;
compCON1330:
	local[31]= fqv[463];
	w = loadglobal(fqv[433]);
	if (memq(local[31],w)==NIL) goto compCON1331;
	local[31]= fqv[492];
	goto compCON1323;
compCON1331:
	local[31]= fqv[493];
	goto compCON1323;
compCON1332:
	local[31]= NIL;
compCON1323:
	goto compIF1322;
compIF1321:
	local[31]= NIL;
compIF1322:
	local[32]= local[0];
	local[33]= fqv[494];
	local[34]= loadglobal(fqv[495]);
	ctx->vsp=local+35;
	w=(*ftab[19])(ctx,1,local+34,&ftab[19],fqv[396]); /*namestring*/
	local[34]= w;
	local[35]= fqv[496];
	local[36]= loadglobal(fqv[390]);
	local[37]= loadglobal(fqv[497]);
	local[38]= fqv[498];
	local[39]= local[14];
	ctx->vsp=local+40;
	w=(*ftab[19])(ctx,1,local+39,&ftab[19],fqv[396]); /*namestring*/
	local[39]= w;
	local[40]= fqv[472];
	w = loadglobal(fqv[433]);
	if (memq(local[40],w)==NIL) goto compIF1333;
	if (local[5]==NIL) goto compIF1333;
	local[40]= loadglobal(fqv[177]);
	local[41]= fqv[499];
	local[42]= local[18];
	ctx->vsp=local+43;
	w=(*ftab[19])(ctx,1,local+42,&ftab[19],fqv[396]); /*namestring*/
	local[42]= w;
	local[43]= fqv[500];
	local[44]= local[17];
	ctx->vsp=local+45;
	w=(*ftab[19])(ctx,1,local+44,&ftab[19],fqv[396]); /*namestring*/
	local[44]= w;
	ctx->vsp=local+45;
	w=(pointer)CONCATENATE(ctx,5,local+40); /*concatenate*/
	local[40]= w;
	goto compIF1334;
compIF1333:
	local[40]= NIL;
compIF1334:
	local[41]= fqv[437];
	w = loadglobal(fqv[433]);
	if (memq(local[41],w)!=NIL) goto compOR1337;
	local[41]= fqv[439];
	w = loadglobal(fqv[433]);
	if (memq(local[41],w)!=NIL) goto compOR1337;
	goto compIF1335;
compOR1337:
	if (local[5]==NIL) goto compIF1335;
	local[41]= loadglobal(fqv[177]);
	local[42]= fqv[501];
	local[43]= local[18];
	ctx->vsp=local+44;
	w=(*ftab[19])(ctx,1,local+43,&ftab[19],fqv[396]); /*namestring*/
	local[43]= w;
	local[44]= fqv[502];
	local[45]= local[17];
	ctx->vsp=local+46;
	w=(*ftab[19])(ctx,1,local+45,&ftab[19],fqv[396]); /*namestring*/
	local[45]= w;
	ctx->vsp=local+46;
	w=(pointer)CONCATENATE(ctx,5,local+41); /*concatenate*/
	local[41]= w;
	goto compIF1336;
compIF1335:
	local[41]= NIL;
compIF1336:
	local[42]= fqv[451];
	w = loadglobal(fqv[433]);
	if (memq(local[42],w)==NIL) goto compIF1338;
	if (local[5]==NIL) goto compIF1338;
	local[42]= loadglobal(fqv[177]);
	local[43]= fqv[447];
	w = loadglobal(fqv[433]);
	if (memq(local[43],w)==NIL) goto compCON1341;
	local[43]= fqv[503];
	goto compCON1340;
compCON1341:
	local[43]= fqv[504];
	w = loadglobal(fqv[433]);
	if (memq(local[43],w)==NIL) goto compCON1342;
	local[43]= fqv[505];
	goto compCON1340;
compCON1342:
	local[43]= fqv[506];
	w = loadglobal(fqv[433]);
	if (memq(local[43],w)==NIL) goto compCON1343;
	local[43]= fqv[507];
	goto compCON1340;
compCON1343:
	local[43]= fqv[467];
	w = loadglobal(fqv[433]);
	if (memq(local[43],w)==NIL) goto compCON1344;
	local[43]= fqv[508];
	goto compCON1340;
compCON1344:
	local[43]= fqv[509];
	goto compCON1340;
compCON1345:
	local[43]= NIL;
compCON1340:
	local[44]= local[18];
	ctx->vsp=local+45;
	w=(*ftab[19])(ctx,1,local+44,&ftab[19],fqv[396]); /*namestring*/
	local[44]= w;
	local[45]= fqv[510];
	local[46]= local[17];
	ctx->vsp=local+47;
	w=(*ftab[19])(ctx,1,local+46,&ftab[19],fqv[396]); /*namestring*/
	local[46]= w;
	ctx->vsp=local+47;
	w=(pointer)CONCATENATE(ctx,5,local+42); /*concatenate*/
	local[42]= w;
	goto compIF1339;
compIF1338:
	local[42]= fqv[511];
compIF1339:
	local[43]= fqv[463];
	w = loadglobal(fqv[433]);
	if (memq(local[43],w)==NIL) goto compIF1346;
	if (local[5]==NIL) goto compIF1346;
	local[43]= loadglobal(fqv[177]);
	local[44]= fqv[512];
	local[45]= local[18];
	ctx->vsp=local+46;
	w=(*ftab[19])(ctx,1,local+45,&ftab[19],fqv[396]); /*namestring*/
	local[45]= w;
	local[46]= fqv[513];
	local[47]= local[17];
	ctx->vsp=local+48;
	w=(*ftab[19])(ctx,1,local+47,&ftab[19],fqv[396]); /*namestring*/
	local[47]= w;
	ctx->vsp=local+48;
	w=(pointer)CONCATENATE(ctx,5,local+43); /*concatenate*/
	local[43]= w;
	goto compIF1347;
compIF1346:
	local[43]= fqv[514];
compIF1347:
	local[44]= fqv[465];
	w = loadglobal(fqv[433]);
	if (memq(local[44],w)==NIL) goto compIF1348;
	if (loadglobal(fqv[515])!=NIL) goto compIF1348;
	local[44]= loadglobal(fqv[177]);
	local[45]= fqv[516];
	local[46]= local[19];
	ctx->vsp=local+47;
	w=(*ftab[19])(ctx,1,local+46,&ftab[19],fqv[396]); /*namestring*/
	local[46]= w;
	local[47]= fqv[517];
	local[48]= local[17];
	ctx->vsp=local+49;
	w=(*ftab[19])(ctx,1,local+48,&ftab[19],fqv[396]); /*namestring*/
	local[48]= w;
	local[49]= fqv[518];
	local[50]= loadglobal(fqv[495]);
	local[51]= fqv[519];
	ctx->vsp=local+52;
	w=(pointer)GETENV(ctx,1,local+51); /*unix:getenv*/
	local[51]= w;
	local[52]= fqv[520];
	local[53]= fqv[521];
	local[54]= fqv[522];
	ctx->vsp=local+55;
	w=(pointer)CONCATENATE(ctx,11,local+44); /*concatenate*/
	local[44]= w;
	goto compIF1349;
compIF1348:
	local[44]= NIL;
compIF1349:
	ctx->vsp=local+45;
	w=(pointer)CONCATENATE(ctx,24,local+21); /*concatenate*/
	local[13] = w;
	if (local[4]==NIL) goto compIF1350;
	local[21]= fqv[523];
	local[22]= local[13];
	ctx->vsp=local+23;
	w=(*ftab[1])(ctx,2,local+21,&ftab[1],fqv[14]); /*warn*/
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)SYSTEM(ctx,1,local+21); /*unix:system*/
	local[21]= w;
	goto compIF1351;
compIF1350:
	local[21]= NIL;
compIF1351:
	local[21]= NIL;
	local[22]= loadglobal(fqv[352]);
compWHL1352:
	if (local[22]==NIL) goto compWHX1353;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	w=local[22];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22] = (w)->c.cons.cdr;
	w = local[23];
	local[21] = w;
	local[23]= local[21];
	local[24]= fqv[351];
	ctx->vsp=local+25;
	w=(*ftab[22])(ctx,2,local+23,&ftab[22],fqv[524]); /*remprop*/
	goto compWHL1352;
compWHX1353:
	local[23]= NIL;
compBLK1354:
	w = NIL;
	local[21]= loadglobal(fqv[60]);
	ctx->vsp=local+22;
	w=(pointer)TERPRI(ctx,1,local+21); /*terpri*/
	local[0]= w;
compBLK1238:
	ctx->vsp=local; return(local[0]);}

/*:specials*/
static pointer compM1355compiler_specials(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[525];
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= fqv[526];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
compBLK1356:
	ctx->vsp=local; return(local[0]);}

/*:copy-compiler*/
static pointer compM1357compiler_copy_compiler(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[6];
	argv[0]->c.obj.iv[7] = NIL;
	argv[0]->c.obj.iv[6] = NIL;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)COPYOBJ(ctx,1,local+3); /*copy-object*/
	local[0] = w;
	local[3]= local[0];
	local[4]= fqv[527];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	argv[0]->c.obj.iv[7] = local[1];
	argv[0]->c.obj.iv[6] = local[2];
	w = local[0];
	local[0]= w;
compBLK1358:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer compM1359compiler_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[528]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	storeglobal(fqv[24],w);
	local[0]= loadglobal(fqv[529]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[58];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = local[0];
	argv[0]->c.obj.iv[0] = w;
	argv[0]->c.obj.iv[2] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[1] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[10] = fqv[530];
	w = argv[0];
	local[0]= w;
compBLK1360:
	ctx->vsp=local; return(local[0]);}

/*dump-function*/
static pointer compF388dump_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
compRST1362:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	local[2]= fqv[531];
	local[3]= fqv[532];
	ctx->vsp=local+4;
	w=(*ftab[21])(ctx,3,local+1,&ftab[21],fqv[416]); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,compUWP1363,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= NIL;
	local[5]= local[0];
compWHL1364:
	if (local[5]==NIL) goto compWHX1365;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)SYMFUNC(ctx,1,local+6); /*symbol-function*/
	local[6]= w;
	local[7]= NIL;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= local[8];
	if (fqv[40]!=local[9]) goto compIF1367;
	local[9]= fqv[349];
	local[10]= local[4];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	goto compIF1368;
compIF1367:
	local[9]= local[8];
	if (fqv[44]!=local[9]) goto compIF1369;
	local[9]= fqv[349];
	local[10]= local[4];
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	goto compIF1370;
compIF1369:
	local[9]= NIL;
compIF1370:
compIF1368:
	w = local[9];
	local[7] = w;
	local[8]= local[7];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,2,local+8,&ftab[23],fqv[533]); /*pprint*/
	goto compWHL1364;
compWHX1365:
	local[6]= NIL;
compBLK1366:
	w = NIL;
	ctx->vsp=local+4;
	compUWP1363(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
compBLK1361:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer compUWP1363(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*comfile*/
static pointer compF389comfile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
compRST1372:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= local[0];
compWHL1373:
	if (local[2]==NIL) goto compWHX1374;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[534];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	goto compWHL1373;
compWHX1374:
	local[3]= NIL;
compBLK1375:
	w = NIL;
	local[0]= w;
compBLK1371:
	ctx->vsp=local; return(local[0]);}

/*compile-file*/
static pointer compF390compile_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
compRST1377:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[535]);
	local[2]= loadglobal(fqv[5]);
	local[3]= fqv[534];
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[0]= w;
compBLK1376:
	ctx->vsp=local; return(local[0]);}

/*compile*/
static pointer compF391compile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
compRST1379:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= fqv[536];
	ctx->vsp=local+3;
	w=(pointer)GETPID(ctx,0,local+3); /*unix:getpid*/
	local[3]= w;
	local[4]= fqv[537];
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,1,local+4); /*gensym*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[333]); /*symbol-name*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	local[1]= w;
	local[2]= NIL;
	local[3]= (pointer)get_sym_func(fqv[538]);
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,3,local+3); /*apply*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)compF390compile_file(ctx,1,local+3); /*compile-file*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)UNLINK(ctx,1,local+3); /*unix:unlink*/
	local[3]= fqv[539];
	local[4]= local[1];
	local[5]= fqv[98];
	local[6]= fqv[540];
	ctx->vsp=local+7;
	w=(*ftab[24])(ctx,4,local+3,&ftab[24],fqv[541]); /*make-pathname*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[396]); /*namestring*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)UNLINK(ctx,1,local+3); /*unix:unlink*/
	local[3]= fqv[539];
	local[4]= local[1];
	local[5]= fqv[98];
	local[6]= fqv[542];
	ctx->vsp=local+7;
	w=(*ftab[24])(ctx,4,local+3,&ftab[24],fqv[541]); /*make-pathname*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[396]); /*namestring*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)UNLINK(ctx,1,local+3); /*unix:unlink*/
	local[3]= fqv[539];
	local[4]= local[1];
	local[5]= fqv[98];
	local[6]= fqv[543];
	ctx->vsp=local+7;
	w=(*ftab[24])(ctx,4,local+3,&ftab[24],fqv[541]); /*make-pathname*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[25])(ctx,1,local+3,&ftab[25],fqv[377]); /*load*/
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[396]); /*namestring*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)UNLINK(ctx,1,local+3); /*unix:unlink*/
	local[3]= fqv[539];
	local[4]= local[1];
	local[5]= fqv[98];
	local[6]= fqv[544];
	ctx->vsp=local+7;
	w=(*ftab[24])(ctx,4,local+3,&ftab[24],fqv[541]); /*make-pathname*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[19])(ctx,1,local+3,&ftab[19],fqv[396]); /*namestring*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)UNLINK(ctx,1,local+3); /*unix:unlink*/
	w = local[0];
	local[0]= w;
compBLK1378:
	ctx->vsp=local; return(local[0]);}

/*compile-file-if-src-newer*/
static pointer compF392compile_file_if_src_newer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto compENT1382;}
	local[0]= fqv[545];
compENT1382:
compENT1381:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-2);
	local[2]= argv[0];
	local[3]= fqv[546];
	ctx->vsp=local+4;
	w=(*ftab[18])(ctx,2,local+2,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[2]= w;
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,1,local+4,&ftab[17],fqv[392]); /*pathname*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[18])(ctx,2,local+3,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[3]= w;
	local[4]= fqv[547];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,1,local+5,&ftab[17],fqv[392]); /*pathname*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,2,local+4,&ftab[18],fqv[395]); /*merge-pathnames*/
	local[4]= w;
	local[5]= local[3];
	local[6]= fqv[98];
	local[7]= fqv[548];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[20])(ctx,1,local+5,&ftab[20],fqv[412]); /*probe-file*/
	if (w==NIL) goto compOR1385;
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[26])(ctx,2,local+5,&ftab[26],fqv[549]); /*file-newer*/
	if (w!=NIL) goto compOR1385;
	goto compIF1383;
compOR1385:
	local[5]= (pointer)get_sym_func(fqv[550]);
	local[6]= argv[0];
	local[7]= fqv[551];
	local[8]= local[3];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,5,local+5); /*apply*/
	local[5]= w;
	goto compIF1384;
compIF1383:
	local[5]= NIL;
compIF1384:
	w = argv[0];
	local[0]= w;
compBLK1380:
	ctx->vsp=local; return(local[0]);}

/*comp-file-toplevel*/
static pointer compF393comp_file_toplevel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
compRST1387:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[552];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[14]); /*warn*/
	local[1]= loadglobal(fqv[60]);
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= makeint((eusinteger_t)60000L);
	ctx->vsp=local+2;
	w=(pointer)ALLOC(ctx,1,local+1); /*system:alloc*/
	local[1]= fqv[553];
	storeglobal(fqv[554],local[1]);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= fqv[555];
	w = local[5];
	ctx->vsp=local+6;
	bindspecial(ctx,fqv[556],w);
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto compCON1389;
	local[9]= (pointer)get_sym_func(fqv[557]);
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,2,local+9); /*apply*/
	local[9]= w;
	goto compCON1388;
compCON1389:
	local[9]= local[2];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto compCON1390;
	local[9]= T;
	local[10]= fqv[558];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,2,local+9); /*format*/
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,1,local+9,&ftab[27],fqv[559]); /*exit*/
	local[9]= w;
	goto compCON1388;
compCON1390:
compWHL1392:
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto compWHX1393;
	{jmp_buf jb;
	w = makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto compCAT1395;}
	local[15]= local[0];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[3] = w;
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(*ftab[28])(ctx,1,local+15,&ftab[28],fqv[560]); /*string-upcase*/
	local[4] = w;
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[1] = w;
	local[15]= local[4];
	local[16]= fqv[561];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1397;
	local[15]= fqv[441];
	w = loadglobal(fqv[433]);
	if (memq(local[15],w)!=NIL) goto compIF1398;
	local[15]= fqv[562];
	storeglobal(fqv[390],local[15]);
	goto compIF1399;
compIF1398:
	local[15]= NIL;
compIF1399:
	goto compCON1396;
compCON1397:
	local[15]= local[4];
	local[16]= fqv[563];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1400;
	local[15]= makeint((eusinteger_t)1L);
	storeglobal(fqv[317],local[15]);
	goto compCON1396;
compCON1400:
	local[15]= local[4];
	local[16]= fqv[564];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1401;
	local[15]= makeint((eusinteger_t)2L);
	storeglobal(fqv[317],local[15]);
	goto compCON1396;
compCON1401:
	local[15]= local[4];
	local[16]= fqv[565];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1402;
	local[15]= makeint((eusinteger_t)3L);
	storeglobal(fqv[317],local[15]);
	goto compCON1396;
compCON1402:
	local[15]= local[4];
	local[16]= fqv[566];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1403;
	local[15]= T;
	storeglobal(fqv[344],local[15]);
	goto compCON1396;
compCON1403:
	local[15]= local[4];
	local[16]= fqv[567];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1404;
	local[15]= makeint((eusinteger_t)0L);
	storeglobal(fqv[184],local[15]);
	goto compCON1396;
compCON1404:
	local[15]= local[4];
	local[16]= fqv[568];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1405;
	local[15]= makeint((eusinteger_t)1L);
	storeglobal(fqv[184],local[15]);
	goto compCON1396;
compCON1405:
	local[15]= local[4];
	local[16]= fqv[569];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1406;
	local[15]= makeint((eusinteger_t)2L);
	storeglobal(fqv[184],local[15]);
	goto compCON1396;
compCON1406:
	local[15]= local[4];
	local[16]= fqv[570];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1407;
	local[15]= makeint((eusinteger_t)3L);
	storeglobal(fqv[184],local[15]);
	goto compCON1396;
compCON1407:
	local[15]= local[4];
	local[16]= fqv[571];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1408;
	local[15]= local[0];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[29])(ctx,1,local+15,&ftab[29],fqv[572]); /*read-from-string*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)EVAL(ctx,1,local+15); /*eval*/
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[1] = w;
	local[15]= local[1];
	goto compCON1396;
compCON1408:
	local[15]= local[4];
	local[16]= fqv[573];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1409;
	local[15]= NIL;
	storeglobal(fqv[386],local[15]);
	goto compCON1396;
compCON1409:
	local[15]= local[4];
	local[16]= fqv[574];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1410;
	local[15]= local[0];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[29])(ctx,1,local+15,&ftab[29],fqv[572]); /*read-from-string*/
	local[15]= w;
	w = loadglobal(fqv[433]);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	storeglobal(fqv[433],local[15]);
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[1] = w;
	local[15]= local[1];
	goto compCON1396;
compCON1410:
	local[15]= local[4];
	local[16]= fqv[575];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1411;
	local[15]= local[0];
	local[16]= local[1];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[29])(ctx,1,local+15,&ftab[29],fqv[572]); /*read-from-string*/
	local[15]= w;
	local[16]= local[15];
	ctx->vsp=local+17;
	w=(pointer)FINDPACKAGE(ctx,1,local+16); /*find-package*/
	if (w!=NIL) goto compIF1412;
	local[16]= local[15];
	ctx->vsp=local+17;
	w=(*ftab[30])(ctx,1,local+16,&ftab[30],fqv[576]); /*make-package*/
	local[16]= w;
	goto compIF1413;
compIF1412:
	local[16]= NIL;
compIF1413:
	local[16]= local[15];
	ctx->vsp=local+17;
	w=(pointer)FINDPACKAGE(ctx,1,local+16); /*find-package*/
	if (w==NIL) goto compIF1414;
	local[16]= local[15];
	ctx->vsp=local+17;
	w=(pointer)FINDPACKAGE(ctx,1,local+16); /*find-package*/
	local[16]= w;
	storeglobal(fqv[406],w);
	goto compIF1415;
compIF1414:
	local[16]= fqv[577];
	ctx->vsp=local+17;
	w=(pointer)SIGERROR(ctx,1,local+16); /*error*/
	local[16]= w;
compIF1415:
	w = local[16];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[1] = w;
	local[15]= local[1];
	goto compCON1396;
compCON1411:
	local[15]= local[4];
	local[16]= fqv[578];
	ctx->vsp=local+17;
	w=(pointer)EQUAL(ctx,2,local+15); /*equal*/
	if (w==NIL) goto compCON1416;
	local[15]= T;
	storeglobal(fqv[387],local[15]);
	goto compCON1396;
compCON1416:
	local[15]= local[4];
	local[16]= fqv[579];
	ctx->vsp=local+17;
	w=(*ftab[31])(ctx,2,local+15,&ftab[31],fqv[580]); /*string-equal*/
	if (w==NIL) goto compCON1417;
	local[15]= NIL;
	storeglobal(fqv[387],local[15]);
	goto compCON1396;
compCON1417:
	local[15]= loadglobal(fqv[5]);
	local[16]= fqv[534];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	goto compCON1396;
compCON1418:
	local[15]= NIL;
compCON1396:
	w = local[15];
compCAT1395:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	goto compWHL1392;
compWHX1393:
	local[9]= NIL;
compBLK1394:
	goto compCON1388;
compCON1391:
	local[9]= NIL;
compCON1388:
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[27])(ctx,1,local+9,&ftab[27],fqv[559]); /*exit*/
	local[9]= w;
	ctx->vsp=local+10;
	unbindx(ctx,1);
	w = local[9];
	local[0]= w;
compBLK1386:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___comp(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[581];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto compIF1419;
	local[0]= fqv[582];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[406],w);
	goto compIF1420;
compIF1419:
	local[0]= fqv[583];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
compIF1420:
	local[0]= fqv[584];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[585];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[586],module,compF377compiled_code_p,fqv[587]);
	local[0]= fqv[390];
	local[1]= fqv[588];
	local[2]= fqv[589];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[497];
	local[1]= fqv[588];
	local[2]= fqv[590];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[352];
	local[1]= fqv[588];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[344];
	local[1]= fqv[588];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[317];
	local[1]= fqv[588];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[184];
	local[1]= fqv[588];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[320];
	local[1]= fqv[588];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[386];
	local[1]= fqv[588];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[387];
	local[1]= fqv[588];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[515];
	local[1]= fqv[588];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[429];
	local[1]= fqv[588];
	local[2]= fqv[504];
	local[3]= loadglobal(fqv[433]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,2,local+2,&ftab[10],fqv[267]); /*member*/
	if (w==NIL) goto compCON1422;
	local[2]= fqv[591];
	goto compCON1421;
compCON1422:
	local[2]= fqv[506];
	local[3]= loadglobal(fqv[433]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,2,local+2,&ftab[10],fqv[267]); /*member*/
	if (w==NIL) goto compCON1423;
	local[2]= fqv[592];
	goto compCON1421;
compCON1423:
	local[2]= fqv[477];
	local[3]= loadglobal(fqv[433]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,2,local+2,&ftab[10],fqv[267]); /*member*/
	if (w==NIL) goto compCON1424;
	local[2]= fqv[593];
	goto compCON1421;
compCON1424:
	local[2]= fqv[463];
	local[3]= loadglobal(fqv[433]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,2,local+2,&ftab[10],fqv[267]); /*member*/
	if (w==NIL) goto compCON1425;
	local[2]= fqv[594];
	goto compCON1421;
compCON1425:
	local[2]= fqv[595];
	goto compCON1421;
compCON1426:
	local[2]= NIL;
compCON1421:
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[5];
	local[1]= fqv[596];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto compIF1427;
	local[0]= fqv[5];
	local[1]= fqv[596];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[5];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto compIF1429;
	local[0]= fqv[5];
	local[1]= fqv[588];
	local[2]= NIL;
	local[3]= fqv[597];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto compIF1430;
compIF1429:
	local[0]= NIL;
compIF1430:
	local[0]= fqv[5];
	goto compIF1428;
compIF1427:
	local[0]= NIL;
compIF1428:
	local[0]= fqv[24];
	local[1]= fqv[596];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto compIF1431;
	local[0]= fqv[24];
	local[1]= fqv[596];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[24];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto compIF1433;
	local[0]= fqv[24];
	local[1]= fqv[588];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto compIF1434;
compIF1433:
	local[0]= NIL;
compIF1434:
	local[0]= fqv[24];
	goto compIF1432;
compIF1431:
	local[0]= NIL;
compIF1432:
	local[0]= fqv[417];
	local[1]= fqv[596];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto compIF1435;
	local[0]= fqv[417];
	local[1]= fqv[596];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[417];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto compIF1437;
	local[0]= fqv[417];
	local[1]= fqv[588];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto compIF1438;
compIF1437:
	local[0]= NIL;
compIF1438:
	local[0]= fqv[417];
	goto compIF1436;
compIF1435:
	local[0]= NIL;
compIF1436:
	ctx->vsp=local+0;
	compfun(ctx,fqv[598],module,compF378ovafp,fqv[599]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[600],module,compF379class_symbolp,fqv[601]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[602],module,compF380quoted_symbolp,fqv[603]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[604],module,compF381proclaimed_special_p,fqv[605]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[606],module,compF382proclaimed_global_p,fqv[607]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[608],module,compF383object_variable_names,fqv[609]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[610],module,compF384object_variable_type,fqv[611]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[612],module,compF385coerce_type,fqv[613]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[614],module,compF386check_arg,fqv[615]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[616],module,compF387def_function_type,fqv[617]);
	local[0]= fqv[9];
	local[1]= fqv[618];
	ctx->vsp=local+2;
	w=(pointer)compF387def_function_type(ctx,2,local+0); /*def-function-type*/
	local[0]= fqv[11];
	local[1]= fqv[619];
	ctx->vsp=local+2;
	w=(pointer)compF387def_function_type(ctx,2,local+0); /*def-function-type*/
	local[0]= loadglobal(fqv[179]);
	local[1]= fqv[620];
	ctx->vsp=local+2;
	w=(pointer)compF387def_function_type(ctx,2,local+0); /*def-function-type*/
	local[0]= fqv[57];
	local[1]= fqv[588];
	local[2]= fqv[57];
	local[3]= fqv[621];
	local[4]= loadglobal(fqv[357]);
	local[5]= fqv[622];
	local[6]= fqv[623];
	local[7]= fqv[624];
	local[8]= NIL;
	local[9]= fqv[625];
	local[10]= NIL;
	local[11]= fqv[626];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[627];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[32])(ctx,13,local+2,&ftab[32],fqv[628]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM437identifier_type,fqv[98],fqv[57],fqv[629]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM441identifier_offset,fqv[630],fqv[57],fqv[631]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM445identifier_binding,fqv[64],fqv[57],fqv[632]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM449identifier_init,fqv[58],fqv[57],fqv[633]);
	local[0]= fqv[529];
	local[1]= fqv[588];
	local[2]= fqv[529];
	local[3]= fqv[621];
	local[4]= loadglobal(fqv[357]);
	local[5]= fqv[622];
	local[6]= fqv[634];
	local[7]= fqv[624];
	local[8]= NIL;
	local[9]= fqv[625];
	local[10]= NIL;
	local[11]= fqv[626];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[627];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[32])(ctx,13,local+2,&ftab[32],fqv[628]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM451identifier_table_find,fqv[65],fqv[529],fqv[635]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM455identifier_table_get,fqv[56],fqv[529],fqv[636]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM464identifier_table_enter,fqv[17],fqv[529],fqv[637]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM468identifier_table_enter_special,fqv[59],fqv[529],fqv[638]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM470identifier_table_create_frame,fqv[78],fqv[529],fqv[639]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM472identifier_table_pop_frame,fqv[84],fqv[529],fqv[640]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM474identifier_table_clear_frame,fqv[641],fqv[529],fqv[642]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM476identifier_table_level,fqv[79],fqv[529],fqv[643]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM480identifier_table_frame,fqv[526],fqv[529],fqv[644]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM484identifier_table_init_frames,fqv[420],fqv[529],fqv[645]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM489identifier_table_init,fqv[58],fqv[529],fqv[646]);
	local[0]= fqv[77];
	local[1]= fqv[588];
	local[2]= fqv[77];
	local[3]= fqv[621];
	local[4]= loadglobal(fqv[357]);
	local[5]= fqv[622];
	local[6]= fqv[647];
	local[7]= fqv[624];
	local[8]= NIL;
	local[9]= fqv[625];
	local[10]= NIL;
	local[11]= fqv[626];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[627];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[32])(ctx,13,local+2,&ftab[32],fqv[628]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM493stack_frame_offset,fqv[630],fqv[77],fqv[648]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM499stack_frame_special,fqv[70],fqv[77],fqv[649]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM503stack_frame_local,fqv[72],fqv[77],fqv[650]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM507stack_frame_init,fqv[58],fqv[77],fqv[651]);
	local[0]= fqv[652];
	local[1]= fqv[588];
	local[2]= fqv[652];
	local[3]= fqv[621];
	local[4]= loadglobal(fqv[357]);
	local[5]= fqv[622];
	local[6]= fqv[653];
	local[7]= fqv[624];
	local[8]= NIL;
	local[9]= fqv[625];
	local[10]= NIL;
	local[11]= fqv[626];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[627];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[32])(ctx,13,local+2,&ftab[32],fqv[628]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[21];
	local[1]= fqv[596];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto compIF1439;
	local[0]= fqv[21];
	local[1]= fqv[596];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[21];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto compIF1441;
	local[0]= fqv[21];
	local[1]= fqv[588];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto compIF1442;
compIF1441:
	local[0]= NIL;
compIF1442:
	local[0]= fqv[21];
	goto compIF1440;
compIF1439:
	local[0]= NIL;
compIF1440:
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM509compiler_genlabel,fqv[256],fqv[652],fqv[654]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM513compiler_gencname_tail,fqv[655],fqv[652],fqv[656]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM516compiler_progn,fqv[235],fqv[652],fqv[657]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM524compiler_eval,fqv[23],fqv[652],fqv[658]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM554compiler_get_function,fqv[39],fqv[652],fqv[659]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM565compiler_call_closure,fqv[47],fqv[652],fqv[660]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM572compiler_variable,fqv[63],fqv[652],fqv[661]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM580compiler_var_binding,fqv[274],fqv[652],fqv[662]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM584compiler_special_variable_p,fqv[283],fqv[652],fqv[663]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM589compiler_enter_variable,fqv[69],fqv[652],fqv[664]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM598compiler_bind,fqv[280],fqv[652],fqv[665]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM617compiler_create_frame,fqv[78],fqv[652],fqv[666]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM619compiler_delete_frame,fqv[282],fqv[652],fqv[667]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM627compiler_load_ovaf,fqv[36],fqv[652],fqv[668]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM636compiler_load_var,fqv[33],fqv[652],fqv[669]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM650compiler_store_ovaf,fqv[101],fqv[652],fqv[670]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM656compiler_store_var,fqv[276],fqv[652],fqv[671]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM666compiler_funcall,fqv[41],fqv[652],fqv[672]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM739compiler_vector_op,fqv[162],fqv[652],fqv[673]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM750compiler_slot,fqv[167],fqv[652],fqv[674]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM757compiler_setslot,fqv[170],fqv[652],fqv[675]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM764compiler_arithmetic,fqv[164],fqv[652],fqv[676]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM807compiler_special_form,fqv[43],fqv[652],fqv[677]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM861compiler_conditional_jump,fqv[250],fqv[652],fqv[678]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM865compiler_evcon,fqv[254],fqv[652],fqv[679]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM904compiler_if,fqv[204],fqv[652],fqv[680]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM906compiler_setq,fqv[202],fqv[652],fqv[681]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM920compiler_let_,fqv[208],fqv[652],fqv[682]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM932compiler_let,fqv[206],fqv[652],fqv[683]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM950compiler_cond,fqv[210],fqv[652],fqv[684]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM961compiler_while,fqv[212],fqv[652],fqv[685]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM963compiler_and,fqv[214],fqv[652],fqv[686]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM968compiler_or,fqv[216],fqv[652],fqv[687]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM973compiler_catch,fqv[222],fqv[652],fqv[688]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM975compiler_throw,fqv[224],fqv[652],fqv[689]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM977compiler_unwind_protect,fqv[233],fqv[652],fqv[690]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM979compiler_enter_block,fqv[288],fqv[652],fqv[691]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM983compiler_leave_block,fqv[289],fqv[652],fqv[692]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM985compiler_block,fqv[218],fqv[652],fqv[693]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM987compiler_return_from,fqv[220],fqv[652],fqv[694]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM994compiler_tagbody,fqv[226],fqv[652],fqv[695]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1007compiler_go,fqv[228],fqv[652],fqv[696]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1012compiler_function,fqv[237],fqv[652],fqv[697]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1018compiler_flet,fqv[230],fqv[652],fqv[698]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1025compiler_change_flets,fqv[311],fqv[652],fqv[699]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1027compiler_declare,fqv[279],fqv[652],fqv[700]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1067compiler_lambda,fqv[346],fqv[652],fqv[701]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1142compiler_lambda_block,fqv[355],fqv[652],fqv[702]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1152compiler_def_user_entry,fqv[380],fqv[652],fqv[703]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1156compiler_defun,fqv[369],fqv[652],fqv[704]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1164compiler_defmethod,fqv[372],fqv[652],fqv[705]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1174compiler_add_initcode,fqv[356],fqv[652],fqv[706]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1176compiler_add_closure,fqv[298],fqv[652],fqv[707]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1178compiler_closure_level,fqv[527],fqv[652],fqv[708]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1180compiler_compile_a_closure,fqv[367],fqv[652],fqv[709]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1184compiler_compile_closures,fqv[366],fqv[652],fqv[710]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1189compiler_toplevel_eval,fqv[381],fqv[652],fqv[711]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1199compiler_toplevel,fqv[378],fqv[652],fqv[712]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1227compiler_toplevel_execution,fqv[422],fqv[652],fqv[713]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1237compiler_compile_file,fqv[534],fqv[652],fqv[714]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1355compiler_specials,fqv[715],fqv[652],fqv[716]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1357compiler_copy_compiler,fqv[297],fqv[652],fqv[717]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,compM1359compiler_init,fqv[58],fqv[652],fqv[718]);
	local[0]= loadglobal(fqv[652]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	storeglobal(fqv[5],w);
	local[0]= loadglobal(fqv[5]);
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[538],module,compF388dump_function,fqv[719]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[720],module,compF389comfile,fqv[721]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[550],module,compF390compile_file,fqv[722]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[376],module,compF391compile,fqv[723]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[724],module,compF392compile_file_if_src_newer,fqv[725]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[726],module,compF393comp_file_toplevel,fqv[727]);
	local[0]= fqv[728];
	local[1]= fqv[729];
	ctx->vsp=local+2;
	w=(*ftab[33])(ctx,2,local+0,&ftab[33],fqv[730]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<34; i++) ftab[i]=fcallx;
}
