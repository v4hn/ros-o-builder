/* ./string.c :  entry=string */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Apr 4 05:09:15 UTC 2026) */
#include "eus.h"
#include "string.h"
#pragma init (register_string)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___string();
extern pointer build_quote_vector();
static int register_string()
  { add_module_initializer("___string", ___string);}

static pointer stringF2806read_sharp_backslash();
static pointer stringF2807true_string();
static pointer stringF2808string();
static pointer stringF2809make_string();
static pointer stringF2810string_left_trim();
static pointer stringF2811string_right_trim();
static pointer stringF2812string_trim();
static pointer stringF2813nstring_downcase();
static pointer stringF2814nstring_upcase();
static pointer stringF2815string_upcase();
static pointer stringF2816string_downcase();
static pointer stringF2817string_();
static pointer stringF2818string_equal();
static pointer stringF2819substringp();
static pointer stringF2820explode_directory_names();
static pointer stringF2821pathnamep();
static pointer stringF2822pathname();
static pointer stringF2823namestring();
static pointer stringF2824pathname_directory();
static pointer stringF2825pathname_name();
static pointer stringF2826pathname_type();
static pointer stringF2827directory_namestring();
static pointer stringF2828make_pathname();
static pointer stringF2829parse_namestring();
static pointer stringF2830null_string_p();
static pointer stringF2831merge_pathnames();
static pointer stringF2832concatenate_pathnames();
static pointer stringF2833truename();
static pointer stringF2834url_pathname();
static pointer stringF2835parse_url();
static pointer stringF2836escape_url();
static pointer stringF2837escaped_url_string_from_namestring();
static pointer stringF2838unescape_url();
static pointer stringF2839unescaped_url_string_from_namestring();
static pointer stringF2840digits_string();
static pointer stringF2841timed_file_name();
static pointer stringF2842dated_file_name();
static pointer stringF2843sequential_file_name();

/*read_sharp_backslash*/
static pointer stringF2806read_sharp_backslash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)READCH(ctx,1,local+3); /*read-char*/
	local[0] = w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ALPHAP(ctx,1,local+3); /*alpha-char-p*/
	if (w==NIL) goto stringCON2846;
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)UNREADCH(ctx,2,local+3); /*unread-char*/
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,1,local+3); /*read*/
	local[1] = w;
	local[3]= *(ovafptr(local[1],fqv[0]));
	local[4]= fqv[1];
	local[5]= fqv[2];
	local[6]= (pointer)get_sym_func(fqv[3]);
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,4,local+3,&ftab[0],fqv[4]); /*assoc*/
	local[2] = w;
	if (local[2]==NIL) goto stringIF2847;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto stringIF2848;
stringIF2847:
	local[3]= *(ovafptr(local[1],fqv[0]));
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	if (makeint((eusinteger_t)1L)!=local[3]) goto stringIF2849;
	local[3]= local[0];
	goto stringIF2850;
stringIF2849:
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
stringIF2850:
stringIF2848:
	goto stringCON2845;
stringCON2846:
	local[3]= local[0];
	goto stringCON2845;
stringCON2851:
	local[3]= NIL;
stringCON2845:
	w = local[3];
	local[0]= w;
stringBLK2844:
	ctx->vsp=local; return(local[0]);}

/*true-string*/
static pointer stringF2807true_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!issymbol(w)) goto stringIF2853;
	local[0]= argv[0]->c.obj.iv[4];
	goto stringIF2854;
stringIF2853:
	local[0]= argv[0];
stringIF2854:
	w = local[0];
	local[0]= w;
stringBLK2852:
	ctx->vsp=local; return(local[0]);}

/*string*/
static pointer stringF2808string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isstring(w)) goto stringCON2857;
	local[0]= argv[0];
	goto stringCON2856;
stringCON2857:
	w = argv[0];
	if (!issymbol(w)) goto stringCON2858;
	local[0]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
	goto stringCON2856;
stringCON2858:
	w = argv[0];
	if (!numberp(w)) goto stringCON2859;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[6]); /*princ-to-string*/
	local[0]= w;
	goto stringCON2856;
stringCON2859:
	local[0]= fqv[7];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto stringCON2856;
stringCON2860:
	local[0]= NIL;
stringCON2856:
	w = local[0];
	local[0]= w;
stringBLK2855:
	ctx->vsp=local; return(local[0]);}

/*make-string*/
static pointer stringF2809make_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[8]);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
stringBLK2861:
	ctx->vsp=local; return(local[0]);}

/*string-left-trim*/
static pointer stringF2810string_left_trim(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)stringF2807true_string(ctx,1,local+1); /*true-string*/
	argv[1] = w;
stringWHL2863:
	local[1]= argv[1];
	{ register eusinteger_t i=intval(local[0]);
	  w=makeint(local[1]->c.str.chars[i]);}
	local[1]= w;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[9]); /*position*/
	if (w==NIL) goto stringWHX2864;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[0] = w;
	goto stringWHL2863;
stringWHX2864:
	local[1]= NIL;
stringBLK2865:
	local[1]= argv[1];
	local[2]= local[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[0]= w;
stringBLK2862:
	ctx->vsp=local; return(local[0]);}

/*string-right-trim*/
static pointer stringF2811string_right_trim(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)stringF2807true_string(ctx,1,local+1); /*true-string*/
	argv[1] = w;
stringWHL2867:
	local[1]= argv[1];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	{ register eusinteger_t i=intval(w);
	  w=makeint(local[1]->c.str.chars[i]);}
	local[1]= w;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[9]); /*position*/
	if (w==NIL) goto stringWHX2868;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[0] = w;
	goto stringWHL2867;
stringWHX2868:
	local[1]= NIL;
stringBLK2869:
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[0]= w;
stringBLK2866:
	ctx->vsp=local; return(local[0]);}

/*string-trim*/
static pointer stringF2812string_trim(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)stringF2811string_right_trim(ctx,2,local+1); /*string-right-trim*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)stringF2810string_left_trim(ctx,2,local+0); /*string-left-trim*/
	local[0]= w;
stringBLK2870:
	ctx->vsp=local; return(local[0]);}

/*nstring-downcase*/
static pointer stringF2813nstring_downcase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[10], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto stringKEY2872;
	local[0] = makeint((eusinteger_t)0L);
stringKEY2872:
	if (n & (1<<1)) goto stringKEY2873;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[1] = w;
stringKEY2873:
	w = argv[0];
	if (isstring(w)) goto stringIF2874;
	local[2]= fqv[11];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto stringIF2875;
stringIF2874:
	local[2]= NIL;
stringIF2875:
stringWHL2876:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto stringWHX2877;
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= argv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=makeint(local[4]->c.str.chars[i]);}
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CHDOWNCASE(ctx,1,local+4); /*char-downcase*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.str.chars[i]=intval(w);}
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto stringWHL2876;
stringWHX2877:
	local[2]= NIL;
stringBLK2878:
	w = argv[0];
	local[0]= w;
stringBLK2871:
	ctx->vsp=local; return(local[0]);}

/*nstring-upcase*/
static pointer stringF2814nstring_upcase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[12], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto stringKEY2880;
	local[0] = makeint((eusinteger_t)0L);
stringKEY2880:
	if (n & (1<<1)) goto stringKEY2881;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[1] = w;
stringKEY2881:
	w = argv[0];
	if (isstring(w)) goto stringIF2882;
	local[2]= fqv[13];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto stringIF2883;
stringIF2882:
	local[2]= NIL;
stringIF2883:
stringWHL2884:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto stringWHX2885;
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= argv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=makeint(local[4]->c.str.chars[i]);}
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CHUPCASE(ctx,1,local+4); /*char-upcase*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.str.chars[i]=intval(w);}
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto stringWHL2884;
stringWHX2885:
	local[2]= NIL;
stringBLK2886:
	w = argv[0];
	local[0]= w;
stringBLK2879:
	ctx->vsp=local; return(local[0]);}

/*string-upcase*/
static pointer stringF2815string_upcase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[14], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto stringKEY2888;
	local[0] = makeint((eusinteger_t)0L);
stringKEY2888:
	if (n & (1<<1)) goto stringKEY2889;
	local[1] = NIL;
stringKEY2889:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)stringF2807true_string(ctx,1,local+2); /*true-string*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)COPYSEQ(ctx,1,local+2); /*copy-seq*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[15];
	local[5]= local[0];
	local[6]= fqv[16];
	if (local[1]==NIL) goto stringIF2890;
	local[7]= local[1];
	goto stringIF2891;
stringIF2890:
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
stringIF2891:
	ctx->vsp=local+8;
	w=(pointer)stringF2814nstring_upcase(ctx,5,local+3); /*nstring-upcase*/
	local[0]= w;
stringBLK2887:
	ctx->vsp=local; return(local[0]);}

/*string-downcase*/
static pointer stringF2816string_downcase(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[17], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto stringKEY2893;
	local[0] = makeint((eusinteger_t)0L);
stringKEY2893:
	if (n & (1<<1)) goto stringKEY2894;
	local[1] = NIL;
stringKEY2894:
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)stringF2807true_string(ctx,1,local+2); /*true-string*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)COPYSEQ(ctx,1,local+2); /*copy-seq*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[15];
	local[5]= local[0];
	local[6]= fqv[16];
	if (local[1]==NIL) goto stringIF2895;
	local[7]= local[1];
	goto stringIF2896;
stringIF2895:
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
stringIF2896:
	ctx->vsp=local+8;
	w=(pointer)stringF2813nstring_downcase(ctx,5,local+3); /*nstring-downcase*/
	local[0]= w;
stringBLK2892:
	ctx->vsp=local; return(local[0]);}

/*string=*/
static pointer stringF2817string_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[18], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto stringKEY2898;
	local[0] = makeint((eusinteger_t)0L);
stringKEY2898:
	if (n & (1<<1)) goto stringKEY2899;
	local[1] = makeint((eusinteger_t)100000000L);
stringKEY2899:
	if (n & (1<<2)) goto stringKEY2900;
	local[2] = makeint((eusinteger_t)0L);
stringKEY2900:
	if (n & (1<<3)) goto stringKEY2901;
	local[3] = makeint((eusinteger_t)100000000L);
stringKEY2901:
	local[4]= argv[0];
	local[5]= argv[1];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,6,local+4,&ftab[3],fqv[19]); /*stringeq*/
	local[0]= w;
stringBLK2897:
	ctx->vsp=local; return(local[0]);}

/*string-equal*/
static pointer stringF2818string_equal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[20], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto stringKEY2903;
	local[0] = makeint((eusinteger_t)0L);
stringKEY2903:
	if (n & (1<<1)) goto stringKEY2904;
	local[1] = makeint((eusinteger_t)100000000L);
stringKEY2904:
	if (n & (1<<2)) goto stringKEY2905;
	local[2] = makeint((eusinteger_t)0L);
stringKEY2905:
	if (n & (1<<3)) goto stringKEY2906;
	local[3] = makeint((eusinteger_t)100000000L);
stringKEY2906:
	local[4]= argv[0];
	local[5]= argv[1];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[4])(ctx,6,local+4,&ftab[4],fqv[21]); /*stringequal*/
	local[0]= w;
stringBLK2902:
	ctx->vsp=local; return(local[0]);}

/*substringp*/
static pointer stringF2819substringp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[0]= (pointer)((eusinteger_t)local[0] - (eusinteger_t)w);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
stringTAG2909:
	local[3]= local[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto stringIF2910;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto stringBLK2908;
	goto stringIF2911;
stringIF2910:
	local[3]= NIL;
stringIF2911:
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= fqv[22];
	local[6]= local[2];
	local[7]= fqv[23];
	local[8]= local[2];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)PLUS(ctx,2,local+8); /*+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)stringF2818string_equal(ctx,6,local+3); /*string-equal*/
	if (w==NIL) goto stringIF2912;
	w = T;
	ctx->vsp=local+3;
	local[0]=w;
	goto stringBLK2907;
	goto stringIF2913;
stringIF2912:
	local[3]= NIL;
stringIF2913:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[2] = local[3];
	w = NIL;
	ctx->vsp=local+3;
	goto stringTAG2909;
	w = NIL;
	local[0]= w;
stringBLK2908:
	w = local[0];
	local[0]= w;
stringBLK2907:
	ctx->vsp=local; return(local[0]);}

/*:get*/
static pointer stringM2914string_get(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
stringBLK2915:
	ctx->vsp=local; return(local[0]);}

/*:set*/
static pointer stringM2916string_set(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	w = argv[2];
	if (!numberp(w)) goto stringIF2918;
	local[0]= argv[2];
	local[1]= argv[0];
	local[2]= argv[3];
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
	goto stringIF2919;
stringIF2918:
	local[0]= argv[4];
	local[1]= fqv[24];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[4]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= NIL;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,1,local+2,&ftab[5],fqv[25]); /*flatten*/
	local[2]= w;
stringWHL2920:
	if (local[2]==NIL) goto stringWHX2921;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	w = local[1];
	if (!numberp(w)) goto stringCON2924;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= argv[3];
	local[6]= argv[4];
	ctx->vsp=local+7;
	w=(pointer)POKE(ctx,4,local+3); /*system:poke*/
	local[3]= argv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[3] = w;
	local[3]= argv[3];
	goto stringCON2923;
stringCON2924:
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
stringWHL2926:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto stringWHX2927;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ROUND(ctx,1,local+5); /*round*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(pointer)POKE(ctx,4,local+5); /*system:poke*/
	local[5]= argv[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	argv[3] = w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto stringWHL2926;
stringWHX2927:
	local[5]= NIL;
stringBLK2928:
	w = NIL;
	local[3]= w;
	goto stringCON2923;
stringCON2925:
	local[3]= NIL;
stringCON2923:
	goto stringWHL2920;
stringWHX2921:
	local[3]= NIL;
stringBLK2922:
	w = NIL;
	local[0]= w;
stringIF2919:
	w = local[0];
	local[0]= w;
stringBLK2917:
	ctx->vsp=local; return(local[0]);}

/*explode-directory-names*/
static pointer stringF2820explode_directory_names(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
stringWHL2930:
	local[4]= makeint((eusinteger_t)47L);
	local[5]= argv[0];
	local[6]= fqv[15];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(*ftab[2])(ctx,4,local+4,&ftab[2],fqv[9]); /*position*/
	local[3] = w;
	if (local[3]==NIL) goto stringWHX2931;
	local[4]= argv[0];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[0] = w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[4] <= (eusinteger_t)w) goto stringIF2933;
	local[4]= local[0];
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto stringIF2934;
stringIF2933:
	local[4]= NIL;
stringIF2934:
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto stringWHL2930;
stringWHX2931:
	local[4]= NIL;
stringBLK2932:
	local[4]= argv[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,2,local+4); /*subseq*/
	local[0] = w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[4] <= (eusinteger_t)w) goto stringIF2935;
	local[4]= local[0];
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto stringIF2936;
stringIF2935:
	local[4]= NIL;
stringIF2936:
	w = local[1];
	local[0]= w;
stringBLK2929:
	ctx->vsp=local; return(local[0]);}

/*:parse-namestring*/
static pointer stringM2937pathname_parse_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
	argv[0]->c.obj.iv[2] = NIL;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[6])(ctx,1,local+7,&ftab[6],fqv[26]); /*zerop*/
	if (w==NIL) goto stringIF2939;
	argv[0]->c.obj.iv[0] = fqv[27];
	argv[0]->c.obj.iv[1] = fqv[28];
	w = argv[0];
	ctx->vsp=local+7;
	local[0]=w;
	goto stringBLK2938;
	goto stringIF2940;
stringIF2939:
	local[7]= NIL;
stringIF2940:
	local[7]= makeint((eusinteger_t)58L);
	local[8]= argv[2];
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,2,local+7,&ftab[2],fqv[9]); /*position*/
	local[6] = w;
	if (local[6]==NIL) goto stringIF2941;
	local[0] = local[6];
	local[7]= argv[2];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	argv[0]->c.obj.iv[0] = w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[0] = w;
	local[7]= local[0];
	goto stringIF2942;
stringIF2941:
	local[7]= NIL;
stringIF2942:
	local[1] = local[0];
	local[7]= argv[2];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)47L);
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto stringCON2944;
	local[7]= fqv[29];
	w = argv[0]->c.obj.iv[2];
	ctx->vsp=local+8;
	argv[0]->c.obj.iv[2] = cons(ctx,local[7],w);
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[1] = w;
	local[7]= local[1];
	goto stringCON2943;
stringCON2944:
	local[7]= argv[2];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)126L);
	ctx->vsp=local+9;
	w=(pointer)EQ(ctx,2,local+7); /*eql*/
	if (w==NIL) goto stringCON2945;
	local[7]= fqv[30];
	ctx->vsp=local+8;
	w=(pointer)GETENV(ctx,1,local+7); /*unix:getenv*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)stringF2820explode_directory_names(ctx,1,local+7); /*explode-directory-names*/
	argv[0]->c.obj.iv[2] = w;
	local[7]= argv[0]->c.obj.iv[2];
	local[8]= fqv[29];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NCONC(ctx,2,local+7); /*nconc*/
	argv[0]->c.obj.iv[2] = w;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[1] = w;
	local[7]= local[1];
	goto stringCON2943;
stringCON2945:
	local[7]= NIL;
stringCON2943:
stringWHL2946:
	local[7]= makeint((eusinteger_t)47L);
	local[8]= argv[2];
	local[9]= fqv[15];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,4,local+7,&ftab[2],fqv[9]); /*position*/
	local[6] = w;
	if (local[6]==NIL) goto stringWHX2947;
	local[7]= argv[2];
	local[8]= local[1];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[3] = w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[7] <= (eusinteger_t)w) goto stringIF2949;
	local[7]= local[3];
	w = argv[0]->c.obj.iv[2];
	ctx->vsp=local+8;
	argv[0]->c.obj.iv[2] = cons(ctx,local[7],w);
	local[7]= argv[0]->c.obj.iv[2];
	goto stringIF2950;
stringIF2949:
	local[7]= NIL;
stringIF2950:
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[1] = w;
	local[2] = local[1];
	goto stringWHL2946;
stringWHX2947:
	local[7]= NIL;
stringBLK2948:
	local[7]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	argv[0]->c.obj.iv[2] = w;
	local[7]= argv[2];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,2,local+7); /*subseq*/
	local[4] = w;
	local[7]= local[4];
	local[8]= fqv[31];
	ctx->vsp=local+9;
	w=(pointer)EQUAL(ctx,2,local+7); /*equal*/
	if (w==NIL) goto stringCON2952;
	argv[0]->c.obj.iv[3] = local[4];
	argv[0]->c.obj.iv[4] = NIL;
	local[7]= argv[0]->c.obj.iv[4];
	goto stringCON2951;
stringCON2952:
	local[7]= makeint((eusinteger_t)46L);
	local[8]= argv[2];
	local[9]= fqv[15];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,4,local+7,&ftab[2],fqv[9]); /*position*/
	local[2] = w;
	if (local[2]!=NIL) goto stringCON2955;
	local[7]= argv[2];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w==NIL) goto stringIF2956;
	local[7]= argv[2];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,2,local+7); /*subseq*/
	argv[0]->c.obj.iv[3] = w;
	local[7]= argv[0]->c.obj.iv[3];
	goto stringIF2957;
stringIF2956:
	local[7]= NIL;
stringIF2957:
	goto stringCON2954;
stringCON2955:
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[2] = w;
stringWHL2959:
	local[7]= makeint((eusinteger_t)46L);
	local[8]= argv[2];
	local[9]= fqv[15];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,4,local+7,&ftab[2],fqv[9]); /*position*/
	local[6] = w;
	if (local[6]==NIL) goto stringWHX2960;
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[2] = w;
	goto stringWHL2959;
stringWHX2960:
	local[7]= NIL;
stringBLK2961:
	local[7]= argv[2];
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SUB1(ctx,1,local+9); /*1-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	argv[0]->c.obj.iv[3] = w;
	local[7]= argv[2];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,2,local+7); /*subseq*/
	argv[0]->c.obj.iv[4] = w;
	local[7]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+8;
	w=(pointer)stringF2830null_string_p(ctx,1,local+7); /*null-string-p*/
	if (w==NIL) goto stringIF2962;
	argv[0]->c.obj.iv[3] = NIL;
	local[7]= argv[0]->c.obj.iv[3];
	goto stringIF2963;
stringIF2962:
	local[7]= NIL;
stringIF2963:
	goto stringCON2954;
stringCON2958:
	local[7]= NIL;
stringCON2954:
	goto stringCON2951;
stringCON2953:
	local[7]= NIL;
stringCON2951:
	w = argv[0];
	local[0]= w;
stringBLK2938:
	ctx->vsp=local; return(local[0]);}

/*:directory-string*/
static pointer stringM2964pathname_directory_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[2];
	w=argv[0]->c.obj.iv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)EQ(ctx,2,local+2); /*eql*/
	if (w==NIL) goto stringIF2966;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[2]= fqv[32];
	w = local[0];
	ctx->vsp=local+3;
	local[0] = cons(ctx,local[2],w);
	local[2]= local[0];
	goto stringIF2967;
stringIF2966:
	local[2]= NIL;
stringIF2967:
	local[2]= NIL;
	local[3]= local[1];
stringWHL2968:
	if (local[3]==NIL) goto stringWHX2969;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	local[4]= fqv[33];
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	goto stringWHL2968;
stringWHX2969:
	local[4]= NIL;
stringBLK2970:
	w = NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0] = w;
	local[2]= (pointer)get_sym_func(fqv[34]);
	local[3]= loadglobal(fqv[8]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,3,local+2); /*apply*/
	local[0]= w;
stringBLK2965:
	ctx->vsp=local; return(local[0]);}

/*:namestring*/
static pointer stringM2971pathname_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	if (argv[0]->c.obj.iv[4]==NIL) goto stringIF2973;
	local[1]= loadglobal(fqv[8]);
	local[2]= fqv[36];
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(pointer)CONCATENATE(ctx,3,local+1); /*concatenate*/
	local[1]= w;
	goto stringIF2974;
stringIF2973:
	local[1]= NIL;
stringIF2974:
	if (argv[0]->c.obj.iv[3]==NIL) goto stringIF2975;
	local[2]= loadglobal(fqv[8]);
	local[3]= argv[0]->c.obj.iv[0];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[3];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,6,local+2); /*concatenate*/
	local[2]= w;
	goto stringIF2976;
stringIF2975:
	local[2]= loadglobal(fqv[8]);
	local[3]= argv[0]->c.obj.iv[0];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)CONCATENATE(ctx,5,local+2); /*concatenate*/
	local[2]= w;
stringIF2976:
	w = local[2];
	local[0]= w;
stringBLK2972:
	ctx->vsp=local; return(local[0]);}

/*:host*/
static pointer stringM2977pathname_host(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT2980;}
	local[0]= NIL;
stringENT2980:
stringENT2979:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF2981;
	argv[0]->c.obj.iv[0] = local[0];
	local[1]= argv[0]->c.obj.iv[0];
	goto stringIF2982;
stringIF2981:
	local[1]= argv[0]->c.obj.iv[0];
stringIF2982:
	w = local[1];
	local[0]= w;
stringBLK2978:
	ctx->vsp=local; return(local[0]);}

/*:device*/
static pointer stringM2983pathname_device(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT2986;}
	local[0]= NIL;
stringENT2986:
stringENT2985:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF2987;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto stringIF2988;
stringIF2987:
	local[1]= argv[0]->c.obj.iv[1];
stringIF2988:
	w = local[1];
	local[0]= w;
stringBLK2984:
	ctx->vsp=local; return(local[0]);}

/*:directory*/
static pointer stringM2989pathname_directory(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT2992;}
	local[0]= NIL;
stringENT2992:
stringENT2991:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF2993;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto stringIF2994;
stringIF2993:
	local[1]= argv[0]->c.obj.iv[2];
stringIF2994:
	w = local[1];
	local[0]= w;
stringBLK2990:
	ctx->vsp=local; return(local[0]);}

/*:name*/
static pointer stringM2995pathname_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT2998;}
	local[0]= NIL;
stringENT2998:
stringENT2997:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF2999;
	argv[0]->c.obj.iv[3] = local[0];
	local[1]= argv[0]->c.obj.iv[3];
	goto stringIF3000;
stringIF2999:
	local[1]= argv[0]->c.obj.iv[3];
stringIF3000:
	w = local[1];
	local[0]= w;
stringBLK2996:
	ctx->vsp=local; return(local[0]);}

/*:type*/
static pointer stringM3001pathname_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3004;}
	local[0]= NIL;
stringENT3004:
stringENT3003:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF3005;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto stringIF3006;
stringIF3005:
	local[1]= argv[0]->c.obj.iv[4];
stringIF3006:
	w = local[1];
	local[0]= w;
stringBLK3002:
	ctx->vsp=local; return(local[0]);}

/*:set-type*/
static pointer stringM3007pathname_set_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[4] = argv[2];
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
stringBLK3008:
	ctx->vsp=local; return(local[0]);}

/*:version*/
static pointer stringM3009pathname_version(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3012;}
	local[0]= NIL;
stringENT3012:
stringENT3011:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF3013;
	argv[0]->c.obj.iv[5] = local[0];
	local[1]= argv[0]->c.obj.iv[5];
	goto stringIF3014;
stringIF3013:
	local[1]= argv[0]->c.obj.iv[5];
stringIF3014:
	w = local[1];
	local[0]= w;
stringBLK3010:
	ctx->vsp=local; return(local[0]);}

/*:merge*/
static pointer stringM3015pathname_merge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[0]!=NIL) goto stringIF3017;
	argv[0]->c.obj.iv[0] = *(ovafptr(argv[2],fqv[37]));
	local[0]= argv[0]->c.obj.iv[0];
	goto stringIF3018;
stringIF3017:
	local[0]= NIL;
stringIF3018:
	if (argv[0]->c.obj.iv[1]!=NIL) goto stringIF3019;
	argv[0]->c.obj.iv[1] = *(ovafptr(argv[2],fqv[38]));
	local[0]= argv[0]->c.obj.iv[1];
	goto stringIF3020;
stringIF3019:
	local[0]= NIL;
stringIF3020:
	if (argv[0]->c.obj.iv[2]!=NIL) goto stringIF3021;
	argv[0]->c.obj.iv[2] = *(ovafptr(argv[2],fqv[39]));
	local[0]= argv[0]->c.obj.iv[2];
	goto stringIF3022;
stringIF3021:
	local[0]= NIL;
stringIF3022:
	if (argv[0]->c.obj.iv[3]!=NIL) goto stringIF3023;
	argv[0]->c.obj.iv[3] = *(ovafptr(argv[2],fqv[40]));
	local[0]= argv[0]->c.obj.iv[3];
	goto stringIF3024;
stringIF3023:
	local[0]= NIL;
stringIF3024:
	if (argv[0]->c.obj.iv[4]!=NIL) goto stringIF3025;
	argv[0]->c.obj.iv[4] = *(ovafptr(argv[2],fqv[41]));
	local[0]= argv[0]->c.obj.iv[4];
	goto stringIF3026;
stringIF3025:
	local[0]= NIL;
stringIF3026:
	if (argv[0]->c.obj.iv[5]!=NIL) goto stringIF3027;
	argv[0]->c.obj.iv[5] = *(ovafptr(argv[2],fqv[42]));
	local[0]= argv[0]->c.obj.iv[5];
	goto stringIF3028;
stringIF3027:
	local[0]= NIL;
stringIF3028:
	w = argv[0];
	local[0]= w;
stringBLK3016:
	ctx->vsp=local; return(local[0]);}

/*:add-directory*/
static pointer stringM3029pathname_add_directory(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= (pointer)get_sym_func(fqv[8]);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
stringBLK3030:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer stringM3031pathname_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3034;}
	local[0]= T;
stringENT3034:
stringENT3033:
	if (n>3) maerror();
	local[1]= local[0];
	local[2]= fqv[43];
	local[3]= argv[0];
	local[4]= fqv[44];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[0]= w;
stringBLK3032:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer stringM3035pathname_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[45], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto stringKEY3037;
	local[0] = NIL;
stringKEY3037:
	if (n & (1<<1)) goto stringKEY3038;
	local[1] = NIL;
stringKEY3038:
	if (n & (1<<2)) goto stringKEY3039;
	local[2] = NIL;
stringKEY3039:
	if (n & (1<<3)) goto stringKEY3040;
	local[3] = NIL;
stringKEY3040:
	if (n & (1<<4)) goto stringKEY3041;
	local[4] = NIL;
stringKEY3041:
	if (n & (1<<5)) goto stringKEY3042;
	local[5] = NIL;
stringKEY3042:
	if (local[0]==NIL) goto stringIF3043;
	argv[0]->c.obj.iv[0] = local[0];
	local[6]= argv[0]->c.obj.iv[0];
	goto stringIF3044;
stringIF3043:
	local[6]= NIL;
stringIF3044:
	if (local[1]==NIL) goto stringIF3045;
	argv[0]->c.obj.iv[1] = local[1];
	local[6]= argv[0]->c.obj.iv[1];
	goto stringIF3046;
stringIF3045:
	local[6]= NIL;
stringIF3046:
	if (local[2]==NIL) goto stringIF3047;
	argv[0]->c.obj.iv[2] = local[2];
	local[6]= argv[0]->c.obj.iv[2];
	goto stringIF3048;
stringIF3047:
	local[6]= NIL;
stringIF3048:
	if (local[3]==NIL) goto stringIF3049;
	argv[0]->c.obj.iv[3] = local[3];
	local[6]= argv[0]->c.obj.iv[3];
	goto stringIF3050;
stringIF3049:
	local[6]= NIL;
stringIF3050:
	if (local[4]==NIL) goto stringIF3051;
	argv[0]->c.obj.iv[4] = local[4];
	local[6]= argv[0]->c.obj.iv[4];
	goto stringIF3052;
stringIF3051:
	local[6]= NIL;
stringIF3052:
	if (local[5]==NIL) goto stringIF3053;
	argv[0]->c.obj.iv[5] = local[5];
	local[6]= argv[0]->c.obj.iv[5];
	goto stringIF3054;
stringIF3053:
	local[6]= NIL;
stringIF3054:
	w = argv[0];
	local[0]= w;
stringBLK3036:
	ctx->vsp=local; return(local[0]);}

/*pathnamep*/
static pointer stringF2821pathnamep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[46]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
stringBLK3055:
	ctx->vsp=local; return(local[0]);}

/*pathname*/
static pointer stringF2822pathname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[46]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto stringIF3057;
	local[0]= argv[0];
	goto stringIF3058;
stringIF3057:
	if (argv[0]==NIL) goto stringIF3059;
	local[0]= loadglobal(fqv[46]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[47];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)stringF2808string(ctx,1,local+3); /*string*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
	goto stringIF3060;
stringIF3059:
	local[0]= loadglobal(fqv[46]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
stringIF3060:
stringIF3058:
	w = local[0];
	local[0]= w;
stringBLK3056:
	ctx->vsp=local; return(local[0]);}

/*namestring*/
static pointer stringF2823namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!issymbol(w)) goto stringCON3063;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2808string(ctx,1,local+0); /*string*/
	local[0]= w;
	goto stringCON3062;
stringCON3063:
	w = argv[0];
	if (!isstring(w)) goto stringCON3064;
	local[0]= argv[0];
	goto stringCON3062;
stringCON3064:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2821pathnamep(ctx,1,local+0); /*pathnamep*/
	if (w==NIL) goto stringCON3065;
	local[0]= argv[0];
	local[1]= fqv[44];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto stringCON3062;
stringCON3065:
	local[0]= fqv[48];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto stringCON3062;
stringCON3066:
	local[0]= NIL;
stringCON3062:
	w = local[0];
	local[0]= w;
stringBLK3061:
	ctx->vsp=local; return(local[0]);}

/*pathname-directory*/
static pointer stringF2824pathname_directory(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2822pathname(ctx,1,local+0); /*pathname*/
	w = *(ovafptr(w,fqv[39]));
	local[0]= w;
stringBLK3067:
	ctx->vsp=local; return(local[0]);}

/*pathname-name*/
static pointer stringF2825pathname_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2822pathname(ctx,1,local+0); /*pathname*/
	w = *(ovafptr(w,fqv[40]));
	local[0]= w;
stringBLK3068:
	ctx->vsp=local; return(local[0]);}

/*pathname-type*/
static pointer stringF2826pathname_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2822pathname(ctx,1,local+0); /*pathname*/
	w = *(ovafptr(w,fqv[41]));
	local[0]= w;
stringBLK3069:
	ctx->vsp=local; return(local[0]);}

/*directory-namestring*/
static pointer stringF2827directory_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2822pathname(ctx,1,local+0); /*pathname*/
	local[0]= w;
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
stringBLK3070:
	ctx->vsp=local; return(local[0]);}

/*make-pathname*/
static pointer stringF2828make_pathname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[49], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto stringKEY3072;
	local[0] = NIL;
stringKEY3072:
	if (n & (1<<1)) goto stringKEY3073;
	local[1] = NIL;
stringKEY3073:
	if (n & (1<<2)) goto stringKEY3074;
	local[2] = NIL;
stringKEY3074:
	if (n & (1<<3)) goto stringKEY3075;
	local[3] = NIL;
stringKEY3075:
	if (n & (1<<4)) goto stringKEY3076;
	local[4] = NIL;
stringKEY3076:
	if (n & (1<<5)) goto stringKEY3077;
	local[5] = NIL;
stringKEY3077:
	if (n & (1<<6)) goto stringKEY3078;
	local[6] = NIL;
stringKEY3078:
	local[7]= loadglobal(fqv[46]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[50];
	local[10]= fqv[51];
	local[11]= local[0];
	local[12]= fqv[52];
	local[13]= local[1];
	local[14]= fqv[53];
	local[15]= local[2];
	local[16]= fqv[54];
	local[17]= local[3];
	local[18]= fqv[55];
	local[19]= local[4];
	local[20]= fqv[56];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,14,local+8); /*send*/
	w = local[7];
	local[7]= w;
	local[8]= fqv[57];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)stringF2822pathname(ctx,1,local+9); /*pathname*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[0]= w;
stringBLK3071:
	ctx->vsp=local; return(local[0]);}

/*parse-namestring*/
static pointer stringF2829parse_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2822pathname(ctx,1,local+0); /*pathname*/
	local[0]= w;
stringBLK3079:
	ctx->vsp=local; return(local[0]);}

/*null-string-p*/
static pointer stringF2830null_string_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)EQUAL(ctx,2,local+0); /*equal*/
	local[0]= w;
stringBLK3080:
	ctx->vsp=local; return(local[0]);}

/*merge-pathnames*/
static pointer stringF2831merge_pathnames(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto stringENT3083;}
	local[0]= loadglobal(fqv[59]);
stringENT3083:
stringENT3082:
	if (n>2) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)stringF2821pathnamep(ctx,1,local+1); /*pathnamep*/
	if (w==NIL) goto stringIF3084;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)COPYOBJ(ctx,1,local+1); /*copy-object*/
	local[1]= w;
	goto stringIF3085;
stringIF3084:
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)stringF2822pathname(ctx,1,local+1); /*pathname*/
	local[1]= w;
stringIF3085:
	argv[0] = local[1];
	local[1]= argv[0];
	local[2]= fqv[57];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)stringF2822pathname(ctx,1,local+3); /*pathname*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
stringBLK3081:
	ctx->vsp=local; return(local[0]);}

/*concatenate-pathnames*/
static pointer stringF2832concatenate_pathnames(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
stringRST3087:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[34]);
	local[2]= loadglobal(fqv[8]);
	local[3]= (pointer)get_sym_func(fqv[60]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)stringF2822pathname(ctx,1,local+1); /*pathname*/
	local[0]= w;
stringBLK3086:
	ctx->vsp=local; return(local[0]);}

/*truename*/
static pointer stringF2833truename(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)stringF2822pathname(ctx,1,local+0); /*pathname*/
	argv[0] = w;
	ctx->vsp=local+0;
	w=(pointer)GETWD(ctx,0,local+0); /*unix:getwd*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[35];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= T;
	if (local[1]==NIL) goto stringIF3089;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)CHDIR(ctx,1,local+3); /*unix:chdir*/
	local[2] = w;
	local[3]= local[2];
	goto stringIF3090;
stringIF3089:
	local[3]= NIL;
stringIF3090:
	local[3]= local[2];
	if (T!=local[3]) goto stringCON3092;
	ctx->vsp=local+3;
	w=(pointer)GETWD(ctx,0,local+3); /*unix:getwd*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	w = makeint((eusinteger_t)1L);
	if ((eusinteger_t)local[3] <= (eusinteger_t)w) goto stringIF3093;
	local[3]= loadglobal(fqv[8]);
	local[4]= local[2];
	local[5]= fqv[61];
	ctx->vsp=local+6;
	w=(pointer)CONCATENATE(ctx,3,local+3); /*concatenate*/
	local[2] = w;
	local[3]= local[2];
	goto stringIF3094;
stringIF3093:
	local[3]= NIL;
stringIF3094:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)CHDIR(ctx,1,local+3); /*unix:chdir*/
	local[3]= fqv[54];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)stringF2825pathname_name(ctx,1,local+4); /*pathname-name*/
	local[4]= w;
	local[5]= fqv[55];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)stringF2826pathname_type(ctx,1,local+6); /*pathname-type*/
	local[6]= w;
	local[7]= fqv[53];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)stringF2824pathname_directory(ctx,1,local+8); /*pathname-directory*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)stringF2828make_pathname(ctx,6,local+3); /*make-pathname*/
	local[3]= w;
	goto stringCON3091;
stringCON3092:
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto stringCON3091;
stringCON3095:
	local[3]= NIL;
stringCON3091:
	w = local[3];
	local[0]= w;
stringBLK3088:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer stringM3096url_pathname_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[63];
	local[2]= argv[1];
	local[3]= fqv[54];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)ADDRESS(ctx,1,local+3); /*system:address*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[64];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
stringBLK3097:
	ctx->vsp=local; return(local[0]);}

/*:string*/
static pointer stringM3098url_pathname_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= fqv[65];
	local[2]= argv[0]->c.obj.iv[6];
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= argv[0]->c.obj.iv[8];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)stringF2823namestring(ctx,1,local+5); /*namestring*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,6,local+0); /*format*/
	local[0]= w;
stringBLK3099:
	ctx->vsp=local; return(local[0]);}

/*:string2*/
static pointer stringM3100url_pathname_string2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= fqv[66];
	local[2]= argv[0]->c.obj.iv[6];
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)stringF2823namestring(ctx,1,local+4); /*namestring*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,5,local+0); /*format*/
	local[0]= w;
stringBLK3101:
	ctx->vsp=local; return(local[0]);}

/*:port*/
static pointer stringM3102url_pathname_port(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3105;}
	local[0]= NIL;
stringENT3105:
stringENT3104:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF3106;
	argv[0]->c.obj.iv[8] = local[0];
	local[1]= argv[0]->c.obj.iv[8];
	goto stringIF3107;
stringIF3106:
	local[1]= NIL;
stringIF3107:
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
stringBLK3103:
	ctx->vsp=local; return(local[0]);}

/*:server*/
static pointer stringM3108url_pathname_server(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3111;}
	local[0]= NIL;
stringENT3111:
stringENT3110:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF3112;
	argv[0]->c.obj.iv[7] = local[0];
	local[1]= argv[0]->c.obj.iv[7];
	goto stringIF3113;
stringIF3112:
	local[1]= NIL;
stringIF3113:
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
stringBLK3109:
	ctx->vsp=local; return(local[0]);}

/*:connect*/
static pointer stringM3114url_pathname_connect(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3117;}
	local[0]= makeint((eusinteger_t)5L);
stringENT3117:
stringENT3116:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[8];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[7])(ctx,3,local+1,&ftab[7],fqv[67]); /*connect-server*/
	local[0]= w;
stringBLK3115:
	ctx->vsp=local; return(local[0]);}

/*:host*/
static pointer stringM3118url_pathname_host(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3121;}
	local[0]= NIL;
stringENT3121:
stringENT3120:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF3122;
	argv[0]->c.obj.iv[7] = local[0];
	local[1]= argv[0]->c.obj.iv[7];
	goto stringIF3123;
stringIF3122:
	local[1]= NIL;
stringIF3123:
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
stringBLK3119:
	ctx->vsp=local; return(local[0]);}

/*:protocol*/
static pointer stringM3124url_pathname_protocol(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3127;}
	local[0]= NIL;
stringENT3127:
stringENT3126:
	if (n>3) maerror();
	if (local[0]==NIL) goto stringIF3128;
	argv[0]->c.obj.iv[6] = local[0];
	local[1]= argv[0]->c.obj.iv[6];
	goto stringIF3129;
stringIF3128:
	local[1]= NIL;
stringIF3129:
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
stringBLK3125:
	ctx->vsp=local; return(local[0]);}

/*:parse-namestring*/
static pointer stringM3130url_pathname_parse_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)58L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,2,local+3,&ftab[2],fqv[9]); /*position*/
	local[0] = w;
	if (local[0]==NIL) goto stringIF3132;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	argv[0]->c.obj.iv[6] = w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[0] = w;
	local[3]= local[0];
	goto stringIF3133;
stringIF3132:
	argv[0]->c.obj.iv[6] = fqv[68];
	local[0] = makeint((eusinteger_t)0L);
	local[3]= local[0];
stringIF3133:
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)47L);
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w==NIL) goto stringCON3135;
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)47L);
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w==NIL) goto stringCON3135;
	local[3]= makeint((eusinteger_t)47L);
	local[4]= argv[2];
	local[5]= fqv[15];
	local[6]= makeint((eusinteger_t)3L);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,4,local+3,&ftab[2],fqv[9]); /*position*/
	local[2] = w;
	if (local[2]!=NIL) goto stringIF3136;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[2] = w;
	local[3]= local[2];
	goto stringIF3137;
stringIF3136:
	local[3]= NIL;
stringIF3137:
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	argv[0]->c.obj.iv[7] = w;
	local[3]= makeint((eusinteger_t)58L);
	local[4]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,2,local+3,&ftab[2],fqv[9]); /*position*/
	local[1] = w;
	if (local[1]==NIL) goto stringIF3138;
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,2,local+3); /*subseq*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,1,local+3,&ftab[8],fqv[69]); /*read-from-string*/
	argv[0]->c.obj.iv[8] = w;
	local[3]= argv[0]->c.obj.iv[7];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	argv[0]->c.obj.iv[7] = w;
	local[3]= argv[0]->c.obj.iv[7];
	goto stringIF3139;
stringIF3138:
	argv[0]->c.obj.iv[8] = makeint((eusinteger_t)80L);
	local[3]= argv[0]->c.obj.iv[8];
stringIF3139:
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[70]));
	local[5]= fqv[47];
	local[6]= argv[2];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,2,local+6); /*subseq*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,4,local+3); /*send-message*/
	local[3]= fqv[71];
	w=argv[0]->c.obj.iv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	argv[0]->c.obj.iv[2] = w;
	local[3]= argv[0];
	goto stringCON3134;
stringCON3135:
	local[3]= fqv[72];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,2,local+3); /*error*/
	local[3]= w;
	goto stringCON3134;
stringCON3140:
	local[3]= NIL;
stringCON3134:
	w = local[3];
	local[0]= w;
stringBLK3131:
	ctx->vsp=local; return(local[0]);}

/*:percent-escape*/
static pointer stringM3141url_pathname_percent_escape(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[73], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto stringKEY3143;
	local[0] = T;
stringKEY3143:
	if (n & (1<<1)) goto stringKEY3144;
	local[1] = NIL;
stringKEY3144:
	local[2]= argv[0];
	local[3]= fqv[47];
	if (local[1]==NIL) goto stringIF3145;
	local[4]= argv[0];
	local[5]= fqv[64];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)stringF2839unescaped_url_string_from_namestring(ctx,2,local+4); /*unescaped-url-string-from-namestring*/
	local[4]= w;
	goto stringIF3146;
stringIF3145:
	local[4]= argv[0];
	local[5]= fqv[64];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)stringF2837escaped_url_string_from_namestring(ctx,2,local+4); /*escaped-url-string-from-namestring*/
	local[4]= w;
stringIF3146:
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0]= w;
stringBLK3142:
	ctx->vsp=local; return(local[0]);}

/*url-pathname*/
static pointer stringF2834url_pathname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[74]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto stringIF3148;
	local[0]= argv[0];
	goto stringIF3149;
stringIF3148:
	if (argv[0]==NIL) goto stringIF3150;
	local[0]= loadglobal(fqv[74]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[47];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)stringF2808string(ctx,1,local+3); /*string*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
	goto stringIF3151;
stringIF3150:
	local[0]= loadglobal(fqv[74]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
stringIF3151:
stringIF3149:
	w = local[0];
	local[0]= w;
stringBLK3147:
	ctx->vsp=local; return(local[0]);}

/*parse-url*/
static pointer stringF2835parse_url(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[75];
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)80L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)58L);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(*ftab[2])(ctx,2,local+6,&ftab[2],fqv[9]); /*position*/
	local[4] = w;
	if (local[4]==NIL) goto stringIF3153;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[0] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	local[6]= local[4];
	goto stringIF3154;
stringIF3153:
	local[4] = makeint((eusinteger_t)0L);
	local[6]= local[4];
stringIF3154:
	local[6]= argv[0];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)47L);
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w==NIL) goto stringCON3156;
	local[6]= argv[0];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)47L);
	ctx->vsp=local+8;
	w=(pointer)EQ(ctx,2,local+6); /*eql*/
	if (w==NIL) goto stringCON3156;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)47L);
	local[9]= argv[0];
	local[10]= fqv[15];
	local[11]= makeint((eusinteger_t)3L);
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[2])(ctx,4,local+8,&ftab[2],fqv[9]); /*position*/
	local[4] = w;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[1] = w;
	local[6]= makeint((eusinteger_t)58L);
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[2])(ctx,2,local+6,&ftab[2],fqv[9]); /*position*/
	local[5] = w;
	if (local[5]==NIL) goto stringIF3157;
	local[6]= local[1];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,2,local+6); /*subseq*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[8])(ctx,1,local+6,&ftab[8],fqv[69]); /*read-from-string*/
	local[3] = w;
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)SUBSEQ(ctx,3,local+6); /*subseq*/
	local[1] = w;
	local[6]= local[1];
	goto stringIF3158;
stringIF3157:
	local[3] = makeint((eusinteger_t)80L);
	local[6]= local[3];
stringIF3158:
	local[6]= argv[0];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)SUBSEQ(ctx,2,local+6); /*subseq*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)stringF2822pathname(ctx,1,local+6); /*pathname*/
	local[2] = w;
	local[6]= local[2];
	local[7]= fqv[53];
	local[8]= fqv[76];
	local[9]= local[2];
	local[10]= fqv[53];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.cdr;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[3];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,4,local+6); /*list*/
	local[6]= w;
	goto stringCON3155;
stringCON3156:
	local[6]= fqv[77];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,2,local+6); /*error*/
	local[6]= w;
	goto stringCON3155;
stringCON3159:
	local[6]= NIL;
stringCON3155:
	w = local[6];
	local[0]= w;
stringBLK3152:
	ctx->vsp=local; return(local[0]);}

/*escape-url*/
static pointer stringF2836escape_url(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto stringENT3163;}
	local[0]= loadglobal(fqv[78]);
stringENT3163:
	if (n>=3) { local[1]=(argv[2]); goto stringENT3162;}
	local[1]= T;
stringENT3162:
stringENT3161:
	if (n>3) maerror();
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,stringFLET3164,env,argv,local);
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,stringFLET3165,env,argv,local);
	local[4]= NIL;
	local[5]= argv[0];
	local[6]= loadglobal(fqv[79]);
	ctx->vsp=local+7;
	w=(pointer)COERCE(ctx,2,local+5); /*coerce*/
	local[5]= w;
stringWHL3166:
	if (local[5]==NIL) goto stringWHX3167;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	w = local[2];
	ctx->vsp=local+7;
	w=stringFLET3164(ctx,1,local+6,w);
	if (w==NIL) goto stringCON3170;
	local[6]= local[4];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)WRTBYTE(ctx,2,local+6); /*write-byte*/
	local[6]= w;
	goto stringCON3169;
stringCON3170:
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)13L);
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,2,local+6,&ftab[9],fqv[80]); /*char=*/
	if (w==NIL) goto stringCON3171;
	local[6]= makeint((eusinteger_t)10L);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)WRTBYTE(ctx,2,local+6); /*write-byte*/
	local[6]= w;
	goto stringCON3169;
stringCON3171:
	if (local[1]==NIL) goto stringCON3172;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)32L);
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,2,local+6,&ftab[9],fqv[80]); /*char=*/
	if (w==NIL) goto stringCON3172;
	local[6]= makeint((eusinteger_t)43L);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)WRTBYTE(ctx,2,local+6); /*write-byte*/
	local[6]= w;
	goto stringCON3169;
stringCON3172:
	local[6]= local[0];
	local[7]= fqv[81];
	local[8]= NIL;
	local[9]= fqv[82];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	w = local[3];
	ctx->vsp=local+10;
	w=stringFLET3165(ctx,2,local+8,w);
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto stringCON3169;
stringCON3173:
	local[6]= NIL;
stringCON3169:
	goto stringWHL3166;
stringWHX3167:
	local[6]= NIL;
stringBLK3168:
	w = NIL;
	local[0]= w;
stringBLK3160:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer stringFLET3164(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)65L);
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)90L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	local[0]= w;
	if (w!=NIL) goto stringOR3174;
	local[0]= makeint((eusinteger_t)97L);
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)122L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	local[0]= w;
	if (w!=NIL) goto stringOR3174;
	local[0]= makeint((eusinteger_t)48L);
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)57L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,3,local+0); /*<=*/
	local[0]= w;
	if (w!=NIL) goto stringOR3174;
	local[0]= argv[0];
	local[1]= loadglobal(fqv[83]);
	local[2]= fqv[2];
	local[3]= (pointer)get_sym_func(fqv[80]);
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,4,local+0,&ftab[10],fqv[84]); /*find*/
	local[0]= w;
stringOR3174:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer stringFLET3165(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(*ftab[11])(ctx,0,local+0,&ftab[11],fqv[85]); /*make-string-output-stream*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
stringWHL3175:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto stringWHX3176;
	local[3]= makeint((eusinteger_t)48L);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)WRTBYTE(ctx,2,local+3); /*write-byte*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto stringWHL3175;
stringWHX3176:
	local[3]= NIL;
stringBLK3177:
	w = NIL;
	local[1]= local[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,2,local+1); /*format*/
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,1,local+1,&ftab[12],fqv[86]); /*get-output-stream-string*/
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,1,local+1,&ftab[12],fqv[86]); /*get-output-stream-string*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*escaped-url-string-from-namestring*/
static pointer stringF2837escaped_url_string_from_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto stringENT3180;}
	local[0]= T;
stringENT3180:
stringENT3179:
	if (n>2) maerror();
	ctx->vsp=local+1;
	w=(*ftab[11])(ctx,0,local+1,&ftab[11],fqv[85]); /*make-string-output-stream*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)stringF2836escape_url(ctx,3,local+2); /*escape-url*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[86]); /*get-output-stream-string*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[86]); /*get-output-stream-string*/
	local[0]= w;
stringBLK3178:
	ctx->vsp=local; return(local[0]);}

/*unescape-url*/
static pointer stringF2838unescape_url(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto stringENT3184;}
	local[0]= loadglobal(fqv[78]);
stringENT3184:
	if (n>=3) { local[1]=(argv[2]); goto stringENT3183;}
	local[1]= T;
stringENT3183:
stringENT3182:
	if (n>3) maerror();
	local[2]= argv[0];
	local[3]= fqv[15];
	local[4]= fqv[87];
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,2,local+3,&ftab[13],fqv[88]); /*member*/
	if (w==NIL) goto stringIF3185;
	local[3]= fqv[15];
	local[4]= fqv[89];
	ctx->vsp=local+5;
	w=(*ftab[13])(ctx,2,local+3,&ftab[13],fqv[88]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto stringIF3186;
stringIF3185:
	local[3]= NIL;
stringIF3186:
	local[4]= fqv[16];
	local[5]= fqv[90];
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,2,local+4,&ftab[13],fqv[88]); /*member*/
	if (w==NIL) goto stringIF3187;
	local[4]= fqv[16];
	local[5]= fqv[91];
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,2,local+4,&ftab[13],fqv[88]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	goto stringIF3188;
stringIF3187:
	local[4]= NIL;
stringIF3188:
	ctx->vsp=local+5;
	w=(*ftab[14])(ctx,3,local+2,&ftab[14],fqv[92]); /*make-string-input-stream*/
	local[2]= w;
stringWHL3189:
	local[3]= local[2];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)PEEKCH(ctx,2,local+3); /*peek-char*/
	if (w==NIL) goto stringWHX3190;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)PEEKCH(ctx,1,local+3); /*peek-char*/
	local[3]= w;
	local[4]= local[3];
	if (fqv[93]!=local[4]) goto stringIF3192;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)READCH(ctx,1,local+4); /*read-char*/
	local[4]= makeint((eusinteger_t)35L);
	local[5]= makeint((eusinteger_t)120L);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)READCH(ctx,1,local+6); /*read-char*/
	local[6]= w;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)READCH(ctx,1,local+7); /*read-char*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,4,local+4); /*list*/
	local[4]= w;
	local[5]= loadglobal(fqv[8]);
	ctx->vsp=local+6;
	w=(pointer)COERCE(ctx,2,local+4); /*coerce*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,1,local+4,&ftab[8],fqv[69]); /*read-from-string*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)WRTBYTE(ctx,2,local+4); /*write-byte*/
	local[4]= w;
	goto stringIF3193;
stringIF3192:
	local[4]= local[3];
	if (fqv[94]!=local[4]) goto stringIF3194;
	if (local[1]==NIL) goto stringIF3196;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)READCH(ctx,1,local+4); /*read-char*/
	local[4]= makeint((eusinteger_t)32L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)WRTBYTE(ctx,2,local+4); /*write-byte*/
	local[4]= w;
	goto stringIF3197;
stringIF3196:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)READCH(ctx,1,local+4); /*read-char*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)WRTBYTE(ctx,2,local+4); /*write-byte*/
	local[4]= w;
stringIF3197:
	goto stringIF3195;
stringIF3194:
	if (T==NIL) goto stringIF3198;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)READCH(ctx,1,local+4); /*read-char*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)WRTBYTE(ctx,2,local+4); /*write-byte*/
	local[4]= w;
	goto stringIF3199;
stringIF3198:
	local[4]= NIL;
stringIF3199:
stringIF3195:
stringIF3193:
	w = local[4];
	goto stringWHL3189;
stringWHX3190:
	local[3]= NIL;
stringBLK3191:
	w = local[3];
	local[0]= w;
stringBLK3181:
	ctx->vsp=local; return(local[0]);}

/*unescaped-url-string-from-namestring*/
static pointer stringF2839unescaped_url_string_from_namestring(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto stringENT3202;}
	local[0]= T;
stringENT3202:
stringENT3201:
	if (n>2) maerror();
	ctx->vsp=local+1;
	w=(*ftab[11])(ctx,0,local+1,&ftab[11],fqv[85]); /*make-string-output-stream*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)stringF2838unescape_url(ctx,3,local+2); /*unescape-url*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[86]); /*get-output-stream-string*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[86]); /*get-output-stream-string*/
	local[0]= w;
stringBLK3200:
	ctx->vsp=local; return(local[0]);}

/*digits-string*/
static pointer stringF2840digits_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3205;}
	local[0]= makeint((eusinteger_t)10L);
stringENT3205:
stringENT3204:
	if (n>3) maerror();
	local[1]= argv[1];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,2,local+1); /*<=*/
	if (w==NIL) goto stringIF3206;
	local[1]= NIL;
	local[2]= fqv[95];
	local[3]= argv[0];
	local[4]= argv[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto stringIF3207;
stringIF3206:
	local[1]= loadglobal(fqv[8]);
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)stringF2840digits_string(ctx,2,local+2); /*digits-string*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)stringF2840digits_string(ctx,2,local+3); /*digits-string*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)CONCATENATE(ctx,3,local+1); /*concatenate*/
	local[1]= w;
stringIF3207:
	w = local[1];
	local[0]= w;
stringBLK3203:
	ctx->vsp=local; return(local[0]);}

/*timed-file-name*/
static pointer stringF2841timed_file_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3210;}
	ctx->vsp=local+0;
	w=(pointer)LOCALTIME(ctx,0,local+0); /*unix:localtime*/
	local[0]= w;
stringENT3210:
stringENT3209:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= fqv[96];
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)stringF2840digits_string(ctx,2,local+4); /*digits-string*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)stringF2840digits_string(ctx,2,local+5); /*digits-string*/
	local[5]= w;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)stringF2840digits_string(ctx,2,local+6); /*digits-string*/
	local[6]= w;
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,7,local+1); /*format*/
	local[0]= w;
stringBLK3208:
	ctx->vsp=local; return(local[0]);}

/*dated-file-name*/
static pointer stringF2842dated_file_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto stringENT3213;}
	ctx->vsp=local+0;
	w=(pointer)LOCALTIME(ctx,0,local+0); /*unix:localtime*/
	local[0]= w;
stringENT3213:
stringENT3212:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= fqv[97];
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)5L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)stringF2840digits_string(ctx,2,local+4); /*digits-string*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)4L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= fqv[98];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[4]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)stringF2840digits_string(ctx,2,local+6); /*digits-string*/
	local[6]= w;
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,7,local+1); /*format*/
	local[0]= w;
stringBLK3211:
	ctx->vsp=local; return(local[0]);}

/*sequential-file-name*/
static pointer stringF2843sequential_file_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto stringENT3216;}
	local[0]= makeint((eusinteger_t)4L);
stringENT3216:
stringENT3215:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= fqv[99];
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)stringF2840digits_string(ctx,2,local+4); /*digits-string*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,5,local+1); /*format*/
	local[0]= w;
stringBLK3214:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___string(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[100];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= fqv[101];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto stringIF3217;
	local[0]= fqv[102];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[103],w);
	goto stringIF3218;
stringIF3217:
	local[0]= fqv[104];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
stringIF3218:
	local[0]= fqv[105];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[106],module,stringF2806read_sharp_backslash,fqv[107]);
	local[0]= makeint((eusinteger_t)35L);
	local[1]= makeint((eusinteger_t)92L);
	local[2]= fqv[106];
	ctx->vsp=local+3;
	w=(pointer)SETDISPMACRO(ctx,3,local+0); /*set-dispatch-macro-character*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[108],module,stringF2807true_string,fqv[109]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[8],module,stringF2808string,fqv[110]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[111],module,stringF2809make_string,fqv[112]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[113],module,stringF2810string_left_trim,fqv[114]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[115],module,stringF2811string_right_trim,fqv[116]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[117],module,stringF2812string_trim,fqv[118]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[119],module,stringF2813nstring_downcase,fqv[120]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[121],module,stringF2814nstring_upcase,fqv[122]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[123],module,stringF2815string_upcase,fqv[124]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[125],module,stringF2816string_downcase,fqv[126]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[127],module,stringF2817string_,fqv[128]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[3],module,stringF2818string_equal,fqv[129]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[130],module,stringF2819substringp,fqv[131]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2914string_get,fqv[132],fqv[8],fqv[133]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2916string_set,fqv[134],fqv[8],fqv[135]);
	local[0]= fqv[46];
	local[1]= fqv[136];
	local[2]= fqv[46];
	local[3]= fqv[137];
	local[4]= loadglobal(fqv[138]);
	local[5]= fqv[139];
	local[6]= fqv[140];
	local[7]= fqv[141];
	local[8]= NIL;
	local[9]= fqv[142];
	local[10]= NIL;
	local[11]= fqv[143];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[144];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[145]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[146];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[147],module,stringF2820explode_directory_names,fqv[148]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2937pathname_parse_namestring,fqv[47],fqv[46],fqv[149]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2964pathname_directory_string,fqv[35],fqv[46],fqv[150]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2971pathname_namestring,fqv[44],fqv[46],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2977pathname_host,fqv[51],fqv[46],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2983pathname_device,fqv[52],fqv[46],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2989pathname_directory,fqv[53],fqv[46],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM2995pathname_name,fqv[54],fqv[46],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3001pathname_type,fqv[55],fqv[46],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3007pathname_set_type,fqv[157],fqv[46],fqv[158]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3009pathname_version,fqv[56],fqv[46],fqv[159]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3015pathname_merge,fqv[57],fqv[46],fqv[160]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3029pathname_add_directory,fqv[161],fqv[46],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3031pathname_prin1,fqv[163],fqv[46],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3035pathname_init,fqv[50],fqv[46],fqv[165]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[166],module,stringF2821pathnamep,fqv[167]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[46],module,stringF2822pathname,fqv[168]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[60],module,stringF2823namestring,fqv[169]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[170],module,stringF2824pathname_directory,fqv[171]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[172],module,stringF2825pathname_name,fqv[173]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[174],module,stringF2826pathname_type,fqv[175]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[176],module,stringF2827directory_namestring,fqv[177]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[178],module,stringF2828make_pathname,fqv[179]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[180],module,stringF2829parse_namestring,fqv[181]);
	local[0]= fqv[59];
	local[1]= fqv[136];
	local[2]= fqv[182];
	local[3]= fqv[183];
	local[4]= fqv[184];
	local[5]= fqv[185];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,4,local+2); /*list*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[186],module,stringF2830null_string_p,fqv[187]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[188],module,stringF2831merge_pathnames,fqv[189]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[190],module,stringF2832concatenate_pathnames,fqv[191]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[192],module,stringF2833truename,fqv[193]);
	local[0]= fqv[74];
	local[1]= fqv[136];
	local[2]= fqv[74];
	local[3]= fqv[137];
	local[4]= loadglobal(fqv[46]);
	local[5]= fqv[139];
	local[6]= fqv[194];
	local[7]= fqv[141];
	local[8]= NIL;
	local[9]= fqv[142];
	local[10]= NIL;
	local[11]= fqv[143];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[144];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[15])(ctx,13,local+2,&ftab[15],fqv[145]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3096url_pathname_prin1,fqv[163],fqv[74],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3098url_pathname_string,fqv[64],fqv[74],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3100url_pathname_string2,fqv[197],fqv[74],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3102url_pathname_port,fqv[199],fqv[74],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3108url_pathname_server,fqv[201],fqv[74],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3114url_pathname_connect,fqv[203],fqv[74],fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3118url_pathname_host,fqv[51],fqv[74],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3124url_pathname_protocol,fqv[206],fqv[74],fqv[207]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3130url_pathname_parse_namestring,fqv[47],fqv[74],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,stringM3141url_pathname_percent_escape,fqv[209],fqv[74],fqv[210]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[74],module,stringF2834url_pathname,fqv[211]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[212],module,stringF2835parse_url,fqv[213]);
	local[0]= fqv[83];
	local[1]= fqv[214];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto stringIF3219;
	local[0]= fqv[83];
	local[1]= fqv[214];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[83];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto stringIF3221;
	local[0]= fqv[83];
	local[1]= fqv[136];
	local[2]= fqv[215];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto stringIF3222;
stringIF3221:
	local[0]= NIL;
stringIF3222:
	local[0]= fqv[83];
	goto stringIF3220;
stringIF3219:
	local[0]= NIL;
stringIF3220:
	ctx->vsp=local+0;
	compfun(ctx,fqv[216],module,stringF2836escape_url,fqv[217]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[218],module,stringF2837escaped_url_string_from_namestring,fqv[219]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[220],module,stringF2838unescape_url,fqv[221]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[222],module,stringF2839unescaped_url_string_from_namestring,fqv[223]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[224],module,stringF2840digits_string,fqv[225]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[226],module,stringF2841timed_file_name,fqv[227]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[228],module,stringF2842dated_file_name,fqv[229]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[230],module,stringF2843sequential_file_name,fqv[231]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<16; i++) ftab[i]=fcallx;
}
