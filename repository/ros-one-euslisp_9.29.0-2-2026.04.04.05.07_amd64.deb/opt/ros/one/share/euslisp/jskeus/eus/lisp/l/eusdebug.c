/* ./eusdebug.c :  entry=eusdebug */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Apr 4 05:09:15 UTC 2026) */
#include "eus.h"
#include "eusdebug.h"
#pragma init (register_eusdebug)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___eusdebug();
extern pointer build_quote_vector();
static int register_eusdebug()
  { add_module_initializer("___eusdebug", ___eusdebug);}

static pointer eusdebugF1835warning_message();
static pointer eusdebugF1836warn();
static pointer eusdebugF1837describe();
static pointer eusdebugF1838describe_list();
static pointer eusdebugF1839apropos();
static pointer eusdebugF1840apropos_list();
static pointer eusdebugF1841dump_string();
static pointer eusdebugF1842break();
static pointer eusdebugF1843setbreak();
static pointer eusdebugF1844unbreak();
static pointer eusdebugF1845btrace();
static pointer eusdebugF1846eval_dynamic();
static pointer eusdebugF1847step_hook();
static pointer eusdebugF1848tracex();
static pointer eusdebugF1849trace1();
static pointer eusdebugF1850inspect1();
static pointer eusdebugF1851time_func();
static pointer eusdebugF1852list_symbols();
static pointer eusdebugF1853functions();
static pointer eusdebugF1854special_variables();
static pointer eusdebugF1855global_variables();
static pointer eusdebugF1856variables();
static pointer eusdebugF1857constants();
static pointer eusdebugF1858methods();
static pointer eusdebugF1859method_list();
static pointer eusdebugF1860y_or_n_p();
static pointer eusdebugF1861yes_or_no_p();
static pointer eusdebugF1862bell();
static pointer eusdebugF1863check_methods();
static pointer eusdebugF1864pfuncs();
static pointer eusdebugF1865class_hierarchy();
static pointer eusdebugF1866classdef();
static pointer eusdebugF1867classdefs();
static pointer eusdebugF1868remote_error();
static pointer eusdebugF1869reval();
static pointer eusdebugF1870install_remote_function();
static pointer eusdebugF1871open_server();

/*assert*/
static pointer eusdebugF1872(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT1875;}
	local[0]= fqv[0];
eusdebugENT1875:
eusdebugENT1874:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-2);
	local[2]= fqv[1];
	local[3]= fqv[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[3];
	local[5]= fqv[4];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= NIL;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[5];
	local[6]= fqv[4];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[6];
	local[7]= fqv[7];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
eusdebugBLK1873:
	ctx->vsp=local; return(local[0]);}

/*warning-message*/
static pointer eusdebugF1835warning_message(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
eusdebugRST1877:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[4]);
	local[2]= fqv[8];
	local[3]= makeint((eusinteger_t)27L);
	local[4]= argv[0];
	local[5]= makeint((eusinteger_t)48L);
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	local[1]= (pointer)get_sym_func(fqv[3]);
	local[2]= loadglobal(fqv[4]);
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= loadglobal(fqv[4]);
	local[2]= fqv[9];
	local[3]= makeint((eusinteger_t)27L);
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= loadglobal(fqv[4]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
eusdebugBLK1876:
	ctx->vsp=local; return(local[0]);}

/*warn*/
static pointer eusdebugF1836warn(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
eusdebugRST1879:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= (pointer)get_sym_func(fqv[3]);
	local[2]= loadglobal(fqv[4]);
	local[3]= argv[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= loadglobal(fqv[4]);
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	if (loadglobal(fqv[10])==NIL) goto eusdebugIF1880;
	local[1]= fqv[11];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[6]); /*reploop*/
	local[1]= w;
	goto eusdebugIF1881;
eusdebugIF1880:
	local[1]= NIL;
eusdebugIF1881:
	w = local[1];
	local[0]= w;
eusdebugBLK1878:
	ctx->vsp=local; return(local[0]);}

/*describe*/
static pointer eusdebugF1837describe(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT1886;}
	local[0]= loadglobal(fqv[12]);
eusdebugENT1886:
	if (n>=3) { local[1]=(argv[2]); goto eusdebugENT1885;}
	local[1]= NIL;
eusdebugENT1885:
	w = local[1];
	ctx->vsp=local+1;
	bindspecial(ctx,fqv[13],w);
	if (n>=4) { local[4]=(argv[3]); goto eusdebugENT1884;}
	local[4]= NIL;
eusdebugENT1884:
	w = local[4];
	ctx->vsp=local+4;
	bindspecial(ctx,fqv[14],w);
eusdebugENT1883:
	if (n>4) maerror();
	w = argv[0];
	if (!numberp(w)) goto eusdebugIF1887;
	local[7]= argv[0];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)PRINT(ctx,2,local+7); /*print*/
	w = NIL;
	ctx->vsp=local+7;
	unwind(ctx,local+0);
	local[0]=w;
	goto eusdebugBLK1882;
	goto eusdebugIF1888;
eusdebugIF1887:
	local[7]= NIL;
eusdebugIF1888:
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)GETCLASS(ctx,1,local+7); /*class*/
	local[7]= w;
	local[8]= NIL;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[8] = local[7]->c.obj.iv[4];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[9] = w;
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)VECTORP(ctx,1,local+11); /*vectorp*/
	if (w==NIL) goto eusdebugIF1889;
	local[11]= argv[0];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(*ftab[1])(ctx,2,local+11,&ftab[1],fqv[15]); /*pprint*/
	local[11]= w;
	goto eusdebugIF1890;
eusdebugIF1889:
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[9];
eusdebugWHL1891:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto eusdebugWHX1892;
	local[13]= local[0];
	local[14]= fqv[16];
	local[15]= local[8];
	{ register eusinteger_t i=intval(local[11]);
	  w=(local[15]->c.vec.v[i]);}
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,3,local+13); /*format*/
	local[13]= local[8];
	{ register eusinteger_t i=intval(local[11]);
	  w=(local[13]->c.vec.v[i]);}
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PRNTSIZE(ctx,1,local+13); /*print-size*/
	local[10] = w;
	local[13]= local[10];
	local[14]= makeint((eusinteger_t)20L);
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto eusdebugIF1894;
	local[10] = makeint((eusinteger_t)5L);
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)TERPRI(ctx,1,local+13); /*terpri*/
	local[13]= w;
	goto eusdebugIF1895;
eusdebugIF1894:
	local[13]= NIL;
eusdebugIF1895:
	if (loadglobal(fqv[13])==NIL) goto eusdebugIF1896;
	local[13]= argv[0];
	local[14]= local[7];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)SLOT(ctx,3,local+13); /*slot*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PRINT(ctx,1,local+13); /*print*/
	local[13]= w;
	goto eusdebugIF1897;
eusdebugIF1896:
	local[13]= argv[0];
	local[14]= local[7];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)SLOT(ctx,3,local+13); /*slot*/
	local[13]= w;
	local[14]= local[0];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)ADD1(ctx,1,local+15); /*1+*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)78L);
	ctx->vsp=local+17;
	w=(*ftab[1])(ctx,4,local+13,&ftab[1],fqv[15]); /*pprint*/
	local[13]= w;
eusdebugIF1897:
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto eusdebugWHL1891;
eusdebugWHX1892:
	local[13]= NIL;
eusdebugBLK1893:
	w = NIL;
	local[11]= w;
eusdebugIF1890:
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)FINOUT(ctx,1,local+11); /*finish-output*/
	local[7]= w;
	ctx->vsp=local+8;
	unbindx(ctx,2);
	w = local[7];
	local[0]= w;
eusdebugBLK1882:
	ctx->vsp=local; return(local[0]);}

/*describe-list*/
static pointer eusdebugF1838describe_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT1900;}
	local[0]= loadglobal(fqv[12]);
eusdebugENT1900:
eusdebugENT1899:
	if (n>2) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugFLET1901,env,argv,local);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)STREAMP(ctx,1,local+3); /*streamp*/
	if (w!=NIL) goto eusdebugIF1902;
	local[3]= local[0];
	local[4]= fqv[17];
	local[5]= fqv[18];
	local[6]= fqv[19];
	local[7]= fqv[20];
	local[8]= fqv[21];
	local[9]= fqv[22];
	ctx->vsp=local+10;
	w=(*ftab[2])(ctx,7,local+3,&ftab[2],fqv[23]); /*open*/
	local[1] = w;
	local[3]= local[1];
	goto eusdebugIF1903;
eusdebugIF1902:
	local[3]= NIL;
eusdebugIF1903:
	local[3]= argv[0];
	w = local[2];
	ctx->vsp=local+4;
	w=eusdebugFLET1901(ctx,1,local+3,w);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)STREAMP(ctx,1,local+3); /*streamp*/
	if (w!=NIL) goto eusdebugIF1904;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)CLOSE(ctx,1,local+3); /*close*/
	local[3]= w;
	goto eusdebugIF1905;
eusdebugIF1904:
	local[3]= NIL;
eusdebugIF1905:
	w = local[3];
	local[0]= w;
eusdebugBLK1898:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugFLET1901(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto eusdebugCON1907;
	local[0]= NIL;
	local[1]= argv[0];
eusdebugWHL1908:
	if (local[1]==NIL) goto eusdebugWHX1909;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	w = env->c.clo.env2[2];
	ctx->vsp=local+3;
	w=eusdebugFLET1901(ctx,1,local+2,w);
	goto eusdebugWHL1908;
eusdebugWHX1909:
	local[2]= NIL;
eusdebugBLK1910:
	w = NIL;
	local[0]= w;
	goto eusdebugCON1906;
eusdebugCON1907:
	local[0]= env->c.clo.env2[1];
	local[1]= fqv[24];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0];
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(pointer)eusdebugF1837describe(ctx,2,local+0); /*describe*/
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)TERPRI(ctx,1,local+0); /*terpri*/
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)TERPRI(ctx,1,local+0); /*terpri*/
	local[0]= w;
	goto eusdebugCON1906;
eusdebugCON1911:
	local[0]= NIL;
eusdebugCON1906:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*apropos*/
static pointer eusdebugF1839apropos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT1914;}
	local[0]= NIL;
eusdebugENT1914:
eusdebugENT1913:
	if (n>2) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	argv[0] = w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,eusdebugFLET1915,env,argv,local);
	if (local[0]==NIL) goto eusdebugCON1917;
	local[2]= NIL;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)FINDPACKAGE(ctx,1,local+3); /*find-package*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= *(ovafptr(local[3],fqv[26]));
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
eusdebugWHL1918:
	local[7]= local[4];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto eusdebugWHX1919;
	local[7]= local[5];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[2] = w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[4] = w;
	w = local[2];
	if (!issymbol(w)) goto eusdebugIF1921;
	local[7]= argv[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,1,local+8,&ftab[3],fqv[25]); /*string*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[27]); /*substringp*/
	if (w==NIL) goto eusdebugIF1923;
	local[7]= local[2];
	w = local[1];
	ctx->vsp=local+8;
	w=eusdebugFLET1915(ctx,1,local+7,w);
	local[7]= w;
	goto eusdebugIF1924;
eusdebugIF1923:
	local[7]= NIL;
eusdebugIF1924:
	goto eusdebugIF1922;
eusdebugIF1921:
	local[7]= NIL;
eusdebugIF1922:
	goto eusdebugWHL1918;
eusdebugWHX1919:
	local[7]= NIL;
eusdebugBLK1920:
	w = NIL;
	local[2]= w;
	goto eusdebugCON1916;
eusdebugCON1917:
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugWHL1926:
	if (local[3]==NIL) goto eusdebugWHX1927;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= NIL;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)FINDPACKAGE(ctx,1,local+5); /*find-package*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= *(ovafptr(local[5],fqv[26]));
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
eusdebugWHL1929:
	local[9]= local[6];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto eusdebugWHX1930;
	local[9]= local[7];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[4] = w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[6] = w;
	w = local[4];
	if (!issymbol(w)) goto eusdebugIF1932;
	local[9]= argv[0];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,1,local+10,&ftab[3],fqv[25]); /*string*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,2,local+9,&ftab[4],fqv[27]); /*substringp*/
	if (w==NIL) goto eusdebugIF1934;
	local[9]= local[4];
	w = local[1];
	ctx->vsp=local+10;
	w=eusdebugFLET1915(ctx,1,local+9,w);
	local[9]= w;
	goto eusdebugIF1935;
eusdebugIF1934:
	local[9]= NIL;
eusdebugIF1935:
	goto eusdebugIF1933;
eusdebugIF1932:
	local[9]= NIL;
eusdebugIF1933:
	goto eusdebugWHL1929;
eusdebugWHX1930:
	local[9]= NIL;
eusdebugBLK1931:
	w = NIL;
	goto eusdebugWHL1926;
eusdebugWHX1927:
	local[4]= NIL;
eusdebugBLK1928:
	w = NIL;
	local[2]= w;
	goto eusdebugCON1916;
eusdebugCON1925:
	local[2]= NIL;
eusdebugCON1916:
	w = NIL;
	local[0]= w;
eusdebugBLK1912:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugFLET1915(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= T;
	local[1]= fqv[28];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)FBOUNDP(ctx,1,local+3); /*fboundp*/
	if (w==NIL) goto eusdebugIF1936;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[5])(ctx,1,local+3,&ftab[5],fqv[29]); /*special-form-p*/
	if (w==NIL) goto eusdebugIF1938;
	local[3]= fqv[30];
	goto eusdebugIF1939;
eusdebugIF1938:
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,1,local+3,&ftab[6],fqv[31]); /*macro-function*/
	if (w==NIL) goto eusdebugIF1940;
	local[3]= fqv[32];
	goto eusdebugIF1941;
eusdebugIF1940:
	local[3]= fqv[33];
eusdebugIF1941:
eusdebugIF1939:
	goto eusdebugIF1937;
eusdebugIF1936:
	local[3]= fqv[34];
eusdebugIF1937:
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)BOUNDP(ctx,1,local+4); /*boundp*/
	if (w==NIL) goto eusdebugIF1942;
	local[4]= argv[0];
	local[5]= fqv[35];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[4];
	if (fqv[36]!=local[5]) goto eusdebugIF1944;
	local[5]= fqv[37];
	goto eusdebugIF1945;
eusdebugIF1944:
	local[5]= local[4];
	if (fqv[38]!=local[5]) goto eusdebugIF1946;
	local[5]= fqv[39];
	goto eusdebugIF1947;
eusdebugIF1946:
	local[5]= local[4];
	if (fqv[40]!=local[5]) goto eusdebugIF1948;
	local[5]= fqv[41];
	goto eusdebugIF1949;
eusdebugIF1948:
	if (T==NIL) goto eusdebugIF1950;
	local[5]= fqv[42];
	goto eusdebugIF1951;
eusdebugIF1950:
	local[5]= NIL;
eusdebugIF1951:
eusdebugIF1949:
eusdebugIF1947:
eusdebugIF1945:
	w = local[5];
	local[4]= w;
	goto eusdebugIF1943;
eusdebugIF1942:
	local[4]= fqv[43];
eusdebugIF1943:
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)BOUNDP(ctx,1,local+5); /*boundp*/
	if (w==NIL) goto eusdebugIF1952;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)SYMBNDVALUE(ctx,1,local+5); /*symbol-bound-value*/
	local[5]= w;
	goto eusdebugIF1953;
eusdebugIF1952:
	local[5]= fqv[44];
eusdebugIF1953:
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,6,local+0); /*format*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*apropos-list*/
static pointer eusdebugF1840apropos_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT1956;}
	local[0]= NIL;
eusdebugENT1956:
eusdebugENT1955:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[25]); /*string*/
	argv[0] = w;
	if (local[0]==NIL) goto eusdebugCON1958;
	local[2]= NIL;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)FINDPACKAGE(ctx,1,local+3); /*find-package*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= *(ovafptr(local[3],fqv[26]));
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
eusdebugWHL1959:
	local[7]= local[4];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w==NIL) goto eusdebugWHX1960;
	local[7]= local[5];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[2] = w;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[4] = w;
	w = local[2];
	if (!issymbol(w)) goto eusdebugIF1962;
	local[7]= argv[0];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(*ftab[3])(ctx,1,local+8,&ftab[3],fqv[25]); /*string*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[27]); /*substringp*/
	if (w==NIL) goto eusdebugIF1964;
	local[7]= local[2];
	w = local[1];
	ctx->vsp=local+8;
	local[1] = cons(ctx,local[7],w);
	local[7]= local[1];
	goto eusdebugIF1965;
eusdebugIF1964:
	local[7]= NIL;
eusdebugIF1965:
	goto eusdebugIF1963;
eusdebugIF1962:
	local[7]= NIL;
eusdebugIF1963:
	goto eusdebugWHL1959;
eusdebugWHX1960:
	local[7]= NIL;
eusdebugBLK1961:
	w = NIL;
	local[2]= w;
	goto eusdebugCON1957;
eusdebugCON1958:
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugWHL1967:
	if (local[3]==NIL) goto eusdebugWHX1968;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= NIL;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)FINDPACKAGE(ctx,1,local+5); /*find-package*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= *(ovafptr(local[5],fqv[26]));
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
eusdebugWHL1970:
	local[9]= local[6];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)LESSP(ctx,2,local+9); /*<*/
	if (w==NIL) goto eusdebugWHX1971;
	local[9]= local[7];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[4] = w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[6] = w;
	w = local[4];
	if (!issymbol(w)) goto eusdebugIF1973;
	local[9]= argv[0];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,1,local+10,&ftab[3],fqv[25]); /*string*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,2,local+9,&ftab[4],fqv[27]); /*substringp*/
	if (w==NIL) goto eusdebugIF1975;
	local[9]= local[4];
	w = local[1];
	ctx->vsp=local+10;
	local[1] = cons(ctx,local[9],w);
	local[9]= local[1];
	goto eusdebugIF1976;
eusdebugIF1975:
	local[9]= NIL;
eusdebugIF1976:
	goto eusdebugIF1974;
eusdebugIF1973:
	local[9]= NIL;
eusdebugIF1974:
	goto eusdebugWHL1970;
eusdebugWHX1971:
	local[9]= NIL;
eusdebugBLK1972:
	w = NIL;
	goto eusdebugWHL1967;
eusdebugWHX1968:
	local[4]= NIL;
eusdebugBLK1969:
	w = NIL;
	local[2]= w;
	goto eusdebugCON1957;
eusdebugCON1966:
	local[2]= NIL;
eusdebugCON1957:
	w = local[1];
	local[0]= w;
eusdebugBLK1954:
	ctx->vsp=local; return(local[0]);}

/*dump-string*/
static pointer eusdebugF1841dump_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT1981;}
	local[0]= loadglobal(fqv[12]);
eusdebugENT1981:
	if (n>=3) { local[1]=(argv[2]); goto eusdebugENT1980;}
	local[1]= fqv[45];
eusdebugENT1980:
	if (n>=4) { local[2]=(argv[3]); goto eusdebugENT1979;}
	local[2]= makeint((eusinteger_t)16L);
eusdebugENT1979:
eusdebugENT1978:
	if (n>4) maerror();
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	local[5]= NIL;
	local[6]= local[1];
	local[7]= fqv[46];
	local[8]= fqv[47];
	local[9]= (pointer)get_sym_func(fqv[48]);
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,4,local+6,&ftab[7],fqv[49]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.car;
eusdebugWHL1982:
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto eusdebugWHX1983;
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MOD(ctx,2,local+6); /*mod*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w==NIL) goto eusdebugIF1985;
	local[6]= local[0];
	local[7]= fqv[50];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto eusdebugIF1986;
eusdebugIF1985:
	local[6]= NIL;
eusdebugIF1986:
	local[6]= local[5];
	local[7]= local[6];
	if (fqv[51]!=local[7]) goto eusdebugIF1987;
	local[7]= local[0];
	local[8]= fqv[52];
	local[9]= argv[0];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	goto eusdebugIF1988;
eusdebugIF1987:
	local[7]= local[6];
	if (fqv[53]!=local[7]) goto eusdebugIF1989;
	local[7]= local[0];
	local[8]= fqv[54];
	local[9]= makeint((eusinteger_t)65535L);
	local[10]= argv[0];
	local[11]= local[3];
	local[12]= fqv[55];
	ctx->vsp=local+13;
	w=(pointer)PEEK(ctx,3,local+10); /*system:peek*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LOGAND(ctx,2,local+9); /*logand*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	goto eusdebugIF1990;
eusdebugIF1989:
	local[7]= local[6];
	if (fqv[56]!=local[7]) goto eusdebugIF1991;
	local[7]= local[0];
	local[8]= fqv[57];
	local[9]= argv[0];
	local[10]= local[3];
	local[11]= fqv[58];
	ctx->vsp=local+12;
	w=(pointer)PEEK(ctx,3,local+9); /*system:peek*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	goto eusdebugIF1992;
eusdebugIF1991:
	local[7]= NIL;
eusdebugIF1992:
eusdebugIF1990:
eusdebugIF1988:
	w = local[7];
	local[6]= local[3];
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[3] = w;
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MOD(ctx,2,local+6); /*mod*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w==NIL) goto eusdebugIF1993;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)TERPRI(ctx,1,local+6); /*terpri*/
	local[6]= w;
	goto eusdebugIF1994;
eusdebugIF1993:
	local[6]= NIL;
eusdebugIF1994:
	goto eusdebugWHL1982;
eusdebugWHX1983:
	local[6]= NIL;
eusdebugBLK1984:
	w = local[6];
	local[0]= w;
eusdebugBLK1977:
	ctx->vsp=local; return(local[0]);}

/*break*/
static pointer eusdebugF1842break(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT1997;}
	local[0]= NIL;
	local[1]= fqv[59];
	local[2]= loadglobal(fqv[60]);
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
eusdebugENT1997:
eusdebugENT1996:
	if (n>1) maerror();
	local[1]= loadglobal(fqv[60]);
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	w = local[1];
	ctx->vsp=local+2;
	bindspecial(ctx,fqv[60],w);
	{jmp_buf jb;
	w = loadglobal(fqv[60]);
	ctx->vsp=local+5;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto eusdebugCAT1998;}
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(*ftab[0])(ctx,1,local+11,&ftab[0],fqv[6]); /*reploop*/
eusdebugCAT1998:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[5]= w;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
eusdebugBLK1995:
	ctx->vsp=local; return(local[0]);}

/*setbreak*/
static pointer eusdebugF1843setbreak(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	if (w!=NIL) goto eusdebugIF2000;
	local[0]= fqv[61];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto eusdebugIF2001;
eusdebugIF2000:
	local[0]= NIL;
eusdebugIF2001:
	local[0]= argv[0];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	if (w!=NIL) goto eusdebugIF2002;
	local[0]= argv[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SYMFUNC(ctx,1,local+1); /*symbol-function*/
	local[1]= w;
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= argv[0];
	local[1]= fqv[63];
	local[2]= fqv[64];
	local[3]= fqv[65];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[66];
	local[4]= fqv[67];
	local[5]= fqv[68];
	local[6]= fqv[69];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[69];
	local[8]= fqv[62];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[65];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[70];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)SETFUNC(ctx,2,local+0); /*setfunc*/
	local[0]= argv[0];
	goto eusdebugIF2003;
eusdebugIF2002:
	local[0]= NIL;
eusdebugIF2003:
	w = local[0];
	local[0]= w;
eusdebugBLK1999:
	ctx->vsp=local; return(local[0]);}

/*unbreak*/
static pointer eusdebugF1844unbreak(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[62];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	if (w==NIL) goto eusdebugIF2005;
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SETFUNC(ctx,2,local+0); /*setfunc*/
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= w;
	goto eusdebugIF2006;
eusdebugIF2005:
	local[0]= NIL;
eusdebugIF2006:
	w = local[0];
	local[0]= w;
eusdebugBLK2004:
	ctx->vsp=local; return(local[0]);}

/*timing*/
static pointer eusdebugF2007(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
eusdebugRST2009:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[71];
	local[2]= fqv[72];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[73];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[74];
	local[5]= fqv[75];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[76];
	local[6]= fqv[77];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[78];
	local[7]= fqv[79];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[1];
	local[4]= fqv[80];
	local[5]= fqv[72];
	local[6]= fqv[81];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[82];
	local[6]= fqv[72];
	local[7]= fqv[83];
	local[8]= fqv[72];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	w = local[0];
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[82];
	local[5]= fqv[78];
	local[6]= fqv[75];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[1];
	local[6]= fqv[80];
	local[7]= fqv[73];
	local[8]= fqv[84];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[82];
	local[8]= fqv[73];
	local[9]= fqv[83];
	local[10]= fqv[73];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[82];
	local[7]= fqv[76];
	local[8]= fqv[85];
	local[9]= fqv[75];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[9]= w;
	local[10]= fqv[78];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[3];
	local[8]= fqv[86];
	local[9]= fqv[87];
	local[10]= fqv[88];
	local[11]= fqv[89];
	local[12]= fqv[88];
	local[13]= fqv[90];
	local[14]= fqv[91];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[85];
	local[14]= fqv[78];
	local[15]= fqv[74];
	local[16]= fqv[76];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
eusdebugBLK2008:
	ctx->vsp=local; return(local[0]);}

/*btrace*/
static pointer eusdebugF1845btrace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2012;}
	local[0]= makeint((eusinteger_t)10L);
eusdebugENT2012:
eusdebugENT2011:
	if (n>1) maerror();
	local[1]= (pointer)get_sym_func(fqv[92]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)BKTRACE(ctx,1,local+2); /*system::bktrace*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(pointer)MAPC(ctx,2,local+1); /*mapc*/
	w = T;
	local[0]= w;
eusdebugBLK2010:
	ctx->vsp=local; return(local[0]);}

/*eval-dynamic*/
static pointer eusdebugF1846eval_dynamic(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT2015;}
	ctx->vsp=local+0;
	w=(pointer)LISTBINDINGS(ctx,0,local+0); /*system:list-all-bindings*/
	local[0]= w;
eusdebugENT2015:
eusdebugENT2014:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
eusdebugWHL2016:
	if (local[3]==NIL) goto eusdebugWHX2017;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car!=local[4]) goto eusdebugIF2019;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+4;
	local[0]=w;
	goto eusdebugBLK2013;
	goto eusdebugIF2020;
eusdebugIF2019:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)VECTORP(ctx,1,local+4); /*vectorp*/
	if (w==NIL) goto eusdebugIF2021;
	local[4]= argv[0];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(*ftab[8])(ctx,2,local+4,&ftab[8],fqv[93]); /*position*/
	local[1] = w;
	if (local[1]==NIL) goto eusdebugIF2021;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
	ctx->vsp=local+6;
	w=(pointer)GETCLASS(ctx,1,local+5); /*class*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SLOT(ctx,3,local+4); /*slot*/
	ctx->vsp=local+4;
	local[0]=w;
	goto eusdebugBLK2013;
	goto eusdebugIF2022;
eusdebugIF2021:
	local[4]= NIL;
eusdebugIF2022:
eusdebugIF2020:
	goto eusdebugWHL2016;
eusdebugWHX2017:
	local[4]= NIL;
eusdebugBLK2018:
	w = NIL;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)BOUNDP(ctx,1,local+2); /*boundp*/
	if (w==NIL) goto eusdebugIF2023;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SYMVALUE(ctx,1,local+2); /*symbol-value*/
	local[2]= w;
	goto eusdebugIF2024;
eusdebugIF2023:
	local[2]= fqv[94];
eusdebugIF2024:
	w = local[2];
	local[0]= w;
eusdebugBLK2013:
	ctx->vsp=local; return(local[0]);}

/*step-hook*/
static pointer eusdebugF1847step_hook(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= T;
	local[3]= makeint((eusinteger_t)10L);
	local[4]= makeint((eusinteger_t)5L);
	w = local[4];
	ctx->vsp=local+5;
	bindspecial(ctx,fqv[13],w);
	w = local[3];
	ctx->vsp=local+8;
	bindspecial(ctx,fqv[14],w);
	local[11]= loadglobal(fqv[95]);
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[11]= w;
	storeglobal(fqv[95],w);
	local[11]= loadglobal(fqv[95]);
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,1,local+11,&ftab[9],fqv[96]); /*spaces*/
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)PRINT(ctx,1,local+11); /*print*/
eusdebugWHL2026:
	if (local[2]==NIL) goto eusdebugWHX2027;
	local[11]= T;
	local[12]= fqv[97];
	local[13]= loadglobal(fqv[95]);
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	ctx->vsp=local+11;
	w=(pointer)FINOUT(ctx,0,local+11); /*finish-output*/
	local[11]= loadglobal(fqv[98]);
	w = local[11];
	ctx->vsp=local+12;
	bindspecial(ctx,fqv[99],w);
	ctx->vsp=local+15;
	w=(pointer)READ(ctx,0,local+15); /*read*/
	local[15]= w;
	ctx->vsp=local+16;
	unbindx(ctx,1);
	w = local[15];
	local[0] = w;
	local[11]= local[0];
	local[12]= local[11];
	w = fqv[100];
	if (memq(local[12],w)==NIL) goto eusdebugIF2029;
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(*ftab[1])(ctx,1,local+12,&ftab[1],fqv[15]); /*pprint*/
	local[12]= w;
	goto eusdebugIF2030;
eusdebugIF2029:
	local[12]= local[11];
	w = fqv[101];
	if (memq(local[12],w)==NIL) goto eusdebugIF2031;
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)PRINT(ctx,1,local+12); /*print*/
	local[12]= w;
	goto eusdebugIF2032;
eusdebugIF2031:
	local[12]= local[11];
	w = fqv[102];
	if (memq(local[12],w)==NIL) goto eusdebugIF2033;
	local[12]= argv[0];
	local[13]= argv[1];
	ctx->vsp=local+14;
	w=(pointer)EVAL(ctx,2,local+12); /*eval*/
	local[1] = w;
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)PRINT(ctx,1,local+12); /*print*/
	local[12]= T;
	local[13]= fqv[103];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,3,local+12); /*format*/
	local[2] = NIL;
	local[12]= local[2];
	goto eusdebugIF2034;
eusdebugIF2033:
	local[12]= local[11];
	w = fqv[104];
	if (memq(local[12],w)==NIL) goto eusdebugIF2035;
	local[12]= argv[0];
	local[13]= (pointer)get_sym_func(fqv[66]);
	local[14]= argv[1];
	ctx->vsp=local+15;
	w=(pointer)EVALHOOK(ctx,3,local+12); /*evalhook*/
	local[1] = w;
	local[12]= T;
	local[13]= fqv[105];
	local[14]= argv[0];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)XFORMAT(ctx,4,local+12); /*format*/
	local[2] = NIL;
	local[12]= local[2];
	goto eusdebugIF2036;
eusdebugIF2035:
	local[12]= local[11];
	w = fqv[106];
	if (memq(local[12],w)==NIL) goto eusdebugIF2037;
	local[12]= fqv[107];
	w = fqv[108];
	ctx->vsp=local+13;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto eusdebugIF2038;
eusdebugIF2037:
	local[12]= local[11];
	w = fqv[109];
	if (memq(local[12],w)==NIL) goto eusdebugIF2039;
	local[12]= T;
	local[13]= fqv[110];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	local[12]= T;
	local[13]= fqv[111];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	local[12]= T;
	local[13]= fqv[112];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	local[12]= T;
	local[13]= fqv[113];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	local[12]= T;
	local[13]= fqv[114];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	local[12]= w;
	goto eusdebugIF2040;
eusdebugIF2039:
	local[12]= local[11];
	if (fqv[115]!=local[12]) goto eusdebugIF2041;
	ctx->vsp=local+12;
	w=(pointer)READ(ctx,0,local+12); /*read*/
	local[0] = w;
	w = local[0];
	if (!issymbol(w)) goto eusdebugCON2044;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)eusdebugF1846eval_dynamic(ctx,1,local+12); /*eval-dynamic*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PRINT(ctx,1,local+12); /*print*/
	local[12]= w;
	goto eusdebugCON2043;
eusdebugCON2044:
	{jmp_buf jb;
	w = fqv[116];
	ctx->vsp=local+12;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto eusdebugCAT2046;}
	local[18]= fqv[117];
	w = local[18];
	ctx->vsp=local+19;
	bindspecial(ctx,fqv[118],w);
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)EVAL(ctx,1,local+22); /*eval*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)PRINT(ctx,1,local+22); /*print*/
	local[22]= w;
	ctx->vsp=local+23;
	unbindx(ctx,1);
	w = local[22];
eusdebugCAT2046:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[12]= w;
	goto eusdebugCON2043;
eusdebugCON2045:
	local[12]= NIL;
eusdebugCON2043:
	goto eusdebugIF2042;
eusdebugIF2041:
	if (T==NIL) goto eusdebugIF2047;
	local[12]= T;
	local[13]= fqv[119];
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,2,local+12); /*format*/
	local[12]= w;
	goto eusdebugIF2048;
eusdebugIF2047:
	local[12]= NIL;
eusdebugIF2048:
eusdebugIF2042:
eusdebugIF2040:
eusdebugIF2038:
eusdebugIF2036:
eusdebugIF2034:
eusdebugIF2032:
eusdebugIF2030:
	w = local[12];
	goto eusdebugWHL2026;
eusdebugWHX2027:
	local[11]= NIL;
eusdebugBLK2028:
	local[11]= loadglobal(fqv[95]);
	ctx->vsp=local+12;
	w=(pointer)SUB1(ctx,1,local+11); /*1-*/
	local[11]= w;
	storeglobal(fqv[95],w);
	local[11]= local[1];
	ctx->vsp=local+12;
	unbindx(ctx,2);
	w = local[11];
	local[0]= w;
eusdebugBLK2025:
	ctx->vsp=local; return(local[0]);}

/*step*/
static pointer eusdebugF2049(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[120];
	local[1]= fqv[82];
	local[2]= fqv[95];
	local[3]= fqv[121];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[122];
	local[3]= fqv[69];
	local[4]= fqv[107];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[123];
	local[5]= fqv[69];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[124];
	local[7]= fqv[69];
	local[8]= fqv[66];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
eusdebugBLK2050:
	ctx->vsp=local; return(local[0]);}

/*tracex*/
static pointer eusdebugF1848tracex(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= loadglobal(fqv[95]);
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	w = local[2];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[95],w);
	local[6]= T;
	local[7]= fqv[125];
	local[8]= loadglobal(fqv[95]);
	local[9]= argv[0];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,5,local+6); /*format*/
	local[6]= argv[0];
	local[7]= fqv[126];
	ctx->vsp=local+8;
	w=(pointer)GETPROP(ctx,2,local+6); /*get*/
	local[6]= w;
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,2,local+6); /*apply*/
	local[0] = w;
	local[6]= T;
	local[7]= fqv[127];
	local[8]= loadglobal(fqv[95]);
	local[9]= local[0];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,5,local+6); /*format*/
	local[6]= loadglobal(fqv[95]);
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)EQUAL(ctx,2,local+6); /*equal*/
	local[6]= w;
	if (w==NIL) goto eusdebugAND2052;
	ctx->vsp=local+6;
	w=(pointer)TERPRI(ctx,0,local+6); /*terpri*/
	local[6]= w;
eusdebugAND2052:
	local[6]= local[0];
	ctx->vsp=local+7;
	unbindx(ctx,1);
	w = local[6];
	local[0]= w;
eusdebugBLK2051:
	ctx->vsp=local; return(local[0]);}

/*trace1*/
static pointer eusdebugF1849trace1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SYMFUNC(ctx,1,local+0); /*symbol-function*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[10])(ctx,1,local+1,&ftab[10],fqv[128]); /*functionp*/
	if (w!=NIL) goto eusdebugIF2054;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto eusdebugBLK2053;
	goto eusdebugIF2055;
eusdebugIF2054:
	local[1]= NIL;
eusdebugIF2055:
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[126];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= argv[0];
	local[2]= fqv[63];
	local[3]= fqv[129];
	local[4]= fqv[130];
	local[5]= fqv[69];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[131];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SETFUNC(ctx,2,local+1); /*setfunc*/
	w = argv[0];
	ctx->vsp=local+1;
	local[0]=w;
	goto eusdebugBLK2053;
	w = local[1];
	local[0]= w;
eusdebugBLK2053:
	ctx->vsp=local; return(local[0]);}

/*trace*/
static pointer eusdebugF2056(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
eusdebugRST2058:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[132];
	local[2]= fqv[133];
	local[3]= fqv[69];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[134];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[135];
	local[4]= fqv[48];
	local[5]= fqv[133];
	local[6]= fqv[134];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[136];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[137];
	local[6]= fqv[138];
	local[7]= fqv[133];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[139];
	local[7]= fqv[140];
	local[8]= fqv[133];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[86];
	local[7]= fqv[141];
	local[8]= fqv[133];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[142];
	local[9]= fqv[133];
	local[10]= fqv[134];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
eusdebugBLK2057:
	ctx->vsp=local; return(local[0]);}

/*untrace*/
static pointer eusdebugF2059(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
eusdebugRST2061:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	if (local[0]!=NIL) goto eusdebugIF2062;
	local[0] = loadglobal(fqv[134]);
	local[1]= local[0];
	goto eusdebugIF2063;
eusdebugIF2062:
	local[1]= NIL;
eusdebugIF2063:
	local[1]= fqv[132];
	local[2]= fqv[133];
	local[3]= fqv[69];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[134];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[135];
	local[4]= fqv[48];
	local[5]= fqv[133];
	local[6]= fqv[134];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[143];
	local[6]= fqv[124];
	local[7]= fqv[133];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[68];
	local[8]= fqv[133];
	local[9]= fqv[69];
	local[10]= fqv[126];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[82];
	local[7]= fqv[134];
	local[8]= fqv[144];
	local[9]= fqv[133];
	local[10]= fqv[134];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
eusdebugBLK2060:
	ctx->vsp=local; return(local[0]);}

/*inspect1*/
static pointer eusdebugF1850inspect1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT2066;}
	local[0]= NIL;
eusdebugENT2066:
eusdebugENT2065:
	if (n>2) maerror();
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,eusdebugFLET2067,env,argv,local);
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	w=eusdebugFLET2067(ctx,1,local+2,w);
	local[2]= w;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= *(ovafptr(w,fqv[145]));
	local[4]= NIL;
eusdebugTAG2069:
	if (NIL==NIL) goto eusdebugIF2070;
	w = NIL;
	ctx->vsp=local+5;
	local[2]=w;
	goto eusdebugBLK2068;
	goto eusdebugIF2071;
eusdebugIF2070:
	local[5]= NIL;
eusdebugIF2071:
	w = local[2];
	if (!issymbol(w)) goto eusdebugIF2072;
	local[5]= local[2]->c.obj.iv[4];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeint(local[5]->c.str.chars[i]);}
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)CHUPCASE(ctx,1,local+5); /*char-upcase*/
	local[5]= w;
	goto eusdebugIF2073;
eusdebugIF2072:
	local[5]= local[2];
eusdebugIF2073:
	local[6]= local[5];
	if (fqv[146]!=local[6]) goto eusdebugIF2074;
	local[6]= argv[0];
	local[7]= loadglobal(fqv[147]);
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)eusdebugF1837describe(ctx,4,local+6); /*describe*/
	local[6]= w;
	goto eusdebugIF2075;
eusdebugIF2074:
	local[6]= local[5];
	if (fqv[148]!=local[6]) goto eusdebugIF2076;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,1,local+6,&ftab[1],fqv[15]); /*pprint*/
	local[6]= w;
	goto eusdebugIF2077;
eusdebugIF2076:
	local[6]= local[5];
	if (fqv[149]!=local[6]) goto eusdebugIF2078;
	ctx->vsp=local+6;
	w=(pointer)READ(ctx,0,local+6); /*read*/
	local[2] = w;
	local[6]= loadglobal(fqv[25]);
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[25]); /*string*/
	local[7]= w;
	local[8]= fqv[150];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[3])(ctx,1,local+9,&ftab[3],fqv[25]); /*string*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)CONCATENATE(ctx,4,local+6); /*concatenate*/
	local[4] = w;
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,2,local+6,&ftab[11],fqv[151]); /*find*/
	if (w!=NIL) goto eusdebugOR2082;
	w = local[2];
	if (!isint(w)) goto eusdebugAND2083;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)ARRAYP(ctx,1,local+6); /*arrayp*/
	if (w!=NIL) goto eusdebugOR2084;
	w = argv[0];
	if (iscons(w)) goto eusdebugOR2084;
	goto eusdebugAND2083;
eusdebugOR2084:
	local[6]= local[2];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto eusdebugAND2083;
	goto eusdebugOR2082;
eusdebugAND2083:
	goto eusdebugIF2080;
eusdebugOR2082:
	w = local[2];
	if (!isint(w)) goto eusdebugIF2085;
	local[6]= argv[0];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	goto eusdebugIF2086;
eusdebugIF2085:
	local[6]= argv[0];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)GETCLASS(ctx,1,local+7); /*class*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SLOT(ctx,3,local+6); /*slot*/
	local[6]= w;
eusdebugIF2086:
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)eusdebugF1850inspect1(ctx,2,local+6); /*inspect1*/
	local[6]= w;
	goto eusdebugIF2081;
eusdebugIF2080:
	local[6]= makeint((eusinteger_t)4L);
	local[7]= fqv[152];
	ctx->vsp=local+8;
	w=(pointer)eusdebugF1835warning_message(ctx,2,local+6); /*warning-message*/
	local[6]= w;
eusdebugIF2081:
	goto eusdebugIF2079;
eusdebugIF2078:
	local[6]= local[5];
	if (fqv[153]!=local[6]) goto eusdebugIF2087;
	w = NIL;
	ctx->vsp=local+6;
	local[0]=w;
	goto eusdebugBLK2064;
	goto eusdebugIF2088;
eusdebugIF2087:
	local[6]= local[5];
	if (fqv[154]!=local[6]) goto eusdebugIF2089;
	local[6]= fqv[155];
	w = NIL;
	ctx->vsp=local+7;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	goto eusdebugIF2090;
eusdebugIF2089:
	local[6]= local[5];
	if (fqv[156]!=local[6]) goto eusdebugIF2091;
	ctx->vsp=local+6;
	w=(pointer)READ(ctx,0,local+6); /*read*/
	local[2] = w;
	ctx->vsp=local+6;
	w=(pointer)READ(ctx,0,local+6); /*read*/
	local[4] = w;
	w = local[2];
	if (!isint(w)) goto eusdebugIF2093;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)ARRAYP(ctx,1,local+6); /*arrayp*/
	if (w!=NIL) goto eusdebugOR2095;
	w = argv[0];
	if (iscons(w)) goto eusdebugOR2095;
	goto eusdebugIF2093;
eusdebugOR2095:
	local[6]= local[2];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto eusdebugIF2093;
	local[6]= argv[0];
	local[7]= local[2];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= w;
	goto eusdebugIF2094;
eusdebugIF2093:
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,2,local+6,&ftab[11],fqv[151]); /*find*/
	if (w==NIL) goto eusdebugIF2096;
	local[6]= argv[0];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)GETCLASS(ctx,1,local+7); /*class*/
	local[7]= w;
	local[8]= local[2];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SETSLOT(ctx,4,local+6); /*setslot*/
	local[6]= w;
	goto eusdebugIF2097;
eusdebugIF2096:
	local[6]= NIL;
eusdebugIF2097:
eusdebugIF2094:
	goto eusdebugIF2092;
eusdebugIF2091:
	local[6]= local[5];
	w = fqv[157];
	if (memq(local[6],w)==NIL) goto eusdebugIF2098;
	local[6]= T;
	local[7]= fqv[158];
	ctx->vsp=local+8;
	w=(pointer)XFORMAT(ctx,2,local+6); /*format*/
	local[6]= w;
	goto eusdebugIF2099;
eusdebugIF2098:
	if (T==NIL) goto eusdebugIF2100;
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[11])(ctx,2,local+6,&ftab[11],fqv[151]); /*find*/
	if (w==NIL) goto eusdebugCON2103;
	local[6]= argv[0];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)GETCLASS(ctx,1,local+7); /*class*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SLOT(ctx,3,local+6); /*slot*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)eusdebugF1837describe(ctx,1,local+6); /*describe*/
	local[6]= w;
	goto eusdebugCON2102;
eusdebugCON2103:
	w = local[2];
	if (!isint(w)) goto eusdebugCON2104;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)ARRAYP(ctx,1,local+6); /*arrayp*/
	if (w!=NIL) goto eusdebugOR2105;
	w = argv[0];
	if (iscons(w)) goto eusdebugOR2105;
	goto eusdebugCON2104;
eusdebugOR2105:
	local[6]= local[2];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LESSP(ctx,2,local+6); /*<*/
	if (w==NIL) goto eusdebugCON2104;
	local[6]= argv[0];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PRINT(ctx,1,local+6); /*print*/
	local[6]= w;
	goto eusdebugCON2102;
eusdebugCON2104:
	{jmp_buf jb;
	w = fqv[159];
	ctx->vsp=local+6;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto eusdebugCAT2107;}
	local[12]= fqv[160];
	w = local[12];
	ctx->vsp=local+13;
	bindspecial(ctx,fqv[118],w);
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)EVAL(ctx,1,local+16); /*eval*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)PRINT(ctx,1,local+16); /*print*/
	local[16]= w;
	ctx->vsp=local+17;
	unbindx(ctx,1);
	w = local[16];
eusdebugCAT2107:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[6]= w;
	goto eusdebugCON2102;
eusdebugCON2106:
	local[6]= NIL;
eusdebugCON2102:
	goto eusdebugIF2101;
eusdebugIF2100:
	local[6]= NIL;
eusdebugIF2101:
eusdebugIF2099:
eusdebugIF2092:
eusdebugIF2090:
eusdebugIF2088:
eusdebugIF2079:
eusdebugIF2077:
eusdebugIF2075:
	w = local[6];
	local[5]= local[0];
	w = local[1];
	ctx->vsp=local+6;
	w=eusdebugFLET2067(ctx,1,local+5,w);
	local[2] = w;
	local[4] = NIL;
	ctx->vsp=local+5;
	goto eusdebugTAG2069;
	w = NIL;
	local[2]= w;
eusdebugBLK2068:
	w = local[2];
	local[0]= w;
eusdebugBLK2064:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugFLET2067(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= T;
	local[1]= fqv[161];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= T;
	ctx->vsp=local+1;
	w=(pointer)FINOUT(ctx,1,local+0); /*finish-output*/
	local[0]= loadglobal(fqv[162]);
	local[1]= NIL;
	local[2]= fqv[163];
	ctx->vsp=local+3;
	w=(pointer)READ(ctx,3,local+0); /*read*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*inspect*/
static pointer eusdebugF2108(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[122];
	local[1]= fqv[69];
	local[2]= fqv[155];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[164];
	local[3]= argv[0];
	local[4]= fqv[3];
	local[5]= fqv[136];
	local[6]= fqv[165];
	local[7]= fqv[69];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
eusdebugBLK2109:
	ctx->vsp=local; return(local[0]);}

/*time-func*/
static pointer eusdebugF1851time_func(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[63];
	local[1]= fqv[64];
	local[2]= fqv[65];
	local[3]= fqv[166];
	local[4]= fqv[167];
	local[5]= fqv[168];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[169];
	local[3]= fqv[68];
	local[4]= fqv[69];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[170];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[82];
	local[4]= fqv[167];
	local[5]= fqv[171];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[168];
	local[7]= fqv[172];
	local[8]= fqv[68];
	local[9]= fqv[69];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[173];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[65];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[169];
	local[5]= fqv[68];
	local[6]= fqv[69];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[174];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[85];
	local[7]= fqv[171];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= fqv[167];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[168];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
eusdebugBLK2110:
	ctx->vsp=local; return(local[0]);}

/*time*/
static pointer eusdebugF2111(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT2114;}
	local[0]= NIL;
eusdebugENT2114:
eusdebugENT2113:
	if (n>2) maerror();
	local[1]= fqv[120];
	local[2]= fqv[135];
	local[3]= fqv[68];
	local[4]= fqv[69];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[173];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[175];
	local[5]= fqv[176];
	local[6]= fqv[69];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[69];
	local[8]= fqv[177];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[69];
	local[9]= fqv[178];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[68];
	local[10]= fqv[69];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[170];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[69];
	local[11]= fqv[179];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[69];
	local[12]= fqv[180];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[69];
	local[13]= fqv[181];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[89];
	local[14]= fqv[182];
	local[15]= fqv[68];
	local[16]= fqv[69];
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= fqv[174];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[69];
	local[15]= fqv[183];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[184];
	local[7]= local[0];
	local[8]= fqv[143];
	local[9]= fqv[68];
	local[10]= fqv[69];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[170];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[185];
	local[11]= fqv[68];
	local[12]= fqv[69];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[174];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[186];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[187];
	local[5]= fqv[2];
	local[6]= fqv[138];
	local[7]= fqv[69];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[31];
	local[7]= fqv[69];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[188];
	local[6]= fqv[189];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[86];
	local[6]= fqv[71];
	local[7]= fqv[190];
	local[8]= fqv[124];
	local[9]= fqv[69];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= fqv[143];
	local[9]= fqv[68];
	local[10]= fqv[69];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[170];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[191];
	local[11]= fqv[68];
	local[12]= fqv[69];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[174];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[192];
	local[13]= fqv[68];
	local[14]= fqv[69];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	local[15]= fqv[173];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[190];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[193];
	local[10]= fqv[69];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[194];
	local[12]= fqv[69];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[142];
	local[11]= fqv[69];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[195];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[176];
	local[12]= fqv[69];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[69];
	local[14]= fqv[177];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[69];
	local[15]= fqv[196];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	local[15]= fqv[69];
	local[16]= fqv[197];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
eusdebugBLK2112:
	ctx->vsp=local; return(local[0]);}

/*untime*/
static pointer eusdebugF2115(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[120];
	local[1]= fqv[198];
	local[2]= fqv[68];
	local[3]= fqv[69];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[173];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[82];
	local[4]= fqv[195];
	local[5]= fqv[144];
	local[6]= fqv[69];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[195];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[193];
	local[5]= fqv[69];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[68];
	local[7]= fqv[69];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[173];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[69];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
eusdebugBLK2116:
	ctx->vsp=local; return(local[0]);}

/*list-symbols*/
static pointer eusdebugF1852list_symbols(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[1];
eusdebugWHL2118:
	if (local[2]==NIL) goto eusdebugWHX2119;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)FINDPACKAGE(ctx,1,local+4); /*find-package*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= *(ovafptr(local[4],fqv[26]));
	local[7]= local[6];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
eusdebugWHL2121:
	local[8]= local[5];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto eusdebugWHX2122;
	local[8]= local[6];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[3] = w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[5] = w;
	w = local[3];
	if (!issymbol(w)) goto eusdebugIF2124;
	local[8]= argv[0];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,2,local+8); /*funcall*/
	if (w==NIL) goto eusdebugIF2126;
	local[8]= local[3];
	w = local[0];
	ctx->vsp=local+9;
	local[0] = cons(ctx,local[8],w);
	local[8]= local[0];
	goto eusdebugIF2127;
eusdebugIF2126:
	local[8]= NIL;
eusdebugIF2127:
	goto eusdebugIF2125;
eusdebugIF2124:
	local[8]= NIL;
eusdebugIF2125:
	goto eusdebugWHL2121;
eusdebugWHX2122:
	local[8]= NIL;
eusdebugBLK2123:
	w = NIL;
	goto eusdebugWHL2118;
eusdebugWHX2119:
	local[3]= NIL;
eusdebugBLK2120:
	w = NIL;
	local[1]= local[0];
	local[2]= (pointer)get_sym_func(fqv[199]);
	ctx->vsp=local+3;
	w=(pointer)SORT(ctx,2,local+1); /*sort*/
	local[0]= w;
eusdebugBLK2117:
	ctx->vsp=local; return(local[0]);}

/*functions*/
static pointer eusdebugF1853functions(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2130;}
	local[0]= fqv[200];
eusdebugENT2130:
eusdebugENT2129:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[25]); /*string*/
	local[0] = w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugCLO2131,env,argv,local);
	if (local[1]==NIL) goto eusdebugIF2132;
	local[3]= local[1];
	goto eusdebugIF2133;
eusdebugIF2132:
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugIF2133:
	ctx->vsp=local+4;
	w=(pointer)eusdebugF1852list_symbols(ctx,2,local+2); /*list-symbols*/
	local[0]= w;
eusdebugBLK2128:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2131(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2134;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[27]); /*substringp*/
	local[0]= w;
eusdebugAND2134:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*special-variables*/
static pointer eusdebugF1854special_variables(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2137;}
	local[0]= fqv[201];
eusdebugENT2137:
eusdebugENT2136:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[25]); /*string*/
	local[0] = w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugCLO2138,env,argv,local);
	if (local[1]==NIL) goto eusdebugIF2139;
	local[3]= local[1];
	goto eusdebugIF2140;
eusdebugIF2139:
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugIF2140:
	ctx->vsp=local+4;
	w=(pointer)eusdebugF1852list_symbols(ctx,2,local+2); /*list-symbols*/
	local[0]= w;
eusdebugBLK2135:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2138(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2141;
	local[0]= argv[0];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)3L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2141;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[27]); /*substringp*/
	local[0]= w;
eusdebugAND2141:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*global-variables*/
static pointer eusdebugF1855global_variables(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2144;}
	local[0]= fqv[202];
eusdebugENT2144:
eusdebugENT2143:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[25]); /*string*/
	local[0] = w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugCLO2145,env,argv,local);
	if (local[1]==NIL) goto eusdebugIF2146;
	local[3]= local[1];
	goto eusdebugIF2147;
eusdebugIF2146:
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugIF2147:
	ctx->vsp=local+4;
	w=(pointer)eusdebugF1852list_symbols(ctx,2,local+2); /*list-symbols*/
	local[0]= w;
eusdebugBLK2142:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2145(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2148;
	local[0]= argv[0];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2148;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[27]); /*substringp*/
	local[0]= w;
eusdebugAND2148:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*variables*/
static pointer eusdebugF1856variables(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2151;}
	local[0]= fqv[203];
eusdebugENT2151:
eusdebugENT2150:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[25]); /*string*/
	local[0] = w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugCLO2152,env,argv,local);
	if (local[1]==NIL) goto eusdebugIF2153;
	local[3]= local[1];
	goto eusdebugIF2154;
eusdebugIF2153:
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugIF2154:
	ctx->vsp=local+4;
	w=(pointer)eusdebugF1852list_symbols(ctx,2,local+2); /*list-symbols*/
	local[0]= w;
eusdebugBLK2149:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2152(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2155;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[12])(ctx,1,local+0,&ftab[12],fqv[204]); /*constantp*/
	local[0]= ((w)==NIL?T:NIL);
	if (local[0]==NIL) goto eusdebugAND2155;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[27]); /*substringp*/
	local[0]= w;
eusdebugAND2155:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*constants*/
static pointer eusdebugF1857constants(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2158;}
	local[0]= fqv[205];
eusdebugENT2158:
eusdebugENT2157:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugCLO2159,env,argv,local);
	if (local[1]==NIL) goto eusdebugIF2160;
	local[3]= local[1];
	goto eusdebugIF2161;
eusdebugIF2160:
	ctx->vsp=local+3;
	w=(pointer)ALLPACKAGES(ctx,0,local+3); /*list-all-packages*/
	local[3]= w;
eusdebugIF2161:
	ctx->vsp=local+4;
	w=(pointer)eusdebugF1852list_symbols(ctx,2,local+2); /*list-symbols*/
	local[0]= w;
eusdebugBLK2156:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2159(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[12])(ctx,1,local+0,&ftab[12],fqv[204]); /*constantp*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2162;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[27]); /*substringp*/
	local[0]= w;
eusdebugAND2162:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*methods*/
static pointer eusdebugF1858methods(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2166;}
	local[0]= fqv[206];
eusdebugENT2166:
	if (n>=2) { local[1]=(argv[1]); goto eusdebugENT2165;}
	local[1]= fqv[207];
	ctx->vsp=local+2;
	w=(pointer)FINDPACKAGE(ctx,1,local+1); /*find-package*/
	local[1]= w;
eusdebugENT2165:
eusdebugENT2164:
	if (n>2) maerror();
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,eusdebugCLO2167,env,argv,local);
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,eusdebugCLO2168,env,argv,local);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)eusdebugF1852list_symbols(ctx,2,local+3); /*list-symbols*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[0]= w;
eusdebugBLK2163:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2167(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[208];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	local[2]= fqv[209];
	ctx->vsp=local+3;
	w=(*ftab[13])(ctx,2,local+1,&ftab[13],fqv[210]); /*send-all*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugCLO2168(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[25]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[27]); /*substringp*/
	local[0]= w;
	if (w==NIL) goto eusdebugAND2169;
	local[0]= argv[0];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
eusdebugAND2169:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*method-list*/
static pointer eusdebugF1859method_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2173;}
	local[0]= T;
eusdebugENT2173:
	if (n>=2) { local[1]=(argv[1]); goto eusdebugENT2172;}
	local[1]= NIL;
eusdebugENT2172:
eusdebugENT2171:
	ctx->vsp=local+2;
	local[2]= minilist(ctx,&argv[n],n-2);
	if (local[2]!=NIL) goto eusdebugIF2174;
	ctx->vsp=local+3;
	w=(pointer)LISTALLCLASSES(ctx,0,local+3); /*system:list-all-classes*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[2] = w;
	local[3]= local[2];
	goto eusdebugIF2175;
eusdebugIF2174:
	local[3]= NIL;
eusdebugIF2175:
	local[3]= NIL;
	local[4]= local[2];
eusdebugWHL2176:
	if (local[4]==NIL) goto eusdebugWHX2177;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[0];
	local[8]= fqv[211];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[14])(ctx,1,local+9,&ftab[14],fqv[212]); /*metaclass-name*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= (pointer)get_sym_func(fqv[213]);
	local[8]= local[3]->c.obj.iv[7];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[6] = w;
	local[7]= NIL;
	local[8]= local[6];
	local[9]= (pointer)get_sym_func(fqv[199]);
	ctx->vsp=local+10;
	w=(pointer)SORT(ctx,2,local+8); /*sort*/
	local[8]= w;
eusdebugWHL2179:
	if (local[8]==NIL) goto eusdebugWHX2180;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8] = (w)->c.cons.cdr;
	w = local[9];
	local[7] = w;
	local[9]= local[3];
	local[10]= local[7];
	local[11]= fqv[214];
	ctx->vsp=local+12;
	w=(*ftab[15])(ctx,2,local+10,&ftab[15],fqv[215]); /*documentation*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[7])(ctx,2,local+9,&ftab[7],fqv[49]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	if (local[5]==NIL) goto eusdebugIF2182;
	local[9]= local[5];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,2,local+9); /*aref*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)40L);
	ctx->vsp=local+11;
	w=(pointer)EQUAL(ctx,2,local+9); /*equal*/
	if (w==NIL) goto eusdebugIF2182;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,1,local+9,&ftab[16],fqv[216]); /*read-from-string*/
	local[5] = w;
	w = local[5];
	if (!iscons(w)) goto eusdebugIF2184;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	if (fqv[217]!=local[9]) goto eusdebugIF2186;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[9];
	local[9]= w;
	goto eusdebugIF2187;
eusdebugIF2186:
	local[9]= NIL;
eusdebugIF2187:
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	if (fqv[218]!=local[9]) goto eusdebugIF2188;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[9];
	local[9]= w;
	goto eusdebugIF2189;
eusdebugIF2188:
	local[9]= NIL;
eusdebugIF2189:
	goto eusdebugIF2185;
eusdebugIF2184:
	local[9]= NIL;
eusdebugIF2185:
	goto eusdebugIF2183;
eusdebugIF2182:
	local[9]= NIL;
eusdebugIF2183:
	local[9]= local[0];
	local[10]= fqv[219];
	local[11]= makeint((eusinteger_t)9L);
	local[12]= local[7];
	if (local[1]==NIL) goto eusdebugIF2190;
	if (local[5]==NIL) goto eusdebugIF2190;
	local[13]= local[5];
	goto eusdebugIF2191;
eusdebugIF2190:
	local[13]= fqv[220];
eusdebugIF2191:
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,5,local+9); /*format*/
	goto eusdebugWHL2179;
eusdebugWHX2180:
	local[9]= NIL;
eusdebugBLK2181:
	w = NIL;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)TERPRI(ctx,1,local+7); /*terpri*/
	goto eusdebugWHL2176;
eusdebugWHX2177:
	local[5]= NIL;
eusdebugBLK2178:
	w = NIL;
	local[0]= w;
eusdebugBLK2170:
	ctx->vsp=local; return(local[0]);}

/*more*/
static pointer eusdebugF2192(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= fqv[221];
	ctx->vsp=local+2;
	w=(pointer)GETPID(ctx,0,local+2); /*unix:getpid*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	local[1]= NIL;
	local[2]= fqv[222];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	local[2]= fqv[223];
	local[3]= fqv[120];
	local[4]= fqv[224];
	local[5]= fqv[12];
	local[6]= local[0];
	local[7]= fqv[17];
	local[8]= fqv[18];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[225];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[226];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
eusdebugBLK2193:
	ctx->vsp=local; return(local[0]);}

/*y-or-n-p*/
static pointer eusdebugF1860y_or_n_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2196;}
	local[0]= NIL;
eusdebugENT2196:
eusdebugENT2195:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	local[2]= NIL;
	local[3]= NIL;
eusdebugTAG2197:
	if (local[0]==NIL) goto eusdebugIF2198;
	local[4]= (pointer)get_sym_func(fqv[3]);
	local[5]= T;
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,4,local+4); /*apply*/
	local[4]= w;
	goto eusdebugIF2199;
eusdebugIF2198:
	local[4]= NIL;
eusdebugIF2199:
	local[4]= T;
	local[5]= fqv[227];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)READLINE(ctx,1,local+4); /*read-line*/
	local[3] = w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	if (makeint((eusinteger_t)0L)!=local[4]) goto eusdebugIF2200;
	ctx->vsp=local+4;
	goto eusdebugTAG2197;
	goto eusdebugIF2201;
eusdebugIF2200:
	local[4]= NIL;
eusdebugIF2201:
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)CHUPCASE(ctx,1,local+4); /*char-upcase*/
	local[4]= w;
	local[5]= local[4];
	if (fqv[228]!=local[5]) goto eusdebugIF2202;
	w = T;
	ctx->vsp=local+5;
	local[0]=w;
	goto eusdebugBLK2194;
	goto eusdebugIF2203;
eusdebugIF2202:
	local[5]= local[4];
	if (fqv[229]!=local[5]) goto eusdebugIF2204;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto eusdebugBLK2194;
	goto eusdebugIF2205;
eusdebugIF2204:
	if (T==NIL) goto eusdebugIF2206;
	ctx->vsp=local+5;
	goto eusdebugTAG2197;
	goto eusdebugIF2207;
eusdebugIF2206:
	local[5]= NIL;
eusdebugIF2207:
eusdebugIF2205:
eusdebugIF2203:
	w = local[5];
	w = NIL;
	local[0]= w;
eusdebugBLK2194:
	ctx->vsp=local; return(local[0]);}

/*yes-or-no-p*/
static pointer eusdebugF1861yes_or_no_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2210;}
	local[0]= NIL;
eusdebugENT2210:
eusdebugENT2209:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-1);
	local[2]= NIL;
	local[3]= NIL;
eusdebugTAG2211:
	if (local[0]==NIL) goto eusdebugIF2212;
	local[4]= (pointer)get_sym_func(fqv[3]);
	local[5]= T;
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,4,local+4); /*apply*/
	local[4]= w;
	goto eusdebugIF2213;
eusdebugIF2212:
	local[4]= NIL;
eusdebugIF2213:
	local[4]= T;
	local[5]= fqv[230];
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,2,local+4); /*format*/
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)READLINE(ctx,1,local+4); /*read-line*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[17])(ctx,1,local+4,&ftab[17],fqv[231]); /*string-upcase*/
	local[3] = w;
	local[4]= local[3];
	local[5]= fqv[232];
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,2,local+4,&ftab[18],fqv[233]); /*string=*/
	if (w==NIL) goto eusdebugCON2215;
	w = T;
	ctx->vsp=local+4;
	local[0]=w;
	goto eusdebugBLK2208;
	goto eusdebugCON2214;
eusdebugCON2215:
	local[4]= local[3];
	local[5]= fqv[234];
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,2,local+4,&ftab[18],fqv[233]); /*string=*/
	if (w==NIL) goto eusdebugCON2216;
	w = NIL;
	ctx->vsp=local+4;
	local[0]=w;
	goto eusdebugBLK2208;
	goto eusdebugCON2214;
eusdebugCON2216:
	ctx->vsp=local+4;
	goto eusdebugTAG2211;
	goto eusdebugCON2214;
eusdebugCON2217:
	local[4]= NIL;
eusdebugCON2214:
	w = NIL;
	local[0]= w;
eusdebugBLK2208:
	ctx->vsp=local; return(local[0]);}

/*bell*/
static pointer eusdebugF1862bell(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT2220;}
	local[0]= T;
eusdebugENT2220:
eusdebugENT2219:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0];
eusdebugWHL2221:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto eusdebugWHX2222;
	local[3]= local[0];
	local[4]= fqv[235];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,2,local+3); /*format*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto eusdebugWHL2221;
eusdebugWHX2222:
	local[3]= NIL;
eusdebugBLK2223:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)FINOUT(ctx,1,local+1); /*finish-output*/
	local[0]= w;
eusdebugBLK2218:
	ctx->vsp=local; return(local[0]);}

/*:type*/
static pointer eusdebugM2224compiled_code_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= local[0];
	if (fqv[236]!=local[1]) goto eusdebugIF2226;
	local[1]= fqv[237];
	goto eusdebugIF2227;
eusdebugIF2226:
	local[1]= local[0];
	if (fqv[238]!=local[1]) goto eusdebugIF2228;
	local[1]= fqv[239];
	goto eusdebugIF2229;
eusdebugIF2228:
	local[1]= local[0];
	if (fqv[240]!=local[1]) goto eusdebugIF2230;
	local[1]= fqv[241];
	goto eusdebugIF2231;
eusdebugIF2230:
	local[1]= local[0];
	if (fqv[242]!=local[1]) goto eusdebugIF2232;
	local[1]= fqv[243];
	goto eusdebugIF2233;
eusdebugIF2232:
	local[1]= NIL;
eusdebugIF2233:
eusdebugIF2231:
eusdebugIF2229:
eusdebugIF2227:
	w = local[1];
	local[0]= w;
eusdebugBLK2225:
	ctx->vsp=local; return(local[0]);}

/*check-methods*/
static pointer eusdebugF1863check_methods(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	w=(pointer)LISTALLCLASSES(ctx,0,local+0); /*system:list-all-classes*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[244]);
	local[2]= local[0];
	local[3]= fqv[245];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,2,local+2,&ftab[13],fqv[210]); /*send-all*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[246]);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= (pointer)get_sym_func(fqv[213]);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(*ftab[19])(ctx,1,local+4,&ftab[19],fqv[247]); /*remove-duplicates*/
	local[4]= w;
	local[5]= T;
	local[6]= fqv[248];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LENGTH(ctx,1,local+7); /*length*/
	local[7]= w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= (pointer)get_sym_func(fqv[249]);
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(*ftab[20])(ctx,2,local+10,&ftab[20],fqv[250]); /*count-if*/
	local[10]= w;
	local[11]= (pointer)get_sym_func(fqv[249]);
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(*ftab[21])(ctx,2,local+11,&ftab[21],fqv[251]); /*count-if-not*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,7,local+5); /*format*/
	local[0]= w;
eusdebugBLK2234:
	ctx->vsp=local; return(local[0]);}

/*pfuncs*/
static pointer eusdebugF1864pfuncs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto eusdebugENT2238;}
	ctx->vsp=local+0;
	w=(pointer)eusdebugF1853functions(ctx,0,local+0); /*functions*/
	local[0]= w;
eusdebugENT2238:
	if (n>=3) { local[1]=(argv[2]); goto eusdebugENT2237;}
	local[1]= NIL;
eusdebugENT2237:
eusdebugENT2236:
	if (n>3) maerror();
	local[2]= argv[0];
	local[3]= fqv[17];
	local[4]= fqv[18];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,3,local+2,&ftab[2],fqv[23]); /*open*/
	local[2]= w;
	ctx->vsp=local+3;
	w = makeclosure(codevec,quotevec,eusdebugUWP2239,env,argv,local);
	local[3]=(pointer)(ctx->protfp); local[4]=w;
	ctx->protfp=(struct protectframe *)(local+3);
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[0];
eusdebugWHL2240:
	if (local[7]==NIL) goto eusdebugWHX2241;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)SYMFUNC(ctx,1,local+8); /*symbol-function*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[22])(ctx,1,local+8,&ftab[22],fqv[249]); /*compiled-function-p*/
	if (w!=NIL) goto eusdebugOR2245;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,1,local+8,&ftab[6],fqv[31]); /*macro-function*/
	if (w==NIL) goto eusdebugOR2245;
	goto eusdebugIF2243;
eusdebugOR2245:
	local[8]= local[2];
	local[9]= fqv[252];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[23])(ctx,1,local+10,&ftab[23],fqv[253]); /*symbol-name*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[24])(ctx,1,local+10,&ftab[24],fqv[254]); /*string-downcase*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= makeint((eusinteger_t)40L);
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)PRNTSIZE(ctx,1,local+9); /*print-size*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(*ftab[9])(ctx,2,local+8,&ftab[9],fqv[96]); /*spaces*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[25])(ctx,1,local+8,&ftab[25],fqv[255]); /*symbol-package*/
	local[5] = w;
	local[8]= local[2];
	local[9]= fqv[256];
	local[10]= local[5];
	local[11]= fqv[257];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	if (w==NIL) goto eusdebugIF2246;
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[26])(ctx,1,local+10,&ftab[26],fqv[258]); /*package-name*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[24])(ctx,1,local+10,&ftab[24],fqv[254]); /*string-downcase*/
	local[10]= w;
	goto eusdebugIF2247;
eusdebugIF2246:
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[26])(ctx,1,local+10,&ftab[26],fqv[258]); /*package-name*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[17])(ctx,1,local+10,&ftab[17],fqv[231]); /*string-upcase*/
	local[10]= w;
eusdebugIF2247:
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SYMFUNC(ctx,1,local+11); /*symbol-function*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[22])(ctx,1,local+11,&ftab[22],fqv[249]); /*compiled-function-p*/
	if (w==NIL) goto eusdebugIF2248;
	local[11]= fqv[259];
	goto eusdebugIF2249;
eusdebugIF2248:
	local[11]= fqv[260];
eusdebugIF2249:
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(*ftab[6])(ctx,1,local+12,&ftab[6],fqv[31]); /*macro-function*/
	if (w==NIL) goto eusdebugIF2250;
	local[12]= fqv[261];
	goto eusdebugIF2251;
eusdebugIF2250:
	local[12]= fqv[262];
eusdebugIF2251:
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,5,local+8); /*format*/
	if (local[1]==NIL) goto eusdebugIF2252;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[15])(ctx,1,local+8,&ftab[15],fqv[215]); /*documentation*/
	if (w==NIL) goto eusdebugIF2252;
	local[8]= local[2];
	local[9]= fqv[263];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[15])(ctx,1,local+10,&ftab[15],fqv[215]); /*documentation*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	goto eusdebugIF2253;
eusdebugIF2252:
	local[8]= NIL;
eusdebugIF2253:
	goto eusdebugIF2244;
eusdebugIF2243:
	local[8]= NIL;
eusdebugIF2244:
	goto eusdebugWHL2240;
eusdebugWHX2241:
	local[8]= NIL;
eusdebugBLK2242:
	w = NIL;
	ctx->vsp=local+5;
	eusdebugUWP2239(ctx,0,local+5,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
eusdebugBLK2235:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugUWP2239(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[2];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*class-hierarchy*/
static pointer eusdebugF1865class_hierarchy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2258;}
	local[0]= loadglobal(fqv[264]);
eusdebugENT2258:
	if (n>=2) { local[1]=(argv[1]); goto eusdebugENT2257;}
	local[1]= T;
eusdebugENT2257:
	if (n>=3) { local[2]=(argv[2]); goto eusdebugENT2256;}
	local[2]= NIL;
eusdebugENT2256:
eusdebugENT2255:
	if (n>3) maerror();
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,eusdebugFLET2259,env,argv,local);
	local[4]= local[0];
	local[5]= fqv[265];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	w = local[3];
	ctx->vsp=local+6;
	w=eusdebugFLET2259(ctx,2,local+4,w);
	local[0]= w;
eusdebugBLK2254:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer eusdebugFLET2259(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[1]= argv[1];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,2,local+1,&ftab[9],fqv[96]); /*spaces*/
	local[1]= env->c.clo.env2[1];
	local[2]= fqv[266];
	local[3]= local[0];
	local[4]= fqv[209];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[24])(ctx,1,local+3,&ftab[24],fqv[254]); /*string-downcase*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	if (env->c.clo.env2[2]==NIL) goto eusdebugIF2260;
	local[1]= local[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[27])(ctx,1,local+2,&ftab[27],fqv[267]); /*metaclass-vars*/
	local[2]= w;
	local[3]= loadglobal(fqv[67]);
	ctx->vsp=local+4;
	w=(pointer)COERCE(ctx,2,local+2); /*coerce*/
	local[2]= w;
	if (local[1]==NIL) goto eusdebugIF2262;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[27])(ctx,1,local+3,&ftab[27],fqv[267]); /*metaclass-vars*/
	local[3]= w;
	local[4]= loadglobal(fqv[67]);
	ctx->vsp=local+5;
	w=(pointer)COERCE(ctx,2,local+3); /*coerce*/
	local[3]= w;
	goto eusdebugIF2263;
eusdebugIF2262:
	local[3]= NIL;
eusdebugIF2263:
	local[4]= local[2];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[28])(ctx,2,local+4,&ftab[28],fqv[268]); /*set-difference*/
	local[2] = w;
	local[4]= (pointer)get_sym_func(fqv[254]);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[2] = w;
	local[4]= env->c.clo.env2[1];
	local[5]= fqv[269];
	if (local[2]==NIL) goto eusdebugIF2264;
	local[6]= local[2];
	goto eusdebugIF2265;
eusdebugIF2264:
	local[6]= fqv[270];
eusdebugIF2265:
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[1]= w;
	goto eusdebugIF2261;
eusdebugIF2260:
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= w;
eusdebugIF2261:
	w = local[1];
	local[0]= NIL;
	local[1]= argv[0];
eusdebugWHL2266:
	if (local[1]==NIL) goto eusdebugWHX2267;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	local[3]= argv[1];
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	w = env->c.clo.env2[3];
	ctx->vsp=local+4;
	w=eusdebugFLET2259(ctx,2,local+2,w);
	goto eusdebugWHL2266;
eusdebugWHX2267:
	local[2]= NIL;
eusdebugBLK2268:
	w = NIL;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*classdef*/
static pointer eusdebugF1866classdef(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[271];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= fqv[272];
	local[4]= argv[0];
	local[5]= fqv[209];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[271];
	if (local[0]==NIL) goto eusdebugIF2270;
	local[6]= local[0];
	local[7]= fqv[209];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	goto eusdebugIF2271;
eusdebugIF2270:
	local[6]= NIL;
eusdebugIF2271:
	local[7]= fqv[273];
	local[8]= argv[0];
	local[9]= fqv[273];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= loadglobal(fqv[67]);
	ctx->vsp=local+10;
	w=(pointer)COERCE(ctx,2,local+8); /*coerce*/
	local[8]= w;
	if (local[0]==NIL) goto eusdebugIF2272;
	local[9]= local[0];
	local[10]= fqv[273];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	goto eusdebugIF2273;
eusdebugIF2272:
	local[9]= NIL;
eusdebugIF2273:
	local[10]= loadglobal(fqv[67]);
	ctx->vsp=local+11;
	w=(pointer)COERCE(ctx,2,local+9); /*coerce*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,2,local+8,&ftab[28],fqv[268]); /*set-difference*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
eusdebugBLK2269:
	ctx->vsp=local; return(local[0]);}

/*classdefs*/
static pointer eusdebugF1867classdefs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2277;}
	local[0]= loadglobal(fqv[264]);
eusdebugENT2277:
	if (n>=2) { local[1]=(argv[1]); goto eusdebugENT2276;}
	local[1]= T;
eusdebugENT2276:
eusdebugENT2275:
	if (n>2) maerror();
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)eusdebugF1866classdef(ctx,1,local+2); /*classdef*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,2,local+2,&ftab[1],fqv[15]); /*pprint*/
	local[2]= NIL;
	local[3]= local[0];
	local[4]= fqv[274];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
eusdebugWHL2278:
	if (local[3]==NIL) goto eusdebugWHX2279;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)eusdebugF1867classdefs(ctx,2,local+4); /*classdefs*/
	goto eusdebugWHL2278;
eusdebugWHX2279:
	local[4]= NIL;
eusdebugBLK2280:
	w = NIL;
	local[0]= w;
eusdebugBLK2274:
	ctx->vsp=local; return(local[0]);}

/*remote-error*/
static pointer eusdebugF1868remote_error(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto eusdebugENT2283;}
	local[0]= NIL;
eusdebugENT2283:
eusdebugENT2282:
	if (n>4) maerror();
	local[1]= loadglobal(fqv[4]);
	local[2]= fqv[275];
	local[3]= loadglobal(fqv[276]);
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,4,local+1); /*format*/
	if (local[0]==NIL) goto eusdebugIF2284;
	local[1]= loadglobal(fqv[4]);
	local[2]= fqv[277];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto eusdebugIF2285;
eusdebugIF2284:
	local[1]= NIL;
eusdebugIF2285:
	if (argv[2]==NIL) goto eusdebugIF2286;
	local[1]= loadglobal(fqv[4]);
	local[2]= fqv[278];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	goto eusdebugIF2287;
eusdebugIF2286:
	local[1]= NIL;
eusdebugIF2287:
	local[1]= loadglobal(fqv[4]);
	ctx->vsp=local+2;
	w=(pointer)TERPRI(ctx,1,local+1); /*terpri*/
	local[1]= fqv[279];
	w = NIL;
	ctx->vsp=local+2;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[1];
	local[0]= w;
eusdebugBLK2281:
	ctx->vsp=local; return(local[0]);}

/*reval*/
static pointer eusdebugF1869reval(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[280];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	w = local[0];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[162],w);
	local[3]= argv[0];
	local[4]= fqv[281];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	w = local[3];
	ctx->vsp=local+3;
	bindspecial(ctx,fqv[12],w);
	local[6]= loadglobal(fqv[12]);
	w = local[6];
	ctx->vsp=local+6;
	bindspecial(ctx,fqv[4],w);
	local[9]= fqv[282];
	w = local[9];
	ctx->vsp=local+9;
	bindspecial(ctx,fqv[118],w);
	{jmp_buf jb;
	w = fqv[279];
	ctx->vsp=local+12;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto eusdebugCAT2289;}
	local[18]= argv[0];
	ctx->vsp=local+19;
	w=(pointer)READ(ctx,1,local+18); /*read*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)EVAL(ctx,1,local+18); /*eval*/
	local[18]= w;
	local[19]= argv[0];
	ctx->vsp=local+20;
	w=(pointer)PRINT(ctx,2,local+18); /*print*/
eusdebugCAT2289:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[12]= w;
	ctx->vsp=local+13;
	unbindx(ctx,4);
	w = local[12];
	local[0]= w;
eusdebugBLK2288:
	ctx->vsp=local; return(local[0]);}

/*install-remote-function*/
static pointer eusdebugF1870install_remote_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= T;
	local[1]= fqv[283];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= T;
	local[1]= fqv[284];
	local[2]= loadglobal(fqv[285]);
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[29])(ctx,1,local+0,&ftab[29],fqv[286]); /*make-server-socket-stream*/
	local[0]= w;
	local[1]= local[0];
	w = loadglobal(fqv[287]);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	storeglobal(fqv[287],local[1]);
	local[1]= local[0];
	local[2]= loadglobal(fqv[288]);
	local[3]= fqv[47];
	local[4]= NIL;
	local[5]= fqv[289];
	local[6]= NIL;
	local[7]= fqv[290];
	local[8]= NIL;
	ctx->vsp=local+9;
	w=(*ftab[30])(ctx,8,local+1,&ftab[30],fqv[48]); /*member*/
	if (w!=NIL) goto eusdebugIF2291;
	local[1]= local[0];
	w = loadglobal(fqv[288]);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	storeglobal(fqv[288],local[1]);
	goto eusdebugIF2292;
eusdebugIF2291:
	local[1]= NIL;
eusdebugIF2292:
	local[1]= makeint((eusinteger_t)29L);
	local[2]= fqv[291];
	ctx->vsp=local+3;
	w=(pointer)SIGNAL(ctx,2,local+1); /*unix:signal*/
	w = local[0];
	if (!isint(w)) goto eusdebugIF2293;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)3L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)FCNTL(ctx,3,local+3); /*unix:fcntl*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)8192L);
	ctx->vsp=local+5;
	w=(pointer)LOGIOR(ctx,2,local+3); /*logior*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FCNTL(ctx,3,local+1); /*unix:fcntl*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)8L);
	ctx->vsp=local+3;
	w=(pointer)GETPID(ctx,0,local+3); /*unix:getpid*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FCNTL(ctx,3,local+1); /*unix:fcntl*/
	local[1]= w;
	goto eusdebugIF2294;
eusdebugIF2293:
	local[1]= local[0];
	local[2]= fqv[292];
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
eusdebugIF2294:
	local[1]= loadglobal(fqv[293]);
	w = local[0];
	if (!isint(w)) goto eusdebugIF2295;
	local[2]= local[0];
	goto eusdebugIF2296;
eusdebugIF2295:
	local[2]= local[0];
	local[3]= fqv[294];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
eusdebugIF2296:
	local[3]= loadglobal(fqv[285]);
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[0]= w;
eusdebugBLK2290:
	ctx->vsp=local; return(local[0]);}

/*open-server*/
static pointer eusdebugF1871open_server(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto eusdebugENT2300;}
	local[0]= makeint((eusinteger_t)2048L);
eusdebugENT2300:
	if (n>=2) { local[1]=(argv[1]); goto eusdebugENT2299;}
	local[1]= (pointer)get_sym_func(fqv[279]);
eusdebugENT2299:
eusdebugENT2298:
	if (n>2) maerror();
	local[2]= fqv[295];
	local[3]= makeint((eusinteger_t)2L);
	local[4]= fqv[296];
	ctx->vsp=local+5;
	w=(pointer)GETHOSTNAME(ctx,0,local+5); /*unix:gethostname*/
	local[5]= w;
	local[6]= fqv[297];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[31])(ctx,6,local+2,&ftab[31],fqv[298]); /*make-socket-address*/
	local[2]= w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[32])(ctx,1,local+3,&ftab[32],fqv[299]); /*make-socket-port*/
	local[3]= w;
	storeglobal(fqv[300],w);
	local[3]= loadglobal(fqv[300]);
	local[4]= loadglobal(fqv[301]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto eusdebugCON2302;
	local[3]= fqv[302];
	ctx->vsp=local+4;
	w=(pointer)GETHOSTNAME(ctx,0,local+4); /*unix:gethostname*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)eusdebugF1836warn(ctx,3,local+3); /*warn*/
	local[3]= w;
	goto eusdebugCON2301;
eusdebugCON2302:
	local[3]= loadglobal(fqv[300]);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SYSERRLIST(ctx,1,local+3); /*unix:syserrlist*/
	ctx->vsp=local+3;
	local[0]=w;
	goto eusdebugBLK2297;
	goto eusdebugCON2301;
eusdebugCON2303:
	local[3]= NIL;
eusdebugCON2301:
	local[3]= local[1];
	storeglobal(fqv[285],local[3]);
	local[3]= loadglobal(fqv[300]);
	local[4]= loadglobal(fqv[288]);
	local[5]= fqv[47];
	local[6]= NIL;
	local[7]= fqv[289];
	local[8]= NIL;
	local[9]= fqv[290];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(*ftab[30])(ctx,8,local+3,&ftab[30],fqv[48]); /*member*/
	if (w!=NIL) goto eusdebugIF2304;
	local[3]= loadglobal(fqv[300]);
	w = loadglobal(fqv[288]);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	storeglobal(fqv[288],local[3]);
	goto eusdebugIF2305;
eusdebugIF2304:
	local[3]= NIL;
eusdebugIF2305:
	local[3]= makeint((eusinteger_t)29L);
	local[4]= fqv[291];
	ctx->vsp=local+5;
	w=(pointer)SIGNAL(ctx,2,local+3); /*unix:signal*/
	w = loadglobal(fqv[300]);
	if (!isint(w)) goto eusdebugIF2306;
	local[3]= loadglobal(fqv[300]);
	local[4]= makeint((eusinteger_t)4L);
	local[5]= loadglobal(fqv[300]);
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)FCNTL(ctx,3,local+5); /*unix:fcntl*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)8192L);
	ctx->vsp=local+7;
	w=(pointer)LOGIOR(ctx,2,local+5); /*logior*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)FCNTL(ctx,3,local+3); /*unix:fcntl*/
	local[3]= loadglobal(fqv[300]);
	local[4]= makeint((eusinteger_t)8L);
	ctx->vsp=local+5;
	w=(pointer)GETPID(ctx,0,local+5); /*unix:getpid*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)FCNTL(ctx,3,local+3); /*unix:fcntl*/
	local[3]= w;
	goto eusdebugIF2307;
eusdebugIF2306:
	local[3]= loadglobal(fqv[300]);
	local[4]= fqv[292];
	local[5]= T;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
eusdebugIF2307:
	local[3]= loadglobal(fqv[293]);
	w = loadglobal(fqv[300]);
	if (!isint(w)) goto eusdebugIF2308;
	local[4]= loadglobal(fqv[300]);
	goto eusdebugIF2309;
eusdebugIF2308:
	local[4]= loadglobal(fqv[300]);
	local[5]= fqv[294];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
eusdebugIF2309:
	local[5]= fqv[303];
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[0]= w;
eusdebugBLK2297:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___eusdebug(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[304];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto eusdebugIF2310;
	local[0]= fqv[305];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[99],w);
	goto eusdebugIF2311;
eusdebugIF2310:
	local[0]= fqv[306];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
eusdebugIF2311:
	local[0]= fqv[307];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compmacro(ctx,fqv[308],module,eusdebugF1872,fqv[309]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[310],module,eusdebugF1835warning_message,fqv[311]);
	local[0]= fqv[10];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eusdebugIF2312;
	local[0]= fqv[10];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[10];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eusdebugIF2314;
	local[0]= fqv[10];
	local[1]= fqv[312];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eusdebugIF2315;
eusdebugIF2314:
	local[0]= NIL;
eusdebugIF2315:
	local[0]= fqv[10];
	goto eusdebugIF2313;
eusdebugIF2312:
	local[0]= NIL;
eusdebugIF2313:
	ctx->vsp=local+0;
	compfun(ctx,fqv[139],module,eusdebugF1836warn,fqv[313]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[314],module,eusdebugF1837describe,fqv[315]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[316],module,eusdebugF1838describe_list,fqv[317]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[318],module,eusdebugF1839apropos,fqv[319]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[320],module,eusdebugF1840apropos_list,fqv[321]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[322],module,eusdebugF1841dump_string,fqv[323]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[324],module,eusdebugF1842break,fqv[325]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[326],module,eusdebugF1843setbreak,fqv[327]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[328],module,eusdebugF1844unbreak,fqv[329]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[330],module,eusdebugF2007,fqv[331]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[332],module,eusdebugF1845btrace,fqv[333]);
	local[0]= fqv[95];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eusdebugIF2316;
	local[0]= fqv[95];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[95];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eusdebugIF2318;
	local[0]= fqv[95];
	local[1]= fqv[312];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eusdebugIF2319;
eusdebugIF2318:
	local[0]= NIL;
eusdebugIF2319:
	local[0]= fqv[95];
	goto eusdebugIF2317;
eusdebugIF2316:
	local[0]= NIL;
eusdebugIF2317:
	ctx->vsp=local+0;
	compfun(ctx,fqv[334],module,eusdebugF1846eval_dynamic,fqv[335]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[66],module,eusdebugF1847step_hook,fqv[336]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[337],module,eusdebugF2049,fqv[338]);
	local[0]= fqv[134];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eusdebugIF2320;
	local[0]= fqv[134];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[134];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eusdebugIF2322;
	local[0]= fqv[134];
	local[1]= fqv[312];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eusdebugIF2323;
eusdebugIF2322:
	local[0]= NIL;
eusdebugIF2323:
	local[0]= fqv[134];
	goto eusdebugIF2321;
eusdebugIF2320:
	local[0]= NIL;
eusdebugIF2321:
	ctx->vsp=local+0;
	compfun(ctx,fqv[130],module,eusdebugF1848tracex,fqv[339]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[141],module,eusdebugF1849trace1,fqv[340]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[341],module,eusdebugF2056,fqv[342]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[343],module,eusdebugF2059,fqv[344]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[164],module,eusdebugF1850inspect1,fqv[345]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[155],module,eusdebugF2108,fqv[346]);
	local[0]= fqv[195];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eusdebugIF2324;
	local[0]= fqv[195];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[195];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eusdebugIF2326;
	local[0]= fqv[195];
	local[1]= fqv[312];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eusdebugIF2327;
eusdebugIF2326:
	local[0]= NIL;
eusdebugIF2327:
	local[0]= fqv[195];
	goto eusdebugIF2325;
eusdebugIF2324:
	local[0]= NIL;
eusdebugIF2325:
	ctx->vsp=local+0;
	compfun(ctx,fqv[194],module,eusdebugF1851time_func,fqv[347]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[348],module,eusdebugF2111,fqv[349]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[350],module,eusdebugF2115,fqv[351]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[352],module,eusdebugF1852list_symbols,fqv[353]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[354],module,eusdebugF1853functions,fqv[355]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[356],module,eusdebugF1854special_variables,fqv[357]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[358],module,eusdebugF1855global_variables,fqv[359]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[360],module,eusdebugF1856variables,fqv[361]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[362],module,eusdebugF1857constants,fqv[363]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[364],module,eusdebugF1858methods,fqv[365]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[366],module,eusdebugF1859method_list,fqv[367]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[368],module,eusdebugF2192,fqv[369]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[370],module,eusdebugF1860y_or_n_p,fqv[371]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[372],module,eusdebugF1861yes_or_no_p,fqv[373]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[374],module,eusdebugF1862bell,fqv[375]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,eusdebugM2224compiled_code_type,fqv[376],fqv[377],fqv[378]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[379],module,eusdebugF1863check_methods,fqv[380]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[381],module,eusdebugF1864pfuncs,fqv[382]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[383],module,eusdebugF1865class_hierarchy,fqv[384]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[385],module,eusdebugF1866classdef,fqv[386]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[387],module,eusdebugF1867classdefs,fqv[388]);
	local[0]= fqv[300];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eusdebugIF2328;
	local[0]= fqv[300];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[300];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eusdebugIF2330;
	local[0]= fqv[300];
	local[1]= fqv[312];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eusdebugIF2331;
eusdebugIF2330:
	local[0]= NIL;
eusdebugIF2331:
	local[0]= fqv[300];
	goto eusdebugIF2329;
eusdebugIF2328:
	local[0]= NIL;
eusdebugIF2329:
	ctx->vsp=local+0;
	compfun(ctx,fqv[282],module,eusdebugF1868remote_error,fqv[389]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[279],module,eusdebugF1869reval,fqv[390]);
	local[0]= fqv[287];
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto eusdebugIF2332;
	local[0]= fqv[287];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[287];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto eusdebugIF2334;
	local[0]= fqv[287];
	local[1]= fqv[312];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto eusdebugIF2335;
eusdebugIF2334:
	local[0]= NIL;
eusdebugIF2335:
	local[0]= fqv[287];
	goto eusdebugIF2333;
eusdebugIF2332:
	local[0]= NIL;
eusdebugIF2333:
	ctx->vsp=local+0;
	compfun(ctx,fqv[303],module,eusdebugF1870install_remote_function,fqv[391]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[392],module,eusdebugF1871open_server,fqv[393]);
	local[0]= fqv[394];
	local[1]= fqv[395];
	ctx->vsp=local+2;
	w=(*ftab[33])(ctx,2,local+0,&ftab[33],fqv[396]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<34; i++) ftab[i]=fcallx;
}
