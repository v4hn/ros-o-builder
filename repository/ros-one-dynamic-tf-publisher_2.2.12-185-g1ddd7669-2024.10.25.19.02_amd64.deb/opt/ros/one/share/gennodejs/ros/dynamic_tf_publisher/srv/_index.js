
"use strict";

let DeleteTF = require('./DeleteTF.js')
let DissocTF = require('./DissocTF.js')
let AssocTF = require('./AssocTF.js')
let SetDynamicTF = require('./SetDynamicTF.js')

module.exports = {
  DeleteTF: DeleteTF,
  DissocTF: DissocTF,
  AssocTF: AssocTF,
  SetDynamicTF: SetDynamicTF,
};
