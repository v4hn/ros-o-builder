
"use strict";

let GetPointMapROI = require('./GetPointMapROI.js')
let GetPointMap = require('./GetPointMap.js')
let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetMapROI = require('./GetMapROI.js')
let SaveMap = require('./SaveMap.js')
let SetMapProjections = require('./SetMapProjections.js')

module.exports = {
  GetPointMapROI: GetPointMapROI,
  GetPointMap: GetPointMap,
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetMapROI: GetMapROI,
  SaveMap: SaveMap,
  SetMapProjections: SetMapProjections,
};
