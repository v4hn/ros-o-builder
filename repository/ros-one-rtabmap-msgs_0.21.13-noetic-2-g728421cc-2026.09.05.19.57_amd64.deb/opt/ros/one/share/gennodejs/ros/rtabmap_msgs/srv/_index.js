
"use strict";

let GetMap2 = require('./GetMap2.js')
let SetLabel = require('./SetLabel.js')
let ResetPose = require('./ResetPose.js')
let CleanupLocalGrids = require('./CleanupLocalGrids.js')
let GlobalBundleAdjustment = require('./GlobalBundleAdjustment.js')
let GetMap = require('./GetMap.js')
let RemoveLabel = require('./RemoveLabel.js')
let GetNodesInRadius = require('./GetNodesInRadius.js')
let PublishMap = require('./PublishMap.js')
let AddLink = require('./AddLink.js')
let GetNodeData = require('./GetNodeData.js')
let GetPlan = require('./GetPlan.js')
let SetGoal = require('./SetGoal.js')
let ListLabels = require('./ListLabels.js')
let DetectMoreLoopClosures = require('./DetectMoreLoopClosures.js')
let LoadDatabase = require('./LoadDatabase.js')

module.exports = {
  GetMap2: GetMap2,
  SetLabel: SetLabel,
  ResetPose: ResetPose,
  CleanupLocalGrids: CleanupLocalGrids,
  GlobalBundleAdjustment: GlobalBundleAdjustment,
  GetMap: GetMap,
  RemoveLabel: RemoveLabel,
  GetNodesInRadius: GetNodesInRadius,
  PublishMap: PublishMap,
  AddLink: AddLink,
  GetNodeData: GetNodeData,
  GetPlan: GetPlan,
  SetGoal: SetGoal,
  ListLabels: ListLabels,
  DetectMoreLoopClosures: DetectMoreLoopClosures,
  LoadDatabase: LoadDatabase,
};
