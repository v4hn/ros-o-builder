; Auto-generated. Do not edit!


(cl:in-package robot_body_filter-msg)


;//! \htmlinclude OrientedBoundingBox.msg.html

(cl:defclass <OrientedBoundingBox> (roslisp-msg-protocol:ros-message)
  ((extents
    :reader extents
    :initarg :extents
    :type geometry_msgs-msg:Vector3
    :initform (cl:make-instance 'geometry_msgs-msg:Vector3))
   (pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Transform
    :initform (cl:make-instance 'geometry_msgs-msg:Transform)))
)

(cl:defclass OrientedBoundingBox (<OrientedBoundingBox>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <OrientedBoundingBox>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'OrientedBoundingBox)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name robot_body_filter-msg:<OrientedBoundingBox> is deprecated: use robot_body_filter-msg:OrientedBoundingBox instead.")))

(cl:ensure-generic-function 'extents-val :lambda-list '(m))
(cl:defmethod extents-val ((m <OrientedBoundingBox>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:extents-val is deprecated.  Use robot_body_filter-msg:extents instead.")
  (extents m))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <OrientedBoundingBox>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader robot_body_filter-msg:pose-val is deprecated.  Use robot_body_filter-msg:pose instead.")
  (pose m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <OrientedBoundingBox>) ostream)
  "Serializes a message object of type '<OrientedBoundingBox>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'extents) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <OrientedBoundingBox>) istream)
  "Deserializes a message object of type '<OrientedBoundingBox>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'extents) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<OrientedBoundingBox>)))
  "Returns string type for a message object of type '<OrientedBoundingBox>"
  "robot_body_filter/OrientedBoundingBox")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'OrientedBoundingBox)))
  "Returns string type for a message object of type 'OrientedBoundingBox"
  "robot_body_filter/OrientedBoundingBox")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<OrientedBoundingBox>)))
  "Returns md5sum for a message object of type '<OrientedBoundingBox>"
  "23fbcbbbf48653ccd6241e4b01144f36")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'OrientedBoundingBox)))
  "Returns md5sum for a message object of type 'OrientedBoundingBox"
  "23fbcbbbf48653ccd6241e4b01144f36")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<OrientedBoundingBox>)))
  "Returns full string definition for message of type '<OrientedBoundingBox>"
  (cl:format cl:nil "geometry_msgs/Vector3 extents~%geometry_msgs/Transform pose~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'OrientedBoundingBox)))
  "Returns full string definition for message of type 'OrientedBoundingBox"
  (cl:format cl:nil "geometry_msgs/Vector3 extents~%geometry_msgs/Transform pose~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <OrientedBoundingBox>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'extents))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <OrientedBoundingBox>))
  "Converts a ROS message object to a list"
  (cl:list 'OrientedBoundingBox
    (cl:cons ':extents (extents msg))
    (cl:cons ':pose (pose msg))
))
