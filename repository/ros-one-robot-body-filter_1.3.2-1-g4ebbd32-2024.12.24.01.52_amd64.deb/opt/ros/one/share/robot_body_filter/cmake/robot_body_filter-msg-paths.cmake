# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${robot_body_filter_DIR}/.." "msg" robot_body_filter_MSG_INCLUDE_DIRS UNIQUE)
set(robot_body_filter_MSG_DEPENDENCIES geometry_msgs;std_msgs)
