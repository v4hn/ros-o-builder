; Auto-generated. Do not edit!


(cl:in-package jsk_recognition_msgs-msg)


;//! \htmlinclude VQATaskGoal.msg.html

(cl:defclass <VQATaskGoal> (roslisp-msg-protocol:ros-message)
  ((image
    :reader image
    :initarg :image
    :type sensor_msgs-msg:Image
    :initform (cl:make-instance 'sensor_msgs-msg:Image))
   (compressed_image
    :reader compressed_image
    :initarg :compressed_image
    :type sensor_msgs-msg:CompressedImage
    :initform (cl:make-instance 'sensor_msgs-msg:CompressedImage))
   (questions
    :reader questions
    :initarg :questions
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element "")))
)

(cl:defclass VQATaskGoal (<VQATaskGoal>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <VQATaskGoal>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'VQATaskGoal)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_recognition_msgs-msg:<VQATaskGoal> is deprecated: use jsk_recognition_msgs-msg:VQATaskGoal instead.")))

(cl:ensure-generic-function 'image-val :lambda-list '(m))
(cl:defmethod image-val ((m <VQATaskGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:image-val is deprecated.  Use jsk_recognition_msgs-msg:image instead.")
  (image m))

(cl:ensure-generic-function 'compressed_image-val :lambda-list '(m))
(cl:defmethod compressed_image-val ((m <VQATaskGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:compressed_image-val is deprecated.  Use jsk_recognition_msgs-msg:compressed_image instead.")
  (compressed_image m))

(cl:ensure-generic-function 'questions-val :lambda-list '(m))
(cl:defmethod questions-val ((m <VQATaskGoal>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:questions-val is deprecated.  Use jsk_recognition_msgs-msg:questions instead.")
  (questions m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <VQATaskGoal>) ostream)
  "Serializes a message object of type '<VQATaskGoal>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'image) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'compressed_image) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'questions))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'questions))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <VQATaskGoal>) istream)
  "Deserializes a message object of type '<VQATaskGoal>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'image) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'compressed_image) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'questions) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'questions)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<VQATaskGoal>)))
  "Returns string type for a message object of type '<VQATaskGoal>"
  "jsk_recognition_msgs/VQATaskGoal")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'VQATaskGoal)))
  "Returns string type for a message object of type 'VQATaskGoal"
  "jsk_recognition_msgs/VQATaskGoal")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<VQATaskGoal>)))
  "Returns md5sum for a message object of type '<VQATaskGoal>"
  "6d989868a8332f72b725e727adff21b1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'VQATaskGoal)))
  "Returns md5sum for a message object of type 'VQATaskGoal"
  "6d989868a8332f72b725e727adff21b1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<VQATaskGoal>)))
  "Returns full string definition for message of type '<VQATaskGoal>"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%sensor_msgs/Image image~%sensor_msgs/CompressedImage compressed_image~%string[] questions~%~%================================================================================~%MSG: sensor_msgs/Image~%# This message contains an uncompressed image~%# (0, 0) is at top-left corner of image~%#~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%                     # If the frame_id here and the frame_id of the CameraInfo~%                     # message associated with the image conflict~%                     # the behavior is undefined~%~%uint32 height         # image height, that is, number of rows~%uint32 width          # image width, that is, number of columns~%~%# The legal values for encoding are in file src/image_encodings.cpp~%# If you want to standardize a new string format, join~%# ros-users@lists.sourceforge.net and send an email proposing a new encoding.~%~%string encoding       # Encoding of pixels -- channel meaning, ordering, size~%                      # taken from the list of strings in include/sensor_msgs/image_encodings.h~%~%uint8 is_bigendian    # is this data bigendian?~%uint32 step           # Full row length in bytes~%uint8[] data          # actual matrix data, size is (step * rows)~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: sensor_msgs/CompressedImage~%# This message contains a compressed image~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%~%string format        # Specifies the format of the data~%                     # Acceptable values differ by the image transport used:~%                     # - compressed_image_transport:~%                     #     ORIG_PIXFMT; CODEC compressed [COMPRESSED_PIXFMT]~%                     #   where:~%                     #   - ORIG_PIXFMT is pixel format of the raw image, i.e.~%                     #     the content of sensor_msgs/Image/encoding with~%                     #     values from include/sensor_msgs/image_encodings.h~%                     #   - CODEC is one of [jpeg, png]~%                     #   - COMPRESSED_PIXFMT is only appended for color images~%                     #     and is the pixel format used by the compression~%                     #     algorithm. Valid values for jpeg encoding are:~%                     #     [bgr8, rgb8]. Valid values for png encoding are:~%                     #     [bgr8, rgb8, bgr16, rgb16].~%                     #   If the field is empty or does not correspond to the~%                     #   above pattern, the image is treated as bgr8 or mono8~%                     #   jpeg image (depending on the number of channels).~%                     # - compressed_depth_image_transport:~%                     #     ORIG_PIXFMT; compressedDepth CODEC~%                     #   where:~%                     #   - ORIG_PIXFMT is pixel format of the raw image, i.e.~%                     #     the content of sensor_msgs/Image/encoding with~%                     #     values from include/sensor_msgs/image_encodings.h~%                     #     It is usually one of [16UC1, 32FC1].~%                     #   - CODEC is one of [png, rvl]~%                     #   If the field is empty or does not correspond to the~%                     #   above pattern, the image is treated as png image.~%                     # - Other image transports can store whatever values they~%                     #   need for successful decoding of the image. Refer to~%                     #   documentation of the other transports for details.~%~%uint8[] data         # Compressed image buffer~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'VQATaskGoal)))
  "Returns full string definition for message of type 'VQATaskGoal"
  (cl:format cl:nil "# ====== DO NOT MODIFY! AUTOGENERATED FROM AN ACTION DEFINITION ======~%sensor_msgs/Image image~%sensor_msgs/CompressedImage compressed_image~%string[] questions~%~%================================================================================~%MSG: sensor_msgs/Image~%# This message contains an uncompressed image~%# (0, 0) is at top-left corner of image~%#~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%                     # If the frame_id here and the frame_id of the CameraInfo~%                     # message associated with the image conflict~%                     # the behavior is undefined~%~%uint32 height         # image height, that is, number of rows~%uint32 width          # image width, that is, number of columns~%~%# The legal values for encoding are in file src/image_encodings.cpp~%# If you want to standardize a new string format, join~%# ros-users@lists.sourceforge.net and send an email proposing a new encoding.~%~%string encoding       # Encoding of pixels -- channel meaning, ordering, size~%                      # taken from the list of strings in include/sensor_msgs/image_encodings.h~%~%uint8 is_bigendian    # is this data bigendian?~%uint32 step           # Full row length in bytes~%uint8[] data          # actual matrix data, size is (step * rows)~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: sensor_msgs/CompressedImage~%# This message contains a compressed image~%~%Header header        # Header timestamp should be acquisition time of image~%                     # Header frame_id should be optical frame of camera~%                     # origin of frame should be optical center of camera~%                     # +x should point to the right in the image~%                     # +y should point down in the image~%                     # +z should point into to plane of the image~%~%string format        # Specifies the format of the data~%                     # Acceptable values differ by the image transport used:~%                     # - compressed_image_transport:~%                     #     ORIG_PIXFMT; CODEC compressed [COMPRESSED_PIXFMT]~%                     #   where:~%                     #   - ORIG_PIXFMT is pixel format of the raw image, i.e.~%                     #     the content of sensor_msgs/Image/encoding with~%                     #     values from include/sensor_msgs/image_encodings.h~%                     #   - CODEC is one of [jpeg, png]~%                     #   - COMPRESSED_PIXFMT is only appended for color images~%                     #     and is the pixel format used by the compression~%                     #     algorithm. Valid values for jpeg encoding are:~%                     #     [bgr8, rgb8]. Valid values for png encoding are:~%                     #     [bgr8, rgb8, bgr16, rgb16].~%                     #   If the field is empty or does not correspond to the~%                     #   above pattern, the image is treated as bgr8 or mono8~%                     #   jpeg image (depending on the number of channels).~%                     # - compressed_depth_image_transport:~%                     #     ORIG_PIXFMT; compressedDepth CODEC~%                     #   where:~%                     #   - ORIG_PIXFMT is pixel format of the raw image, i.e.~%                     #     the content of sensor_msgs/Image/encoding with~%                     #     values from include/sensor_msgs/image_encodings.h~%                     #     It is usually one of [16UC1, 32FC1].~%                     #   - CODEC is one of [png, rvl]~%                     #   If the field is empty or does not correspond to the~%                     #   above pattern, the image is treated as png image.~%                     # - Other image transports can store whatever values they~%                     #   need for successful decoding of the image. Refer to~%                     #   documentation of the other transports for details.~%~%uint8[] data         # Compressed image buffer~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <VQATaskGoal>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'image))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'compressed_image))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'questions) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <VQATaskGoal>))
  "Converts a ROS message object to a list"
  (cl:list 'VQATaskGoal
    (cl:cons ':image (image msg))
    (cl:cons ':compressed_image (compressed_image msg))
    (cl:cons ':questions (questions msg))
))
