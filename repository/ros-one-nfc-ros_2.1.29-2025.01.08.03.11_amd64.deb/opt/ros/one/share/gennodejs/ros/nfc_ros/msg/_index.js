
"use strict";

let NDEFRecord = require('./NDEFRecord.js');
let Tag = require('./Tag.js');

module.exports = {
  NDEFRecord: NDEFRecord,
  Tag: Tag,
};
