from ._NDEFRecord import *
from ._Tag import *
