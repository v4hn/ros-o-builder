
"use strict";

let DiscreteQuery = require('./DiscreteQuery.js')
let LinearGaussianParameterEstimation = require('./LinearGaussianParameterEstimation.js')
let DiscreteParameterEstimation = require('./DiscreteParameterEstimation.js')
let DiscreteStructureEstimation = require('./DiscreteStructureEstimation.js')
let LinearGaussianStructureEstimation = require('./LinearGaussianStructureEstimation.js')

module.exports = {
  DiscreteQuery: DiscreteQuery,
  LinearGaussianParameterEstimation: LinearGaussianParameterEstimation,
  DiscreteParameterEstimation: DiscreteParameterEstimation,
  DiscreteStructureEstimation: DiscreteStructureEstimation,
  LinearGaussianStructureEstimation: LinearGaussianStructureEstimation,
};
