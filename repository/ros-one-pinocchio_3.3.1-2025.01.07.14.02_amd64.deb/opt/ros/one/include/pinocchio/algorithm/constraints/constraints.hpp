//
// Copyright (c) 2023 INRIA
//

#ifndef __pinocchio_algorithm_constraints_constraints_hpp__
#define __pinocchio_algorithm_constraints_constraints_hpp__

#include "pinocchio/algorithm/constraints/fwd.hpp"

namespace pinocchio
{
}

#endif // ifndef __pinocchio_algorithm_constraints_constraints_hpp__
