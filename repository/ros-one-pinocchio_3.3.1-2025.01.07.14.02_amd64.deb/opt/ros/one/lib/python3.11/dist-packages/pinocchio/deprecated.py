#
# Copyright (c) 2018-2023 CNRS INRIA
#

## In this file, are reported some deprecated functions
# that are still maintained until the next important future releases
