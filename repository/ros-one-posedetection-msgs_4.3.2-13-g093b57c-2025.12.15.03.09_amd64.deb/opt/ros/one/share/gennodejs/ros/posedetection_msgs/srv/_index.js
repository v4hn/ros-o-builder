
"use strict";

let Detect = require('./Detect.js')
let Feature0DDetect = require('./Feature0DDetect.js')
let TargetObj = require('./TargetObj.js')
let Feature1DDetect = require('./Feature1DDetect.js')

module.exports = {
  Detect: Detect,
  Feature0DDetect: Feature0DDetect,
  TargetObj: TargetObj,
  Feature1DDetect: Feature1DDetect,
};
