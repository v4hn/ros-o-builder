
"use strict";

let SetDynamicTF = require('./SetDynamicTF.js')
let DissocTF = require('./DissocTF.js')
let AssocTF = require('./AssocTF.js')
let DeleteTF = require('./DeleteTF.js')

module.exports = {
  SetDynamicTF: SetDynamicTF,
  DissocTF: DissocTF,
  AssocTF: AssocTF,
  DeleteTF: DeleteTF,
};
