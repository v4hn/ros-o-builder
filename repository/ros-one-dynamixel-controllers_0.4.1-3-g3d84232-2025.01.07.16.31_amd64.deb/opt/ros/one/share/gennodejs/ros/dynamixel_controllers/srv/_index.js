
"use strict";

let SetComplianceMargin = require('./SetComplianceMargin.js')
let SetSpeed = require('./SetSpeed.js')
let StartController = require('./StartController.js')
let StopController = require('./StopController.js')
let TorqueEnable = require('./TorqueEnable.js')
let RestartController = require('./RestartController.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')

module.exports = {
  SetComplianceMargin: SetComplianceMargin,
  SetSpeed: SetSpeed,
  StartController: StartController,
  StopController: StopController,
  TorqueEnable: TorqueEnable,
  RestartController: RestartController,
  SetCompliancePunch: SetCompliancePunch,
  SetTorqueLimit: SetTorqueLimit,
  SetComplianceSlope: SetComplianceSlope,
};
