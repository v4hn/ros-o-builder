
"use strict";

let Upload = require('./Upload.js')
let MultipleUpload = require('./MultipleUpload.js')

module.exports = {
  Upload: Upload,
  MultipleUpload: MultipleUpload,
};
