# Append cmake modules from source directory to the cmake module path
list(APPEND CMAKE_MODULE_PATH "${cras_cpp_common_DIR}/../../../share/cras_cpp_common/cmake/Modules")
cmake_policy(SET CMP0022 NEW)
add_compile_options(-DXMLRPCPP_HAS_PRINTTO=1)
