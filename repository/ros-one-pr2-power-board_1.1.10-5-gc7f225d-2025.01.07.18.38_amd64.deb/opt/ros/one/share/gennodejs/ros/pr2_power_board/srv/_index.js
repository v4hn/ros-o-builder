
"use strict";

let PowerBoardCommand2 = require('./PowerBoardCommand2.js')
let PowerBoardCommand = require('./PowerBoardCommand.js')

module.exports = {
  PowerBoardCommand2: PowerBoardCommand2,
  PowerBoardCommand: PowerBoardCommand,
};
