
"use strict";

let AddTwoInts = require('./AddTwoInts.js')
let BadTwoInts = require('./BadTwoInts.js')

module.exports = {
  AddTwoInts: AddTwoInts,
  BadTwoInts: BadTwoInts,
};
