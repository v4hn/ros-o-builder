
"use strict";

let PhraseRule = require('./PhraseRule.js');
let Vocabulary = require('./Vocabulary.js');
let Grammar = require('./Grammar.js');
let SpeechRecognitionCandidates = require('./SpeechRecognitionCandidates.js');

module.exports = {
  PhraseRule: PhraseRule,
  Vocabulary: Vocabulary,
  Grammar: Grammar,
  SpeechRecognitionCandidates: SpeechRecognitionCandidates,
};
