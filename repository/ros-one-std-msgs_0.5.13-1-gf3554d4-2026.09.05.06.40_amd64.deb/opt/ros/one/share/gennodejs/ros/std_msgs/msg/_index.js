
"use strict";

let Float64MultiArray = require('./Float64MultiArray.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Float64 = require('./Float64.js');
let Int16 = require('./Int16.js');
let Int8 = require('./Int8.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let Byte = require('./Byte.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let String = require('./String.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let UInt8 = require('./UInt8.js');
let Empty = require('./Empty.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let Int32 = require('./Int32.js');
let Duration = require('./Duration.js');
let Int64 = require('./Int64.js');
let UInt16 = require('./UInt16.js');
let Char = require('./Char.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let Time = require('./Time.js');
let Bool = require('./Bool.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let Float32 = require('./Float32.js');
let ColorRGBA = require('./ColorRGBA.js');
let UInt32 = require('./UInt32.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let UInt64 = require('./UInt64.js');
let Header = require('./Header.js');

module.exports = {
  Float64MultiArray: Float64MultiArray,
  UInt32MultiArray: UInt32MultiArray,
  Float32MultiArray: Float32MultiArray,
  MultiArrayDimension: MultiArrayDimension,
  Float64: Float64,
  Int16: Int16,
  Int8: Int8,
  Int32MultiArray: Int32MultiArray,
  Byte: Byte,
  UInt64MultiArray: UInt64MultiArray,
  UInt8MultiArray: UInt8MultiArray,
  String: String,
  UInt16MultiArray: UInt16MultiArray,
  ByteMultiArray: ByteMultiArray,
  UInt8: UInt8,
  Empty: Empty,
  Int8MultiArray: Int8MultiArray,
  Int32: Int32,
  Duration: Duration,
  Int64: Int64,
  UInt16: UInt16,
  Char: Char,
  Int16MultiArray: Int16MultiArray,
  Time: Time,
  Bool: Bool,
  MultiArrayLayout: MultiArrayLayout,
  Float32: Float32,
  ColorRGBA: ColorRGBA,
  UInt32: UInt32,
  Int64MultiArray: Int64MultiArray,
  UInt64: UInt64,
  Header: Header,
};
