
"use strict";

let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequestResult: SoundRequestResult,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequest: SoundRequest,
};
