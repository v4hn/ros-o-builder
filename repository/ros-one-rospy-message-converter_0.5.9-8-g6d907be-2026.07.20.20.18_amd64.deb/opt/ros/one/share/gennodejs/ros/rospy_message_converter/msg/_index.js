
"use strict";

let Uint8Array3TestMessage = require('./Uint8Array3TestMessage.js');
let NestedUint8ArrayTestMessage = require('./NestedUint8ArrayTestMessage.js');
let Uint8ArrayTestMessage = require('./Uint8ArrayTestMessage.js');
let TestArray = require('./TestArray.js');

module.exports = {
  Uint8Array3TestMessage: Uint8Array3TestMessage,
  NestedUint8ArrayTestMessage: NestedUint8ArrayTestMessage,
  Uint8ArrayTestMessage: Uint8ArrayTestMessage,
  TestArray: TestArray,
};
