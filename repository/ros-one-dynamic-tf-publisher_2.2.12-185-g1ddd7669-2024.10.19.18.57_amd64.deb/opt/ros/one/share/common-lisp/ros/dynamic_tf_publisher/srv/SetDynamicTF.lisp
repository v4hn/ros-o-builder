; Auto-generated. Do not edit!


(cl:in-package dynamic_tf_publisher-srv)


;//! \htmlinclude SetDynamicTF-request.msg.html

(cl:defclass <SetDynamicTF-request> (roslisp-msg-protocol:ros-message)
  ((freq
    :reader freq
    :initarg :freq
    :type cl:float
    :initform 0.0)
   (cur_tf
    :reader cur_tf
    :initarg :cur_tf
    :type geometry_msgs-msg:TransformStamped
    :initform (cl:make-instance 'geometry_msgs-msg:TransformStamped)))
)

(cl:defclass SetDynamicTF-request (<SetDynamicTF-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetDynamicTF-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetDynamicTF-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<SetDynamicTF-request> is deprecated: use dynamic_tf_publisher-srv:SetDynamicTF-request instead.")))

(cl:ensure-generic-function 'freq-val :lambda-list '(m))
(cl:defmethod freq-val ((m <SetDynamicTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:freq-val is deprecated.  Use dynamic_tf_publisher-srv:freq instead.")
  (freq m))

(cl:ensure-generic-function 'cur_tf-val :lambda-list '(m))
(cl:defmethod cur_tf-val ((m <SetDynamicTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:cur_tf-val is deprecated.  Use dynamic_tf_publisher-srv:cur_tf instead.")
  (cur_tf m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetDynamicTF-request>) ostream)
  "Serializes a message object of type '<SetDynamicTF-request>"
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'freq))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'cur_tf) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetDynamicTF-request>) istream)
  "Deserializes a message object of type '<SetDynamicTF-request>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'freq) (roslisp-utils:decode-single-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'cur_tf) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetDynamicTF-request>)))
  "Returns string type for a service object of type '<SetDynamicTF-request>"
  "dynamic_tf_publisher/SetDynamicTFRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetDynamicTF-request)))
  "Returns string type for a service object of type 'SetDynamicTF-request"
  "dynamic_tf_publisher/SetDynamicTFRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetDynamicTF-request>)))
  "Returns md5sum for a message object of type '<SetDynamicTF-request>"
  "257be6eb2c49e846d6c3c12c85bb0fb1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetDynamicTF-request)))
  "Returns md5sum for a message object of type 'SetDynamicTF-request"
  "257be6eb2c49e846d6c3c12c85bb0fb1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetDynamicTF-request>)))
  "Returns full string definition for message of type '<SetDynamicTF-request>"
  (cl:format cl:nil "float32 freq~%geometry_msgs/TransformStamped cur_tf~%~%================================================================================~%MSG: geometry_msgs/TransformStamped~%# This expresses a transform from coordinate frame header.frame_id~%# to the coordinate frame child_frame_id~%#~%# This message is mostly used by the ~%# <a href=\"http://wiki.ros.org/tf\">tf</a> package. ~%# See its documentation for more information.~%~%Header header~%string child_frame_id # the frame id of the child frame~%Transform transform~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetDynamicTF-request)))
  "Returns full string definition for message of type 'SetDynamicTF-request"
  (cl:format cl:nil "float32 freq~%geometry_msgs/TransformStamped cur_tf~%~%================================================================================~%MSG: geometry_msgs/TransformStamped~%# This expresses a transform from coordinate frame header.frame_id~%# to the coordinate frame child_frame_id~%#~%# This message is mostly used by the ~%# <a href=\"http://wiki.ros.org/tf\">tf</a> package. ~%# See its documentation for more information.~%~%Header header~%string child_frame_id # the frame id of the child frame~%Transform transform~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Transform~%# This represents the transform between two coordinate frames in free space.~%~%Vector3 translation~%Quaternion rotation~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetDynamicTF-request>))
  (cl:+ 0
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'cur_tf))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetDynamicTF-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SetDynamicTF-request
    (cl:cons ':freq (freq msg))
    (cl:cons ':cur_tf (cur_tf msg))
))
;//! \htmlinclude SetDynamicTF-response.msg.html

(cl:defclass <SetDynamicTF-response> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass SetDynamicTF-response (<SetDynamicTF-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SetDynamicTF-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SetDynamicTF-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<SetDynamicTF-response> is deprecated: use dynamic_tf_publisher-srv:SetDynamicTF-response instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SetDynamicTF-response>) ostream)
  "Serializes a message object of type '<SetDynamicTF-response>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SetDynamicTF-response>) istream)
  "Deserializes a message object of type '<SetDynamicTF-response>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SetDynamicTF-response>)))
  "Returns string type for a service object of type '<SetDynamicTF-response>"
  "dynamic_tf_publisher/SetDynamicTFResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetDynamicTF-response)))
  "Returns string type for a service object of type 'SetDynamicTF-response"
  "dynamic_tf_publisher/SetDynamicTFResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SetDynamicTF-response>)))
  "Returns md5sum for a message object of type '<SetDynamicTF-response>"
  "257be6eb2c49e846d6c3c12c85bb0fb1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SetDynamicTF-response)))
  "Returns md5sum for a message object of type 'SetDynamicTF-response"
  "257be6eb2c49e846d6c3c12c85bb0fb1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SetDynamicTF-response>)))
  "Returns full string definition for message of type '<SetDynamicTF-response>"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SetDynamicTF-response)))
  "Returns full string definition for message of type 'SetDynamicTF-response"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SetDynamicTF-response>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SetDynamicTF-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SetDynamicTF-response
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SetDynamicTF)))
  'SetDynamicTF-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SetDynamicTF)))
  'SetDynamicTF-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SetDynamicTF)))
  "Returns string type for a service object of type '<SetDynamicTF>"
  "dynamic_tf_publisher/SetDynamicTF")