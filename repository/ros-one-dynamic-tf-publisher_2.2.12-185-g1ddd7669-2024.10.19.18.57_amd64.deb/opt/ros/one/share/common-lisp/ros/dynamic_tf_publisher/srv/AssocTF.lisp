; Auto-generated. Do not edit!


(cl:in-package dynamic_tf_publisher-srv)


;//! \htmlinclude AssocTF-request.msg.html

(cl:defclass <AssocTF-request> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (parent_frame
    :reader parent_frame
    :initarg :parent_frame
    :type cl:string
    :initform "")
   (child_frame
    :reader child_frame
    :initarg :child_frame
    :type cl:string
    :initform ""))
)

(cl:defclass AssocTF-request (<AssocTF-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AssocTF-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AssocTF-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<AssocTF-request> is deprecated: use dynamic_tf_publisher-srv:AssocTF-request instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <AssocTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:header-val is deprecated.  Use dynamic_tf_publisher-srv:header instead.")
  (header m))

(cl:ensure-generic-function 'parent_frame-val :lambda-list '(m))
(cl:defmethod parent_frame-val ((m <AssocTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:parent_frame-val is deprecated.  Use dynamic_tf_publisher-srv:parent_frame instead.")
  (parent_frame m))

(cl:ensure-generic-function 'child_frame-val :lambda-list '(m))
(cl:defmethod child_frame-val ((m <AssocTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:child_frame-val is deprecated.  Use dynamic_tf_publisher-srv:child_frame instead.")
  (child_frame m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AssocTF-request>) ostream)
  "Serializes a message object of type '<AssocTF-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parent_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parent_frame))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'child_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'child_frame))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AssocTF-request>) istream)
  "Deserializes a message object of type '<AssocTF-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parent_frame) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parent_frame) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'child_frame) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'child_frame) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AssocTF-request>)))
  "Returns string type for a service object of type '<AssocTF-request>"
  "dynamic_tf_publisher/AssocTFRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AssocTF-request)))
  "Returns string type for a service object of type 'AssocTF-request"
  "dynamic_tf_publisher/AssocTFRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AssocTF-request>)))
  "Returns md5sum for a message object of type '<AssocTF-request>"
  "984a9f3f6741b2b5568909b82fec6355")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AssocTF-request)))
  "Returns md5sum for a message object of type 'AssocTF-request"
  "984a9f3f6741b2b5568909b82fec6355")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AssocTF-request>)))
  "Returns full string definition for message of type '<AssocTF-request>"
  (cl:format cl:nil "Header  header~%string         parent_frame~%string         child_frame~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AssocTF-request)))
  "Returns full string definition for message of type 'AssocTF-request"
  (cl:format cl:nil "Header  header~%string         parent_frame~%string         child_frame~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AssocTF-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'parent_frame))
     4 (cl:length (cl:slot-value msg 'child_frame))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AssocTF-request>))
  "Converts a ROS message object to a list"
  (cl:list 'AssocTF-request
    (cl:cons ':header (header msg))
    (cl:cons ':parent_frame (parent_frame msg))
    (cl:cons ':child_frame (child_frame msg))
))
;//! \htmlinclude AssocTF-response.msg.html

(cl:defclass <AssocTF-response> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass AssocTF-response (<AssocTF-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AssocTF-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AssocTF-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<AssocTF-response> is deprecated: use dynamic_tf_publisher-srv:AssocTF-response instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AssocTF-response>) ostream)
  "Serializes a message object of type '<AssocTF-response>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AssocTF-response>) istream)
  "Deserializes a message object of type '<AssocTF-response>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AssocTF-response>)))
  "Returns string type for a service object of type '<AssocTF-response>"
  "dynamic_tf_publisher/AssocTFResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AssocTF-response)))
  "Returns string type for a service object of type 'AssocTF-response"
  "dynamic_tf_publisher/AssocTFResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AssocTF-response>)))
  "Returns md5sum for a message object of type '<AssocTF-response>"
  "984a9f3f6741b2b5568909b82fec6355")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AssocTF-response)))
  "Returns md5sum for a message object of type 'AssocTF-response"
  "984a9f3f6741b2b5568909b82fec6355")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AssocTF-response>)))
  "Returns full string definition for message of type '<AssocTF-response>"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AssocTF-response)))
  "Returns full string definition for message of type 'AssocTF-response"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AssocTF-response>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AssocTF-response>))
  "Converts a ROS message object to a list"
  (cl:list 'AssocTF-response
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'AssocTF)))
  'AssocTF-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'AssocTF)))
  'AssocTF-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AssocTF)))
  "Returns string type for a service object of type '<AssocTF>"
  "dynamic_tf_publisher/AssocTF")