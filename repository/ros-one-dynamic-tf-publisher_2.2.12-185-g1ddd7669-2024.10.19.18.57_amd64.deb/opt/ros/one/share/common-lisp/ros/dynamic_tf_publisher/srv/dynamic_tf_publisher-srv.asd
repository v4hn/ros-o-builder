
(cl:in-package :asdf)

(defsystem "dynamic_tf_publisher-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "AssocTF" :depends-on ("_package_AssocTF"))
    (:file "_package_AssocTF" :depends-on ("_package"))
    (:file "DeleteTF" :depends-on ("_package_DeleteTF"))
    (:file "_package_DeleteTF" :depends-on ("_package"))
    (:file "DissocTF" :depends-on ("_package_DissocTF"))
    (:file "_package_DissocTF" :depends-on ("_package"))
    (:file "SetDynamicTF" :depends-on ("_package_SetDynamicTF"))
    (:file "_package_SetDynamicTF" :depends-on ("_package"))
  ))