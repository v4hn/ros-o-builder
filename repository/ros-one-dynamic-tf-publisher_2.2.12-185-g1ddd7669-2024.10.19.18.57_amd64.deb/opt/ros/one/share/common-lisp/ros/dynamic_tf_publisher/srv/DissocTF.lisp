; Auto-generated. Do not edit!


(cl:in-package dynamic_tf_publisher-srv)


;//! \htmlinclude DissocTF-request.msg.html

(cl:defclass <DissocTF-request> (roslisp-msg-protocol:ros-message)
  ((header
    :reader header
    :initarg :header
    :type std_msgs-msg:Header
    :initform (cl:make-instance 'std_msgs-msg:Header))
   (frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform ""))
)

(cl:defclass DissocTF-request (<DissocTF-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DissocTF-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DissocTF-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<DissocTF-request> is deprecated: use dynamic_tf_publisher-srv:DissocTF-request instead.")))

(cl:ensure-generic-function 'header-val :lambda-list '(m))
(cl:defmethod header-val ((m <DissocTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:header-val is deprecated.  Use dynamic_tf_publisher-srv:header instead.")
  (header m))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <DissocTF-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader dynamic_tf_publisher-srv:frame_id-val is deprecated.  Use dynamic_tf_publisher-srv:frame_id instead.")
  (frame_id m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DissocTF-request>) ostream)
  "Serializes a message object of type '<DissocTF-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'header) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DissocTF-request>) istream)
  "Deserializes a message object of type '<DissocTF-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'header) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DissocTF-request>)))
  "Returns string type for a service object of type '<DissocTF-request>"
  "dynamic_tf_publisher/DissocTFRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DissocTF-request)))
  "Returns string type for a service object of type 'DissocTF-request"
  "dynamic_tf_publisher/DissocTFRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DissocTF-request>)))
  "Returns md5sum for a message object of type '<DissocTF-request>"
  "5fa93cf9f65be2325fa0008ddcc90131")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DissocTF-request)))
  "Returns md5sum for a message object of type 'DissocTF-request"
  "5fa93cf9f65be2325fa0008ddcc90131")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DissocTF-request>)))
  "Returns full string definition for message of type '<DissocTF-request>"
  (cl:format cl:nil "Header  header~%string         frame_id~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DissocTF-request)))
  "Returns full string definition for message of type 'DissocTF-request"
  (cl:format cl:nil "Header  header~%string         frame_id~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DissocTF-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'header))
     4 (cl:length (cl:slot-value msg 'frame_id))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DissocTF-request>))
  "Converts a ROS message object to a list"
  (cl:list 'DissocTF-request
    (cl:cons ':header (header msg))
    (cl:cons ':frame_id (frame_id msg))
))
;//! \htmlinclude DissocTF-response.msg.html

(cl:defclass <DissocTF-response> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass DissocTF-response (<DissocTF-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DissocTF-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DissocTF-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name dynamic_tf_publisher-srv:<DissocTF-response> is deprecated: use dynamic_tf_publisher-srv:DissocTF-response instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DissocTF-response>) ostream)
  "Serializes a message object of type '<DissocTF-response>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DissocTF-response>) istream)
  "Deserializes a message object of type '<DissocTF-response>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DissocTF-response>)))
  "Returns string type for a service object of type '<DissocTF-response>"
  "dynamic_tf_publisher/DissocTFResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DissocTF-response)))
  "Returns string type for a service object of type 'DissocTF-response"
  "dynamic_tf_publisher/DissocTFResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DissocTF-response>)))
  "Returns md5sum for a message object of type '<DissocTF-response>"
  "5fa93cf9f65be2325fa0008ddcc90131")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DissocTF-response)))
  "Returns md5sum for a message object of type 'DissocTF-response"
  "5fa93cf9f65be2325fa0008ddcc90131")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DissocTF-response>)))
  "Returns full string definition for message of type '<DissocTF-response>"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DissocTF-response)))
  "Returns full string definition for message of type 'DissocTF-response"
  (cl:format cl:nil "~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DissocTF-response>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DissocTF-response>))
  "Converts a ROS message object to a list"
  (cl:list 'DissocTF-response
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'DissocTF)))
  'DissocTF-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'DissocTF)))
  'DissocTF-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DissocTF)))
  "Returns string type for a service object of type '<DissocTF>"
  "dynamic_tf_publisher/DissocTF")