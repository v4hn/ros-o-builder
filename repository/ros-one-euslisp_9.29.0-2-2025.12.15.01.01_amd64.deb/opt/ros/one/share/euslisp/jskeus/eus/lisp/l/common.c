/* ./common.c :  entry=common */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Dec 15 01:02:36 UTC 2025) */
#include "eus.h"
#include "common.h"
#pragma init (register_common)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___common();
extern pointer build_quote_vector();
static int register_common()
  { add_module_initializer("___common", ___common);}

static pointer commonF50lisp_implementation_type();
static pointer commonF51lisp_implementation_version();
static pointer commonF52macroexpand();
static pointer commonF53casebody();
static pointer commonF54casehead();
static pointer commonF55case1();
static pointer commonF56classcasehead();
static pointer commonF57classcase1();
static pointer commonF58string();
static pointer commonF59alias();
static pointer commonF60caaar();
static pointer commonF61caadr();
static pointer commonF62cadar();
static pointer commonF63cdaar();
static pointer commonF64cdadr();
static pointer commonF65cddar();
static pointer commonF66cdddr();
static pointer commonF67fourth();
static pointer commonF68fifth();
static pointer commonF69sixth();
static pointer commonF70seventh();
static pointer commonF71eighth();
static pointer commonF72cddddr();
static pointer commonF73cadddr();
static pointer commonF74caaddr();
static pointer commonF75cdaddr();
static pointer commonF76caddddr();
static pointer commonF77flatten();
static pointer commonF78list_insert();
static pointer commonF79list_delete();
static pointer commonF80adjoin();
static pointer commonF81union();
static pointer commonF82intersection();
static pointer commonF83set_difference();
static pointer commonF84set_exclusive_or();
static pointer commonF85rotate_list();
static pointer commonF86last();
static pointer commonF87copy_tree();
static pointer commonF88copy_list();
static pointer commonF89nreconc();
static pointer commonF90rassoc();
static pointer commonF91acons();
static pointer commonF92member();
static pointer commonF93assoc();
static pointer commonF94subsetp();
static pointer commonF95maplist();
static pointer commonF96mapcon();
static pointer commonF97find();
static pointer commonF98find_if();
static pointer commonF99find_if_not();
static pointer commonF100position();
static pointer commonF101position_if();
static pointer commonF102position_if_not();
static pointer commonF103count();
static pointer commonF104count_if();
static pointer commonF105count_if_not();
static pointer commonF106member_if();
static pointer commonF107member_if_not();
static pointer commonF108collect_if();
static pointer commonF109collect_instances();
static pointer commonF110pairlis();
static pointer commonF111transpose_list();
static pointer commonF112make_list();
static pointer commonF113make_sequence();
static pointer commonF114fill();
static pointer commonF115replace();
static pointer commonF116remove();
static pointer commonF117remove_if();
static pointer commonF118remove_if_not();
static pointer commonF119delete();
static pointer commonF120delete_if();
static pointer commonF121delete_if_not();
static pointer commonF122substitute();
static pointer commonF123substitute_if();
static pointer commonF124substitute_if_not();
static pointer commonF125nsubstitute();
static pointer commonF126nsubstitute_if();
static pointer commonF127nsubstitute_if_not();
static pointer commonF128unique();
static pointer commonF129remove_duplicates();
static pointer commonF130extream();
static pointer commonF131send_all();
static pointer commonF132resend();
static pointer commonF133make_instance();
static pointer commonF134delete_method();
static pointer commonF135make_class();
static pointer commonF136readtablep();
static pointer commonF137copy_readtable();
static pointer commonF138set_syntax_from_char();
static pointer commonF139keywordp();
static pointer commonF140constantp();
static pointer commonF141functionp();
static pointer commonF142vector_class_p();
static pointer commonF143compiled_function_p();
static pointer commonF144input_stream_p();
static pointer commonF145output_stream_p();
static pointer commonF146io_stream_p();
static pointer commonF147special_form_p();
static pointer commonF148macro_function();
static pointer commonF149zerop();
static pointer commonF150plusp();
static pointer commonF151minusp();
static pointer commonF152oddp();
static pointer commonF153evenp();
static pointer commonF154logandc1();
static pointer commonF155logandc2();
static pointer commonF156every();
static pointer commonF157some();
static pointer commonF158reduce();
static pointer commonF159merge_list();
static pointer commonF160merge();
static pointer commonF161expt();
static pointer commonF162signum();
static pointer commonF163rad2deg();
static pointer commonF164deg2rad();
static pointer commonF165setf_expand_1();
static pointer commonF166setf_expand();

/*lisp-implementation-type*/
static pointer commonF50lisp_implementation_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	w = fqv[0];
	local[0]= w;
commonBLK167:
	ctx->vsp=local; return(local[0]);}

/*lisp-implementation-version*/
static pointer commonF51lisp_implementation_version(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= NIL;
	local[1]= fqv[1];
	w=loadglobal(fqv[2]);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)commonF66cdddr(ctx,1,local+3); /*cdddr*/
	local[3]= w;
	local[4]= loadglobal(fqv[3]);
	w=loadglobal(fqv[2]);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=loadglobal(fqv[2]);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,7,local+0); /*format*/
	local[0]= w;
commonBLK168:
	ctx->vsp=local; return(local[0]);}

/*macroexpand*/
static pointer commonF52macroexpand(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)MACEXPAND2(ctx,1,local+0); /*macroexpand2*/
	local[0]= w;
commonWHL170:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto commonWHX171;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)commonF148macro_function(ctx,1,local+1); /*macro-function*/
	if (w==NIL) goto commonWHX171;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)MACEXPAND2(ctx,1,local+1); /*macroexpand2*/
	local[0] = w;
	goto commonWHL170;
commonWHX171:
	local[1]= NIL;
commonBLK172:
	w = local[0];
	local[0]= w;
commonBLK169:
	ctx->vsp=local; return(local[0]);}

/*prog1*/
static pointer commonF173(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST175:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[4];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[5];
	local[3]= local[1];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[6];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK174:
	ctx->vsp=local; return(local[0]);}

/*loop*/
static pointer commonF176(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST178:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[7];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[8];
	local[3]= fqv[9];
	local[4]= fqv[10];
	local[5]= local[1];
	local[6]= local[0];
	local[7]= fqv[11];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK177:
	ctx->vsp=local; return(local[0]);}

/*unless*/
static pointer commonF179(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST181:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[12];
	local[2]= fqv[13];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	w = local[0];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK180:
	ctx->vsp=local; return(local[0]);}

/*until*/
static pointer commonF182(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST184:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[14];
	local[2]= fqv[13];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= local[0];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK183:
	ctx->vsp=local; return(local[0]);}

/*pop*/
static pointer commonF185(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[15];
	local[1]= fqv[16];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	local[2]= fqv[17];
	local[3]= argv[0];
	local[4]= fqv[18];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
commonBLK186:
	ctx->vsp=local; return(local[0]);}

/*push*/
static pointer commonF187(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[17];
	local[1]= argv[1];
	local[2]= fqv[19];
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
commonBLK188:
	ctx->vsp=local; return(local[0]);}

/*pushnew*/
static pointer commonF189(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[20], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY191;
	local[0] = NIL;
commonKEY191:
	if (n & (1<<1)) goto commonKEY192;
	local[1] = NIL;
commonKEY192:
	if (n & (1<<2)) goto commonKEY193;
	local[2] = NIL;
commonKEY193:
	local[3]= fqv[6];
	local[4]= fqv[21];
	local[5]= fqv[13];
	local[6]= fqv[22];
	local[7]= argv[0];
	local[8]= argv[1];
	local[9]= fqv[23];
	local[10]= local[0];
	local[11]= fqv[24];
	local[12]= local[1];
	local[13]= fqv[25];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[17];
	local[7]= argv[1];
	local[8]= fqv[19];
	local[9]= argv[0];
	local[10]= argv[1];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[9];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
commonBLK190:
	ctx->vsp=local; return(local[0]);}

/*inc*/
static pointer commonF194(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT197;}
	local[0]= NIL;
commonENT197:
commonENT196:
	if (n>2) maerror();
	if (local[0]==NIL) goto commonIF198;
	local[1]= fqv[26];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto commonIF199;
commonIF198:
	local[1]= fqv[27];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
commonIF199:
	local[1]= fqv[28];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0]= w;
commonBLK195:
	ctx->vsp=local; return(local[0]);}

/*dec*/
static pointer commonF200(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT203;}
	local[0]= NIL;
commonENT203:
commonENT202:
	if (n>2) maerror();
	if (local[0]==NIL) goto commonIF204;
	local[1]= fqv[29];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto commonIF205;
commonIF204:
	local[1]= fqv[30];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
commonIF205:
	local[1]= fqv[28];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0]= w;
commonBLK201:
	ctx->vsp=local; return(local[0]);}

/*incf*/
static pointer commonF206(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT209;}
	local[0]= NIL;
commonENT209:
commonENT208:
	if (n>2) maerror();
	if (local[0]==NIL) goto commonIF210;
	local[1]= fqv[26];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto commonIF211;
commonIF210:
	local[1]= fqv[27];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
commonIF211:
	local[1]= fqv[17];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0]= w;
commonBLK207:
	ctx->vsp=local; return(local[0]);}

/*decf*/
static pointer commonF212(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT215;}
	local[0]= NIL;
commonENT215:
commonENT214:
	if (n>2) maerror();
	if (local[0]==NIL) goto commonIF216;
	local[1]= fqv[29];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
	goto commonIF217;
commonIF216:
	local[1]= fqv[30];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[0] = w;
	local[1]= local[0];
commonIF217:
	local[1]= fqv[17];
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[0]= w;
commonBLK213:
	ctx->vsp=local; return(local[0]);}

/*defvar*/
static pointer commonF218(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT222;}
	local[0]= NIL;
commonENT222:
	if (n>=3) { local[1]=(argv[2]); goto commonENT221;}
	local[1]= NIL;
commonENT221:
commonENT220:
	if (n>3) maerror();
	w = argv[0];
	if (issymbol(w)) goto commonIF223;
	local[2]= makeint((eusinteger_t)20L);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto commonIF224;
commonIF223:
	local[2]= NIL;
commonIF224:
	local[2]= fqv[12];
	local[3]= fqv[31];
	local[4]= fqv[32];
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[34];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[35];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[32];
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[34];
	local[7]= fqv[36];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[21];
	local[6]= fqv[13];
	local[7]= fqv[37];
	local[8]= fqv[33];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[32];
	local[8]= fqv[33];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[38];
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[33];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK219:
	ctx->vsp=local; return(local[0]);}

/*deflocal*/
static pointer commonF225(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT229;}
	local[0]= NIL;
commonENT229:
	if (n>=3) { local[1]=(argv[2]); goto commonENT228;}
	local[1]= NIL;
commonENT228:
commonENT227:
	if (n>3) maerror();
	w = argv[0];
	if (issymbol(w)) goto commonIF230;
	local[2]= makeint((eusinteger_t)20L);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto commonIF231;
commonIF230:
	local[2]= NIL;
commonIF231:
	local[2]= fqv[6];
	local[3]= fqv[32];
	local[4]= fqv[33];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[39];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[33];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK226:
	ctx->vsp=local; return(local[0]);}

/*defparameter*/
static pointer commonF232(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto commonENT235;}
	local[0]= NIL;
commonENT235:
commonENT234:
	if (n>3) maerror();
	w = argv[0];
	if (issymbol(w)) goto commonIF236;
	local[1]= makeint((eusinteger_t)20L);
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto commonIF237;
commonIF236:
	local[1]= NIL;
commonIF237:
	local[1]= fqv[32];
	local[2]= fqv[33];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[38];
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK233:
	ctx->vsp=local; return(local[0]);}

/*defconstant*/
static pointer commonF238(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto commonENT241;}
	local[0]= NIL;
commonENT241:
commonENT240:
	if (n>3) maerror();
	w = argv[0];
	if (issymbol(w)) goto commonIF242;
	local[1]= makeint((eusinteger_t)20L);
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto commonIF243;
commonIF242:
	local[1]= NIL;
commonIF243:
	local[1]= fqv[32];
	local[2]= fqv[33];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[40];
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK239:
	ctx->vsp=local; return(local[0]);}

/*dotimes*/
static pointer commonF244(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST246:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[41];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[5];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= fqv[42];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[43];
	local[5]= fqv[44];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[14];
	local[6]= fqv[45];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= local[0];
	local[8]= fqv[28];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[27];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK245:
	ctx->vsp=local; return(local[0]);}

/*dolist*/
static pointer commonF247(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST249:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[46];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w = local[2];
	if (!iscons(w)) goto commonIF250;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (fqv[43]!=local[3]) goto commonIF250;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	local[3]= local[0];
	goto commonIF251;
commonIF250:
	local[2] = NIL;
	local[3]= local[2];
commonIF251:
	local[3]= fqv[5];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[9];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[2];
	local[6]= fqv[14];
	local[7]= local[1];
	local[8]= fqv[28];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[47];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[0];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,2,local+9); /*append*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
commonBLK248:
	ctx->vsp=local; return(local[0]);}

/*do-symbols*/
static pointer commonF252(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST254:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto commonIF255;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto commonIF256;
commonIF255:
	local[3]= fqv[49];
commonIF256:
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,0,local+5); /*gensym*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)GENSYM(ctx,0,local+6); /*gensym*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)GENSYM(ctx,0,local+7); /*gensym*/
	local[7]= w;
	local[8]= fqv[50];
	local[9]= local[2];
	local[10]= fqv[9];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= local[4];
	local[11]= fqv[51];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[5];
	local[12]= fqv[52];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[7];
	local[13]= local[4];
	w = fqv[53];
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= local[6];
	local[14]= fqv[54];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[14];
	local[11]= fqv[45];
	local[12]= local[5];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[28];
	local[13]= local[2];
	local[14]= fqv[55];
	local[15]= local[7];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[56];
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[12];
	local[15]= fqv[57];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	w = local[0];
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	local[0]= w;
commonBLK253:
	ctx->vsp=local; return(local[0]);}

/*do-external-symbols*/
static pointer commonF257(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST259:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto commonIF260;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	goto commonIF261;
commonIF260:
	local[3]= fqv[49];
commonIF261:
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,0,local+5); /*gensym*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)GENSYM(ctx,0,local+6); /*gensym*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)GENSYM(ctx,0,local+7); /*gensym*/
	local[7]= w;
	local[8]= fqv[50];
	local[9]= local[2];
	local[10]= fqv[9];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= local[4];
	local[11]= fqv[51];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[5];
	local[12]= fqv[59];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= local[7];
	local[13]= local[4];
	w = fqv[60];
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= local[6];
	local[14]= fqv[54];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[14];
	local[11]= fqv[45];
	local[12]= local[5];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[28];
	local[13]= local[2];
	local[14]= fqv[55];
	local[15]= local[7];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[56];
	local[14]= local[5];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[12];
	local[15]= fqv[57];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	w = local[0];
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	local[0]= w;
commonBLK258:
	ctx->vsp=local; return(local[0]);}

/*do-all-symbols*/
static pointer commonF262(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST264:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[61];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[62];
	local[3]= local[1];
	local[4]= fqv[63];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[64];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	w = local[0];
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK263:
	ctx->vsp=local; return(local[0]);}

/*psetq*/
static pointer commonF265(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST267:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
commonWHL268:
	if (local[0]==NIL) goto commonWHX269;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	w = local[2];
	ctx->vsp=local+5;
	local[2] = cons(ctx,local[4],w);
	local[4]= fqv[65];
	ctx->vsp=local+5;
	w=(pointer)GENSYM(ctx,1,local+4); /*gensym*/
	local[4]= w;
	w = local[3];
	ctx->vsp=local+5;
	local[3] = cons(ctx,local[4],w);
	goto commonWHL268;
commonWHX269:
	local[4]= NIL;
commonBLK270:
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[1] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[2] = w;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[3] = w;
	local[4]= fqv[50];
	local[5]= (pointer)get_sym_func(fqv[66]);
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,3,local+5); /*mapcar*/
	local[5]= w;
	local[6]= fqv[28];
	local[7]= (pointer)get_sym_func(fqv[66]);
	local[8]= local[1];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MAPCAN(ctx,3,local+7); /*mapcan*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[9];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	local[0]= w;
commonBLK266:
	ctx->vsp=local; return(local[0]);}

/*do*/
static pointer commonF271(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST273:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[67];
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,1,local+2); /*gensym*/
	local[2]= w;
	w = local[1];
	if (!iscons(w)) goto commonIF274;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (fqv[43]!=local[3]) goto commonIF274;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	local[3]= local[0];
	goto commonIF275;
commonIF274:
	local[1] = NIL;
	local[3]= local[1];
commonIF275:
	local[3]= fqv[8];
	local[4]= fqv[9];
	local[5]= fqv[5];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,commonCLO276,env,argv,local);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	local[7]= local[1];
	local[8]= fqv[10];
	local[9]= local[2];
	local[10]= fqv[21];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[68];
	local[13]= fqv[6];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[0];
	local[12]= fqv[69];
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,commonCLO277,env,argv,local);
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(pointer)MAPCAN(ctx,2,local+13); /*mapcan*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[11];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)APPEND(ctx,2,local+11); /*append*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
commonBLK272:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO276(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO277(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto commonIF278;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	goto commonIF279;
commonIF278:
	local[0]= NIL;
commonIF279:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*do**/
static pointer commonF280(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST282:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[70];
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,1,local+2); /*gensym*/
	local[2]= w;
	w = local[1];
	if (!iscons(w)) goto commonIF283;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (fqv[43]!=local[3]) goto commonIF283;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	local[3]= local[0];
	goto commonIF284;
commonIF283:
	local[1] = NIL;
	local[3]= local[1];
commonIF284:
	local[3]= fqv[8];
	local[4]= fqv[9];
	local[5]= fqv[50];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,commonCLO285,env,argv,local);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	local[7]= local[1];
	local[8]= fqv[10];
	local[9]= local[2];
	local[10]= fqv[21];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[68];
	local[13]= fqv[6];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= local[0];
	local[12]= fqv[28];
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,commonCLO286,env,argv,local);
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(pointer)MAPCAN(ctx,2,local+13); /*mapcan*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[11];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)APPEND(ctx,2,local+11); /*append*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
commonBLK281:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO285(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO286(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto commonIF287;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	goto commonIF288;
commonIF287:
	local[0]= NIL;
commonIF288:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*prog*/
static pointer commonF289(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST291:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[8];
	local[2]= fqv[9];
	local[3]= fqv[5];
	local[4]= argv[0];
	local[5]= fqv[10];
	local[6]= local[0];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK290:
	ctx->vsp=local; return(local[0]);}

/*prog**/
static pointer commonF292(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST294:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[8];
	local[2]= fqv[9];
	local[3]= fqv[50];
	local[4]= argv[0];
	local[5]= fqv[10];
	local[6]= local[0];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK293:
	ctx->vsp=local; return(local[0]);}

/*casebody*/
static pointer commonF53casebody(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto commonIF296;
	local[0]= fqv[6];
	w = argv[0];
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto commonIF297;
commonIF296:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
commonIF297:
	w = local[0];
	local[0]= w;
commonBLK295:
	ctx->vsp=local; return(local[0]);}

/*casehead*/
static pointer commonF54casehead(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[1];
	if (!!iscons(w)) goto commonIF299;
	local[0]= argv[1];
	w = fqv[71];
	if (memq(local[0],w)==NIL) goto commonIF301;
	local[0]= T;
	goto commonIF302;
commonIF301:
	local[0]= fqv[72];
	local[1]= argv[0];
	local[2]= fqv[33];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
commonIF302:
	goto commonIF300;
commonIF299:
	local[0]= fqv[73];
	local[1]= argv[0];
	local[2]= fqv[33];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
commonIF300:
	w = local[0];
	local[0]= w;
commonBLK298:
	ctx->vsp=local; return(local[0]);}

/*case1*/
static pointer commonF55case1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[1];
	if (!!iscons(w)) goto commonIF304;
	local[0]= NIL;
	goto commonIF305;
commonIF304:
	local[0]= fqv[21];
	local[1]= argv[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)commonF54casehead(ctx,2,local+1); /*casehead*/
	local[1]= w;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(pointer)commonF53casebody(ctx,1,local+2); /*casebody*/
	local[2]= w;
	local[3]= argv[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)commonF55case1(ctx,2,local+3); /*case1*/
	local[3]= w;
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,5,local+0); /*list*/
	local[0]= w;
commonIF305:
	w = local[0];
	local[0]= w;
commonBLK303:
	ctx->vsp=local; return(local[0]);}

/*case*/
static pointer commonF306(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST308:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[74];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= NIL;
	local[3]= fqv[5];
	local[4]= local[1];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)commonF55case1(ctx,2,local+5); /*case1*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[0]= w;
commonBLK307:
	ctx->vsp=local; return(local[0]);}

/*classcasehead*/
static pointer commonF56classcasehead(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	w = fqv[75];
	if (memq(local[0],w)==NIL) goto commonIF310;
	local[0]= T;
	goto commonIF311;
commonIF310:
	w = argv[1];
	if (!!iscons(w)) goto commonIF312;
	local[0]= fqv[76];
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto commonIF313;
commonIF312:
	local[0]= fqv[77];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,commonCLO314,env,argv,local);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
commonIF313:
commonIF311:
	w = local[0];
	local[0]= w;
commonBLK309:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO314(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[76];
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*classcase1*/
static pointer commonF57classcase1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[1];
	if (!!iscons(w)) goto commonIF316;
	local[0]= NIL;
	goto commonIF317;
commonIF316:
	local[0]= fqv[21];
	local[1]= argv[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)commonF56classcasehead(ctx,2,local+1); /*classcasehead*/
	local[1]= w;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	ctx->vsp=local+3;
	w=(pointer)commonF53casebody(ctx,1,local+2); /*casebody*/
	local[2]= w;
	local[3]= argv[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	ctx->vsp=local+5;
	w=(pointer)commonF57classcase1(ctx,2,local+3); /*classcase1*/
	local[3]= w;
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,5,local+0); /*list*/
	local[0]= w;
commonIF317:
	w = local[0];
	local[0]= w;
commonBLK315:
	ctx->vsp=local; return(local[0]);}

/*classcase*/
static pointer commonF318(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST320:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[78];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[5];
	local[3]= local[1];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)commonF57classcase1(ctx,2,local+4); /*classcase1*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
commonBLK319:
	ctx->vsp=local; return(local[0]);}

/*string*/
static pointer commonF58string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!isstring(w)) goto commonIF322;
	local[0]= argv[0];
	goto commonIF323;
commonIF322:
	w = argv[0];
	if (!issymbol(w)) goto commonIF324;
	local[0]= *(ovafptr(argv[0],fqv[79]));
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
	goto commonIF325;
commonIF324:
	w = argv[0];
	if (!numberp(w)) goto commonIF326;
	local[0]= NIL;
	local[1]= fqv[80];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)XFORMAT(ctx,3,local+0); /*format*/
	local[0]= w;
	goto commonIF327;
commonIF326:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
commonIF327:
commonIF325:
commonIF323:
	w = local[0];
	local[0]= w;
commonBLK321:
	ctx->vsp=local; return(local[0]);}

/*alias*/
static pointer commonF59alias(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)SYMFUNC(ctx,1,local+0); /*symbol-function*/
	local[0]= w;
	local[1]= w;
	w = argv[0];
	w->c.obj.iv[3] = local[1];
	w = local[0];
	local[0]= w;
commonBLK328:
	ctx->vsp=local; return(local[0]);}

/*caaar*/
static pointer commonF60caaar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK329:
	ctx->vsp=local; return(local[0]);}

/*caadr*/
static pointer commonF61caadr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK330:
	ctx->vsp=local; return(local[0]);}

/*cadar*/
static pointer commonF62cadar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK331:
	ctx->vsp=local; return(local[0]);}

/*cdaar*/
static pointer commonF63cdaar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
commonBLK332:
	ctx->vsp=local; return(local[0]);}

/*cdadr*/
static pointer commonF64cdadr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
commonBLK333:
	ctx->vsp=local; return(local[0]);}

/*cddar*/
static pointer commonF65cddar(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
commonBLK334:
	ctx->vsp=local; return(local[0]);}

/*cdddr*/
static pointer commonF66cdddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
commonBLK335:
	ctx->vsp=local; return(local[0]);}

/*fourth*/
static pointer commonF67fourth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK336:
	ctx->vsp=local; return(local[0]);}

/*fifth*/
static pointer commonF68fifth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK337:
	ctx->vsp=local; return(local[0]);}

/*sixth*/
static pointer commonF69sixth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF66cdddr(ctx,1,local+0); /*cdddr*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK338:
	ctx->vsp=local; return(local[0]);}

/*seventh*/
static pointer commonF70seventh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF72cddddr(ctx,1,local+0); /*cddddr*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK339:
	ctx->vsp=local; return(local[0]);}

/*eighth*/
static pointer commonF71eighth(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF72cddddr(ctx,1,local+0); /*cddddr*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)commonF73cadddr(ctx,1,local+0); /*cadddr*/
	local[0]= w;
commonBLK340:
	ctx->vsp=local; return(local[0]);}

/*cddddr*/
static pointer commonF72cddddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
commonBLK341:
	ctx->vsp=local; return(local[0]);}

/*cadddr*/
static pointer commonF73cadddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK342:
	ctx->vsp=local; return(local[0]);}

/*caaddr*/
static pointer commonF74caaddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK343:
	ctx->vsp=local; return(local[0]);}

/*cdaddr*/
static pointer commonF75cdaddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
commonBLK344:
	ctx->vsp=local; return(local[0]);}

/*caddddr*/
static pointer commonF76caddddr(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF66cdddr(ctx,1,local+0); /*cdddr*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
commonBLK345:
	ctx->vsp=local; return(local[0]);}

/*flatten*/
static pointer commonF77flatten(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto commonENT348;}
	local[0]= NIL;
commonENT348:
commonENT347:
	if (n>2) maerror();
	if (argv[0]!=NIL) goto commonCON350;
	local[1]= local[0];
	goto commonCON349;
commonCON350:
	w = argv[0];
	if (!!iscons(w)) goto commonCON351;
	local[1]= argv[0];
	w = local[0];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON349;
commonCON351:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)commonF77flatten(ctx,2,local+2); /*flatten*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)commonF77flatten(ctx,2,local+1); /*flatten*/
	local[1]= w;
	goto commonCON349;
commonCON352:
	local[1]= NIL;
commonCON349:
	w = local[1];
	local[0]= w;
commonBLK346:
	ctx->vsp=local; return(local[0]);}

/*list-insert*/
static pointer commonF78list_insert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]!=NIL) goto commonCON355;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto commonCON354;
commonCON355:
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto commonCON356;
	local[0]= argv[2];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	local[0]= w;
	goto commonCON354;
commonCON356:
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto commonCON357;
	local[0]= argv[0];
	w = argv[2];
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto commonCON354;
commonCON357:
	local[0]= argv[0];
	local[1]= argv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)NTHCDR(ctx,2,local+1); /*nthcdr*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)NTHCDR(ctx,2,local+1); /*nthcdr*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)RPLACD(ctx,2,local+1); /*rplacd*/
	w = argv[2];
	local[0]= w;
	goto commonCON354;
commonCON358:
	local[0]= NIL;
commonCON354:
	w = local[0];
	local[0]= w;
commonBLK353:
	ctx->vsp=local; return(local[0]);}

/*list-delete*/
static pointer commonF79list_delete(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto commonIF360;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[0]= argv[0];
	goto commonIF361;
commonIF360:
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)NTHCDR(ctx,2,local+0); /*nthcdr*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)NTHCDR(ctx,2,local+1); /*nthcdr*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)RPLACD(ctx,2,local+0); /*rplacd*/
	local[0]= w;
commonIF361:
	w = argv[0];
	local[0]= w;
commonBLK359:
	ctx->vsp=local; return(local[0]);}

/*adjoin*/
static pointer commonF80adjoin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[81], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY363;
	local[0] = (pointer)get_sym_func(fqv[72]);
commonKEY363:
	if (n & (1<<1)) goto commonKEY364;
	local[1] = NIL;
commonKEY364:
	if (n & (1<<2)) goto commonKEY365;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY365:
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= fqv[23];
	local[6]= local[0];
	local[7]= fqv[24];
	local[8]= local[1];
	local[9]= fqv[25];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)commonF92member(ctx,8,local+3); /*member*/
	if (w==NIL) goto commonIF366;
	local[3]= argv[1];
	goto commonIF367;
commonIF366:
	local[3]= argv[0];
	w = argv[1];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
commonIF367:
	w = local[3];
	local[0]= w;
commonBLK362:
	ctx->vsp=local; return(local[0]);}

/*union*/
static pointer commonF81union(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[83], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY369;
	local[0] = (pointer)get_sym_func(fqv[72]);
commonKEY369:
	if (n & (1<<1)) goto commonKEY370;
	local[1] = NIL;
commonKEY370:
	if (n & (1<<2)) goto commonKEY371;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY371:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
commonWHL372:
	if (local[5]==NIL) goto commonWHX373;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	local[6]= w;
	local[7]= local[3];
	local[8]= fqv[23];
	local[9]= local[0];
	local[10]= fqv[24];
	local[11]= local[1];
	local[12]= fqv[25];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)commonF92member(ctx,8,local+6); /*member*/
	if (w!=NIL) goto commonIF375;
	local[6]= local[4];
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	local[6]= local[3];
	goto commonIF376;
commonIF375:
	local[6]= NIL;
commonIF376:
	goto commonWHL372;
commonWHX373:
	local[6]= NIL;
commonBLK374:
	w = NIL;
	local[4]= NIL;
	local[5]= argv[1];
commonWHL377:
	if (local[5]==NIL) goto commonWHX378;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	local[6]= w;
	local[7]= local[3];
	local[8]= fqv[23];
	local[9]= local[0];
	local[10]= fqv[24];
	local[11]= local[1];
	local[12]= fqv[25];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)commonF92member(ctx,8,local+6); /*member*/
	if (w!=NIL) goto commonIF380;
	local[6]= local[4];
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	local[6]= local[3];
	goto commonIF381;
commonIF380:
	local[6]= NIL;
commonIF381:
	goto commonWHL377;
commonWHX378:
	local[6]= NIL;
commonBLK379:
	w = NIL;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)REVERSE(ctx,1,local+4); /*reverse*/
	local[0]= w;
commonBLK368:
	ctx->vsp=local; return(local[0]);}

/*intersection*/
static pointer commonF82intersection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[84], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY383;
	local[0] = (pointer)get_sym_func(fqv[72]);
commonKEY383:
	if (n & (1<<1)) goto commonKEY384;
	local[1] = NIL;
commonKEY384:
	if (n & (1<<2)) goto commonKEY385;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY385:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
commonWHL386:
	if (local[5]==NIL) goto commonWHX387;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= fqv[23];
	local[9]= local[0];
	local[10]= fqv[24];
	local[11]= local[1];
	local[12]= fqv[25];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)commonF92member(ctx,8,local+6); /*member*/
	if (w==NIL) goto commonIF389;
	local[6]= local[4];
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	local[6]= local[3];
	goto commonIF390;
commonIF389:
	local[6]= NIL;
commonIF390:
	goto commonWHL386;
commonWHX387:
	local[6]= NIL;
commonBLK388:
	w = NIL;
	w = local[3];
	local[0]= w;
commonBLK382:
	ctx->vsp=local; return(local[0]);}

/*set-difference*/
static pointer commonF83set_difference(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[85], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY392;
	local[0] = (pointer)get_sym_func(fqv[72]);
commonKEY392:
	if (n & (1<<1)) goto commonKEY393;
	local[1] = NIL;
commonKEY393:
	if (n & (1<<2)) goto commonKEY394;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY394:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0];
commonWHL395:
	if (local[5]==NIL) goto commonWHX396;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= fqv[23];
	local[9]= local[0];
	local[10]= fqv[24];
	local[11]= local[1];
	local[12]= fqv[25];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)commonF92member(ctx,8,local+6); /*member*/
	if (w!=NIL) goto commonIF398;
	local[6]= local[4];
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	local[6]= local[3];
	goto commonIF399;
commonIF398:
	local[6]= NIL;
commonIF399:
	goto commonWHL395;
commonWHX396:
	local[6]= NIL;
commonBLK397:
	w = NIL;
	local[4]= local[3];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[0]= w;
commonBLK391:
	ctx->vsp=local; return(local[0]);}

/*set-exclusive-or*/
static pointer commonF84set_exclusive_or(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[86], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY401;
	local[0] = (pointer)get_sym_func(fqv[72]);
commonKEY401:
	if (n & (1<<1)) goto commonKEY402;
	local[1] = NIL;
commonKEY402:
	if (n & (1<<2)) goto commonKEY403;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY403:
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
commonWHL404:
	if (local[6]==NIL) goto commonWHX405;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[2];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,2,local+7); /*funcall*/
	local[5] = w;
	local[7]= local[5];
	local[8]= argv[1];
	local[9]= fqv[23];
	local[10]= local[0];
	local[11]= fqv[24];
	local[12]= local[1];
	local[13]= fqv[25];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)commonF92member(ctx,8,local+7); /*member*/
	if (w!=NIL) goto commonIF407;
	local[7]= local[5];
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[7]= local[3];
	goto commonIF408;
commonIF407:
	local[7]= NIL;
commonIF408:
	goto commonWHL404;
commonWHX405:
	local[7]= NIL;
commonBLK406:
	w = NIL;
	local[5]= NIL;
	local[6]= argv[1];
commonWHL409:
	if (local[6]==NIL) goto commonWHX410;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	local[7]= local[2];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,2,local+7); /*funcall*/
	local[5] = w;
	local[7]= local[5];
	local[8]= argv[0];
	local[9]= fqv[23];
	local[10]= local[0];
	local[11]= fqv[24];
	local[12]= local[1];
	local[13]= fqv[25];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)commonF92member(ctx,8,local+7); /*member*/
	if (w!=NIL) goto commonIF412;
	local[7]= local[5];
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	local[7]= local[4];
	goto commonIF413;
commonIF412:
	local[7]= NIL;
commonIF413:
	goto commonWHL409;
commonWHX410:
	local[7]= NIL;
commonBLK411:
	w = NIL;
	local[5]= local[3];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	local[0]= w;
commonBLK400:
	ctx->vsp=local; return(local[0]);}

/*rotate-list*/
static pointer commonF85rotate_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
commonBLK414:
	ctx->vsp=local; return(local[0]);}

/*last*/
static pointer commonF86last(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
commonWHL416:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	if (!iscons(w)) goto commonWHX417;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	goto commonWHL416;
commonWHX417:
	local[0]= NIL;
commonBLK418:
	w = argv[0];
	local[0]= w;
commonBLK415:
	ctx->vsp=local; return(local[0]);}

/*copy-tree*/
static pointer commonF87copy_tree(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= T;
	local[1]= T;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SUBST(ctx,3,local+0); /*subst*/
	local[0]= w;
commonBLK419:
	ctx->vsp=local; return(local[0]);}

/*copy-list*/
static pointer commonF88copy_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)REVERSE(ctx,1,local+0); /*reverse*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)NREVERSE(ctx,1,local+0); /*nreverse*/
	local[0]= w;
commonBLK420:
	ctx->vsp=local; return(local[0]);}

/*nreconc*/
static pointer commonF89nreconc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)NREVERSE(ctx,1,local+0); /*nreverse*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)NCONC(ctx,2,local+0); /*nconc*/
	local[0]= w;
commonBLK421:
	ctx->vsp=local; return(local[0]);}

/*rassoc*/
static pointer commonF90rassoc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[1];
commonWHL423:
	if (local[1]==NIL) goto commonWHX424;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)EQUAL(ctx,2,local+2); /*equal*/
	if (w==NIL) goto commonIF426;
	w = local[0];
	ctx->vsp=local+2;
	local[0]=w;
	goto commonBLK422;
	goto commonIF427;
commonIF426:
	local[2]= NIL;
commonIF427:
	goto commonWHL423;
commonWHX424:
	local[2]= NIL;
commonBLK425:
	w = NIL;
	local[0]= w;
commonBLK422:
	ctx->vsp=local; return(local[0]);}

/*acons*/
static pointer commonF91acons(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	w = argv[1];
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	w = argv[2];
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
commonBLK428:
	ctx->vsp=local; return(local[0]);}

/*member*/
static pointer commonF92member(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[87], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY430;
	local[0] = NIL;
commonKEY430:
	if (n & (1<<1)) goto commonKEY431;
	local[1] = NIL;
commonKEY431:
	if (n & (1<<2)) goto commonKEY432;
	local[2] = NIL;
commonKEY432:
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= local[0];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SUPERMEMBER(ctx,5,local+3); /*supermember*/
	local[0]= w;
commonBLK429:
	ctx->vsp=local; return(local[0]);}

/*assoc*/
static pointer commonF93assoc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[88], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY434;
	local[0] = NIL;
commonKEY434:
	if (n & (1<<1)) goto commonKEY435;
	local[1] = NIL;
commonKEY435:
	if (n & (1<<2)) goto commonKEY436;
	local[2] = NIL;
commonKEY436:
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= local[0];
	local[6]= local[1];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SUPERASSOC(ctx,5,local+3); /*superassoc*/
	local[0]= w;
commonBLK433:
	ctx->vsp=local; return(local[0]);}

/*subsetp*/
static pointer commonF94subsetp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[89], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY438;
	local[0] = NIL;
commonKEY438:
	if (n & (1<<1)) goto commonKEY439;
	local[1] = NIL;
commonKEY439:
	if (n & (1<<2)) goto commonKEY440;
	local[2] = NIL;
commonKEY440:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,commonCLO441,env,argv,local);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)commonF156every(ctx,2,local+3); /*every*/
	local[0]= w;
commonBLK437:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO441(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[1];
	local[2]= fqv[25];
	local[3]= env->c.clo.env2[0];
	local[4]= fqv[23];
	local[5]= env->c.clo.env2[1];
	local[6]= fqv[24];
	local[7]= env->c.clo.env2[2];
	ctx->vsp=local+8;
	w=(pointer)commonF92member(ctx,8,local+0); /*member*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*maplist*/
static pointer commonF95maplist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST443:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto commonIF444;
	local[3]= NIL;
	local[4]= NIL;
commonWHL446:
	if (argv[1]==NIL) goto commonWHX447;
	local[3] = NIL;
	local[5]= argv[1];
	w = local[3];
	ctx->vsp=local+6;
	local[3] = cons(ctx,local[5],w);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	local[4] = local[0];
commonWHL449:
	if (local[4]==NIL) goto commonWHX450;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+6;
	local[3] = cons(ctx,local[5],w);
	local[5]= local[4];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)RPLACA2(ctx,2,local+5); /*rplaca2*/
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	goto commonWHL449;
commonWHX450:
	local[5]= NIL;
commonBLK451:
	local[5]= argv[0];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	goto commonWHL446;
commonWHX447:
	local[5]= NIL;
commonBLK448:
	w = local[5];
	local[3]= w;
	goto commonIF445;
commonIF444:
commonWHL452:
	if (argv[1]==NIL) goto commonWHX453;
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,2,local+3); /*funcall*/
	local[3]= w;
	w = local[2];
	ctx->vsp=local+4;
	local[2] = cons(ctx,local[3],w);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	goto commonWHL452;
commonWHX453:
	local[3]= NIL;
commonBLK454:
commonIF445:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
commonBLK442:
	ctx->vsp=local; return(local[0]);}

/*mapcon*/
static pointer commonF96mapcon(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST456:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= NIL;
	if (local[0]==NIL) goto commonIF457;
	local[3]= NIL;
	local[4]= NIL;
commonWHL459:
	if (argv[1]==NIL) goto commonWHX460;
	local[3] = NIL;
	local[5]= argv[1];
	w = local[3];
	ctx->vsp=local+6;
	local[3] = cons(ctx,local[5],w);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	local[4] = local[0];
commonWHL462:
	if (local[4]==NIL) goto commonWHX463;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+6;
	local[3] = cons(ctx,local[5],w);
	local[5]= local[4];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.cdr;
	ctx->vsp=local+7;
	w=(pointer)RPLACA2(ctx,2,local+5); /*rplaca2*/
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	goto commonWHL462;
commonWHX463:
	local[5]= NIL;
commonBLK464:
	local[5]= argv[0];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)NREVERSE(ctx,1,local+6); /*nreverse*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[5]= w;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	local[2] = w;
	goto commonWHL459;
commonWHX460:
	local[5]= NIL;
commonBLK461:
	w = local[5];
	local[3]= w;
	goto commonIF458;
commonIF457:
commonWHL465:
	if (argv[1]==NIL) goto commonWHX466;
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,2,local+3); /*funcall*/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	local[2] = w;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	goto commonWHL465;
commonWHX466:
	local[3]= NIL;
commonBLK467:
commonIF458:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)NREVERSE(ctx,1,local+3); /*nreverse*/
	local[0]= w;
commonBLK455:
	ctx->vsp=local; return(local[0]);}

/*find*/
static pointer commonF97find(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[90], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY469;
	local[0] = makeint((eusinteger_t)0L);
commonKEY469:
	if (n & (1<<1)) goto commonKEY470;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[1] = w;
commonKEY470:
	if (n & (1<<2)) goto commonKEY471;
	local[2] = (pointer)get_sym_func(fqv[72]);
commonKEY471:
	if (n & (1<<3)) goto commonKEY472;
	local[3] = NIL;
commonKEY472:
	if (n & (1<<4)) goto commonKEY473;
	local[4] = (pointer)get_sym_func(fqv[82]);
commonKEY473:
	local[5]= argv[0];
	local[6]= argv[1];
	local[7]= local[2];
	local[8]= local[3];
	local[9]= local[4];
	local[10]= NIL;
	local[11]= NIL;
	local[12]= local[0];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)FIND(ctx,9,local+5); /*system::raw-find*/
	local[0]= w;
commonBLK468:
	ctx->vsp=local; return(local[0]);}

/*find-if*/
static pointer commonF98find_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[91], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY475;
	local[0] = makeint((eusinteger_t)0L);
commonKEY475:
	if (n & (1<<1)) goto commonKEY476;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[1] = w;
commonKEY476:
	if (n & (1<<2)) goto commonKEY477;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY477:
	local[3]= NIL;
	local[4]= argv[1];
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[2];
	local[8]= argv[0];
	local[9]= NIL;
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)FIND(ctx,9,local+3); /*system::raw-find*/
	local[0]= w;
commonBLK474:
	ctx->vsp=local; return(local[0]);}

/*find-if-not*/
static pointer commonF99find_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[92], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY479;
	local[0] = makeint((eusinteger_t)0L);
commonKEY479:
	if (n & (1<<1)) goto commonKEY480;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[1] = w;
commonKEY480:
	if (n & (1<<2)) goto commonKEY481;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY481:
	local[3]= NIL;
	local[4]= argv[1];
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[2];
	local[8]= NIL;
	local[9]= argv[0];
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)FIND(ctx,9,local+3); /*system::raw-find*/
	local[0]= w;
commonBLK478:
	ctx->vsp=local; return(local[0]);}

/*position*/
static pointer commonF100position(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[93], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY483;
	local[0] = makeint((eusinteger_t)0L);
commonKEY483:
	if (n & (1<<1)) goto commonKEY484;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[1] = w;
commonKEY484:
	if (n & (1<<2)) goto commonKEY485;
	local[2] = makeint((eusinteger_t)1L);
commonKEY485:
	if (n & (1<<3)) goto commonKEY486;
	local[3] = (pointer)get_sym_func(fqv[72]);
commonKEY486:
	if (n & (1<<4)) goto commonKEY487;
	local[4] = NIL;
commonKEY487:
	if (n & (1<<5)) goto commonKEY488;
	local[5] = (pointer)get_sym_func(fqv[82]);
commonKEY488:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= local[3];
	local[9]= local[4];
	local[10]= local[5];
	local[11]= NIL;
	local[12]= NIL;
	local[13]= local[0];
	local[14]= local[1];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)POSITION(ctx,10,local+6); /*system::raw-position*/
	local[0]= w;
commonBLK482:
	ctx->vsp=local; return(local[0]);}

/*position-if*/
static pointer commonF101position_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[94], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY490;
	local[0] = makeint((eusinteger_t)0L);
commonKEY490:
	if (n & (1<<1)) goto commonKEY491;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY491:
	if (n & (1<<2)) goto commonKEY492;
	local[2] = makeint((eusinteger_t)1L);
commonKEY492:
	if (n & (1<<3)) goto commonKEY493;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY493:
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= NIL;
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)POSITION(ctx,10,local+4); /*system::raw-position*/
	local[0]= w;
commonBLK489:
	ctx->vsp=local; return(local[0]);}

/*position-if-not*/
static pointer commonF102position_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[95], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY495;
	local[0] = makeint((eusinteger_t)0L);
commonKEY495:
	if (n & (1<<1)) goto commonKEY496;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY496:
	if (n & (1<<2)) goto commonKEY497;
	local[2] = makeint((eusinteger_t)1L);
commonKEY497:
	if (n & (1<<3)) goto commonKEY498;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY498:
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)POSITION(ctx,10,local+4); /*system::raw-position*/
	local[0]= w;
commonBLK494:
	ctx->vsp=local; return(local[0]);}

/*count*/
static pointer commonF103count(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[96], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY500;
	local[0] = makeint((eusinteger_t)0L);
commonKEY500:
	if (n & (1<<1)) goto commonKEY501;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[1] = w;
commonKEY501:
	if (n & (1<<2)) goto commonKEY502;
	local[2] = (pointer)get_sym_func(fqv[72]);
commonKEY502:
	if (n & (1<<3)) goto commonKEY503;
	local[3] = NIL;
commonKEY503:
	if (n & (1<<4)) goto commonKEY504;
	local[4] = (pointer)get_sym_func(fqv[82]);
commonKEY504:
	local[5]= argv[0];
	local[6]= argv[1];
	local[7]= local[2];
	local[8]= local[3];
	local[9]= local[4];
	local[10]= NIL;
	local[11]= NIL;
	local[12]= local[0];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)COUNT(ctx,9,local+5); /*system::raw-count*/
	local[0]= w;
commonBLK499:
	ctx->vsp=local; return(local[0]);}

/*count-if*/
static pointer commonF104count_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[97], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY506;
	local[0] = makeint((eusinteger_t)0L);
commonKEY506:
	if (n & (1<<1)) goto commonKEY507;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[1] = w;
commonKEY507:
	if (n & (1<<2)) goto commonKEY508;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY508:
	local[3]= NIL;
	local[4]= argv[1];
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[2];
	local[8]= argv[0];
	local[9]= NIL;
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)COUNT(ctx,9,local+3); /*system::raw-count*/
	local[0]= w;
commonBLK505:
	ctx->vsp=local; return(local[0]);}

/*count-if-not*/
static pointer commonF105count_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[98], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY510;
	local[0] = makeint((eusinteger_t)0L);
commonKEY510:
	if (n & (1<<1)) goto commonKEY511;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[1] = w;
commonKEY511:
	if (n & (1<<2)) goto commonKEY512;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY512:
	local[3]= NIL;
	local[4]= argv[1];
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[2];
	local[8]= NIL;
	local[9]= argv[0];
	local[10]= local[0];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)COUNT(ctx,9,local+3); /*system::raw-count*/
	local[0]= w;
commonBLK509:
	ctx->vsp=local; return(local[0]);}

/*member-if*/
static pointer commonF106member_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[99], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY514;
	local[0] = (pointer)get_sym_func(fqv[82]);
commonKEY514:
commonWHL515:
	if (argv[1]==NIL) goto commonWHX516;
	local[1]= argv[0];
	local[2]= local[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)FUNCALL(ctx,2,local+2); /*funcall*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,2,local+1); /*funcall*/
	if (w==NIL) goto commonIF518;
	w = argv[1];
	ctx->vsp=local+1;
	local[0]=w;
	goto commonBLK513;
	goto commonIF519;
commonIF518:
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	local[1]= argv[1];
commonIF519:
	goto commonWHL515;
commonWHX516:
	local[1]= NIL;
commonBLK517:
	w = local[1];
	local[0]= w;
commonBLK513:
	ctx->vsp=local; return(local[0]);}

/*member-if-not*/
static pointer commonF107member_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[100], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY521;
	local[0] = (pointer)get_sym_func(fqv[82]);
commonKEY521:
commonWHL522:
	if (argv[1]==NIL) goto commonWHX523;
	local[1]= argv[0];
	local[2]= local[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)FUNCALL(ctx,2,local+2); /*funcall*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,2,local+1); /*funcall*/
	if (w!=NIL) goto commonIF525;
	w = argv[1];
	ctx->vsp=local+1;
	local[0]=w;
	goto commonBLK520;
	goto commonIF526;
commonIF525:
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	local[1]= argv[1];
commonIF526:
	goto commonWHL522;
commonWHX523:
	local[1]= NIL;
commonBLK524:
	w = local[1];
	local[0]= w;
commonBLK520:
	ctx->vsp=local; return(local[0]);}

/*collect-if*/
static pointer commonF108collect_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[1];
commonWHL528:
	if (local[3]==NIL) goto commonWHX529;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= argv[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,2,local+4); /*funcall*/
	if (w==NIL) goto commonIF531;
	local[4]= local[2];
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto commonIF532;
commonIF531:
	local[4]= NIL;
commonIF532:
	goto commonWHL528;
commonWHX529:
	local[4]= NIL;
commonBLK530:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
commonBLK527:
	ctx->vsp=local; return(local[0]);}

/*collect-instances*/
static pointer commonF109collect_instances(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,commonCLO534,env,argv,local);
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)commonF77flatten(ctx,1,local+1); /*flatten*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)commonF108collect_if(ctx,2,local+0); /*collect-if*/
	local[0]= w;
commonBLK533:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO534(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env1[0];
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*pairlis*/
static pointer commonF110pairlis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto commonENT537;}
	local[0]= NIL;
commonENT537:
commonENT536:
	if (n>3) maerror();
	if (argv[0]==NIL) goto commonIF538;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)commonF110pairlis(ctx,3,local+2); /*pairlis*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonIF539;
commonIF538:
	local[1]= local[0];
commonIF539:
	w = local[1];
	local[0]= w;
commonBLK535:
	ctx->vsp=local; return(local[0]);}

/*transpose-list*/
static pointer commonF111transpose_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
commonWHL541:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto commonWHX542;
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,commonCLO544,env,argv,local);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto commonWHL541;
commonWHX542:
	local[3]= NIL;
commonBLK543:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)NREVERSE(ctx,1,local+1); /*nreverse*/
	local[0]= w;
commonBLK540:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO544(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[1];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-list*/
static pointer commonF112make_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[101], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto commonKEY546;
	local[0] = NIL;
commonKEY546:
	local[1]= NIL;
	w = argv[0];
	if (isint(w)) goto commonIF547;
	local[2]= fqv[102];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto commonIF548;
commonIF547:
	local[2]= NIL;
commonIF548:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0];
commonWHL549:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto commonWHX550;
	local[4]= local[0];
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto commonWHL549;
commonWHX550:
	local[4]= NIL;
commonBLK551:
	w = local[1];
	local[0]= w;
commonBLK545:
	ctx->vsp=local; return(local[0]);}

/*make-sequence*/
static pointer commonF113make_sequence(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[103], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY553;
	local[0] = NIL;
commonKEY553:
	local[1]= argv[0];
	w = fqv[104];
	if (memq(local[1],w)!=NIL) goto commonOR556;
	local[1]= argv[0];
	if (loadglobal(fqv[19])==local[1]) goto commonOR556;
	goto commonIF554;
commonOR556:
	local[1]= argv[1];
	local[2]= fqv[105];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)commonF112make_list(ctx,3,local+1); /*make-list*/
	local[1]= w;
	goto commonIF555;
commonIF554:
	local[1]= argv[1];
	local[2]= fqv[106];
	local[3]= argv[0];
	local[4]= fqv[105];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[0])(ctx,5,local+1,&ftab[0],fqv[107]); /*make-array*/
	local[1]= w;
commonIF555:
	w = local[1];
	local[0]= w;
commonBLK552:
	ctx->vsp=local; return(local[0]);}

/*fill*/
static pointer commonF114fill(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[108], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY558;
	local[0] = makeint((eusinteger_t)0L);
commonKEY558:
	if (n & (1<<1)) goto commonKEY559;
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[1] = w;
commonKEY559:
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)FILL(ctx,4,local+2); /*system::raw-fill*/
	local[0]= w;
commonBLK557:
	ctx->vsp=local; return(local[0]);}

/*replace*/
static pointer commonF115replace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[109], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY561;
	local[0] = makeint((eusinteger_t)0L);
commonKEY561:
	if (n & (1<<1)) goto commonKEY562;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY562:
	if (n & (1<<2)) goto commonKEY563;
	local[2] = makeint((eusinteger_t)0L);
commonKEY563:
	if (n & (1<<3)) goto commonKEY564;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[3] = w;
commonKEY564:
	local[4]= argv[0];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	local[5]= w;
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LISTP(ctx,1,local+6); /*listp*/
	if (w==NIL) goto commonCON566;
	local[6]= local[0];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)NTHCDR(ctx,2,local+6); /*nthcdr*/
	argv[0] = w;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LISTP(ctx,1,local+6); /*listp*/
	if (w==NIL) goto commonCON568;
	local[6]= local[2];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)NTHCDR(ctx,2,local+6); /*nthcdr*/
	argv[1] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[5];
commonWHL569:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto commonWHX570;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= w;
	local[9]= w;
	*(ovafptr(argv[0],fqv[16])) = local[9];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto commonWHL569;
commonWHX570:
	local[8]= NIL;
commonBLK571:
	w = NIL;
	local[6]= w;
	goto commonCON567;
commonCON568:
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[5];
commonWHL573:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto commonWHX574;
	local[8]= argv[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	local[9]= w;
	*(ovafptr(argv[0],fqv[16])) = local[9];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[2] = w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[8];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto commonWHL573;
commonWHX574:
	local[8]= NIL;
commonBLK575:
	w = NIL;
	local[6]= w;
	goto commonCON567;
commonCON572:
	local[6]= NIL;
commonCON567:
	goto commonCON565;
commonCON566:
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LISTP(ctx,1,local+6); /*listp*/
	if (w==NIL) goto commonCON576;
	local[6]= local[2];
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)NTHCDR(ctx,2,local+6); /*nthcdr*/
	argv[1] = w;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= local[5];
commonWHL577:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto commonWHX578;
	local[8]= argv[0];
	local[9]= local[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[10];
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ASET(ctx,3,local+8); /*aset*/
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[0] = w;
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto commonWHL577;
commonWHX578:
	local[8]= NIL;
commonBLK579:
	w = NIL;
	local[6]= w;
	goto commonCON565;
commonCON576:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)VECREPLACE(ctx,6,local+6); /*system::vector-replace*/
	local[6]= w;
	goto commonCON565;
commonCON580:
	local[6]= NIL;
commonCON565:
	w = local[4];
	local[0]= w;
commonBLK560:
	ctx->vsp=local; return(local[0]);}

/*remove*/
static pointer commonF116remove(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[110], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY582;
	local[0] = makeint((eusinteger_t)0L);
commonKEY582:
	if (n & (1<<1)) goto commonKEY583;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[1] = w;
commonKEY583:
	if (n & (1<<2)) goto commonKEY584;
	local[2] = (pointer)get_sym_func(fqv[72]);
commonKEY584:
	if (n & (1<<3)) goto commonKEY585;
	local[3] = NIL;
commonKEY585:
	if (n & (1<<4)) goto commonKEY586;
	local[4] = makeint((eusinteger_t)1000000L);
commonKEY586:
	if (n & (1<<5)) goto commonKEY587;
	local[5] = (pointer)get_sym_func(fqv[82]);
commonKEY587:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= local[5];
	local[11]= NIL;
	local[12]= NIL;
	local[13]= local[0];
	local[14]= local[1];
	local[15]= local[4];
	ctx->vsp=local+16;
	w=(pointer)UNIREMOVE(ctx,10,local+6); /*system::universal-remove*/
	local[0]= w;
commonBLK581:
	ctx->vsp=local; return(local[0]);}

/*remove-if*/
static pointer commonF117remove_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[111], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY589;
	local[0] = makeint((eusinteger_t)0L);
commonKEY589:
	if (n & (1<<1)) goto commonKEY590;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY590:
	if (n & (1<<2)) goto commonKEY591;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY591:
	if (n & (1<<3)) goto commonKEY592;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY592:
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= NIL;
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)UNIREMOVE(ctx,10,local+4); /*system::universal-remove*/
	local[0]= w;
commonBLK588:
	ctx->vsp=local; return(local[0]);}

/*remove-if-not*/
static pointer commonF118remove_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[112], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY594;
	local[0] = makeint((eusinteger_t)0L);
commonKEY594:
	if (n & (1<<1)) goto commonKEY595;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY595:
	if (n & (1<<2)) goto commonKEY596;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY596:
	if (n & (1<<3)) goto commonKEY597;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY597:
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)UNIREMOVE(ctx,10,local+4); /*system::universal-remove*/
	local[0]= w;
commonBLK593:
	ctx->vsp=local; return(local[0]);}

/*delete*/
static pointer commonF119delete(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[113], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY599;
	local[0] = makeint((eusinteger_t)0L);
commonKEY599:
	if (n & (1<<1)) goto commonKEY600;
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[1] = w;
commonKEY600:
	if (n & (1<<2)) goto commonKEY601;
	local[2] = (pointer)get_sym_func(fqv[72]);
commonKEY601:
	if (n & (1<<3)) goto commonKEY602;
	local[3] = NIL;
commonKEY602:
	if (n & (1<<4)) goto commonKEY603;
	local[4] = makeint((eusinteger_t)1000000L);
commonKEY603:
	if (n & (1<<5)) goto commonKEY604;
	local[5] = (pointer)get_sym_func(fqv[82]);
commonKEY604:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= local[5];
	local[11]= NIL;
	local[12]= NIL;
	local[13]= local[0];
	local[14]= local[1];
	local[15]= local[4];
	ctx->vsp=local+16;
	w=(pointer)DELETE(ctx,10,local+6); /*system::raw-delete*/
	local[0]= w;
commonBLK598:
	ctx->vsp=local; return(local[0]);}

/*delete-if*/
static pointer commonF120delete_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[114], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY606;
	local[0] = makeint((eusinteger_t)0L);
commonKEY606:
	if (n & (1<<1)) goto commonKEY607;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY607:
	if (n & (1<<2)) goto commonKEY608;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY608:
	if (n & (1<<3)) goto commonKEY609;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY609:
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= argv[0];
	local[10]= NIL;
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)DELETE(ctx,10,local+4); /*system::raw-delete*/
	local[0]= w;
commonBLK605:
	ctx->vsp=local; return(local[0]);}

/*delete-if-not*/
static pointer commonF121delete_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[115], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY611;
	local[0] = makeint((eusinteger_t)0L);
commonKEY611:
	if (n & (1<<1)) goto commonKEY612;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY612:
	if (n & (1<<2)) goto commonKEY613;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY613:
	if (n & (1<<3)) goto commonKEY614;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY614:
	local[4]= NIL;
	local[5]= argv[1];
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[3];
	local[9]= NIL;
	local[10]= argv[0];
	local[11]= local[0];
	local[12]= local[1];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)DELETE(ctx,10,local+4); /*system::raw-delete*/
	local[0]= w;
commonBLK610:
	ctx->vsp=local; return(local[0]);}

/*substitute*/
static pointer commonF122substitute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[116], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto commonKEY616;
	local[0] = makeint((eusinteger_t)0L);
commonKEY616:
	if (n & (1<<1)) goto commonKEY617;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[1] = w;
commonKEY617:
	if (n & (1<<2)) goto commonKEY618;
	local[2] = (pointer)get_sym_func(fqv[72]);
commonKEY618:
	if (n & (1<<3)) goto commonKEY619;
	local[3] = NIL;
commonKEY619:
	if (n & (1<<4)) goto commonKEY620;
	local[4] = makeint((eusinteger_t)1000000L);
commonKEY620:
	if (n & (1<<5)) goto commonKEY621;
	local[5] = (pointer)get_sym_func(fqv[82]);
commonKEY621:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= argv[2];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[5];
	local[12]= NIL;
	local[13]= NIL;
	local[14]= local[0];
	local[15]= local[1];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SUBSTITUTE(ctx,11,local+6); /*system::raw-substitute*/
	local[0]= w;
commonBLK615:
	ctx->vsp=local; return(local[0]);}

/*substitute-if*/
static pointer commonF123substitute_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[117], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto commonKEY623;
	local[0] = makeint((eusinteger_t)0L);
commonKEY623:
	if (n & (1<<1)) goto commonKEY624;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY624:
	if (n & (1<<2)) goto commonKEY625;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY625:
	if (n & (1<<3)) goto commonKEY626;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY626:
	local[4]= argv[0];
	local[5]= NIL;
	local[6]= argv[2];
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[3];
	local[10]= argv[1];
	local[11]= NIL;
	local[12]= local[0];
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)SUBSTITUTE(ctx,11,local+4); /*system::raw-substitute*/
	local[0]= w;
commonBLK622:
	ctx->vsp=local; return(local[0]);}

/*substitute-if-not*/
static pointer commonF124substitute_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[118], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto commonKEY628;
	local[0] = makeint((eusinteger_t)0L);
commonKEY628:
	if (n & (1<<1)) goto commonKEY629;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY629:
	if (n & (1<<2)) goto commonKEY630;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY630:
	if (n & (1<<3)) goto commonKEY631;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY631:
	local[4]= argv[0];
	local[5]= NIL;
	local[6]= argv[2];
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[3];
	local[10]= NIL;
	local[11]= argv[1];
	local[12]= local[0];
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)SUBSTITUTE(ctx,11,local+4); /*system::raw-substitute*/
	local[0]= w;
commonBLK627:
	ctx->vsp=local; return(local[0]);}

/*nsubstitute*/
static pointer commonF125nsubstitute(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[119], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto commonKEY633;
	local[0] = makeint((eusinteger_t)0L);
commonKEY633:
	if (n & (1<<1)) goto commonKEY634;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[1] = w;
commonKEY634:
	if (n & (1<<2)) goto commonKEY635;
	local[2] = (pointer)get_sym_func(fqv[72]);
commonKEY635:
	if (n & (1<<3)) goto commonKEY636;
	local[3] = NIL;
commonKEY636:
	if (n & (1<<4)) goto commonKEY637;
	local[4] = makeint((eusinteger_t)1000000L);
commonKEY637:
	if (n & (1<<5)) goto commonKEY638;
	local[5] = (pointer)get_sym_func(fqv[82]);
commonKEY638:
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= argv[2];
	local[9]= local[2];
	local[10]= local[3];
	local[11]= local[5];
	local[12]= NIL;
	local[13]= NIL;
	local[14]= local[0];
	local[15]= local[1];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)NSUBSTITUTE(ctx,11,local+6); /*system::raw-nsubstitute*/
	local[0]= w;
commonBLK632:
	ctx->vsp=local; return(local[0]);}

/*nsubstitute-if*/
static pointer commonF126nsubstitute_if(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[120], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto commonKEY640;
	local[0] = makeint((eusinteger_t)0L);
commonKEY640:
	if (n & (1<<1)) goto commonKEY641;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY641:
	if (n & (1<<2)) goto commonKEY642;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY642:
	if (n & (1<<3)) goto commonKEY643;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY643:
	local[4]= argv[0];
	local[5]= NIL;
	local[6]= argv[2];
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[3];
	local[10]= argv[1];
	local[11]= NIL;
	local[12]= local[0];
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)NSUBSTITUTE(ctx,11,local+4); /*system::raw-nsubstitute*/
	local[0]= w;
commonBLK639:
	ctx->vsp=local; return(local[0]);}

/*nsubstitute-if-not*/
static pointer commonF127nsubstitute_if_not(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[121], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto commonKEY645;
	local[0] = makeint((eusinteger_t)0L);
commonKEY645:
	if (n & (1<<1)) goto commonKEY646;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY646:
	if (n & (1<<2)) goto commonKEY647;
	local[2] = makeint((eusinteger_t)1000000L);
commonKEY647:
	if (n & (1<<3)) goto commonKEY648;
	local[3] = (pointer)get_sym_func(fqv[82]);
commonKEY648:
	local[4]= argv[0];
	local[5]= NIL;
	local[6]= argv[2];
	local[7]= NIL;
	local[8]= NIL;
	local[9]= local[3];
	local[10]= NIL;
	local[11]= argv[1];
	local[12]= local[0];
	local[13]= local[1];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)NSUBSTITUTE(ctx,11,local+4); /*system::raw-nsubstitute*/
	local[0]= w;
commonBLK644:
	ctx->vsp=local; return(local[0]);}

/*unique*/
static pointer commonF128unique(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	if (!!iscons(w)) goto commonCON651;
	local[0]= argv[0];
	goto commonCON650;
commonCON651:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	if (memq(local[0],w)==NIL) goto commonCON652;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	ctx->vsp=local+1;
	w=(pointer)commonF128unique(ctx,1,local+0); /*unique*/
	local[0]= w;
	goto commonCON650;
commonCON652:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)commonF128unique(ctx,1,local+1); /*unique*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto commonCON650;
commonCON653:
	local[0]= NIL;
commonCON650:
	w = local[0];
	local[0]= w;
commonBLK649:
	ctx->vsp=local; return(local[0]);}

/*remove-duplicates*/
static pointer commonF129remove_duplicates(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[122], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto commonKEY655;
	local[0] = (pointer)get_sym_func(fqv[72]);
commonKEY655:
	if (n & (1<<1)) goto commonKEY656;
	local[1] = NIL;
commonKEY656:
	if (n & (1<<2)) goto commonKEY657;
	local[2] = (pointer)get_sym_func(fqv[82]);
commonKEY657:
	if (n & (1<<3)) goto commonKEY658;
	local[3] = makeint((eusinteger_t)0L);
commonKEY658:
	if (n & (1<<4)) goto commonKEY659;
	local[4] = makeint((eusinteger_t)1000000L);
commonKEY659:
	local[5]= argv[0];
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)REMOVE_DUPLICATES(ctx,6,local+5); /*system::raw-remove-duplicates*/
	local[0]= w;
commonBLK654:
	ctx->vsp=local; return(local[0]);}

/*extream*/
static pointer commonF130extream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto commonENT662;}
	local[0]= (pointer)get_sym_func(fqv[82]);
commonENT662:
commonENT661:
	if (n>3) maerror();
	if (argv[0]!=NIL) goto commonIF663;
	local[1]= NIL;
	goto commonIF664;
commonIF663:
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)FUNCALL(ctx,2,local+2); /*funcall*/
	local[2]= w;
	local[3]= NIL;
	w = argv[0];
	if (!iscons(w)) goto commonIF665;
	local[4]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.cdr;
commonWHL667:
	if (local[5]==NIL) goto commonWHX668;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= argv[1];
	local[7]= local[0];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,2,local+7); /*funcall*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,3,local+6); /*funcall*/
	if (w==NIL) goto commonIF670;
	local[1] = local[4];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	local[2] = w;
	local[6]= local[2];
	goto commonIF671;
commonIF670:
	local[6]= NIL;
commonIF671:
	goto commonWHL667;
commonWHX668:
	local[6]= NIL;
commonBLK669:
	w = NIL;
	local[4]= w;
	goto commonIF666;
commonIF665:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
commonWHL672:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto commonWHX673;
	local[6]= argv[1];
	local[7]= local[0];
	local[8]= argv[0];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[3] = w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,2,local+7); /*funcall*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,3,local+6); /*funcall*/
	if (w==NIL) goto commonIF675;
	local[1] = local[3];
	local[6]= local[0];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,2,local+6); /*funcall*/
	local[2] = w;
	local[6]= local[2];
	goto commonIF676;
commonIF675:
	local[6]= NIL;
commonIF676:
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto commonWHL672;
commonWHX673:
	local[6]= NIL;
commonBLK674:
	w = NIL;
	local[4]= w;
commonIF666:
	w = local[1];
	local[1]= w;
commonIF664:
	w = local[1];
	local[0]= w;
commonBLK660:
	ctx->vsp=local; return(local[0]);}

/*send-super-lexpr*/
static pointer commonF677(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST679:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[123];
	local[2]= fqv[124];
	local[3]= fqv[125];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[126];
	local[4]= fqv[127];
	w = fqv[128];
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= argv[0];
	w = local[0];
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK678:
	ctx->vsp=local; return(local[0]);}

/*send-super**/
static pointer commonF680(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST682:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[123];
	local[2]= fqv[124];
	local[3]= fqv[125];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[126];
	local[4]= fqv[127];
	w = fqv[128];
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[0];
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK681:
	ctx->vsp=local; return(local[0]);}

/*send-lexpr*/
static pointer commonF683(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST685:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[123];
	local[2]= fqv[124];
	local[3]= fqv[32];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= argv[0];
	local[4]= argv[1];
	w = local[0];
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK684:
	ctx->vsp=local; return(local[0]);}

/*send**/
static pointer commonF686(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST688:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[123];
	local[2]= fqv[124];
	local[3]= fqv[32];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	w = local[0];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK687:
	ctx->vsp=local; return(local[0]);}

/*send-super*/
static pointer commonF689(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST691:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[125];
	local[2]= fqv[126];
	local[3]= fqv[127];
	w = fqv[128];
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= NIL;
	ctx->vsp=local+7;
	w=(pointer)APPEND(ctx,2,local+5); /*append*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK690:
	ctx->vsp=local; return(local[0]);}

/*send-all*/
static pointer commonF131send_all(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST693:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,commonCLO694,env,argv,local);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[0]= w;
commonBLK692:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO694(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= fqv[32];
	local[1]= argv[0];
	local[2]= env->c.clo.env2[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*resend*/
static pointer commonF132resend(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[32];
	local[1]= argv[0];
	w = argv[1];
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	ctx->vsp=local+1;
	w=(pointer)EVAL(ctx,1,local+0); /*eval*/
	local[0]= w;
commonBLK695:
	ctx->vsp=local; return(local[0]);}

/*instance*/
static pointer commonF696(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST698:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	if (local[0]==NIL) goto commonIF699;
	local[1]= fqv[129];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[5];
	local[3]= local[1];
	local[4]= fqv[130];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[32];
	local[5]= local[1];
	local[6]= local[0];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[1]= w;
	goto commonIF700;
commonIF699:
	local[1]= fqv[130];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
commonIF700:
	w = local[1];
	local[0]= w;
commonBLK697:
	ctx->vsp=local; return(local[0]);}

/*instance**/
static pointer commonF701(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST703:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	if (local[0]==NIL) goto commonIF704;
	local[1]= fqv[131];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[5];
	local[3]= local[1];
	local[4]= fqv[130];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[132];
	local[5]= local[1];
	local[6]= local[0];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[1]= w;
	goto commonIF705;
commonIF704:
	local[1]= fqv[130];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
commonIF705:
	w = local[1];
	local[0]= w;
commonBLK702:
	ctx->vsp=local; return(local[0]);}

/*make-instance*/
static pointer commonF133make_instance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST707:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
commonWHL708:
	if (local[0]==NIL) goto commonWHX709;
	local[2]= local[1];
	local[3]= argv[0];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)commonF58string(ctx,1,local+4); /*string*/
	local[4]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	w = local[5];
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SETSLOT(ctx,4,local+2); /*setslot*/
	goto commonWHL708;
commonWHX709:
	local[2]= NIL;
commonBLK710:
	w = local[1];
	local[0]= w;
commonBLK706:
	ctx->vsp=local; return(local[0]);}

/*defclassmethod*/
static pointer commonF711(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST713:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[133];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SYMVALUE(ctx,1,local+2); /*symbol-value*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GETCLASS(ctx,1,local+2); /*class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,1,local+2,&ftab[1],fqv[134]); /*metaclass-name*/
	local[2]= w;
	w = local[0];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK712:
	ctx->vsp=local; return(local[0]);}

/*delete-method*/
static pointer commonF134delete_method(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= fqv[25];
	local[3]= (pointer)get_sym_func(fqv[16]);
	ctx->vsp=local+4;
	w=(pointer)commonF119delete(ctx,4,local+0); /*delete*/
	local[0]= w;
	local[1]= w;
	w = argv[0];
	w->c.obj.iv[7] = local[1];
	local[0]= T;
	ctx->vsp=local+1;
	w=(pointer)METHCACHE(ctx,1,local+0); /*system::method-cache*/
	local[0]= w;
commonBLK714:
	ctx->vsp=local; return(local[0]);}

/*make-class*/
static pointer commonF135make_class(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[135], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto commonKEY716;
	local[0] = loadglobal(fqv[136]);
commonKEY716:
	if (n & (1<<1)) goto commonKEY717;
	local[1] = loadglobal(fqv[136]);
commonKEY717:
	if (n & (1<<2)) goto commonKEY718;
	local[2] = NIL;
commonKEY718:
	if (n & (1<<3)) goto commonKEY719;
	local[3] = NIL;
commonKEY719:
	if (n & (1<<4)) goto commonKEY720;
	local[4] = NIL;
commonKEY720:
	if (n & (1<<5)) goto commonKEY721;
	local[5] = NIL;
commonKEY721:
	if (n & (1<<6)) goto commonKEY722;
	local[6] = NIL;
commonKEY722:
	if (n & (1<<7)) goto commonKEY723;
	local[7] = NIL;
commonKEY723:
	if (n & (1<<8)) goto commonKEY724;
	local[8] = makeint((eusinteger_t)-1L);
commonKEY724:
	if (n & (1<<9)) goto commonKEY725;
	local[9] = NIL;
commonKEY725:
	if (n & (1<<10)) goto commonKEY726;
	local[10] = NIL;
commonKEY726:
	w = local[0];
	if (!issymbol(w)) goto commonIF727;
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)SYMVALUE(ctx,1,local+11); /*symbol-value*/
	local[0] = w;
	local[11]= local[0];
	goto commonIF728;
commonIF727:
	local[11]= NIL;
commonIF728:
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)BOUNDP(ctx,1,local+11); /*boundp*/
	if (w==NIL) goto commonIF729;
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)SYMVALUE(ctx,1,local+11); /*symbol-value*/
	local[11]= w;
	goto commonIF730;
commonIF729:
	local[11]= NIL;
commonIF730:
	local[12]= NIL;
	local[13]= NIL;
	local[14]= NIL;
	local[15]= NIL;
	local[16]= makeint((eusinteger_t)0L);
	local[17]= NIL;
	local[18]= NIL;
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(pointer)CLASSP(ctx,1,local+19); /*classp*/
	if (w!=NIL) goto commonCON732;
	local[19]= local[6];
	if (local[19]!=NIL) goto commonCON733;
commonCON734:
	local[19]= local[6];
	ctx->vsp=local+20;
	w=(pointer)CLASSP(ctx,1,local+19); /*classp*/
	local[19]= w;
	if (w!=NIL) goto commonCON733;
commonCON735:
	if (local[0]==NIL) goto commonCON736;
	local[19]= local[0];
	ctx->vsp=local+20;
	w=(pointer)GETCLASS(ctx,1,local+19); /*class*/
	local[6] = w;
	local[19]= local[6];
	goto commonCON733;
commonCON736:
	local[19]= fqv[137];
	ctx->vsp=local+20;
	w=(pointer)SYMVALUE(ctx,1,local+19); /*symbol-value*/
	local[6] = w;
	local[19]= local[6];
	goto commonCON733;
commonCON737:
	local[19]= NIL;
commonCON733:
	local[19]= local[6];
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,1,local+19); /*instantiate*/
	local[11] = w;
	local[19]= local[11];
	goto commonCON731;
commonCON732:
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(pointer)GETCLASS(ctx,1,local+19); /*class*/
	local[6] = w;
	local[19]= local[6];
	goto commonCON731;
commonCON738:
	local[19]= NIL;
commonCON731:
	local[19]= *(ovafptr(local[0],fqv[138]));
	local[20]= loadglobal(fqv[19]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)NREVERSE(ctx,1,local+19); /*nreverse*/
	local[12] = w;
	local[19]= *(ovafptr(local[0],fqv[139]));
	local[20]= loadglobal(fqv[19]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)NREVERSE(ctx,1,local+19); /*nreverse*/
	local[13] = w;
	local[19]= *(ovafptr(local[0],fqv[140]));
	local[20]= loadglobal(fqv[19]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)NREVERSE(ctx,1,local+19); /*nreverse*/
	local[14] = w;
	local[19]= NIL;
	local[20]= local[9];
commonWHL739:
	if (local[20]==NIL) goto commonWHX740;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20] = (w)->c.cons.cdr;
	w = local[21];
	local[19] = w;
	w = local[19];
	if (!iscons(w)) goto commonCON743;
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	local[22]= local[12];
	ctx->vsp=local+23;
	w=(pointer)commonF92member(ctx,2,local+21); /*member*/
	if (w==NIL) goto commonIF744;
	local[21]= fqv[141];
	ctx->vsp=local+22;
	w=(pointer)SIGERROR(ctx,1,local+21); /*error*/
	local[21]= w;
	goto commonIF745;
commonIF744:
	local[21]= NIL;
commonIF745:
	w=local[19];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w = local[12];
	ctx->vsp=local+22;
	local[12] = cons(ctx,local[21],w);
	local[21]= fqv[142];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)commonF100position(ctx,2,local+21); /*position*/
	local[18] = w;
	if (local[18]==NIL) goto commonIF746;
	local[21]= local[19];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	goto commonIF747;
commonIF746:
	local[21]= T;
commonIF747:
	w = local[13];
	ctx->vsp=local+22;
	local[13] = cons(ctx,local[21],w);
	local[21]= fqv[143];
	local[22]= local[19];
	ctx->vsp=local+23;
	w=(pointer)commonF100position(ctx,2,local+21); /*position*/
	local[18] = w;
	if (local[18]==NIL) goto commonIF748;
	local[21]= local[19];
	local[22]= local[18];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	goto commonIF749;
commonIF748:
	local[21]= NIL;
commonIF749:
	w = local[14];
	ctx->vsp=local+22;
	local[14] = cons(ctx,local[21],w);
	local[21]= local[14];
	goto commonCON742;
commonCON743:
	w = local[19];
	if (!issymbol(w)) goto commonCON750;
	local[21]= local[19];
	local[22]= local[12];
	ctx->vsp=local+23;
	w=(pointer)commonF92member(ctx,2,local+21); /*member*/
	if (w==NIL) goto commonIF751;
	local[21]= fqv[144];
	ctx->vsp=local+22;
	w=(pointer)SIGERROR(ctx,1,local+21); /*error*/
	local[21]= w;
	goto commonIF752;
commonIF751:
	local[21]= NIL;
commonIF752:
	local[21]= local[19];
	w = local[12];
	ctx->vsp=local+22;
	local[12] = cons(ctx,local[21],w);
	local[21]= T;
	w = local[13];
	ctx->vsp=local+22;
	local[13] = cons(ctx,local[21],w);
	local[21]= NIL;
	w = local[14];
	ctx->vsp=local+22;
	local[14] = cons(ctx,local[21],w);
	local[21]= local[14];
	goto commonCON742;
commonCON750:
	local[21]= fqv[145];
	ctx->vsp=local+22;
	w=(pointer)SIGERROR(ctx,1,local+21); /*error*/
	local[21]= w;
	goto commonCON742;
commonCON753:
	local[21]= NIL;
commonCON742:
	goto commonWHL739;
commonWHX740:
	local[21]= NIL;
commonBLK741:
	w = NIL;
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)NREVERSE(ctx,1,local+19); /*nreverse*/
	local[19]= w;
	local[20]= loadglobal(fqv[146]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[12] = w;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)NREVERSE(ctx,1,local+19); /*nreverse*/
	local[19]= w;
	local[20]= loadglobal(fqv[146]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[13] = w;
	local[19]= local[14];
	ctx->vsp=local+20;
	w=(pointer)NREVERSE(ctx,1,local+19); /*nreverse*/
	local[19]= w;
	local[20]= loadglobal(fqv[146]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[14] = w;
	local[19]= local[7];
	local[20]= fqv[147];
	ctx->vsp=local+21;
	w=(pointer)ASSQ(ctx,2,local+19); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	if (local[15]!=NIL) goto commonIF754;
	local[19]= local[6];
	local[20]= loadglobal(fqv[148]);
	ctx->vsp=local+21;
	w=(pointer)SUBCLASSP(ctx,2,local+19); /*subclassp*/
	if (w==NIL) goto commonIF756;
	local[19]= local[0]->c.obj.iv[8];
	goto commonIF757;
commonIF756:
	local[19]= makeint((eusinteger_t)0L);
commonIF757:
	local[15] = local[19];
	local[19]= local[15];
	goto commonIF755;
commonIF754:
	local[19]= NIL;
commonIF755:
	local[19]= argv[0];
	*(ovafptr(local[11],fqv[149])) = local[19];
	local[19]= local[12];
	*(ovafptr(local[11],fqv[138])) = local[19];
	local[19]= local[13];
	*(ovafptr(local[11],fqv[139])) = local[19];
	local[19]= local[14];
	*(ovafptr(local[11],fqv[140])) = local[19];
	local[19]= local[0];
	local[20]= local[19];
	*(ovafptr(local[11],fqv[128])) = local[20];
	local[19]= local[6];
	local[20]= loadglobal(fqv[148]);
	ctx->vsp=local+21;
	w=(pointer)SUBCLASSP(ctx,2,local+19); /*subclassp*/
	if (w==NIL) goto commonIF758;
	local[19]= local[15];
	*(ovafptr(local[11],fqv[150])) = local[19];
	local[19]= local[8];
	local[20]= local[19];
	*(ovafptr(local[11],fqv[151])) = local[20];
	goto commonIF759;
commonIF758:
	local[19]= NIL;
commonIF759:
	if (*(ovafptr(local[11],fqv[152]))!=NIL) goto commonIF760;
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(*ftab[2])(ctx,1,local+19,&ftab[2],fqv[153]); /*enter-class*/
	local[19]= w;
	goto commonIF761;
commonIF760:
	local[19]= NIL;
commonIF761:
	local[19]= local[11];
	local[20]= local[10];
	local[21]= fqv[154];
	ctx->vsp=local+22;
	w=(pointer)PUTPROP(ctx,3,local+19); /*putprop*/
	local[19]= local[12];
	local[20]= loadglobal(fqv[19]);
	ctx->vsp=local+21;
	w=(pointer)COERCE(ctx,2,local+19); /*coerce*/
	local[12] = w;
	local[19]= NIL;
	local[20]= local[12];
commonWHL762:
	if (local[20]==NIL) goto commonWHX763;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[21]= (w)->c.cons.car;
	w=local[20];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20] = (w)->c.cons.cdr;
	w = local[21];
	local[19] = w;
	local[21]= loadglobal(fqv[155]);
	local[22]= argv[0];
	ctx->vsp=local+23;
	w=(pointer)commonF58string(ctx,1,local+22); /*string*/
	local[22]= w;
	local[23]= fqv[156];
	local[24]= local[19];
	ctx->vsp=local+25;
	w=(pointer)commonF58string(ctx,1,local+24); /*string*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)CONCATENATE(ctx,4,local+21); /*concatenate*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)INTERN(ctx,1,local+21); /*intern*/
	local[17] = w;
	local[21]= local[17];
	local[22]= fqv[157];
	local[23]= fqv[158];
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,1,local+23); /*list*/
	local[23]= w;
	local[24]= fqv[66];
	local[25]= fqv[33];
	local[26]= fqv[159];
	ctx->vsp=local+27;
	w=(pointer)LIST(ctx,1,local+26); /*list*/
	ctx->vsp=local+26;
	local[25]= cons(ctx,local[25],w);
	local[26]= fqv[158];
	local[27]= fqv[33];
	local[28]= argv[0];
	ctx->vsp=local+29;
	w=(pointer)LIST(ctx,1,local+28); /*list*/
	ctx->vsp=local+28;
	local[27]= cons(ctx,local[27],w);
	local[28]= local[16];
	ctx->vsp=local+29;
	w=(pointer)LIST(ctx,1,local+28); /*list*/
	ctx->vsp=local+28;
	w = cons(ctx,local[27],w);
	ctx->vsp=local+27;
	w = cons(ctx,local[26],w);
	ctx->vsp=local+26;
	w = cons(ctx,local[25],w);
	ctx->vsp=local+25;
	local[24]= cons(ctx,local[24],w);
	ctx->vsp=local+25;
	w=(pointer)LIST(ctx,1,local+24); /*list*/
	ctx->vsp=local+24;
	w = cons(ctx,local[23],w);
	ctx->vsp=local+23;
	local[22]= cons(ctx,local[22],w);
	ctx->vsp=local+23;
	w=(pointer)SETFUNC(ctx,2,local+21); /*setfunc*/
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[16] = w;
	goto commonWHL762;
commonWHX763:
	local[21]= NIL;
commonBLK764:
	w = NIL;
	w = local[11];
	local[0]= w;
commonBLK715:
	ctx->vsp=local; return(local[0]);}

/*defstruct*/
static pointer commonF765(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST767:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[6];
	local[2]= fqv[32];
	local[3]= fqv[33];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[38];
	local[5]= fqv[160];
	local[6]= fqv[33];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[161];
	local[8]= fqv[33];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[33];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK766:
	ctx->vsp=local; return(local[0]);}

/*defclass*/
static pointer commonF768(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[162], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto commonKEY770;
	local[0] = NIL;
commonKEY770:
	if (n & (1<<1)) goto commonKEY771;
	local[1] = fqv[136];
commonKEY771:
	if (n & (1<<2)) goto commonKEY772;
	local[2] = makeint((eusinteger_t)-1L);
commonKEY772:
	if (n & (1<<3)) goto commonKEY773;
	local[3] = NIL;
commonKEY773:
	if (n & (1<<4)) goto commonKEY774;
	local[4] = NIL;
commonKEY774:
	if (n & (1<<5)) goto commonKEY775;
	local[5] = NIL;
commonKEY775:
	if (n & (1<<6)) goto commonKEY776;
	local[6] = local[5];
commonKEY776:
	local[7]= fqv[6];
	local[8]= fqv[32];
	local[9]= fqv[33];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[38];
	local[11]= fqv[160];
	local[12]= fqv[33];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[163];
	local[14]= local[1];
	local[15]= fqv[161];
	local[16]= fqv[33];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,1,local+17); /*list*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= fqv[164];
	local[18]= local[3];
	local[19]= fqv[106];
	local[20]= local[4];
	local[21]= fqv[165];
	local[22]= local[2];
	local[23]= fqv[166];
	local[24]= local[6];
	ctx->vsp=local+25;
	w=(pointer)LIST(ctx,1,local+24); /*list*/
	ctx->vsp=local+24;
	w = cons(ctx,local[23],w);
	ctx->vsp=local+23;
	w = cons(ctx,local[22],w);
	ctx->vsp=local+22;
	w = cons(ctx,local[21],w);
	ctx->vsp=local+21;
	w = cons(ctx,local[20],w);
	ctx->vsp=local+20;
	w = cons(ctx,local[19],w);
	ctx->vsp=local+19;
	w = cons(ctx,local[18],w);
	ctx->vsp=local+18;
	w = cons(ctx,local[17],w);
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[33];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	local[0]= w;
commonBLK769:
	ctx->vsp=local; return(local[0]);}

/*readtablep*/
static pointer commonF136readtablep(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[167]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
commonBLK777:
	ctx->vsp=local; return(local[0]);}

/*copy-readtable*/
static pointer commonF137copy_readtable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto commonENT781;}
	local[0]= loadglobal(fqv[168]);
commonENT781:
	if (n>=2) { local[1]=(argv[1]); goto commonENT780;}
	local[1]= NIL;
commonENT780:
commonENT779:
	if (n>2) maerror();
	if (local[0]!=NIL) goto commonIF782;
	local[0] = loadglobal(fqv[169]);
	local[2]= local[0];
	goto commonIF783;
commonIF782:
	local[2]= NIL;
commonIF783:
	if (local[1]!=NIL) goto commonIF784;
	local[2]= loadglobal(fqv[167]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[1] = w;
	local[2]= loadglobal(fqv[155]);
	local[3]= makeint((eusinteger_t)256L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= w;
	w = local[1];
	w->c.obj.iv[1] = local[3];
	local[2]= loadglobal(fqv[146]);
	local[3]= makeint((eusinteger_t)256L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= w;
	w = local[1];
	w->c.obj.iv[2] = local[3];
	local[2]= loadglobal(fqv[146]);
	local[3]= makeint((eusinteger_t)256L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= w;
	w = local[1];
	w->c.obj.iv[3] = local[3];
	goto commonIF785;
commonIF784:
	local[2]= NIL;
commonIF785:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)commonF136readtablep(ctx,1,local+2); /*readtablep*/
	if (w==NIL) goto commonOR788;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)commonF136readtablep(ctx,1,local+2); /*readtablep*/
	if (w==NIL) goto commonOR788;
	goto commonIF786;
commonOR788:
	local[2]= fqv[170];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto commonIF787;
commonIF786:
	local[2]= NIL;
commonIF787:
	local[2]= local[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)commonF115replace(ctx,2,local+2); /*replace*/
	local[2]= local[1]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)commonF115replace(ctx,2,local+2); /*replace*/
	local[2]= local[1]->c.obj.iv[3];
	local[3]= local[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)commonF115replace(ctx,2,local+2); /*replace*/
	local[2]= local[0]->c.obj.iv[4];
	local[3]= local[2];
	w = local[1];
	w->c.obj.iv[4] = local[3];
	w = local[1];
	local[0]= w;
commonBLK778:
	ctx->vsp=local; return(local[0]);}

/*set-syntax-from-char*/
static pointer commonF138set_syntax_from_char(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto commonENT792;}
	local[0]= loadglobal(fqv[168]);
commonENT792:
	if (n>=4) { local[1]=(argv[3]); goto commonENT791;}
	local[1]= loadglobal(fqv[169]);
commonENT791:
commonENT790:
	if (n>4) maerror();
	local[2]= NIL;
	local[3]= local[1]->c.obj.iv[1];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[2] = w;
	local[3]= local[0]->c.obj.iv[1];
	local[4]= argv[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[3]= local[2];
	if (makeint((eusinteger_t)7L)==local[3]) goto commonOR795;
	local[3]= local[2];
	if (makeint((eusinteger_t)8L)==local[3]) goto commonOR795;
	goto commonIF793;
commonOR795:
	local[3]= local[0]->c.obj.iv[2];
	local[4]= argv[0];
	local[5]= local[1]->c.obj.iv[2];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[3]= w;
	goto commonIF794;
commonIF793:
	local[3]= NIL;
commonIF794:
	w = local[2];
	local[0]= w;
commonBLK789:
	ctx->vsp=local; return(local[0]);}

/*keywordp*/
static pointer commonF139keywordp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= (issymbol(w)?T:NIL);
	if (local[0]==NIL) goto commonAND797;
	local[0]= argv[0]->c.obj.iv[5];
	local[0]= ((loadglobal(fqv[171]))==(local[0])?T:NIL);
commonAND797:
	w = local[0];
	local[0]= w;
commonBLK796:
	ctx->vsp=local; return(local[0]);}

/*constantp*/
static pointer commonF140constantp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!issymbol(w)) goto commonIF799;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF139keywordp(ctx,1,local+0); /*keywordp*/
	if (w!=NIL) goto commonOR803;
	local[0]= argv[0]->c.obj.iv[2];
	if (makeint((eusinteger_t)0L)==local[0]) goto commonOR803;
	goto commonIF801;
commonOR803:
	local[0]= T;
	goto commonIF802;
commonIF801:
	local[0]= NIL;
commonIF802:
	goto commonIF800;
commonIF799:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto commonIF804;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[33]!=local[0]) goto commonIF806;
	local[0]= T;
	goto commonIF807;
commonIF806:
	local[0]= NIL;
commonIF807:
	goto commonIF805;
commonIF804:
	w = argv[0];
	if (!!iscons(w)) goto commonIF808;
	local[0]= T;
	goto commonIF809;
commonIF808:
	local[0]= NIL;
commonIF809:
commonIF805:
commonIF800:
	w = local[0];
	local[0]= w;
commonBLK798:
	ctx->vsp=local; return(local[0]);}

/*functionp*/
static pointer commonF141functionp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!numberp(w)) goto commonCON812;
	local[0]= NIL;
	goto commonCON811;
commonCON812:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto commonCON813;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w = fqv[172];
	if (memq(local[0],w)!=NIL) goto commonOR816;
	goto commonIF814;
commonOR816:
	local[0]= T;
	goto commonIF815;
commonIF814:
	local[0]= NIL;
commonIF815:
	goto commonCON811;
commonCON813:
	local[0]= argv[0];
	local[1]= loadglobal(fqv[173]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto commonCON817;
	local[0]= argv[0]->c.obj.iv[2];
	local[0]= ((makeint((eusinteger_t)0L))==(local[0])?T:NIL);
	goto commonCON811;
commonCON817:
	w = argv[0];
	if (!issymbol(w)) goto commonCON818;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	if (w==NIL) goto commonCON818;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SYMFUNC(ctx,1,local+0); /*symbol-function*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)commonF141functionp(ctx,1,local+0); /*functionp*/
	local[0]= w;
	goto commonCON811;
commonCON818:
	local[0]= NIL;
	goto commonCON811;
commonCON819:
	local[0]= NIL;
commonCON811:
	w = local[0];
	local[0]= w;
commonBLK810:
	ctx->vsp=local; return(local[0]);}

/*vector-class-p*/
static pointer commonF142vector_class_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[148]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
commonBLK820:
	ctx->vsp=local; return(local[0]);}

/*compiled-function-p*/
static pointer commonF143compiled_function_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[173]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
commonBLK821:
	ctx->vsp=local; return(local[0]);}

/*input-stream-p*/
static pointer commonF144input_stream_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[174]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	if (w==NIL) goto commonAND824;
	local[0]= argv[0]->c.obj.iv[1];
	local[0]= ((fqv[175])==(local[0])?T:NIL);
commonAND824:
	if (local[0]!=NIL) goto commonOR823;
	local[0]= argv[0];
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
commonOR823:
	w = local[0];
	local[0]= w;
commonBLK822:
	ctx->vsp=local; return(local[0]);}

/*output-stream-p*/
static pointer commonF145output_stream_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[174]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	if (w==NIL) goto commonAND827;
	local[0]= argv[0]->c.obj.iv[1];
	local[0]= ((fqv[177])==(local[0])?T:NIL);
commonAND827:
	if (local[0]!=NIL) goto commonOR826;
	local[0]= argv[0];
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
commonOR826:
	w = local[0];
	local[0]= w;
commonBLK825:
	ctx->vsp=local; return(local[0]);}

/*io-stream-p*/
static pointer commonF146io_stream_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[176]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
commonBLK828:
	ctx->vsp=local; return(local[0]);}

/*special-form-p*/
static pointer commonF147special_form_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= (issymbol(w)?T:NIL);
	if (local[0]==NIL) goto commonAND830;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	local[0]= w;
	if (w==NIL) goto commonAND830;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SYMFUNC(ctx,1,local+0); /*symbol-function*/
	argv[0] = w;
	local[0]= argv[0];
	if (local[0]==NIL) goto commonAND830;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF143compiled_function_p(ctx,1,local+0); /*compiled-function-p*/
	local[0]= w;
	if (w==NIL) goto commonAND830;
	local[0]= *(ovafptr(argv[0],fqv[178]));
	local[0]= ((makeint((eusinteger_t)2L))==(local[0])?T:NIL);
commonAND830:
	w = local[0];
	local[0]= w;
commonBLK829:
	ctx->vsp=local; return(local[0]);}

/*macro-function*/
static pointer commonF148macro_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	local[0]= (issymbol(w)?T:NIL);
	if (local[0]==NIL) goto commonAND832;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)FBOUNDP(ctx,1,local+0); /*fboundp*/
	local[0]= w;
	if (w==NIL) goto commonAND832;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)SYMFUNC(ctx,1,local+0); /*symbol-function*/
	argv[0] = w;
	local[0]= argv[0];
	if (local[0]==NIL) goto commonAND832;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF143compiled_function_p(ctx,1,local+0); /*compiled-function-p*/
	if (w==NIL) goto commonIF833;
	local[0]= *(ovafptr(argv[0],fqv[178]));
	if (makeint((eusinteger_t)1L)!=local[0]) goto commonIF833;
	local[0]= argv[0];
	goto commonIF834;
commonIF833:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto commonIF835;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (fqv[157]!=local[0]) goto commonIF835;
	local[0]= argv[0];
	goto commonIF836;
commonIF835:
	local[0]= NIL;
commonIF836:
commonIF834:
commonAND832:
	w = local[0];
	local[0]= w;
commonBLK831:
	ctx->vsp=local; return(local[0]);}

/*zerop*/
static pointer commonF149zerop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	local[0]= w;
commonBLK837:
	ctx->vsp=local; return(local[0]);}

/*plusp*/
static pointer commonF150plusp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	local[0]= w;
commonBLK838:
	ctx->vsp=local; return(local[0]);}

/*minusp*/
static pointer commonF151minusp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
commonBLK839:
	ctx->vsp=local; return(local[0]);}

/*oddp*/
static pointer commonF152oddp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LOGBITP(ctx,2,local+0); /*logbitp*/
	local[0]= w;
commonBLK840:
	ctx->vsp=local; return(local[0]);}

/*evenp*/
static pointer commonF153evenp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LOGBITP(ctx,2,local+0); /*logbitp*/
	w = ((w)==NIL?T:NIL);
	local[0]= w;
commonBLK841:
	ctx->vsp=local; return(local[0]);}

/*logandc1*/
static pointer commonF154logandc1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LOGNOT(ctx,1,local+0); /*lognot*/
	local[0]= w;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LOGAND(ctx,2,local+0); /*logand*/
	local[0]= w;
commonBLK842:
	ctx->vsp=local; return(local[0]);}

/*logandc2*/
static pointer commonF155logandc2(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LOGNOT(ctx,1,local+1); /*lognot*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LOGAND(ctx,2,local+0); /*logand*/
	local[0]= w;
commonBLK843:
	ctx->vsp=local; return(local[0]);}

/*ecase*/
static pointer commonF844(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST846:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[179];
	w = local[0];
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK845:
	ctx->vsp=local; return(local[0]);}

/*every*/
static pointer commonF156every(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST848:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]!=NIL) goto commonCON850;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto commonCON850;
commonWHL851:
	if (argv[1]==NIL) goto commonWHX852;
	local[1]= argv[0];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[2];
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,2,local+1); /*funcall*/
	if (w!=NIL) goto commonIF854;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto commonBLK847;
	goto commonIF855;
commonIF854:
	local[1]= NIL;
commonIF855:
	goto commonWHL851;
commonWHX852:
	local[1]= NIL;
commonBLK853:
	goto commonCON849;
commonCON850:
	local[1]= argv[1];
	w = local[0];
	ctx->vsp=local+2;
	argv[1] = cons(ctx,local[1],w);
	local[1]= makeint((eusinteger_t)0L);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
commonWHL857:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto commonWHX858;
	local[3]= argv[0];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,commonCLO862,env,argv,local);
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,2,local+3); /*apply*/
	if (w!=NIL) goto commonIF860;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto commonBLK847;
	goto commonIF861;
commonIF860:
	local[3]= NIL;
commonIF861:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto commonWHL857;
commonWHX858:
	local[3]= NIL;
commonBLK859:
	w = NIL;
	local[1]= w;
	goto commonCON849;
commonCON856:
	local[1]= NIL;
commonCON849:
	w = T;
	local[0]= w;
commonBLK847:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO862(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[1];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*some*/
static pointer commonF157some(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST864:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[1];
	w = local[0];
	ctx->vsp=local+4;
	argv[1] = cons(ctx,local[3],w);
	local[3]= makeint((eusinteger_t)0L);
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
commonWHL865:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto commonWHX866;
	local[5]= argv[0];
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,commonCLO870,env,argv,local);
	local[7]= argv[1];
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,2,local+6); /*mapcar*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,2,local+5); /*apply*/
	local[2] = w;
	if (local[2]==NIL) goto commonIF868;
	w = local[2];
	ctx->vsp=local+5;
	local[0]=w;
	goto commonBLK863;
	goto commonIF869;
commonIF868:
	local[5]= NIL;
commonIF869:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto commonWHL865;
commonWHX866:
	local[5]= NIL;
commonBLK867:
	w = NIL;
	w = NIL;
	local[0]= w;
commonBLK863:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer commonCLO870(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*reduce*/
static pointer commonF158reduce(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[180], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto commonKEY872;
	local[0] = makeint((eusinteger_t)0L);
commonKEY872:
	if (n & (1<<1)) goto commonKEY873;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[1] = w;
commonKEY873:
	if (n & (1<<2)) goto commonKEY874;
	local[2] = NIL;
commonKEY874:
	if (n & (1<<3)) goto commonKEY875;
	local[3] = NIL;
commonKEY875:
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	if (local[2]==NIL) goto commonIF876;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)REVERSE(ctx,1,local+5); /*reverse*/
	argv[1] = w;
	local[5]= argv[1];
	goto commonIF877;
commonIF876:
	local[5]= NIL;
commonIF877:
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto commonCON879;
	if (local[3]!=NIL) goto commonCON879;
	local[5]= argv[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	goto commonCON878;
commonCON879:
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto commonCON880;
	if (local[3]==NIL) goto commonIF881;
	local[5]= local[3];
	goto commonIF882;
commonIF881:
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,1,local+5); /*funcall*/
	local[5]= w;
commonIF882:
	goto commonCON878;
commonCON880:
	if (local[3]!=NIL) goto commonIF884;
	local[5]= argv[0];
	local[6]= argv[1];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[0] = w;
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)FUNCALL(ctx,3,local+5); /*funcall*/
	local[3] = w;
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[4] = w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[0] = w;
	local[5]= local[0];
	goto commonIF885;
commonIF884:
	local[5]= NIL;
commonIF885:
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[4];
commonWHL886:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto commonWHX887;
	local[7]= argv[0];
	local[8]= local[3];
	local[9]= argv[1];
	local[10]= local[0];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,3,local+7); /*funcall*/
	local[3] = w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto commonWHL886;
commonWHX887:
	local[7]= NIL;
commonBLK888:
	w = NIL;
	local[5]= local[3];
	goto commonCON878;
commonCON883:
	local[5]= NIL;
commonCON878:
	w = local[5];
	local[0]= w;
commonBLK871:
	ctx->vsp=local; return(local[0]);}

/*merge-list*/
static pointer commonF159merge_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= NIL;
commonWHL890:
	if (argv[1]==NIL) goto commonWHX891;
	local[7]= argv[2];
	local[8]= argv[3];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,2,local+8); /*funcall*/
	local[8]= w;
	local[9]= argv[3];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)FUNCALL(ctx,2,local+9); /*funcall*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,3,local+7); /*funcall*/
	if (w!=NIL) goto commonWHX891;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[1] = (w)->c.cons.cdr;
	w = local[7];
	local[7]= w;
	w = local[1];
	ctx->vsp=local+8;
	local[1] = cons(ctx,local[7],w);
	goto commonWHL890;
commonWHX891:
	local[7]= NIL;
commonBLK892:
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)NREVERSE(ctx,1,local+7); /*nreverse*/
	local[1] = w;
	local[2] = argv[0];
commonWHL893:
	if (argv[1]==NIL) goto commonWHX894;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto commonWHX894;
	local[7]= argv[3];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)FUNCALL(ctx,2,local+7); /*funcall*/
	local[4] = w;
commonWHL896:
	if (local[2]==NIL) goto commonWHX897;
	local[7]= argv[2];
	local[8]= argv[3];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,2,local+8); /*funcall*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,3,local+7); /*funcall*/
	if (w==NIL) goto commonWHX897;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[7];
	goto commonWHL896;
commonWHX897:
	local[7]= NIL;
commonBLK898:
	if (local[2]==NIL) goto commonIF899;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	local[7]= local[2];
	local[8]= argv[1];
	ctx->vsp=local+9;
	w=(pointer)RPLACD2(ctx,2,local+7); /*rplacd2*/
	local[7]= argv[1];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)RPLACD2(ctx,2,local+7); /*rplacd2*/
	local[2] = argv[1];
	argv[1] = local[6];
	local[7]= argv[1];
	goto commonIF900;
commonIF899:
	local[7]= NIL;
commonIF900:
	goto commonWHL893;
commonWHX894:
	local[7]= NIL;
commonBLK895:
	local[7]= local[1];
	local[8]= argv[0];
	local[9]= argv[1];
	ctx->vsp=local+10;
	w=(pointer)NCONC(ctx,3,local+7); /*nconc*/
	local[0]= w;
commonBLK889:
	ctx->vsp=local; return(local[0]);}

/*merge*/
static pointer commonF160merge(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[181], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto commonKEY902;
	local[0] = (pointer)get_sym_func(fqv[82]);
commonKEY902:
	local[1]= argv[0];
	if (loadglobal(fqv[19])!=local[1]) goto commonIF903;
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto commonIF903;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LISTP(ctx,1,local+1); /*listp*/
	if (w==NIL) goto commonIF903;
	local[1]= argv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)commonF159merge_list(ctx,4,local+1); /*merge-list*/
	local[1]= w;
	goto commonIF904;
commonIF903:
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)commonF113make_sequence(ctx,2,local+4); /*make-sequence*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
commonWHL905:
	local[11]= local[7];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LESSP(ctx,2,local+11); /*<*/
	if (w==NIL) goto commonWHX906;
	local[11]= local[5];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto commonCON909;
	local[11]= argv[2];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[10] = w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[6] = w;
	local[11]= local[6];
	goto commonCON908;
commonCON909:
	local[11]= local[6];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)GREQP(ctx,2,local+11); /*>=*/
	if (w==NIL) goto commonCON910;
	local[11]= argv[1];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[10] = w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[5] = w;
	local[11]= local[5];
	goto commonCON908;
commonCON910:
	local[11]= argv[1];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[8] = w;
	local[11]= argv[2];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[9] = w;
	local[11]= argv[3];
	local[12]= local[0];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)FUNCALL(ctx,2,local+12); /*funcall*/
	local[12]= w;
	local[13]= local[0];
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)FUNCALL(ctx,2,local+13); /*funcall*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)FUNCALL(ctx,3,local+11); /*funcall*/
	if (w==NIL) goto commonIF912;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[5] = w;
	local[10] = local[8];
	local[11]= local[10];
	goto commonIF913;
commonIF912:
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[6] = w;
	local[10] = local[9];
	local[11]= local[10];
commonIF913:
	goto commonCON908;
commonCON911:
	local[11]= NIL;
commonCON908:
	local[11]= local[4];
	local[12]= local[7];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[7] = w;
	goto commonWHL905;
commonWHX906:
	local[11]= NIL;
commonBLK907:
	w = local[4];
	local[1]= w;
commonIF904:
	w = local[1];
	local[0]= w;
commonBLK901:
	ctx->vsp=local; return(local[0]);}

/*expt*/
static pointer commonF161expt(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[1];
	if (!isint(w)) goto commonCON916;
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto commonCON916;
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)commonF149zerop(ctx,1,local+0); /*zerop*/
	if (w==NIL) goto commonIF917;
	local[0]= makeint((eusinteger_t)1L);
	goto commonIF918;
commonIF917:
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)1L);
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
commonWHL919:
	local[3]= local[2];
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[3] <= (eusinteger_t)w) goto commonWHX920;
	local[3]= local[2];
	w = local[1];
	if ((eusinteger_t)local[3] <= (eusinteger_t)w) goto commonCON923;
	local[3]= local[0];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[0] = w;
	local[3]= local[2];
	w = local[1];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[2] = (pointer)((eusinteger_t)local[3] - (eusinteger_t)w);
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ASH(ctx,2,local+3); /*ash*/
	local[1] = w;
	local[3]= local[1];
	goto commonCON922;
commonCON923:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[0] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[2] = w;
	local[3]= local[2];
	goto commonCON922;
commonCON924:
	local[3]= NIL;
commonCON922:
	goto commonWHL919;
commonWHX920:
	local[3]= NIL;
commonBLK921:
	w = local[0];
	local[0]= w;
commonIF918:
	goto commonCON915;
commonCON916:
	local[0]= argv[1];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)LOG(ctx,1,local+1); /*log*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)EXP(ctx,1,local+0); /*exp*/
	local[0]= w;
	goto commonCON915;
commonCON925:
	local[0]= NIL;
commonCON915:
	w = local[0];
	local[0]= w;
commonBLK914:
	ctx->vsp=local; return(local[0]);}

/*signum*/
static pointer commonF162signum(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)commonF149zerop(ctx,1,local+0); /*zerop*/
	if (w==NIL) goto commonIF927;
	local[0]= argv[0];
	goto commonIF928;
commonIF927:
	local[0]= argv[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
commonIF928:
	w = local[0];
	local[0]= w;
commonBLK926:
	ctx->vsp=local; return(local[0]);}

/*rad2deg*/
static pointer commonF163rad2deg(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(3.6000000000000000000000e+02);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(6.2831853071795862319959e+00);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
commonBLK929:
	ctx->vsp=local; return(local[0]);}

/*deg2rad*/
static pointer commonF164deg2rad(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(6.2831853071795862319959e+00);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(3.6000000000000000000000e+02);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
commonBLK930:
	ctx->vsp=local; return(local[0]);}

/*defsetf*/
static pointer commonF931(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST933:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto commonCON935;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (issymbol(w)) goto commonOR936;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)commonF141functionp(ctx,1,local+1); /*functionp*/
	if (w!=NIL) goto commonOR936;
	goto commonCON935;
commonOR936:
	local[1]= fqv[6];
	local[2]= fqv[182];
	local[3]= fqv[33];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[33];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= fqv[183];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[184];
	local[4]= fqv[33];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= fqv[185];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[184];
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[33];
	local[7]= fqv[186];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[182];
	local[6]= fqv[33];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)ENDP(ctx,1,local+7); /*endp*/
	if (w!=NIL) goto commonIF937;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (isstring(w)) goto commonIF939;
	local[7]= fqv[187];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto commonIF940;
commonIF939:
	local[7]= NIL;
commonIF940:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
	ctx->vsp=local+8;
	w=(pointer)ENDP(ctx,1,local+7); /*endp*/
	if (w!=NIL) goto commonIF941;
	local[7]= fqv[188];
	ctx->vsp=local+8;
	w=(pointer)SIGERROR(ctx,1,local+7); /*error*/
	local[7]= w;
	goto commonIF942;
commonIF941:
	local[7]= NIL;
commonIF942:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	goto commonIF938;
commonIF937:
	local[7]= NIL;
commonIF938:
	local[8]= fqv[33];
	local[9]= fqv[189];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[33];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON934;
commonCON935:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[190]); /*list-length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w!=NIL) goto commonIF944;
	local[1]= fqv[191];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto commonIF945;
commonIF944:
	local[1]= NIL;
commonIF945:
	local[1]= fqv[6];
	local[2]= fqv[182];
	local[3]= fqv[33];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[33];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= fqv[185];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[184];
	local[4]= fqv[33];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= fqv[183];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[184];
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[33];
	local[7]= fqv[186];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON934;
commonCON943:
	local[1]= NIL;
commonCON934:
	w = local[1];
	local[0]= w;
commonBLK932:
	ctx->vsp=local; return(local[0]);}

/*define-setf-method*/
static pointer commonF946(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
commonRST948:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[6];
	local[2]= fqv[182];
	local[3]= fqv[33];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[124];
	local[5]= fqv[192];
	local[6]= local[0];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= fqv[186];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[184];
	local[4]= fqv[33];
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= fqv[185];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= fqv[184];
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[33];
	local[7]= fqv[183];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[33];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
commonBLK947:
	ctx->vsp=local; return(local[0]);}

/*setf-expand-1*/
static pointer commonF165setf_expand_1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)commonF52macroexpand(ctx,1,local+1); /*macroexpand*/
	argv[0] = w;
	w = argv[0];
	if (!iscons(w)) goto commonCON951;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	if (fqv[193]!=local[1]) goto commonCON951;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[193];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)commonF165setf_expand_1(ctx,2,local+1); /*setf-expand-1*/
	local[1]= w;
	goto commonCON950;
commonCON951:
	w = argv[0];
	if (!issymbol(w)) goto commonCON952;
	local[1]= fqv[28];
	local[2]= argv[0];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON950;
commonCON952:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto commonCON953;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[183];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto commonCON953;
	local[1]= local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.cdr;
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON950;
commonCON953:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto commonCON954;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[194];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto commonCON954;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	if (w==NIL) goto commonCON954;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	if (fqv[66]==local[1]) goto commonCON954;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	if (fqv[146]==local[1]) goto commonCON954;
	local[1]= fqv[195];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[33];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON950;
commonCON954:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)commonF148macro_function(ctx,1,local+1); /*macro-function*/
	if (w==NIL) goto commonCON955;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)commonF52macroexpand(ctx,1,local+1); /*macroexpand*/
	local[1]= w;
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)commonF165setf_expand_1(ctx,2,local+1); /*setf-expand-1*/
	local[1]= w;
	goto commonCON950;
commonCON955:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[185];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0] = w;
	if (local[0]==NIL) goto commonCON956;
	local[1]= fqv[196];
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,2,local+2); /*append*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)APPEND(ctx,3,local+1); /*append*/
	local[1]= w;
	local[2]= argv[1];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	goto commonCON950;
commonCON956:
	local[1]= fqv[197];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto commonCON950;
commonCON957:
	local[1]= NIL;
commonCON950:
	w = local[1];
	local[0]= w;
commonBLK949:
	ctx->vsp=local; return(local[0]);}

/*setf-expand*/
static pointer commonF166setf_expand(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)ENDP(ctx,1,local+0); /*endp*/
	if (w==NIL) goto commonCON960;
	local[0]= NIL;
	goto commonCON959;
commonCON960:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	ctx->vsp=local+1;
	w=(pointer)ENDP(ctx,1,local+0); /*endp*/
	if (w==NIL) goto commonCON961;
	local[0]= fqv[198];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,2,local+0); /*error*/
	local[0]= w;
	goto commonCON959;
commonCON961:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)commonF165setf_expand_1(ctx,2,local+0); /*setf-expand-1*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)commonF166setf_expand(ctx,1,local+1); /*setf-expand*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto commonCON959;
commonCON962:
	local[0]= NIL;
commonCON959:
	w = local[0];
	local[0]= w;
commonBLK958:
	ctx->vsp=local; return(local[0]);}

/*setf*/
static pointer commonF963(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
commonRST965:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)ENDP(ctx,1,local+1); /*endp*/
	if (w==NIL) goto commonCON967;
	local[1]= NIL;
	goto commonCON966;
commonCON967:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)ENDP(ctx,1,local+1); /*endp*/
	if (w==NIL) goto commonCON968;
	local[1]= fqv[199];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto commonCON966;
commonCON968:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	ctx->vsp=local+2;
	w=(pointer)ENDP(ctx,1,local+1); /*endp*/
	if (w==NIL) goto commonCON969;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)commonF165setf_expand_1(ctx,2,local+1); /*setf-expand-1*/
	local[1]= w;
	goto commonCON966;
commonCON969:
	local[1]= fqv[6];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)commonF166setf_expand(ctx,1,local+2); /*setf-expand*/
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto commonCON966;
commonCON970:
	local[1]= NIL;
commonCON966:
	w = local[1];
	local[0]= w;
commonBLK964:
	ctx->vsp=local; return(local[0]);}

/*multiple-value-bind*/
static pointer commonF971(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
commonRST973:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[200];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	local[5]= argv[0];
commonWHL974:
	if (local[5]==NIL) goto commonWHX975;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	local[7]= fqv[55];
	local[8]= local[1];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	w = local[2];
	ctx->vsp=local+7;
	local[2] = cons(ctx,local[6],w);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[3] = w;
	goto commonWHL974;
commonWHX975:
	local[6]= NIL;
commonBLK976:
	w = NIL;
	local[4]= fqv[50];
	local[5]= local[1];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	w = local[2];
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	w = local[0];
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	local[0]= w;
commonBLK972:
	ctx->vsp=local; return(local[0]);}

/*multiple-value-setq*/
static pointer commonF977(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= fqv[201];
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,1,local+1); /*gensym*/
	local[1]= w;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
commonWHL979:
	if (local[4]==NIL) goto commonWHX980;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[0];
	local[6]= fqv[202];
	ctx->vsp=local+7;
	w=(pointer)commonF93assoc(ctx,2,local+5); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[0] = w;
	goto commonWHL979;
commonWHX980:
	local[5]= NIL;
commonBLK981:
	w = NIL;
	local[3]= fqv[5];
	local[4]= local[1];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	local[5]= fqv[28];
	w = local[2];
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
commonBLK978:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___common(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[203];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto commonIF982;
	local[0]= fqv[204];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[49],w);
	goto commonIF983;
commonIF982:
	local[0]= fqv[205];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
commonIF983:
	local[0]= fqv[206];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= fqv[207];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[208];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[209];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[210];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[211];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[212];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[213];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[214];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[215],module,commonF50lisp_implementation_type,fqv[216]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[2],module,commonF51lisp_implementation_version,fqv[217]);
	local[0]= NIL;
	storeglobal(fqv[218],local[0]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[219],module,commonF52macroexpand,fqv[220]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[15],module,commonF173,fqv[221]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[222],module,commonF176,fqv[223]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[224],module,commonF179,fqv[225]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[226],module,commonF182,fqv[227]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[47],module,commonF185,fqv[228]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[229],module,commonF187,fqv[230]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[231],module,commonF189,fqv[232]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[56],module,commonF194,fqv[233]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[234],module,commonF200,fqv[235]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[236],module,commonF206,fqv[237]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[238],module,commonF212,fqv[239]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[240],module,commonF218,fqv[241]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[242],module,commonF225,fqv[243]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[244],module,commonF232,fqv[245]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[246],module,commonF238,fqv[247]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[248],module,commonF244,fqv[249]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[62],module,commonF247,fqv[250]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[64],module,commonF252,fqv[251]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[252],module,commonF257,fqv[253]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[254],module,commonF262,fqv[255]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[69],module,commonF265,fqv[256]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[257],module,commonF271,fqv[258]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[259],module,commonF280,fqv[260]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[261],module,commonF289,fqv[262]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[263],module,commonF292,fqv[264]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[265],module,commonF53casebody,fqv[266]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[267],module,commonF54casehead,fqv[268]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[269],module,commonF55case1,fqv[270]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[179],module,commonF306,fqv[271]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[272],module,commonF56classcasehead,fqv[273]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[274],module,commonF57classcase1,fqv[275]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[276],module,commonF318,fqv[277]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[155],module,commonF58string,fqv[278]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[279],module,commonF59alias,fqv[280]);
	local[0]= fqv[190];
	local[1]= fqv[54];
	ctx->vsp=local+2;
	w=(pointer)commonF59alias(ctx,2,local+0); /*alias*/
	local[0]= fqv[281];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)commonF59alias(ctx,2,local+0); /*alias*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[282],module,commonF60caaar,fqv[283]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[284],module,commonF61caadr,fqv[285]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[286],module,commonF62cadar,fqv[287]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[288],module,commonF63cdaar,fqv[289]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[290],module,commonF64cdadr,fqv[291]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[292],module,commonF65cddar,fqv[293]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[294],module,commonF66cdddr,fqv[295]);
	local[0]= fqv[296];
	local[1]= fqv[16];
	ctx->vsp=local+2;
	w=(pointer)commonF59alias(ctx,2,local+0); /*alias*/
	local[0]= fqv[297];
	local[1]= fqv[298];
	ctx->vsp=local+2;
	w=(pointer)commonF59alias(ctx,2,local+0); /*alias*/
	local[0]= fqv[299];
	local[1]= fqv[300];
	ctx->vsp=local+2;
	w=(pointer)commonF59alias(ctx,2,local+0); /*alias*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[301],module,commonF67fourth,fqv[302]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[303],module,commonF68fifth,fqv[304]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[305],module,commonF69sixth,fqv[306]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[307],module,commonF70seventh,fqv[308]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[309],module,commonF71eighth,fqv[310]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[311],module,commonF72cddddr,fqv[312]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[313],module,commonF73cadddr,fqv[314]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[315],module,commonF74caaddr,fqv[316]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[317],module,commonF75cdaddr,fqv[318]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[319],module,commonF76caddddr,fqv[320]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[321],module,commonF77flatten,fqv[322]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[323],module,commonF78list_insert,fqv[324]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[325],module,commonF79list_delete,fqv[326]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[327],module,commonF80adjoin,fqv[328]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[329],module,commonF81union,fqv[330]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[331],module,commonF82intersection,fqv[332]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[333],module,commonF83set_difference,fqv[334]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[335],module,commonF84set_exclusive_or,fqv[336]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[337],module,commonF85rotate_list,fqv[338]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[339],module,commonF86last,fqv[340]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[341],module,commonF87copy_tree,fqv[342]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[343],module,commonF88copy_list,fqv[344]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[345],module,commonF89nreconc,fqv[346]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[347],module,commonF90rassoc,fqv[348]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[349],module,commonF91acons,fqv[350]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[22],module,commonF92member,fqv[351]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[352],module,commonF93assoc,fqv[353]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[354],module,commonF94subsetp,fqv[355]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[356],module,commonF95maplist,fqv[357]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[358],module,commonF96mapcon,fqv[359]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[360],module,commonF97find,fqv[361]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[362],module,commonF98find_if,fqv[363]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[364],module,commonF99find_if_not,fqv[365]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[366],module,commonF100position,fqv[367]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[368],module,commonF101position_if,fqv[369]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[370],module,commonF102position_if_not,fqv[371]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[372],module,commonF103count,fqv[373]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[374],module,commonF104count_if,fqv[375]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[376],module,commonF105count_if_not,fqv[377]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[378],module,commonF106member_if,fqv[379]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[380],module,commonF107member_if_not,fqv[381]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[382],module,commonF108collect_if,fqv[383]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[384],module,commonF109collect_instances,fqv[385]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[386],module,commonF110pairlis,fqv[387]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[388],module,commonF111transpose_list,fqv[389]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[390],module,commonF112make_list,fqv[391]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[392],module,commonF113make_sequence,fqv[393]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[394],module,commonF114fill,fqv[395]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[396],module,commonF115replace,fqv[397]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[398],module,commonF116remove,fqv[399]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[400],module,commonF117remove_if,fqv[401]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[402],module,commonF118remove_if_not,fqv[403]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[404],module,commonF119delete,fqv[405]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[406],module,commonF120delete_if,fqv[407]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[408],module,commonF121delete_if_not,fqv[409]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[410],module,commonF122substitute,fqv[411]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[412],module,commonF123substitute_if,fqv[413]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[414],module,commonF124substitute_if_not,fqv[415]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[416],module,commonF125nsubstitute,fqv[417]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[418],module,commonF126nsubstitute_if,fqv[419]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[420],module,commonF127nsubstitute_if_not,fqv[421]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[422],module,commonF128unique,fqv[423]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[424],module,commonF129remove_duplicates,fqv[425]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[426],module,commonF130extream,fqv[427]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[428],module,commonF677,fqv[429]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[430],module,commonF680,fqv[431]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[432],module,commonF683,fqv[433]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[132],module,commonF686,fqv[434]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[435],module,commonF689,fqv[436]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[437],module,commonF131send_all,fqv[438]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[439],module,commonF132resend,fqv[440]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[441],module,commonF696,fqv[442]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[443],module,commonF701,fqv[444]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[445],module,commonF133make_instance,fqv[446]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[447],module,commonF711,fqv[448]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[449],module,commonF134delete_method,fqv[450]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[160],module,commonF135make_class,fqv[451]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[452],module,commonF765,fqv[453]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[454],module,commonF768,fqv[455]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[456],module,commonF136readtablep,fqv[457]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[458],module,commonF137copy_readtable,fqv[459]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[460],module,commonF138set_syntax_from_char,fqv[461]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[462],module,commonF139keywordp,fqv[463]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[464],module,commonF140constantp,fqv[465]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[466],module,commonF141functionp,fqv[467]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[468],module,commonF142vector_class_p,fqv[469]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[470],module,commonF143compiled_function_p,fqv[471]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[472],module,commonF144input_stream_p,fqv[473]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[474],module,commonF145output_stream_p,fqv[475]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[476],module,commonF146io_stream_p,fqv[477]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[478],module,commonF147special_form_p,fqv[479]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[480],module,commonF148macro_function,fqv[481]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[482],module,commonF149zerop,fqv[483]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[484],module,commonF150plusp,fqv[485]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[486],module,commonF151minusp,fqv[487]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[488],module,commonF152oddp,fqv[489]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[490],module,commonF153evenp,fqv[491]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[492],module,commonF154logandc1,fqv[493]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[494],module,commonF155logandc2,fqv[495]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[496],module,commonF844,fqv[497]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[498],module,commonF156every,fqv[499]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[500],module,commonF157some,fqv[501]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[502],module,commonF158reduce,fqv[503]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[504],module,commonF159merge_list,fqv[505]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[506],module,commonF160merge,fqv[507]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[508],module,commonF161expt,fqv[509]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[510],module,commonF162signum,fqv[511]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[512],module,commonF163rad2deg,fqv[513]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[514],module,commonF164deg2rad,fqv[515]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[516],module,commonF931,fqv[517]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[518],module,commonF946,fqv[519]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[520],module,commonF165setf_expand_1,fqv[521]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[522],module,commonF166setf_expand,fqv[523]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[17],module,commonF963,fqv[524]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[525],module,commonF971,fqv[526]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[527],module,commonF977,fqv[528]);
	local[0]= fqv[281];
	local[1]= fqv[66];
	ctx->vsp=local+2;
	w=(pointer)commonF59alias(ctx,2,local+0); /*alias*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<4; i++) ftab[i]=fcallx;
}
