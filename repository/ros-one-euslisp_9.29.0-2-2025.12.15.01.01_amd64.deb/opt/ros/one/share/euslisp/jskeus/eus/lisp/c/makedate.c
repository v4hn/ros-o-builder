char *makedate="Mon Dec 15 01:02:36 UTC 2025";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";
