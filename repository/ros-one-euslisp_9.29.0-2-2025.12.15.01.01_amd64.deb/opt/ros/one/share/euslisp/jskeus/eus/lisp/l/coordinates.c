/* ./coordinates.c :  entry=coordinates */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Dec 15 01:02:36 UTC 2025) */
#include "eus.h"
#include "coordinates.h"
#pragma init (register_coordinates)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___coordinates();
extern pointer build_quote_vector();
static int register_coordinates()
  { add_module_initializer("___coordinates", ___coordinates);}

static pointer coordinaF4488coordinates_p();
static pointer coordinaF4489transform_coords();
static pointer coordinaF4490transform_coords_();
static pointer coordinaF4491transform_vector();
static pointer coordinaF4492make_coords();
static pointer coordinaF4493make_cascoords();
static pointer coordinaF4494coords();
static pointer coordinaF4495cascoords();
static pointer coordinaF4496wrt();
static pointer coordinaF4497coordinates_distance();

/*coordinates-p*/
static pointer coordinaF4488coordinates_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[0]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
coordinaBLK4498:
	ctx->vsp=local; return(local[0]);}

/*:dimension*/
static pointer coordinaM4499coordinates_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
coordinaBLK4500:
	ctx->vsp=local; return(local[0]);}

/*:rot*/
static pointer coordinaM4501coordinates_rot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
coordinaBLK4502:
	ctx->vsp=local; return(local[0]);}

/*:pos*/
static pointer coordinaM4503coordinates_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
coordinaBLK4504:
	ctx->vsp=local; return(local[0]);}

/*:x-axis*/
static pointer coordinaM4505coordinates_x_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[1]); /*matrix-row*/
	local[0]= w;
coordinaBLK4506:
	ctx->vsp=local; return(local[0]);}

/*:y-axis*/
static pointer coordinaM4507coordinates_y_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[1]); /*matrix-row*/
	local[0]= w;
coordinaBLK4508:
	ctx->vsp=local; return(local[0]);}

/*:z-axis*/
static pointer coordinaM4509coordinates_z_axis(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[1]); /*matrix-row*/
	local[0]= w;
coordinaBLK4510:
	ctx->vsp=local; return(local[0]);}

/*:name*/
static pointer coordinaM4511coordinates_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4514;}
	local[0]= NIL;
coordinaENT4514:
coordinaENT4513:
	if (n>3) maerror();
	if (local[0]==NIL) goto coordinaIF4515;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= w;
	goto coordinaIF4516;
coordinaIF4515:
	local[1]= NIL;
coordinaIF4516:
	local[1]= argv[0];
	local[2]= fqv[2];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[0]= w;
coordinaBLK4512:
	ctx->vsp=local; return(local[0]);}

/*:newcoords*/
static pointer coordinaM4517coordinates_newcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4520;}
	local[0]= NIL;
coordinaENT4520:
coordinaENT4519:
	if (n>4) maerror();
	if (local[0]==NIL) goto coordinaIF4521;
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto coordinaIF4522;
coordinaIF4521:
	argv[0]->c.obj.iv[1] = argv[2]->c.obj.iv[1];
	argv[0]->c.obj.iv[2] = argv[2]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[2];
coordinaIF4522:
	w = argv[0];
	local[0]= w;
coordinaBLK4518:
	ctx->vsp=local; return(local[0]);}

/*:replace-rot*/
static pointer coordinaM4523coordinates_replace_rot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*replace-matrix*/
	local[0]= w;
coordinaBLK4524:
	ctx->vsp=local; return(local[0]);}

/*:replace-pos*/
static pointer coordinaM4525coordinates_replace_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[4]); /*replace*/
	local[0]= w;
coordinaBLK4526:
	ctx->vsp=local; return(local[0]);}

/*:replace-coords*/
static pointer coordinaM4527coordinates_replace_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4530;}
	local[0]= NIL;
coordinaENT4530:
coordinaENT4529:
	if (n>4) maerror();
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+1); /*coordinates-p*/
	if (w==NIL) goto coordinaIF4531;
	local[0] = argv[2]->c.obj.iv[2];
	argv[2] = argv[2]->c.obj.iv[1];
	local[1]= argv[2];
	goto coordinaIF4532;
coordinaIF4531:
	local[1]= NIL;
coordinaIF4532:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[3]); /*replace-matrix*/
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[4]); /*replace*/
	w = argv[0];
	local[0]= w;
coordinaBLK4528:
	ctx->vsp=local; return(local[0]);}

/*:copy-rot*/
static pointer coordinaM4533coordinates_copy_rot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[5]); /*copy-matrix*/
	local[0]= w;
coordinaBLK4534:
	ctx->vsp=local; return(local[0]);}

/*:copy-pos*/
static pointer coordinaM4535coordinates_copy_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+1;
	w=(pointer)COPYSEQ(ctx,1,local+0); /*copy-seq*/
	local[0]= w;
coordinaBLK4536:
	ctx->vsp=local; return(local[0]);}

/*:copy-coords*/
static pointer coordinaM4537coordinates_copy_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4540;}
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[6];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
coordinaENT4540:
coordinaENT4539:
	if (n>3) maerror();
	local[1]= local[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[4]); /*replace*/
	local[1]= local[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[3]); /*replace-matrix*/
	w = local[0];
	local[0]= w;
coordinaBLK4538:
	ctx->vsp=local; return(local[0]);}

/*:coords*/
static pointer coordinaM4541coordinates_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4544;}
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[6];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
coordinaENT4544:
coordinaENT4543:
	if (n>3) maerror();
	local[1]= local[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[4]); /*replace*/
	local[1]= local[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[3]); /*replace-matrix*/
	w = local[0];
	local[0]= w;
coordinaBLK4542:
	ctx->vsp=local; return(local[0]);}

/*:worldrot*/
static pointer coordinaM4545coordinates_worldrot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
coordinaBLK4546:
	ctx->vsp=local; return(local[0]);}

/*:worldpos*/
static pointer coordinaM4547coordinates_worldpos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
coordinaBLK4548:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer coordinaM4549coordinates_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0];
	local[0]= w;
coordinaBLK4550:
	ctx->vsp=local; return(local[0]);}

/*:copy-worldcoords*/
static pointer coordinaM4551coordinates_copy_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[7];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
coordinaBLK4552:
	ctx->vsp=local; return(local[0]);}

/*:parentcoords*/
static pointer coordinaM4553coordinates_parentcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = loadglobal(fqv[8]);
	local[0]= w;
coordinaBLK4554:
	ctx->vsp=local; return(local[0]);}

/*:changed*/
static pointer coordinaM4555coordinates_changed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
coordinaBLK4556:
	ctx->vsp=local; return(local[0]);}

/*:reset-coords*/
static pointer coordinaM4557coordinates_reset_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[9]); /*array-dimension*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[10]); /*unit-matrix*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= loadglobal(fqv[11]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	argv[0]->c.obj.iv[2] = w;
	local[1]= argv[0];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
coordinaBLK4558:
	ctx->vsp=local; return(local[0]);}

/*:move-to*/
static pointer coordinaM4559coordinates_move_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4562;}
	local[0]= fqv[13];
coordinaENT4562:
coordinaENT4561:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+3); /*coordinates-p*/
	if (w!=NIL) goto coordinaIF4563;
	local[3]= fqv[14];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto coordinaIF4564;
coordinaIF4563:
	local[3]= NIL;
coordinaIF4564:
	local[3]= local[0];
	w = fqv[15];
	if (memq(local[3],w)!=NIL) goto coordinaOR4567;
	local[3]= local[0];
	if (argv[0]==local[3]) goto coordinaOR4567;
	goto coordinaCON4566;
coordinaOR4567:
	local[3]= argv[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4565;
coordinaCON4566:
	local[3]= local[0];
	w = fqv[17];
	if (memq(local[3],w)!=NIL) goto coordinaOR4569;
	local[3]= local[0];
	local[4]= loadglobal(fqv[8]);
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w!=NIL) goto coordinaOR4569;
	goto coordinaCON4568;
coordinaOR4569:
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4565;
coordinaCON4568:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+3); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4570;
	local[3]= local[0];
	local[4]= fqv[18];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[19];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+3); /*transform-coords*/
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4565;
coordinaCON4570:
	local[3]= NIL;
coordinaCON4565:
	w = local[3];
	local[0]= w;
coordinaBLK4560:
	ctx->vsp=local; return(local[0]);}

/*:rotate-vector*/
static pointer coordinaM4571coordinates_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
coordinaBLK4572:
	ctx->vsp=local; return(local[0]);}

/*:transform-vector*/
static pointer coordinaM4573coordinates_transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
coordinaBLK4574:
	ctx->vsp=local; return(local[0]);}

/*:inverse-transform-vector*/
static pointer coordinaM4575coordinates_inverse_transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)TRANSPOSE(ctx,1,local+0); /*transpose*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)TRANSFORM(ctx,2,local+1); /*transform*/
	local[1]= w;
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,2,local+2); /*transform*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VMINUS(ctx,2,local+1); /*v-*/
	local[0]= w;
coordinaBLK4576:
	ctx->vsp=local; return(local[0]);}

/*:inverse-transformation*/
static pointer coordinaM4577coordinates_inverse_transformation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4580;}
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[6];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
coordinaENT4580:
coordinaENT4579:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,2,local+1); /*transpose*/
	local[1]= local[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,3,local+1); /*transform*/
	local[1]= makeflt(-1.0000000000000000000000e+00);
	local[2]= local[0]->c.obj.iv[2];
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,3,local+1); /*scale*/
	w = local[0];
	local[0]= w;
coordinaBLK4578:
	ctx->vsp=local; return(local[0]);}

/*:transformation*/
static pointer coordinaM4581coordinates_transformation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4584;}
	local[0]= fqv[13];
coordinaENT4584:
coordinaENT4583:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[0];
	w = fqv[21];
	if (memq(local[4],w)!=NIL) goto coordinaOR4587;
	local[4]= local[0];
	if (argv[0]==local[4]) goto coordinaOR4587;
	goto coordinaCON4586;
coordinaOR4587:
	local[4]= local[2];
	local[5]= argv[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= w;
	goto coordinaCON4585;
coordinaCON4586:
	local[4]= local[0];
	w = fqv[22];
	if (memq(local[4],w)!=NIL) goto coordinaOR4589;
	local[4]= local[0];
	if (loadglobal(fqv[8])==local[4]) goto coordinaOR4589;
	goto coordinaCON4588;
coordinaOR4589:
	local[4]= argv[2];
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= w;
	goto coordinaCON4585;
coordinaCON4588:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+4); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4590;
	local[4]= local[0];
	local[5]= fqv[18];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[3] = w;
	local[4]= argv[2];
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= local[3];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= local[2];
	local[5]= local[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+4); /*transform-coords*/
	local[4]= w;
	goto coordinaCON4585;
coordinaCON4590:
	local[4]= argv[0];
	local[5]= fqv[23];
	local[6]= fqv[24];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto coordinaCON4585;
coordinaCON4591:
	local[4]= NIL;
coordinaCON4585:
	w = local[2];
	local[0]= w;
coordinaBLK4582:
	ctx->vsp=local; return(local[0]);}

/*:transform*/
static pointer coordinaM4592coordinates_transform(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4595;}
	local[0]= fqv[13];
coordinaENT4595:
coordinaENT4594:
	if (n>4) maerror();
	local[1]= local[0];
	w = fqv[25];
	if (memq(local[1],w)!=NIL) goto coordinaOR4598;
	local[1]= local[0];
	if (argv[0]==local[1]) goto coordinaOR4598;
	goto coordinaCON4597;
coordinaOR4598:
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4596;
coordinaCON4597:
	local[1]= local[0];
	w = fqv[26];
	if (memq(local[1],w)!=NIL) goto coordinaOR4600;
	local[1]= local[0];
	if (loadglobal(fqv[8])==local[1]) goto coordinaOR4600;
	goto coordinaCON4599;
coordinaOR4600:
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4596;
coordinaCON4599:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+1); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4601;
	local[1]= local[0];
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= local[0];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4596;
coordinaCON4601:
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= fqv[27];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4596;
coordinaCON4602:
	local[1]= NIL;
coordinaCON4596:
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
coordinaBLK4593:
	ctx->vsp=local; return(local[0]);}

/*:rotate-with-matrix*/
static pointer coordinaM4603coordinates_rotate_with_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[28];
	if (memq(local[0],w)!=NIL) goto coordinaOR4607;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4607;
	goto coordinaCON4606;
coordinaOR4607:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= w;
	goto coordinaCON4605;
coordinaCON4606:
	local[0]= argv[3];
	w = fqv[29];
	if (memq(local[0],w)!=NIL) goto coordinaOR4609;
	local[0]= argv[3];
	if (loadglobal(fqv[8])==local[0]) goto coordinaOR4609;
	goto coordinaCON4608;
coordinaOR4609:
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= w;
	goto coordinaCON4605;
coordinaCON4608:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+0); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4610;
	local[0]= argv[3];
	local[1]= fqv[30];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= NIL;
	local[3]= argv[2];
	local[4]= local[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= local[0];
	local[4]= local[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= local[1];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[0]= w;
	goto coordinaCON4605;
coordinaCON4610:
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= fqv[31];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4605;
coordinaCON4611:
	local[0]= NIL;
coordinaCON4605:
	w = local[0];
	local[0]= w;
coordinaBLK4604:
	ctx->vsp=local; return(local[0]);}

/*:rotate*/
static pointer coordinaM4612coordinates_rotate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4616;}
	local[0]= NIL;
coordinaENT4616:
	if (n>=5) { local[1]=(argv[4]); goto coordinaENT4615;}
	local[1]= fqv[13];
coordinaENT4615:
coordinaENT4614:
	if (n>5) maerror();
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
	if (makeint((eusinteger_t)2L)!=local[2]) goto coordinaCON4618;
	w = argv[2];
	if (!numberp(w)) goto coordinaCON4620;
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[2];
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= w;
	goto coordinaCON4619;
coordinaCON4620:
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,1,local+2,&ftab[6],fqv[32]); /*matrixp*/
	if (w==NIL) goto coordinaCON4621;
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)MATTIMES(ctx,3,local+2); /*m**/
	local[2]= w;
	goto coordinaCON4619;
coordinaCON4621:
	local[2]= fqv[33];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto coordinaCON4619;
coordinaCON4622:
	local[2]= NIL;
coordinaCON4619:
	goto coordinaCON4617;
coordinaCON4618:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,1,local+2,&ftab[7],fqv[34]); /*float-vector-p*/
	if (w==NIL) goto coordinaCON4623;
	local[2]= argv[0];
	local[3]= fqv[35];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+4); /*rotation-matrix*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto coordinaCON4617;
coordinaCON4623:
	if (local[0]!=NIL) goto coordinaCON4624;
	local[2]= argv[0];
	local[3]= fqv[35];
	local[4]= argv[2];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto coordinaCON4617;
coordinaCON4624:
	local[2]= local[1];
	w = fqv[36];
	if (memq(local[2],w)!=NIL) goto coordinaOR4628;
	local[2]= local[1];
	if (argv[0]==local[2]) goto coordinaOR4628;
	goto coordinaCON4627;
coordinaOR4628:
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[2];
	local[4]= local[0];
	local[5]= NIL;
	local[6]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= w;
	goto coordinaCON4626;
coordinaCON4627:
	local[2]= local[1];
	w = fqv[37];
	if (memq(local[2],w)!=NIL) goto coordinaOR4630;
	local[2]= local[1];
	if (loadglobal(fqv[8])==local[2]) goto coordinaOR4630;
	goto coordinaCON4629;
coordinaOR4630:
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[2];
	local[4]= local[0];
	local[5]= T;
	local[6]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(pointer)ROTMAT(ctx,5,local+2); /*rotate-matrix*/
	local[2]= w;
	goto coordinaCON4626;
coordinaCON4629:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+2); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4631;
	local[2]= argv[0];
	local[3]= fqv[35];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+4); /*rotation-matrix*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto coordinaCON4626;
coordinaCON4631:
	local[2]= argv[0];
	local[3]= fqv[23];
	local[4]= fqv[38];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	goto coordinaCON4626;
coordinaCON4632:
	local[2]= NIL;
coordinaCON4626:
	goto coordinaCON4617;
coordinaCON4625:
	local[2]= NIL;
coordinaCON4617:
	local[2]= argv[0];
	local[3]= fqv[16];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0]= w;
coordinaBLK4613:
	ctx->vsp=local; return(local[0]);}

/*:orient-with-matrix*/
static pointer coordinaM4633coordinates_orient_with_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[39];
	if (memq(local[0],w)!=NIL) goto coordinaOR4637;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4637;
	goto coordinaCON4636;
coordinaOR4637:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= w;
	goto coordinaCON4635;
coordinaCON4636:
	local[0]= argv[3];
	w = fqv[40];
	if (memq(local[0],w)!=NIL) goto coordinaOR4639;
	local[0]= argv[3];
	if (loadglobal(fqv[8])==local[0]) goto coordinaOR4639;
	goto coordinaCON4638;
coordinaOR4639:
	argv[0]->c.obj.iv[1] = argv[2];
	local[0]= argv[0]->c.obj.iv[1];
	goto coordinaCON4635;
coordinaCON4638:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+0); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4640;
	local[0]= argv[3];
	local[1]= fqv[30];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)MATTIMES(ctx,3,local+1); /*m**/
	local[0]= w;
	goto coordinaCON4635;
coordinaCON4640:
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= fqv[41];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4635;
coordinaCON4641:
	local[0]= NIL;
coordinaCON4635:
	w = local[0];
	local[0]= w;
coordinaBLK4634:
	ctx->vsp=local; return(local[0]);}

/*:orient*/
static pointer coordinaM4642coordinates_orient(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto coordinaENT4645;}
	local[0]= fqv[13];
coordinaENT4645:
coordinaENT4644:
	if (n>5) maerror();
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[34]); /*float-vector-p*/
	if (w==NIL) goto coordinaCON4647;
	local[1]= argv[0];
	local[2]= fqv[42];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4646;
coordinaCON4647:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[32]); /*matrixp*/
	if (w==NIL) goto coordinaCON4648;
	local[1]= argv[0];
	local[2]= fqv[42];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4646;
coordinaCON4648:
	local[1]= local[0];
	w = fqv[43];
	if (memq(local[1],w)!=NIL) goto coordinaOR4652;
	local[1]= local[0];
	if (argv[0]==local[1]) goto coordinaOR4652;
	goto coordinaCON4651;
coordinaOR4652:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	local[1]= w;
	goto coordinaCON4650;
coordinaCON4651:
	local[1]= local[0];
	w = fqv[44];
	if (memq(local[1],w)!=NIL) goto coordinaOR4654;
	local[1]= local[0];
	if (loadglobal(fqv[8])==local[1]) goto coordinaOR4654;
	goto coordinaCON4653;
coordinaOR4654:
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+1); /*rotation-matrix*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= argv[0]->c.obj.iv[1];
	goto coordinaCON4650;
coordinaCON4653:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+1); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4655;
	local[1]= argv[0];
	local[2]= fqv[42];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4650;
coordinaCON4655:
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= fqv[45];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4650;
coordinaCON4656:
	local[1]= NIL;
coordinaCON4650:
	goto coordinaCON4646;
coordinaCON4649:
	local[1]= NIL;
coordinaCON4646:
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
coordinaBLK4643:
	ctx->vsp=local; return(local[0]);}

/*:parent-vector*/
static pointer coordinaM4657coordinates_parent_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[46];
	if (memq(local[0],w)!=NIL) goto coordinaOR4661;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4661;
	goto coordinaCON4660;
coordinaOR4661:
	local[0]= argv[0];
	local[1]= fqv[47];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4659;
coordinaCON4660:
	local[0]= argv[3];
	w = fqv[48];
	if (memq(local[0],w)!=NIL) goto coordinaOR4663;
	local[0]= argv[3];
	if (loadglobal(fqv[8])==local[0]) goto coordinaOR4663;
	goto coordinaCON4662;
coordinaOR4663:
	local[0]= argv[2];
	goto coordinaCON4659;
coordinaCON4662:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+0); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4664;
	local[0]= argv[3];
	local[1]= fqv[47];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4659;
coordinaCON4664:
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= fqv[49];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4659;
coordinaCON4665:
	local[0]= NIL;
coordinaCON4659:
	w = local[0];
	local[0]= w;
coordinaBLK4658:
	ctx->vsp=local; return(local[0]);}

/*:parent-orientation*/
static pointer coordinaM4666coordinates_parent_orientation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[50];
	if (memq(local[0],w)!=NIL) goto coordinaOR4670;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4670;
	goto coordinaCON4669;
coordinaOR4670:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
	goto coordinaCON4668;
coordinaCON4669:
	local[0]= argv[3];
	w = fqv[51];
	if (memq(local[0],w)!=NIL) goto coordinaOR4672;
	local[0]= argv[3];
	if (loadglobal(fqv[8])==local[0]) goto coordinaOR4672;
	goto coordinaCON4671;
coordinaOR4672:
	local[0]= argv[2];
	goto coordinaCON4668;
coordinaCON4671:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+0); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4673;
	local[0]= argv[3];
	local[1]= fqv[30];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
	goto coordinaCON4668;
coordinaCON4673:
	local[0]= argv[0];
	local[1]= fqv[23];
	local[2]= fqv[52];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4668;
coordinaCON4674:
	local[0]= NIL;
coordinaCON4668:
	w = local[0];
	local[0]= w;
coordinaBLK4667:
	ctx->vsp=local; return(local[0]);}

/*:translate*/
static pointer coordinaM4675coordinates_translate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4678;}
	local[0]= fqv[13];
coordinaENT4678:
coordinaENT4677:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0];
	local[5]= fqv[53];
	local[6]= argv[2];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[2];
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)VPLUS(ctx,3,local+4); /*v+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
coordinaBLK4676:
	ctx->vsp=local; return(local[0]);}

/*:locate*/
static pointer coordinaM4679coordinates_locate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4682;}
	local[0]= fqv[13];
coordinaENT4682:
coordinaENT4681:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= argv[0];
	local[6]= fqv[54];
	local[7]= argv[2];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,2,local+4,&ftab[2],fqv[4]); /*replace*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
coordinaBLK4680:
	ctx->vsp=local; return(local[0]);}

/*:scale*/
static pointer coordinaM4683coordinates_scale(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4686;}
	local[0]= NIL;
coordinaENT4686:
coordinaENT4685:
	if (n>3) maerror();
	if (local[0]==NIL) goto coordinaIF4687;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(*ftab[8])(ctx,3,local+1,&ftab[8],fqv[55]); /*scale-matrix*/
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto coordinaIF4688;
coordinaIF4687:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*matrix-row*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VNORM(ctx,1,local+1); /*norm*/
	local[1]= w;
coordinaIF4688:
	w = local[1];
	local[0]= w;
coordinaBLK4684:
	ctx->vsp=local; return(local[0]);}

/*:euler*/
static pointer coordinaM4689coordinates_euler(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,3,local+2,&ftab[9],fqv[56]); /*euler-matrix*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
coordinaBLK4690:
	ctx->vsp=local; return(local[0]);}

/*:euler-angle*/
static pointer coordinaM4691coordinates_euler_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)INV_EULER(ctx,1,local+0); /*euler-angle*/
	local[0]= w;
coordinaBLK4692:
	ctx->vsp=local; return(local[0]);}

/*:rpy*/
static pointer coordinaM4693coordinates_rpy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,3,local+2,&ftab[10],fqv[57]); /*rpy-matrix*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
coordinaBLK4694:
	ctx->vsp=local; return(local[0]);}

/*:rpy-angle*/
static pointer coordinaM4695coordinates_rpy_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)INV_RPY(ctx,1,local+0); /*rpy-angle*/
	local[0]= w;
coordinaBLK4696:
	ctx->vsp=local; return(local[0]);}

/*:rotation-angle*/
static pointer coordinaM4697coordinates_rotation_angle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)ROTANGLE(ctx,1,local+0); /*rotation-angle*/
	local[0]= w;
coordinaBLK4698:
	ctx->vsp=local; return(local[0]);}

/*:4x4*/
static pointer coordinaM4699coordinates_4x4(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4702;}
	local[0]= NIL;
coordinaENT4702:
coordinaENT4701:
	if (n>3) maerror();
	if (local[0]==NIL) goto coordinaCON4704;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)3L);
coordinaWHL4705:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto coordinaWHX4706;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)3L);
coordinaWHL4708:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto coordinaWHX4709;
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= local[1];
	local[7]= local[3];
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,4,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto coordinaWHL4708;
coordinaWHX4709:
	local[5]= NIL;
coordinaBLK4710:
	w = NIL;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	local[5]= local[0];
	local[6]= local[1];
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[4]); v=local[3];
	  v->c.fvec.fv[i]=fltval(w);}
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto coordinaWHL4705;
coordinaWHX4706:
	local[3]= NIL;
coordinaBLK4707:
	w = NIL;
	local[1]= argv[0];
	goto coordinaCON4703;
coordinaCON4704:
	local[1]= makeint((eusinteger_t)4L);
	local[2]= makeint((eusinteger_t)4L);
	ctx->vsp=local+3;
	w=(*ftab[11])(ctx,2,local+1,&ftab[11],fqv[58]); /*make-matrix*/
	local[0] = w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)3L);
	local[3]= makeint((eusinteger_t)3L);
	local[4]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,4,local+1); /*aset*/
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)3L);
coordinaWHL4712:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto coordinaWHX4713;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)3L);
coordinaWHL4715:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto coordinaWHX4716;
	local[5]= local[0];
	local[6]= local[1];
	local[7]= local[3];
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= local[1];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,4,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto coordinaWHL4715;
coordinaWHX4716:
	local[5]= NIL;
coordinaBLK4717:
	w = NIL;
	local[3]= local[0];
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= argv[0]->c.obj.iv[2];
	{ register eusinteger_t i=intval(local[1]);
	  w=makeflt(local[6]->c.fvec.fv[i]);}
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,4,local+3); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto coordinaWHL4712;
coordinaWHX4713:
	local[3]= NIL;
coordinaBLK4714:
	w = NIL;
	local[1]= local[0];
	goto coordinaCON4703;
coordinaCON4711:
	local[1]= NIL;
coordinaCON4703:
	w = local[1];
	local[0]= w;
coordinaBLK4700:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer coordinaM4718coordinates_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4721;}
	local[0]= T;
coordinaENT4721:
coordinaENT4720:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[30];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[59];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	w = makeint((eusinteger_t)2L);
	if ((eusinteger_t)local[5] <= (eusinteger_t)w) goto coordinaCON4723;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)INV_RPY(ctx,1,local+5); /*rpy-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[60]));
	local[7]= fqv[61];
	local[8]= local[0];
	local[9]= NIL;
	local[10]= fqv[62];
	if (local[1]==NIL) goto coordinaIF4724;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	goto coordinaIF4725;
coordinaIF4724:
	local[11]= fqv[63];
coordinaIF4725:
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,2,local+12); /*aref*/
	local[12]= w;
	local[13]= local[4];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	local[14]= local[4];
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,9,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SENDMESSAGE(ctx,5,local+5); /*send-message*/
	local[5]= w;
	goto coordinaCON4722;
coordinaCON4723:
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	if (makeint((eusinteger_t)2L)!=local[5]) goto coordinaCON4726;
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[60]));
	local[7]= fqv[61];
	local[8]= local[0];
	local[9]= NIL;
	local[10]= fqv[64];
	if (local[1]==NIL) goto coordinaIF4727;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	goto coordinaIF4728;
coordinaIF4727:
	local[11]= fqv[65];
coordinaIF4728:
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,2,local+12); /*aref*/
	local[12]= w;
	local[13]= local[4];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)AREF(ctx,2,local+13); /*aref*/
	local[13]= w;
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)ROTANGLE(ctx,1,local+14); /*rotation-angle*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,6,local+9); /*format*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SENDMESSAGE(ctx,5,local+5); /*send-message*/
	local[5]= w;
	goto coordinaCON4722;
coordinaCON4726:
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[60]));
	local[7]= fqv[61];
	local[8]= local[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SENDMESSAGE(ctx,5,local+5); /*send-message*/
	local[5]= w;
	goto coordinaCON4722;
coordinaCON4729:
	local[5]= NIL;
coordinaCON4722:
	w = local[5];
	local[0]= w;
coordinaBLK4719:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer coordinaM4730coordinates_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4733;}
	local[0]= makeint((eusinteger_t)3L);
coordinaENT4733:
coordinaENT4732:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[10]); /*unit-matrix*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= loadglobal(fqv[11]);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,2,local+1); /*instantiate*/
	argv[0]->c.obj.iv[2] = w;
	w = argv[0];
	local[0]= w;
coordinaBLK4731:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer coordinaM4734coordinates_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[66], &argv[2], n-2, local+0, 1);
	if (n & (1<<0)) goto coordinaKEY4736;
	local[0] = makeint((eusinteger_t)3L);
coordinaKEY4736:
	if (n & (1<<1)) goto coordinaKEY4737;
	local[13]= loadglobal(fqv[11]);
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[1] = w;
coordinaKEY4737:
	if (n & (1<<2)) goto coordinaKEY4738;
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,1,local+13,&ftab[5],fqv[10]); /*unit-matrix*/
	local[2] = w;
coordinaKEY4738:
	if (n & (1<<3)) goto coordinaKEY4739;
	local[3] = NIL;
coordinaKEY4739:
	if (n & (1<<4)) goto coordinaKEY4740;
	local[4] = NIL;
coordinaKEY4740:
	if (n & (1<<5)) goto coordinaKEY4741;
	local[5] = NIL;
coordinaKEY4741:
	if (n & (1<<6)) goto coordinaKEY4742;
	local[6] = NIL;
coordinaKEY4742:
	if (n & (1<<7)) goto coordinaKEY4743;
	local[7] = NIL;
coordinaKEY4743:
	if (n & (1<<8)) goto coordinaKEY4744;
	local[8] = local[7];
coordinaKEY4744:
	if (n & (1<<9)) goto coordinaKEY4745;
	local[9] = NIL;
coordinaKEY4745:
	if (n & (1<<10)) goto coordinaKEY4746;
	local[10] = fqv[13];
coordinaKEY4746:
	if (n & (1<<11)) goto coordinaKEY4747;
	local[11] = NIL;
coordinaKEY4747:
	if (n & (1<<12)) goto coordinaKEY4748;
	local[12] = NIL;
coordinaKEY4748:
	argv[0]->c.obj.iv[1] = local[2];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+13); /*coordinates-p*/
	if (w==NIL) goto coordinaIF4749;
	local[13]= local[10];
	local[14]= fqv[47];
	local[15]= local[1];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	goto coordinaIF4750;
coordinaIF4749:
	local[13]= local[1];
coordinaIF4750:
	argv[0]->c.obj.iv[2] = local[13];
	if (local[3]==NIL) goto coordinaCON4752;
	local[13]= argv[0];
	local[14]= fqv[67];
	local[15]= local[3];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[3];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[3];
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,5,local+13); /*send*/
	local[13]= w;
	goto coordinaCON4751;
coordinaCON4752:
	if (local[4]==NIL) goto coordinaCON4753;
	local[13]= argv[0];
	local[14]= fqv[68];
	local[15]= local[4];
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[4];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[4];
	local[18]= makeint((eusinteger_t)2L);
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,5,local+13); /*send*/
	local[13]= w;
	goto coordinaCON4751;
coordinaCON4753:
	if (local[8]==NIL) goto coordinaCON4754;
	local[13]= argv[0];
	local[14]= fqv[69];
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	goto coordinaCON4751;
coordinaCON4754:
	w = local[6];
	if (!iscons(w)) goto coordinaCON4755;
	local[13]= NIL;
	local[14]= local[6];
coordinaWHL4756:
	if (local[14]==NIL) goto coordinaWHX4757;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	local[15]= argv[0];
	local[16]= fqv[70];
	local[17]= local[13];
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[18];
	local[18]= w;
	local[19]= local[10];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,5,local+15); /*send*/
	goto coordinaWHL4756;
coordinaWHX4757:
	local[15]= NIL;
coordinaBLK4758:
	w = NIL;
	local[13]= w;
	goto coordinaCON4751;
coordinaCON4755:
	w = local[6];
	if (!numberp(w)) goto coordinaCON4759;
	local[13]= argv[0];
	local[14]= fqv[70];
	local[15]= local[6];
	local[16]= local[5];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,5,local+13); /*send*/
	local[13]= w;
	goto coordinaCON4751;
coordinaCON4759:
	if (local[9]==NIL) goto coordinaCON4760;
	local[13]= argv[0];
	local[14]= fqv[71];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	goto coordinaCON4751;
coordinaCON4760:
	local[13]= NIL;
coordinaCON4751:
	if (local[11]==NIL) goto coordinaIF4761;
	local[13]= argv[0];
	local[14]= fqv[2];
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	goto coordinaIF4762;
coordinaIF4761:
	local[13]= NIL;
coordinaIF4762:
	local[13]= NIL;
	local[14]= local[12];
coordinaWHL4763:
	if (local[14]==NIL) goto coordinaWHX4764;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14] = (w)->c.cons.cdr;
	w = local[15];
	local[13] = w;
	local[15]= argv[0];
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[13];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	ctx->vsp=local+18;
	w=(pointer)PUTPROP(ctx,3,local+15); /*putprop*/
	goto coordinaWHL4763;
coordinaWHX4764:
	local[15]= NIL;
coordinaBLK4765:
	w = NIL;
	w = argv[0];
	local[0]= w;
coordinaBLK4735:
	ctx->vsp=local; return(local[0]);}

/*:parent*/
static pointer coordinaM4766cascaded_coords_parent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
coordinaBLK4767:
	ctx->vsp=local; return(local[0]);}

/*:descendants*/
static pointer coordinaM4768cascaded_coords_descendants(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
coordinaBLK4769:
	ctx->vsp=local; return(local[0]);}

/*:inheritance*/
static pointer coordinaM4770cascaded_coords_inheritance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,coordinaCLO4772,env,argv,local);
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
coordinaBLK4771:
	ctx->vsp=local; return(local[0]);}

/*:leaves*/
static pointer coordinaM4773cascaded_coords_leaves(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[4]==NIL) goto coordinaIF4775;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= fqv[72];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[73]); /*send-all*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[13])(ctx,1,local+0,&ftab[13],fqv[74]); /*flatten*/
	local[0]= w;
	goto coordinaIF4776;
coordinaIF4775:
	local[0]= argv[0];
coordinaIF4776:
	w = local[0];
	local[0]= w;
coordinaBLK4774:
	ctx->vsp=local; return(local[0]);}

/*:assoc*/
static pointer coordinaM4777cascaded_coords_assoc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4780;}
	local[0]= NIL;
coordinaENT4780:
coordinaENT4779:
	if (n>4) maerror();
	local[1]= argv[2];
	w = argv[0]->c.obj.iv[4];
	if (memq(local[1],w)!=NIL) goto coordinaIF4781;
	if (local[0]!=NIL) goto coordinaIF4783;
	local[1]= argv[0];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[75];
	local[3]= argv[2];
	local[4]= fqv[18];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0] = w;
	local[1]= local[0];
	goto coordinaIF4784;
coordinaIF4783:
	local[1]= NIL;
coordinaIF4784:
	local[1]= argv[2];
	local[2]= fqv[76];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[2];
	local[2]= fqv[16];
	local[3]= local[0]->c.obj.iv[1];
	local[4]= local[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= argv[2];
	w = argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[4] = cons(ctx,local[1],w);
	local[1]= argv[2];
	goto coordinaIF4782;
coordinaIF4781:
	local[1]= NIL;
coordinaIF4782:
	w = local[1];
	local[0]= w;
coordinaBLK4778:
	ctx->vsp=local; return(local[0]);}

/*:dissoc*/
static pointer coordinaM4785cascaded_coords_dissoc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	w = argv[0]->c.obj.iv[4];
	if (memq(local[0],w)==NIL) goto coordinaIF4787;
	local[0]= argv[2];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[77];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,2,local+1,&ftab[14],fqv[78]); /*delete*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= argv[2];
	local[2]= fqv[79];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= argv[2];
	local[2]= fqv[16];
	local[3]= local[0]->c.obj.iv[1];
	local[4]= local[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = argv[2];
	local[0]= w;
	goto coordinaIF4788;
coordinaIF4787:
	local[0]= NIL;
coordinaIF4788:
	w = local[0];
	local[0]= w;
coordinaBLK4786:
	ctx->vsp=local; return(local[0]);}

/*:clear-assoc*/
static pointer coordinaM4789cascaded_coords_clear_assoc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[4];
coordinaWHL4791:
	if (local[1]==NIL) goto coordinaWHX4792;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[80];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto coordinaWHL4791;
coordinaWHX4792:
	local[2]= NIL;
coordinaBLK4793:
	w = NIL;
	w = NIL;
	local[0]= w;
coordinaBLK4790:
	ctx->vsp=local; return(local[0]);}

/*:obey*/
static pointer coordinaM4794cascaded_coords_obey(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[3]==NIL) goto coordinaIF4796;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[80];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto coordinaIF4797;
coordinaIF4796:
	local[0]= NIL;
coordinaIF4797:
	argv[0]->c.obj.iv[3] = argv[2];
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
coordinaBLK4795:
	ctx->vsp=local; return(local[0]);}

/*:disobey*/
static pointer coordinaM4798cascaded_coords_disobey(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	if (argv[0]->c.obj.iv[3]!=local[0]) goto coordinaIF4800;
	argv[0]->c.obj.iv[3] = NIL;
	local[0]= argv[0]->c.obj.iv[3];
	goto coordinaIF4801;
coordinaIF4800:
	local[0]= NIL;
coordinaIF4801:
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
coordinaBLK4799:
	ctx->vsp=local; return(local[0]);}

/*:newcoords*/
static pointer coordinaM4802cascaded_coords_newcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4805;}
	local[0]= NIL;
coordinaENT4805:
coordinaENT4804:
	if (n>4) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[60]));
	local[3]= fqv[16];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[1]= argv[0];
	local[2]= fqv[12];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = argv[0];
	local[0]= w;
coordinaBLK4803:
	ctx->vsp=local; return(local[0]);}

/*:changed*/
static pointer coordinaM4806cascaded_coords_changed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[7]!=NIL) goto coordinaIF4808;
	argv[0]->c.obj.iv[7] = T;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= fqv[12];
	ctx->vsp=local+2;
	w=(*ftab[12])(ctx,2,local+0,&ftab[12],fqv[73]); /*send-all*/
	local[0]= w;
	goto coordinaIF4809;
coordinaIF4808:
	local[0]= NIL;
coordinaIF4809:
	w = local[0];
	local[0]= w;
coordinaBLK4807:
	ctx->vsp=local; return(local[0]);}

/*:worldrot*/
static pointer coordinaM4810cascaded_coords_worldrot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = w->c.obj.iv[1];
	local[0]= w;
coordinaBLK4811:
	ctx->vsp=local; return(local[0]);}

/*:worldpos*/
static pointer coordinaM4812cascaded_coords_worldpos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = w->c.obj.iv[2];
	local[0]= w;
coordinaBLK4813:
	ctx->vsp=local; return(local[0]);}

/*:worldcoords*/
static pointer coordinaM4814cascaded_coords_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[7]==NIL) goto coordinaIF4816;
	if (argv[0]->c.obj.iv[3]==NIL) goto coordinaIF4818;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+3;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+0); /*transform-coords*/
	local[0]= w;
	goto coordinaIF4819;
coordinaIF4818:
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= fqv[69];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
coordinaIF4819:
	local[0]= argv[0];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[7] = NIL;
	local[0]= argv[0]->c.obj.iv[7];
	goto coordinaIF4817;
coordinaIF4816:
	local[0]= NIL;
coordinaIF4817:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
coordinaBLK4815:
	ctx->vsp=local; return(local[0]);}

/*:copy-worldcoords*/
static pointer coordinaM4820cascaded_coords_copy_worldcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4823;}
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[6];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = local[0];
	local[0]= w;
coordinaENT4823:
coordinaENT4822:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= local[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[5]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[4]); /*replace*/
	local[1]= local[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[5]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[3]); /*replace-matrix*/
	w = local[0];
	local[0]= w;
coordinaBLK4821:
	ctx->vsp=local; return(local[0]);}

/*:update*/
static pointer coordinaM4824cascaded_coords_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = NIL;
	local[0]= w;
coordinaBLK4825:
	ctx->vsp=local; return(local[0]);}

/*:parentcoords*/
static pointer coordinaM4826cascaded_coords_parentcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[3]==NIL) goto coordinaIF4828;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto coordinaIF4829;
coordinaIF4828:
	local[0]= argv[0];
	local[1]= fqv[82];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	if (fqv[83]!=local[1]) goto coordinaIF4830;
	local[1]= loadglobal(fqv[8]);
	goto coordinaIF4831;
coordinaIF4830:
	local[1]= local[0];
	if (fqv[84]!=local[1]) goto coordinaIF4832;
	local[1]= loadglobal(fqv[85]);
	goto coordinaIF4833;
coordinaIF4832:
	if (T==NIL) goto coordinaIF4834;
	local[1]= fqv[86];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto coordinaIF4835;
coordinaIF4834:
	local[1]= NIL;
coordinaIF4835:
coordinaIF4833:
coordinaIF4831:
	w = local[1];
	local[0]= w;
coordinaIF4829:
	w = local[0];
	local[0]= w;
coordinaBLK4827:
	ctx->vsp=local; return(local[0]);}

/*:transform-vector*/
static pointer coordinaM4836cascaded_coords_transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[47];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
coordinaBLK4837:
	ctx->vsp=local; return(local[0]);}

/*:rotate-vector*/
static pointer coordinaM4838cascaded_coords_rotate_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[87];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
coordinaBLK4839:
	ctx->vsp=local; return(local[0]);}

/*:inverse-transform-vector*/
static pointer coordinaM4840cascaded_coords_inverse_transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[18];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[88];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
coordinaBLK4841:
	ctx->vsp=local; return(local[0]);}

/*:inverse-transformation*/
static pointer coordinaM4842cascaded_coords_inverse_transformation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4845;}
	local[0]= loadglobal(fqv[0]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[6];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	w = local[0];
	local[0]= w;
coordinaENT4845:
coordinaENT4844:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[20];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
coordinaBLK4843:
	ctx->vsp=local; return(local[0]);}

/*:transformation*/
static pointer coordinaM4846cascaded_coords_transformation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4849;}
	local[0]= fqv[13];
coordinaENT4849:
coordinaENT4848:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[18];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= NIL;
	local[5]= NIL;
	local[6]= local[0];
	w = fqv[89];
	if (memq(local[6],w)!=NIL) goto coordinaOR4852;
	local[6]= local[0];
	if (argv[0]==local[6]) goto coordinaOR4852;
	goto coordinaCON4851;
coordinaOR4852:
	local[6]= local[3];
	local[7]= local[1];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto coordinaCON4850;
coordinaCON4851:
	local[6]= local[0];
	w = fqv[90];
	if (memq(local[6],w)!=NIL) goto coordinaOR4854;
	local[6]= local[0];
	if (argv[0]->c.obj.iv[3]==local[6]) goto coordinaOR4854;
	goto coordinaCON4853;
coordinaOR4854:
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[60]));
	local[8]= fqv[20];
	ctx->vsp=local+9;
	w=(pointer)SENDMESSAGE(ctx,3,local+6); /*send-message*/
	local[4] = w;
	local[6]= local[1];
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= local[3];
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= argv[0];
	local[7]= local[4];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto coordinaCON4850;
coordinaCON4853:
	local[6]= local[0];
	w = fqv[91];
	if (memq(local[6],w)!=NIL) goto coordinaOR4856;
	local[6]= local[0];
	local[7]= loadglobal(fqv[8]);
	ctx->vsp=local+8;
	w=(pointer)EQUAL(ctx,2,local+6); /*equal*/
	if (w!=NIL) goto coordinaOR4856;
	goto coordinaCON4855;
coordinaOR4856:
	local[6]= local[1];
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto coordinaCON4850;
coordinaCON4855:
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+6); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4857;
	local[6]= local[0];
	local[7]= fqv[18];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[5] = w;
	local[6]= local[3];
	local[7]= local[5];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= local[1];
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= local[5];
	local[7]= fqv[20];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[3];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+6); /*transform-coords*/
	local[6]= w;
	goto coordinaCON4850;
coordinaCON4857:
	local[6]= argv[0];
	local[7]= fqv[23];
	local[8]= fqv[92];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	goto coordinaCON4850;
coordinaCON4858:
	local[6]= NIL;
coordinaCON4850:
	w = local[6];
	local[0]= w;
coordinaBLK4847:
	ctx->vsp=local; return(local[0]);}

/*:transform*/
static pointer coordinaM4859cascaded_coords_transform(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4862;}
	local[0]= fqv[13];
coordinaENT4862:
coordinaENT4861:
	if (n>4) maerror();
	local[1]= local[0];
	w = fqv[93];
	if (memq(local[1],w)!=NIL) goto coordinaOR4865;
	local[1]= local[0];
	if (argv[0]==local[1]) goto coordinaOR4865;
	goto coordinaCON4864;
coordinaOR4865:
	local[1]= argv[0];
	local[2]= argv[2];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4863;
coordinaCON4864:
	local[1]= local[0];
	w = fqv[94];
	if (memq(local[1],w)!=NIL) goto coordinaOR4867;
	local[1]= local[0];
	if (argv[0]->c.obj.iv[3]==local[1]) goto coordinaOR4867;
	goto coordinaCON4866;
coordinaOR4867:
	local[1]= argv[2];
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+1); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4863;
coordinaCON4866:
	local[1]= local[0];
	w = fqv[95];
	if (memq(local[1],w)!=NIL) goto coordinaOR4869;
	local[1]= local[0];
	local[2]= loadglobal(fqv[8]);
	ctx->vsp=local+3;
	w=(pointer)EQUAL(ctx,2,local+1); /*equal*/
	if (w!=NIL) goto coordinaOR4869;
	goto coordinaCON4868;
coordinaOR4869:
	local[1]= argv[0];
	local[2]= fqv[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[1];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4863;
coordinaCON4868:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+1); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4870;
	local[1]= argv[0];
	local[2]= fqv[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[0];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= argv[2];
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[0];
	local[3]= fqv[18];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[2]= local[1];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+2); /*transform-coords*/
	local[1]= w;
	goto coordinaCON4863;
coordinaCON4870:
	local[1]= argv[0];
	local[2]= fqv[23];
	local[3]= fqv[96];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4863;
coordinaCON4871:
	local[1]= NIL;
coordinaCON4863:
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[0]= w;
coordinaBLK4860:
	ctx->vsp=local; return(local[0]);}

/*:move-to*/
static pointer coordinaM4872cascaded_coords_move_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto coordinaENT4875;}
	local[0]= fqv[13];
coordinaENT4875:
coordinaENT4874:
	if (n>4) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+3); /*coordinates-p*/
	if (w!=NIL) goto coordinaIF4876;
	local[3]= fqv[97];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto coordinaIF4877;
coordinaIF4876:
	local[3]= NIL;
coordinaIF4877:
	local[3]= local[0];
	w = fqv[98];
	if (memq(local[3],w)!=NIL) goto coordinaOR4880;
	local[3]= local[0];
	if (argv[0]==local[3]) goto coordinaOR4880;
	goto coordinaCON4879;
coordinaOR4880:
	local[3]= argv[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4878;
coordinaCON4879:
	local[3]= local[0];
	w = fqv[99];
	if (memq(local[3],w)!=NIL) goto coordinaOR4882;
	local[3]= local[0];
	if (argv[0]->c.obj.iv[3]==local[3]) goto coordinaOR4882;
	goto coordinaCON4881;
coordinaOR4882:
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4878;
coordinaCON4881:
	local[3]= local[0];
	w = fqv[100];
	if (memq(local[3],w)!=NIL) goto coordinaOR4884;
	local[3]= local[0];
	local[4]= loadglobal(fqv[8]);
	ctx->vsp=local+5;
	w=(pointer)EQUAL(ctx,2,local+3); /*equal*/
	if (w!=NIL) goto coordinaOR4884;
	goto coordinaCON4883;
coordinaOR4884:
	local[3]= argv[0];
	local[4]= fqv[19];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4878;
coordinaCON4883:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+3); /*coordinates-p*/
	if (w==NIL) goto coordinaCON4885;
	local[3]= local[0];
	local[4]= fqv[18];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= argv[0];
	local[4]= fqv[19];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+3); /*transform-coords*/
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto coordinaCON4878;
coordinaCON4885:
	local[3]= NIL;
coordinaCON4878:
	w = local[3];
	local[0]= w;
coordinaBLK4873:
	ctx->vsp=local; return(local[0]);}

/*:rotate-with-matrix*/
static pointer coordinaM4886cascaded_coords_rotate_with_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[101];
	if (memq(local[0],w)!=NIL) goto coordinaOR4890;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4890;
	goto coordinaCON4889;
coordinaOR4890:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4888;
coordinaCON4889:
	local[0]= argv[3];
	w = fqv[102];
	if (memq(local[0],w)!=NIL) goto coordinaOR4892;
	local[0]= argv[3];
	if (argv[0]->c.obj.iv[3]==local[0]) goto coordinaOR4892;
	goto coordinaCON4891;
coordinaOR4892:
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4888;
coordinaCON4891:
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[1];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+3); /*coordinates-p*/
	if (w==NIL) goto coordinaIF4894;
	local[3]= argv[3];
	local[4]= fqv[30];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[0] = w;
	local[3]= local[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MATTIMES(ctx,2,local+3); /*m**/
	argv[2] = w;
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)TRANSPOSE(ctx,1,local+4); /*transpose*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= w;
	goto coordinaIF4895;
coordinaIF4894:
	local[3]= NIL;
coordinaIF4895:
	local[3]= argv[2];
	local[4]= local[2];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)TRANSPOSE(ctx,1,local+3); /*transpose*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= argv[2];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[0]= w;
	goto coordinaCON4888;
coordinaCON4893:
	local[0]= NIL;
coordinaCON4888:
	w = local[0];
	local[0]= w;
coordinaBLK4887:
	ctx->vsp=local; return(local[0]);}

/*:rotate*/
static pointer coordinaM4896cascaded_coords_rotate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto coordinaENT4899;}
	local[0]= fqv[13];
coordinaENT4899:
coordinaENT4898:
	if (n>5) maerror();
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	if (makeint((eusinteger_t)2L)!=local[1]) goto coordinaCON4901;
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[60]));
	local[3]= fqv[70];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[1]= w;
	goto coordinaCON4900;
coordinaCON4901:
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[34]); /*float-vector-p*/
	if (w==NIL) goto coordinaCON4902;
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4900;
coordinaCON4902:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[32]); /*matrixp*/
	if (w==NIL) goto coordinaCON4903;
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4900;
coordinaCON4903:
	local[1]= local[0];
	w = fqv[103];
	if (memq(local[1],w)!=NIL) goto coordinaOR4907;
	local[1]= local[0];
	if (argv[0]==local[1]) goto coordinaOR4907;
	goto coordinaCON4906;
coordinaOR4907:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4905;
coordinaCON4906:
	local[1]= local[0];
	w = fqv[104];
	if (memq(local[1],w)!=NIL) goto coordinaOR4909;
	local[1]= local[0];
	if (argv[0]->c.obj.iv[3]==local[1]) goto coordinaOR4909;
	goto coordinaCON4908;
coordinaOR4909:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= T;
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4905;
coordinaCON4908:
	local[1]= argv[0];
	local[2]= fqv[35];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4905;
coordinaCON4910:
	local[1]= NIL;
coordinaCON4905:
	goto coordinaCON4900;
coordinaCON4904:
	local[1]= NIL;
coordinaCON4900:
	w = local[1];
	local[0]= w;
coordinaBLK4897:
	ctx->vsp=local; return(local[0]);}

/*:orient-with-matrix*/
static pointer coordinaM4911cascaded_coords_orient_with_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[105];
	if (memq(local[0],w)!=NIL) goto coordinaOR4915;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4915;
	goto coordinaCON4914;
coordinaOR4915:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4913;
coordinaCON4914:
	local[0]= argv[3];
	w = fqv[106];
	if (memq(local[0],w)!=NIL) goto coordinaOR4917;
	local[0]= argv[3];
	if (argv[0]->c.obj.iv[3]==local[0]) goto coordinaOR4917;
	goto coordinaCON4916;
coordinaOR4917:
	argv[0]->c.obj.iv[1] = argv[2];
	local[0]= argv[0];
	local[1]= fqv[16];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto coordinaCON4913;
coordinaCON4916:
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[19];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= local[1]->c.obj.iv[1];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+3); /*coordinates-p*/
	if (w==NIL) goto coordinaIF4919;
	local[3]= argv[3];
	local[4]= fqv[30];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[0] = w;
	local[3]= local[0];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)MATTIMES(ctx,2,local+3); /*m**/
	argv[2] = w;
	local[3]= argv[2];
	goto coordinaIF4920;
coordinaIF4919:
	local[3]= NIL;
coordinaIF4920:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)TRANSPOSE(ctx,1,local+3); /*transpose*/
	local[3]= w;
	local[4]= argv[2];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)MATTIMES(ctx,3,local+3); /*m**/
	local[3]= argv[0];
	local[4]= fqv[16];
	local[5]= argv[0]->c.obj.iv[1];
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[0]= w;
	goto coordinaCON4913;
coordinaCON4918:
	local[0]= NIL;
coordinaCON4913:
	w = local[0];
	local[0]= w;
coordinaBLK4912:
	ctx->vsp=local; return(local[0]);}

/*:orient*/
static pointer coordinaM4921cascaded_coords_orient(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto coordinaENT4924;}
	local[0]= fqv[13];
coordinaENT4924:
coordinaENT4923:
	if (n>5) maerror();
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[34]); /*float-vector-p*/
	if (w==NIL) goto coordinaCON4926;
	local[1]= argv[0];
	local[2]= fqv[42];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4925;
coordinaCON4926:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,1,local+1,&ftab[6],fqv[32]); /*matrixp*/
	if (w==NIL) goto coordinaCON4927;
	local[1]= argv[0];
	local[2]= fqv[42];
	local[3]= argv[2];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4925;
coordinaCON4927:
	local[1]= local[0];
	w = fqv[107];
	if (memq(local[1],w)!=NIL) goto coordinaOR4931;
	local[1]= local[0];
	if (argv[0]==local[1]) goto coordinaOR4931;
	goto coordinaCON4930;
coordinaOR4931:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4929;
coordinaCON4930:
	local[1]= local[0];
	w = fqv[108];
	if (memq(local[1],w)!=NIL) goto coordinaOR4933;
	local[1]= local[0];
	if (argv[0]->c.obj.iv[3]==local[1]) goto coordinaOR4933;
	goto coordinaCON4932;
coordinaOR4933:
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+1); /*rotation-matrix*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= argv[0];
	local[2]= fqv[16];
	local[3]= argv[0]->c.obj.iv[1];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4929;
coordinaCON4932:
	local[1]= argv[0];
	local[2]= fqv[42];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto coordinaCON4929;
coordinaCON4934:
	local[1]= NIL;
coordinaCON4929:
	goto coordinaCON4925;
coordinaCON4928:
	local[1]= NIL;
coordinaCON4925:
	w = local[1];
	local[0]= w;
coordinaBLK4922:
	ctx->vsp=local; return(local[0]);}

/*:parent-vector*/
static pointer coordinaM4935cascaded_coords_parent_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[109];
	if (memq(local[0],w)!=NIL) goto coordinaOR4939;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4939;
	goto coordinaCON4938;
coordinaOR4939:
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[60]));
	local[2]= fqv[47];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SENDMESSAGE(ctx,4,local+0); /*send-message*/
	local[0]= w;
	goto coordinaCON4937;
coordinaCON4938:
	local[0]= argv[3];
	w = fqv[110];
	if (memq(local[0],w)!=NIL) goto coordinaOR4941;
	local[0]= argv[3];
	if (argv[0]->c.obj.iv[3]==local[0]) goto coordinaOR4941;
	goto coordinaCON4940;
coordinaOR4941:
	local[0]= argv[2];
	goto coordinaCON4937;
coordinaCON4940:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+0); /*coordinates-p*/
	if (w==NIL) goto coordinaIF4943;
	local[0]= argv[3];
	local[1]= fqv[47];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	argv[2] = w;
	local[0]= argv[2];
	goto coordinaIF4944;
coordinaIF4943:
	local[0]= NIL;
coordinaIF4944:
	if (argv[0]->c.obj.iv[3]==NIL) goto coordinaIF4945;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[88];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto coordinaIF4946;
coordinaIF4945:
	local[0]= argv[2];
coordinaIF4946:
	goto coordinaCON4937;
coordinaCON4942:
	local[0]= NIL;
coordinaCON4937:
	w = local[0];
	local[0]= w;
coordinaBLK4936:
	ctx->vsp=local; return(local[0]);}

/*:parent-orientation*/
static pointer coordinaM4947cascaded_coords_parent_orientation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	w = fqv[111];
	if (memq(local[0],w)!=NIL) goto coordinaOR4951;
	local[0]= argv[3];
	if (argv[0]==local[0]) goto coordinaOR4951;
	goto coordinaCON4950;
coordinaOR4951:
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
	goto coordinaCON4949;
coordinaCON4950:
	local[0]= argv[3];
	w = fqv[112];
	if (memq(local[0],w)!=NIL) goto coordinaOR4953;
	local[0]= argv[3];
	if (argv[0]->c.obj.iv[3]==local[0]) goto coordinaOR4953;
	goto coordinaCON4952;
coordinaOR4953:
	local[0]= argv[2];
	goto coordinaCON4949;
coordinaCON4952:
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)coordinaF4488coordinates_p(ctx,1,local+0); /*coordinates-p*/
	if (w==NIL) goto coordinaIF4955;
	local[0]= argv[3];
	local[1]= fqv[30];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	argv[2] = w;
	local[0]= argv[2];
	goto coordinaIF4956;
coordinaIF4955:
	local[0]= NIL;
coordinaIF4956:
	if (argv[0]->c.obj.iv[3]==NIL) goto coordinaIF4957;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[30];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)TRANSPOSE(ctx,1,local+0); /*transpose*/
	local[0]= w;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
	goto coordinaIF4958;
coordinaIF4957:
	local[0]= argv[2];
coordinaIF4958:
	goto coordinaCON4949;
coordinaCON4954:
	local[0]= NIL;
coordinaCON4949:
	w = local[0];
	local[0]= w;
coordinaBLK4948:
	ctx->vsp=local; return(local[0]);}

/*:manager*/
static pointer coordinaM4959cascaded_coords_manager(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4962;}
	local[0]= NIL;
coordinaENT4962:
coordinaENT4961:
	if (n>3) maerror();
	if (local[0]==NIL) goto coordinaIF4963;
	argv[0]->c.obj.iv[6] = local[0];
	local[1]= argv[0]->c.obj.iv[6];
	goto coordinaIF4964;
coordinaIF4963:
	local[1]= NIL;
coordinaIF4964:
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
coordinaBLK4960:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer coordinaM4965cascaded_coords_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
coordinaRST4967:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[113], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto coordinaKEY4968;
	local[1] = NIL;
coordinaKEY4968:
	if (n & (1<<1)) goto coordinaKEY4969;
	local[2] = NIL;
coordinaKEY4969:
	local[3]= (pointer)get_sym_func(fqv[114]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[60]));
	local[6]= fqv[115];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	argv[0]->c.obj.iv[6] = argv[0];
	argv[0]->c.obj.iv[7] = T;
	local[3]= loadglobal(fqv[0]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[115];
	local[6]= fqv[116];
	local[7]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[5]); /*copy-matrix*/
	local[7]= w;
	local[8]= fqv[117];
	local[9]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+10;
	w=(pointer)COPYSEQ(ctx,1,local+9); /*copy-seq*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	w = local[3];
	argv[0]->c.obj.iv[5] = w;
	if (local[1]==NIL) goto coordinaIF4970;
	local[3]= local[1];
	local[4]= fqv[118];
	local[5]= argv[0];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	goto coordinaIF4971;
coordinaIF4970:
	local[3]= NIL;
coordinaIF4971:
	w = argv[0];
	local[0]= w;
coordinaBLK4966:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer coordinaCLO4772(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[119];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*transform-coords*/
static pointer coordinaF4489transform_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto coordinaENT4974;}
	local[0]= argv[0];
	local[1]= fqv[82];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[0]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[16];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,1,local+4,&ftab[5],fqv[10]); /*unit-matrix*/
	local[4]= w;
	local[5]= loadglobal(fqv[11]);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	w = local[1];
	local[0]= w;
coordinaENT4974:
coordinaENT4973:
	if (n>3) maerror();
	local[1]= argv[0];
	if (local[0]!=local[1]) goto coordinaIF4975;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[1]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,2,local+2); /*transform*/
	local[2]= w;
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[1]= w;
	goto coordinaIF4976;
coordinaIF4975:
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[1]->c.obj.iv[2];
	local[4]= local[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)TRANSFORM(ctx,3,local+2); /*transform*/
	local[2]= w;
	local[3]= local[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,3,local+1); /*v+*/
	local[1]= w;
coordinaIF4976:
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)MATTIMES(ctx,3,local+1); /*m**/
	w = local[0];
	local[0]= w;
coordinaBLK4972:
	ctx->vsp=local; return(local[0]);}

/*transform-coords**/
static pointer coordinaF4490transform_coords_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
coordinaRST4978:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)coordinaF4489transform_coords(ctx,2,local+3); /*transform-coords*/
	local[2] = w;
	local[3]= NIL;
	local[4]= local[0];
coordinaWHL4979:
	if (local[4]==NIL) goto coordinaWHX4980;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)coordinaF4489transform_coords(ctx,3,local+5); /*transform-coords*/
	goto coordinaWHL4979;
coordinaWHX4980:
	local[5]= NIL;
coordinaBLK4981:
	w = NIL;
	w = local[2];
	local[0]= w;
coordinaBLK4977:
	ctx->vsp=local; return(local[0]);}

/*transform-vector*/
static pointer coordinaF4491transform_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)TRANSFORM(ctx,2,local+0); /*transform*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
coordinaBLK4982:
	ctx->vsp=local; return(local[0]);}

/*make-coords*/
static pointer coordinaF4492make_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
coordinaRST4984:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[120]);
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[115];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
coordinaBLK4983:
	ctx->vsp=local; return(local[0]);}

/*make-cascoords*/
static pointer coordinaF4493make_cascoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
coordinaRST4986:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[120]);
	local[2]= loadglobal(fqv[121]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[115];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
coordinaBLK4985:
	ctx->vsp=local; return(local[0]);}

/*coords*/
static pointer coordinaF4494coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
coordinaRST4988:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[120]);
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[115];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
coordinaBLK4987:
	ctx->vsp=local; return(local[0]);}

/*cascoords*/
static pointer coordinaF4495cascoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
coordinaRST4990:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[120]);
	local[2]= loadglobal(fqv[121]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[115];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
coordinaBLK4989:
	ctx->vsp=local; return(local[0]);}

/*wrt*/
static pointer coordinaF4496wrt(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[47];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
coordinaBLK4991:
	ctx->vsp=local; return(local[0]);}

/*coordinates-distance*/
static pointer coordinaF4497coordinates_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[75];
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[59];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)VNORM(ctx,1,local+2); /*norm*/
	local[2]= w;
	local[3]= local[1];
	local[4]= fqv[30];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ROTANGLE(ctx,1,local+3); /*rotation-angle*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[0]= w;
coordinaBLK4992:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___coordinates(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[122];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w!=NIL) goto coordinaIF4993;
	local[0]= fqv[123];
	local[1]= fqv[124];
	local[2]= fqv[125];
	ctx->vsp=local+3;
	w=(*ftab[15])(ctx,3,local+0,&ftab[15],fqv[126]); /*make-package*/
	local[0]= fqv[127];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto coordinaIF4995;
	local[0]= fqv[128];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[129],w);
	goto coordinaIF4996;
coordinaIF4995:
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
coordinaIF4996:
	local[0]= fqv[131];
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[132]); /*use-package*/
	local[0]= w;
	goto coordinaIF4994;
coordinaIF4993:
	local[0]= NIL;
coordinaIF4994:
	local[0]= fqv[133];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto coordinaIF4997;
	local[0]= fqv[134];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[129],w);
	goto coordinaIF4998;
coordinaIF4997:
	local[0]= fqv[135];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
coordinaIF4998:
	local[0]= fqv[136];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[137];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[138];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[139];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[140];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[0];
	local[1]= fqv[141];
	local[2]= fqv[0];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[143]);
	local[5]= fqv[144];
	local[6]= fqv[145];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[17])(ctx,13,local+2,&ftab[17],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[151],module,coordinaF4488coordinates_p,fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4499coordinates_dimension,fqv[82],fqv[0],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4501coordinates_rot,fqv[116],fqv[0],fqv[154]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4503coordinates_pos,fqv[117],fqv[0],fqv[155]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4505coordinates_x_axis,fqv[156],fqv[0],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4507coordinates_y_axis,fqv[158],fqv[0],fqv[159]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4509coordinates_z_axis,fqv[160],fqv[0],fqv[161]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4511coordinates_name,fqv[2],fqv[0],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4517coordinates_newcoords,fqv[16],fqv[0],fqv[163]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4523coordinates_replace_rot,fqv[164],fqv[0],fqv[165]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4525coordinates_replace_pos,fqv[166],fqv[0],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4527coordinates_replace_coords,fqv[69],fqv[0],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4533coordinates_copy_rot,fqv[169],fqv[0],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4535coordinates_copy_pos,fqv[171],fqv[0],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4537coordinates_copy_coords,fqv[77],fqv[0],fqv[173]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4541coordinates_coords,fqv[7],fqv[0],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4545coordinates_worldrot,fqv[30],fqv[0],fqv[175]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4547coordinates_worldpos,fqv[59],fqv[0],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4549coordinates_worldcoords,fqv[18],fqv[0],fqv[177]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4551coordinates_copy_worldcoords,fqv[178],fqv[0],fqv[179]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4553coordinates_parentcoords,fqv[19],fqv[0],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4555coordinates_changed,fqv[12],fqv[0],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4557coordinates_reset_coords,fqv[182],fqv[0],fqv[183]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4559coordinates_move_to,fqv[184],fqv[0],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4571coordinates_rotate_vector,fqv[87],fqv[0],fqv[186]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4573coordinates_transform_vector,fqv[47],fqv[0],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4575coordinates_inverse_transform_vector,fqv[88],fqv[0],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4577coordinates_inverse_transformation,fqv[20],fqv[0],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4581coordinates_transformation,fqv[75],fqv[0],fqv[190]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4592coordinates_transform,fqv[191],fqv[0],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4603coordinates_rotate_with_matrix,fqv[35],fqv[0],fqv[193]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4612coordinates_rotate,fqv[70],fqv[0],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4633coordinates_orient_with_matrix,fqv[42],fqv[0],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4642coordinates_orient,fqv[196],fqv[0],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4657coordinates_parent_vector,fqv[54],fqv[0],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4666coordinates_parent_orientation,fqv[53],fqv[0],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4675coordinates_translate,fqv[200],fqv[0],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4679coordinates_locate,fqv[202],fqv[0],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4683coordinates_scale,fqv[204],fqv[0],fqv[205]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4689coordinates_euler,fqv[67],fqv[0],fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4691coordinates_euler_angle,fqv[207],fqv[0],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4693coordinates_rpy,fqv[68],fqv[0],fqv[209]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4695coordinates_rpy_angle,fqv[210],fqv[0],fqv[211]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4697coordinates_rotation_angle,fqv[212],fqv[0],fqv[213]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4699coordinates_4x4,fqv[71],fqv[0],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4718coordinates_prin1,fqv[61],fqv[0],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4730coordinates_create,fqv[6],fqv[0],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4734coordinates_init,fqv[115],fqv[0],fqv[217]);
	local[0]= fqv[121];
	local[1]= fqv[141];
	local[2]= fqv[121];
	local[3]= fqv[142];
	local[4]= loadglobal(fqv[0]);
	local[5]= fqv[144];
	local[6]= fqv[218];
	local[7]= fqv[146];
	local[8]= NIL;
	local[9]= fqv[147];
	local[10]= NIL;
	local[11]= fqv[148];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[149];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[17])(ctx,13,local+2,&ftab[17],fqv[150]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4766cascaded_coords_parent,fqv[219],fqv[121],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4768cascaded_coords_descendants,fqv[221],fqv[121],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4770cascaded_coords_inheritance,fqv[119],fqv[121],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4773cascaded_coords_leaves,fqv[72],fqv[121],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4777cascaded_coords_assoc,fqv[118],fqv[121],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4785cascaded_coords_dissoc,fqv[80],fqv[121],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4789cascaded_coords_clear_assoc,fqv[227],fqv[121],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4794cascaded_coords_obey,fqv[76],fqv[121],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4798cascaded_coords_disobey,fqv[79],fqv[121],fqv[230]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4802cascaded_coords_newcoords,fqv[16],fqv[121],fqv[231]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4806cascaded_coords_changed,fqv[12],fqv[121],fqv[232]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4810cascaded_coords_worldrot,fqv[30],fqv[121],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4812cascaded_coords_worldpos,fqv[59],fqv[121],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4814cascaded_coords_worldcoords,fqv[18],fqv[121],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4820cascaded_coords_copy_worldcoords,fqv[178],fqv[121],fqv[236]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4824cascaded_coords_update,fqv[81],fqv[121],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4826cascaded_coords_parentcoords,fqv[19],fqv[121],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4836cascaded_coords_transform_vector,fqv[47],fqv[121],fqv[239]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4838cascaded_coords_rotate_vector,fqv[87],fqv[121],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4840cascaded_coords_inverse_transform_vector,fqv[88],fqv[121],fqv[241]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4842cascaded_coords_inverse_transformation,fqv[20],fqv[121],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4846cascaded_coords_transformation,fqv[75],fqv[121],fqv[243]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4859cascaded_coords_transform,fqv[191],fqv[121],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4872cascaded_coords_move_to,fqv[184],fqv[121],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4886cascaded_coords_rotate_with_matrix,fqv[35],fqv[121],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4896cascaded_coords_rotate,fqv[70],fqv[121],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4911cascaded_coords_orient_with_matrix,fqv[42],fqv[121],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4921cascaded_coords_orient,fqv[196],fqv[121],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4935cascaded_coords_parent_vector,fqv[54],fqv[121],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4947cascaded_coords_parent_orientation,fqv[53],fqv[121],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4959cascaded_coords_manager,fqv[252],fqv[121],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,coordinaM4965cascaded_coords_init,fqv[115],fqv[121],fqv[254]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[255],module,coordinaF4489transform_coords,fqv[256]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[257],module,coordinaF4490transform_coords_,fqv[258]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[259],module,coordinaF4491transform_vector,fqv[260]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[261],module,coordinaF4492make_coords,fqv[262]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[263],module,coordinaF4493make_cascoords,fqv[264]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[265],module,coordinaF4494coords,fqv[266]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[267],module,coordinaF4495cascoords,fqv[268]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[269],module,coordinaF4496wrt,fqv[270]);
	local[0]= fqv[8];
	local[1]= fqv[271];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[115];
	local[5]= fqv[2];
	local[6]= fqv[8];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	w = local[2];
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[85];
	local[1]= fqv[271];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[115];
	local[5]= fqv[82];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= fqv[2];
	local[8]= fqv[85];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[272],module,coordinaF4497coordinates_distance,fqv[273]);
	local[0]= fqv[274];
	local[1]= fqv[275];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,2,local+0,&ftab[18],fqv[276]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<19; i++) ftab[i]=fcallx;
}
