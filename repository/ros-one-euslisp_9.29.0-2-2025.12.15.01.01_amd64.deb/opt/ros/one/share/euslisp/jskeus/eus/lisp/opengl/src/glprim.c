/* ./glprim.c :  entry=glprim */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Dec 15 01:02:36 UTC 2025) */
#include "eus.h"
#include "glprim.h"
#pragma init (register_glprim)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___glprim();
extern pointer build_quote_vector();
static int register_glprim()
  { add_module_initializer("___glprim", ___glprim);}

static pointer glprimF56draw_face();
static pointer glprimF57draw_body();

/*draw-face*/
static pointer glprimF56draw_face(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.cdr;
	local[1]= argv[0];
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,glprimCLO59,env,argv,local);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (w==NIL) goto glprimCON61;
	local[3]= argv[0];
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (w!=NIL) goto glprimCON61;
	local[3]= makeint((eusinteger_t)9L);
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,1,local+3,&ftab[0],fqv[4]); /*glbegin*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[5]); /*glnormal3fv*/
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,glprimCLO62,env,argv,local);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)MAPC(ctx,2,local+3); /*mapc*/
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,0,local+3,&ftab[2],fqv[6]); /*glend*/
	local[3]= w;
	goto glprimCON60;
glprimCON61:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,glprimFLET64,env,argv,local);
	local[4]= argv[0];
	local[5]= fqv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	local[6]= loadglobal(fqv[7]);
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,1,local+6,&ftab[3],fqv[8]); /*glubeginpolygon*/
	local[6]= loadglobal(fqv[7]);
	local[7]= makeint((eusinteger_t)100123L);
	ctx->vsp=local+8;
	w=(*ftab[4])(ctx,2,local+6,&ftab[4],fqv[9]); /*glunextcontour*/
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,1,local+6,&ftab[1],fqv[5]); /*glnormal3fv*/
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,glprimCLO65,env,argv,local);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)MAPC(ctx,2,local+6); /*mapc*/
	if (local[4]==NIL) goto glprimIF66;
	local[6]= NIL;
	local[7]= local[4];
glprimWHL68:
	if (local[7]==NIL) goto glprimWHX69;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[0];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,glprimCLO71,env,argv,local);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= local[3];
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)MAPCAR(ctx,2,local+10); /*mapcar*/
	local[10]= w;
	local[11]= loadglobal(fqv[7]);
	local[12]= makeint((eusinteger_t)100122L);
	ctx->vsp=local+13;
	w=(*ftab[4])(ctx,2,local+11,&ftab[4],fqv[9]); /*glunextcontour*/
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,glprimCLO72,env,argv,local);
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)MAPC(ctx,2,local+11); /*mapc*/
	local[11]= local[5];
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)NCONC(ctx,2,local+11); /*nconc*/
	goto glprimWHL68;
glprimWHX69:
	local[8]= NIL;
glprimBLK70:
	w = NIL;
	local[6]= w;
	goto glprimIF67;
glprimIF66:
	local[6]= NIL;
glprimIF67:
	local[6]= loadglobal(fqv[7]);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,1,local+6,&ftab[5],fqv[10]); /*gluendpolygon*/
	local[6]= (pointer)get_sym_func(fqv[11]);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)MAPC(ctx,2,local+6); /*mapc*/
	local[3]= w;
	goto glprimCON60;
glprimCON63:
	local[3]= NIL;
glprimCON60:
	w = local[3];
	local[0]= w;
glprimBLK58:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO59(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	if (env->c.clo.env1[1]==NIL) goto glprimIF73;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	local[2]= env->c.clo.env1[1];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[12]); /*gethash*/
	local[1]= w;
	goto glprimIF74;
glprimIF73:
	local[1]= NIL;
glprimIF74:
	if (env->c.clo.env1[2]==NIL) goto glprimIF75;
	local[2]= argv[0];
	local[3]= env->c.clo.env2[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	local[3]= env->c.clo.env1[2];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[12]); /*gethash*/
	local[2]= w;
	goto glprimIF76;
glprimIF75:
	local[2]= NIL;
glprimIF76:
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO62(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto glprimIF77;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[13]); /*gltexcoord2fv*/
	local[0]= w;
	goto glprimIF78;
glprimIF77:
	local[0]= NIL;
glprimIF78:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto glprimIF79;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[5]); /*glnormal3fv*/
	local[0]= w;
	goto glprimIF80;
glprimIF79:
	local[0]= NIL;
glprimIF80:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[14]); /*glvertex3fv*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimFLET64(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto glprimCON82;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto glprimCON82;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= makeint((eusinteger_t)1L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeint((eusinteger_t)1L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,5,local+0,&ftab[9],fqv[15]); /*alloctessinfo*/
	local[0]= w;
	goto glprimCON81;
glprimCON82:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto glprimCON83;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= makeint((eusinteger_t)1L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,5,local+0,&ftab[9],fqv[15]); /*alloctessinfo*/
	local[0]= w;
	goto glprimCON81;
glprimCON83:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto glprimCON84;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeint((eusinteger_t)1L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,5,local+0,&ftab[9],fqv[15]); /*alloctessinfo*/
	local[0]= w;
	goto glprimCON81;
glprimCON84:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeint((eusinteger_t)0L);
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(*ftab[9])(ctx,5,local+0,&ftab[9],fqv[15]); /*alloctessinfo*/
	local[0]= w;
	goto glprimCON81;
glprimCON85:
	local[0]= NIL;
glprimCON81:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO65(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,3,local+0,&ftab[10],fqv[16]); /*glutessvertex*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO71(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	if (env->c.clo.env1[1]==NIL) goto glprimIF86;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[0];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	local[2]= env->c.clo.env1[1];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[12]); /*gethash*/
	local[1]= w;
	goto glprimIF87;
glprimIF86:
	local[1]= NIL;
glprimIF87:
	if (env->c.clo.env1[2]==NIL) goto glprimIF88;
	local[2]= argv[0];
	local[3]= env->c.clo.env2[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	local[3]= env->c.clo.env1[2];
	ctx->vsp=local+4;
	w=(*ftab[6])(ctx,2,local+2,&ftab[6],fqv[12]); /*gethash*/
	local[2]= w;
	goto glprimIF89;
glprimIF88:
	local[2]= NIL;
glprimIF89:
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO72(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[7]);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[10])(ctx,3,local+0,&ftab[10],fqv[16]); /*glutessvertex*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*draw-body*/
static pointer glprimF57draw_body(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[17];
	ctx->vsp=local+2;
	w=(pointer)GETPROP(ctx,2,local+0); /*get*/
	local[0]= w;
	local[1]= argv[1];
	local[2]= fqv[18];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	local[2]= argv[1];
	local[3]= fqv[19];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	local[3]= argv[1];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	local[4]= argv[1];
	local[5]= fqv[21];
	ctx->vsp=local+6;
	w=(pointer)GETPROP(ctx,2,local+4); /*get*/
	local[4]= w;
	local[5]= local[3];
	local[6]= loadglobal(fqv[22]);
	ctx->vsp=local+7;
	w=(pointer)DERIVEDP(ctx,2,local+5); /*derivedp*/
	if (w==NIL) goto glprimCON92;
	local[5]= local[3];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	goto glprimCON91;
glprimCON92:
	local[5]= local[4];
	local[6]= loadglobal(fqv[22]);
	ctx->vsp=local+7;
	w=(pointer)DERIVEDP(ctx,2,local+5); /*derivedp*/
	if (w==NIL) goto glprimCON93;
	local[5]= local[4];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	goto glprimCON91;
glprimCON93:
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,1,local+5,&ftab[11],fqv[24]); /*float-vector-p*/
	if (w==NIL) goto glprimCON94;
	local[5]= makeint((eusinteger_t)1032L);
	local[6]= makeint((eusinteger_t)4608L);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[12])(ctx,3,local+5,&ftab[12],fqv[25]); /*glmaterialfv*/
	local[5]= makeint((eusinteger_t)1032L);
	local[6]= makeint((eusinteger_t)4609L);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[12])(ctx,3,local+5,&ftab[12],fqv[25]); /*glmaterialfv*/
	local[5]= makeint((eusinteger_t)1032L);
	local[6]= makeint((eusinteger_t)4610L);
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[12])(ctx,3,local+5,&ftab[12],fqv[25]); /*glmaterialfv*/
	local[5]= w;
	goto glprimCON91;
glprimCON94:
	local[5]= NIL;
glprimCON91:
	if (local[0]==NIL) goto glprimCON96;
	local[5]= argv[1];
	local[6]= fqv[26];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[27];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[13])(ctx,0,local+6,&ftab[13],fqv[28]); /*glpushmatrix*/
	local[6]= local[5];
	local[7]= loadglobal(fqv[29]);
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,2,local+6); /*transpose*/
	local[6]= w->c.obj.iv[1];
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,1,local+6,&ftab[14],fqv[30]); /*glmultmatrixf*/
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[15])(ctx,1,local+6,&ftab[15],fqv[31]); /*glcalllist*/
	ctx->vsp=local+6;
	w=(*ftab[16])(ctx,0,local+6,&ftab[16],fqv[32]); /*glpopmatrix*/
	local[5]= w;
	goto glprimCON95;
glprimCON96:
	if (local[1]==NIL) goto glprimCON97;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,1,local+5,&ftab[17],fqv[33]); /*glgenlists*/
	local[5]= w;
	local[6]= argv[1];
	local[7]= fqv[26];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[34];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= fqv[35];
	ctx->vsp=local+9;
	w=(pointer)GETPROP(ctx,2,local+7); /*get*/
	local[7]= w;
	local[8]= argv[1];
	local[9]= fqv[36];
	ctx->vsp=local+10;
	w=(pointer)GETPROP(ctx,2,local+8); /*get*/
	local[8]= w;
	local[8]= ((fqv[37])==(local[8])?T:NIL);
	local[9]= fqv[38];
	ctx->vsp=local+10;
	w=(*ftab[18])(ctx,1,local+9,&ftab[18],fqv[39]); /*probe-extension*/
	if (w==NIL) goto glprimIF98;
	local[9]= makeint((eusinteger_t)1L);
	local[10]= fqv[40];
	local[11]= fqv[41];
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,3,local+9,&ftab[19],fqv[42]); /*make-array*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(*ftab[20])(ctx,2,local+10,&ftab[20],fqv[43]); /*glgentexturesext*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)AREF(ctx,2,local+10); /*aref*/
	local[9]= w;
	goto glprimIF99;
glprimIF98:
	local[9]= NIL;
glprimIF99:
	local[10]= fqv[38];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,1,local+10,&ftab[18],fqv[39]); /*probe-extension*/
	if (w==NIL) goto glprimIF100;
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[44]); /*glbindtextureext*/
	local[10]= w;
	goto glprimIF101;
glprimIF100:
	local[10]= NIL;
glprimIF101:
	local[10]= makeint((eusinteger_t)3317L);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(*ftab[22])(ctx,2,local+10,&ftab[22],fqv[45]); /*glpixelstorei*/
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= makeint((eusinteger_t)10242L);
	local[12]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,3,local+10,&ftab[23],fqv[46]); /*gltexparameteri*/
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= makeint((eusinteger_t)10243L);
	local[12]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,3,local+10,&ftab[23],fqv[46]); /*gltexparameteri*/
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= makeint((eusinteger_t)10240L);
	local[12]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,3,local+10,&ftab[23],fqv[46]); /*gltexparameteri*/
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= makeint((eusinteger_t)10241L);
	local[12]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+13;
	w=(*ftab[23])(ctx,3,local+10,&ftab[23],fqv[46]); /*gltexparameteri*/
	local[10]= makeint((eusinteger_t)8960L);
	local[11]= makeint((eusinteger_t)8704L);
	local[12]= makeint((eusinteger_t)8448L);
	ctx->vsp=local+13;
	w=(*ftab[24])(ctx,3,local+10,&ftab[24],fqv[47]); /*gltexenvi*/
	local[10]= argv[1];
	local[11]= fqv[48];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	local[10]= w;
	local[11]= argv[1];
	local[12]= fqv[18];
	ctx->vsp=local+13;
	w=(pointer)GETPROP(ctx,2,local+11); /*get*/
	local[11]= w;
	local[12]= argv[1];
	local[13]= fqv[49];
	ctx->vsp=local+14;
	w=(pointer)GETPROP(ctx,2,local+12); /*get*/
	local[12]= w;
	local[13]= argv[1];
	local[14]= fqv[50];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	local[13]= w;
	local[14]= argv[1];
	local[15]= fqv[51];
	ctx->vsp=local+16;
	w=(pointer)GETPROP(ctx,2,local+14); /*get*/
	local[14]= w;
	if (local[10]!=NIL) goto glprimIF102;
	local[15]= NIL;
	local[16]= fqv[52];
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,3,local+15); /*format*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(*ftab[25])(ctx,1,local+15,&ftab[25],fqv[53]); /*warn*/
	local[15]= local[11];
	ctx->vsp=local+16;
	w=(*ftab[26])(ctx,1,local+15,&ftab[26],fqv[54]); /*load-texture-file*/
	local[15]= w;
	local[16]= argv[1];
	local[17]= local[15];
	local[18]= fqv[55];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= fqv[49];
	ctx->vsp=local+19;
	w=(pointer)PUTPROP(ctx,3,local+16); /*putprop*/
	local[16]= argv[1];
	local[17]= local[15];
	local[18]= fqv[56];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= fqv[50];
	ctx->vsp=local+19;
	w=(pointer)PUTPROP(ctx,3,local+16); /*putprop*/
	local[16]= argv[1];
	local[17]= local[15];
	local[18]= fqv[57];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= fqv[51];
	ctx->vsp=local+19;
	w=(pointer)PUTPROP(ctx,3,local+16); /*putprop*/
	local[16]= argv[1];
	local[17]= local[15];
	local[18]= fqv[58];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= fqv[48];
	ctx->vsp=local+19;
	w=(pointer)PUTPROP(ctx,3,local+16); /*putprop*/
	local[16]= local[15];
	local[17]= fqv[55];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[12] = w;
	local[16]= local[15];
	local[17]= fqv[56];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[13] = w;
	local[16]= local[15];
	local[17]= fqv[57];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[14] = w;
	local[16]= local[15];
	local[17]= fqv[58];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[10] = w;
	w = local[10];
	local[15]= w;
	goto glprimIF103;
glprimIF102:
	local[15]= NIL;
glprimIF103:
	local[15]= makeint((eusinteger_t)3553L);
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[14];
	local[18]= local[12];
	local[19]= local[13];
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[14];
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto glprimIF104;
	local[21]= makeint((eusinteger_t)6407L);
	goto glprimIF105;
glprimIF104:
	local[21]= makeint((eusinteger_t)6409L);
glprimIF105:
	local[22]= makeint((eusinteger_t)5121L);
	local[23]= local[10];
	ctx->vsp=local+24;
	w=(*ftab[27])(ctx,9,local+15,&ftab[27],fqv[59]); /*glteximage2d*/
	local[10]= argv[1];
	local[11]= fqv[60];
	local[12]= local[6];
	local[13]= fqv[61];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[1];
	local[11]= fqv[26];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= local[5];
	local[11]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+12;
	w=(*ftab[28])(ctx,2,local+10,&ftab[28],fqv[62]); /*glnewlist*/
	local[10]= fqv[38];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,1,local+10,&ftab[18],fqv[39]); /*probe-extension*/
	if (w==NIL) goto glprimIF106;
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(*ftab[21])(ctx,2,local+10,&ftab[21],fqv[44]); /*glbindtextureext*/
	local[10]= w;
	goto glprimIF107;
glprimIF106:
	local[10]= makeint((eusinteger_t)3553L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= argv[1];
	local[13]= fqv[51];
	ctx->vsp=local+14;
	w=(pointer)GETPROP(ctx,2,local+12); /*get*/
	local[12]= w;
	local[13]= argv[1];
	local[14]= fqv[49];
	ctx->vsp=local+15;
	w=(pointer)GETPROP(ctx,2,local+13); /*get*/
	local[13]= w;
	local[14]= argv[1];
	local[15]= fqv[50];
	ctx->vsp=local+16;
	w=(pointer)GETPROP(ctx,2,local+14); /*get*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	local[16]= argv[1];
	local[17]= fqv[51];
	ctx->vsp=local+18;
	w=(pointer)GETPROP(ctx,2,local+16); /*get*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)3L);
	ctx->vsp=local+18;
	w=(pointer)NUMEQUAL(ctx,2,local+16); /*=*/
	if (w==NIL) goto glprimIF108;
	local[16]= makeint((eusinteger_t)6407L);
	goto glprimIF109;
glprimIF108:
	local[16]= makeint((eusinteger_t)6409L);
glprimIF109:
	local[17]= makeint((eusinteger_t)5121L);
	local[18]= argv[1];
	local[19]= fqv[48];
	ctx->vsp=local+20;
	w=(pointer)GETPROP(ctx,2,local+18); /*get*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(*ftab[27])(ctx,9,local+10,&ftab[27],fqv[59]); /*glteximage2d*/
	local[10]= w;
glprimIF107:
	local[10]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,1,local+10,&ftab[29],fqv[63]); /*glenable*/
	if (local[8]==NIL) goto glprimCON111;
	local[10]= makeint((eusinteger_t)8192L);
	local[11]= makeint((eusinteger_t)9472L);
	local[12]= makeint((eusinteger_t)9218L);
	ctx->vsp=local+13;
	w=(*ftab[30])(ctx,3,local+10,&ftab[30],fqv[64]); /*gltexgeni*/
	local[10]= makeint((eusinteger_t)8193L);
	local[11]= makeint((eusinteger_t)9472L);
	local[12]= makeint((eusinteger_t)9218L);
	ctx->vsp=local+13;
	w=(*ftab[30])(ctx,3,local+10,&ftab[30],fqv[64]); /*gltexgeni*/
	local[10]= makeint((eusinteger_t)3168L);
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,1,local+10,&ftab[29],fqv[63]); /*glenable*/
	local[10]= makeint((eusinteger_t)3169L);
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,1,local+10,&ftab[29],fqv[63]); /*glenable*/
	local[10]= w;
	goto glprimCON110;
glprimCON111:
	local[10]= argv[1];
	local[11]= fqv[35];
	ctx->vsp=local+12;
	w=(pointer)GETPROP(ctx,2,local+10); /*get*/
	if (w!=NIL) goto glprimCON112;
	local[10]= argv[1];
	local[11]= fqv[65];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[66];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[10];
	local[13]= fqv[67];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= local[11];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[12];
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[11];
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	local[16]= local[12];
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)ELT(ctx,2,local+16); /*elt*/
	local[16]= w;
	local[17]= local[14];
	local[18]= local[13];
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,2,local+17); /*-*/
	local[17]= w;
	local[18]= local[16];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)MINUS(ctx,2,local+18); /*-*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)8192L);
	local[20]= makeint((eusinteger_t)9472L);
	local[21]= makeint((eusinteger_t)9217L);
	ctx->vsp=local+22;
	w=(*ftab[30])(ctx,3,local+19,&ftab[30],fqv[64]); /*gltexgeni*/
	local[19]= makeint((eusinteger_t)8193L);
	local[20]= makeint((eusinteger_t)9472L);
	local[21]= makeint((eusinteger_t)9217L);
	ctx->vsp=local+22;
	w=(*ftab[30])(ctx,3,local+19,&ftab[30],fqv[64]); /*gltexgeni*/
	local[19]= makeint((eusinteger_t)8192L);
	local[20]= makeint((eusinteger_t)9473L);
	local[21]= makeflt(1.0000000000000000000000e+00);
	local[22]= local[17];
	ctx->vsp=local+23;
	w=(pointer)QUOTIENT(ctx,2,local+21); /*/*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[13];
	local[25]= local[17];
	ctx->vsp=local+26;
	w=(pointer)QUOTIENT(ctx,2,local+24); /*/*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)MKFLTVEC(ctx,4,local+21); /*float-vector*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[31])(ctx,3,local+19,&ftab[31],fqv[68]); /*gltexgenfv*/
	local[19]= makeint((eusinteger_t)8193L);
	local[20]= makeint((eusinteger_t)9473L);
	local[21]= makeint((eusinteger_t)0L);
	local[22]= makeflt(1.0000000000000000000000e+00);
	local[23]= local[18];
	ctx->vsp=local+24;
	w=(pointer)QUOTIENT(ctx,2,local+22); /*/*/
	local[22]= w;
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[15];
	local[25]= local[18];
	ctx->vsp=local+26;
	w=(pointer)QUOTIENT(ctx,2,local+24); /*/*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)MKFLTVEC(ctx,4,local+21); /*float-vector*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(*ftab[31])(ctx,3,local+19,&ftab[31],fqv[68]); /*gltexgenfv*/
	local[19]= makeint((eusinteger_t)3168L);
	ctx->vsp=local+20;
	w=(*ftab[29])(ctx,1,local+19,&ftab[29],fqv[63]); /*glenable*/
	local[19]= makeint((eusinteger_t)3169L);
	ctx->vsp=local+20;
	w=(*ftab[29])(ctx,1,local+19,&ftab[29],fqv[63]); /*glenable*/
	local[10]= w;
	goto glprimCON110;
glprimCON112:
	local[10]= NIL;
glprimCON110:
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,glprimCLO113,env,argv,local);
	local[11]= argv[1];
	local[12]= fqv[69];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MAPC(ctx,2,local+10); /*mapc*/
	if (local[8]!=NIL) goto glprimOR116;
	if (local[7]==NIL) goto glprimOR116;
	goto glprimIF114;
glprimOR116:
	local[10]= makeint((eusinteger_t)3168L);
	ctx->vsp=local+11;
	w=(*ftab[32])(ctx,1,local+10,&ftab[32],fqv[70]); /*gldisable*/
	local[10]= makeint((eusinteger_t)3169L);
	ctx->vsp=local+11;
	w=(*ftab[32])(ctx,1,local+10,&ftab[32],fqv[70]); /*gldisable*/
	local[10]= w;
	goto glprimIF115;
glprimIF114:
	local[10]= NIL;
glprimIF115:
	local[10]= makeint((eusinteger_t)3553L);
	ctx->vsp=local+11;
	w=(*ftab[32])(ctx,1,local+10,&ftab[32],fqv[70]); /*gldisable*/
	ctx->vsp=local+10;
	w=(*ftab[33])(ctx,0,local+10,&ftab[33],fqv[71]); /*glendlist*/
	local[10]= argv[1];
	local[11]= fqv[60];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[1];
	local[11]= fqv[26];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= argv[1];
	local[11]= local[5];
	local[12]= fqv[17];
	ctx->vsp=local+13;
	w=(pointer)PUTPROP(ctx,3,local+10); /*putprop*/
	local[10]= argv[0];
	local[11]= argv[1];
	ctx->vsp=local+12;
	w=(pointer)glprimF57draw_body(ctx,2,local+10); /*draw-body*/
	local[5]= w;
	goto glprimCON95;
glprimCON97:
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[17])(ctx,1,local+5,&ftab[17],fqv[33]); /*glgenlists*/
	local[5]= w;
	local[6]= argv[1];
	local[7]= fqv[26];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= fqv[34];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= fqv[60];
	local[9]= local[6];
	local[10]= fqv[61];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[1];
	local[8]= fqv[26];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)4864L);
	ctx->vsp=local+9;
	w=(*ftab[28])(ctx,2,local+7,&ftab[28],fqv[62]); /*glnewlist*/
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,glprimCLO118,env,argv,local);
	local[8]= argv[1];
	local[9]= fqv[69];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MAPC(ctx,2,local+7); /*mapc*/
	ctx->vsp=local+7;
	w=(*ftab[33])(ctx,0,local+7,&ftab[33],fqv[71]); /*glendlist*/
	local[7]= argv[1];
	local[8]= fqv[60];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[1];
	local[8]= fqv[26];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= argv[1];
	local[8]= local[5];
	local[9]= fqv[17];
	ctx->vsp=local+10;
	w=(pointer)PUTPROP(ctx,3,local+7); /*putprop*/
	local[5]= argv[0];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)glprimF57draw_body(ctx,2,local+5); /*draw-body*/
	local[5]= w;
	goto glprimCON95;
glprimCON117:
	local[5]= NIL;
glprimCON95:
	w = local[5];
	local[0]= w;
glprimBLK90:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO113(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	if (env->c.clo.env2[8]!=NIL) goto glprimIF119;
	local[1]= env->c.clo.env2[7];
	goto glprimIF120;
glprimIF119:
	local[1]= NIL;
glprimIF120:
	local[2]= env->c.clo.env2[2];
	ctx->vsp=local+3;
	w=(pointer)glprimF56draw_face(ctx,3,local+0); /*draw-face*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glprimCLO118(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= env->c.clo.env2[2];
	ctx->vsp=local+3;
	w=(pointer)glprimF56draw_face(ctx,3,local+0); /*draw-face*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___glprim(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[72];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto glprimIF121;
	local[0]= fqv[73];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[74],w);
	goto glprimIF122;
glprimIF121:
	local[0]= fqv[75];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
glprimIF122:
	local[0]= fqv[76];
	local[1]= fqv[77];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glprimIF123;
	local[0]= fqv[76];
	local[1]= fqv[77];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[76];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glprimIF125;
	local[0]= fqv[76];
	local[1]= fqv[78];
	local[2]= T;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glprimIF126;
glprimIF125:
	local[0]= NIL;
glprimIF126:
	local[0]= fqv[76];
	goto glprimIF124;
glprimIF123:
	local[0]= NIL;
glprimIF124:
	local[0]= fqv[7];
	local[1]= fqv[77];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glprimIF127;
	local[0]= fqv[7];
	local[1]= fqv[77];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[7];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glprimIF129;
	local[0]= fqv[7];
	local[1]= fqv[78];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glprimIF130;
glprimIF129:
	local[0]= NIL;
glprimIF130:
	local[0]= fqv[7];
	goto glprimIF128;
glprimIF127:
	local[0]= NIL;
glprimIF128:
	local[0]= fqv[29];
	local[1]= fqv[77];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glprimIF131;
	local[0]= fqv[29];
	local[1]= fqv[77];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[29];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glprimIF133;
	local[0]= fqv[29];
	local[1]= fqv[78];
	local[2]= fqv[79];
	local[3]= fqv[40];
	local[4]= fqv[80];
	ctx->vsp=local+5;
	w=(*ftab[19])(ctx,3,local+2,&ftab[19],fqv[42]); /*make-array*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glprimIF134;
glprimIF133:
	local[0]= NIL;
glprimIF134:
	local[0]= fqv[29];
	goto glprimIF132;
glprimIF131:
	local[0]= NIL;
glprimIF132:
	local[0]= fqv[81];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[82],module,glprimF56draw_face,fqv[83]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[84],module,glprimF57draw_body,fqv[85]);
	local[0]= fqv[86];
	local[1]= fqv[87];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,2,local+0,&ftab[34],fqv[88]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<35; i++) ftab[i]=fcallx;
}
