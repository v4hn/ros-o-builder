cmake_minimum_required(VERSION 3.12)

# using pybind11_add_module requires Development component in addition to Interpreter,
# but we do not let it pull it in by itself, see https://github.com/pybind/pybind11/issues/5472
if(NOT COMMAND python_add_library)
find_package(Python ${PYTHON_VERSION} COMPONENTS Development REQUIRED)
endif()

set(PYBIND11_PYTHON_VERSION ${PYTHON_VERSION_STRING})
find_package(pybind11  REQUIRED)

list(APPEND pybind11_catkin_LIBRARIES pybind11::pybind11)
list(APPEND pybind11_catkin_INCLUDE_DIRS ${pybind11_INCLUDE_DIRS})

# Augment the pybind11_add_module function to set the output directory
macro(pybind_add_module target_name)
    pybind11_add_module(${ARGV})
    set_target_properties(${target_name} PROPERTIES LIBRARY_OUTPUT_DIRECTORY ${CATKIN_DEVEL_PREFIX}/${CATKIN_GLOBAL_PYTHON_DESTINATION})
endmacro(pybind_add_module)
