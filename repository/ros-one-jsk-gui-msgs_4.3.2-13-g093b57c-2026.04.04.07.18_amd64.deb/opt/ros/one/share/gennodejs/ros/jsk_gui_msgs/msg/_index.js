
"use strict";

let DeviceSensor = require('./DeviceSensor.js');
let Tablet = require('./Tablet.js');
let TouchEvent = require('./TouchEvent.js');
let MultiTouch = require('./MultiTouch.js');
let AndroidSensor = require('./AndroidSensor.js');
let Touch = require('./Touch.js');
let Action = require('./Action.js');
let SlackMessage = require('./SlackMessage.js');
let MagneticField = require('./MagneticField.js');
let VoiceMessage = require('./VoiceMessage.js');
let Gravity = require('./Gravity.js');

module.exports = {
  DeviceSensor: DeviceSensor,
  Tablet: Tablet,
  TouchEvent: TouchEvent,
  MultiTouch: MultiTouch,
  AndroidSensor: AndroidSensor,
  Touch: Touch,
  Action: Action,
  SlackMessage: SlackMessage,
  MagneticField: MagneticField,
  VoiceMessage: VoiceMessage,
  Gravity: Gravity,
};
