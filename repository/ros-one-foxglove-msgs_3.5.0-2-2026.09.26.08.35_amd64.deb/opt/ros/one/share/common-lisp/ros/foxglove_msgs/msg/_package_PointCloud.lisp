(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          POSE-VAL
          POSE
          POINT_STRIDE-VAL
          POINT_STRIDE
          FIELDS-VAL
          FIELDS
          DATA-VAL
          DATA
))