; Auto-generated. Do not edit!


(cl:in-package multisense_ros-msg)


;//! \htmlinclude DeviceStatus.msg.html

(cl:defclass <DeviceStatus> (roslisp-msg-protocol:ros-message)
  ((time
    :reader time
    :initarg :time
    :type cl:real
    :initform 0)
   (uptime
    :reader uptime
    :initarg :uptime
    :type cl:real
    :initform 0)
   (systemOk
    :reader systemOk
    :initarg :systemOk
    :type cl:boolean
    :initform cl:nil)
   (laserOk
    :reader laserOk
    :initarg :laserOk
    :type cl:boolean
    :initform cl:nil)
   (laserMotorOk
    :reader laserMotorOk
    :initarg :laserMotorOk
    :type cl:boolean
    :initform cl:nil)
   (camerasOk
    :reader camerasOk
    :initarg :camerasOk
    :type cl:boolean
    :initform cl:nil)
   (imuOk
    :reader imuOk
    :initarg :imuOk
    :type cl:boolean
    :initform cl:nil)
   (externalLedsOk
    :reader externalLedsOk
    :initarg :externalLedsOk
    :type cl:boolean
    :initform cl:nil)
   (processingPipelineOk
    :reader processingPipelineOk
    :initarg :processingPipelineOk
    :type cl:boolean
    :initform cl:nil)
   (powerSupplyTemp
    :reader powerSupplyTemp
    :initarg :powerSupplyTemp
    :type cl:float
    :initform 0.0)
   (fpgaTemp
    :reader fpgaTemp
    :initarg :fpgaTemp
    :type cl:float
    :initform 0.0)
   (leftImagerTemp
    :reader leftImagerTemp
    :initarg :leftImagerTemp
    :type cl:float
    :initform 0.0)
   (rightImagerTemp
    :reader rightImagerTemp
    :initarg :rightImagerTemp
    :type cl:float
    :initform 0.0)
   (inputVoltage
    :reader inputVoltage
    :initarg :inputVoltage
    :type cl:float
    :initform 0.0)
   (inputCurrent
    :reader inputCurrent
    :initarg :inputCurrent
    :type cl:float
    :initform 0.0)
   (fpgaPower
    :reader fpgaPower
    :initarg :fpgaPower
    :type cl:float
    :initform 0.0)
   (logicPower
    :reader logicPower
    :initarg :logicPower
    :type cl:float
    :initform 0.0)
   (imagerPower
    :reader imagerPower
    :initarg :imagerPower
    :type cl:float
    :initform 0.0))
)

(cl:defclass DeviceStatus (<DeviceStatus>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <DeviceStatus>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'DeviceStatus)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name multisense_ros-msg:<DeviceStatus> is deprecated: use multisense_ros-msg:DeviceStatus instead.")))

(cl:ensure-generic-function 'time-val :lambda-list '(m))
(cl:defmethod time-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:time-val is deprecated.  Use multisense_ros-msg:time instead.")
  (time m))

(cl:ensure-generic-function 'uptime-val :lambda-list '(m))
(cl:defmethod uptime-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:uptime-val is deprecated.  Use multisense_ros-msg:uptime instead.")
  (uptime m))

(cl:ensure-generic-function 'systemOk-val :lambda-list '(m))
(cl:defmethod systemOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:systemOk-val is deprecated.  Use multisense_ros-msg:systemOk instead.")
  (systemOk m))

(cl:ensure-generic-function 'laserOk-val :lambda-list '(m))
(cl:defmethod laserOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:laserOk-val is deprecated.  Use multisense_ros-msg:laserOk instead.")
  (laserOk m))

(cl:ensure-generic-function 'laserMotorOk-val :lambda-list '(m))
(cl:defmethod laserMotorOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:laserMotorOk-val is deprecated.  Use multisense_ros-msg:laserMotorOk instead.")
  (laserMotorOk m))

(cl:ensure-generic-function 'camerasOk-val :lambda-list '(m))
(cl:defmethod camerasOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:camerasOk-val is deprecated.  Use multisense_ros-msg:camerasOk instead.")
  (camerasOk m))

(cl:ensure-generic-function 'imuOk-val :lambda-list '(m))
(cl:defmethod imuOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:imuOk-val is deprecated.  Use multisense_ros-msg:imuOk instead.")
  (imuOk m))

(cl:ensure-generic-function 'externalLedsOk-val :lambda-list '(m))
(cl:defmethod externalLedsOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:externalLedsOk-val is deprecated.  Use multisense_ros-msg:externalLedsOk instead.")
  (externalLedsOk m))

(cl:ensure-generic-function 'processingPipelineOk-val :lambda-list '(m))
(cl:defmethod processingPipelineOk-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:processingPipelineOk-val is deprecated.  Use multisense_ros-msg:processingPipelineOk instead.")
  (processingPipelineOk m))

(cl:ensure-generic-function 'powerSupplyTemp-val :lambda-list '(m))
(cl:defmethod powerSupplyTemp-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:powerSupplyTemp-val is deprecated.  Use multisense_ros-msg:powerSupplyTemp instead.")
  (powerSupplyTemp m))

(cl:ensure-generic-function 'fpgaTemp-val :lambda-list '(m))
(cl:defmethod fpgaTemp-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:fpgaTemp-val is deprecated.  Use multisense_ros-msg:fpgaTemp instead.")
  (fpgaTemp m))

(cl:ensure-generic-function 'leftImagerTemp-val :lambda-list '(m))
(cl:defmethod leftImagerTemp-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:leftImagerTemp-val is deprecated.  Use multisense_ros-msg:leftImagerTemp instead.")
  (leftImagerTemp m))

(cl:ensure-generic-function 'rightImagerTemp-val :lambda-list '(m))
(cl:defmethod rightImagerTemp-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:rightImagerTemp-val is deprecated.  Use multisense_ros-msg:rightImagerTemp instead.")
  (rightImagerTemp m))

(cl:ensure-generic-function 'inputVoltage-val :lambda-list '(m))
(cl:defmethod inputVoltage-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:inputVoltage-val is deprecated.  Use multisense_ros-msg:inputVoltage instead.")
  (inputVoltage m))

(cl:ensure-generic-function 'inputCurrent-val :lambda-list '(m))
(cl:defmethod inputCurrent-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:inputCurrent-val is deprecated.  Use multisense_ros-msg:inputCurrent instead.")
  (inputCurrent m))

(cl:ensure-generic-function 'fpgaPower-val :lambda-list '(m))
(cl:defmethod fpgaPower-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:fpgaPower-val is deprecated.  Use multisense_ros-msg:fpgaPower instead.")
  (fpgaPower m))

(cl:ensure-generic-function 'logicPower-val :lambda-list '(m))
(cl:defmethod logicPower-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:logicPower-val is deprecated.  Use multisense_ros-msg:logicPower instead.")
  (logicPower m))

(cl:ensure-generic-function 'imagerPower-val :lambda-list '(m))
(cl:defmethod imagerPower-val ((m <DeviceStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader multisense_ros-msg:imagerPower-val is deprecated.  Use multisense_ros-msg:imagerPower instead.")
  (imagerPower m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <DeviceStatus>) ostream)
  "Serializes a message object of type '<DeviceStatus>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'time)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'time) (cl:floor (cl:slot-value msg 'time)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'uptime)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'uptime) (cl:floor (cl:slot-value msg 'uptime)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'systemOk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'laserOk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'laserMotorOk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'camerasOk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'imuOk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'externalLedsOk) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'processingPipelineOk) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'powerSupplyTemp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'fpgaTemp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'leftImagerTemp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'rightImagerTemp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'inputVoltage))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'inputCurrent))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'fpgaPower))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'logicPower))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'imagerPower))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <DeviceStatus>) istream)
  "Deserializes a message object of type '<DeviceStatus>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'time) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'uptime) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:slot-value msg 'systemOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'laserOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'laserMotorOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'camerasOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'imuOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'externalLedsOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'processingPipelineOk) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'powerSupplyTemp) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'fpgaTemp) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'leftImagerTemp) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'rightImagerTemp) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'inputVoltage) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'inputCurrent) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'fpgaPower) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'logicPower) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'imagerPower) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<DeviceStatus>)))
  "Returns string type for a message object of type '<DeviceStatus>"
  "multisense_ros/DeviceStatus")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'DeviceStatus)))
  "Returns string type for a message object of type 'DeviceStatus"
  "multisense_ros/DeviceStatus")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<DeviceStatus>)))
  "Returns md5sum for a message object of type '<DeviceStatus>"
  "2114c900161a6607a8d4a04b3cecd16b")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'DeviceStatus)))
  "Returns md5sum for a message object of type 'DeviceStatus"
  "2114c900161a6607a8d4a04b3cecd16b")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<DeviceStatus>)))
  "Returns full string definition for message of type '<DeviceStatus>"
  (cl:format cl:nil "time time~%time uptime~%bool systemOk~%bool laserOk~%bool laserMotorOk~%bool camerasOk~%bool imuOk~%bool externalLedsOk~%bool processingPipelineOk~%float32 powerSupplyTemp~%float32 fpgaTemp~%float32 leftImagerTemp~%float32 rightImagerTemp~%float32 inputVoltage~%float32 inputCurrent~%float32 fpgaPower~%float32 logicPower~%float32 imagerPower~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'DeviceStatus)))
  "Returns full string definition for message of type 'DeviceStatus"
  (cl:format cl:nil "time time~%time uptime~%bool systemOk~%bool laserOk~%bool laserMotorOk~%bool camerasOk~%bool imuOk~%bool externalLedsOk~%bool processingPipelineOk~%float32 powerSupplyTemp~%float32 fpgaTemp~%float32 leftImagerTemp~%float32 rightImagerTemp~%float32 inputVoltage~%float32 inputCurrent~%float32 fpgaPower~%float32 logicPower~%float32 imagerPower~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <DeviceStatus>))
  (cl:+ 0
     8
     8
     1
     1
     1
     1
     1
     1
     1
     4
     4
     4
     4
     4
     4
     4
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <DeviceStatus>))
  "Converts a ROS message object to a list"
  (cl:list 'DeviceStatus
    (cl:cons ':time (time msg))
    (cl:cons ':uptime (uptime msg))
    (cl:cons ':systemOk (systemOk msg))
    (cl:cons ':laserOk (laserOk msg))
    (cl:cons ':laserMotorOk (laserMotorOk msg))
    (cl:cons ':camerasOk (camerasOk msg))
    (cl:cons ':imuOk (imuOk msg))
    (cl:cons ':externalLedsOk (externalLedsOk msg))
    (cl:cons ':processingPipelineOk (processingPipelineOk msg))
    (cl:cons ':powerSupplyTemp (powerSupplyTemp msg))
    (cl:cons ':fpgaTemp (fpgaTemp msg))
    (cl:cons ':leftImagerTemp (leftImagerTemp msg))
    (cl:cons ':rightImagerTemp (rightImagerTemp msg))
    (cl:cons ':inputVoltage (inputVoltage msg))
    (cl:cons ':inputCurrent (inputCurrent msg))
    (cl:cons ':fpgaPower (fpgaPower msg))
    (cl:cons ':logicPower (logicPower msg))
    (cl:cons ':imagerPower (imagerPower msg))
))
