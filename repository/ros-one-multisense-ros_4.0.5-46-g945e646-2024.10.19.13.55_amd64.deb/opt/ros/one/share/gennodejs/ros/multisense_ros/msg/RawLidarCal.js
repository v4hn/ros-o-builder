// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RawLidarCal {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.laserToSpindle = null;
      this.cameraToSpindleFixed = null;
    }
    else {
      if (initObj.hasOwnProperty('laserToSpindle')) {
        this.laserToSpindle = initObj.laserToSpindle
      }
      else {
        this.laserToSpindle = new Array(16).fill(0);
      }
      if (initObj.hasOwnProperty('cameraToSpindleFixed')) {
        this.cameraToSpindleFixed = initObj.cameraToSpindleFixed
      }
      else {
        this.cameraToSpindleFixed = new Array(16).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RawLidarCal
    // Check that the constant length array field [laserToSpindle] has the right length
    if (obj.laserToSpindle.length !== 16) {
      throw new Error('Unable to serialize array field laserToSpindle - length must be 16')
    }
    // Serialize message field [laserToSpindle]
    bufferOffset = _arraySerializer.float32(obj.laserToSpindle, buffer, bufferOffset, 16);
    // Check that the constant length array field [cameraToSpindleFixed] has the right length
    if (obj.cameraToSpindleFixed.length !== 16) {
      throw new Error('Unable to serialize array field cameraToSpindleFixed - length must be 16')
    }
    // Serialize message field [cameraToSpindleFixed]
    bufferOffset = _arraySerializer.float32(obj.cameraToSpindleFixed, buffer, bufferOffset, 16);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RawLidarCal
    let len;
    let data = new RawLidarCal(null);
    // Deserialize message field [laserToSpindle]
    data.laserToSpindle = _arrayDeserializer.float32(buffer, bufferOffset, 16)
    // Deserialize message field [cameraToSpindleFixed]
    data.cameraToSpindleFixed = _arrayDeserializer.float32(buffer, bufferOffset, 16)
    return data;
  }

  static getMessageSize(object) {
    return 128;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/RawLidarCal';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a40a2eda974181d5f5f21ff840e3a6ff';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32[16] laserToSpindle
    float32[16] cameraToSpindleFixed
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RawLidarCal(null);
    if (msg.laserToSpindle !== undefined) {
      resolved.laserToSpindle = msg.laserToSpindle;
    }
    else {
      resolved.laserToSpindle = new Array(16).fill(0)
    }

    if (msg.cameraToSpindleFixed !== undefined) {
      resolved.cameraToSpindleFixed = msg.cameraToSpindleFixed;
    }
    else {
      resolved.cameraToSpindleFixed = new Array(16).fill(0)
    }

    return resolved;
    }
};

module.exports = RawLidarCal;
