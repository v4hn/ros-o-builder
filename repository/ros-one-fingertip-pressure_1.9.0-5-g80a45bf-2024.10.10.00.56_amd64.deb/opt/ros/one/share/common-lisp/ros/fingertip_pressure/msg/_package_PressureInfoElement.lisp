(cl:in-package fingertip_pressure-msg)
(cl:export '(FRAME_ID-VAL
          FRAME_ID
          CENTER-VAL
          CENTER
          HALFSIDE1-VAL
          HALFSIDE1
          HALFSIDE2-VAL
          HALFSIDE2
          FORCE_PER_UNIT-VAL
          FORCE_PER_UNIT
))