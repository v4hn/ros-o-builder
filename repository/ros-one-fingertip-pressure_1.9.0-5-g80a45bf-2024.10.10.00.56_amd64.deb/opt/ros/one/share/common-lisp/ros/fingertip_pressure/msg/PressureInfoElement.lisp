; Auto-generated. Do not edit!


(cl:in-package fingertip_pressure-msg)


;//! \htmlinclude PressureInfoElement.msg.html

(cl:defclass <PressureInfoElement> (roslisp-msg-protocol:ros-message)
  ((frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform "")
   (center
    :reader center
    :initarg :center
    :type (cl:vector geometry_msgs-msg:Vector3)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Vector3 :initial-element (cl:make-instance 'geometry_msgs-msg:Vector3)))
   (halfside1
    :reader halfside1
    :initarg :halfside1
    :type (cl:vector geometry_msgs-msg:Vector3)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Vector3 :initial-element (cl:make-instance 'geometry_msgs-msg:Vector3)))
   (halfside2
    :reader halfside2
    :initarg :halfside2
    :type (cl:vector geometry_msgs-msg:Vector3)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Vector3 :initial-element (cl:make-instance 'geometry_msgs-msg:Vector3)))
   (force_per_unit
    :reader force_per_unit
    :initarg :force_per_unit
    :type (cl:vector cl:float)
   :initform (cl:make-array 0 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass PressureInfoElement (<PressureInfoElement>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PressureInfoElement>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PressureInfoElement)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name fingertip_pressure-msg:<PressureInfoElement> is deprecated: use fingertip_pressure-msg:PressureInfoElement instead.")))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <PressureInfoElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader fingertip_pressure-msg:frame_id-val is deprecated.  Use fingertip_pressure-msg:frame_id instead.")
  (frame_id m))

(cl:ensure-generic-function 'center-val :lambda-list '(m))
(cl:defmethod center-val ((m <PressureInfoElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader fingertip_pressure-msg:center-val is deprecated.  Use fingertip_pressure-msg:center instead.")
  (center m))

(cl:ensure-generic-function 'halfside1-val :lambda-list '(m))
(cl:defmethod halfside1-val ((m <PressureInfoElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader fingertip_pressure-msg:halfside1-val is deprecated.  Use fingertip_pressure-msg:halfside1 instead.")
  (halfside1 m))

(cl:ensure-generic-function 'halfside2-val :lambda-list '(m))
(cl:defmethod halfside2-val ((m <PressureInfoElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader fingertip_pressure-msg:halfside2-val is deprecated.  Use fingertip_pressure-msg:halfside2 instead.")
  (halfside2 m))

(cl:ensure-generic-function 'force_per_unit-val :lambda-list '(m))
(cl:defmethod force_per_unit-val ((m <PressureInfoElement>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader fingertip_pressure-msg:force_per_unit-val is deprecated.  Use fingertip_pressure-msg:force_per_unit instead.")
  (force_per_unit m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PressureInfoElement>) ostream)
  "Serializes a message object of type '<PressureInfoElement>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'center))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'center))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'halfside1))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'halfside1))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'halfside2))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'halfside2))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'force_per_unit))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'force_per_unit))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PressureInfoElement>) istream)
  "Deserializes a message object of type '<PressureInfoElement>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'center) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'center)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Vector3))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'halfside1) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'halfside1)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Vector3))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'halfside2) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'halfside2)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Vector3))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'force_per_unit) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'force_per_unit)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PressureInfoElement>)))
  "Returns string type for a message object of type '<PressureInfoElement>"
  "fingertip_pressure/PressureInfoElement")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PressureInfoElement)))
  "Returns string type for a message object of type 'PressureInfoElement"
  "fingertip_pressure/PressureInfoElement")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PressureInfoElement>)))
  "Returns md5sum for a message object of type '<PressureInfoElement>"
  "1cb486bb542ab85e1ff8d84fe9cc899f")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PressureInfoElement)))
  "Returns md5sum for a message object of type 'PressureInfoElement"
  "1cb486bb542ab85e1ff8d84fe9cc899f")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PressureInfoElement>)))
  "Returns full string definition for message of type '<PressureInfoElement>"
  (cl:format cl:nil "string frame_id # Frame ID~%geometry_msgs/Vector3[] center # Corner of sensor (meters)~%geometry_msgs/Vector3[] halfside1 # Half of one edge of sensor (meters)~%geometry_msgs/Vector3[] halfside2 # Half of perpendicular edge of sensor (meters)~%# Sensor corners are at center+-halfside1+-halfside2~%# Cross product of halfside1 and halfside2 points out~%float64[] force_per_unit # Multiply this by the raw sensor value to get a force~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PressureInfoElement)))
  "Returns full string definition for message of type 'PressureInfoElement"
  (cl:format cl:nil "string frame_id # Frame ID~%geometry_msgs/Vector3[] center # Corner of sensor (meters)~%geometry_msgs/Vector3[] halfside1 # Half of one edge of sensor (meters)~%geometry_msgs/Vector3[] halfside2 # Half of perpendicular edge of sensor (meters)~%# Sensor corners are at center+-halfside1+-halfside2~%# Cross product of halfside1 and halfside2 points out~%float64[] force_per_unit # Multiply this by the raw sensor value to get a force~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PressureInfoElement>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'frame_id))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'center) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'halfside1) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'halfside2) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'force_per_unit) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PressureInfoElement>))
  "Converts a ROS message object to a list"
  (cl:list 'PressureInfoElement
    (cl:cons ':frame_id (frame_id msg))
    (cl:cons ':center (center msg))
    (cl:cons ':halfside1 (halfside1 msg))
    (cl:cons ':halfside2 (halfside2 msg))
    (cl:cons ':force_per_unit (force_per_unit msg))
))
