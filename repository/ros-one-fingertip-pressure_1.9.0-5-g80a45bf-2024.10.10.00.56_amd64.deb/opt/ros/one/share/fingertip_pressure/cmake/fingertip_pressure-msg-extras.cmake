set(fingertip_pressure_MESSAGE_FILES "msg/PressureInfoElement.msg;msg/PressureInfo.msg")
set(fingertip_pressure_SERVICE_FILES "")
