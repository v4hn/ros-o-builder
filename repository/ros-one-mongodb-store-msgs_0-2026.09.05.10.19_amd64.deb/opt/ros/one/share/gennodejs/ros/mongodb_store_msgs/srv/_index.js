
"use strict";

let MongoDeleteMsg = require('./MongoDeleteMsg.js')
let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')
let MongoInsertMsg = require('./MongoInsertMsg.js')
let MongoUpdateMsg = require('./MongoUpdateMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')

module.exports = {
  MongoDeleteMsg: MongoDeleteMsg,
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
  MongoInsertMsg: MongoInsertMsg,
  MongoUpdateMsg: MongoUpdateMsg,
  MongoQueryMsg: MongoQueryMsg,
};
