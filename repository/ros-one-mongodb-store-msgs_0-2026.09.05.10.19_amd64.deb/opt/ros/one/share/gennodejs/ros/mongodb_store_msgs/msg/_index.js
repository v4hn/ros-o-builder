
"use strict";

let StringPairList = require('./StringPairList.js');
let Insert = require('./Insert.js');
let SerialisedMessage = require('./SerialisedMessage.js');
let StringList = require('./StringList.js');
let StringPair = require('./StringPair.js');
let MoveEntriesResult = require('./MoveEntriesResult.js');
let MoveEntriesActionResult = require('./MoveEntriesActionResult.js');
let MoveEntriesAction = require('./MoveEntriesAction.js');
let MoveEntriesFeedback = require('./MoveEntriesFeedback.js');
let MoveEntriesActionFeedback = require('./MoveEntriesActionFeedback.js');
let MoveEntriesGoal = require('./MoveEntriesGoal.js');
let MoveEntriesActionGoal = require('./MoveEntriesActionGoal.js');

module.exports = {
  StringPairList: StringPairList,
  Insert: Insert,
  SerialisedMessage: SerialisedMessage,
  StringList: StringList,
  StringPair: StringPair,
  MoveEntriesResult: MoveEntriesResult,
  MoveEntriesActionResult: MoveEntriesActionResult,
  MoveEntriesAction: MoveEntriesAction,
  MoveEntriesFeedback: MoveEntriesFeedback,
  MoveEntriesActionFeedback: MoveEntriesActionFeedback,
  MoveEntriesGoal: MoveEntriesGoal,
  MoveEntriesActionGoal: MoveEntriesActionGoal,
};
