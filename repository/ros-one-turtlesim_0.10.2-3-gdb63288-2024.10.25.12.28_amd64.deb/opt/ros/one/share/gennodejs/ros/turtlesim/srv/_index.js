
"use strict";

let TeleportRelative = require('./TeleportRelative.js')
let Kill = require('./Kill.js')
let Spawn = require('./Spawn.js')
let SetPen = require('./SetPen.js')
let TeleportAbsolute = require('./TeleportAbsolute.js')

module.exports = {
  TeleportRelative: TeleportRelative,
  Kill: Kill,
  Spawn: Spawn,
  SetPen: SetPen,
  TeleportAbsolute: TeleportAbsolute,
};
