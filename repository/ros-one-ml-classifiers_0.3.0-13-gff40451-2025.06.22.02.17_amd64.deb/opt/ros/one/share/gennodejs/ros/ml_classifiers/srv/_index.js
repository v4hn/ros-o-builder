
"use strict";

let LoadClassifier = require('./LoadClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let TrainClassifier = require('./TrainClassifier.js')
let ClearClassifier = require('./ClearClassifier.js')
let AddClassData = require('./AddClassData.js')
let CreateClassifier = require('./CreateClassifier.js')
let SaveClassifier = require('./SaveClassifier.js')

module.exports = {
  LoadClassifier: LoadClassifier,
  ClassifyData: ClassifyData,
  TrainClassifier: TrainClassifier,
  ClearClassifier: ClearClassifier,
  AddClassData: AddClassData,
  CreateClassifier: CreateClassifier,
  SaveClassifier: SaveClassifier,
};
