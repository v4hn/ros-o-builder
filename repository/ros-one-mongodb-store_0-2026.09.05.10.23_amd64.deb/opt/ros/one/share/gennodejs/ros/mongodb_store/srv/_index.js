
"use strict";

let MongoInsert = require('./MongoInsert.js')
let MongoUpdate = require('./MongoUpdate.js')
let GetParam = require('./GetParam.js')
let MongoFind = require('./MongoFind.js')
let SetParam = require('./SetParam.js')

module.exports = {
  MongoInsert: MongoInsert,
  MongoUpdate: MongoUpdate,
  GetParam: GetParam,
  MongoFind: MongoFind,
  SetParam: SetParam,
};
