// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RawCamData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.frames_per_second = null;
      this.gain = null;
      this.exposure_time = null;
      this.frame_count = null;
      this.time_stamp = null;
      this.angle = null;
      this.width = null;
      this.height = null;
      this.gray_scale_image = null;
      this.disparity_image = null;
    }
    else {
      if (initObj.hasOwnProperty('frames_per_second')) {
        this.frames_per_second = initObj.frames_per_second
      }
      else {
        this.frames_per_second = 0.0;
      }
      if (initObj.hasOwnProperty('gain')) {
        this.gain = initObj.gain
      }
      else {
        this.gain = 0.0;
      }
      if (initObj.hasOwnProperty('exposure_time')) {
        this.exposure_time = initObj.exposure_time
      }
      else {
        this.exposure_time = 0;
      }
      if (initObj.hasOwnProperty('frame_count')) {
        this.frame_count = initObj.frame_count
      }
      else {
        this.frame_count = 0;
      }
      if (initObj.hasOwnProperty('time_stamp')) {
        this.time_stamp = initObj.time_stamp
      }
      else {
        this.time_stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('angle')) {
        this.angle = initObj.angle
      }
      else {
        this.angle = 0;
      }
      if (initObj.hasOwnProperty('width')) {
        this.width = initObj.width
      }
      else {
        this.width = 0;
      }
      if (initObj.hasOwnProperty('height')) {
        this.height = initObj.height
      }
      else {
        this.height = 0;
      }
      if (initObj.hasOwnProperty('gray_scale_image')) {
        this.gray_scale_image = initObj.gray_scale_image
      }
      else {
        this.gray_scale_image = [];
      }
      if (initObj.hasOwnProperty('disparity_image')) {
        this.disparity_image = initObj.disparity_image
      }
      else {
        this.disparity_image = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RawCamData
    // Serialize message field [frames_per_second]
    bufferOffset = _serializer.float32(obj.frames_per_second, buffer, bufferOffset);
    // Serialize message field [gain]
    bufferOffset = _serializer.float32(obj.gain, buffer, bufferOffset);
    // Serialize message field [exposure_time]
    bufferOffset = _serializer.uint32(obj.exposure_time, buffer, bufferOffset);
    // Serialize message field [frame_count]
    bufferOffset = _serializer.uint32(obj.frame_count, buffer, bufferOffset);
    // Serialize message field [time_stamp]
    bufferOffset = _serializer.time(obj.time_stamp, buffer, bufferOffset);
    // Serialize message field [angle]
    bufferOffset = _serializer.uint32(obj.angle, buffer, bufferOffset);
    // Serialize message field [width]
    bufferOffset = _serializer.uint16(obj.width, buffer, bufferOffset);
    // Serialize message field [height]
    bufferOffset = _serializer.uint16(obj.height, buffer, bufferOffset);
    // Serialize message field [gray_scale_image]
    bufferOffset = _arraySerializer.uint8(obj.gray_scale_image, buffer, bufferOffset, null);
    // Serialize message field [disparity_image]
    bufferOffset = _arraySerializer.uint16(obj.disparity_image, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RawCamData
    let len;
    let data = new RawCamData(null);
    // Deserialize message field [frames_per_second]
    data.frames_per_second = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [gain]
    data.gain = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [exposure_time]
    data.exposure_time = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [frame_count]
    data.frame_count = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [time_stamp]
    data.time_stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [angle]
    data.angle = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [width]
    data.width = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [height]
    data.height = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [gray_scale_image]
    data.gray_scale_image = _arrayDeserializer.uint8(buffer, bufferOffset, null)
    // Deserialize message field [disparity_image]
    data.disparity_image = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += object.gray_scale_image.length;
    length += 2 * object.disparity_image.length;
    return length + 40;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/RawCamData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5088c19778d4fa49ece5e07c0880c7e3';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 frames_per_second
    float32 gain
    uint32  exposure_time
    uint32  frame_count
    time    time_stamp
    uint32  angle
    uint16  width
    uint16  height
    uint8[] gray_scale_image
    uint16[] disparity_image
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RawCamData(null);
    if (msg.frames_per_second !== undefined) {
      resolved.frames_per_second = msg.frames_per_second;
    }
    else {
      resolved.frames_per_second = 0.0
    }

    if (msg.gain !== undefined) {
      resolved.gain = msg.gain;
    }
    else {
      resolved.gain = 0.0
    }

    if (msg.exposure_time !== undefined) {
      resolved.exposure_time = msg.exposure_time;
    }
    else {
      resolved.exposure_time = 0
    }

    if (msg.frame_count !== undefined) {
      resolved.frame_count = msg.frame_count;
    }
    else {
      resolved.frame_count = 0
    }

    if (msg.time_stamp !== undefined) {
      resolved.time_stamp = msg.time_stamp;
    }
    else {
      resolved.time_stamp = {secs: 0, nsecs: 0}
    }

    if (msg.angle !== undefined) {
      resolved.angle = msg.angle;
    }
    else {
      resolved.angle = 0
    }

    if (msg.width !== undefined) {
      resolved.width = msg.width;
    }
    else {
      resolved.width = 0
    }

    if (msg.height !== undefined) {
      resolved.height = msg.height;
    }
    else {
      resolved.height = 0
    }

    if (msg.gray_scale_image !== undefined) {
      resolved.gray_scale_image = msg.gray_scale_image;
    }
    else {
      resolved.gray_scale_image = []
    }

    if (msg.disparity_image !== undefined) {
      resolved.disparity_image = msg.disparity_image;
    }
    else {
      resolved.disparity_image = []
    }

    return resolved;
    }
};

module.exports = RawCamData;
