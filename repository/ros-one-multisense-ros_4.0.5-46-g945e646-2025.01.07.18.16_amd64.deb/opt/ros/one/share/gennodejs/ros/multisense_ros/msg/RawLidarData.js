// Auto-generated. Do not edit!

// (in-package multisense_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RawLidarData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.scan_count = null;
      this.time_start = null;
      this.time_end = null;
      this.angle_start = null;
      this.angle_end = null;
      this.distance = null;
      this.intensity = null;
    }
    else {
      if (initObj.hasOwnProperty('scan_count')) {
        this.scan_count = initObj.scan_count
      }
      else {
        this.scan_count = 0;
      }
      if (initObj.hasOwnProperty('time_start')) {
        this.time_start = initObj.time_start
      }
      else {
        this.time_start = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('time_end')) {
        this.time_end = initObj.time_end
      }
      else {
        this.time_end = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('angle_start')) {
        this.angle_start = initObj.angle_start
      }
      else {
        this.angle_start = 0;
      }
      if (initObj.hasOwnProperty('angle_end')) {
        this.angle_end = initObj.angle_end
      }
      else {
        this.angle_end = 0;
      }
      if (initObj.hasOwnProperty('distance')) {
        this.distance = initObj.distance
      }
      else {
        this.distance = [];
      }
      if (initObj.hasOwnProperty('intensity')) {
        this.intensity = initObj.intensity
      }
      else {
        this.intensity = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RawLidarData
    // Serialize message field [scan_count]
    bufferOffset = _serializer.uint32(obj.scan_count, buffer, bufferOffset);
    // Serialize message field [time_start]
    bufferOffset = _serializer.time(obj.time_start, buffer, bufferOffset);
    // Serialize message field [time_end]
    bufferOffset = _serializer.time(obj.time_end, buffer, bufferOffset);
    // Serialize message field [angle_start]
    bufferOffset = _serializer.int32(obj.angle_start, buffer, bufferOffset);
    // Serialize message field [angle_end]
    bufferOffset = _serializer.int32(obj.angle_end, buffer, bufferOffset);
    // Serialize message field [distance]
    bufferOffset = _arraySerializer.uint32(obj.distance, buffer, bufferOffset, null);
    // Serialize message field [intensity]
    bufferOffset = _arraySerializer.uint32(obj.intensity, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RawLidarData
    let len;
    let data = new RawLidarData(null);
    // Deserialize message field [scan_count]
    data.scan_count = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [time_start]
    data.time_start = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [time_end]
    data.time_end = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [angle_start]
    data.angle_start = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [angle_end]
    data.angle_end = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [distance]
    data.distance = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    // Deserialize message field [intensity]
    data.intensity = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 4 * object.distance.length;
    length += 4 * object.intensity.length;
    return length + 36;
  }

  static datatype() {
    // Returns string type for a message object
    return 'multisense_ros/RawLidarData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c6ed0471015a3cddab804db8e53836c1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 scan_count
    time time_start
    time time_end
    int32 angle_start
    int32 angle_end
    uint32[] distance
    uint32[] intensity
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RawLidarData(null);
    if (msg.scan_count !== undefined) {
      resolved.scan_count = msg.scan_count;
    }
    else {
      resolved.scan_count = 0
    }

    if (msg.time_start !== undefined) {
      resolved.time_start = msg.time_start;
    }
    else {
      resolved.time_start = {secs: 0, nsecs: 0}
    }

    if (msg.time_end !== undefined) {
      resolved.time_end = msg.time_end;
    }
    else {
      resolved.time_end = {secs: 0, nsecs: 0}
    }

    if (msg.angle_start !== undefined) {
      resolved.angle_start = msg.angle_start;
    }
    else {
      resolved.angle_start = 0
    }

    if (msg.angle_end !== undefined) {
      resolved.angle_end = msg.angle_end;
    }
    else {
      resolved.angle_end = 0
    }

    if (msg.distance !== undefined) {
      resolved.distance = msg.distance;
    }
    else {
      resolved.distance = []
    }

    if (msg.intensity !== undefined) {
      resolved.intensity = msg.intensity;
    }
    else {
      resolved.intensity = []
    }

    return resolved;
    }
};

module.exports = RawLidarData;
