
"use strict";

let DataPoints = require('./DataPoints.js');
let StatisticsNames = require('./StatisticsNames.js');
let StatisticsValues = require('./StatisticsValues.js');
let DataPoint = require('./DataPoint.js');
let Dictionary = require('./Dictionary.js');

module.exports = {
  DataPoints: DataPoints,
  StatisticsNames: StatisticsNames,
  StatisticsValues: StatisticsValues,
  DataPoint: DataPoint,
  Dictionary: Dictionary,
};
