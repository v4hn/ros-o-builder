
"use strict";

let TestSubArray = require('./TestSubArray.js');
let TestArray = require('./TestArray.js');
let TestMessage = require('./TestMessage.js');
let SimpleTestFeedback = require('./SimpleTestFeedback.js');
let SimpleTestResult = require('./SimpleTestResult.js');
let SimpleTestAction = require('./SimpleTestAction.js');
let SimpleTestActionGoal = require('./SimpleTestActionGoal.js');
let SimpleTestGoal = require('./SimpleTestGoal.js');
let SimpleTestActionResult = require('./SimpleTestActionResult.js');
let SimpleTestActionFeedback = require('./SimpleTestActionFeedback.js');

module.exports = {
  TestSubArray: TestSubArray,
  TestArray: TestArray,
  TestMessage: TestMessage,
  SimpleTestFeedback: SimpleTestFeedback,
  SimpleTestResult: SimpleTestResult,
  SimpleTestAction: SimpleTestAction,
  SimpleTestActionGoal: SimpleTestActionGoal,
  SimpleTestGoal: SimpleTestGoal,
  SimpleTestActionResult: SimpleTestActionResult,
  SimpleTestActionFeedback: SimpleTestActionFeedback,
};
