
"use strict";

let Velocity = require('./Velocity.js');
let ShapeFeedback = require('./ShapeFeedback.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeAction = require('./ShapeAction.js');

module.exports = {
  Velocity: Velocity,
  ShapeFeedback: ShapeFeedback,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeGoal: ShapeGoal,
  ShapeActionGoal: ShapeActionGoal,
  ShapeActionResult: ShapeActionResult,
  ShapeResult: ShapeResult,
  ShapeAction: ShapeAction,
};
