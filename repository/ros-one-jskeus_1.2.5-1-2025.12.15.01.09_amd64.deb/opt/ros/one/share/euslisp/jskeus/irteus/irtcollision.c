/* ./irtcollision.c :  entry=irtcollision */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Dec 15 01:02:36 UTC 2025) */
#include "eus.h"
#include "irtcollision.h"
#pragma init (register_irtcollision)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtcollision();
extern pointer build_quote_vector();
static int register_irtcollision()
  { add_module_initializer("___irtcollision", ___irtcollision);}

static pointer irtcolliF586collision_distance();
static pointer irtcolliF587collision_check();
static pointer irtcolliF588collision_check_objects();
static pointer irtcolliF589select_collision_algorithm();

/*:make-collisionmodel*/
static pointer irtcolliM590cascaded_coords_make_collisionmodel(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST592:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[1])!=local[1]) goto irtcolliCON594;
	local[1]= (pointer)get_sym_func(fqv[2]);
	local[2]= argv[0];
	local[3]= fqv[3];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON593;
irtcolliCON594:
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[4])!=local[1]) goto irtcolliCON595;
	local[1]= (pointer)get_sym_func(fqv[2]);
	local[2]= argv[0];
	local[3]= fqv[5];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON593;
irtcolliCON595:
	local[1]= fqv[6];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto irtcolliCON593;
irtcolliCON596:
	local[1]= NIL;
irtcolliCON593:
	w = local[1];
	local[0]= w;
irtcolliBLK591:
	ctx->vsp=local; return(local[0]);}

/*collision-distance*/
static pointer irtcolliF586collision_distance(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST598:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[1])!=local[1]) goto irtcolliCON600;
	local[1]= (pointer)get_sym_func(fqv[7]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON599;
irtcolliCON600:
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[4])!=local[1]) goto irtcolliCON601;
	local[1]= (pointer)get_sym_func(fqv[8]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON599;
irtcolliCON601:
	local[1]= fqv[9];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto irtcolliCON599;
irtcolliCON602:
	local[1]= NIL;
irtcolliCON599:
	w = local[1];
	local[0]= w;
irtcolliBLK597:
	ctx->vsp=local; return(local[0]);}

/*collision-check*/
static pointer irtcolliF587collision_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST604:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[1])!=local[1]) goto irtcolliCON606;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto irtcolliIF607;
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPEND(ctx,2,local+1); /*append*/
	local[0] = w;
	local[1]= local[0];
	goto irtcolliIF608;
irtcolliIF607:
	local[1]= NIL;
irtcolliIF608:
	local[1]= (pointer)get_sym_func(fqv[10]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON605;
irtcolliCON606:
	local[1]= loadglobal(fqv[0]);
	if (loadglobal(fqv[4])!=local[1]) goto irtcolliCON609;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!numberp(w)) goto irtcolliIF610;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.cdr;
	local[1]= local[0];
	goto irtcolliIF611;
irtcolliIF610:
	local[1]= NIL;
irtcolliIF611:
	local[1]= (pointer)get_sym_func(fqv[11]);
	local[2]= argv[0];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= w;
	goto irtcolliCON605;
irtcolliCON609:
	local[1]= fqv[12];
	local[2]= loadglobal(fqv[0]);
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto irtcolliCON605;
irtcolliCON612:
	local[1]= NIL;
irtcolliCON605:
	w = local[1];
	local[0]= w;
irtcolliBLK603:
	ctx->vsp=local; return(local[0]);}

/*collision-check-objects*/
static pointer irtcolliF588collision_check_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtcolliRST614:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= argv[0];
irtcolliWHL615:
	if (local[2]==NIL) goto irtcolliWHX616;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= NIL;
	local[4]= argv[1];
irtcolliWHL618:
	if (local[4]==NIL) goto irtcolliWHX619;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[1];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)irtcolliF587collision_check(ctx,2,local+5); /*collision-check*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto irtcolliIF621;
	w = T;
	ctx->vsp=local+5;
	local[0]=w;
	goto irtcolliBLK613;
	goto irtcolliIF622;
irtcolliIF621:
	local[5]= NIL;
irtcolliIF622:
	goto irtcolliWHL618;
irtcolliWHX619:
	local[5]= NIL;
irtcolliBLK620:
	w = NIL;
	goto irtcolliWHL615;
irtcolliWHX616:
	local[3]= NIL;
irtcolliBLK617:
	w = NIL;
	w = NIL;
	local[0]= w;
irtcolliBLK613:
	ctx->vsp=local; return(local[0]);}

/*select-collision-algorithm*/
static pointer irtcolliF589select_collision_algorithm(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	storeglobal(fqv[0],local[0]);
	w = local[0];
	local[0]= w;
irtcolliBLK623:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtcollision(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[13];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtcolliIF624;
	local[0]= fqv[14];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[15],w);
	goto irtcolliIF625;
irtcolliIF624:
	local[0]= fqv[16];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtcolliIF625:
	local[0]= fqv[17];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[18]); /*require*/
	local[0]= fqv[19];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[18]); /*require*/
	local[0]= fqv[1];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto irtcolliIF626;
	local[0]= fqv[4];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto irtcolliIF626;
	local[0]= fqv[0];
	local[1]= fqv[20];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto irtcolliIF628;
	local[0]= fqv[0];
	local[1]= fqv[20];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[0];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto irtcolliIF630;
	local[0]= fqv[0];
	local[1]= fqv[21];
	local[2]= loadglobal(fqv[1]);
	if (local[2]!=NIL) goto irtcolliOR632;
	local[2]= loadglobal(fqv[4]);
irtcolliOR632:
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto irtcolliIF631;
irtcolliIF630:
	local[0]= NIL;
irtcolliIF631:
	local[0]= fqv[0];
	goto irtcolliIF629;
irtcolliIF628:
	local[0]= NIL;
irtcolliIF629:
	goto irtcolliIF627;
irtcolliIF626:
	local[0]= NIL;
irtcolliIF627:
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtcolliM590cascaded_coords_make_collisionmodel,fqv[22],fqv[23],fqv[24]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[25],module,irtcolliF586collision_distance,fqv[26]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[27],module,irtcolliF587collision_check,fqv[28]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[29],module,irtcolliF588collision_check_objects,fqv[30]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[31],module,irtcolliF589select_collision_algorithm,fqv[32]);
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtcolliIF633;
	local[0]= fqv[34];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[15],w);
	goto irtcolliIF634;
irtcolliIF633:
	local[0]= fqv[35];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtcolliIF634:
	local[0]= fqv[36];
	local[1]= fqv[37];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[38]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<2; i++) ftab[i]=fcallx;
}
