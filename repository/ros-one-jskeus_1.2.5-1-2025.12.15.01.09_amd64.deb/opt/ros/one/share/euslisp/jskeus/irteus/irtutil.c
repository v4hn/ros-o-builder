/* ./irtutil.c :  entry=irtutil */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Dec 15 01:02:36 UTC 2025) */
#include "eus.h"
#include "irtutil.h"
#pragma init (register_irtutil)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtutil();
extern pointer build_quote_vector();
static int register_irtutil()
  { add_module_initializer("___irtutil", ___irtutil);}

static pointer irtutilF415forward_message_to();
static pointer irtutilF416forward_message_to_all();
static pointer irtutilF417permutation();
static pointer irtutilF418combination();
static pointer irtutilF419mapjoin();
static pointer irtutilF420find_extreams();
static pointer irtutilF421need_thread();
static pointer irtutilF422eus_server();
static pointer irtutilF423connect_server_until_success();
static pointer irtutilF424format_array();
static pointer irtutilF425his2rgb();
static pointer irtutilF426hvs2rgb();
static pointer irtutilF427rgb2his();
static pointer irtutilF428rgb2hvs();
static pointer irtutilF429color_category10();
static pointer irtutilF430color_category20();
static pointer irtutilF431termios_c_iflag();
static pointer irtutilF432set_termios_c_iflag();
static pointer irtutilF433termios_c_oflag();
static pointer irtutilF434set_termios_c_oflag();
static pointer irtutilF435termios_c_cflag();
static pointer irtutilF436set_termios_c_cflag();
static pointer irtutilF437termios_c_lflag();
static pointer irtutilF438set_termios_c_lflag();
static pointer irtutilF439termios_c_line();
static pointer irtutilF440set_termios_c_line();
static pointer irtutilF441termios_c_cc();
static pointer irtutilF442set_termios_c_cc();
static pointer irtutilF443termios_c_ispeed();
static pointer irtutilF444set_termios_c_ispeed();
static pointer irtutilF445termios_c_ospeed();
static pointer irtutilF446set_termios_c_ospeed();
static pointer irtutilF447kbhit();
static pointer irtutilF448piped_fork_returns_list();
static pointer irtutilF449make_robot_model_from_name();

/*forward-message-to*/
static pointer irtutilF415forward_message_to(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]==NIL) goto irtutilIF451;
	if (argv[1]==NIL) goto irtutilIF453;
	local[0]= (pointer)get_sym_func(fqv[0]);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
	goto irtutilIF454;
irtutilIF453:
	local[0]= argv[0];
irtutilIF454:
	goto irtutilIF452;
irtutilIF451:
	if (loadglobal(fqv[1])==NIL) goto irtutilIF455;
	local[0]= fqv[2];
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,3,local+0,&ftab[0],fqv[3]); /*warn*/
	local[0]= w;
	goto irtutilIF456;
irtutilIF455:
	local[0]= NIL;
irtutilIF456:
irtutilIF452:
	w = local[0];
	local[0]= w;
irtutilBLK450:
	ctx->vsp=local; return(local[0]);}

/*forward-message-to-all*/
static pointer irtutilF416forward_message_to_all(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]==NIL) goto irtutilIF458;
	if (argv[1]==NIL) goto irtutilIF460;
	local[0]= (pointer)get_sym_func(fqv[4]);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
	goto irtutilIF461;
irtutilIF460:
	local[0]= argv[0];
irtutilIF461:
	goto irtutilIF459;
irtutilIF458:
	if (loadglobal(fqv[1])==NIL) goto irtutilIF462;
	local[0]= fqv[5];
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,3,local+0,&ftab[0],fqv[3]); /*warn*/
	local[0]= w;
	goto irtutilIF463;
irtutilIF462:
	local[0]= NIL;
irtutilIF463:
irtutilIF459:
	w = local[0];
	local[0]= w;
irtutilBLK457:
	ctx->vsp=local; return(local[0]);}

/*send-message**/
static pointer irtutilF464(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtutilRST466:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[6];
	local[2]= fqv[7];
	local[3]= fqv[8];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	w = local[0];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtutilBLK465:
	ctx->vsp=local; return(local[0]);}

/*do-until-key-with-check*/
static pointer irtutilF467(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtutilRST469:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[9];
	local[2]= fqv[10];
	local[3]= fqv[11];
	local[4]= fqv[12];
	local[5]= fqv[13];
	local[6]= fqv[14];
	local[7]= fqv[15];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[16];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[17];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= local[0];
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	local[3]= fqv[18];
	local[4]= fqv[19];
	local[5]= fqv[20];
	local[6]= fqv[13];
	local[7]= fqv[14];
	local[8]= fqv[15];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[21];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	local[5]= fqv[22];
	local[6]= fqv[19];
	local[7]= fqv[23];
	local[8]= fqv[19];
	local[9]= fqv[24];
	local[10]= fqv[24];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtutilBLK468:
	ctx->vsp=local; return(local[0]);}

/*do-until-key*/
static pointer irtutilF470(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtutilRST472:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[25];
	local[2]= fqv[26];
	local[3]= local[0];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtutilBLK471:
	ctx->vsp=local; return(local[0]);}

/*do-until-key-with-timer*/
static pointer irtutilF473(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtutilRST475:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[18];
	local[3]= local[1];
	local[4]= fqv[27];
	local[5]= fqv[28];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[25];
	local[5]= fqv[30];
	local[6]= fqv[0];
	local[7]= local[1];
	local[8]= fqv[31];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= local[0];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
irtutilBLK474:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtutilM476mtimer_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[32];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	w = argv[0];
	local[0]= w;
irtutilBLK477:
	ctx->vsp=local; return(local[0]);}

/*:start*/
static pointer irtutilM478mtimer_start(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(pointer)GETTIMEOFDAY(ctx,0,local+0); /*unix:gettimeofday*/
	argv[0]->c.obj.iv[0] = w;
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
irtutilBLK479:
	ctx->vsp=local; return(local[0]);}

/*:stop*/
static pointer irtutilM480mtimer_stop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	ctx->vsp=local+1;
	w=(pointer)GETTIMEOFDAY(ctx,0,local+1); /*unix:gettimeofday*/
	local[0] = w;
	local[1]= loadglobal(fqv[33]);
	local[2]= (pointer)get_sym_func(fqv[34]);
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+5;
	w=(pointer)MAP(ctx,4,local+1); /*map*/
	local[0] = w;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= makeflt(1.0000000000000000000000e+06);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[0]= w;
irtutilBLK481:
	ctx->vsp=local; return(local[0]);}

/*permutation*/
static pointer irtutilF417permutation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto irtutilIF483;
	local[0]= fqv[35];
	goto irtutilIF484;
irtutilIF483:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtutilCLO485,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
irtutilIF484:
	w = local[0];
	local[0]= w;
irtutilBLK482:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO485(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtutilCLO486,env,argv,local);
	local[1]= argv[0];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[36];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,4,local+1,&ftab[1],fqv[37]); /*remove*/
	local[1]= w;
	local[2]= env->c.clo.env1[1];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtutilF417permutation(ctx,2,local+1); /*permutation*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO486(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	w = argv[0];
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*combination*/
static pointer irtutilF418combination(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto irtutilIF488;
	local[0]= fqv[38];
	goto irtutilIF489;
irtutilIF488:
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtutilCLO490,env,argv,local);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
irtutilIF489:
	w = local[0];
	local[0]= w;
irtutilBLK487:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO490(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtutilCLO491,env,argv,local);
	local[1]= argv[0];
	local[2]= env->c.clo.env1[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[39]); /*member*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	local[2]= env->c.clo.env1[1];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)irtutilF418combination(ctx,2,local+1); /*combination*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO491(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	w = argv[0];
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*mapjoin*/
static pointer irtutilF419mapjoin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtutilCLO493,env,argv,local);
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAN(ctx,2,local+0); /*mapcan*/
	local[0]= w;
irtutilBLK492:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO493(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtutilCLO494,env,argv,local);
	local[1]= env->c.clo.env1[2];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO494(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env0->c.clo.env1[0];
	local[1]= env->c.clo.env1[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)FUNCALL(ctx,3,local+0); /*funcall*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*find-extreams*/
static pointer irtutilF420find_extreams(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[40], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto irtutilKEY496;
	local[0] = (pointer)get_sym_func(fqv[41]);
irtutilKEY496:
	if (n & (1<<1)) goto irtutilKEY497;
	local[1] = (pointer)get_sym_func(fqv[42]);
irtutilKEY497:
	if (n & (1<<2)) goto irtutilKEY498;
	local[2] = (pointer)get_sym_func(fqv[43]);
irtutilKEY498:
	local[3]= local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,2,local+3); /*funcall*/
	local[3]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= local[4];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= NIL;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.cdr;
irtutilWHL499:
	if (local[7]==NIL) goto irtutilWHX500;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[0];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)FUNCALL(ctx,2,local+8); /*funcall*/
	local[8]= w;
	local[9]= local[2];
	local[10]= local[8];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)FUNCALL(ctx,3,local+9); /*funcall*/
	if (w==NIL) goto irtutilCON503;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	local[5] = w;
	local[3] = local[8];
	local[4] = local[6];
	local[9]= local[4];
	goto irtutilCON502;
irtutilCON503:
	local[9]= local[1];
	local[10]= local[8];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)FUNCALL(ctx,3,local+9); /*funcall*/
	if (w==NIL) goto irtutilCON504;
	local[9]= local[6];
	w = local[5];
	ctx->vsp=local+10;
	local[5] = cons(ctx,local[9],w);
	local[9]= local[5];
	goto irtutilCON502;
irtutilCON504:
	local[9]= NIL;
irtutilCON502:
	w = local[9];
	goto irtutilWHL499;
irtutilWHX500:
	local[8]= NIL;
irtutilBLK501:
	w = NIL;
	w = local[5];
	local[0]= w;
irtutilBLK495:
	ctx->vsp=local; return(local[0]);}

/*need-thread*/
static pointer irtutilF421need_thread(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT508;}
	local[0]= makeint((eusinteger_t)512L);
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)1024L)); i=intval(local[0]);
		local[0]=(makeint(i * j));}
irtutilENT508:
	if (n>=3) { local[1]=(argv[2]); goto irtutilENT507;}
	local[1]= local[0];
irtutilENT507:
irtutilENT506:
	if (n>3) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)FREE_THREADS(ctx,0,local+5); /*system::free-threads*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[2] = w;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto irtutilIF509;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
irtutilWHL511:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtutilWHX512;
	local[6]= makeint((eusinteger_t)1L);
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)MAKE_THREAD(ctx,3,local+6); /*system:make-thread*/
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtutilCLO514,env,argv,local);
	ctx->vsp=local+7;
	w=(pointer)AFUNCALL(ctx,1,local+6); /*thread*/
	local[6]= w;
	w = local[3];
	ctx->vsp=local+7;
	local[3] = cons(ctx,local[6],w);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtutilWHL511;
irtutilWHX512:
	local[6]= NIL;
irtutilBLK513:
	w = NIL;
	local[4]= NIL;
	local[5]= local[3];
irtutilWHL515:
	if (local[5]==NIL) goto irtutilWHX516;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5] = (w)->c.cons.cdr;
	w = local[6];
	local[4] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)WAIT_AFUNCALL(ctx,1,local+6); /*system:wait-thread*/
	goto irtutilWHL515;
irtutilWHX516:
	local[6]= NIL;
irtutilBLK517:
	w = NIL;
	local[4]= w;
	goto irtutilIF510;
irtutilIF509:
	local[4]= NIL;
irtutilIF510:
	w = local[4];
	local[0]= w;
irtutilBLK505:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO514(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	w = NIL;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*eus-server*/
static pointer irtutilF422eus_server(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto irtutilENT520;}
	local[0]= makeint((eusinteger_t)6666L);
irtutilENT520:
irtutilENT519:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[44], &argv[1], n-1, local+1, 0);
	if (n & (1<<0)) goto irtutilKEY521;
	ctx->vsp=local+2;
	w=(pointer)GETHOSTNAME(ctx,0,local+2); /*unix:gethostname*/
	local[1] = w;
irtutilKEY521:
	local[2]= fqv[45];
	local[3]= local[1];
	local[4]= fqv[46];
	local[5]= makeint((eusinteger_t)2L);
	local[6]= fqv[47];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,6,local+2,&ftab[3],fqv[48]); /*make-socket-address*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,1,local+2,&ftab[4],fqv[49]); /*make-socket-port*/
	local[2]= w;
	local[3]= local[2];
	local[4]= loadglobal(fqv[50]);
	ctx->vsp=local+5;
	w=(pointer)DERIVEDP(ctx,2,local+3); /*derivedp*/
	if (w==NIL) goto irtutilCON523;
	local[3]= loadglobal(fqv[51]);
	local[4]= fqv[52];
	local[5]= local[2];
	local[6]= fqv[53];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	local[3]= w;
	goto irtutilCON522;
irtutilCON523:
	local[3]= NIL;
	local[4]= fqv[54];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,4,local+3); /*format*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto irtutilCON522;
irtutilCON524:
	local[3]= NIL;
irtutilCON522:
	w = local[3];
	local[0]= w;
irtutilBLK518:
	ctx->vsp=local; return(local[0]);}

/*connect-server-until-success*/
static pointer irtutilF423connect_server_until_success(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[55], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtutilKEY526;
	local[2]= argv[1];
	local[3]= makeint((eusinteger_t)20L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[0] = w;
irtutilKEY526:
	if (n & (1<<1)) goto irtutilKEY527;
	local[1] = NIL;
irtutilKEY527:
	local[2]= NIL;
	local[3]= argv[1];
irtutilWHL528:
	local[4]= argv[0];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[56]); /*connect-server*/
	local[2] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)STREAMP(ctx,1,local+4); /*streamp*/
	if (w!=NIL) goto irtutilWHX529;
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto irtutilWHX529;
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	argv[1] = w;
	goto irtutilWHL528;
irtutilWHX529:
	local[4]= NIL;
irtutilBLK530:
	local[4]= argv[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto irtutilCON532;
	local[4]= fqv[57];
	local[5]= makeint((eusinteger_t)27L);
	local[6]= argv[0];
	local[7]= argv[1];
	local[8]= makeint((eusinteger_t)27L);
	ctx->vsp=local+9;
	w=(*ftab[0])(ctx,5,local+4,&ftab[0],fqv[3]); /*warn*/
	if (local[1]==NIL) goto irtutilIF533;
	local[4]= local[2];
	local[5]= argv[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
	goto irtutilIF534;
irtutilIF533:
	local[4]= local[2];
irtutilIF534:
	goto irtutilCON531;
irtutilCON532:
	local[4]= fqv[58];
	local[5]= makeint((eusinteger_t)27L);
	local[6]= argv[0];
	local[7]= local[3];
	local[8]= local[0];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)27L);
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,6,local+4,&ftab[0],fqv[3]); /*warn*/
	local[4]= NIL;
	goto irtutilCON531;
irtutilCON535:
	local[4]= NIL;
irtutilCON531:
	w = local[4];
	local[0]= w;
irtutilBLK525:
	ctx->vsp=local; return(local[0]);}

/*format-array*/
static pointer irtutilF424format_array(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT542;}
	local[0]= fqv[59];
irtutilENT542:
	if (n>=3) { local[1]=(argv[2]); goto irtutilENT541;}
	local[1]= makeint((eusinteger_t)7L);
irtutilENT541:
	if (n>=4) { local[2]=(argv[3]); goto irtutilENT540;}
	local[2]= makeint((eusinteger_t)3L);
irtutilENT540:
	if (n>=5) { local[3]=(argv[4]); goto irtutilENT539;}
	local[3]= loadglobal(fqv[60]);
irtutilENT539:
	if (n>=6) { local[4]=(argv[5]); goto irtutilENT538;}
	local[4]= T;
irtutilENT538:
irtutilENT537:
	if (n>6) maerror();
	local[5]= argv[0];
	local[6]= fqv[61];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[5];
	if (fqv[62]!=local[6]) goto irtutilIF543;
	local[6]= NIL;
	local[7]= fqv[63];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	goto irtutilIF544;
irtutilIF543:
	local[6]= local[5];
	if (fqv[64]!=local[6]) goto irtutilIF545;
	local[6]= NIL;
	local[7]= fqv[65];
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,4,local+6); /*format*/
	local[6]= w;
	goto irtutilIF546;
irtutilIF545:
	local[6]= NIL;
irtutilIF546:
irtutilIF544:
	w = local[6];
	local[5]= w;
	local[6]= NIL;
	local[7]= fqv[66];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= NIL;
	local[8]= local[6];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,3,local+7); /*format*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= loadglobal(fqv[67]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtutilCON548;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
irtutilWHL549:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtutilWHX550;
	local[10]= NIL;
	local[11]= local[5];
	local[12]= argv[0];
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= w;
	w = local[7];
	ctx->vsp=local+11;
	local[7] = cons(ctx,local[10],w);
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtutilWHL549;
irtutilWHX550:
	local[10]= NIL;
irtutilBLK551:
	w = NIL;
	if (local[4]==NIL) goto irtutilIF552;
	local[8]= fqv[68];
	w = local[7];
	ctx->vsp=local+9;
	local[7] = cons(ctx,local[8],w);
	local[8]= local[7];
	goto irtutilIF553;
irtutilIF552:
	local[8]= NIL;
irtutilIF553:
	goto irtutilCON547;
irtutilCON548:
	local[8]= argv[0];
	local[9]= loadglobal(fqv[69]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtutilCON554;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,1,local+9,&ftab[6],fqv[70]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
irtutilWHL555:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtutilWHX556;
	local[10]= local[8];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(*ftab[7])(ctx,2,local+10,&ftab[7],fqv[71]); /*/=*/
	if (w==NIL) goto irtutilIF558;
	local[10]= NIL;
	local[11]= local[6];
	local[12]= fqv[72];
	ctx->vsp=local+13;
	w=(pointer)XFORMAT(ctx,3,local+10); /*format*/
	local[10]= w;
	w = local[7];
	ctx->vsp=local+11;
	local[7] = cons(ctx,local[10],w);
	local[10]= local[7];
	goto irtutilIF559;
irtutilIF558:
	local[10]= NIL;
irtutilIF559:
	local[10]= makeint((eusinteger_t)0L);
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(*ftab[6])(ctx,1,local+11,&ftab[6],fqv[70]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
irtutilWHL560:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtutilWHX561;
	local[12]= NIL;
	local[13]= local[5];
	local[14]= argv[0];
	local[15]= local[8];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,3,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)XFORMAT(ctx,3,local+12); /*format*/
	local[12]= w;
	w = local[7];
	ctx->vsp=local+13;
	local[7] = cons(ctx,local[12],w);
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtutilWHL560;
irtutilWHX561:
	local[12]= NIL;
irtutilBLK562:
	w = NIL;
	if (local[4]==NIL) goto irtutilIF563;
	local[10]= fqv[73];
	w = local[7];
	ctx->vsp=local+11;
	local[7] = cons(ctx,local[10],w);
	local[10]= local[7];
	goto irtutilIF564;
irtutilIF563:
	local[10]= NIL;
irtutilIF564:
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtutilWHL555;
irtutilWHX556:
	local[10]= NIL;
irtutilBLK557:
	w = NIL;
	local[8]= w;
	goto irtutilCON547;
irtutilCON554:
	local[8]= NIL;
irtutilCON547:
	local[8]= local[3];
	local[9]= (pointer)get_sym_func(fqv[74]);
	local[10]= loadglobal(fqv[75]);
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)NREVERSE(ctx,1,local+11); /*nreverse*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)APPLY(ctx,3,local+9); /*apply*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)XFORMAT(ctx,2,local+8); /*format*/
	local[8]= w;
	if (local[3]==NIL) goto irtutilIF565;
	local[9]= argv[0];
	goto irtutilIF566;
irtutilIF565:
	local[9]= local[8];
irtutilIF566:
	w = local[9];
	local[0]= w;
irtutilBLK536:
	ctx->vsp=local; return(local[0]);}

/*with-gensyms*/
static pointer irtutilF567(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtutilRST569:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[18];
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtutilCLO570,env,argv,local);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	local[3]= local[0];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtutilBLK568:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilCLO570(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[76];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	ctx->vsp=local+1;
	w = cons(ctx,local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtutilM571interpolator_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[4] = makeflt(0.0000000000000000000000e+00);
	argv[0]->c.obj.iv[6] = makeflt(0.0000000000000000000000e+00);
	argv[0]->c.obj.iv[7] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[5] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[8] = NIL;
	w = argv[0];
	local[0]= w;
irtutilBLK572:
	ctx->vsp=local; return(local[0]);}

/*:reset*/
static pointer irtutilM573interpolator_reset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtutilRST575:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[77], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtutilKEY576;
	local[3]= argv[0];
	local[4]= fqv[78];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[1] = w;
irtutilKEY576:
	if (n & (1<<1)) goto irtutilKEY577;
	local[3]= argv[0];
	local[4]= fqv[79];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
irtutilKEY577:
	argv[0]->c.obj.iv[1] = local[1];
	argv[0]->c.obj.iv[2] = local[2];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[7])(ctx,2,local+3,&ftab[7],fqv[71]); /*/=*/
	if (w==NIL) goto irtutilIF578;
	local[3]= makeint((eusinteger_t)1L);
	local[4]= fqv[80];
	ctx->vsp=local+5;
	w=(*ftab[8])(ctx,2,local+3,&ftab[8],fqv[81]); /*warning-message*/
	local[3]= w;
	goto irtutilIF579;
irtutilIF578:
	local[3]= NIL;
irtutilIF579:
	argv[0]->c.obj.iv[4] = makeflt(0.0000000000000000000000e+00);
	argv[0]->c.obj.iv[6] = makeflt(0.0000000000000000000000e+00);
	argv[0]->c.obj.iv[7] = makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	argv[0]->c.obj.iv[5] = w;
	argv[0]->c.obj.iv[8] = NIL;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtutilBLK574:
	ctx->vsp=local; return(local[0]);}

/*:position-list*/
static pointer irtutilM580interpolator_position_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
irtutilBLK581:
	ctx->vsp=local; return(local[0]);}

/*:position*/
static pointer irtutilM582interpolator_position(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtutilBLK583:
	ctx->vsp=local; return(local[0]);}

/*:time-list*/
static pointer irtutilM584interpolator_time_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtutilBLK585:
	ctx->vsp=local; return(local[0]);}

/*:time*/
static pointer irtutilM586interpolator_time(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtutilBLK587:
	ctx->vsp=local; return(local[0]);}

/*:segment-time*/
static pointer irtutilM588interpolator_segment_time(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
irtutilBLK589:
	ctx->vsp=local; return(local[0]);}

/*:segment*/
static pointer irtutilM590interpolator_segment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
irtutilBLK591:
	ctx->vsp=local; return(local[0]);}

/*:segment-num*/
static pointer irtutilM592interpolator_segment_num(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
irtutilBLK593:
	ctx->vsp=local; return(local[0]);}

/*:interpolatingp*/
static pointer irtutilM594interpolator_interpolatingp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtutilBLK595:
	ctx->vsp=local; return(local[0]);}

/*:start-interpolation*/
static pointer irtutilM596interpolator_start_interpolation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[8] = T;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtutilBLK597:
	ctx->vsp=local; return(local[0]);}

/*:stop-interpolation*/
static pointer irtutilM598interpolator_stop_interpolation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[8] = NIL;
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
irtutilBLK599:
	ctx->vsp=local; return(local[0]);}

/*:pass-time*/
static pointer irtutilM600interpolator_pass_time(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[8]==NIL) goto irtutilIF602;
	local[0]= argv[0];
	local[1]= fqv[82];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	argv[0]->c.obj.iv[4] = w;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[0]->c.obj.iv[7];
	if (makeint((eusinteger_t)0L)!=local[1]) goto irtutilIF604;
	local[1]= makeint((eusinteger_t)0L);
	goto irtutilIF605;
irtutilIF604:
	local[1]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
irtutilIF605:
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[6] = w;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
	local[2]= makeflt(9.9999999999999977795540e-02);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,3,local+0,&ftab[9],fqv[83]); /*eps>*/
	if (w==NIL) goto irtutilIF606;
irtutilWHL608:
	local[0]= argv[0]->c.obj.iv[7];
	w = argv[0]->c.obj.iv[5];
	if ((eusinteger_t)local[0] >= (eusinteger_t)w) goto irtutilWHX609;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
	local[2]= makeflt(9.9999999999999977795540e-02);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,3,local+0,&ftab[9],fqv[83]); /*eps>*/
	if (w==NIL) goto irtutilWHX609;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[6] = w;
	local[0]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[0]->c.obj.iv[7] = w;
	goto irtutilWHL608;
irtutilWHX609:
	local[0]= NIL;
irtutilBLK610:
	goto irtutilIF607;
irtutilIF606:
	local[0]= NIL;
irtutilIF607:
	local[0]= argv[0]->c.obj.iv[7];
	w = argv[0]->c.obj.iv[5];
	if ((eusinteger_t)local[0] < (eusinteger_t)w) goto irtutilIF611;
	local[0]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[0]->c.obj.iv[7] = w;
	local[0]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+1;
	w=(*ftab[10])(ctx,1,local+0,&ftab[10],fqv[84]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[4] = (w)->c.cons.car;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[0]->c.obj.iv[7];
	if (makeint((eusinteger_t)0L)!=local[1]) goto irtutilIF613;
	local[1]= makeint((eusinteger_t)0L);
	goto irtutilIF614;
irtutilIF613:
	local[1]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
irtutilIF614:
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	argv[0]->c.obj.iv[6] = w;
	local[0]= argv[0];
	local[1]= fqv[82];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[3] = w;
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtutilIF612;
irtutilIF611:
	local[0]= NIL;
irtutilIF612:
	local[0]= argv[0]->c.obj.iv[3];
	goto irtutilIF603;
irtutilIF602:
	local[0]= NIL;
irtutilIF603:
	w = local[0];
	local[0]= w;
irtutilBLK601:
	ctx->vsp=local; return(local[0]);}

/*:interpolation*/
static pointer irtutilM615linear_interpolator_interpolation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[7];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[7];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)NTH(ctx,2,local+2); /*nth*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[7];
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[3] <= (eusinteger_t)w) goto irtutilIF617;
	local[3]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)NTH(ctx,2,local+3); /*nth*/
	local[3]= w;
	goto irtutilIF618;
irtutilIF617:
	local[3]= makeint((eusinteger_t)0L);
irtutilIF618:
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= local[2];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= local[4];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[0] = w;
	local[5]= local[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[1] = w;
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)VPLUS(ctx,2,local+5); /*v+*/
	local[0]= w;
irtutilBLK616:
	ctx->vsp=local; return(local[0]);}

/*:velocity*/
static pointer irtutilM619minjerk_interpolator_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[9];
	local[0]= w;
irtutilBLK620:
	ctx->vsp=local; return(local[0]);}

/*:velocity-list*/
static pointer irtutilM621minjerk_interpolator_velocity_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtutilBLK622:
	ctx->vsp=local; return(local[0]);}

/*:acceleration*/
static pointer irtutilM623minjerk_interpolator_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtutilBLK624:
	ctx->vsp=local; return(local[0]);}

/*:acceleration-list*/
static pointer irtutilM625minjerk_interpolator_acceleration_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
irtutilBLK626:
	ctx->vsp=local; return(local[0]);}

/*:reset*/
static pointer irtutilM627minjerk_interpolator_reset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtutilRST629:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[86], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtutilKEY630;
	local[3]= argv[0];
	local[4]= fqv[87];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[1] = w;
irtutilKEY630:
	if (n & (1<<1)) goto irtutilKEY631;
	local[3]= argv[0];
	local[4]= fqv[88];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
irtutilKEY631:
	local[3]= (pointer)get_sym_func(fqv[8]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[89]));
	local[6]= fqv[85];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,5,local+3); /*apply*/
	if (local[1]==NIL) goto irtutilIF632;
	local[3]= local[1];
	goto irtutilIF633;
irtutilIF632:
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= fqv[90];
	local[5]= loadglobal(fqv[91]);
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,3,local+3,&ftab[11],fqv[92]); /*make-list*/
	local[3]= w;
irtutilIF633:
	argv[0]->c.obj.iv[11] = local[3];
	if (local[2]==NIL) goto irtutilIF634;
	local[3]= local[2];
	goto irtutilIF635;
irtutilIF634:
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= fqv[90];
	local[5]= loadglobal(fqv[91]);
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[11])(ctx,3,local+3,&ftab[11],fqv[92]); /*make-list*/
	local[3]= w;
irtutilIF635:
	argv[0]->c.obj.iv[12] = local[3];
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
irtutilBLK628:
	ctx->vsp=local; return(local[0]);}

/*:interpolation*/
static pointer irtutilM636minjerk_interpolator_interpolation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[7];
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)NTH(ctx,2,local+0); /*nth*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)NTH(ctx,2,local+1); /*nth*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[7];
	local[3]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+4;
	w=(pointer)NTH(ctx,2,local+2); /*nth*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+5;
	w=(pointer)NTH(ctx,2,local+3); /*nth*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[7];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)NTH(ctx,2,local+4); /*nth*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+7;
	w=(pointer)NTH(ctx,2,local+5); /*nth*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[7];
	local[7]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+8;
	w=(pointer)NTH(ctx,2,local+6); /*nth*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[7];
	w = makeint((eusinteger_t)0L);
	if ((eusinteger_t)local[7] <= (eusinteger_t)w) goto irtutilIF638;
	local[7]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+8;
	w=(pointer)SUB1(ctx,1,local+7); /*1-*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+9;
	w=(pointer)NTH(ctx,2,local+7); /*nth*/
	local[7]= w;
	goto irtutilIF639;
irtutilIF638:
	local[7]= makeint((eusinteger_t)0L);
irtutilIF639:
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[6];
	local[9]= local[6];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,3,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	local[8]= local[1];
	local[9]= (pointer)get_sym_func(fqv[93]);
	local[10]= local[0];
	local[11]= local[6];
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
	local[12]= local[6];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= makeflt(5.0000000000000000000000e-01);
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,2,local+12); /*scale*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,3,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[12])(ctx,2,local+9,&ftab[12],fqv[94]); /*reduce*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)VMINUS(ctx,2,local+8); /*v-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	local[8]= makeflt(1.0000000000000000000000e+00);
	local[9]= local[6];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= local[3];
	local[10]= local[2];
	local[11]= local[6];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VPLUS(ctx,2,local+10); /*v+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= makeflt(1.0000000000000000000000e+00);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,1,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[5];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[9]= w;
	local[10]= local[0];
	local[11]= local[2];
	local[12]= makeflt(5.0000000000000000000000e-01);
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,2,local+12); /*scale*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)10L);
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)SCALEVEC(ctx,2,local+13); /*scale*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)4L);
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)VMINUS(ctx,2,local+13); /*v-*/
	local[13]= w;
	local[14]= makeflt(5.0000000000000000000000e-01);
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,2,local+13); /*v+*/
	local[13]= w;
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)-15L);
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,2,local+15); /*scale*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)7L);
	local[17]= local[8];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,2,local+15); /*v+*/
	local[15]= w;
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,2,local+15); /*v-*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[6];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,3,local+15); /*/*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)6L);
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SCALEVEC(ctx,2,local+16); /*scale*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)-3L);
	local[18]= local[8];
	ctx->vsp=local+19;
	w=(pointer)SCALEVEC(ctx,2,local+17); /*scale*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,2,local+16); /*v+*/
	local[16]= w;
	local[17]= makeflt(5.0000000000000000000000e-01);
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(pointer)SCALEVEC(ctx,2,local+17); /*scale*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,2,local+16); /*v+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,2,local+15); /*scale*/
	local[15]= w;
	local[16]= (pointer)get_sym_func(fqv[93]);
	local[17]= local[10];
	local[18]= argv[0]->c.obj.iv[6];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(*ftab[13])(ctx,2,local+18,&ftab[13],fqv[95]); /*expt*/
	local[18]= w;
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= argv[0]->c.obj.iv[6];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(*ftab[13])(ctx,2,local+19,&ftab[13],fqv[95]); /*expt*/
	local[19]= w;
	local[20]= local[12];
	ctx->vsp=local+21;
	w=(pointer)SCALEVEC(ctx,2,local+19); /*scale*/
	local[19]= w;
	local[20]= argv[0]->c.obj.iv[6];
	local[21]= makeint((eusinteger_t)3L);
	ctx->vsp=local+22;
	w=(*ftab[13])(ctx,2,local+20,&ftab[13],fqv[95]); /*expt*/
	local[20]= w;
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	local[21]= argv[0]->c.obj.iv[6];
	local[22]= makeint((eusinteger_t)4L);
	ctx->vsp=local+23;
	w=(*ftab[13])(ctx,2,local+21,&ftab[13],fqv[95]); /*expt*/
	local[21]= w;
	local[22]= local[14];
	ctx->vsp=local+23;
	w=(pointer)SCALEVEC(ctx,2,local+21); /*scale*/
	local[21]= w;
	local[22]= argv[0]->c.obj.iv[6];
	local[23]= makeint((eusinteger_t)5L);
	ctx->vsp=local+24;
	w=(*ftab[13])(ctx,2,local+22,&ftab[13],fqv[95]); /*expt*/
	local[22]= w;
	local[23]= local[15];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,6,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[12])(ctx,2,local+16,&ftab[12],fqv[94]); /*reduce*/
	argv[0]->c.obj.iv[3] = w;
	local[16]= (pointer)get_sym_func(fqv[93]);
	local[17]= local[11];
	local[18]= makeint((eusinteger_t)2L);
	local[19]= argv[0]->c.obj.iv[6];
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(*ftab[13])(ctx,2,local+19,&ftab[13],fqv[95]); /*expt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	local[19]= local[12];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)3L);
	local[20]= argv[0]->c.obj.iv[6];
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(*ftab[13])(ctx,2,local+20,&ftab[13],fqv[95]); /*expt*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= local[13];
	ctx->vsp=local+21;
	w=(pointer)SCALEVEC(ctx,2,local+19); /*scale*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)4L);
	local[21]= argv[0]->c.obj.iv[6];
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(*ftab[13])(ctx,2,local+21,&ftab[13],fqv[95]); /*expt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= local[14];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)5L);
	local[22]= argv[0]->c.obj.iv[6];
	local[23]= makeint((eusinteger_t)4L);
	ctx->vsp=local+24;
	w=(*ftab[13])(ctx,2,local+22,&ftab[13],fqv[95]); /*expt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	local[22]= local[15];
	ctx->vsp=local+23;
	w=(pointer)SCALEVEC(ctx,2,local+21); /*scale*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,5,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[12])(ctx,2,local+16,&ftab[12],fqv[94]); /*reduce*/
	argv[0]->c.obj.iv[9] = w;
	local[16]= (pointer)get_sym_func(fqv[93]);
	local[17]= makeint((eusinteger_t)2L);
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)SCALEVEC(ctx,2,local+17); /*scale*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)6L);
	local[19]= argv[0]->c.obj.iv[6];
	local[20]= makeint((eusinteger_t)1L);
	ctx->vsp=local+21;
	w=(*ftab[13])(ctx,2,local+19,&ftab[13],fqv[95]); /*expt*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)12L);
	local[20]= argv[0]->c.obj.iv[6];
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(*ftab[13])(ctx,2,local+20,&ftab[13],fqv[95]); /*expt*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,2,local+19); /***/
	local[19]= w;
	local[20]= local[14];
	ctx->vsp=local+21;
	w=(pointer)SCALEVEC(ctx,2,local+19); /*scale*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)20L);
	local[21]= argv[0]->c.obj.iv[6];
	local[22]= makeint((eusinteger_t)3L);
	ctx->vsp=local+23;
	w=(*ftab[13])(ctx,2,local+21,&ftab[13],fqv[95]); /*expt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	local[21]= local[15];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,4,local+17); /*list*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[12])(ctx,2,local+16,&ftab[12],fqv[94]); /*reduce*/
	argv[0]->c.obj.iv[10] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
irtutilBLK637:
	ctx->vsp=local; return(local[0]);}

/*his2rgb*/
static pointer irtutilF425his2rgb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT644;}
	local[0]= makeflt(1.0000000000000000000000e+00);
irtutilENT644:
	if (n>=3) { local[1]=(argv[2]); goto irtutilENT643;}
	local[1]= makeflt(1.0000000000000000000000e+00);
irtutilENT643:
	if (n>=4) { local[2]=(argv[3]); goto irtutilENT642;}
	local[2]= NIL;
irtutilENT642:
irtutilENT641:
	if (n>4) maerror();
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtutilF426hvs2rgb(ctx,4,local+3); /*hvs2rgb*/
	local[0]= w;
irtutilBLK640:
	ctx->vsp=local; return(local[0]);}

/*hvs2rgb*/
static pointer irtutilF426hvs2rgb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT649;}
	local[0]= makeflt(1.0000000000000000000000e+00);
irtutilENT649:
	if (n>=3) { local[1]=(argv[2]); goto irtutilENT648;}
	local[1]= makeflt(1.0000000000000000000000e+00);
irtutilENT648:
	if (n>=4) { local[2]=(argv[3]); goto irtutilENT647;}
	local[2]= NIL;
irtutilENT647:
irtutilENT646:
	if (n>4) maerror();
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w!=NIL) goto irtutilOR652;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)VECTORP(ctx,1,local+3); /*vectorp*/
	if (w!=NIL) goto irtutilOR652;
	goto irtutilIF650;
irtutilOR652:
	local[2] = local[0];
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[1] = w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[0] = w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	argv[0] = w;
	local[3]= argv[0];
	goto irtutilIF651;
irtutilIF650:
	local[3]= NIL;
irtutilIF651:
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)360L);
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto irtutilIF653;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)360L);
	ctx->vsp=local+5;
	w=(pointer)MOD(ctx,2,local+3); /*mod*/
	argv[0] = w;
	local[3]= argv[0];
	goto irtutilIF654;
irtutilIF653:
	local[3]= NIL;
irtutilIF654:
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto irtutilIF655;
	local[3]= makeint((eusinteger_t)360L);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,1,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROUND(ctx,1,local+4); /*round*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)360L);
	ctx->vsp=local+6;
	w=(pointer)MOD(ctx,2,local+4); /*mod*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	argv[0] = w;
	local[3]= argv[0];
	goto irtutilIF656;
irtutilIF655:
	local[3]= NIL;
irtutilIF656:
	local[3]= makeint((eusinteger_t)255L);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[1] = w;
	local[3]= makeint((eusinteger_t)255L);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[0] = w;
	local[3]= argv[0];
	local[4]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)FLOOR(ctx,1,local+3); /*floor*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	local[5]= local[0];
	local[6]= makeflt(1.0000000000000000000000e+00);
	local[7]= local[1];
	local[8]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[0];
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= local[4];
	local[9]= local[1];
	local[10]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[0];
	local[8]= makeflt(1.0000000000000000000000e+00);
	local[9]= makeint((eusinteger_t)1L);
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= local[1];
	local[11]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= local[3];
	local[12]= local[11];
	w = fqv[96];
	if (memq(local[12],w)==NIL) goto irtutilIF657;
	local[8] = local[0];
	local[9] = local[7];
	local[10] = local[5];
	local[12]= local[10];
	goto irtutilIF658;
irtutilIF657:
	local[12]= local[11];
	if (fqv[97]!=local[12]) goto irtutilIF659;
	local[8] = local[6];
	local[9] = local[0];
	local[10] = local[5];
	local[12]= local[10];
	goto irtutilIF660;
irtutilIF659:
	local[12]= local[11];
	if (fqv[98]!=local[12]) goto irtutilIF661;
	local[8] = local[5];
	local[9] = local[0];
	local[10] = local[7];
	local[12]= local[10];
	goto irtutilIF662;
irtutilIF661:
	local[12]= local[11];
	if (fqv[99]!=local[12]) goto irtutilIF663;
	local[8] = local[5];
	local[9] = local[6];
	local[10] = local[0];
	local[12]= local[10];
	goto irtutilIF664;
irtutilIF663:
	local[12]= local[11];
	if (fqv[100]!=local[12]) goto irtutilIF665;
	local[8] = local[7];
	local[9] = local[5];
	local[10] = local[0];
	local[12]= local[10];
	goto irtutilIF666;
irtutilIF665:
	local[12]= local[11];
	if (fqv[101]!=local[12]) goto irtutilIF667;
	local[8] = local[0];
	local[9] = local[5];
	local[10] = local[6];
	local[12]= local[10];
	goto irtutilIF668;
irtutilIF667:
	if (T==NIL) goto irtutilIF669;
	local[12]= fqv[102];
	ctx->vsp=local+13;
	w=(*ftab[0])(ctx,1,local+12,&ftab[0],fqv[3]); /*warn*/
	local[12]= w;
	goto irtutilIF670;
irtutilIF669:
	local[12]= NIL;
irtutilIF670:
irtutilIF668:
irtutilIF666:
irtutilIF664:
irtutilIF662:
irtutilIF660:
irtutilIF658:
	w = local[12];
	if (local[2]==NIL) goto irtutilCON672;
	local[11]= local[2];
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[8];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[2];
	local[12]= makeint((eusinteger_t)1L);
	local[13]= local[9];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[2];
	local[12]= makeint((eusinteger_t)2L);
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)SETELT(ctx,3,local+11); /*setelt*/
	local[11]= local[2];
	goto irtutilCON671;
irtutilCON672:
	local[11]= local[8];
	local[12]= local[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	goto irtutilCON671;
irtutilCON673:
	local[11]= NIL;
irtutilCON671:
	w = local[11];
	local[0]= w;
irtutilBLK645:
	ctx->vsp=local; return(local[0]);}

/*rgb2his*/
static pointer irtutilF427rgb2his(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT678;}
	local[0]= NIL;
irtutilENT678:
	if (n>=3) { local[1]=(argv[2]); goto irtutilENT677;}
	local[1]= NIL;
irtutilENT677:
	if (n>=4) { local[2]=(argv[3]); goto irtutilENT676;}
	local[2]= NIL;
irtutilENT676:
irtutilENT675:
	if (n>4) maerror();
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)irtutilF428rgb2hvs(ctx,4,local+3); /*rgb2hvs*/
	local[0]= w;
irtutilBLK674:
	ctx->vsp=local; return(local[0]);}

/*rgb2hvs*/
static pointer irtutilF428rgb2hvs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT683;}
	local[0]= NIL;
irtutilENT683:
	if (n>=3) { local[1]=(argv[2]); goto irtutilENT682;}
	local[1]= NIL;
irtutilENT682:
	if (n>=4) { local[2]=(argv[3]); goto irtutilENT681;}
	local[2]= NIL;
irtutilENT681:
irtutilENT680:
	if (n>4) maerror();
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LISTP(ctx,1,local+3); /*listp*/
	if (w!=NIL) goto irtutilOR686;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)VECTORP(ctx,1,local+3); /*vectorp*/
	if (w!=NIL) goto irtutilOR686;
	goto irtutilIF684;
irtutilOR686:
	local[2] = local[0];
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[0] = w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[1] = w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	argv[0] = w;
	local[3]= argv[0];
	goto irtutilIF685;
irtutilIF684:
	local[3]= NIL;
irtutilIF685:
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MAX(ctx,3,local+3); /*max*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= local[0];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,3,local+4); /*min*/
	local[4]= w;
	local[5]= local[3];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)EUSFLOAT(ctx,1,local+5); /*float*/
	local[5]= w;
	local[6]= local[3];
	local[7]= argv[0];
	local[8]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)QUOTIENT(ctx,2,local+7); /*/*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	local[7]= local[3];
	local[8]= local[0];
	local[9]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	local[8]= local[3];
	local[9]= local[1];
	local[10]= makeflt(6.0000000000000000000000e+01);
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= local[3];
	local[10]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[5];
	local[11]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)NUMEQUAL(ctx,2,local+10); /*=*/
	if (w==NIL) goto irtutilIF687;
	local[10]= makeint((eusinteger_t)0L);
	goto irtutilIF688;
irtutilIF687:
	local[10]= makeflt(2.5500000000000000000000e+02);
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
irtutilIF688:
	local[11]= local[10];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtutilIF689;
	local[11]= makeint((eusinteger_t)0L);
	goto irtutilIF690;
irtutilIF689:
	local[11]= argv[0];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtutilCON692;
	local[11]= local[8];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtutilCON691;
irtutilCON692:
	local[11]= local[0];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)NUMEQUAL(ctx,2,local+11); /*=*/
	if (w==NIL) goto irtutilCON693;
	local[11]= makeint((eusinteger_t)120L);
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtutilCON691;
irtutilCON693:
	local[11]= makeint((eusinteger_t)240L);
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[11]= w;
	goto irtutilCON691;
irtutilCON694:
	local[11]= NIL;
irtutilCON691:
irtutilIF690:
	local[12]= local[11];
	local[13]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(pointer)LESSP(ctx,2,local+12); /*<*/
	if (w==NIL) goto irtutilIF695;
	local[12]= local[11];
	local[13]= makeint((eusinteger_t)360L);
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	goto irtutilIF696;
irtutilIF695:
	local[12]= local[11];
irtutilIF696:
	local[13]= local[10];
	local[14]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[10] = w;
	if (local[2]==NIL) goto irtutilCON698;
	local[13]= local[2];
	local[14]= makeint((eusinteger_t)0L);
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(pointer)SETELT(ctx,3,local+13); /*setelt*/
	local[13]= local[2];
	local[14]= makeint((eusinteger_t)1L);
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)SETELT(ctx,3,local+13); /*setelt*/
	local[13]= local[2];
	local[14]= makeint((eusinteger_t)2L);
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)SETELT(ctx,3,local+13); /*setelt*/
	local[13]= local[2];
	goto irtutilCON697;
irtutilCON698:
	local[13]= local[12];
	local[14]= local[9];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,3,local+13); /*list*/
	local[13]= w;
	goto irtutilCON697;
irtutilCON699:
	local[13]= NIL;
irtutilCON697:
	w = local[13];
	local[0]= w;
irtutilBLK679:
	ctx->vsp=local; return(local[0]);}

/*color-category10*/
static pointer irtutilF429color_category10(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)10L);
	ctx->vsp=local+2;
	w=(pointer)MOD(ctx,2,local+0); /*mod*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)100L);
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+3;
	w=(pointer)irtutilF425his2rgb(ctx,3,local+0); /*his2rgb*/
	local[0]= w;
irtutilBLK700:
	ctx->vsp=local; return(local[0]);}

/*color-category20*/
static pointer irtutilF430color_category20(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)20L);
	ctx->vsp=local+2;
	w=(pointer)MOD(ctx,2,local+0); /*mod*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)100L);
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+3;
	w=(pointer)irtutilF425his2rgb(ctx,3,local+0); /*his2rgb*/
	local[0]= w;
irtutilBLK701:
	ctx->vsp=local; return(local[0]);}

/*bench*/
static pointer irtutilF702(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtutilRST704:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	local[3]= fqv[18];
	local[4]= local[1];
	local[5]= fqv[27];
	local[6]= fqv[28];
	local[7]= fqv[29];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= local[2];
	local[6]= fqv[103];
	w = local[0];
	if (memq(local[6],w)==NIL) goto irtutilIF705;
	local[6]= fqv[103];
	w = local[0];
	w=memq(local[6],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	goto irtutilIF706;
irtutilIF705:
	local[6]= fqv[104];
irtutilIF706:
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[0];
	local[6]= local[1];
	local[7]= fqv[32];
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[9];
	local[7]= fqv[105];
	local[8]= local[0];
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[106];
	local[9]= fqv[26];
	local[10]= fqv[107];
	local[11]= local[2];
	local[12]= fqv[0];
	local[13]= local[1];
	local[14]= fqv[31];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
irtutilBLK703:
	ctx->vsp=local; return(local[0]);}

/*bench2*/
static pointer irtutilF707(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtutilRST709:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	local[2]= fqv[18];
	local[3]= local[1];
	local[4]= fqv[27];
	local[5]= fqv[28];
	local[6]= fqv[29];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[3]= w;
	local[4]= fqv[0];
	local[5]= local[1];
	local[6]= fqv[32];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[105];
	local[6]= local[0];
	local[7]= fqv[0];
	local[8]= local[1];
	local[9]= fqv[31];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	local[0]= w;
irtutilBLK708:
	ctx->vsp=local; return(local[0]);}

/*null-output*/
static pointer irtutilF710(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
irtutilRST712:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= fqv[108];
	local[2]= fqv[109];
	local[3]= local[0];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
irtutilBLK711:
	ctx->vsp=local; return(local[0]);}

/*with-all-output->file*/
static pointer irtutilF713(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtutilRST715:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GENSYM(ctx,0,local+4); /*gensym*/
	local[4]= w;
	local[5]= fqv[105];
	local[6]= fqv[18];
	local[7]= local[1];
	local[8]= fqv[110];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[2];
	local[9]= fqv[60];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[4];
	local[10]= fqv[24];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[111];
	local[9]= fqv[112];
	local[10]= local[3];
	local[11]= argv[0];
	local[12]= fqv[113];
	local[13]= fqv[114];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[115];
	local[12]= fqv[110];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[115];
	local[13]= fqv[60];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= fqv[115];
	local[14]= local[4];
	local[15]= fqv[105];
	local[16]= local[0];
	local[17]= NIL;
	ctx->vsp=local+18;
	w=(pointer)APPEND(ctx,2,local+16); /*append*/
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[105];
	local[11]= fqv[115];
	local[12]= fqv[110];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= fqv[115];
	local[13]= fqv[60];
	local[14]= local[1];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	local[0]= w;
irtutilBLK714:
	ctx->vsp=local; return(local[0]);}

/*read-char-case*/
static pointer irtutilF716(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtutilRST718:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)GENSYM(ctx,0,local+2); /*gensym*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[3]= w;
	local[4]= fqv[105];
	local[5]= fqv[18];
	local[6]= local[3];
	local[7]= fqv[116];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	local[7]= fqv[10];
	local[8]= fqv[117];
	local[9]= local[3];
	local[10]= fqv[116];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[106];
	local[10]= fqv[26];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[118];
	local[11]= fqv[110];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	local[11]= fqv[115];
	local[12]= local[3];
	local[13]= fqv[18];
	local[14]= local[1];
	local[15]= fqv[119];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	local[14]= cons(ctx,local[14],w);
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	local[14]= w;
	local[15]= fqv[120];
	local[16]= local[1];
	local[17]= local[0];
	local[18]= fqv[26];
	local[19]= fqv[116];
	local[20]= local[2];
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,1,local+20); /*list*/
	ctx->vsp=local+20;
	local[19]= cons(ctx,local[19],w);
	ctx->vsp=local+20;
	w=(pointer)LIST(ctx,1,local+19); /*list*/
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,1,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)APPEND(ctx,2,local+17); /*append*/
	ctx->vsp=local+17;
	w = cons(ctx,local[16],w);
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	local[0]= w;
irtutilBLK717:
	ctx->vsp=local; return(local[0]);}

/*termios-c_iflag*/
static pointer irtutilF431termios_c_iflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK719:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_iflag*/
static pointer irtutilF432set_termios_c_iflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK720:
	ctx->vsp=local; return(local[0]);}

/*termios-c_oflag*/
static pointer irtutilF433termios_c_oflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK721:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_oflag*/
static pointer irtutilF434set_termios_c_oflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK722:
	ctx->vsp=local; return(local[0]);}

/*termios-c_cflag*/
static pointer irtutilF435termios_c_cflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK723:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_cflag*/
static pointer irtutilF436set_termios_c_cflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK724:
	ctx->vsp=local; return(local[0]);}

/*termios-c_lflag*/
static pointer irtutilF437termios_c_lflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)12L);
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK725:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_lflag*/
static pointer irtutilF438set_termios_c_lflag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)12L);
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK726:
	ctx->vsp=local; return(local[0]);}

/*termios-c_line*/
static pointer irtutilF439termios_c_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)16L);
	local[2]= fqv[121];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK727:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_line*/
static pointer irtutilF440set_termios_c_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)16L);
	local[3]= fqv[121];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK728:
	ctx->vsp=local; return(local[0]);}

/*termios-c_cc*/
static pointer irtutilF441termios_c_cc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT731;}
	local[0]= NIL;
irtutilENT731:
irtutilENT730:
	if (n>2) maerror();
	if (local[0]==NIL) goto irtutilIF732;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)17L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[122];
	ctx->vsp=local+4;
	w=(pointer)PEEK(ctx,3,local+1); /*system:peek*/
	local[1]= w;
	goto irtutilIF733;
irtutilIF732:
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)17L);
	local[3]= makeint((eusinteger_t)17L);
	w = makeint((eusinteger_t)19L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[3]= (pointer)((eusinteger_t)local[3] + (eusinteger_t)w);
	ctx->vsp=local+4;
	w=(pointer)SUBSEQ(ctx,3,local+1); /*subseq*/
	local[1]= w;
irtutilIF733:
	w = local[1];
	local[0]= w;
irtutilBLK729:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_cc*/
static pointer irtutilF442set_termios_c_cc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtutilRST735:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	if (local[0]==NIL) goto irtutilIF736;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= makeint((eusinteger_t)17L);
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[122];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,3,local+1); /*system:poke*/
	local[1]= w;
	goto irtutilIF737;
irtutilIF736:
	local[1]= argv[0];
	local[2]= argv[1];
	local[3]= fqv[123];
	local[4]= makeint((eusinteger_t)17L);
	local[5]= fqv[124];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,6,local+1,&ftab[14],fqv[125]); /*replace*/
	local[1]= w;
irtutilIF737:
	w = local[1];
	local[0]= w;
irtutilBLK734:
	ctx->vsp=local; return(local[0]);}

/*termios-c_ispeed*/
static pointer irtutilF443termios_c_ispeed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)36L);
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK738:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_ispeed*/
static pointer irtutilF444set_termios_c_ispeed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)36L);
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK739:
	ctx->vsp=local; return(local[0]);}

/*termios-c_ospeed*/
static pointer irtutilF445termios_c_ospeed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)40L);
	local[2]= fqv[62];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
irtutilBLK740:
	ctx->vsp=local; return(local[0]);}

/*set-termios-c_ospeed*/
static pointer irtutilF446set_termios_c_ospeed(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)40L);
	local[3]= fqv[62];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
irtutilBLK741:
	ctx->vsp=local; return(local[0]);}

/*kbhit*/
static pointer irtutilF447kbhit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(*ftab[15])(ctx,1,local+0,&ftab[15],fqv[126]); /*unix:tcgetattr*/
	local[0]= w;
	local[1]= fqv[127];
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[16])(ctx,1,local+4,&ftab[16],fqv[128]); /*copy-list*/
	local[2] = w;
	local[4]= local[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)irtutilF437termios_c_lflag(ctx,1,local+5); /*termios-c_lflag*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)LOGNOT(ctx,1,local+6); /*lognot*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LOGAND(ctx,2,local+5); /*logand*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)irtutilF438set_termios_c_lflag(ctx,2,local+4); /*set-termios-c_lflag*/
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[17])(ctx,3,local+4,&ftab[17],fqv[129]); /*unix:tcsetattr*/
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+6;
	w=(pointer)SELECT_READ(ctx,2,local+4); /*unix:select-read-fd*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto irtutilIF743;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)UNIXREAD(ctx,3,local+4); /*unix:uread*/
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[3] = w;
	local[4]= local[3];
	goto irtutilIF744;
irtutilIF743:
	local[4]= NIL;
irtutilIF744:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[17])(ctx,3,local+4,&ftab[17],fqv[129]); /*unix:tcsetattr*/
	w = local[3];
	local[0]= w;
irtutilBLK742:
	ctx->vsp=local; return(local[0]);}

/*piped-fork-returns-list*/
static pointer irtutilF448piped_fork_returns_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto irtutilENT747;}
	local[0]= NIL;
irtutilENT747:
irtutilENT746:
	if (n>2) maerror();
	local[1]= (pointer)get_sym_func(fqv[130]);
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,irtutilUWP748,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= NIL;
	local[5]= NIL;
irtutilWHL749:
	local[6]= local[1];
	local[7]= NIL;
	ctx->vsp=local+8;
	w=(pointer)READLINE(ctx,2,local+6); /*read-line*/
	local[5] = w;
	if (local[5]==NIL) goto irtutilWHX750;
	local[6]= local[5];
	w = local[4];
	ctx->vsp=local+7;
	local[4] = cons(ctx,local[6],w);
	goto irtutilWHL749;
irtutilWHX750:
	local[6]= NIL;
irtutilBLK751:
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)REVERSE(ctx,1,local+6); /*reverse*/
	ctx->vsp=local+4;
	irtutilUWP748(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
irtutilBLK745:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtutilUWP748(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-robot-model-from-name*/
static pointer irtutilF449make_robot_model_from_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
irtutilRST753:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,1,local+1,&ftab[18],fqv[131]); /*string-downcase*/
	local[1]= w;
	local[2]= loadglobal(fqv[132]);
	local[3]= fqv[133];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,1,local+2,&ftab[19],fqv[134]); /*flatten*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[2];
irtutilWHL754:
	if (local[4]==NIL) goto irtutilWHX755;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= fqv[135];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[18])(ctx,1,local+5,&ftab[18],fqv[131]); /*string-downcase*/
	local[5]= w;
	local[6]= local[5];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[20])(ctx,2,local+6,&ftab[20],fqv[136]); /*string=*/
	if (w!=NIL) goto irtutilOR759;
	local[6]= NIL;
	local[7]= fqv[137];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	local[6]= w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(*ftab[20])(ctx,2,local+6,&ftab[20],fqv[136]); /*string=*/
	if (w!=NIL) goto irtutilOR759;
	goto irtutilIF757;
irtutilOR759:
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= (pointer)get_sym_func(fqv[0]);
	local[8]= local[6];
	local[9]= fqv[29];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,4,local+7); /*apply*/
	w = local[6];
	ctx->vsp=local+6;
	local[0]=w;
	goto irtutilBLK752;
	goto irtutilIF758;
irtutilIF757:
	local[6]= NIL;
irtutilIF758:
	w = local[6];
	goto irtutilWHL754;
irtutilWHX755:
	local[5]= NIL;
irtutilBLK756:
	w = NIL;
	w = NIL;
	local[0]= w;
irtutilBLK752:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtutil(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[138];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtutilIF760;
	local[0]= fqv[139];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[140],w);
	goto irtutilIF761;
irtutilIF760:
	local[0]= fqv[141];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtutilIF761:
	local[0]= fqv[142];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[143],module,irtutilF415forward_message_to,fqv[144]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[145],module,irtutilF416forward_message_to_all,fqv[146]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[147],module,irtutilF464,fqv[148]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[25],module,irtutilF467,fqv[149]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[150],module,irtutilF470,fqv[151]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[152],module,irtutilF473,fqv[153]);
	local[0]= fqv[28];
	local[1]= fqv[154];
	local[2]= fqv[28];
	local[3]= fqv[155];
	local[4]= loadglobal(fqv[156]);
	local[5]= fqv[157];
	local[6]= fqv[158];
	local[7]= fqv[159];
	local[8]= NIL;
	local[9]= fqv[61];
	local[10]= NIL;
	local[11]= fqv[160];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[161];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[162]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM476mtimer_init,fqv[29],fqv[28],fqv[163]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM478mtimer_start,fqv[32],fqv[28],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM480mtimer_stop,fqv[31],fqv[28],fqv[165]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[166],module,irtutilF417permutation,fqv[167]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[168],module,irtutilF418combination,fqv[169]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[170],module,irtutilF419mapjoin,fqv[171]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[172],module,irtutilF420find_extreams,fqv[173]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[174],module,irtutilF421need_thread,fqv[175]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[176],module,irtutilF422eus_server,fqv[177]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[178],module,irtutilF423connect_server_until_success,fqv[179]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[180],module,irtutilF424format_array,fqv[181]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[182],module,irtutilF567,fqv[183]);
	local[0]= fqv[184];
	local[1]= fqv[154];
	local[2]= fqv[184];
	local[3]= fqv[155];
	local[4]= loadglobal(fqv[185]);
	local[5]= fqv[157];
	local[6]= fqv[186];
	local[7]= fqv[159];
	local[8]= NIL;
	local[9]= fqv[61];
	local[10]= NIL;
	local[11]= fqv[160];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[161];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[162]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM571interpolator_init,fqv[29],fqv[184],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM573interpolator_reset,fqv[85],fqv[184],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM580interpolator_position_list,fqv[78],fqv[184],fqv[189]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM582interpolator_position,fqv[190],fqv[184],fqv[191]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM584interpolator_time_list,fqv[79],fqv[184],fqv[192]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM586interpolator_time,fqv[193],fqv[184],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM588interpolator_segment_time,fqv[195],fqv[184],fqv[196]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM590interpolator_segment,fqv[197],fqv[184],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM592interpolator_segment_num,fqv[199],fqv[184],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM594interpolator_interpolatingp,fqv[201],fqv[184],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM596interpolator_start_interpolation,fqv[203],fqv[184],fqv[204]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM598interpolator_stop_interpolation,fqv[205],fqv[184],fqv[206]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM600interpolator_pass_time,fqv[207],fqv[184],fqv[208]);
	local[0]= fqv[209];
	local[1]= fqv[154];
	local[2]= fqv[209];
	local[3]= fqv[155];
	local[4]= loadglobal(fqv[184]);
	local[5]= fqv[157];
	local[6]= fqv[24];
	local[7]= fqv[159];
	local[8]= NIL;
	local[9]= fqv[61];
	local[10]= NIL;
	local[11]= fqv[160];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[161];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[162]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM615linear_interpolator_interpolation,fqv[82],fqv[209],fqv[210]);
	local[0]= fqv[211];
	local[1]= fqv[154];
	local[2]= fqv[211];
	local[3]= fqv[155];
	local[4]= loadglobal(fqv[184]);
	local[5]= fqv[157];
	local[6]= fqv[212];
	local[7]= fqv[159];
	local[8]= NIL;
	local[9]= fqv[61];
	local[10]= NIL;
	local[11]= fqv[160];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[161];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[162]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM619minjerk_interpolator_velocity,fqv[213],fqv[211],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM621minjerk_interpolator_velocity_list,fqv[87],fqv[211],fqv[215]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM623minjerk_interpolator_acceleration,fqv[216],fqv[211],fqv[217]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM625minjerk_interpolator_acceleration_list,fqv[88],fqv[211],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM627minjerk_interpolator_reset,fqv[85],fqv[211],fqv[219]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtutilM636minjerk_interpolator_interpolation,fqv[82],fqv[211],fqv[220]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[221],module,irtutilF425his2rgb,fqv[222]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[223],module,irtutilF426hvs2rgb,fqv[224]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[225],module,irtutilF427rgb2his,fqv[226]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[227],module,irtutilF428rgb2hvs,fqv[228]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[229],module,irtutilF429color_category10,fqv[230]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[231],module,irtutilF430color_category20,fqv[232]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[233],module,irtutilF702,fqv[234]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[235],module,irtutilF707,fqv[236]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[237],module,irtutilF710,fqv[238]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[108],module,irtutilF713,fqv[239]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[240],module,irtutilF716,fqv[241]);
	local[0]= fqv[242];
	local[1]= fqv[154];
	local[2]= fqv[242];
	local[3]= fqv[155];
	local[4]= loadglobal(fqv[243]);
	local[5]= fqv[157];
	local[6]= fqv[24];
	local[7]= fqv[159];
	local[8]= loadglobal(fqv[244]);
	local[9]= fqv[61];
	local[10]= fqv[122];
	local[11]= fqv[160];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[161];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[21])(ctx,13,local+2,&ftab[21],fqv[162]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= loadglobal(fqv[242]);
	local[1]= fqv[245];
	local[2]= fqv[246];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[247],module,irtutilF431termios_c_iflag,fqv[248]);
	local[0]= fqv[247];
	local[1]= fqv[249];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[247];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[247];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[247];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[249],module,irtutilF432set_termios_c_iflag,fqv[255]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[256],module,irtutilF433termios_c_oflag,fqv[257]);
	local[0]= fqv[256];
	local[1]= fqv[258];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[256];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[256];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[256];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[258],module,irtutilF434set_termios_c_oflag,fqv[259]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[260],module,irtutilF435termios_c_cflag,fqv[261]);
	local[0]= fqv[260];
	local[1]= fqv[262];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[260];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[260];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[260];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[262],module,irtutilF436set_termios_c_cflag,fqv[263]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[264],module,irtutilF437termios_c_lflag,fqv[265]);
	local[0]= fqv[264];
	local[1]= fqv[266];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[264];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[264];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[264];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[266],module,irtutilF438set_termios_c_lflag,fqv[267]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[268],module,irtutilF439termios_c_line,fqv[269]);
	local[0]= fqv[268];
	local[1]= fqv[270];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[268];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[268];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[268];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[270],module,irtutilF440set_termios_c_line,fqv[271]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[272],module,irtutilF441termios_c_cc,fqv[273]);
	local[0]= fqv[272];
	local[1]= fqv[274];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[272];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[272];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[272];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[274],module,irtutilF442set_termios_c_cc,fqv[275]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[276],module,irtutilF443termios_c_ispeed,fqv[277]);
	local[0]= fqv[276];
	local[1]= fqv[278];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[276];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[276];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[276];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[278],module,irtutilF444set_termios_c_ispeed,fqv[279]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[280],module,irtutilF445termios_c_ospeed,fqv[281]);
	local[0]= fqv[280];
	local[1]= fqv[282];
	local[2]= fqv[250];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= fqv[280];
	local[1]= fqv[251];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[280];
	local[1]= fqv[253];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,2,local+0,&ftab[22],fqv[252]); /*remprop*/
	local[0]= fqv[280];
	local[1]= NIL;
	local[2]= fqv[254];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[282],module,irtutilF446set_termios_c_ospeed,fqv[283]);
	local[0]= fqv[284];
	local[1]= fqv[285];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[286];
	local[1]= fqv[285];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[287];
	local[1]= fqv[285];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[288];
	local[1]= fqv[285];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[289],module,irtutilF447kbhit,fqv[290]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[291],module,irtutilF448piped_fork_returns_list,fqv[292]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[293],module,irtutilF449make_robot_model_from_name,fqv[294]);
	local[0]= fqv[295];
	local[1]= fqv[296];
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,2,local+0,&ftab[23],fqv[297]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<24; i++) ftab[i]=fcallx;
}
