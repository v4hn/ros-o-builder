
"use strict";

let TextToSpeech = require('./TextToSpeech.js')

module.exports = {
  TextToSpeech: TextToSpeech,
};
