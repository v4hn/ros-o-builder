
"use strict";

let SetIO = require('./SetIO.js')
let SetPayload = require('./SetPayload.js')
let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')
let SetForceMode = require('./SetForceMode.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')

module.exports = {
  SetIO: SetIO,
  SetPayload: SetPayload,
  SetSpeedSliderFraction: SetSpeedSliderFraction,
  SetForceMode: SetForceMode,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
  SetAnalogOutput: SetAnalogOutput,
};
