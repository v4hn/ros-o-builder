
"use strict";

let AprilTagDetectionArray = require('./AprilTagDetectionArray.js');
let AprilTagDetection = require('./AprilTagDetection.js');

module.exports = {
  AprilTagDetectionArray: AprilTagDetectionArray,
  AprilTagDetection: AprilTagDetection,
};
