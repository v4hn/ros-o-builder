// Auto-generated. Do not edit!

// (in-package pgm_learner.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class LinearGaussianNode {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.name = null;
      this.parents = null;
      this.children = null;
      this.mean = null;
      this.variance = null;
      this.mean_scalar = null;
    }
    else {
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('parents')) {
        this.parents = initObj.parents
      }
      else {
        this.parents = [];
      }
      if (initObj.hasOwnProperty('children')) {
        this.children = initObj.children
      }
      else {
        this.children = [];
      }
      if (initObj.hasOwnProperty('mean')) {
        this.mean = initObj.mean
      }
      else {
        this.mean = 0.0;
      }
      if (initObj.hasOwnProperty('variance')) {
        this.variance = initObj.variance
      }
      else {
        this.variance = 0.0;
      }
      if (initObj.hasOwnProperty('mean_scalar')) {
        this.mean_scalar = initObj.mean_scalar
      }
      else {
        this.mean_scalar = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinearGaussianNode
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [parents]
    bufferOffset = _arraySerializer.string(obj.parents, buffer, bufferOffset, null);
    // Serialize message field [children]
    bufferOffset = _arraySerializer.string(obj.children, buffer, bufferOffset, null);
    // Serialize message field [mean]
    bufferOffset = _serializer.float32(obj.mean, buffer, bufferOffset);
    // Serialize message field [variance]
    bufferOffset = _serializer.float32(obj.variance, buffer, bufferOffset);
    // Serialize message field [mean_scalar]
    bufferOffset = _arraySerializer.float32(obj.mean_scalar, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinearGaussianNode
    let len;
    let data = new LinearGaussianNode(null);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents]
    data.parents = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [children]
    data.children = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [mean]
    data.mean = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [variance]
    data.variance = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [mean_scalar]
    data.mean_scalar = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    object.parents.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    object.children.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 4 * object.mean_scalar.length;
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pgm_learner/LinearGaussianNode';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '78e1d100b7497d3d3e117e9c91018b8c';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string name
    string[] parents
    string[] children
    
    float32 mean
    float32 variance
    
    float32[] mean_scalar # scalar for parents
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinearGaussianNode(null);
    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.parents !== undefined) {
      resolved.parents = msg.parents;
    }
    else {
      resolved.parents = []
    }

    if (msg.children !== undefined) {
      resolved.children = msg.children;
    }
    else {
      resolved.children = []
    }

    if (msg.mean !== undefined) {
      resolved.mean = msg.mean;
    }
    else {
      resolved.mean = 0.0
    }

    if (msg.variance !== undefined) {
      resolved.variance = msg.variance;
    }
    else {
      resolved.variance = 0.0
    }

    if (msg.mean_scalar !== undefined) {
      resolved.mean_scalar = msg.mean_scalar;
    }
    else {
      resolved.mean_scalar = []
    }

    return resolved;
    }
};

module.exports = LinearGaussianNode;
