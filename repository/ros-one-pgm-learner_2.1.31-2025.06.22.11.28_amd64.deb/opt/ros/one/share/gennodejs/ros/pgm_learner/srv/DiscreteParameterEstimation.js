// Auto-generated. Do not edit!

// (in-package pgm_learner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let GraphStructure = require('../msg/GraphStructure.js');
let DiscreteGraphState = require('../msg/DiscreteGraphState.js');

//-----------------------------------------------------------

let DiscreteNode = require('../msg/DiscreteNode.js');

//-----------------------------------------------------------

class DiscreteParameterEstimationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.graph = null;
      this.states = null;
    }
    else {
      if (initObj.hasOwnProperty('graph')) {
        this.graph = initObj.graph
      }
      else {
        this.graph = new GraphStructure();
      }
      if (initObj.hasOwnProperty('states')) {
        this.states = initObj.states
      }
      else {
        this.states = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteParameterEstimationRequest
    // Serialize message field [graph]
    bufferOffset = GraphStructure.serialize(obj.graph, buffer, bufferOffset);
    // Serialize message field [states]
    // Serialize the length for message field [states]
    bufferOffset = _serializer.uint32(obj.states.length, buffer, bufferOffset);
    obj.states.forEach((val) => {
      bufferOffset = DiscreteGraphState.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteParameterEstimationRequest
    let len;
    let data = new DiscreteParameterEstimationRequest(null);
    // Deserialize message field [graph]
    data.graph = GraphStructure.deserialize(buffer, bufferOffset);
    // Deserialize message field [states]
    // Deserialize array length for message field [states]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.states = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.states[i] = DiscreteGraphState.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += GraphStructure.getMessageSize(object.graph);
    object.states.forEach((val) => {
      length += DiscreteGraphState.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/DiscreteParameterEstimationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a4887ac175e64291ed3c977eac937022';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/GraphStructure graph # graph skeleton
    pgm_learner/DiscreteGraphState[] states # trial data
    
    ================================================================================
    MSG: pgm_learner/GraphStructure
    string[] nodes
    pgm_learner/GraphEdge[] edges
    
    ================================================================================
    MSG: pgm_learner/GraphEdge
    string node_from
    string node_to
    
    ================================================================================
    MSG: pgm_learner/DiscreteGraphState
    pgm_learner/DiscreteNodeState[] node_states
    
    ================================================================================
    MSG: pgm_learner/DiscreteNodeState
    string node
    string state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteParameterEstimationRequest(null);
    if (msg.graph !== undefined) {
      resolved.graph = GraphStructure.Resolve(msg.graph)
    }
    else {
      resolved.graph = new GraphStructure()
    }

    if (msg.states !== undefined) {
      resolved.states = new Array(msg.states.length);
      for (let i = 0; i < resolved.states.length; ++i) {
        resolved.states[i] = DiscreteGraphState.Resolve(msg.states[i]);
      }
    }
    else {
      resolved.states = []
    }

    return resolved;
    }
};

class DiscreteParameterEstimationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nodes = null;
    }
    else {
      if (initObj.hasOwnProperty('nodes')) {
        this.nodes = initObj.nodes
      }
      else {
        this.nodes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type DiscreteParameterEstimationResponse
    // Serialize message field [nodes]
    // Serialize the length for message field [nodes]
    bufferOffset = _serializer.uint32(obj.nodes.length, buffer, bufferOffset);
    obj.nodes.forEach((val) => {
      bufferOffset = DiscreteNode.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type DiscreteParameterEstimationResponse
    let len;
    let data = new DiscreteParameterEstimationResponse(null);
    // Deserialize message field [nodes]
    // Deserialize array length for message field [nodes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nodes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nodes[i] = DiscreteNode.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.nodes.forEach((val) => {
      length += DiscreteNode.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/DiscreteParameterEstimationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c8f93aadf5ce2cc57073d952e12833e1';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/DiscreteNode[] nodes # information of each nodes
    
    
    ================================================================================
    MSG: pgm_learner/DiscreteNode
    string name
    string[] outcomes
    string[] parents
    string[] children
    pgm_learner/ConditionalProbability[] CPT
    
    ================================================================================
    MSG: pgm_learner/ConditionalProbability
    string[]  values
    float32[] probabilities
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new DiscreteParameterEstimationResponse(null);
    if (msg.nodes !== undefined) {
      resolved.nodes = new Array(msg.nodes.length);
      for (let i = 0; i < resolved.nodes.length; ++i) {
        resolved.nodes[i] = DiscreteNode.Resolve(msg.nodes[i]);
      }
    }
    else {
      resolved.nodes = []
    }

    return resolved;
    }
};

module.exports = {
  Request: DiscreteParameterEstimationRequest,
  Response: DiscreteParameterEstimationResponse,
  md5sum() { return 'bf4a94ba6c903228425606a8b08d8ab9'; },
  datatype() { return 'pgm_learner/DiscreteParameterEstimation'; }
};
