
"use strict";

let DiscreteQuery = require('./DiscreteQuery.js')
let LinearGaussianStructureEstimation = require('./LinearGaussianStructureEstimation.js')
let LinearGaussianParameterEstimation = require('./LinearGaussianParameterEstimation.js')
let DiscreteStructureEstimation = require('./DiscreteStructureEstimation.js')
let DiscreteParameterEstimation = require('./DiscreteParameterEstimation.js')

module.exports = {
  DiscreteQuery: DiscreteQuery,
  LinearGaussianStructureEstimation: LinearGaussianStructureEstimation,
  LinearGaussianParameterEstimation: LinearGaussianParameterEstimation,
  DiscreteStructureEstimation: DiscreteStructureEstimation,
  DiscreteParameterEstimation: DiscreteParameterEstimation,
};
