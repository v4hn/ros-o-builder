
"use strict";

let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let Table = require('./Table.js');
let TableArray = require('./TableArray.js');
let RecognizedObject = require('./RecognizedObject.js');
let ObjectType = require('./ObjectType.js');
let ObjectInformation = require('./ObjectInformation.js');

module.exports = {
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  RecognizedObjectArray: RecognizedObjectArray,
  Table: Table,
  TableArray: TableArray,
  RecognizedObject: RecognizedObject,
  ObjectType: ObjectType,
  ObjectInformation: ObjectInformation,
};
