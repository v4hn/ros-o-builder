
"use strict";

let UpdateFilename = require('./UpdateFilename.js')

module.exports = {
  UpdateFilename: UpdateFilename,
};
