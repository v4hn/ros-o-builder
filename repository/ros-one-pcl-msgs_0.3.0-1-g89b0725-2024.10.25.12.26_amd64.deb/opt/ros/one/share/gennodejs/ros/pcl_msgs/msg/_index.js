
"use strict";

let Vertices = require('./Vertices.js');
let PolygonMesh = require('./PolygonMesh.js');
let ModelCoefficients = require('./ModelCoefficients.js');
let PointIndices = require('./PointIndices.js');

module.exports = {
  Vertices: Vertices,
  PolygonMesh: PolygonMesh,
  ModelCoefficients: ModelCoefficients,
  PointIndices: PointIndices,
};
