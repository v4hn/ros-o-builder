(cl:in-package foxglove_msgs-msg)
(cl:export '(START_TIME-VAL
          START_TIME
          END_TIME-VAL
          END_TIME
          METADATA-VAL
          METADATA
))