
"use strict";

let Velocity = require('./Velocity.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeFeedback = require('./ShapeFeedback.js');

module.exports = {
  Velocity: Velocity,
  ShapeActionResult: ShapeActionResult,
  ShapeAction: ShapeAction,
  ShapeActionGoal: ShapeActionGoal,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeResult: ShapeResult,
  ShapeGoal: ShapeGoal,
  ShapeFeedback: ShapeFeedback,
};
