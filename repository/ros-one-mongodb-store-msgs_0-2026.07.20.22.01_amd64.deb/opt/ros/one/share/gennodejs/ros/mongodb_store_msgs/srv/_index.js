
"use strict";

let MongoInsertMsg = require('./MongoInsertMsg.js')
let MongoUpdateMsg = require('./MongoUpdateMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')
let MongoDeleteMsg = require('./MongoDeleteMsg.js')
let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')

module.exports = {
  MongoInsertMsg: MongoInsertMsg,
  MongoUpdateMsg: MongoUpdateMsg,
  MongoQueryMsg: MongoQueryMsg,
  MongoDeleteMsg: MongoDeleteMsg,
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
};
