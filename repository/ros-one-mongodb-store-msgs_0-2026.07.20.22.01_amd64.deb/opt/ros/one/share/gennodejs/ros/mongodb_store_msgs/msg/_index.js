
"use strict";

let Insert = require('./Insert.js');
let StringList = require('./StringList.js');
let StringPair = require('./StringPair.js');
let SerialisedMessage = require('./SerialisedMessage.js');
let StringPairList = require('./StringPairList.js');
let MoveEntriesGoal = require('./MoveEntriesGoal.js');
let MoveEntriesAction = require('./MoveEntriesAction.js');
let MoveEntriesActionFeedback = require('./MoveEntriesActionFeedback.js');
let MoveEntriesActionGoal = require('./MoveEntriesActionGoal.js');
let MoveEntriesActionResult = require('./MoveEntriesActionResult.js');
let MoveEntriesFeedback = require('./MoveEntriesFeedback.js');
let MoveEntriesResult = require('./MoveEntriesResult.js');

module.exports = {
  Insert: Insert,
  StringList: StringList,
  StringPair: StringPair,
  SerialisedMessage: SerialisedMessage,
  StringPairList: StringPairList,
  MoveEntriesGoal: MoveEntriesGoal,
  MoveEntriesAction: MoveEntriesAction,
  MoveEntriesActionFeedback: MoveEntriesActionFeedback,
  MoveEntriesActionGoal: MoveEntriesActionGoal,
  MoveEntriesActionResult: MoveEntriesActionResult,
  MoveEntriesFeedback: MoveEntriesFeedback,
  MoveEntriesResult: MoveEntriesResult,
};
