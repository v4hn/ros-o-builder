
"use strict";

let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestResult: SoundRequestResult,
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequest: SoundRequest,
};
