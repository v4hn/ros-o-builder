
"use strict";

let IsInRemoteControl = require('./IsInRemoteControl.js')
let Popup = require('./Popup.js')
let GetLoadedProgram = require('./GetLoadedProgram.js')
let GetProgramState = require('./GetProgramState.js')
let GetSafetyMode = require('./GetSafetyMode.js')
let Load = require('./Load.js')
let AddToLog = require('./AddToLog.js')
let IsProgramSaved = require('./IsProgramSaved.js')
let IsProgramRunning = require('./IsProgramRunning.js')
let GetRobotMode = require('./GetRobotMode.js')
let RawRequest = require('./RawRequest.js')

module.exports = {
  IsInRemoteControl: IsInRemoteControl,
  Popup: Popup,
  GetLoadedProgram: GetLoadedProgram,
  GetProgramState: GetProgramState,
  GetSafetyMode: GetSafetyMode,
  Load: Load,
  AddToLog: AddToLog,
  IsProgramSaved: IsProgramSaved,
  IsProgramRunning: IsProgramRunning,
  GetRobotMode: GetRobotMode,
  RawRequest: RawRequest,
};
