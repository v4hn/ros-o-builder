
"use strict";

let DataPoints = require('./DataPoints.js');
let DataPoint = require('./DataPoint.js');
let StatisticsValues = require('./StatisticsValues.js');
let Dictionary = require('./Dictionary.js');
let StatisticsNames = require('./StatisticsNames.js');

module.exports = {
  DataPoints: DataPoints,
  DataPoint: DataPoint,
  StatisticsValues: StatisticsValues,
  Dictionary: Dictionary,
  StatisticsNames: StatisticsNames,
};
