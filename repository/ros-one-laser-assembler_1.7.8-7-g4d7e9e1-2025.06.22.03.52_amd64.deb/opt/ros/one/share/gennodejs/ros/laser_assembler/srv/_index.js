
"use strict";

let AssembleScans2 = require('./AssembleScans2.js')
let AssembleScans = require('./AssembleScans.js')

module.exports = {
  AssembleScans2: AssembleScans2,
  AssembleScans: AssembleScans,
};
