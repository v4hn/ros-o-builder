
"use strict";

let Sub5ActionFeedback = require('./Sub5ActionFeedback.js');
let Multiply10ActionGoal = require('./Multiply10ActionGoal.js');
let Sub5Action = require('./Sub5Action.js');
let Multiply10Result = require('./Multiply10Result.js');
let Multiply10Action = require('./Multiply10Action.js');
let Multiply10Feedback = require('./Multiply10Feedback.js');
let Sub5ActionGoal = require('./Sub5ActionGoal.js');
let Sub5Goal = require('./Sub5Goal.js');
let Sub5ActionResult = require('./Sub5ActionResult.js');
let Sub5Feedback = require('./Sub5Feedback.js');
let Multiply10ActionResult = require('./Multiply10ActionResult.js');
let Multiply10Goal = require('./Multiply10Goal.js');
let Sub5Result = require('./Sub5Result.js');
let Multiply10ActionFeedback = require('./Multiply10ActionFeedback.js');

module.exports = {
  Sub5ActionFeedback: Sub5ActionFeedback,
  Multiply10ActionGoal: Multiply10ActionGoal,
  Sub5Action: Sub5Action,
  Multiply10Result: Multiply10Result,
  Multiply10Action: Multiply10Action,
  Multiply10Feedback: Multiply10Feedback,
  Sub5ActionGoal: Sub5ActionGoal,
  Sub5Goal: Sub5Goal,
  Sub5ActionResult: Sub5ActionResult,
  Sub5Feedback: Sub5Feedback,
  Multiply10ActionResult: Multiply10ActionResult,
  Multiply10Goal: Multiply10Goal,
  Sub5Result: Sub5Result,
  Multiply10ActionFeedback: Multiply10ActionFeedback,
};
