
"use strict";

let StartApp = require('./StartApp.js')
let ListApps = require('./ListApps.js')
let GetAppDetails = require('./GetAppDetails.js')
let StopApp = require('./StopApp.js')
let InstallApp = require('./InstallApp.js')
let GetInstallationState = require('./GetInstallationState.js')
let UninstallApp = require('./UninstallApp.js')

module.exports = {
  StartApp: StartApp,
  ListApps: ListApps,
  GetAppDetails: GetAppDetails,
  StopApp: StopApp,
  InstallApp: InstallApp,
  GetInstallationState: GetInstallationState,
  UninstallApp: UninstallApp,
};
