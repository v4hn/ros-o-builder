// Auto-generated. Do not edit!

// (in-package app_manager.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let KeyValue = require('./KeyValue.js');

//-----------------------------------------------------------

class ClientApp {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.client_type = null;
      this.manager_data = null;
      this.app_data = null;
    }
    else {
      if (initObj.hasOwnProperty('client_type')) {
        this.client_type = initObj.client_type
      }
      else {
        this.client_type = '';
      }
      if (initObj.hasOwnProperty('manager_data')) {
        this.manager_data = initObj.manager_data
      }
      else {
        this.manager_data = [];
      }
      if (initObj.hasOwnProperty('app_data')) {
        this.app_data = initObj.app_data
      }
      else {
        this.app_data = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ClientApp
    // Serialize message field [client_type]
    bufferOffset = _serializer.string(obj.client_type, buffer, bufferOffset);
    // Serialize message field [manager_data]
    // Serialize the length for message field [manager_data]
    bufferOffset = _serializer.uint32(obj.manager_data.length, buffer, bufferOffset);
    obj.manager_data.forEach((val) => {
      bufferOffset = KeyValue.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [app_data]
    // Serialize the length for message field [app_data]
    bufferOffset = _serializer.uint32(obj.app_data.length, buffer, bufferOffset);
    obj.app_data.forEach((val) => {
      bufferOffset = KeyValue.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ClientApp
    let len;
    let data = new ClientApp(null);
    // Deserialize message field [client_type]
    data.client_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [manager_data]
    // Deserialize array length for message field [manager_data]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.manager_data = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.manager_data[i] = KeyValue.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [app_data]
    // Deserialize array length for message field [app_data]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.app_data = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.app_data[i] = KeyValue.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.client_type);
    object.manager_data.forEach((val) => {
      length += KeyValue.getMessageSize(val);
    });
    object.app_data.forEach((val) => {
      length += KeyValue.getMessageSize(val);
    });
    return length + 12;
  }

  static datatype() {
    // Returns string type for a message object
    return 'app_manager/ClientApp';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0a8112672c3fbf73cb62ec78d67e41bb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # like "android" or "web" or "linux"
    string client_type
    
    # like "intent = ros.android.teleop" and "accelerometer = true", used to choose which ClientApp to use
    KeyValue[] manager_data
    
    # parameters which just get passed through to the client app.
    KeyValue[] app_data
    
    ================================================================================
    MSG: app_manager/KeyValue
    string key
    string value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ClientApp(null);
    if (msg.client_type !== undefined) {
      resolved.client_type = msg.client_type;
    }
    else {
      resolved.client_type = ''
    }

    if (msg.manager_data !== undefined) {
      resolved.manager_data = new Array(msg.manager_data.length);
      for (let i = 0; i < resolved.manager_data.length; ++i) {
        resolved.manager_data[i] = KeyValue.Resolve(msg.manager_data[i]);
      }
    }
    else {
      resolved.manager_data = []
    }

    if (msg.app_data !== undefined) {
      resolved.app_data = new Array(msg.app_data.length);
      for (let i = 0; i < resolved.app_data.length; ++i) {
        resolved.app_data[i] = KeyValue.Resolve(msg.app_data[i]);
      }
    }
    else {
      resolved.app_data = []
    }

    return resolved;
    }
};

module.exports = ClientApp;
