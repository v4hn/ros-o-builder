
"use strict";

let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let Table = require('./Table.js');
let ObjectInformation = require('./ObjectInformation.js');
let ObjectType = require('./ObjectType.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let TableArray = require('./TableArray.js');
let RecognizedObject = require('./RecognizedObject.js');

module.exports = {
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  Table: Table,
  ObjectInformation: ObjectInformation,
  ObjectType: ObjectType,
  RecognizedObjectArray: RecognizedObjectArray,
  TableArray: TableArray,
  RecognizedObject: RecognizedObject,
};
