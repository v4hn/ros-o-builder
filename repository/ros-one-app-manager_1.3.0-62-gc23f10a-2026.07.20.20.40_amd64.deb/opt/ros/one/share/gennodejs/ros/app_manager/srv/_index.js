
"use strict";

let GetAppDetails = require('./GetAppDetails.js')
let InstallApp = require('./InstallApp.js')
let GetInstallationState = require('./GetInstallationState.js')
let StopApp = require('./StopApp.js')
let StartApp = require('./StartApp.js')
let UninstallApp = require('./UninstallApp.js')
let ListApps = require('./ListApps.js')

module.exports = {
  GetAppDetails: GetAppDetails,
  InstallApp: InstallApp,
  GetInstallationState: GetInstallationState,
  StopApp: StopApp,
  StartApp: StartApp,
  UninstallApp: UninstallApp,
  ListApps: ListApps,
};
