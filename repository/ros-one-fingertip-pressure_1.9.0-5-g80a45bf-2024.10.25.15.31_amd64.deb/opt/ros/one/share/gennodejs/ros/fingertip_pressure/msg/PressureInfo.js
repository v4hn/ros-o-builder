// Auto-generated. Do not edit!

// (in-package fingertip_pressure.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PressureInfoElement = require('./PressureInfoElement.js');

//-----------------------------------------------------------

class PressureInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sensor = null;
    }
    else {
      if (initObj.hasOwnProperty('sensor')) {
        this.sensor = initObj.sensor
      }
      else {
        this.sensor = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PressureInfo
    // Serialize message field [sensor]
    // Serialize the length for message field [sensor]
    bufferOffset = _serializer.uint32(obj.sensor.length, buffer, bufferOffset);
    obj.sensor.forEach((val) => {
      bufferOffset = PressureInfoElement.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PressureInfo
    let len;
    let data = new PressureInfo(null);
    // Deserialize message field [sensor]
    // Deserialize array length for message field [sensor]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.sensor = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.sensor[i] = PressureInfoElement.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.sensor.forEach((val) => {
      length += PressureInfoElement.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a message object
    return 'fingertip_pressure/PressureInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a11fc5bae3534aa023741e378743af5b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    PressureInfoElement[] sensor # List of pressure sensors for which information is being published
    
    ================================================================================
    MSG: fingertip_pressure/PressureInfoElement
    string frame_id # Frame ID
    geometry_msgs/Vector3[] center # Corner of sensor (meters)
    geometry_msgs/Vector3[] halfside1 # Half of one edge of sensor (meters)
    geometry_msgs/Vector3[] halfside2 # Half of perpendicular edge of sensor (meters)
    # Sensor corners are at center+-halfside1+-halfside2
    # Cross product of halfside1 and halfside2 points out
    float64[] force_per_unit # Multiply this by the raw sensor value to get a force
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PressureInfo(null);
    if (msg.sensor !== undefined) {
      resolved.sensor = new Array(msg.sensor.length);
      for (let i = 0; i < resolved.sensor.length; ++i) {
        resolved.sensor[i] = PressureInfoElement.Resolve(msg.sensor[i]);
      }
    }
    else {
      resolved.sensor = []
    }

    return resolved;
    }
};

module.exports = PressureInfo;
