
"use strict";

let TrainClassifier = require('./TrainClassifier.js')
let AddClassData = require('./AddClassData.js')
let LoadClassifier = require('./LoadClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let CreateClassifier = require('./CreateClassifier.js')
let ClearClassifier = require('./ClearClassifier.js')
let SaveClassifier = require('./SaveClassifier.js')

module.exports = {
  TrainClassifier: TrainClassifier,
  AddClassData: AddClassData,
  LoadClassifier: LoadClassifier,
  ClassifyData: ClassifyData,
  CreateClassifier: CreateClassifier,
  ClearClassifier: ClearClassifier,
  SaveClassifier: SaveClassifier,
};
