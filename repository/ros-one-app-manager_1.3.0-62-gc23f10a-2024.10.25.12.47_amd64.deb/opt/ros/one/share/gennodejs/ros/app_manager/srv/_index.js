
"use strict";

let GetInstallationState = require('./GetInstallationState.js')
let ListApps = require('./ListApps.js')
let StopApp = require('./StopApp.js')
let StartApp = require('./StartApp.js')
let UninstallApp = require('./UninstallApp.js')
let InstallApp = require('./InstallApp.js')
let GetAppDetails = require('./GetAppDetails.js')

module.exports = {
  GetInstallationState: GetInstallationState,
  ListApps: ListApps,
  StopApp: StopApp,
  StartApp: StartApp,
  UninstallApp: UninstallApp,
  InstallApp: InstallApp,
  GetAppDetails: GetAppDetails,
};
