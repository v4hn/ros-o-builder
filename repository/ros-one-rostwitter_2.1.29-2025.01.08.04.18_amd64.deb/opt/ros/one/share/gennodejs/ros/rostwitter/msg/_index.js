
"use strict";

let TweetActionGoal = require('./TweetActionGoal.js');
let TweetFeedback = require('./TweetFeedback.js');
let TweetAction = require('./TweetAction.js');
let TweetGoal = require('./TweetGoal.js');
let TweetActionResult = require('./TweetActionResult.js');
let TweetActionFeedback = require('./TweetActionFeedback.js');
let TweetResult = require('./TweetResult.js');

module.exports = {
  TweetActionGoal: TweetActionGoal,
  TweetFeedback: TweetFeedback,
  TweetAction: TweetAction,
  TweetGoal: TweetGoal,
  TweetActionResult: TweetActionResult,
  TweetActionFeedback: TweetActionFeedback,
  TweetResult: TweetResult,
};
