
"use strict";

let GetMapROI = require('./GetMapROI.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetPointMap = require('./GetPointMap.js')
let SaveMap = require('./SaveMap.js')
let SetMapProjections = require('./SetMapProjections.js')

module.exports = {
  GetMapROI: GetMapROI,
  GetPointMapROI: GetPointMapROI,
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetPointMap: GetPointMap,
  SaveMap: SaveMap,
  SetMapProjections: SetMapProjections,
};
