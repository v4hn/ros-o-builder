
"use strict";

let DeviceArray = require('./DeviceArray.js');
let Hub2 = require('./Hub2.js');
let StripLight = require('./StripLight.js');
let MeterProCO2 = require('./MeterProCO2.js');
let Device = require('./Device.js');
let Meter = require('./Meter.js');
let PlugMini = require('./PlugMini.js');
let Bot = require('./Bot.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');

module.exports = {
  DeviceArray: DeviceArray,
  Hub2: Hub2,
  StripLight: StripLight,
  MeterProCO2: MeterProCO2,
  Device: Device,
  Meter: Meter,
  PlugMini: PlugMini,
  Bot: Bot,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
  SwitchBotCommandAction: SwitchBotCommandAction,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
};
