(cl:in-package opencv_apps-msg)
(cl:export '(HEADER-VAL
          HEADER
          FACES-VAL
          FACES
))