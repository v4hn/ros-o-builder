(cl:in-package ml_classifiers-srv)
(cl:export '(IDENTIFIER-VAL
          IDENTIFIER
          SUCCESS-VAL
          SUCCESS
))