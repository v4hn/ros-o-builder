(cl:in-package ml_classifiers-srv)
(cl:export '(IDENTIFIER-VAL
          IDENTIFIER
          CLASS_TYPE-VAL
          CLASS_TYPE
          SUCCESS-VAL
          SUCCESS
))