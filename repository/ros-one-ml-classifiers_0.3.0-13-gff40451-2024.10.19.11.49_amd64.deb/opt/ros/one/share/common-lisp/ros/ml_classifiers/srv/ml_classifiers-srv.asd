
(cl:in-package :asdf)

(defsystem "ml_classifiers-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :ml_classifiers-msg
)
  :components ((:file "_package")
    (:file "AddClassData" :depends-on ("_package_AddClassData"))
    (:file "_package_AddClassData" :depends-on ("_package"))
    (:file "ClassifyData" :depends-on ("_package_ClassifyData"))
    (:file "_package_ClassifyData" :depends-on ("_package"))
    (:file "ClearClassifier" :depends-on ("_package_ClearClassifier"))
    (:file "_package_ClearClassifier" :depends-on ("_package"))
    (:file "CreateClassifier" :depends-on ("_package_CreateClassifier"))
    (:file "_package_CreateClassifier" :depends-on ("_package"))
    (:file "LoadClassifier" :depends-on ("_package_LoadClassifier"))
    (:file "_package_LoadClassifier" :depends-on ("_package"))
    (:file "SaveClassifier" :depends-on ("_package_SaveClassifier"))
    (:file "_package_SaveClassifier" :depends-on ("_package"))
    (:file "TrainClassifier" :depends-on ("_package_TrainClassifier"))
    (:file "_package_TrainClassifier" :depends-on ("_package"))
  ))