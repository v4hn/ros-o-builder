(cl:in-package ml_classifiers-msg)
(cl:export '(TARGET_CLASS-VAL
          TARGET_CLASS
          POINT-VAL
          POINT
))