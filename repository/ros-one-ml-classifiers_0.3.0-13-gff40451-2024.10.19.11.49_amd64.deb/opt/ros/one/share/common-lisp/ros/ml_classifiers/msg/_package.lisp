(cl:defpackage ml_classifiers-msg
  (:use )
  (:export
   "<CLASSDATAPOINT>"
   "CLASSDATAPOINT"
  ))

