; Auto-generated. Do not edit!


(cl:in-package ml_classifiers-srv)


;//! \htmlinclude ClassifyData-request.msg.html

(cl:defclass <ClassifyData-request> (roslisp-msg-protocol:ros-message)
  ((identifier
    :reader identifier
    :initarg :identifier
    :type cl:string
    :initform "")
   (data
    :reader data
    :initarg :data
    :type (cl:vector ml_classifiers-msg:ClassDataPoint)
   :initform (cl:make-array 0 :element-type 'ml_classifiers-msg:ClassDataPoint :initial-element (cl:make-instance 'ml_classifiers-msg:ClassDataPoint))))
)

(cl:defclass ClassifyData-request (<ClassifyData-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ClassifyData-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ClassifyData-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<ClassifyData-request> is deprecated: use ml_classifiers-srv:ClassifyData-request instead.")))

(cl:ensure-generic-function 'identifier-val :lambda-list '(m))
(cl:defmethod identifier-val ((m <ClassifyData-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:identifier-val is deprecated.  Use ml_classifiers-srv:identifier instead.")
  (identifier m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <ClassifyData-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:data-val is deprecated.  Use ml_classifiers-srv:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ClassifyData-request>) ostream)
  "Serializes a message object of type '<ClassifyData-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'identifier))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'identifier))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ClassifyData-request>) istream)
  "Deserializes a message object of type '<ClassifyData-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'identifier) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'identifier) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'ml_classifiers-msg:ClassDataPoint))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ClassifyData-request>)))
  "Returns string type for a service object of type '<ClassifyData-request>"
  "ml_classifiers/ClassifyDataRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ClassifyData-request)))
  "Returns string type for a service object of type 'ClassifyData-request"
  "ml_classifiers/ClassifyDataRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ClassifyData-request>)))
  "Returns md5sum for a message object of type '<ClassifyData-request>"
  "5ee7ec82bea2c231e357662def7bf4a4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ClassifyData-request)))
  "Returns md5sum for a message object of type 'ClassifyData-request"
  "5ee7ec82bea2c231e357662def7bf4a4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ClassifyData-request>)))
  "Returns full string definition for message of type '<ClassifyData-request>"
  (cl:format cl:nil "string identifier~%ClassDataPoint[] data~%~%================================================================================~%MSG: ml_classifiers/ClassDataPoint~%string target_class~%float64[] point~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ClassifyData-request)))
  "Returns full string definition for message of type 'ClassifyData-request"
  (cl:format cl:nil "string identifier~%ClassDataPoint[] data~%~%================================================================================~%MSG: ml_classifiers/ClassDataPoint~%string target_class~%float64[] point~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ClassifyData-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'identifier))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ClassifyData-request>))
  "Converts a ROS message object to a list"
  (cl:list 'ClassifyData-request
    (cl:cons ':identifier (identifier msg))
    (cl:cons ':data (data msg))
))
;//! \htmlinclude ClassifyData-response.msg.html

(cl:defclass <ClassifyData-response> (roslisp-msg-protocol:ros-message)
  ((classifications
    :reader classifications
    :initarg :classifications
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element "")))
)

(cl:defclass ClassifyData-response (<ClassifyData-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ClassifyData-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ClassifyData-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<ClassifyData-response> is deprecated: use ml_classifiers-srv:ClassifyData-response instead.")))

(cl:ensure-generic-function 'classifications-val :lambda-list '(m))
(cl:defmethod classifications-val ((m <ClassifyData-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:classifications-val is deprecated.  Use ml_classifiers-srv:classifications instead.")
  (classifications m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ClassifyData-response>) ostream)
  "Serializes a message object of type '<ClassifyData-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'classifications))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'classifications))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ClassifyData-response>) istream)
  "Deserializes a message object of type '<ClassifyData-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'classifications) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'classifications)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ClassifyData-response>)))
  "Returns string type for a service object of type '<ClassifyData-response>"
  "ml_classifiers/ClassifyDataResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ClassifyData-response)))
  "Returns string type for a service object of type 'ClassifyData-response"
  "ml_classifiers/ClassifyDataResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ClassifyData-response>)))
  "Returns md5sum for a message object of type '<ClassifyData-response>"
  "5ee7ec82bea2c231e357662def7bf4a4")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ClassifyData-response)))
  "Returns md5sum for a message object of type 'ClassifyData-response"
  "5ee7ec82bea2c231e357662def7bf4a4")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ClassifyData-response>)))
  "Returns full string definition for message of type '<ClassifyData-response>"
  (cl:format cl:nil "string[] classifications~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ClassifyData-response)))
  "Returns full string definition for message of type 'ClassifyData-response"
  (cl:format cl:nil "string[] classifications~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ClassifyData-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'classifications) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ClassifyData-response>))
  "Converts a ROS message object to a list"
  (cl:list 'ClassifyData-response
    (cl:cons ':classifications (classifications msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'ClassifyData)))
  'ClassifyData-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'ClassifyData)))
  'ClassifyData-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ClassifyData)))
  "Returns string type for a service object of type '<ClassifyData>"
  "ml_classifiers/ClassifyData")