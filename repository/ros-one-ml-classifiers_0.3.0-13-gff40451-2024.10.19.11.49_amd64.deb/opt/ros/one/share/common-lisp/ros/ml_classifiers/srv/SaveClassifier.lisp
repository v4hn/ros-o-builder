; Auto-generated. Do not edit!


(cl:in-package ml_classifiers-srv)


;//! \htmlinclude SaveClassifier-request.msg.html

(cl:defclass <SaveClassifier-request> (roslisp-msg-protocol:ros-message)
  ((identifier
    :reader identifier
    :initarg :identifier
    :type cl:string
    :initform "")
   (filename
    :reader filename
    :initarg :filename
    :type cl:string
    :initform ""))
)

(cl:defclass SaveClassifier-request (<SaveClassifier-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SaveClassifier-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SaveClassifier-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<SaveClassifier-request> is deprecated: use ml_classifiers-srv:SaveClassifier-request instead.")))

(cl:ensure-generic-function 'identifier-val :lambda-list '(m))
(cl:defmethod identifier-val ((m <SaveClassifier-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:identifier-val is deprecated.  Use ml_classifiers-srv:identifier instead.")
  (identifier m))

(cl:ensure-generic-function 'filename-val :lambda-list '(m))
(cl:defmethod filename-val ((m <SaveClassifier-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:filename-val is deprecated.  Use ml_classifiers-srv:filename instead.")
  (filename m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SaveClassifier-request>) ostream)
  "Serializes a message object of type '<SaveClassifier-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'identifier))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'identifier))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'filename))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'filename))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SaveClassifier-request>) istream)
  "Deserializes a message object of type '<SaveClassifier-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'identifier) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'identifier) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'filename) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'filename) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SaveClassifier-request>)))
  "Returns string type for a service object of type '<SaveClassifier-request>"
  "ml_classifiers/SaveClassifierRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SaveClassifier-request)))
  "Returns string type for a service object of type 'SaveClassifier-request"
  "ml_classifiers/SaveClassifierRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SaveClassifier-request>)))
  "Returns md5sum for a message object of type '<SaveClassifier-request>"
  "dca3260ff732b49e8277c15729218301")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SaveClassifier-request)))
  "Returns md5sum for a message object of type 'SaveClassifier-request"
  "dca3260ff732b49e8277c15729218301")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SaveClassifier-request>)))
  "Returns full string definition for message of type '<SaveClassifier-request>"
  (cl:format cl:nil "string identifier~%string filename~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SaveClassifier-request)))
  "Returns full string definition for message of type 'SaveClassifier-request"
  (cl:format cl:nil "string identifier~%string filename~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SaveClassifier-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'identifier))
     4 (cl:length (cl:slot-value msg 'filename))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SaveClassifier-request>))
  "Converts a ROS message object to a list"
  (cl:list 'SaveClassifier-request
    (cl:cons ':identifier (identifier msg))
    (cl:cons ':filename (filename msg))
))
;//! \htmlinclude SaveClassifier-response.msg.html

(cl:defclass <SaveClassifier-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass SaveClassifier-response (<SaveClassifier-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SaveClassifier-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SaveClassifier-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<SaveClassifier-response> is deprecated: use ml_classifiers-srv:SaveClassifier-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <SaveClassifier-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:success-val is deprecated.  Use ml_classifiers-srv:success instead.")
  (success m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SaveClassifier-response>) ostream)
  "Serializes a message object of type '<SaveClassifier-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SaveClassifier-response>) istream)
  "Deserializes a message object of type '<SaveClassifier-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SaveClassifier-response>)))
  "Returns string type for a service object of type '<SaveClassifier-response>"
  "ml_classifiers/SaveClassifierResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SaveClassifier-response)))
  "Returns string type for a service object of type 'SaveClassifier-response"
  "ml_classifiers/SaveClassifierResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SaveClassifier-response>)))
  "Returns md5sum for a message object of type '<SaveClassifier-response>"
  "dca3260ff732b49e8277c15729218301")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SaveClassifier-response)))
  "Returns md5sum for a message object of type 'SaveClassifier-response"
  "dca3260ff732b49e8277c15729218301")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SaveClassifier-response>)))
  "Returns full string definition for message of type '<SaveClassifier-response>"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SaveClassifier-response)))
  "Returns full string definition for message of type 'SaveClassifier-response"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SaveClassifier-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SaveClassifier-response>))
  "Converts a ROS message object to a list"
  (cl:list 'SaveClassifier-response
    (cl:cons ':success (success msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'SaveClassifier)))
  'SaveClassifier-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'SaveClassifier)))
  'SaveClassifier-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SaveClassifier)))
  "Returns string type for a service object of type '<SaveClassifier>"
  "ml_classifiers/SaveClassifier")