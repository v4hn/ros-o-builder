; Auto-generated. Do not edit!


(cl:in-package ml_classifiers-srv)


;//! \htmlinclude TrainClassifier-request.msg.html

(cl:defclass <TrainClassifier-request> (roslisp-msg-protocol:ros-message)
  ((identifier
    :reader identifier
    :initarg :identifier
    :type cl:string
    :initform ""))
)

(cl:defclass TrainClassifier-request (<TrainClassifier-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TrainClassifier-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TrainClassifier-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<TrainClassifier-request> is deprecated: use ml_classifiers-srv:TrainClassifier-request instead.")))

(cl:ensure-generic-function 'identifier-val :lambda-list '(m))
(cl:defmethod identifier-val ((m <TrainClassifier-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:identifier-val is deprecated.  Use ml_classifiers-srv:identifier instead.")
  (identifier m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TrainClassifier-request>) ostream)
  "Serializes a message object of type '<TrainClassifier-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'identifier))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'identifier))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TrainClassifier-request>) istream)
  "Deserializes a message object of type '<TrainClassifier-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'identifier) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'identifier) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TrainClassifier-request>)))
  "Returns string type for a service object of type '<TrainClassifier-request>"
  "ml_classifiers/TrainClassifierRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TrainClassifier-request)))
  "Returns string type for a service object of type 'TrainClassifier-request"
  "ml_classifiers/TrainClassifierRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TrainClassifier-request>)))
  "Returns md5sum for a message object of type '<TrainClassifier-request>"
  "126e80d7c8d36adbb3fd063504a07c0d")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TrainClassifier-request)))
  "Returns md5sum for a message object of type 'TrainClassifier-request"
  "126e80d7c8d36adbb3fd063504a07c0d")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TrainClassifier-request>)))
  "Returns full string definition for message of type '<TrainClassifier-request>"
  (cl:format cl:nil "string identifier~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TrainClassifier-request)))
  "Returns full string definition for message of type 'TrainClassifier-request"
  (cl:format cl:nil "string identifier~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TrainClassifier-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'identifier))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TrainClassifier-request>))
  "Converts a ROS message object to a list"
  (cl:list 'TrainClassifier-request
    (cl:cons ':identifier (identifier msg))
))
;//! \htmlinclude TrainClassifier-response.msg.html

(cl:defclass <TrainClassifier-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass TrainClassifier-response (<TrainClassifier-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TrainClassifier-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TrainClassifier-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<TrainClassifier-response> is deprecated: use ml_classifiers-srv:TrainClassifier-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <TrainClassifier-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:success-val is deprecated.  Use ml_classifiers-srv:success instead.")
  (success m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TrainClassifier-response>) ostream)
  "Serializes a message object of type '<TrainClassifier-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TrainClassifier-response>) istream)
  "Deserializes a message object of type '<TrainClassifier-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TrainClassifier-response>)))
  "Returns string type for a service object of type '<TrainClassifier-response>"
  "ml_classifiers/TrainClassifierResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TrainClassifier-response)))
  "Returns string type for a service object of type 'TrainClassifier-response"
  "ml_classifiers/TrainClassifierResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TrainClassifier-response>)))
  "Returns md5sum for a message object of type '<TrainClassifier-response>"
  "126e80d7c8d36adbb3fd063504a07c0d")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TrainClassifier-response)))
  "Returns md5sum for a message object of type 'TrainClassifier-response"
  "126e80d7c8d36adbb3fd063504a07c0d")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TrainClassifier-response>)))
  "Returns full string definition for message of type '<TrainClassifier-response>"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TrainClassifier-response)))
  "Returns full string definition for message of type 'TrainClassifier-response"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TrainClassifier-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TrainClassifier-response>))
  "Converts a ROS message object to a list"
  (cl:list 'TrainClassifier-response
    (cl:cons ':success (success msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'TrainClassifier)))
  'TrainClassifier-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'TrainClassifier)))
  'TrainClassifier-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TrainClassifier)))
  "Returns string type for a service object of type '<TrainClassifier>"
  "ml_classifiers/TrainClassifier")