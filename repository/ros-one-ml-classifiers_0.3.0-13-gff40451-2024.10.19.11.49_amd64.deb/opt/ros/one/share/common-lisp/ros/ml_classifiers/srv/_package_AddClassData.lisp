(cl:in-package ml_classifiers-srv)
(cl:export '(IDENTIFIER-VAL
          IDENTIFIER
          DATA-VAL
          DATA
          SUCCESS-VAL
          SUCCESS
))