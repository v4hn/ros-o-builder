
(cl:in-package :asdf)

(defsystem "ml_classifiers-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "ClassDataPoint" :depends-on ("_package_ClassDataPoint"))
    (:file "_package_ClassDataPoint" :depends-on ("_package"))
  ))