; Auto-generated. Do not edit!


(cl:in-package ml_classifiers-srv)


;//! \htmlinclude AddClassData-request.msg.html

(cl:defclass <AddClassData-request> (roslisp-msg-protocol:ros-message)
  ((identifier
    :reader identifier
    :initarg :identifier
    :type cl:string
    :initform "")
   (data
    :reader data
    :initarg :data
    :type (cl:vector ml_classifiers-msg:ClassDataPoint)
   :initform (cl:make-array 0 :element-type 'ml_classifiers-msg:ClassDataPoint :initial-element (cl:make-instance 'ml_classifiers-msg:ClassDataPoint))))
)

(cl:defclass AddClassData-request (<AddClassData-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AddClassData-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AddClassData-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<AddClassData-request> is deprecated: use ml_classifiers-srv:AddClassData-request instead.")))

(cl:ensure-generic-function 'identifier-val :lambda-list '(m))
(cl:defmethod identifier-val ((m <AddClassData-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:identifier-val is deprecated.  Use ml_classifiers-srv:identifier instead.")
  (identifier m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <AddClassData-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:data-val is deprecated.  Use ml_classifiers-srv:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AddClassData-request>) ostream)
  "Serializes a message object of type '<AddClassData-request>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'identifier))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'identifier))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AddClassData-request>) istream)
  "Deserializes a message object of type '<AddClassData-request>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'identifier) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'identifier) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'ml_classifiers-msg:ClassDataPoint))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AddClassData-request>)))
  "Returns string type for a service object of type '<AddClassData-request>"
  "ml_classifiers/AddClassDataRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AddClassData-request)))
  "Returns string type for a service object of type 'AddClassData-request"
  "ml_classifiers/AddClassDataRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AddClassData-request>)))
  "Returns md5sum for a message object of type '<AddClassData-request>"
  "d4c3cb23d4d2e3dec5588818fec39e8c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AddClassData-request)))
  "Returns md5sum for a message object of type 'AddClassData-request"
  "d4c3cb23d4d2e3dec5588818fec39e8c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AddClassData-request>)))
  "Returns full string definition for message of type '<AddClassData-request>"
  (cl:format cl:nil "string identifier~%ClassDataPoint[] data~%~%================================================================================~%MSG: ml_classifiers/ClassDataPoint~%string target_class~%float64[] point~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AddClassData-request)))
  "Returns full string definition for message of type 'AddClassData-request"
  (cl:format cl:nil "string identifier~%ClassDataPoint[] data~%~%================================================================================~%MSG: ml_classifiers/ClassDataPoint~%string target_class~%float64[] point~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AddClassData-request>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'identifier))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AddClassData-request>))
  "Converts a ROS message object to a list"
  (cl:list 'AddClassData-request
    (cl:cons ':identifier (identifier msg))
    (cl:cons ':data (data msg))
))
;//! \htmlinclude AddClassData-response.msg.html

(cl:defclass <AddClassData-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass AddClassData-response (<AddClassData-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <AddClassData-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'AddClassData-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name ml_classifiers-srv:<AddClassData-response> is deprecated: use ml_classifiers-srv:AddClassData-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <AddClassData-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader ml_classifiers-srv:success-val is deprecated.  Use ml_classifiers-srv:success instead.")
  (success m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <AddClassData-response>) ostream)
  "Serializes a message object of type '<AddClassData-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'success) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <AddClassData-response>) istream)
  "Deserializes a message object of type '<AddClassData-response>"
    (cl:setf (cl:slot-value msg 'success) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<AddClassData-response>)))
  "Returns string type for a service object of type '<AddClassData-response>"
  "ml_classifiers/AddClassDataResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AddClassData-response)))
  "Returns string type for a service object of type 'AddClassData-response"
  "ml_classifiers/AddClassDataResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<AddClassData-response>)))
  "Returns md5sum for a message object of type '<AddClassData-response>"
  "d4c3cb23d4d2e3dec5588818fec39e8c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'AddClassData-response)))
  "Returns md5sum for a message object of type 'AddClassData-response"
  "d4c3cb23d4d2e3dec5588818fec39e8c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<AddClassData-response>)))
  "Returns full string definition for message of type '<AddClassData-response>"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'AddClassData-response)))
  "Returns full string definition for message of type 'AddClassData-response"
  (cl:format cl:nil "bool success~%~%~%~%~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <AddClassData-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <AddClassData-response>))
  "Converts a ROS message object to a list"
  (cl:list 'AddClassData-response
    (cl:cons ':success (success msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'AddClassData)))
  'AddClassData-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'AddClassData)))
  'AddClassData-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'AddClassData)))
  "Returns string type for a service object of type '<AddClassData>"
  "ml_classifiers/AddClassData")