#!/usr/bin/env bash

if [ "TRUE" = "TRUE" ]; then
	exec /opt/ros/one/share/nfc_ros/venv/bin/python - "$@" <<- EOF
	import re
	import sys

	from setproctitle import setproctitle

	program_path = "/opt/ros/one/share/nfc_ros/catkin_virtualenv_scripts/nfc_ros_node.py"
	setproctitle(' '.join([program_path] + sys.argv[1:]))
	exec(open(program_path).read())
	EOF
else
	exec /opt/ros/one/share/nfc_ros/venv/bin/python /opt/ros/one/share/nfc_ros/catkin_virtualenv_scripts/nfc_ros_node.py "$@"
fi
