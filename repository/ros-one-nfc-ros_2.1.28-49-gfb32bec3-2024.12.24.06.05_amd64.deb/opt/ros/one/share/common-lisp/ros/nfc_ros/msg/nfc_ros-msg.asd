
(cl:in-package :asdf)

(defsystem "nfc_ros-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "NDEFRecord" :depends-on ("_package_NDEFRecord"))
    (:file "_package_NDEFRecord" :depends-on ("_package"))
    (:file "Tag" :depends-on ("_package_Tag"))
    (:file "_package_Tag" :depends-on ("_package"))
  ))