; Auto-generated. Do not edit!


(cl:in-package nfc_ros-msg)


;//! \htmlinclude Tag.msg.html

(cl:defclass <Tag> (roslisp-msg-protocol:ros-message)
  ((tag_type
    :reader tag_type
    :initarg :tag_type
    :type cl:fixnum
    :initform 0)
   (ndef_records
    :reader ndef_records
    :initarg :ndef_records
    :type (cl:vector nfc_ros-msg:NDEFRecord)
   :initform (cl:make-array 0 :element-type 'nfc_ros-msg:NDEFRecord :initial-element (cl:make-instance 'nfc_ros-msg:NDEFRecord)))
   (identifier
    :reader identifier
    :initarg :identifier
    :type cl:string
    :initform ""))
)

(cl:defclass Tag (<Tag>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Tag>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Tag)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nfc_ros-msg:<Tag> is deprecated: use nfc_ros-msg:Tag instead.")))

(cl:ensure-generic-function 'tag_type-val :lambda-list '(m))
(cl:defmethod tag_type-val ((m <Tag>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nfc_ros-msg:tag_type-val is deprecated.  Use nfc_ros-msg:tag_type instead.")
  (tag_type m))

(cl:ensure-generic-function 'ndef_records-val :lambda-list '(m))
(cl:defmethod ndef_records-val ((m <Tag>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nfc_ros-msg:ndef_records-val is deprecated.  Use nfc_ros-msg:ndef_records instead.")
  (ndef_records m))

(cl:ensure-generic-function 'identifier-val :lambda-list '(m))
(cl:defmethod identifier-val ((m <Tag>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nfc_ros-msg:identifier-val is deprecated.  Use nfc_ros-msg:identifier instead.")
  (identifier m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<Tag>)))
    "Constants for message type '<Tag>"
  '((:NFC_TAG_TYPE1TAG . 100)
    (:NFC_TAG_TYPE2TAG . 200)
    (:NFC_TAG_TYPE2NXPMIFAREULTRALIGHT . 201)
    (:NFC_TAG_TYPE2NXPMIFAREULTRALIGHTC . 202)
    (:NFC_TAG_TYPE2NXPNTAG210 . 203)
    (:NFC_TAG_TYPE2NXPNTAG212 . 204)
    (:NFC_TAG_TYPE2NXPNTAG215 . 205)
    (:NFC_TAG_TYPE2NXPNTAG216 . 206)
    (:NFC_TAG_TYPE2NXPMIFAREULTRALIGHTEV1 . 207)
    (:NFC_TAG_TYPE3TAG . 300)
    (:NFC_TAG_FELICASTANDARD . 301)
    (:NFC_TAG_FELICAMOBILE . 302)
    (:NFC_TAG_FELICALITE . 303)
    (:NFC_TAG_FELICALITES . 304)
    (:NFC_TAG_FELICAPLUG . 305)
    (:NFC_TAG_TYPE4TAG . 400)
    (:NFC_TAG_TYPE4ATAG . 401)
    (:NFC_TAG_TYPE4BTAG . 402))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'Tag)))
    "Constants for message type 'Tag"
  '((:NFC_TAG_TYPE1TAG . 100)
    (:NFC_TAG_TYPE2TAG . 200)
    (:NFC_TAG_TYPE2NXPMIFAREULTRALIGHT . 201)
    (:NFC_TAG_TYPE2NXPMIFAREULTRALIGHTC . 202)
    (:NFC_TAG_TYPE2NXPNTAG210 . 203)
    (:NFC_TAG_TYPE2NXPNTAG212 . 204)
    (:NFC_TAG_TYPE2NXPNTAG215 . 205)
    (:NFC_TAG_TYPE2NXPNTAG216 . 206)
    (:NFC_TAG_TYPE2NXPMIFAREULTRALIGHTEV1 . 207)
    (:NFC_TAG_TYPE3TAG . 300)
    (:NFC_TAG_FELICASTANDARD . 301)
    (:NFC_TAG_FELICAMOBILE . 302)
    (:NFC_TAG_FELICALITE . 303)
    (:NFC_TAG_FELICALITES . 304)
    (:NFC_TAG_FELICAPLUG . 305)
    (:NFC_TAG_TYPE4TAG . 400)
    (:NFC_TAG_TYPE4ATAG . 401)
    (:NFC_TAG_TYPE4BTAG . 402))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Tag>) ostream)
  "Serializes a message object of type '<Tag>"
  (cl:let* ((signed (cl:slot-value msg 'tag_type)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 65536) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) unsigned) ostream)
    )
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'ndef_records))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'ndef_records))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'identifier))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'identifier))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Tag>) istream)
  "Deserializes a message object of type '<Tag>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'tag_type) (cl:if (cl:< unsigned 32768) unsigned (cl:- unsigned 65536))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'ndef_records) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'ndef_records)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'nfc_ros-msg:NDEFRecord))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'identifier) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'identifier) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Tag>)))
  "Returns string type for a message object of type '<Tag>"
  "nfc_ros/Tag")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Tag)))
  "Returns string type for a message object of type 'Tag"
  "nfc_ros/Tag")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Tag>)))
  "Returns md5sum for a message object of type '<Tag>"
  "36322935513001cbca4f6ccdd60cbada")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Tag)))
  "Returns md5sum for a message object of type 'Tag"
  "36322935513001cbca4f6ccdd60cbada")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Tag>)))
  "Returns full string definition for message of type '<Tag>"
  (cl:format cl:nil "int16 NFC_TAG_TYPE1TAG=100~%~%# Type2 Tags~%int16 NFC_TAG_TYPE2TAG=200~%int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHT=201~%int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHTC=202~%int16 NFC_TAG_TYPE2NXPNTAG210=203~%int16 NFC_TAG_TYPE2NXPNTAG212=204~%int16 NFC_TAG_TYPE2NXPNTAG215=205~%int16 NFC_TAG_TYPE2NXPNTAG216=206~%int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHTEV1=207~%~%# Type3 Tags~%int16 NFC_TAG_TYPE3TAG=300~%int16 NFC_TAG_FelicaStandard=301~%int16 NFC_TAG_FelicaMobile=302~%int16 NFC_TAG_FelicaLite=303~%int16 NFC_TAG_FelicaLiteS=304~%int16 NFC_TAG_FelicaPlug=305~%~%# Type4 Tags~%int16 NFC_TAG_TYPE4TAG=400~%int16 NFC_TAG_TYPE4ATAG=401~%int16 NFC_TAG_TYPE4BTAG=402~%~%int16 tag_type~%NDEFRecord[] ndef_records~%string identifier~%~%================================================================================~%MSG: nfc_ros/NDEFRecord~%string type~%string name~%string data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Tag)))
  "Returns full string definition for message of type 'Tag"
  (cl:format cl:nil "int16 NFC_TAG_TYPE1TAG=100~%~%# Type2 Tags~%int16 NFC_TAG_TYPE2TAG=200~%int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHT=201~%int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHTC=202~%int16 NFC_TAG_TYPE2NXPNTAG210=203~%int16 NFC_TAG_TYPE2NXPNTAG212=204~%int16 NFC_TAG_TYPE2NXPNTAG215=205~%int16 NFC_TAG_TYPE2NXPNTAG216=206~%int16 NFC_TAG_TYPE2NXPMIFAREULTRALIGHTEV1=207~%~%# Type3 Tags~%int16 NFC_TAG_TYPE3TAG=300~%int16 NFC_TAG_FelicaStandard=301~%int16 NFC_TAG_FelicaMobile=302~%int16 NFC_TAG_FelicaLite=303~%int16 NFC_TAG_FelicaLiteS=304~%int16 NFC_TAG_FelicaPlug=305~%~%# Type4 Tags~%int16 NFC_TAG_TYPE4TAG=400~%int16 NFC_TAG_TYPE4ATAG=401~%int16 NFC_TAG_TYPE4BTAG=402~%~%int16 tag_type~%NDEFRecord[] ndef_records~%string identifier~%~%================================================================================~%MSG: nfc_ros/NDEFRecord~%string type~%string name~%string data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Tag>))
  (cl:+ 0
     2
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'ndef_records) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:length (cl:slot-value msg 'identifier))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Tag>))
  "Converts a ROS message object to a list"
  (cl:list 'Tag
    (cl:cons ':tag_type (tag_type msg))
    (cl:cons ':ndef_records (ndef_records msg))
    (cl:cons ':identifier (identifier msg))
))
