(cl:defpackage nfc_ros-msg
  (:use )
  (:export
   "<NDEFRECORD>"
   "NDEFRECORD"
   "<TAG>"
   "TAG"
  ))

