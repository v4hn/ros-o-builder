; Auto-generated. Do not edit!


(cl:in-package nfc_ros-msg)


;//! \htmlinclude NDEFRecord.msg.html

(cl:defclass <NDEFRecord> (roslisp-msg-protocol:ros-message)
  ((type
    :reader type
    :initarg :type
    :type cl:string
    :initform "")
   (name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (data
    :reader data
    :initarg :data
    :type cl:string
    :initform ""))
)

(cl:defclass NDEFRecord (<NDEFRecord>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <NDEFRecord>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'NDEFRecord)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name nfc_ros-msg:<NDEFRecord> is deprecated: use nfc_ros-msg:NDEFRecord instead.")))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <NDEFRecord>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nfc_ros-msg:type-val is deprecated.  Use nfc_ros-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <NDEFRecord>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nfc_ros-msg:name-val is deprecated.  Use nfc_ros-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <NDEFRecord>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader nfc_ros-msg:data-val is deprecated.  Use nfc_ros-msg:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <NDEFRecord>) ostream)
  "Serializes a message object of type '<NDEFRecord>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'type))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <NDEFRecord>) istream)
  "Deserializes a message object of type '<NDEFRecord>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'data) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'data) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<NDEFRecord>)))
  "Returns string type for a message object of type '<NDEFRecord>"
  "nfc_ros/NDEFRecord")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'NDEFRecord)))
  "Returns string type for a message object of type 'NDEFRecord"
  "nfc_ros/NDEFRecord")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<NDEFRecord>)))
  "Returns md5sum for a message object of type '<NDEFRecord>"
  "8f3a679a1066a646142407d5f4a01d95")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'NDEFRecord)))
  "Returns md5sum for a message object of type 'NDEFRecord"
  "8f3a679a1066a646142407d5f4a01d95")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<NDEFRecord>)))
  "Returns full string definition for message of type '<NDEFRecord>"
  (cl:format cl:nil "string type~%string name~%string data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'NDEFRecord)))
  "Returns full string definition for message of type 'NDEFRecord"
  (cl:format cl:nil "string type~%string name~%string data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <NDEFRecord>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'type))
     4 (cl:length (cl:slot-value msg 'name))
     4 (cl:length (cl:slot-value msg 'data))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <NDEFRecord>))
  "Converts a ROS message object to a list"
  (cl:list 'NDEFRecord
    (cl:cons ':type (type msg))
    (cl:cons ':name (name msg))
    (cl:cons ':data (data msg))
))
