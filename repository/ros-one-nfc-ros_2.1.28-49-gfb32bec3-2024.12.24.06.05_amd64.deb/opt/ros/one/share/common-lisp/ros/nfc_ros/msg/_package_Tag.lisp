(cl:in-package nfc_ros-msg)
(cl:export '(TAG_TYPE-VAL
          TAG_TYPE
          NDEF_RECORDS-VAL
          NDEF_RECORDS
          IDENTIFIER-VAL
          IDENTIFIER
))