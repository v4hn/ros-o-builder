
"use strict";

let DataPoint = require('./DataPoint.js');
let StatisticsValues = require('./StatisticsValues.js');
let DataPoints = require('./DataPoints.js');
let StatisticsNames = require('./StatisticsNames.js');
let Dictionary = require('./Dictionary.js');

module.exports = {
  DataPoint: DataPoint,
  StatisticsValues: StatisticsValues,
  DataPoints: DataPoints,
  StatisticsNames: StatisticsNames,
  Dictionary: Dictionary,
};
