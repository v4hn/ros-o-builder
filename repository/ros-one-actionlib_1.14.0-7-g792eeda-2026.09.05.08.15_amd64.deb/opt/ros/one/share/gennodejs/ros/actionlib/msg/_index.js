
"use strict";

let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestResult = require('./TestResult.js');
let TestActionGoal = require('./TestActionGoal.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestAction = require('./TestAction.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestFeedback = require('./TestFeedback.js');
let TestActionResult = require('./TestActionResult.js');
let TestGoal = require('./TestGoal.js');
let TestRequestAction = require('./TestRequestAction.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TwoIntsResult = require('./TwoIntsResult.js');

module.exports = {
  TwoIntsGoal: TwoIntsGoal,
  TestResult: TestResult,
  TestActionGoal: TestActionGoal,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestRequestFeedback: TestRequestFeedback,
  TestRequestGoal: TestRequestGoal,
  TestRequestActionResult: TestRequestActionResult,
  TestAction: TestAction,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestResult: TestRequestResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TestFeedback: TestFeedback,
  TestActionResult: TestActionResult,
  TestGoal: TestGoal,
  TestRequestAction: TestRequestAction,
  TwoIntsAction: TwoIntsAction,
  TwoIntsFeedback: TwoIntsFeedback,
  TestActionFeedback: TestActionFeedback,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestRequestActionGoal: TestRequestActionGoal,
  TwoIntsResult: TwoIntsResult,
};
