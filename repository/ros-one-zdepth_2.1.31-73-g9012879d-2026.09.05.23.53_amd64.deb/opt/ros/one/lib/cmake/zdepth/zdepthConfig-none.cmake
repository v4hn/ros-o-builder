#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "zdepth::zstd" for configuration "None"
set_property(TARGET zdepth::zstd APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(zdepth::zstd PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/libzstd.so"
  IMPORTED_SONAME_NONE "libzstd.so"
  )

list(APPEND _cmake_import_check_targets zdepth::zstd )
list(APPEND _cmake_import_check_files_for_zdepth::zstd "${_IMPORT_PREFIX}/lib/libzstd.so" )

# Import target "zdepth::zdepth" for configuration "None"
set_property(TARGET zdepth::zdepth APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(zdepth::zdepth PROPERTIES
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/libzdepth.so"
  IMPORTED_SONAME_NONE "libzdepth.so"
  )

list(APPEND _cmake_import_check_targets zdepth::zdepth )
list(APPEND _cmake_import_check_files_for_zdepth::zdepth "${_IMPORT_PREFIX}/lib/libzdepth.so" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
