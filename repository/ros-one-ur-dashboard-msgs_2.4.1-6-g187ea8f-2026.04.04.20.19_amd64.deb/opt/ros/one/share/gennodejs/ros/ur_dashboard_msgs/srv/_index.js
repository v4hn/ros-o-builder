
"use strict";

let IsProgramRunning = require('./IsProgramRunning.js')
let IsInRemoteControl = require('./IsInRemoteControl.js')
let GetProgramState = require('./GetProgramState.js')
let RawRequest = require('./RawRequest.js')
let Popup = require('./Popup.js')
let Load = require('./Load.js')
let AddToLog = require('./AddToLog.js')
let GetSafetyMode = require('./GetSafetyMode.js')
let GetRobotMode = require('./GetRobotMode.js')
let IsProgramSaved = require('./IsProgramSaved.js')
let GetLoadedProgram = require('./GetLoadedProgram.js')

module.exports = {
  IsProgramRunning: IsProgramRunning,
  IsInRemoteControl: IsInRemoteControl,
  GetProgramState: GetProgramState,
  RawRequest: RawRequest,
  Popup: Popup,
  Load: Load,
  AddToLog: AddToLog,
  GetSafetyMode: GetSafetyMode,
  GetRobotMode: GetRobotMode,
  IsProgramSaved: IsProgramSaved,
  GetLoadedProgram: GetLoadedProgram,
};
