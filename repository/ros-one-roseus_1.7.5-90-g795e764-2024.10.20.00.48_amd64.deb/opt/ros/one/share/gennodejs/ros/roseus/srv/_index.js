
"use strict";

let AddTwoInts = require('./AddTwoInts.js')
let StringString = require('./StringString.js')

module.exports = {
  AddTwoInts: AddTwoInts,
  StringString: StringString,
};
