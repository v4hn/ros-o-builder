
(cl:in-package :asdf)

(defsystem "roseus-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "FixedArray" :depends-on ("_package_FixedArray"))
    (:file "_package_FixedArray" :depends-on ("_package"))
    (:file "String" :depends-on ("_package_String"))
    (:file "_package_String" :depends-on ("_package"))
    (:file "StringStamped" :depends-on ("_package_StringStamped"))
    (:file "_package_StringStamped" :depends-on ("_package"))
    (:file "TestName" :depends-on ("_package_TestName"))
    (:file "_package_TestName" :depends-on ("_package"))
    (:file "VariableArray" :depends-on ("_package_VariableArray"))
    (:file "_package_VariableArray" :depends-on ("_package"))
  ))