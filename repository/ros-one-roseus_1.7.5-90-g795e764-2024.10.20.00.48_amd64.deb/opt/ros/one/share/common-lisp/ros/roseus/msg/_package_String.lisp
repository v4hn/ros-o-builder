(cl:in-package roseus-msg)
(cl:export '(DATA-VAL
          DATA
))