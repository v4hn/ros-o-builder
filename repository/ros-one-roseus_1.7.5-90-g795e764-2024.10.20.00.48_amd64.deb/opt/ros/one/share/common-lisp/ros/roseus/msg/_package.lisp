(cl:defpackage roseus-msg
  (:use )
  (:export
   "<FIXEDARRAY>"
   "FIXEDARRAY"
   "<STRING>"
   "STRING"
   "<STRINGSTAMPED>"
   "STRINGSTAMPED"
   "<TESTNAME>"
   "TESTNAME"
   "<VARIABLEARRAY>"
   "VARIABLEARRAY"
  ))

