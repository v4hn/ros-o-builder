(cl:in-package roseus-srv)
(cl:export '(A-VAL
          A
          B-VAL
          B
          SUM-VAL
          SUM
))