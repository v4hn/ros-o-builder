
"use strict";

let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TestAction = require('./TestAction.js');
let TestResult = require('./TestResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TestFeedback = require('./TestFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestActionResult = require('./TestActionResult.js');
let TestGoal = require('./TestGoal.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestAction = require('./TestRequestAction.js');

module.exports = {
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestActionFeedback: TestActionFeedback,
  TestAction: TestAction,
  TestResult: TestResult,
  TwoIntsGoal: TwoIntsGoal,
  TestFeedback: TestFeedback,
  TestActionGoal: TestActionGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsResult: TwoIntsResult,
  TwoIntsAction: TwoIntsAction,
  TestRequestFeedback: TestRequestFeedback,
  TestRequestActionResult: TestRequestActionResult,
  TestActionResult: TestActionResult,
  TestGoal: TestGoal,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestRequestActionGoal: TestRequestActionGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestRequestGoal: TestRequestGoal,
  TestRequestResult: TestRequestResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestAction: TestRequestAction,
};
