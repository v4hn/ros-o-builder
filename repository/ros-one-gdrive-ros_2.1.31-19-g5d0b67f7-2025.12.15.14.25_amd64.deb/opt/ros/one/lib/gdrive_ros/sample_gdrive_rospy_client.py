#!/usr/bin/env bash

if [ "TRUE" = "TRUE" ]; then
	exec /opt/ros/one/share/gdrive_ros/venv/bin/python /dev/fd/3 "$@" 3<<- EOF
	import re
	import sys

	from setproctitle import setproctitle

	program_path = "/opt/ros/one/share/gdrive_ros/catkin_virtualenv_scripts/sample_gdrive_rospy_client.py"
	setproctitle(' '.join([program_path] + sys.argv[1:]))
	exec(open(program_path).read())
	EOF
else
	exec /opt/ros/one/share/gdrive_ros/venv/bin/python /opt/ros/one/share/gdrive_ros/catkin_virtualenv_scripts/sample_gdrive_rospy_client.py "$@"
fi
