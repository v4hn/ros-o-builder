set(gdrive_ros_MESSAGE_FILES "")
set(gdrive_ros_SERVICE_FILES "srv/Upload.srv;srv/MultipleUpload.srv")
