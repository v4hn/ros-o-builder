# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${gdrive_ros_DIR}/.." "" gdrive_ros_MSG_INCLUDE_DIRS UNIQUE)
set(gdrive_ros_MSG_DEPENDENCIES )
