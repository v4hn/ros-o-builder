// Auto-generated. Do not edit!

// (in-package gdrive_ros.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class UploadRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.file_path = null;
      this.file_title = null;
      this.parents_path = null;
      this.parents_id = null;
      this.use_timestamp_folder = null;
      this.use_timestamp_file_title = null;
    }
    else {
      if (initObj.hasOwnProperty('file_path')) {
        this.file_path = initObj.file_path
      }
      else {
        this.file_path = '';
      }
      if (initObj.hasOwnProperty('file_title')) {
        this.file_title = initObj.file_title
      }
      else {
        this.file_title = '';
      }
      if (initObj.hasOwnProperty('parents_path')) {
        this.parents_path = initObj.parents_path
      }
      else {
        this.parents_path = '';
      }
      if (initObj.hasOwnProperty('parents_id')) {
        this.parents_id = initObj.parents_id
      }
      else {
        this.parents_id = '';
      }
      if (initObj.hasOwnProperty('use_timestamp_folder')) {
        this.use_timestamp_folder = initObj.use_timestamp_folder
      }
      else {
        this.use_timestamp_folder = false;
      }
      if (initObj.hasOwnProperty('use_timestamp_file_title')) {
        this.use_timestamp_file_title = initObj.use_timestamp_file_title
      }
      else {
        this.use_timestamp_file_title = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UploadRequest
    // Serialize message field [file_path]
    bufferOffset = _serializer.string(obj.file_path, buffer, bufferOffset);
    // Serialize message field [file_title]
    bufferOffset = _serializer.string(obj.file_title, buffer, bufferOffset);
    // Serialize message field [parents_path]
    bufferOffset = _serializer.string(obj.parents_path, buffer, bufferOffset);
    // Serialize message field [parents_id]
    bufferOffset = _serializer.string(obj.parents_id, buffer, bufferOffset);
    // Serialize message field [use_timestamp_folder]
    bufferOffset = _serializer.bool(obj.use_timestamp_folder, buffer, bufferOffset);
    // Serialize message field [use_timestamp_file_title]
    bufferOffset = _serializer.bool(obj.use_timestamp_file_title, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UploadRequest
    let len;
    let data = new UploadRequest(null);
    // Deserialize message field [file_path]
    data.file_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [file_title]
    data.file_title = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents_path]
    data.parents_path = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents_id]
    data.parents_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [use_timestamp_folder]
    data.use_timestamp_folder = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [use_timestamp_file_title]
    data.use_timestamp_file_title = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.file_path);
    length += _getByteLength(object.file_title);
    length += _getByteLength(object.parents_path);
    length += _getByteLength(object.parents_id);
    return length + 18;
  }

  static datatype() {
    // Returns string type for a service object
    return 'gdrive_ros/UploadRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a09a0dc73a941d3514dca63d7fc3cf3b';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string file_path
    string file_title
    string parents_path
    string parents_id
    bool use_timestamp_folder
    bool use_timestamp_file_title
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UploadRequest(null);
    if (msg.file_path !== undefined) {
      resolved.file_path = msg.file_path;
    }
    else {
      resolved.file_path = ''
    }

    if (msg.file_title !== undefined) {
      resolved.file_title = msg.file_title;
    }
    else {
      resolved.file_title = ''
    }

    if (msg.parents_path !== undefined) {
      resolved.parents_path = msg.parents_path;
    }
    else {
      resolved.parents_path = ''
    }

    if (msg.parents_id !== undefined) {
      resolved.parents_id = msg.parents_id;
    }
    else {
      resolved.parents_id = ''
    }

    if (msg.use_timestamp_folder !== undefined) {
      resolved.use_timestamp_folder = msg.use_timestamp_folder;
    }
    else {
      resolved.use_timestamp_folder = false
    }

    if (msg.use_timestamp_file_title !== undefined) {
      resolved.use_timestamp_file_title = msg.use_timestamp_file_title;
    }
    else {
      resolved.use_timestamp_file_title = false
    }

    return resolved;
    }
};

class UploadResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.file_id = null;
      this.file_url = null;
      this.parents_id = null;
      this.parents_url = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('file_id')) {
        this.file_id = initObj.file_id
      }
      else {
        this.file_id = '';
      }
      if (initObj.hasOwnProperty('file_url')) {
        this.file_url = initObj.file_url
      }
      else {
        this.file_url = '';
      }
      if (initObj.hasOwnProperty('parents_id')) {
        this.parents_id = initObj.parents_id
      }
      else {
        this.parents_id = '';
      }
      if (initObj.hasOwnProperty('parents_url')) {
        this.parents_url = initObj.parents_url
      }
      else {
        this.parents_url = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type UploadResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [file_id]
    bufferOffset = _serializer.string(obj.file_id, buffer, bufferOffset);
    // Serialize message field [file_url]
    bufferOffset = _serializer.string(obj.file_url, buffer, bufferOffset);
    // Serialize message field [parents_id]
    bufferOffset = _serializer.string(obj.parents_id, buffer, bufferOffset);
    // Serialize message field [parents_url]
    bufferOffset = _serializer.string(obj.parents_url, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type UploadResponse
    let len;
    let data = new UploadResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [file_id]
    data.file_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [file_url]
    data.file_url = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents_id]
    data.parents_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [parents_url]
    data.parents_url = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.file_id);
    length += _getByteLength(object.file_url);
    length += _getByteLength(object.parents_id);
    length += _getByteLength(object.parents_url);
    return length + 17;
  }

  static datatype() {
    // Returns string type for a service object
    return 'gdrive_ros/UploadResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8f896e15fe386deb4d613a31c64e0cf6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success
    string file_id
    string file_url
    string parents_id
    string parents_url
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new UploadResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.file_id !== undefined) {
      resolved.file_id = msg.file_id;
    }
    else {
      resolved.file_id = ''
    }

    if (msg.file_url !== undefined) {
      resolved.file_url = msg.file_url;
    }
    else {
      resolved.file_url = ''
    }

    if (msg.parents_id !== undefined) {
      resolved.parents_id = msg.parents_id;
    }
    else {
      resolved.parents_id = ''
    }

    if (msg.parents_url !== undefined) {
      resolved.parents_url = msg.parents_url;
    }
    else {
      resolved.parents_url = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: UploadRequest,
  Response: UploadResponse,
  md5sum() { return '27634bfec9309170d00ba7c592dae289'; },
  datatype() { return 'gdrive_ros/Upload'; }
};
