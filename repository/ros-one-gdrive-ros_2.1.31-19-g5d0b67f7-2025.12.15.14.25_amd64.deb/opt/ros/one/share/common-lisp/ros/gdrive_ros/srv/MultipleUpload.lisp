; Auto-generated. Do not edit!


(cl:in-package gdrive_ros-srv)


;//! \htmlinclude MultipleUpload-request.msg.html

(cl:defclass <MultipleUpload-request> (roslisp-msg-protocol:ros-message)
  ((file_paths
    :reader file_paths
    :initarg :file_paths
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (file_titles
    :reader file_titles
    :initarg :file_titles
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (parents_path
    :reader parents_path
    :initarg :parents_path
    :type cl:string
    :initform "")
   (parents_id
    :reader parents_id
    :initarg :parents_id
    :type cl:string
    :initform "")
   (use_timestamp_folder
    :reader use_timestamp_folder
    :initarg :use_timestamp_folder
    :type cl:boolean
    :initform cl:nil)
   (use_timestamp_file_title
    :reader use_timestamp_file_title
    :initarg :use_timestamp_file_title
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass MultipleUpload-request (<MultipleUpload-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <MultipleUpload-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'MultipleUpload-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name gdrive_ros-srv:<MultipleUpload-request> is deprecated: use gdrive_ros-srv:MultipleUpload-request instead.")))

(cl:ensure-generic-function 'file_paths-val :lambda-list '(m))
(cl:defmethod file_paths-val ((m <MultipleUpload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_paths-val is deprecated.  Use gdrive_ros-srv:file_paths instead.")
  (file_paths m))

(cl:ensure-generic-function 'file_titles-val :lambda-list '(m))
(cl:defmethod file_titles-val ((m <MultipleUpload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_titles-val is deprecated.  Use gdrive_ros-srv:file_titles instead.")
  (file_titles m))

(cl:ensure-generic-function 'parents_path-val :lambda-list '(m))
(cl:defmethod parents_path-val ((m <MultipleUpload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_path-val is deprecated.  Use gdrive_ros-srv:parents_path instead.")
  (parents_path m))

(cl:ensure-generic-function 'parents_id-val :lambda-list '(m))
(cl:defmethod parents_id-val ((m <MultipleUpload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_id-val is deprecated.  Use gdrive_ros-srv:parents_id instead.")
  (parents_id m))

(cl:ensure-generic-function 'use_timestamp_folder-val :lambda-list '(m))
(cl:defmethod use_timestamp_folder-val ((m <MultipleUpload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:use_timestamp_folder-val is deprecated.  Use gdrive_ros-srv:use_timestamp_folder instead.")
  (use_timestamp_folder m))

(cl:ensure-generic-function 'use_timestamp_file_title-val :lambda-list '(m))
(cl:defmethod use_timestamp_file_title-val ((m <MultipleUpload-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:use_timestamp_file_title-val is deprecated.  Use gdrive_ros-srv:use_timestamp_file_title instead.")
  (use_timestamp_file_title m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <MultipleUpload-request>) ostream)
  "Serializes a message object of type '<MultipleUpload-request>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'file_paths))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'file_paths))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'file_titles))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'file_titles))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_path))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_path))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_id))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'use_timestamp_folder) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'use_timestamp_file_title) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <MultipleUpload-request>) istream)
  "Deserializes a message object of type '<MultipleUpload-request>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'file_paths) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'file_paths)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'file_titles) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'file_titles)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_path) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_path) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'use_timestamp_folder) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'use_timestamp_file_title) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<MultipleUpload-request>)))
  "Returns string type for a service object of type '<MultipleUpload-request>"
  "gdrive_ros/MultipleUploadRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'MultipleUpload-request)))
  "Returns string type for a service object of type 'MultipleUpload-request"
  "gdrive_ros/MultipleUploadRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<MultipleUpload-request>)))
  "Returns md5sum for a message object of type '<MultipleUpload-request>"
  "6ce04b4ad1fd58ceadb6d132fb43ce42")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'MultipleUpload-request)))
  "Returns md5sum for a message object of type 'MultipleUpload-request"
  "6ce04b4ad1fd58ceadb6d132fb43ce42")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<MultipleUpload-request>)))
  "Returns full string definition for message of type '<MultipleUpload-request>"
  (cl:format cl:nil "string[] file_paths~%string[] file_titles~%string parents_path~%string parents_id~%bool use_timestamp_folder~%bool use_timestamp_file_title~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'MultipleUpload-request)))
  "Returns full string definition for message of type 'MultipleUpload-request"
  (cl:format cl:nil "string[] file_paths~%string[] file_titles~%string parents_path~%string parents_id~%bool use_timestamp_folder~%bool use_timestamp_file_title~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <MultipleUpload-request>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'file_paths) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'file_titles) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:length (cl:slot-value msg 'parents_path))
     4 (cl:length (cl:slot-value msg 'parents_id))
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <MultipleUpload-request>))
  "Converts a ROS message object to a list"
  (cl:list 'MultipleUpload-request
    (cl:cons ':file_paths (file_paths msg))
    (cl:cons ':file_titles (file_titles msg))
    (cl:cons ':parents_path (parents_path msg))
    (cl:cons ':parents_id (parents_id msg))
    (cl:cons ':use_timestamp_folder (use_timestamp_folder msg))
    (cl:cons ':use_timestamp_file_title (use_timestamp_file_title msg))
))
;//! \htmlinclude MultipleUpload-response.msg.html

(cl:defclass <MultipleUpload-response> (roslisp-msg-protocol:ros-message)
  ((successes
    :reader successes
    :initarg :successes
    :type (cl:vector cl:boolean)
   :initform (cl:make-array 0 :element-type 'cl:boolean :initial-element cl:nil))
   (file_ids
    :reader file_ids
    :initarg :file_ids
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (file_urls
    :reader file_urls
    :initarg :file_urls
    :type (cl:vector cl:string)
   :initform (cl:make-array 0 :element-type 'cl:string :initial-element ""))
   (parents_id
    :reader parents_id
    :initarg :parents_id
    :type cl:string
    :initform "")
   (parents_url
    :reader parents_url
    :initarg :parents_url
    :type cl:string
    :initform ""))
)

(cl:defclass MultipleUpload-response (<MultipleUpload-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <MultipleUpload-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'MultipleUpload-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name gdrive_ros-srv:<MultipleUpload-response> is deprecated: use gdrive_ros-srv:MultipleUpload-response instead.")))

(cl:ensure-generic-function 'successes-val :lambda-list '(m))
(cl:defmethod successes-val ((m <MultipleUpload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:successes-val is deprecated.  Use gdrive_ros-srv:successes instead.")
  (successes m))

(cl:ensure-generic-function 'file_ids-val :lambda-list '(m))
(cl:defmethod file_ids-val ((m <MultipleUpload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_ids-val is deprecated.  Use gdrive_ros-srv:file_ids instead.")
  (file_ids m))

(cl:ensure-generic-function 'file_urls-val :lambda-list '(m))
(cl:defmethod file_urls-val ((m <MultipleUpload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:file_urls-val is deprecated.  Use gdrive_ros-srv:file_urls instead.")
  (file_urls m))

(cl:ensure-generic-function 'parents_id-val :lambda-list '(m))
(cl:defmethod parents_id-val ((m <MultipleUpload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_id-val is deprecated.  Use gdrive_ros-srv:parents_id instead.")
  (parents_id m))

(cl:ensure-generic-function 'parents_url-val :lambda-list '(m))
(cl:defmethod parents_url-val ((m <MultipleUpload-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader gdrive_ros-srv:parents_url-val is deprecated.  Use gdrive_ros-srv:parents_url instead.")
  (parents_url m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <MultipleUpload-response>) ostream)
  "Serializes a message object of type '<MultipleUpload-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'successes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if ele 1 0)) ostream))
   (cl:slot-value msg 'successes))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'file_ids))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'file_ids))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'file_urls))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((__ros_str_len (cl:length ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) ele))
   (cl:slot-value msg 'file_urls))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_id))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'parents_url))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'parents_url))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <MultipleUpload-response>) istream)
  "Deserializes a message object of type '<MultipleUpload-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'successes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'successes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:not (cl:zerop (cl:read-byte istream)))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'file_ids) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'file_ids)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'file_urls) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'file_urls)))
    (cl:dotimes (i __ros_arr_len)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:aref vals i) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:aref vals i) __ros_str_idx) (cl:code-char (cl:read-byte istream))))))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'parents_url) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'parents_url) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<MultipleUpload-response>)))
  "Returns string type for a service object of type '<MultipleUpload-response>"
  "gdrive_ros/MultipleUploadResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'MultipleUpload-response)))
  "Returns string type for a service object of type 'MultipleUpload-response"
  "gdrive_ros/MultipleUploadResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<MultipleUpload-response>)))
  "Returns md5sum for a message object of type '<MultipleUpload-response>"
  "6ce04b4ad1fd58ceadb6d132fb43ce42")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'MultipleUpload-response)))
  "Returns md5sum for a message object of type 'MultipleUpload-response"
  "6ce04b4ad1fd58ceadb6d132fb43ce42")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<MultipleUpload-response>)))
  "Returns full string definition for message of type '<MultipleUpload-response>"
  (cl:format cl:nil "bool[] successes~%string[] file_ids~%string[] file_urls~%string parents_id~%string parents_url~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'MultipleUpload-response)))
  "Returns full string definition for message of type 'MultipleUpload-response"
  (cl:format cl:nil "bool[] successes~%string[] file_ids~%string[] file_urls~%string parents_id~%string parents_url~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <MultipleUpload-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'successes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'file_ids) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'file_urls) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4 (cl:length ele))))
     4 (cl:length (cl:slot-value msg 'parents_id))
     4 (cl:length (cl:slot-value msg 'parents_url))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <MultipleUpload-response>))
  "Converts a ROS message object to a list"
  (cl:list 'MultipleUpload-response
    (cl:cons ':successes (successes msg))
    (cl:cons ':file_ids (file_ids msg))
    (cl:cons ':file_urls (file_urls msg))
    (cl:cons ':parents_id (parents_id msg))
    (cl:cons ':parents_url (parents_url msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'MultipleUpload)))
  'MultipleUpload-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'MultipleUpload)))
  'MultipleUpload-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'MultipleUpload)))
  "Returns string type for a service object of type '<MultipleUpload>"
  "gdrive_ros/MultipleUpload")