(cl:in-package gdrive_ros-srv)
(cl:export '(FILE_PATH-VAL
          FILE_PATH
          FILE_TITLE-VAL
          FILE_TITLE
          PARENTS_PATH-VAL
          PARENTS_PATH
          PARENTS_ID-VAL
          PARENTS_ID
          USE_TIMESTAMP_FOLDER-VAL
          USE_TIMESTAMP_FOLDER
          USE_TIMESTAMP_FILE_TITLE-VAL
          USE_TIMESTAMP_FILE_TITLE
          SUCCESS-VAL
          SUCCESS
          FILE_ID-VAL
          FILE_ID
          FILE_URL-VAL
          FILE_URL
          PARENTS_ID-VAL
          PARENTS_ID
          PARENTS_URL-VAL
          PARENTS_URL
))