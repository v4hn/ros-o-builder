
"use strict";

let TestHeader = require('./TestHeader.js');
let TestTimeArray = require('./TestTimeArray.js');
let TestChar = require('./TestChar.js');
let TestUInt8 = require('./TestUInt8.js');
let TestDurationArray = require('./TestDurationArray.js');
let Num = require('./Num.js');
let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');
let TestHeaderTwo = require('./TestHeaderTwo.js');
let TestHeaderArray = require('./TestHeaderArray.js');

module.exports = {
  TestHeader: TestHeader,
  TestTimeArray: TestTimeArray,
  TestChar: TestChar,
  TestUInt8: TestUInt8,
  TestDurationArray: TestDurationArray,
  Num: Num,
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
  TestHeaderTwo: TestHeaderTwo,
  TestHeaderArray: TestHeaderArray,
};
