
"use strict";

let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let SendBytes = require('./SendBytes.js')
let AddTwoInts = require('./AddTwoInts.js')
let TestEmpty = require('./TestEmpty.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestNestedService = require('./TestNestedService.js')

module.exports = {
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestResponseOnly: TestResponseOnly,
  TestRequestOnly: TestRequestOnly,
  TestArrayRequest: TestArrayRequest,
  SendBytes: SendBytes,
  AddTwoInts: AddTwoInts,
  TestEmpty: TestEmpty,
  TestRequestAndResponse: TestRequestAndResponse,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestNestedService: TestNestedService,
};
