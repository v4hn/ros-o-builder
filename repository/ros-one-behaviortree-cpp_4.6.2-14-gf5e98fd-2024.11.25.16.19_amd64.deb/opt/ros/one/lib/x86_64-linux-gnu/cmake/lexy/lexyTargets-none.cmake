#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "foonathan::lexy::file" for configuration "None"
set_property(TARGET foonathan::lexy::file APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(foonathan::lexy::file PROPERTIES
  IMPORTED_LINK_INTERFACE_LANGUAGES_NONE "CXX"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liblexy_file.a"
  )

list(APPEND _cmake_import_check_targets foonathan::lexy::file )
list(APPEND _cmake_import_check_files_for_foonathan::lexy::file "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/liblexy_file.a" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
