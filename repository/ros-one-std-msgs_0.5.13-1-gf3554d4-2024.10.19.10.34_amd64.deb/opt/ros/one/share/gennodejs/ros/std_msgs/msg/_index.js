
"use strict";

let String = require('./String.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let UInt8 = require('./UInt8.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let UInt64 = require('./UInt64.js');
let UInt32 = require('./UInt32.js');
let Bool = require('./Bool.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let Int8 = require('./Int8.js');
let Float32 = require('./Float32.js');
let Char = require('./Char.js');
let Int64 = require('./Int64.js');
let Float64MultiArray = require('./Float64MultiArray.js');
let Duration = require('./Duration.js');
let Int16 = require('./Int16.js');
let Byte = require('./Byte.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Time = require('./Time.js');
let Header = require('./Header.js');
let Float64 = require('./Float64.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let Int32 = require('./Int32.js');
let ColorRGBA = require('./ColorRGBA.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let Empty = require('./Empty.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let UInt16 = require('./UInt16.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');

module.exports = {
  String: String,
  Int64MultiArray: Int64MultiArray,
  UInt8: UInt8,
  Int32MultiArray: Int32MultiArray,
  UInt64: UInt64,
  UInt32: UInt32,
  Bool: Bool,
  MultiArrayLayout: MultiArrayLayout,
  UInt32MultiArray: UInt32MultiArray,
  UInt8MultiArray: UInt8MultiArray,
  Int8: Int8,
  Float32: Float32,
  Char: Char,
  Int64: Int64,
  Float64MultiArray: Float64MultiArray,
  Duration: Duration,
  Int16: Int16,
  Byte: Byte,
  MultiArrayDimension: MultiArrayDimension,
  Time: Time,
  Header: Header,
  Float64: Float64,
  Float32MultiArray: Float32MultiArray,
  Int16MultiArray: Int16MultiArray,
  Int32: Int32,
  ColorRGBA: ColorRGBA,
  UInt16MultiArray: UInt16MultiArray,
  Empty: Empty,
  ByteMultiArray: ByteMultiArray,
  Int8MultiArray: Int8MultiArray,
  UInt16: UInt16,
  UInt64MultiArray: UInt64MultiArray,
};
