
"use strict";

let AveragingFeedback = require('./AveragingFeedback.js');
let FibonacciResult = require('./FibonacciResult.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let AveragingResult = require('./AveragingResult.js');
let AveragingAction = require('./AveragingAction.js');
let AveragingGoal = require('./AveragingGoal.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let FibonacciAction = require('./FibonacciAction.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');

module.exports = {
  AveragingFeedback: AveragingFeedback,
  FibonacciResult: FibonacciResult,
  AveragingActionResult: AveragingActionResult,
  AveragingActionFeedback: AveragingActionFeedback,
  AveragingResult: AveragingResult,
  AveragingAction: AveragingAction,
  AveragingGoal: AveragingGoal,
  FibonacciGoal: FibonacciGoal,
  FibonacciActionGoal: FibonacciActionGoal,
  FibonacciFeedback: FibonacciFeedback,
  FibonacciActionResult: FibonacciActionResult,
  FibonacciAction: FibonacciAction,
  FibonacciActionFeedback: FibonacciActionFeedback,
  AveragingActionGoal: AveragingActionGoal,
};
