
"use strict";

let MoveModel = require('./MoveModel.js')
let DeleteModel = require('./DeleteModel.js')
let SpawnModel = require('./SpawnModel.js')

module.exports = {
  MoveModel: MoveModel,
  DeleteModel: DeleteModel,
  SpawnModel: SpawnModel,
};
