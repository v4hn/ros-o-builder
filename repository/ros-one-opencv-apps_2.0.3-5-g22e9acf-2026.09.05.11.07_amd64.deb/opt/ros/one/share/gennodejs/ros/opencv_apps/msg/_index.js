
"use strict";

let Point2DStamped = require('./Point2DStamped.js');
let RotatedRectStamped = require('./RotatedRectStamped.js');
let FlowStamped = require('./FlowStamped.js');
let Contour = require('./Contour.js');
let Point2D = require('./Point2D.js');
let Flow = require('./Flow.js');
let FaceArrayStamped = require('./FaceArrayStamped.js');
let RotatedRect = require('./RotatedRect.js');
let Line = require('./Line.js');
let ContourArrayStamped = require('./ContourArrayStamped.js');
let CircleArray = require('./CircleArray.js');
let ContourArray = require('./ContourArray.js');
let FaceArray = require('./FaceArray.js');
let LineArray = require('./LineArray.js');
let Moment = require('./Moment.js');
let Face = require('./Face.js');
let Size = require('./Size.js');
let RotatedRectArrayStamped = require('./RotatedRectArrayStamped.js');
let CircleArrayStamped = require('./CircleArrayStamped.js');
let LineArrayStamped = require('./LineArrayStamped.js');
let FlowArray = require('./FlowArray.js');
let Rect = require('./Rect.js');
let FlowArrayStamped = require('./FlowArrayStamped.js');
let RectArray = require('./RectArray.js');
let RotatedRectArray = require('./RotatedRectArray.js');
let Circle = require('./Circle.js');
let Point2DArray = require('./Point2DArray.js');
let RectArrayStamped = require('./RectArrayStamped.js');
let Point2DArrayStamped = require('./Point2DArrayStamped.js');
let MomentArrayStamped = require('./MomentArrayStamped.js');
let MomentArray = require('./MomentArray.js');

module.exports = {
  Point2DStamped: Point2DStamped,
  RotatedRectStamped: RotatedRectStamped,
  FlowStamped: FlowStamped,
  Contour: Contour,
  Point2D: Point2D,
  Flow: Flow,
  FaceArrayStamped: FaceArrayStamped,
  RotatedRect: RotatedRect,
  Line: Line,
  ContourArrayStamped: ContourArrayStamped,
  CircleArray: CircleArray,
  ContourArray: ContourArray,
  FaceArray: FaceArray,
  LineArray: LineArray,
  Moment: Moment,
  Face: Face,
  Size: Size,
  RotatedRectArrayStamped: RotatedRectArrayStamped,
  CircleArrayStamped: CircleArrayStamped,
  LineArrayStamped: LineArrayStamped,
  FlowArray: FlowArray,
  Rect: Rect,
  FlowArrayStamped: FlowArrayStamped,
  RectArray: RectArray,
  RotatedRectArray: RotatedRectArray,
  Circle: Circle,
  Point2DArray: Point2DArray,
  RectArrayStamped: RectArrayStamped,
  Point2DArrayStamped: Point2DArrayStamped,
  MomentArrayStamped: MomentArrayStamped,
  MomentArray: MomentArray,
};
