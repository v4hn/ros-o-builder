(cl:in-package opencv_apps-msg)
(cl:export '(FLOW-VAL
          FLOW
          STATUS-VAL
          STATUS
))