; Auto-generated. Do not edit!


(cl:in-package pgm_learner-srv)


;//! \htmlinclude LinearGaussianParameterEstimation-request.msg.html

(cl:defclass <LinearGaussianParameterEstimation-request> (roslisp-msg-protocol:ros-message)
  ((graph
    :reader graph
    :initarg :graph
    :type pgm_learner-msg:GraphStructure
    :initform (cl:make-instance 'pgm_learner-msg:GraphStructure))
   (states
    :reader states
    :initarg :states
    :type (cl:vector pgm_learner-msg:LinearGaussianGraphState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:LinearGaussianGraphState :initial-element (cl:make-instance 'pgm_learner-msg:LinearGaussianGraphState))))
)

(cl:defclass LinearGaussianParameterEstimation-request (<LinearGaussianParameterEstimation-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinearGaussianParameterEstimation-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinearGaussianParameterEstimation-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<LinearGaussianParameterEstimation-request> is deprecated: use pgm_learner-srv:LinearGaussianParameterEstimation-request instead.")))

(cl:ensure-generic-function 'graph-val :lambda-list '(m))
(cl:defmethod graph-val ((m <LinearGaussianParameterEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:graph-val is deprecated.  Use pgm_learner-srv:graph instead.")
  (graph m))

(cl:ensure-generic-function 'states-val :lambda-list '(m))
(cl:defmethod states-val ((m <LinearGaussianParameterEstimation-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:states-val is deprecated.  Use pgm_learner-srv:states instead.")
  (states m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinearGaussianParameterEstimation-request>) ostream)
  "Serializes a message object of type '<LinearGaussianParameterEstimation-request>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'graph) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'states))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'states))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinearGaussianParameterEstimation-request>) istream)
  "Deserializes a message object of type '<LinearGaussianParameterEstimation-request>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'graph) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'states) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'states)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:LinearGaussianGraphState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinearGaussianParameterEstimation-request>)))
  "Returns string type for a service object of type '<LinearGaussianParameterEstimation-request>"
  "pgm_learner/LinearGaussianParameterEstimationRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianParameterEstimation-request)))
  "Returns string type for a service object of type 'LinearGaussianParameterEstimation-request"
  "pgm_learner/LinearGaussianParameterEstimationRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinearGaussianParameterEstimation-request>)))
  "Returns md5sum for a message object of type '<LinearGaussianParameterEstimation-request>"
  "0dcac92874fe4c5badf892fef99ed657")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinearGaussianParameterEstimation-request)))
  "Returns md5sum for a message object of type 'LinearGaussianParameterEstimation-request"
  "0dcac92874fe4c5badf892fef99ed657")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinearGaussianParameterEstimation-request>)))
  "Returns full string definition for message of type '<LinearGaussianParameterEstimation-request>"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # graph skeleton~%pgm_learner/LinearGaussianGraphState[] states # trial data~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%================================================================================~%MSG: pgm_learner/LinearGaussianGraphState~%pgm_learner/LinearGaussianNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNodeState~%string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinearGaussianParameterEstimation-request)))
  "Returns full string definition for message of type 'LinearGaussianParameterEstimation-request"
  (cl:format cl:nil "pgm_learner/GraphStructure graph # graph skeleton~%pgm_learner/LinearGaussianGraphState[] states # trial data~%~%================================================================================~%MSG: pgm_learner/GraphStructure~%string[] nodes~%pgm_learner/GraphEdge[] edges~%~%================================================================================~%MSG: pgm_learner/GraphEdge~%string node_from~%string node_to~%~%================================================================================~%MSG: pgm_learner/LinearGaussianGraphState~%pgm_learner/LinearGaussianNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNodeState~%string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinearGaussianParameterEstimation-request>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'graph))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'states) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinearGaussianParameterEstimation-request>))
  "Converts a ROS message object to a list"
  (cl:list 'LinearGaussianParameterEstimation-request
    (cl:cons ':graph (graph msg))
    (cl:cons ':states (states msg))
))
;//! \htmlinclude LinearGaussianParameterEstimation-response.msg.html

(cl:defclass <LinearGaussianParameterEstimation-response> (roslisp-msg-protocol:ros-message)
  ((nodes
    :reader nodes
    :initarg :nodes
    :type (cl:vector pgm_learner-msg:LinearGaussianNode)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:LinearGaussianNode :initial-element (cl:make-instance 'pgm_learner-msg:LinearGaussianNode))))
)

(cl:defclass LinearGaussianParameterEstimation-response (<LinearGaussianParameterEstimation-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinearGaussianParameterEstimation-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinearGaussianParameterEstimation-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-srv:<LinearGaussianParameterEstimation-response> is deprecated: use pgm_learner-srv:LinearGaussianParameterEstimation-response instead.")))

(cl:ensure-generic-function 'nodes-val :lambda-list '(m))
(cl:defmethod nodes-val ((m <LinearGaussianParameterEstimation-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-srv:nodes-val is deprecated.  Use pgm_learner-srv:nodes instead.")
  (nodes m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinearGaussianParameterEstimation-response>) ostream)
  "Serializes a message object of type '<LinearGaussianParameterEstimation-response>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'nodes))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'nodes))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinearGaussianParameterEstimation-response>) istream)
  "Deserializes a message object of type '<LinearGaussianParameterEstimation-response>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'nodes) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'nodes)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:LinearGaussianNode))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinearGaussianParameterEstimation-response>)))
  "Returns string type for a service object of type '<LinearGaussianParameterEstimation-response>"
  "pgm_learner/LinearGaussianParameterEstimationResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianParameterEstimation-response)))
  "Returns string type for a service object of type 'LinearGaussianParameterEstimation-response"
  "pgm_learner/LinearGaussianParameterEstimationResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinearGaussianParameterEstimation-response>)))
  "Returns md5sum for a message object of type '<LinearGaussianParameterEstimation-response>"
  "0dcac92874fe4c5badf892fef99ed657")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinearGaussianParameterEstimation-response)))
  "Returns md5sum for a message object of type 'LinearGaussianParameterEstimation-response"
  "0dcac92874fe4c5badf892fef99ed657")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinearGaussianParameterEstimation-response>)))
  "Returns full string definition for message of type '<LinearGaussianParameterEstimation-response>"
  (cl:format cl:nil "pgm_learner/LinearGaussianNode[] nodes # information of each nodes~%~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNode~%string name~%string[] parents~%string[] children~%~%float32 mean~%float32 variance~%~%float32[] mean_scalar # scalar for parents~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinearGaussianParameterEstimation-response)))
  "Returns full string definition for message of type 'LinearGaussianParameterEstimation-response"
  (cl:format cl:nil "pgm_learner/LinearGaussianNode[] nodes # information of each nodes~%~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNode~%string name~%string[] parents~%string[] children~%~%float32 mean~%float32 variance~%~%float32[] mean_scalar # scalar for parents~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinearGaussianParameterEstimation-response>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'nodes) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinearGaussianParameterEstimation-response>))
  "Converts a ROS message object to a list"
  (cl:list 'LinearGaussianParameterEstimation-response
    (cl:cons ':nodes (nodes msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'LinearGaussianParameterEstimation)))
  'LinearGaussianParameterEstimation-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'LinearGaussianParameterEstimation)))
  'LinearGaussianParameterEstimation-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianParameterEstimation)))
  "Returns string type for a service object of type '<LinearGaussianParameterEstimation>"
  "pgm_learner/LinearGaussianParameterEstimation")