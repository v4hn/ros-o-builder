; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude LinearGaussianNodeState.msg.html

(cl:defclass <LinearGaussianNodeState> (roslisp-msg-protocol:ros-message)
  ((node
    :reader node
    :initarg :node
    :type cl:string
    :initform "")
   (state
    :reader state
    :initarg :state
    :type cl:float
    :initform 0.0))
)

(cl:defclass LinearGaussianNodeState (<LinearGaussianNodeState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinearGaussianNodeState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinearGaussianNodeState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<LinearGaussianNodeState> is deprecated: use pgm_learner-msg:LinearGaussianNodeState instead.")))

(cl:ensure-generic-function 'node-val :lambda-list '(m))
(cl:defmethod node-val ((m <LinearGaussianNodeState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:node-val is deprecated.  Use pgm_learner-msg:node instead.")
  (node m))

(cl:ensure-generic-function 'state-val :lambda-list '(m))
(cl:defmethod state-val ((m <LinearGaussianNodeState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:state-val is deprecated.  Use pgm_learner-msg:state instead.")
  (state m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinearGaussianNodeState>) ostream)
  "Serializes a message object of type '<LinearGaussianNodeState>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'state))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinearGaussianNodeState>) istream)
  "Deserializes a message object of type '<LinearGaussianNodeState>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'state) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinearGaussianNodeState>)))
  "Returns string type for a message object of type '<LinearGaussianNodeState>"
  "pgm_learner/LinearGaussianNodeState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianNodeState)))
  "Returns string type for a message object of type 'LinearGaussianNodeState"
  "pgm_learner/LinearGaussianNodeState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinearGaussianNodeState>)))
  "Returns md5sum for a message object of type '<LinearGaussianNodeState>"
  "0346d671d7c07a522c68e4b95d0f9ce5")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinearGaussianNodeState)))
  "Returns md5sum for a message object of type 'LinearGaussianNodeState"
  "0346d671d7c07a522c68e4b95d0f9ce5")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinearGaussianNodeState>)))
  "Returns full string definition for message of type '<LinearGaussianNodeState>"
  (cl:format cl:nil "string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinearGaussianNodeState)))
  "Returns full string definition for message of type 'LinearGaussianNodeState"
  (cl:format cl:nil "string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinearGaussianNodeState>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'node))
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinearGaussianNodeState>))
  "Converts a ROS message object to a list"
  (cl:list 'LinearGaussianNodeState
    (cl:cons ':node (node msg))
    (cl:cons ':state (state msg))
))
