; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude LinearGaussianGraphState.msg.html

(cl:defclass <LinearGaussianGraphState> (roslisp-msg-protocol:ros-message)
  ((node_states
    :reader node_states
    :initarg :node_states
    :type (cl:vector pgm_learner-msg:LinearGaussianNodeState)
   :initform (cl:make-array 0 :element-type 'pgm_learner-msg:LinearGaussianNodeState :initial-element (cl:make-instance 'pgm_learner-msg:LinearGaussianNodeState))))
)

(cl:defclass LinearGaussianGraphState (<LinearGaussianGraphState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinearGaussianGraphState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinearGaussianGraphState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<LinearGaussianGraphState> is deprecated: use pgm_learner-msg:LinearGaussianGraphState instead.")))

(cl:ensure-generic-function 'node_states-val :lambda-list '(m))
(cl:defmethod node_states-val ((m <LinearGaussianGraphState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:node_states-val is deprecated.  Use pgm_learner-msg:node_states instead.")
  (node_states m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinearGaussianGraphState>) ostream)
  "Serializes a message object of type '<LinearGaussianGraphState>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'node_states))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'node_states))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinearGaussianGraphState>) istream)
  "Deserializes a message object of type '<LinearGaussianGraphState>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'node_states) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'node_states)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'pgm_learner-msg:LinearGaussianNodeState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinearGaussianGraphState>)))
  "Returns string type for a message object of type '<LinearGaussianGraphState>"
  "pgm_learner/LinearGaussianGraphState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinearGaussianGraphState)))
  "Returns string type for a message object of type 'LinearGaussianGraphState"
  "pgm_learner/LinearGaussianGraphState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinearGaussianGraphState>)))
  "Returns md5sum for a message object of type '<LinearGaussianGraphState>"
  "f6ac09f794ac42baad4ddfb93fc0a69c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinearGaussianGraphState)))
  "Returns md5sum for a message object of type 'LinearGaussianGraphState"
  "f6ac09f794ac42baad4ddfb93fc0a69c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinearGaussianGraphState>)))
  "Returns full string definition for message of type '<LinearGaussianGraphState>"
  (cl:format cl:nil "pgm_learner/LinearGaussianNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNodeState~%string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinearGaussianGraphState)))
  "Returns full string definition for message of type 'LinearGaussianGraphState"
  (cl:format cl:nil "pgm_learner/LinearGaussianNodeState[] node_states~%~%================================================================================~%MSG: pgm_learner/LinearGaussianNodeState~%string node~%float32 state~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinearGaussianGraphState>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'node_states) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinearGaussianGraphState>))
  "Converts a ROS message object to a list"
  (cl:list 'LinearGaussianGraphState
    (cl:cons ':node_states (node_states msg))
))
