; Auto-generated. Do not edit!


(cl:in-package pgm_learner-msg)


;//! \htmlinclude GraphEdge.msg.html

(cl:defclass <GraphEdge> (roslisp-msg-protocol:ros-message)
  ((node_from
    :reader node_from
    :initarg :node_from
    :type cl:string
    :initform "")
   (node_to
    :reader node_to
    :initarg :node_to
    :type cl:string
    :initform ""))
)

(cl:defclass GraphEdge (<GraphEdge>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <GraphEdge>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'GraphEdge)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pgm_learner-msg:<GraphEdge> is deprecated: use pgm_learner-msg:GraphEdge instead.")))

(cl:ensure-generic-function 'node_from-val :lambda-list '(m))
(cl:defmethod node_from-val ((m <GraphEdge>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:node_from-val is deprecated.  Use pgm_learner-msg:node_from instead.")
  (node_from m))

(cl:ensure-generic-function 'node_to-val :lambda-list '(m))
(cl:defmethod node_to-val ((m <GraphEdge>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pgm_learner-msg:node_to-val is deprecated.  Use pgm_learner-msg:node_to instead.")
  (node_to m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <GraphEdge>) ostream)
  "Serializes a message object of type '<GraphEdge>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node_from))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node_from))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'node_to))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'node_to))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <GraphEdge>) istream)
  "Deserializes a message object of type '<GraphEdge>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node_from) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node_from) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'node_to) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'node_to) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<GraphEdge>)))
  "Returns string type for a message object of type '<GraphEdge>"
  "pgm_learner/GraphEdge")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'GraphEdge)))
  "Returns string type for a message object of type 'GraphEdge"
  "pgm_learner/GraphEdge")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<GraphEdge>)))
  "Returns md5sum for a message object of type '<GraphEdge>"
  "0e8438c5349fda07e98ac2a93db05307")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'GraphEdge)))
  "Returns md5sum for a message object of type 'GraphEdge"
  "0e8438c5349fda07e98ac2a93db05307")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<GraphEdge>)))
  "Returns full string definition for message of type '<GraphEdge>"
  (cl:format cl:nil "string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'GraphEdge)))
  "Returns full string definition for message of type 'GraphEdge"
  (cl:format cl:nil "string node_from~%string node_to~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <GraphEdge>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'node_from))
     4 (cl:length (cl:slot-value msg 'node_to))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <GraphEdge>))
  "Converts a ROS message object to a list"
  (cl:list 'GraphEdge
    (cl:cons ':node_from (node_from msg))
    (cl:cons ':node_to (node_to msg))
))
