// Auto-generated. Do not edit!

// (in-package sesame_ros.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class StatusRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
    }
    else {
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StatusRequest
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StatusRequest
    let len;
    let data = new StatusRequest(null);
    return data;
  }

  static getMessageSize(object) {
    return 0;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sesame_ros/StatusRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd41d8cd98f00b204e9800998ecf8427e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StatusRequest(null);
    return resolved;
    }
};

class StatusResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nickname = null;
      this.serial = null;
      this.device_id = null;
      this.battery = null;
      this.locked = null;
      this.responsive = null;
    }
    else {
      if (initObj.hasOwnProperty('nickname')) {
        this.nickname = initObj.nickname
      }
      else {
        this.nickname = '';
      }
      if (initObj.hasOwnProperty('serial')) {
        this.serial = initObj.serial
      }
      else {
        this.serial = '';
      }
      if (initObj.hasOwnProperty('device_id')) {
        this.device_id = initObj.device_id
      }
      else {
        this.device_id = '';
      }
      if (initObj.hasOwnProperty('battery')) {
        this.battery = initObj.battery
      }
      else {
        this.battery = 0;
      }
      if (initObj.hasOwnProperty('locked')) {
        this.locked = initObj.locked
      }
      else {
        this.locked = false;
      }
      if (initObj.hasOwnProperty('responsive')) {
        this.responsive = initObj.responsive
      }
      else {
        this.responsive = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type StatusResponse
    // Serialize message field [nickname]
    bufferOffset = _serializer.string(obj.nickname, buffer, bufferOffset);
    // Serialize message field [serial]
    bufferOffset = _serializer.string(obj.serial, buffer, bufferOffset);
    // Serialize message field [device_id]
    bufferOffset = _serializer.string(obj.device_id, buffer, bufferOffset);
    // Serialize message field [battery]
    bufferOffset = _serializer.int32(obj.battery, buffer, bufferOffset);
    // Serialize message field [locked]
    bufferOffset = _serializer.bool(obj.locked, buffer, bufferOffset);
    // Serialize message field [responsive]
    bufferOffset = _serializer.bool(obj.responsive, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type StatusResponse
    let len;
    let data = new StatusResponse(null);
    // Deserialize message field [nickname]
    data.nickname = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [serial]
    data.serial = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [device_id]
    data.device_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [battery]
    data.battery = _deserializer.int32(buffer, bufferOffset);
    // Deserialize message field [locked]
    data.locked = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [responsive]
    data.responsive = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.nickname);
    length += _getByteLength(object.serial);
    length += _getByteLength(object.device_id);
    return length + 18;
  }

  static datatype() {
    // Returns string type for a service object
    return 'sesame_ros/StatusResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '25385424a97316579ec1ed945842d240';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string nickname
    string serial
    string device_id
    int32 battery
    bool locked
    bool responsive
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new StatusResponse(null);
    if (msg.nickname !== undefined) {
      resolved.nickname = msg.nickname;
    }
    else {
      resolved.nickname = ''
    }

    if (msg.serial !== undefined) {
      resolved.serial = msg.serial;
    }
    else {
      resolved.serial = ''
    }

    if (msg.device_id !== undefined) {
      resolved.device_id = msg.device_id;
    }
    else {
      resolved.device_id = ''
    }

    if (msg.battery !== undefined) {
      resolved.battery = msg.battery;
    }
    else {
      resolved.battery = 0
    }

    if (msg.locked !== undefined) {
      resolved.locked = msg.locked;
    }
    else {
      resolved.locked = false
    }

    if (msg.responsive !== undefined) {
      resolved.responsive = msg.responsive;
    }
    else {
      resolved.responsive = false
    }

    return resolved;
    }
};

module.exports = {
  Request: StatusRequest,
  Response: StatusResponse,
  md5sum() { return '25385424a97316579ec1ed945842d240'; },
  datatype() { return 'sesame_ros/Status'; }
};
