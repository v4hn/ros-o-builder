
"use strict";

let SpeechRecognitionCandidates = require('./SpeechRecognitionCandidates.js');
let Vocabulary = require('./Vocabulary.js');
let Grammar = require('./Grammar.js');
let PhraseRule = require('./PhraseRule.js');

module.exports = {
  SpeechRecognitionCandidates: SpeechRecognitionCandidates,
  Vocabulary: Vocabulary,
  Grammar: Grammar,
  PhraseRule: PhraseRule,
};
