
"use strict";

let SetPen = require('./SetPen.js')
let TeleportRelative = require('./TeleportRelative.js')
let Spawn = require('./Spawn.js')
let TeleportAbsolute = require('./TeleportAbsolute.js')
let Kill = require('./Kill.js')

module.exports = {
  SetPen: SetPen,
  TeleportRelative: TeleportRelative,
  Spawn: Spawn,
  TeleportAbsolute: TeleportAbsolute,
  Kill: Kill,
};
