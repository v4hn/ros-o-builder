
"use strict";

let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');
let TestDurationArray = require('./TestDurationArray.js');
let TestUInt8 = require('./TestUInt8.js');
let TestTimeArray = require('./TestTimeArray.js');
let TestHeaderArray = require('./TestHeaderArray.js');
let TestHeaderTwo = require('./TestHeaderTwo.js');
let TestHeader = require('./TestHeader.js');
let TestChar = require('./TestChar.js');
let Num = require('./Num.js');

module.exports = {
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
  TestDurationArray: TestDurationArray,
  TestUInt8: TestUInt8,
  TestTimeArray: TestTimeArray,
  TestHeaderArray: TestHeaderArray,
  TestHeaderTwo: TestHeaderTwo,
  TestHeader: TestHeader,
  TestChar: TestChar,
  Num: Num,
};
