
"use strict";

let Velocity = require('./Velocity.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeFeedback = require('./ShapeFeedback.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeGoal = require('./ShapeGoal.js');

module.exports = {
  Velocity: Velocity,
  ShapeActionGoal: ShapeActionGoal,
  ShapeFeedback: ShapeFeedback,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeActionResult: ShapeActionResult,
  ShapeResult: ShapeResult,
  ShapeAction: ShapeAction,
  ShapeGoal: ShapeGoal,
};
