
"use strict";

let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let Table = require('./Table.js');
let ObjectInformation = require('./ObjectInformation.js');
let TableArray = require('./TableArray.js');
let RecognizedObject = require('./RecognizedObject.js');
let ObjectType = require('./ObjectType.js');

module.exports = {
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  RecognizedObjectArray: RecognizedObjectArray,
  Table: Table,
  ObjectInformation: ObjectInformation,
  TableArray: TableArray,
  RecognizedObject: RecognizedObject,
  ObjectType: ObjectType,
};
