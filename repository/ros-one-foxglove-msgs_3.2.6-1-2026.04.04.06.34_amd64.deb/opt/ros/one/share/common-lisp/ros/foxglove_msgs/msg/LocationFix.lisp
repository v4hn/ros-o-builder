; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude LocationFix.msg.html

(cl:defclass <LocationFix> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform "")
   (latitude
    :reader latitude
    :initarg :latitude
    :type cl:float
    :initform 0.0)
   (longitude
    :reader longitude
    :initarg :longitude
    :type cl:float
    :initform 0.0)
   (altitude
    :reader altitude
    :initarg :altitude
    :type cl:float
    :initform 0.0)
   (position_covariance
    :reader position_covariance
    :initarg :position_covariance
    :type (cl:vector cl:float)
   :initform (cl:make-array 9 :element-type 'cl:float :initial-element 0.0))
   (position_covariance_type
    :reader position_covariance_type
    :initarg :position_covariance_type
    :type cl:fixnum
    :initform 0)
   (heading
    :reader heading
    :initarg :heading
    :type cl:float
    :initform 0.0)
   (velocity
    :reader velocity
    :initarg :velocity
    :type foxglove_msgs-msg:Velocity3
    :initform (cl:make-instance 'foxglove_msgs-msg:Velocity3))
   (color
    :reader color
    :initarg :color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (metadata
    :reader metadata
    :initarg :metadata
    :type (cl:vector foxglove_msgs-msg:KeyValuePair)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:KeyValuePair :initial-element (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))))
)

(cl:defclass LocationFix (<LocationFix>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LocationFix>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LocationFix)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<LocationFix> is deprecated: use foxglove_msgs-msg:LocationFix instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:frame_id-val is deprecated.  Use foxglove_msgs-msg:frame_id instead.")
  (frame_id m))

(cl:ensure-generic-function 'latitude-val :lambda-list '(m))
(cl:defmethod latitude-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:latitude-val is deprecated.  Use foxglove_msgs-msg:latitude instead.")
  (latitude m))

(cl:ensure-generic-function 'longitude-val :lambda-list '(m))
(cl:defmethod longitude-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:longitude-val is deprecated.  Use foxglove_msgs-msg:longitude instead.")
  (longitude m))

(cl:ensure-generic-function 'altitude-val :lambda-list '(m))
(cl:defmethod altitude-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:altitude-val is deprecated.  Use foxglove_msgs-msg:altitude instead.")
  (altitude m))

(cl:ensure-generic-function 'position_covariance-val :lambda-list '(m))
(cl:defmethod position_covariance-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:position_covariance-val is deprecated.  Use foxglove_msgs-msg:position_covariance instead.")
  (position_covariance m))

(cl:ensure-generic-function 'position_covariance_type-val :lambda-list '(m))
(cl:defmethod position_covariance_type-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:position_covariance_type-val is deprecated.  Use foxglove_msgs-msg:position_covariance_type instead.")
  (position_covariance_type m))

(cl:ensure-generic-function 'heading-val :lambda-list '(m))
(cl:defmethod heading-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:heading-val is deprecated.  Use foxglove_msgs-msg:heading instead.")
  (heading m))

(cl:ensure-generic-function 'velocity-val :lambda-list '(m))
(cl:defmethod velocity-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:velocity-val is deprecated.  Use foxglove_msgs-msg:velocity instead.")
  (velocity m))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:color-val is deprecated.  Use foxglove_msgs-msg:color instead.")
  (color m))

(cl:ensure-generic-function 'metadata-val :lambda-list '(m))
(cl:defmethod metadata-val ((m <LocationFix>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:metadata-val is deprecated.  Use foxglove_msgs-msg:metadata instead.")
  (metadata m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<LocationFix>)))
    "Constants for message type '<LocationFix>"
  '((:UNKNOWN . 0)
    (:APPROXIMATED . 1)
    (:DIAGONAL_KNOWN . 2)
    (:KNOWN . 3))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'LocationFix)))
    "Constants for message type 'LocationFix"
  '((:UNKNOWN . 0)
    (:APPROXIMATED . 1)
    (:DIAGONAL_KNOWN . 2)
    (:KNOWN . 3))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LocationFix>) ostream)
  "Serializes a message object of type '<LocationFix>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'latitude))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'longitude))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'altitude))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'position_covariance))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'position_covariance_type)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'heading))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'velocity) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'metadata))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'metadata))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LocationFix>) istream)
  "Deserializes a message object of type '<LocationFix>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'latitude) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'longitude) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'altitude) (roslisp-utils:decode-double-float-bits bits)))
  (cl:setf (cl:slot-value msg 'position_covariance) (cl:make-array 9))
  (cl:let ((vals (cl:slot-value msg 'position_covariance)))
    (cl:dotimes (i 9)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'position_covariance_type)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'heading) (roslisp-utils:decode-double-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'velocity) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'metadata) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'metadata)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LocationFix>)))
  "Returns string type for a message object of type '<LocationFix>"
  "foxglove_msgs/LocationFix")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LocationFix)))
  "Returns string type for a message object of type 'LocationFix"
  "foxglove_msgs/LocationFix")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LocationFix>)))
  "Returns md5sum for a message object of type '<LocationFix>"
  "e519365cbe0be6fd561ed2fb057ee35c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LocationFix)))
  "Returns md5sum for a message object of type 'LocationFix"
  "e519365cbe0be6fd561ed2fb057ee35c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LocationFix>)))
  "Returns full string definition for message of type '<LocationFix>"
  (cl:format cl:nil "# foxglove_msgs/LocationFix~%# A navigation satellite fix for any Global Navigation Satellite System~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the message~%time timestamp~%~%# Frame for the sensor. Latitude and longitude readings are at the origin of the frame.~%string frame_id~%~%# Latitude in degrees~%float64 latitude~%~%# Longitude in degrees~%float64 longitude~%~%# Altitude in meters~%float64 altitude~%~%# Position covariance (m^2) defined relative to a tangential plane through the reported position. The components are East, North, and Up (ENU), in row-major order.~%float64[9] position_covariance~%~%# Unknown position covariance type~%uint8 UNKNOWN=0~%~%# Position covariance is approximated~%uint8 APPROXIMATED=1~%~%# Position covariance is per-axis, so put it along the diagonal~%uint8 DIAGONAL_KNOWN=2~%~%# Position covariance of the fix is known~%uint8 KNOWN=3~%~%# If `position_covariance` is available, `position_covariance_type` must be set to indicate the type of covariance.~%uint8 position_covariance_type~%~%# Heading (yaw angle), in radians, measured clockwise from north (NaN indicates this value is not set)~%float64 heading~%~%# Velocity in local East-North-Up (ENU) frame in m/s~%foxglove_msgs/Velocity3 velocity~%~%# Color used to visualize the location~%foxglove_msgs/Color color~%~%# Additional user-provided metadata associated with the location fix. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Velocity3~%# foxglove_msgs/Velocity3~%# A velocity vector in 3D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x component~%float64 x~%~%# y component~%float64 y~%~%# z component~%float64 z~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LocationFix)))
  "Returns full string definition for message of type 'LocationFix"
  (cl:format cl:nil "# foxglove_msgs/LocationFix~%# A navigation satellite fix for any Global Navigation Satellite System~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the message~%time timestamp~%~%# Frame for the sensor. Latitude and longitude readings are at the origin of the frame.~%string frame_id~%~%# Latitude in degrees~%float64 latitude~%~%# Longitude in degrees~%float64 longitude~%~%# Altitude in meters~%float64 altitude~%~%# Position covariance (m^2) defined relative to a tangential plane through the reported position. The components are East, North, and Up (ENU), in row-major order.~%float64[9] position_covariance~%~%# Unknown position covariance type~%uint8 UNKNOWN=0~%~%# Position covariance is approximated~%uint8 APPROXIMATED=1~%~%# Position covariance is per-axis, so put it along the diagonal~%uint8 DIAGONAL_KNOWN=2~%~%# Position covariance of the fix is known~%uint8 KNOWN=3~%~%# If `position_covariance` is available, `position_covariance_type` must be set to indicate the type of covariance.~%uint8 position_covariance_type~%~%# Heading (yaw angle), in radians, measured clockwise from north (NaN indicates this value is not set)~%float64 heading~%~%# Velocity in local East-North-Up (ENU) frame in m/s~%foxglove_msgs/Velocity3 velocity~%~%# Color used to visualize the location~%foxglove_msgs/Color color~%~%# Additional user-provided metadata associated with the location fix. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Velocity3~%# foxglove_msgs/Velocity3~%# A velocity vector in 3D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x component~%float64 x~%~%# y component~%float64 y~%~%# z component~%float64 z~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LocationFix>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'frame_id))
     8
     8
     8
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'position_covariance) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     1
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'velocity))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'metadata) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LocationFix>))
  "Converts a ROS message object to a list"
  (cl:list 'LocationFix
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':frame_id (frame_id msg))
    (cl:cons ':latitude (latitude msg))
    (cl:cons ':longitude (longitude msg))
    (cl:cons ':altitude (altitude msg))
    (cl:cons ':position_covariance (position_covariance msg))
    (cl:cons ':position_covariance_type (position_covariance_type msg))
    (cl:cons ':heading (heading msg))
    (cl:cons ':velocity (velocity msg))
    (cl:cons ':color (color msg))
    (cl:cons ':metadata (metadata msg))
))
