/* ./irtdyna.c :  entry=irtdyna */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Sep 5 06:56:26 UTC 2026) */
#include "eus.h"
#include "irtdyna.h"
#pragma init (register_irtdyna)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtdyna();
extern pointer build_quote_vector();
static int register_irtdyna()
  { add_module_initializer("___irtdyna", ___irtdyna);}

static pointer irtdynaF2835calc_inertia_matrix_rotational();
static pointer irtdynaF2836calc_inertia_matrix_linear();

/*:calc-inertia-matrix*/
static pointer irtdynaM2837joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST2839:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK2838:
	ctx->vsp=local; return(local[0]);}

/*calc-inertia-matrix-rotational*/
static pointer irtdynaF2835calc_inertia_matrix_rotational(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=20) maerror();
	local[0]= argv[9];
	local[1]= fqv[2];
	local[2]= argv[3];
	local[3]= argv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= argv[15];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*normalize-vector*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[5];
	local[4]= argv[16];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999985548644e-10);
	local[4]= argv[6];
	local[5]= argv[19];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,3,local+3,&ftab[2],fqv[4]); /*scale-matrix*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	local[6]= local[2];
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= argv[8];
	local[9]= fqv[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[17];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= w;
	local[8]= argv[17];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,3,local+6); /*v-*/
	local[6]= w;
	local[7]= argv[18];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= argv[17];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[4];
	local[7]= argv[18];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= local[3];
	local[7]= local[0];
	local[8]= argv[16];
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,3,local+6); /*transform*/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,3,local+5); /*v+*/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[7];
	local[8]= argv[15];
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,3,local+6); /*scale*/
	local[6]= w;
	local[7]= local[4];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+6); /*v**/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,3,local+5); /*v-*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[10];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,5,local+6,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtdynaWHL2841:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX2842;
	local[9]= argv[0];
	local[10]= argv[1];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[2];
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL2841;
irtdynaWHX2842:
	local[9]= NIL;
irtdynaBLK2843:
	w = NIL;
	local[7]= local[5];
	local[8]= argv[11];
	local[9]= argv[12];
	local[10]= argv[13];
	local[11]= argv[14];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,5,local+7,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
irtdynaWHL2844:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2845;
	local[10]= argv[0];
	local[11]= argv[1];
	local[12]= local[8];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,3,local+11); /*+*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= local[7];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2844;
irtdynaWHX2845:
	local[10]= NIL;
irtdynaBLK2846:
	w = NIL;
	local[0]= w;
irtdynaBLK2840:
	ctx->vsp=local; return(local[0]);}

/*calc-inertia-matrix-linear*/
static pointer irtdynaF2836calc_inertia_matrix_linear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=20) maerror();
	local[0]= argv[9];
	local[1]= fqv[2];
	local[2]= argv[3];
	local[3]= argv[15];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	local[1]= argv[15];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,2,local+0,&ftab[1],fqv[3]); /*normalize-vector*/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000208167e-03);
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[5];
	local[4]= argv[16];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,3,local+2); /*scale*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999985548644e-10);
	local[4]= argv[6];
	local[5]= argv[19];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,3,local+3,&ftab[2],fqv[4]); /*scale-matrix*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[0];
	local[6]= argv[15];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[4];
	local[7]= argv[17];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+5); /*v**/
	local[5]= w;
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[7];
	local[8]= argv[16];
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,3,local+6); /*scale*/
	local[6]= w;
	local[7]= local[4];
	local[8]= argv[18];
	ctx->vsp=local+9;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+6); /*v**/
	local[6]= w;
	local[7]= argv[16];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,3,local+5); /*v-*/
	local[5]= w;
	local[6]= local[4];
	local[7]= argv[10];
	local[8]= argv[12];
	local[9]= argv[13];
	local[10]= argv[14];
	ctx->vsp=local+11;
	w=(*ftab[3])(ctx,5,local+6,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LENGTH(ctx,1,local+8); /*length*/
	local[8]= w;
irtdynaWHL2848:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX2849;
	local[9]= argv[0];
	local[10]= argv[1];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= argv[2];
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ASET(ctx,4,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL2848;
irtdynaWHX2849:
	local[9]= NIL;
irtdynaBLK2850:
	w = NIL;
	local[7]= local[5];
	local[8]= argv[11];
	local[9]= argv[12];
	local[10]= argv[13];
	local[11]= argv[14];
	ctx->vsp=local+12;
	w=(*ftab[3])(ctx,5,local+7,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
irtdynaWHL2851:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2852;
	local[10]= argv[0];
	local[11]= argv[1];
	local[12]= local[8];
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,3,local+11); /*+*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= local[7];
	local[14]= local[8];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)ASET(ctx,4,local+10); /*aset*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2851;
irtdynaWHX2852:
	local[10]= NIL;
irtdynaBLK2853:
	w = NIL;
	local[0]= w;
irtdynaBLK2847:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2854rotational_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= argv[5];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2855:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2856linear_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= argv[5];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2836calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= w;
irtdynaBLK2857:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2858omniwheel_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= fqv[7];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2836calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[8];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2836calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[9];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2859:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM2860sphere_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= fqv[10];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[11];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[12];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2861:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix*/
static pointer irtdynaM28626dof_joint_calc_inertia_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=21) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= fqv[13];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2836calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[14];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2836calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[15];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2836calc_inertia_matrix_linear(ctx,20,local+0); /*calc-inertia-matrix-linear*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[16];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)4L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[17];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[4];
	local[3]= makeint((eusinteger_t)5L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= fqv[18];
	local[4]= argv[6];
	local[5]= argv[7];
	local[6]= argv[8];
	local[7]= argv[9];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= argv[10];
	local[10]= argv[11];
	local[11]= argv[12];
	local[12]= argv[13];
	local[13]= argv[14];
	local[14]= argv[15];
	local[15]= argv[16];
	local[16]= argv[17];
	local[17]= argv[18];
	local[18]= argv[19];
	local[19]= argv[20];
	ctx->vsp=local+20;
	w=(pointer)irtdynaF2835calc_inertia_matrix_rotational(ctx,20,local+0); /*calc-inertia-matrix-rotational*/
	local[0]= w;
irtdynaBLK2863:
	ctx->vsp=local; return(local[0]);}

/*:append-weight-no-update*/
static pointer irtdynaM2864bodyset_link_append_weight_no_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[19], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2866;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[0] = w;
irtdynaKEY2866:
	local[1]= argv[0];
	local[2]= fqv[20];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
irtdynaWHL2867:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtdynaWHX2868;
	local[4]= argv[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[1] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtdynaWHL2867;
irtdynaWHX2868:
	local[4]= NIL;
irtdynaBLK2869:
	w = NIL;
	w = local[1];
	local[0]= w;
irtdynaBLK2865:
	ctx->vsp=local; return(local[0]);}

/*:append-centroid-no-update*/
static pointer irtdynaM2870bodyset_link_append_centroid_no_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[21], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2872;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[0] = w;
irtdynaKEY2872:
	if (n & (1<<1)) goto irtdynaKEY2873;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[1] = w;
irtdynaKEY2873:
	if (n & (1<<2)) goto irtdynaKEY2874;
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[2] = w;
irtdynaKEY2874:
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)EUSFLOAT(ctx,1,local+3); /*float*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF2875;
	local[3]= argv[4];
	goto irtdynaIF2876;
irtdynaIF2875:
	local[3]= makeflt(1.0000000000000000000000e+00);
	local[4]= argv[5];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[20];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[4];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,3,local+4); /*scale*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[2];
irtdynaWHL2877:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtdynaWHX2878;
	local[7]= local[4];
	local[8]= argv[2];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= argv[3];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtdynaWHL2877;
irtdynaWHX2878:
	local[7]= NIL;
irtdynaBLK2879:
	w = NIL;
	w = local[4];
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,3,local+3); /*scale*/
	local[3]= w;
irtdynaIF2876:
	w = local[3];
	local[0]= w;
irtdynaBLK2871:
	ctx->vsp=local; return(local[0]);}

/*:append-inertia-no-update*/
static pointer irtdynaM2880bodyset_link_append_inertia_no_update(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<7) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[23], &argv[7], n-7, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2882;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[0] = w;
irtdynaKEY2882:
	if (n & (1<<1)) goto irtdynaKEY2883;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[1] = w;
irtdynaKEY2883:
	if (n & (1<<2)) goto irtdynaKEY2884;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[2] = w;
irtdynaKEY2884:
	if (n & (1<<3)) goto irtdynaKEY2885;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2885:
	if (n & (1<<4)) goto irtdynaKEY2886;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,3,local+6); /*float-vector*/
	local[4] = w;
irtdynaKEY2886:
	if (n & (1<<5)) goto irtdynaKEY2887;
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[5] = w;
irtdynaKEY2887:
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtdynaFLET2888,env,argv,local);
	local[7]= argv[0];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[25];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)TRANSPOSE(ctx,2,local+8); /*transpose*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[20];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[5];
	local[10]= argv[6];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,3,local+9); /*v-*/
	local[9]= w;
	w = local[6];
	ctx->vsp=local+10;
	w=irtdynaFLET2888(ctx,1,local+9,w);
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,3,local+8,&ftab[2],fqv[4]); /*scale-matrix*/
	local[8]= w;
	local[9]= local[7];
	local[10]= local[7];
	ctx->vsp=local+11;
	w=(*ftab[6])(ctx,3,local+8,&ftab[6],fqv[27]); /*m+*/
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[5];
irtdynaWHL2889:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX2890;
	local[10]= argv[4];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[7];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[6])(ctx,3,local+10,&ftab[6],fqv[27]); /*m+*/
	local[10]= argv[2];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= argv[3];
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[6];
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)VMINUS(ctx,3,local+11); /*v-*/
	local[11]= w;
	w = local[6];
	ctx->vsp=local+12;
	w=irtdynaFLET2888(ctx,1,local+11,w);
	local[11]= w;
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(*ftab[2])(ctx,3,local+10,&ftab[2],fqv[4]); /*scale-matrix*/
	local[10]= w;
	local[11]= local[7];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(*ftab[6])(ctx,3,local+10,&ftab[6],fqv[27]); /*m+*/
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL2889;
irtdynaWHX2890:
	local[10]= NIL;
irtdynaBLK2891:
	w = NIL;
	w = local[7];
	local[0]= w;
irtdynaBLK2881:
	ctx->vsp=local; return(local[0]);}

/*:append-mass-properties*/
static pointer irtdynaM2892bodyset_link_append_mass_properties(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[28], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2894;
	local[0] = T;
irtdynaKEY2894:
	if (n & (1<<1)) goto irtdynaKEY2895;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[1] = w;
irtdynaKEY2895:
	if (n & (1<<2)) goto irtdynaKEY2896;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[2] = w;
irtdynaKEY2896:
	if (n & (1<<3)) goto irtdynaKEY2897;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2897:
	if (n & (1<<4)) goto irtdynaKEY2898;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY2898:
	if (n & (1<<5)) goto irtdynaKEY2899;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2899:
	if (n & (1<<6)) goto irtdynaKEY2900;
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[6] = w;
irtdynaKEY2900:
	if (n & (1<<7)) goto irtdynaKEY2901;
	local[11]= argv[2];
	local[12]= fqv[20];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,2,local+11,&ftab[7],fqv[29]); /*send-all*/
	local[7] = w;
irtdynaKEY2901:
	if (n & (1<<8)) goto irtdynaKEY2902;
	local[11]= argv[2];
	local[12]= fqv[30];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,2,local+11,&ftab[7],fqv[29]); /*send-all*/
	local[8] = w;
irtdynaKEY2902:
	if (n & (1<<9)) goto irtdynaKEY2903;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO2904,env,argv,local);
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	local[9] = w;
irtdynaKEY2903:
	if (n & (1<<10)) goto irtdynaKEY2905;
	local[11]= argv[0];
	local[12]= fqv[30];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[10] = w;
irtdynaKEY2905:
	local[11]= argv[2];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[31];
	local[14]= local[7];
	local[15]= fqv[32];
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,5,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[33];
	local[15]= local[7];
	local[16]= local[8];
	local[17]= local[10];
	local[18]= local[12];
	local[19]= fqv[34];
	local[20]= local[1];
	local[21]= fqv[35];
	local[22]= local[2];
	local[23]= fqv[32];
	local[24]= local[11];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,12,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[36];
	local[16]= local[7];
	local[17]= local[8];
	local[18]= local[9];
	local[19]= local[10];
	local[20]= local[13];
	local[21]= fqv[37];
	local[22]= local[3];
	local[23]= fqv[38];
	local[24]= local[4];
	local[25]= fqv[39];
	local[26]= local[5];
	local[27]= fqv[40];
	local[28]= local[6];
	local[29]= fqv[34];
	local[30]= local[1];
	local[31]= fqv[32];
	local[32]= local[11];
	ctx->vsp=local+33;
	w=(pointer)SEND(ctx,19,local+14); /*send*/
	local[14]= w;
	if (local[0]==NIL) goto irtdynaIF2906;
	local[15]= argv[0];
	local[16]= fqv[20];
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= argv[0];
	local[16]= fqv[41];
	local[17]= local[13];
	local[18]= argv[0]->c.obj.iv[15];
	local[19]= local[1];
	local[20]= local[3];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,6,local+15); /*send*/
	argv[0]->c.obj.iv[15] = w;
	local[15]= argv[0];
	local[16]= fqv[26];
	local[17]= argv[0];
	local[18]= fqv[25];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)TRANSPOSE(ctx,2,local+17); /*transpose*/
	local[17]= w;
	local[18]= local[14];
	local[19]= local[4];
	ctx->vsp=local+20;
	w=(pointer)MATTIMES(ctx,3,local+17); /*m**/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[25];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	local[19]= argv[0];
	local[20]= fqv[26];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,2,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)MATTIMES(ctx,3,local+17); /*m**/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	goto irtdynaIF2907;
irtdynaIF2906:
	local[15]= NIL;
irtdynaIF2907:
	local[15]= local[12];
	local[16]= local[13];
	local[17]= local[14];
	ctx->vsp=local+18;
	w=(pointer)LIST(ctx,3,local+15); /*list*/
	local[0]= w;
irtdynaBLK2893:
	ctx->vsp=local; return(local[0]);}

/*:propagate-mass-properties*/
static pointer irtdynaM2908bodyset_link_propagate_mass_properties(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[42], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2910;
	local[0] = NIL;
irtdynaKEY2910:
	if (n & (1<<1)) goto irtdynaKEY2911;
	local[6]= loadglobal(fqv[43]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[1] = w;
irtdynaKEY2911:
	if (n & (1<<2)) goto irtdynaKEY2912;
	local[6]= loadglobal(fqv[43]);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[2] = w;
irtdynaKEY2912:
	if (n & (1<<3)) goto irtdynaKEY2913;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2913:
	if (n & (1<<4)) goto irtdynaKEY2914;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY2914:
	if (n & (1<<5)) goto irtdynaKEY2915;
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[5])(ctx,2,local+6,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2915:
	if (argv[0]->c.obj.iv[11]==NIL) goto irtdynaIF2916;
	local[6]= NIL;
	local[7]= argv[0]->c.obj.iv[11];
irtdynaWHL2918:
	if (local[7]==NIL) goto irtdynaWHX2919;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	w=local[7];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7] = (w)->c.cons.cdr;
	w = local[8];
	local[6] = w;
	local[8]= local[6];
	local[9]= fqv[44];
	local[10]= fqv[45];
	local[11]= local[0];
	local[12]= fqv[34];
	local[13]= local[1];
	local[14]= fqv[35];
	local[15]= local[2];
	local[16]= fqv[37];
	local[17]= local[3];
	local[18]= fqv[38];
	local[19]= local[4];
	local[20]= fqv[39];
	local[21]= local[5];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,14,local+8); /*send*/
	goto irtdynaWHL2918;
irtdynaWHX2919:
	local[8]= NIL;
irtdynaBLK2920:
	w = NIL;
	local[6]= argv[0];
	local[7]= fqv[46];
	local[8]= fqv[47];
	local[9]= argv[0];
	local[10]= fqv[48];
	local[11]= argv[0]->c.obj.iv[11];
	local[12]= fqv[37];
	local[13]= local[3];
	local[14]= fqv[38];
	local[15]= local[4];
	local[16]= fqv[39];
	local[17]= local[5];
	local[18]= fqv[40];
	local[19]= argv[0];
	local[20]= fqv[49];
	local[21]= fqv[50];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= fqv[34];
	local[21]= local[1];
	local[22]= fqv[35];
	local[23]= argv[0];
	local[24]= fqv[49];
	local[25]= fqv[51];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[23]= w;
	local[24]= fqv[52];
	local[25]= argv[0]->c.obj.iv[11];
	local[26]= fqv[49];
	local[27]= fqv[47];
	ctx->vsp=local+28;
	w=(*ftab[7])(ctx,3,local+25,&ftab[7],fqv[29]); /*send-all*/
	local[25]= w;
	local[26]= fqv[53];
	local[27]= argv[0]->c.obj.iv[11];
	local[28]= fqv[49];
	local[29]= fqv[51];
	ctx->vsp=local+30;
	w=(*ftab[7])(ctx,3,local+27,&ftab[7],fqv[29]); /*send-all*/
	local[27]= w;
	local[28]= fqv[54];
	local[29]= argv[0]->c.obj.iv[11];
	local[30]= fqv[49];
	local[31]= fqv[50];
	ctx->vsp=local+32;
	w=(*ftab[7])(ctx,3,local+29,&ftab[7],fqv[29]); /*send-all*/
	local[29]= w;
	local[30]= fqv[55];
	local[31]= argv[0];
	local[32]= fqv[30];
	ctx->vsp=local+33;
	w=(pointer)SEND(ctx,2,local+31); /*send*/
	local[31]= w;
	local[32]= fqv[56];
	local[33]= NIL;
	ctx->vsp=local+34;
	w=(pointer)SEND(ctx,25,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	goto irtdynaIF2917;
irtdynaIF2916:
	local[6]= argv[0];
	local[7]= fqv[30];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)3L);
irtdynaWHL2921:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX2922;
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[51];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= local[7];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SETELT(ctx,3,local+9); /*setelt*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL2921;
irtdynaWHX2922:
	local[9]= NIL;
irtdynaBLK2923:
	w = NIL;
	local[7]= argv[0];
	local[8]= fqv[46];
	local[9]= fqv[47];
	local[10]= argv[0];
	local[11]= fqv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[26];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[25];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)TRANSPOSE(ctx,2,local+8); /*transpose*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[50];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,3,local+7); /*m**/
	local[6]= w;
irtdynaIF2917:
	if (local[0]==NIL) goto irtdynaIF2924;
	local[6]= fqv[57];
	local[7]= argv[0];
	local[8]= fqv[58];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[47];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[51];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[0])(ctx,4,local+6,&ftab[0],fqv[1]); /*warn*/
	local[6]= w;
	goto irtdynaIF2925;
irtdynaIF2924:
	local[6]= NIL;
irtdynaIF2925:
	w = T;
	local[0]= w;
irtdynaBLK2909:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix-column*/
static pointer irtdynaM2926bodyset_link_calc_inertia_matrix_column(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtdynaRST2928:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[59], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2929;
	local[1] = NIL;
irtdynaKEY2929:
	if (n & (1<<1)) goto irtdynaKEY2930;
	local[2] = T;
irtdynaKEY2930:
	if (n & (1<<2)) goto irtdynaKEY2931;
	local[3] = NIL;
irtdynaKEY2931:
	if (n & (1<<3)) goto irtdynaKEY2932;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,3,local+13); /*float-vector*/
	local[4] = w;
irtdynaKEY2932:
	if (n & (1<<4)) goto irtdynaKEY2933;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[5] = w;
irtdynaKEY2933:
	if (n & (1<<5)) goto irtdynaKEY2934;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[6] = w;
irtdynaKEY2934:
	if (n & (1<<6)) goto irtdynaKEY2935;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[7] = w;
irtdynaKEY2935:
	if (n & (1<<7)) goto irtdynaKEY2936;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[8] = w;
irtdynaKEY2936:
	if (n & (1<<8)) goto irtdynaKEY2937;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[9] = w;
irtdynaKEY2937:
	if (n & (1<<9)) goto irtdynaKEY2938;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[10] = w;
irtdynaKEY2938:
	if (n & (1<<10)) goto irtdynaKEY2939;
	local[13]= loadglobal(fqv[43]);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[11] = w;
irtdynaKEY2939:
	if (n & (1<<11)) goto irtdynaKEY2940;
	local[13]= makeint((eusinteger_t)3L);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,2,local+13,&ftab[5],fqv[24]); /*make-matrix*/
	local[12] = w;
irtdynaKEY2940:
	local[13]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	local[14]= local[13];
	if (fqv[61]!=local[14]) goto irtdynaIF2941;
	local[14]= makeint((eusinteger_t)1L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2942;
irtdynaIF2941:
	local[14]= local[13];
	if (fqv[62]!=local[14]) goto irtdynaIF2943;
	local[14]= makeint((eusinteger_t)-1L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2944;
irtdynaIF2943:
	local[14]= local[13];
	if (fqv[63]!=local[14]) goto irtdynaIF2945;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)1L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2946;
irtdynaIF2945:
	local[14]= local[13];
	if (fqv[64]!=local[14]) goto irtdynaIF2947;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)-1L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2948;
irtdynaIF2947:
	local[14]= local[13];
	if (fqv[65]!=local[14]) goto irtdynaIF2949;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)1L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2950;
irtdynaIF2949:
	local[14]= local[13];
	if (fqv[66]!=local[14]) goto irtdynaIF2951;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	goto irtdynaIF2952;
irtdynaIF2951:
	if (T==NIL) goto irtdynaIF2953;
	local[14]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	goto irtdynaIF2954;
irtdynaIF2953:
	local[14]= NIL;
irtdynaIF2954:
irtdynaIF2952:
irtdynaIF2950:
irtdynaIF2948:
irtdynaIF2946:
irtdynaIF2944:
irtdynaIF2942:
	w = local[14];
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= argv[0]->c.obj.iv[9];
	local[16]= fqv[67];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= fqv[68];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= fqv[69];
	local[17]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[70]));
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[9];
	local[17]= fqv[71];
	local[18]= local[3];
	local[19]= local[14];
	local[20]= argv[2];
	local[21]= local[13];
	local[22]= argv[0];
	local[23]= fqv[49];
	local[24]= fqv[47];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,3,local+22); /*send*/
	local[22]= w;
	local[23]= argv[0];
	local[24]= fqv[49];
	local[25]= fqv[51];
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,3,local+23); /*send*/
	local[23]= w;
	local[24]= argv[0];
	local[25]= fqv[49];
	local[26]= fqv[50];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	local[25]= local[4];
	local[26]= local[15];
	local[27]= local[2];
	local[28]= local[1];
	local[29]= local[5];
	local[30]= local[6];
	local[31]= local[7];
	local[32]= local[8];
	local[33]= local[9];
	local[34]= local[10];
	local[35]= local[11];
	local[36]= local[12];
	ctx->vsp=local+37;
	w=(pointer)SEND(ctx,21,local+16); /*send*/
	w = T;
	local[0]= w;
irtdynaBLK2927:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaFLET2888(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[0];
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[72]); /*outer-product-matrix*/
	local[0]= w;
	local[1]= local[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,2,local+1); /*transpose*/
	local[1]= w;
	local[2]= local[0];
	local[3]= env->c.clo.env2[2];
	ctx->vsp=local+4;
	w=(pointer)MATTIMES(ctx,3,local+1); /*m**/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO2904(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[25];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= env->c.clo.env2[3];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,3,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[25];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= env->c.clo.env2[4];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,2,local+1); /*transpose*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:update-mass-properties*/
static pointer irtdynaM2955cascaded_link_update_mass_properties(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[73], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY2957;
	local[5]= loadglobal(fqv[43]);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[0] = w;
irtdynaKEY2957:
	if (n & (1<<1)) goto irtdynaKEY2958;
	local[5]= loadglobal(fqv[43]);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[1] = w;
irtdynaKEY2958:
	if (n & (1<<2)) goto irtdynaKEY2959;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,2,local+5,&ftab[5],fqv[24]); /*make-matrix*/
	local[2] = w;
irtdynaKEY2959:
	if (n & (1<<3)) goto irtdynaKEY2960;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,2,local+5,&ftab[5],fqv[24]); /*make-matrix*/
	local[3] = w;
irtdynaKEY2960:
	if (n & (1<<4)) goto irtdynaKEY2961;
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[5])(ctx,2,local+5,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY2961:
	local[5]= argv[0];
	local[6]= fqv[74];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtdynaCLO2962,env,argv,local);
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,2,local+5,&ftab[9],fqv[75]); /*all-child-links*/
	local[5]= argv[0];
	local[6]= fqv[74];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= fqv[44];
	local[7]= fqv[34];
	local[8]= local[0];
	local[9]= fqv[35];
	local[10]= local[1];
	local[11]= fqv[37];
	local[12]= local[2];
	local[13]= fqv[38];
	local[14]= local[3];
	local[15]= fqv[39];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,12,local+5); /*send*/
	local[0]= w;
irtdynaBLK2956:
	ctx->vsp=local; return(local[0]);}

/*:calc-inertia-matrix-from-link-list*/
static pointer irtdynaM2963cascaded_link_calc_inertia_matrix_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST2965:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[76], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2966;
	local[18]= argv[0]->c.obj.iv[9];
	local[19]= fqv[77];
	ctx->vsp=local+20;
	w=(*ftab[7])(ctx,2,local+18,&ftab[7],fqv[29]); /*send-all*/
	local[1] = w;
irtdynaKEY2966:
	if (n & (1<<1)) goto irtdynaKEY2967;
	local[2] = NIL;
irtdynaKEY2967:
	if (n & (1<<2)) goto irtdynaKEY2968;
	local[3] = T;
irtdynaKEY2968:
	if (n & (1<<3)) goto irtdynaKEY2969;
	local[18]= argv[0];
	local[19]= fqv[78];
	local[20]= local[2];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,4,local+18); /*send*/
	local[4] = w;
irtdynaKEY2969:
	if (n & (1<<4)) goto irtdynaKEY2970;
	local[18]= local[4];
	local[19]= argv[0];
	local[20]= fqv[79];
	local[21]= local[1];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2970:
	if (n & (1<<5)) goto irtdynaKEY2971;
	local[6] = T;
irtdynaKEY2971:
	if (n & (1<<6)) goto irtdynaKEY2972;
	local[7] = NIL;
irtdynaKEY2972:
	if (n & (1<<7)) goto irtdynaKEY2973;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[8] = w;
irtdynaKEY2973:
	if (n & (1<<8)) goto irtdynaKEY2974;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[9] = w;
irtdynaKEY2974:
	if (n & (1<<9)) goto irtdynaKEY2975;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)2L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[10] = w;
irtdynaKEY2975:
	if (n & (1<<10)) goto irtdynaKEY2976;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[11] = w;
irtdynaKEY2976:
	if (n & (1<<11)) goto irtdynaKEY2977;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[12] = w;
irtdynaKEY2977:
	if (n & (1<<12)) goto irtdynaKEY2978;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[13] = w;
irtdynaKEY2978:
	if (n & (1<<13)) goto irtdynaKEY2979;
	local[18]= loadglobal(fqv[43]);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(pointer)INSTANTIATE(ctx,2,local+18); /*instantiate*/
	local[14] = w;
irtdynaKEY2979:
	if (n & (1<<14)) goto irtdynaKEY2980;
	local[18]= makeint((eusinteger_t)3L);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[15] = w;
irtdynaKEY2980:
	if (n & (1<<15)) goto irtdynaKEY2981;
	local[18]= makeint((eusinteger_t)3L);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[16] = w;
irtdynaKEY2981:
	if (n & (1<<16)) goto irtdynaKEY2982;
	local[18]= makeint((eusinteger_t)3L);
	local[19]= makeint((eusinteger_t)3L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	local[17] = w;
irtdynaKEY2982:
	if (local[6]==NIL) goto irtdynaIF2983;
	local[18]= argv[0];
	local[19]= fqv[80];
	local[20]= fqv[34];
	local[21]= local[11];
	local[22]= fqv[35];
	local[23]= local[12];
	local[24]= fqv[37];
	local[25]= local[15];
	local[26]= fqv[38];
	local[27]= local[16];
	local[28]= fqv[39];
	local[29]= local[17];
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,12,local+18); /*send*/
	local[18]= w;
	goto irtdynaIF2984;
irtdynaIF2983:
	local[18]= NIL;
irtdynaIF2984:
	local[18]= NIL;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= makeint((eusinteger_t)0L);
irtdynaTAG2986:
	local[21]= local[20];
	local[22]= local[1];
	ctx->vsp=local+23;
	w=(pointer)LENGTH(ctx,1,local+22); /*length*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)GREQP(ctx,2,local+21); /*>=*/
	if (w==NIL) goto irtdynaIF2987;
	w = NIL;
	ctx->vsp=local+21;
	local[19]=w;
	goto irtdynaBLK2985;
	goto irtdynaIF2988;
irtdynaIF2987:
	local[21]= NIL;
irtdynaIF2988:
	local[21]= local[1];
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= fqv[81];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[18] = w;
	local[21]= (pointer)get_sym_func(fqv[82]);
	local[22]= local[1];
	local[23]= local[20];
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	local[23]= fqv[83];
	local[24]= local[19];
	local[25]= fqv[84];
	local[26]= local[5];
	local[27]= fqv[85];
	if (local[7]==NIL) goto irtdynaIF2989;
	local[28]= local[7];
	goto irtdynaIF2990;
irtdynaIF2989:
	local[28]= argv[0];
	local[29]= fqv[30];
	local[30]= NIL;
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,3,local+28); /*send*/
	local[28]= w;
irtdynaIF2990:
	local[29]= fqv[86];
	local[30]= local[3];
	local[31]= fqv[87];
	local[32]= local[2];
	local[33]= local[0];
	ctx->vsp=local+34;
	w=(pointer)APPLY(ctx,13,local+21); /*apply*/
	local[21]= local[19];
	local[22]= local[18];
	local[23]= fqv[88];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)PLUS(ctx,2,local+21); /*+*/
	local[21]= w;
	local[22]= local[20];
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)PLUS(ctx,2,local+22); /*+*/
	local[22]= w;
	local[19] = local[21];
	local[20] = local[22];
	w = NIL;
	ctx->vsp=local+21;
	goto irtdynaTAG2986;
	w = NIL;
	local[19]= w;
irtdynaBLK2985:
	w = local[19];
	w = local[5];
	local[0]= w;
irtdynaBLK2964:
	ctx->vsp=local; return(local[0]);}

/*:calc-cog-jacobian-from-link-list*/
static pointer irtdynaM2991cascaded_link_calc_cog_jacobian_from_link_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST2993:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[89], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY2994;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= fqv[77];
	ctx->vsp=local+9;
	w=(*ftab[7])(ctx,2,local+7,&ftab[7],fqv[29]); /*send-all*/
	local[1] = w;
irtdynaKEY2994:
	if (n & (1<<1)) goto irtdynaKEY2995;
	local[2] = NIL;
irtdynaKEY2995:
	if (n & (1<<2)) goto irtdynaKEY2996;
	local[3] = T;
irtdynaKEY2996:
	if (n & (1<<3)) goto irtdynaKEY2997;
	local[7]= argv[0];
	local[8]= fqv[78];
	local[9]= local[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[4] = w;
irtdynaKEY2997:
	if (n & (1<<4)) goto irtdynaKEY2998;
	local[7]= local[4];
	local[8]= argv[0];
	local[9]= fqv[79];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,2,local+7,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY2998:
	if (n & (1<<5)) goto irtdynaKEY2999;
	local[6] = T;
irtdynaKEY2999:
	local[7]= makeflt(1.0000000000000000208167e-03);
	local[8]= argv[0];
	local[9]= fqv[20];
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= (pointer)get_sym_func(fqv[82]);
	local[9]= argv[0];
	local[10]= fqv[90];
	local[11]= fqv[80];
	local[12]= NIL;
	local[13]= fqv[84];
	local[14]= local[5];
	local[15]= fqv[91];
	local[16]= local[1];
	local[17]= local[0];
	ctx->vsp=local+18;
	w=(pointer)APPLY(ctx,10,local+8); /*apply*/
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[4];
irtdynaWHL3000:
	local[10]= local[8];
	w = local[9];
	if ((eusinteger_t)local[10] >= (eusinteger_t)w) goto irtdynaWHX3001;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(*ftab[10])(ctx,1,local+11,&ftab[10],fqv[92]); /*array-dimensions*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
irtdynaWHL3003:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3004;
	local[12]= local[5];
	local[13]= local[8];
	local[14]= local[10];
	local[15]= local[5];
	local[16]= local[8];
	local[17]= local[10];
	ctx->vsp=local+18;
	w=(pointer)AREF(ctx,3,local+15); /*aref*/
	local[15]= w;
	local[16]= local[7];
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)ASET(ctx,4,local+12); /*aset*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3003;
irtdynaWHX3004:
	local[12]= NIL;
irtdynaBLK3005:
	w = NIL;
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[8] = w;
	goto irtdynaWHL3000;
irtdynaWHX3001:
	local[10]= NIL;
irtdynaBLK3002:
	w = NIL;
	w = local[5];
	local[0]= w;
irtdynaBLK2992:
	ctx->vsp=local; return(local[0]);}

/*:cog-jacobian-balance-nspace*/
static pointer irtdynaM3006cascaded_link_cog_jacobian_balance_nspace(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtdynaRST3008:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[93], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY3009;
	local[1] = makeflt(1.0000000000000000000000e+00);
irtdynaKEY3009:
	if (n & (1<<1)) goto irtdynaKEY3010;
	local[2] = fqv[65];
irtdynaKEY3010:
	if (n & (1<<2)) goto irtdynaKEY3011;
	local[3] = NIL;
irtdynaKEY3011:
	if (n & (1<<3)) goto irtdynaKEY3012;
	local[4] = NIL;
irtdynaKEY3012:
	if (n & (1<<4)) goto irtdynaKEY3013;
	local[5] = T;
irtdynaKEY3013:
	local[6]= (pointer)get_sym_func(fqv[82]);
	local[7]= argv[0];
	local[8]= fqv[94];
	local[9]= (pointer)get_sym_func(fqv[82]);
	local[10]= argv[0];
	local[11]= fqv[95];
	local[12]= fqv[80];
	local[13]= local[5];
	local[14]= fqv[91];
	local[15]= argv[2];
	local[16]= fqv[86];
	local[17]= local[2];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,10,local+9); /*apply*/
	local[9]= w;
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,5,local+6); /*apply*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= fqv[96];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= fqv[97];
	local[13]= local[4];
	local[14]= fqv[80];
	local[15]= NIL;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,9,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[98];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	if (w==NIL) goto irtdynaIF3014;
	local[8]= fqv[30];
	local[9]= argv[0];
	local[10]= fqv[49];
	local[11]= fqv[98];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[11])(ctx,2,local+8,&ftab[11],fqv[99]); /*assoc*/
	local[8]= w;
	local[9]= local[7];
	local[10]= fqv[30];
	local[11]= argv[0];
	local[12]= fqv[49];
	local[13]= fqv[98];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[11])(ctx,2,local+10,&ftab[11],fqv[99]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)RPLACD2(ctx,2,local+8); /*rplacd2*/
	local[8]= w;
	goto irtdynaIF3015;
irtdynaIF3014:
	local[8]= NIL;
irtdynaIF3015:
	w = local[7];
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TRANSFORM(ctx,2,local+6); /*transform*/
	local[0]= w;
irtdynaBLK3007:
	ctx->vsp=local; return(local[0]);}

/*:calc-vel-for-cog*/
static pointer irtdynaM3016cascaded_link_calc_vel_for_cog(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[100], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3018;
	local[0] = NIL;
irtdynaKEY3018:
	if (n & (1<<1)) goto irtdynaKEY3019;
	local[1] = T;
irtdynaKEY3019:
	local[2]= makeflt(1.0000000000000000208167e-03);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[101];
	local[5]= argv[4];
	local[6]= fqv[97];
	local[7]= local[0];
	local[8]= fqv[86];
	local[9]= argv[3];
	local[10]= fqv[102];
	local[11]= T;
	local[12]= fqv[80];
	local[13]= local[1];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,11,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,2,local+2); /*scale*/
	local[0]= w;
irtdynaBLK3017:
	ctx->vsp=local; return(local[0]);}

/*:difference-cog-position*/
static pointer irtdynaM3020cascaded_link_difference_cog_position(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[103], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3022;
	local[0] = NIL;
irtdynaKEY3022:
	if (n & (1<<1)) goto irtdynaKEY3023;
	local[1] = fqv[65];
irtdynaKEY3023:
	if (n & (1<<2)) goto irtdynaKEY3024;
	local[2] = NIL;
irtdynaKEY3024:
	if (n & (1<<3)) goto irtdynaKEY3025;
	local[3] = T;
irtdynaKEY3025:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto irtdynaIF3026;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)FUNCALL(ctx,1,local+4); /*funcall*/
	local[4]= w;
	goto irtdynaIF3027;
irtdynaIF3026:
	local[4]= argv[0];
	local[5]= fqv[30];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
irtdynaIF3027:
	if (local[2]==NIL) goto irtdynaIF3028;
	local[5]= argv[0];
	local[6]= fqv[46];
	local[7]= fqv[105];
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[105];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= fqv[106];
	local[11]= fqv[107];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,3,local+9); /*list*/
	local[9]= w;
	local[10]= local[4];
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= makeint((eusinteger_t)2L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,3,local+10); /*float-vector*/
	local[10]= w;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)100L);
	local[13]= fqv[106];
	local[14]= fqv[109];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,5,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)APPEND(ctx,2,local+8); /*append*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	goto irtdynaIF3029;
irtdynaIF3028:
	local[5]= NIL;
irtdynaIF3029:
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[3])(ctx,2,local+5,&ftab[3],fqv[6]); /*calc-dif-with-axis*/
	local[0]= w;
irtdynaBLK3021:
	ctx->vsp=local; return(local[0]);}

/*:cog-convergence-check*/
static pointer irtdynaM3030cascaded_link_cog_convergence_check(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[110], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3032;
	local[0] = NIL;
irtdynaKEY3032:
	if (n & (1<<1)) goto irtdynaKEY3033;
	local[1] = fqv[65];
irtdynaKEY3033:
	if (n & (1<<2)) goto irtdynaKEY3034;
	local[2] = T;
irtdynaKEY3034:
	local[3]= argv[0];
	local[4]= fqv[101];
	local[5]= argv[3];
	local[6]= fqv[97];
	local[7]= local[0];
	local[8]= fqv[86];
	local[9]= local[1];
	local[10]= fqv[80];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,9,local+3); /*send*/
	local[3]= w;
	w = argv[2];
	if (!numberp(w)) goto irtdynaCON3036;
	local[4]= argv[2];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)VNORM(ctx,1,local+5); /*norm*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	local[4]= w;
	goto irtdynaCON3035;
irtdynaCON3036:
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,1,local+4,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto irtdynaCON3037;
	local[4]= argv[2];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,2,local+4); /*funcall*/
	local[4]= w;
	goto irtdynaCON3035;
irtdynaCON3037:
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)VECTORP(ctx,1,local+4); /*vectorp*/
	if (w==NIL) goto irtdynaCON3038;
	local[4]= loadglobal(fqv[43]);
	local[5]= (pointer)get_sym_func(fqv[111]);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MAP(ctx,3,local+4); /*map*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)VLESSP(ctx,2,local+4); /*v<*/
	local[4]= w;
	goto irtdynaCON3035;
irtdynaCON3038:
	local[4]= NIL;
irtdynaCON3035:
	w = local[4];
	local[0]= w;
irtdynaBLK3031:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO2962(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[47];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3039:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3040;
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= fqv[51];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3039;
irtdynaWHX3040:
	local[2]= NIL;
irtdynaBLK3041:
	w = NIL;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3042:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3043;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)3L);
irtdynaWHL3045:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtdynaWHX3046;
	local[4]= argv[0];
	local[5]= fqv[49];
	local[6]= fqv[50];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= local[2];
	local[6]= local[0];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)ASET(ctx,4,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtdynaWHL3045;
irtdynaWHX3046:
	local[4]= NIL;
irtdynaBLK3047:
	w = NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3042;
irtdynaWHX3043:
	local[2]= NIL;
irtdynaBLK3044:
	w = NIL;
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-velocity-jacobian*/
static pointer irtdynaM3048joint_calc_spacial_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3050:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[112];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3049:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-velocity-jacobian*/
static pointer irtdynaM3051joint_calc_angular_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3053:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[113];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3052:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-acceleration-jacobian*/
static pointer irtdynaM3054joint_calc_spacial_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3056:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[114];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3055:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-acceleration-jacobian*/
static pointer irtdynaM3057joint_calc_angular_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3059:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= fqv[115];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,2,local+1,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3058:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-velocity-jacobian*/
static pointer irtdynaM3060rotational_joint_calc_spacial_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)SCALEVEC(ctx,3,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
irtdynaBLK3061:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-velocity-jacobian*/
static pointer irtdynaM3062rotational_joint_calc_angular_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3064:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3065;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3064;
irtdynaWHX3065:
	local[2]= NIL;
irtdynaBLK3066:
	w = NIL;
	w = argv[3];
	local[0]= w;
irtdynaBLK3063:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-acceleration-jacobian*/
static pointer irtdynaM3067rotational_joint_calc_spacial_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[4];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= fqv[117];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[3];
	local[3]= argv[5];
	ctx->vsp=local+4;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+1); /*v**/
	local[1]= w;
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)VPLUS(ctx,3,local+0); /*v+*/
	local[0]= w;
irtdynaBLK3068:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-acceleration-jacobian*/
static pointer irtdynaM3069rotational_joint_calc_angular_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
irtdynaBLK3070:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-velocity-jacobian*/
static pointer irtdynaM3071linear_joint_calc_spacial_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3073:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3074;
	local[2]= argv[4];
	local[3]= local[0];
	local[4]= argv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3073;
irtdynaWHX3074:
	local[2]= NIL;
irtdynaBLK3075:
	w = NIL;
	w = argv[4];
	local[0]= w;
irtdynaBLK3072:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-velocity-jacobian*/
static pointer irtdynaM3076linear_joint_calc_angular_velocity_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3078:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3079;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3078;
irtdynaWHX3079:
	local[2]= NIL;
irtdynaBLK3080:
	w = NIL;
	w = argv[3];
	local[0]= w;
irtdynaBLK3077:
	ctx->vsp=local; return(local[0]);}

/*:calc-spacial-acceleration-jacobian*/
static pointer irtdynaM3081linear_joint_calc_spacial_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[116];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+0); /*v**/
	local[0]= w;
irtdynaBLK3082:
	ctx->vsp=local; return(local[0]);}

/*:calc-angular-acceleration-jacobian*/
static pointer irtdynaM3083linear_joint_calc_angular_acceleration_jacobian(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)3L);
irtdynaWHL3085:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3086;
	local[2]= argv[3];
	local[3]= local[0];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SETELT(ctx,3,local+2); /*setelt*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3085;
irtdynaWHX3086:
	local[2]= NIL;
irtdynaBLK3087:
	w = NIL;
	w = argv[3];
	local[0]= w;
irtdynaBLK3084:
	ctx->vsp=local; return(local[0]);}

/*:reset-dynamics*/
static pointer irtdynaM3088bodyset_link_reset_dynamics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[47];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[51];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[50];
	local[3]= makeint((eusinteger_t)3L);
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(*ftab[5])(ctx,2,local+3,&ftab[5],fqv[24]); /*make-matrix*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[17] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[18] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[19] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[20] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[24] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[23] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[22] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[21] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[25] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[26] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[27] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	argv[0]->c.obj.iv[28] = w;
	w = argv[0]->c.obj.iv[28];
	local[0]= w;
irtdynaBLK3089:
	ctx->vsp=local; return(local[0]);}

/*:angular-velocity*/
static pointer irtdynaM3090bodyset_link_angular_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3093;}
	local[0]= NIL;
irtdynaENT3093:
irtdynaENT3092:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3094;
	argv[0]->c.obj.iv[17] = local[0];
	local[1]= argv[0]->c.obj.iv[17];
	goto irtdynaIF3095;
irtdynaIF3094:
	local[1]= argv[0]->c.obj.iv[17];
irtdynaIF3095:
	w = local[1];
	local[0]= w;
irtdynaBLK3091:
	ctx->vsp=local; return(local[0]);}

/*:angular-acceleration*/
static pointer irtdynaM3096bodyset_link_angular_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3099;}
	local[0]= NIL;
irtdynaENT3099:
irtdynaENT3098:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3100;
	argv[0]->c.obj.iv[18] = local[0];
	local[1]= argv[0]->c.obj.iv[18];
	goto irtdynaIF3101;
irtdynaIF3100:
	local[1]= argv[0]->c.obj.iv[18];
irtdynaIF3101:
	w = local[1];
	local[0]= w;
irtdynaBLK3097:
	ctx->vsp=local; return(local[0]);}

/*:spacial-velocity*/
static pointer irtdynaM3102bodyset_link_spacial_velocity(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3105;}
	local[0]= NIL;
irtdynaENT3105:
irtdynaENT3104:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3106;
	argv[0]->c.obj.iv[19] = local[0];
	local[1]= argv[0]->c.obj.iv[19];
	goto irtdynaIF3107;
irtdynaIF3106:
	local[1]= argv[0]->c.obj.iv[19];
irtdynaIF3107:
	w = local[1];
	local[0]= w;
irtdynaBLK3103:
	ctx->vsp=local; return(local[0]);}

/*:spacial-acceleration*/
static pointer irtdynaM3108bodyset_link_spacial_acceleration(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3111;}
	local[0]= NIL;
irtdynaENT3111:
irtdynaENT3110:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3112;
	argv[0]->c.obj.iv[20] = local[0];
	local[1]= argv[0]->c.obj.iv[20];
	goto irtdynaIF3113;
irtdynaIF3112:
	local[1]= argv[0]->c.obj.iv[20];
irtdynaIF3113:
	w = local[1];
	local[0]= w;
irtdynaBLK3109:
	ctx->vsp=local; return(local[0]);}

/*:force*/
static pointer irtdynaM3114bodyset_link_force(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[25];
	local[0]= w;
irtdynaBLK3115:
	ctx->vsp=local; return(local[0]);}

/*:moment*/
static pointer irtdynaM3116bodyset_link_moment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[26];
	local[0]= w;
irtdynaBLK3117:
	ctx->vsp=local; return(local[0]);}

/*:ext-force*/
static pointer irtdynaM3118bodyset_link_ext_force(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3121;}
	local[0]= NIL;
irtdynaENT3121:
irtdynaENT3120:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3122;
	argv[0]->c.obj.iv[27] = local[0];
	local[1]= argv[0]->c.obj.iv[27];
	goto irtdynaIF3123;
irtdynaIF3122:
	local[1]= argv[0]->c.obj.iv[27];
irtdynaIF3123:
	w = local[1];
	local[0]= w;
irtdynaBLK3119:
	ctx->vsp=local; return(local[0]);}

/*:ext-moment*/
static pointer irtdynaM3124bodyset_link_ext_moment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3127;}
	local[0]= NIL;
irtdynaENT3127:
irtdynaENT3126:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3128;
	argv[0]->c.obj.iv[28] = local[0];
	local[1]= argv[0]->c.obj.iv[28];
	goto irtdynaIF3129;
irtdynaIF3128:
	local[1]= argv[0]->c.obj.iv[28];
irtdynaIF3129:
	w = local[1];
	local[0]= w;
irtdynaBLK3125:
	ctx->vsp=local; return(local[0]);}

/*:forward-all-kinematics*/
static pointer irtdynaM3130bodyset_link_forward_all_kinematics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[118], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3132;
	local[0] = NIL;
irtdynaKEY3132:
	if (n & (1<<1)) goto irtdynaKEY3133;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[1] = w;
irtdynaKEY3133:
	if (local[0]==NIL) goto irtdynaIF3134;
	local[2]= T;
	local[3]= fqv[119];
	local[4]= argv[0];
	local[5]= fqv[58];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)XFORMAT(ctx,3,local+2); /*format*/
	local[2]= w;
	goto irtdynaIF3135;
irtdynaIF3134:
	local[2]= NIL;
irtdynaIF3135:
	if (argv[0]->c.obj.iv[10]==NIL) goto irtdynaIF3136;
	local[2]= argv[0];
	local[3]= fqv[120];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= loadglobal(fqv[121]);
	ctx->vsp=local+4;
	w=(pointer)DERIVEDP(ctx,2,local+2); /*derivedp*/
	if (w==NIL) goto irtdynaIF3136;
	local[2]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	local[3]= local[2];
	if (fqv[61]!=local[3]) goto irtdynaIF3138;
	local[3]= fqv[122];
	goto irtdynaIF3139;
irtdynaIF3138:
	local[3]= local[2];
	if (fqv[63]!=local[3]) goto irtdynaIF3140;
	local[3]= fqv[123];
	goto irtdynaIF3141;
irtdynaIF3140:
	local[3]= local[2];
	if (fqv[65]!=local[3]) goto irtdynaIF3142;
	local[3]= fqv[124];
	goto irtdynaIF3143;
irtdynaIF3142:
	local[3]= local[2];
	if (fqv[125]!=local[3]) goto irtdynaIF3144;
	local[3]= fqv[126];
	goto irtdynaIF3145;
irtdynaIF3144:
	local[3]= local[2];
	if (fqv[127]!=local[3]) goto irtdynaIF3146;
	local[3]= fqv[128];
	goto irtdynaIF3147;
irtdynaIF3146:
	local[3]= local[2];
	if (fqv[129]!=local[3]) goto irtdynaIF3148;
	local[3]= fqv[130];
	goto irtdynaIF3149;
irtdynaIF3148:
	local[3]= local[2];
	if (fqv[62]!=local[3]) goto irtdynaIF3150;
	local[3]= fqv[131];
	goto irtdynaIF3151;
irtdynaIF3150:
	local[3]= local[2];
	if (fqv[64]!=local[3]) goto irtdynaIF3152;
	local[3]= fqv[132];
	goto irtdynaIF3153;
irtdynaIF3152:
	local[3]= local[2];
	if (fqv[66]!=local[3]) goto irtdynaIF3154;
	local[3]= fqv[133];
	goto irtdynaIF3155;
irtdynaIF3154:
	if (T==NIL) goto irtdynaIF3156;
	local[3]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[60]));
	goto irtdynaIF3157;
irtdynaIF3156:
	local[3]= NIL;
irtdynaIF3157:
irtdynaIF3155:
irtdynaIF3153:
irtdynaIF3151:
irtdynaIF3149:
irtdynaIF3147:
irtdynaIF3145:
irtdynaIF3143:
irtdynaIF3141:
irtdynaIF3139:
	w = local[3];
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[10];
	local[4]= fqv[68];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[69];
	local[5]= *(ovafptr(argv[0]->c.obj.iv[9],fqv[70]));
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[2];
	local[5]= local[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[49];
	local[6]= fqv[134];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[3]); /*normalize-vector*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[9];
	local[5]= fqv[135];
	local[6]= local[3];
	local[7]= local[1];
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[136];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,5,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[9];
	local[6]= fqv[137];
	local[7]= local[3];
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[134];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[10];
	local[7]= fqv[116];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= fqv[138];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[5];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[17];
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,3,local+6); /*v+*/
	argv[0]->c.obj.iv[17] = w;
	local[6]= argv[0]->c.obj.iv[10];
	local[7]= fqv[117];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= fqv[138];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= local[4];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,3,local+7); /*scale*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)VPLUS(ctx,3,local+6); /*v+*/
	argv[0]->c.obj.iv[19] = w;
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= fqv[139];
	local[8]= local[4];
	local[9]= local[5];
	local[10]= local[1];
	local[11]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,6,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[10];
	local[8]= fqv[140];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[138];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[6];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[141];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[4];
	local[10]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	argv[0]->c.obj.iv[20] = w;
	w = argv[0]->c.obj.iv[20];
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= fqv[142];
	local[8]= local[5];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[10];
	local[8]= fqv[143];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[138];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[6];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[141];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[5];
	local[10]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,3,local+8); /*scale*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+10;
	w=(pointer)VPLUS(ctx,3,local+7); /*v+*/
	argv[0]->c.obj.iv[18] = w;
	w = argv[0]->c.obj.iv[18];
	local[2]= w;
	goto irtdynaIF3137;
irtdynaIF3136:
	local[2]= NIL;
irtdynaIF3137:
	local[2]= argv[0]->c.obj.iv[11];
	local[3]= fqv[144];
	local[4]= fqv[45];
	local[5]= local[0];
	local[6]= fqv[34];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,6,local+2,&ftab[7],fqv[29]); /*send-all*/
	local[0]= w;
irtdynaBLK3131:
	ctx->vsp=local; return(local[0]);}

/*:inverse-dynamics*/
static pointer irtdynaM3158bodyset_link_inverse_dynamics(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[145], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3160;
	local[0] = NIL;
irtdynaKEY3160:
	if (n & (1<<1)) goto irtdynaKEY3161;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[1] = w;
irtdynaKEY3161:
	if (n & (1<<2)) goto irtdynaKEY3162;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[2] = w;
irtdynaKEY3162:
	if (n & (1<<3)) goto irtdynaKEY3163;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[3] = w;
irtdynaKEY3163:
	if (n & (1<<4)) goto irtdynaKEY3164;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY3164:
	if (n & (1<<5)) goto irtdynaKEY3165;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY3165:
	if (n & (1<<6)) goto irtdynaKEY3166;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[6] = w;
irtdynaKEY3166:
	if (n & (1<<7)) goto irtdynaKEY3167;
	local[8]= makeint((eusinteger_t)3L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(*ftab[5])(ctx,2,local+8,&ftab[5],fqv[24]); /*make-matrix*/
	local[7] = w;
irtdynaKEY3167:
	if (local[0]==NIL) goto irtdynaIF3168;
	local[8]= T;
	local[9]= fqv[146];
	local[10]= argv[0];
	local[11]= fqv[58];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,3,local+8); /*format*/
	local[8]= w;
	goto irtdynaIF3169;
irtdynaIF3168:
	local[8]= NIL;
irtdynaIF3169:
	local[8]= makeflt(1.0000000000000000208167e-03);
	local[9]= argv[0];
	local[10]= fqv[20];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,2,local+8); /***/
	local[8]= w;
	local[9]= makeflt(-1.0000000000000000000000e+00);
	local[10]= local[8];
	local[11]= makeflt(1.0000000000000000208167e-03);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,3,local+9); /***/
	local[9]= w;
	local[10]= loadglobal(fqv[147]);
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,3,local+9); /*scale*/
	local[9]= w;
	local[10]= makeflt(1.0000000000000000208167e-03);
	local[11]= argv[0];
	local[12]= fqv[30];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,3,local+10); /*scale*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[25];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= makeflt(9.9999999999999985548644e-10);
	local[13]= argv[0];
	local[14]= fqv[26];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,3,local+12,&ftab[2],fqv[4]); /*scale-matrix*/
	local[12]= w;
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(pointer)MATTIMES(ctx,3,local+11); /*m**/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[25];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= local[6];
	ctx->vsp=local+14;
	w=(pointer)TRANSPOSE(ctx,2,local+12); /*transpose*/
	local[12]= w;
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)MATTIMES(ctx,3,local+11); /*m**/
	local[11]= w;
	local[12]= local[10];
	local[13]= local[5];
	ctx->vsp=local+14;
	w=(*ftab[8])(ctx,2,local+12,&ftab[8],fqv[72]); /*outer-product-matrix*/
	local[12]= w;
	local[13]= local[11];
	local[14]= local[8];
	local[15]= local[12];
	local[16]= local[12];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)TRANSPOSE(ctx,2,local+16); /*transpose*/
	local[16]= w;
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)MATTIMES(ctx,3,local+15); /*m**/
	local[15]= w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(*ftab[2])(ctx,3,local+14,&ftab[2],fqv[4]); /*scale-matrix*/
	local[14]= w;
	local[15]= local[5];
	ctx->vsp=local+16;
	w=(*ftab[6])(ctx,3,local+13,&ftab[6],fqv[27]); /*m+*/
	local[13]= w;
	local[14]= local[8];
	local[15]= argv[0]->c.obj.iv[19];
	local[16]= argv[0]->c.obj.iv[17];
	local[17]= local[10];
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+16); /*v**/
	local[16]= w;
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	argv[0]->c.obj.iv[23] = w;
	local[14]= local[8];
	local[15]= local[10];
	local[16]= argv[0]->c.obj.iv[19];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	local[14]= w;
	local[15]= local[13];
	local[16]= argv[0]->c.obj.iv[17];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)TRANSFORM(ctx,3,local+15); /*transform*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	argv[0]->c.obj.iv[24] = w;
	local[14]= local[8];
	local[15]= argv[0]->c.obj.iv[20];
	local[16]= argv[0]->c.obj.iv[18];
	local[17]= local[10];
	local[18]= local[3];
	ctx->vsp=local+19;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+16); /*v**/
	local[16]= w;
	local[17]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[17];
	local[16]= argv[0]->c.obj.iv[23];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	argv[0]->c.obj.iv[25] = w;
	local[14]= local[8];
	local[15]= local[10];
	local[16]= argv[0]->c.obj.iv[20];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)SCALEVEC(ctx,3,local+14); /*scale*/
	local[14]= w;
	local[15]= local[13];
	local[16]= argv[0]->c.obj.iv[18];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)TRANSFORM(ctx,3,local+15); /*transform*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[19];
	local[16]= argv[0]->c.obj.iv[23];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[17];
	local[16]= argv[0]->c.obj.iv[24];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VPLUS(ctx,3,local+14); /*v+*/
	argv[0]->c.obj.iv[26] = w;
	local[14]= argv[0]->c.obj.iv[25];
	local[15]= local[9];
	local[16]= argv[0]->c.obj.iv[27];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,3,local+14); /*v-*/
	argv[0]->c.obj.iv[25] = w;
	local[14]= argv[0]->c.obj.iv[26];
	local[15]= local[10];
	local[16]= local[9];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)VCROSSPRODUCT(ctx,3,local+15); /*v**/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[28];
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)VPLUS(ctx,3,local+15); /*v+*/
	local[15]= w;
	local[16]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,3,local+14); /*v-*/
	argv[0]->c.obj.iv[26] = w;
	w = argv[0]->c.obj.iv[26];
	local[8]= NIL;
	local[9]= argv[0]->c.obj.iv[11];
irtdynaWHL3170:
	if (local[9]==NIL) goto irtdynaWHX3171;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	w=local[9];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9] = (w)->c.cons.cdr;
	w = local[10];
	local[8] = w;
	local[10]= local[8];
	local[11]= fqv[148];
	local[12]= fqv[45];
	local[13]= local[0];
	local[14]= fqv[34];
	local[15]= local[1];
	local[16]= fqv[35];
	local[17]= local[2];
	local[18]= fqv[149];
	local[19]= local[3];
	local[20]= fqv[37];
	local[21]= local[4];
	local[22]= fqv[38];
	local[23]= local[5];
	local[24]= fqv[39];
	local[25]= local[6];
	local[26]= fqv[40];
	local[27]= local[7];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,18,local+10); /*send*/
	local[10]= argv[0]->c.obj.iv[25];
	local[11]= local[8];
	local[12]= fqv[150];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,3,local+10); /*v+*/
	argv[0]->c.obj.iv[25] = w;
	local[10]= argv[0]->c.obj.iv[26];
	local[11]= local[8];
	local[12]= fqv[151];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+13;
	w=(pointer)VPLUS(ctx,3,local+10); /*v+*/
	argv[0]->c.obj.iv[26] = w;
	goto irtdynaWHL3170;
irtdynaWHX3171:
	local[10]= NIL;
irtdynaBLK3172:
	w = NIL;
	if (argv[0]->c.obj.iv[9]==NIL) goto irtdynaIF3173;
	if (argv[0]->c.obj.iv[10]==NIL) goto irtdynaIF3173;
	local[8]= argv[0];
	local[9]= fqv[120];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= loadglobal(fqv[121]);
	ctx->vsp=local+10;
	w=(pointer)DERIVEDP(ctx,2,local+8); /*derivedp*/
	if (w==NIL) goto irtdynaIF3173;
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= fqv[152];
	local[10]= argv[0];
	local[11]= fqv[49];
	local[12]= fqv[136];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+12;
	w=(pointer)VINNERPRODUCT(ctx,2,local+10); /*v.*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[49];
	local[13]= fqv[134];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[26];
	ctx->vsp=local+13;
	w=(pointer)VINNERPRODUCT(ctx,2,local+11); /*v.*/
	{ double x,y;
		y=fltval(w); x=fltval(local[10]);
		local[10]=(makeflt(x + y));}
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3174;
irtdynaIF3173:
	local[8]= NIL;
irtdynaIF3174:
	w = local[8];
	local[0]= w;
irtdynaBLK3159:
	ctx->vsp=local; return(local[0]);}

/*:max-torque-vector*/
static pointer irtdynaM3175cascaded_link_max_torque_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	local[1]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,1,local+1,&ftab[13],fqv[153]); /*calc-target-joint-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,2,local+0); /*instantiate*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[9];
irtdynaWHL3177:
	if (local[3]==NIL) goto irtdynaWHX3178;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	local[6]= fqv[88];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
irtdynaWHL3180:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtdynaWHX3181;
	local[6]= local[0];
	local[7]= local[1];
	local[8]= local[2];
	local[9]= fqv[88];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[8];
	if (fqv[154]!=local[9]) goto irtdynaIF3183;
	local[9]= local[2];
	local[10]= fqv[155];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	goto irtdynaIF3184;
irtdynaIF3183:
	if (T==NIL) goto irtdynaIF3185;
	local[9]= local[2];
	local[10]= fqv[155];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	goto irtdynaIF3186;
irtdynaIF3185:
	local[9]= NIL;
irtdynaIF3186:
irtdynaIF3184:
	w = local[9];
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[1] = w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtdynaWHL3180;
irtdynaWHX3181:
	local[6]= NIL;
irtdynaBLK3182:
	w = NIL;
	goto irtdynaWHL3177;
irtdynaWHX3178:
	local[4]= NIL;
irtdynaBLK3179:
	w = NIL;
	w = local[0];
	local[0]= w;
irtdynaBLK3176:
	ctx->vsp=local; return(local[0]);}

/*:torque-ratio-vector*/
static pointer irtdynaM3187cascaded_link_torque_ratio_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtdynaRST3189:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[156], &argv[2], n-2, local+1, 0);
	if (n & (1<<0)) goto irtdynaKEY3190;
	local[2]= (pointer)get_sym_func(fqv[82]);
	local[3]= argv[0];
	local[4]= fqv[157];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,4,local+2); /*apply*/
	local[1] = w;
irtdynaKEY3190:
	local[2]= argv[0];
	local[3]= fqv[158];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= loadglobal(fqv[43]);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
irtdynaWHL3191:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto irtdynaWHX3192;
	local[6]= local[3];
	local[7]= local[4];
	local[8]= local[1];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SETELT(ctx,3,local+6); /*setelt*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto irtdynaWHL3191;
irtdynaWHX3192:
	local[6]= NIL;
irtdynaBLK3193:
	w = NIL;
	w = local[3];
	local[0]= w;
irtdynaBLK3188:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-buffer-args*/
static pointer irtdynaM3194cascaded_link_calc_torque_buffer_args(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[34];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	local[2]= fqv[35];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	local[4]= fqv[149];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,3,local+5); /*float-vector*/
	local[5]= w;
	local[6]= fqv[37];
	local[7]= makeint((eusinteger_t)3L);
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,2,local+7,&ftab[5],fqv[24]); /*make-matrix*/
	local[7]= w;
	local[8]= fqv[38];
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(*ftab[5])(ctx,2,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[9]= w;
	local[10]= fqv[39];
	local[11]= makeint((eusinteger_t)3L);
	local[12]= makeint((eusinteger_t)3L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[11]= w;
	local[12]= fqv[40];
	local[13]= makeint((eusinteger_t)3L);
	local[14]= makeint((eusinteger_t)3L);
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,2,local+13,&ftab[5],fqv[24]); /*make-matrix*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,14,local+0); /*list*/
	local[0]= w;
irtdynaBLK3195:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque*/
static pointer irtdynaM3196cascaded_link_calc_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[159], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3198;
	local[0] = NIL;
irtdynaKEY3198:
	if (n & (1<<1)) goto irtdynaKEY3199;
	local[1] = T;
irtdynaKEY3199:
	if (n & (1<<2)) goto irtdynaKEY3200;
	local[2] = makeflt(4.9999999999999975019982e-03);
irtdynaKEY3200:
	if (n & (1<<3)) goto irtdynaKEY3201;
	local[9]= argv[0];
	local[10]= fqv[160];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[3] = w;
irtdynaKEY3201:
	if (n & (1<<4)) goto irtdynaKEY3202;
	local[9]= argv[0];
	local[10]= fqv[74];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= fqv[68];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[4] = w;
irtdynaKEY3202:
	if (n & (1<<5)) goto irtdynaKEY3203;
	local[5] = NIL;
irtdynaKEY3203:
	if (n & (1<<6)) goto irtdynaKEY3204;
	local[6] = NIL;
irtdynaKEY3204:
	if (n & (1<<7)) goto irtdynaKEY3205;
	local[7] = NIL;
irtdynaKEY3205:
	if (n & (1<<8)) goto irtdynaKEY3206;
	local[9]= argv[0];
	local[10]= fqv[161];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[8] = w;
irtdynaKEY3206:
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)NUMEQUAL(ctx,3,local+9); /*=*/
	if (w!=NIL) goto irtdynaIF3207;
	local[9]= fqv[162];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)LENGTH(ctx,1,local+10); /*length*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)LENGTH(ctx,1,local+12); /*length*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SIGERROR(ctx,4,local+9); /*error*/
	local[9]= w;
	goto irtdynaIF3208;
irtdynaIF3207:
	local[9]= NIL;
irtdynaIF3208:
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3209,env,argv,local);
	local[10]= local[5];
	local[11]= local[6];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,4,local+9); /*mapcar*/
	local[9]= argv[0];
	local[10]= fqv[163];
	local[11]= fqv[45];
	local[12]= local[0];
	local[13]= fqv[164];
	local[14]= local[1];
	local[15]= fqv[165];
	local[16]= local[3];
	local[17]= fqv[166];
	local[18]= local[4];
	local[19]= fqv[167];
	local[20]= local[2];
	local[21]= fqv[161];
	local[22]= local[8];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,14,local+9); /*send*/
	local[0]= w;
irtdynaBLK3197:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-without-ext-wrench*/
static pointer irtdynaM3210cascaded_link_calc_torque_without_ext_wrench(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[168], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3212;
	local[0] = NIL;
irtdynaKEY3212:
	if (n & (1<<1)) goto irtdynaKEY3213;
	local[1] = T;
irtdynaKEY3213:
	if (n & (1<<2)) goto irtdynaKEY3214;
	local[2] = makeflt(4.9999999999999975019982e-03);
irtdynaKEY3214:
	if (n & (1<<3)) goto irtdynaKEY3215;
	local[6]= argv[0];
	local[7]= fqv[160];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[3] = w;
irtdynaKEY3215:
	if (n & (1<<4)) goto irtdynaKEY3216;
	local[6]= argv[0];
	local[7]= fqv[74];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[68];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[4] = w;
irtdynaKEY3216:
	if (n & (1<<5)) goto irtdynaKEY3217;
	local[6]= argv[0];
	local[7]= fqv[161];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[5] = w;
irtdynaKEY3217:
	local[6]= (pointer)get_sym_func(fqv[82]);
	local[7]= argv[0];
	local[8]= fqv[169];
	local[9]= fqv[45];
	local[10]= local[0];
	local[11]= fqv[161];
	local[12]= local[5];
	if (local[1]!=NIL) goto irtdynaIF3218;
	local[13]= argv[0];
	local[14]= fqv[170];
	local[15]= local[2];
	local[16]= local[4];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[171];
	local[16]= local[2];
	local[17]= local[3];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= w;
	local[15]= fqv[172];
	local[16]= fqv[173];
	w = local[14];
	w=memq(local[16],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	local[17]= fqv[174];
	local[18]= fqv[175];
	w = local[14];
	w=memq(local[18],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[18]= (w)->c.cons.car;
	local[19]= fqv[176];
	local[20]= fqv[176];
	w = local[13];
	w=memq(local[20],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[177];
	local[22]= fqv[177];
	w = local[13];
	w=memq(local[22],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	local[23]= fqv[178];
	local[24]= fqv[178];
	w = local[13];
	w=memq(local[24],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.car;
	local[25]= fqv[179];
	local[26]= fqv[179];
	w = local[13];
	w=memq(local[26],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[26]= (w)->c.cons.car;
	ctx->vsp=local+27;
	w=(pointer)LIST(ctx,12,local+15); /*list*/
	local[13]= w;
	goto irtdynaIF3219;
irtdynaIF3218:
	local[13]= NIL;
irtdynaIF3219:
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,8,local+6); /*apply*/
	local[0]= w;
irtdynaBLK3211:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-from-vel-acc*/
static pointer irtdynaM3220cascaded_link_calc_torque_from_vel_acc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[180], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3222;
	local[0] = NIL;
irtdynaKEY3222:
	if (n & (1<<1)) goto irtdynaKEY3223;
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[1] = w;
irtdynaKEY3223:
	if (n & (1<<2)) goto irtdynaKEY3224;
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[2] = w;
irtdynaKEY3224:
	if (n & (1<<3)) goto irtdynaKEY3225;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[3] = w;
irtdynaKEY3225:
	if (n & (1<<4)) goto irtdynaKEY3226;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[4] = w;
irtdynaKEY3226:
	if (n & (1<<5)) goto irtdynaKEY3227;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[5] = w;
irtdynaKEY3227:
	if (n & (1<<6)) goto irtdynaKEY3228;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[6] = w;
irtdynaKEY3228:
	if (n & (1<<7)) goto irtdynaKEY3229;
	local[8]= argv[0];
	local[9]= fqv[161];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[7] = w;
irtdynaKEY3229:
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[8]= w;
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3230,env,argv,local);
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= fqv[181];
	local[12]= fqv[182];
	ctx->vsp=local+13;
	w=(*ftab[7])(ctx,3,local+10,&ftab[7],fqv[29]); /*send-all*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3231,env,argv,local);
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,2,local+10,&ftab[9],fqv[75]); /*all-child-links*/
	local[10]= makeint((eusinteger_t)0L);
	local[11]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtdynaWHL3232:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3233;
	local[12]= argv[0]->c.obj.iv[9];
	local[13]= local[10];
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[12];
	local[14]= fqv[138];
	local[15]= local[1];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= local[12];
	local[14]= fqv[141];
	local[15]= local[2];
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)ELT(ctx,2,local+15); /*elt*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3232;
irtdynaWHX3233:
	local[12]= NIL;
irtdynaBLK3234:
	w = NIL;
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[140];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[143];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[117];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	local[11]= fqv[116];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= (pointer)get_sym_func(fqv[82]);
	local[11]= argv[0];
	local[12]= fqv[74];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[144];
	local[13]= fqv[45];
	local[14]= local[0];
	local[15]= local[7];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(pointer)SUBSEQ(ctx,3,local+15); /*subseq*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,6,local+10); /*apply*/
	local[10]= (pointer)get_sym_func(fqv[82]);
	local[11]= argv[0];
	local[12]= fqv[74];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	local[12]= fqv[148];
	local[13]= fqv[45];
	local[14]= local[0];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(pointer)APPLY(ctx,6,local+10); /*apply*/
	local[10]= argv[0];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3235,env,argv,local);
	ctx->vsp=local+12;
	w=(*ftab[9])(ctx,2,local+10,&ftab[9],fqv[75]); /*all-child-links*/
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtdynaWHL3236:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3237;
	local[12]= local[8];
	local[13]= local[10];
	local[14]= argv[0]->c.obj.iv[9];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= fqv[152];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3236;
irtdynaWHX3237:
	local[12]= NIL;
irtdynaBLK3238:
	w = NIL;
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,irtdynaCLO3239,env,argv,local);
	local[11]= argv[0];
	local[12]= fqv[74];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,3,local+10); /*mapcar*/
	w = local[8];
	local[0]= w;
irtdynaBLK3221:
	ctx->vsp=local; return(local[0]);}

/*:calc-root-coords-vel-acc-from-pos*/
static pointer irtdynaM3240cascaded_link_calc_root_coords_vel_acc_from_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaFLET3242,env,argv,local);
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= fqv[183];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	if (w==NIL) goto irtdynaIF3243;
	local[2]= argv[0];
	local[3]= fqv[49];
	local[4]= fqv[183];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto irtdynaIF3244;
irtdynaIF3243:
	local[2]= argv[3];
irtdynaIF3244:
	local[3]= local[1];
	local[4]= local[2];
	local[5]= fqv[2];
	local[6]= local[2];
	local[7]= fqv[25];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TRANSPOSE(ctx,1,local+6); /*transpose*/
	local[6]= w;
	local[7]= argv[3];
	local[8]= fqv[25];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	w = local[0];
	ctx->vsp=local+7;
	w=irtdynaFLET3242(ctx,1,local+6,w);
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[3];
	local[6]= fqv[5];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000208167e-03);
	local[6]= local[2];
	local[7]= fqv[5];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SCALEVEC(ctx,2,local+5); /*scale*/
	local[5]= w;
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VNORM(ctx,1,local+6); /*norm*/
	local[6]= w;
	local[7]= makeflt(0.0000000000000000000000e+00);
	local[8]= makeflt(4.9999999999999975019982e-03);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,3,local+6,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3245;
	local[6]= local[1];
	local[7]= local[4];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)VMINUS(ctx,2,local+7); /*v-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SCALEVEC(ctx,2,local+6); /*scale*/
	local[6]= w;
	goto irtdynaIF3246;
irtdynaIF3245:
	local[6]= local[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+6); /*v**/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)VNORM(ctx,1,local+7); /*norm*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(*ftab[14])(ctx,1,local+8,&ftab[14],fqv[184]); /*unit-matrix*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[15])(ctx,1,local+9,&ftab[15],fqv[185]); /*matrix-exponent*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[186]); /*m-*/
	local[8]= w;
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[3]); /*normalize-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[8])(ctx,1,local+9,&ftab[8],fqv[72]); /*outer-product-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[2];
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)VNORM(ctx,1,local+10); /*norm*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeint((eusinteger_t)3L);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,3,local+10,&ftab[5],fqv[24]); /*make-matrix*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TRANSPOSE(ctx,1,local+10); /*transpose*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)3L);
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,3,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,2,local+10); /*m**/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,2,local+9,&ftab[2],fqv[4]); /*scale-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,2,local+8,&ftab[6],fqv[27]); /*m+*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,1,local+8,&ftab[17],fqv[187]); /*inverse-matrix*/
	local[8]= w;
	local[9]= local[4];
	local[10]= argv[2];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[15])(ctx,1,local+10,&ftab[15],fqv[185]); /*matrix-exponent*/
	local[10]= w;
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)TRANSFORM(ctx,2,local+10); /*transform*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRANSFORM(ctx,2,local+8); /*transform*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)VPLUS(ctx,2,local+6); /*v+*/
	local[6]= w;
irtdynaIF3246:
	local[7]= argv[0];
	local[8]= fqv[49];
	local[9]= fqv[188];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	if (w==NIL) goto irtdynaIF3247;
	local[7]= argv[0];
	local[8]= fqv[49];
	local[9]= fqv[188];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto irtdynaIF3248;
irtdynaIF3247:
	local[7]= local[6];
irtdynaIF3248:
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[189];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	if (w==NIL) goto irtdynaIF3249;
	local[8]= argv[0];
	local[9]= fqv[49];
	local[10]= fqv[189];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3250;
irtdynaIF3249:
	local[8]= local[3];
irtdynaIF3250:
	local[9]= local[1];
	local[10]= local[3];
	local[11]= local[8];
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SCALEVEC(ctx,2,local+9); /*scale*/
	local[9]= w;
	local[10]= local[1];
	local[11]= local[6];
	local[12]= argv[2];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)SCALEVEC(ctx,2,local+12); /*scale*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,1,local+12,&ftab[15],fqv[185]); /*matrix-exponent*/
	local[12]= w;
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)TRANSFORM(ctx,2,local+12); /*transform*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)VMINUS(ctx,2,local+11); /*v-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	local[11]= local[9];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+11); /*v**/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)VMINUS(ctx,2,local+10); /*v-*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[46];
	local[13]= fqv[183];
	local[14]= argv[3];
	local[15]= fqv[68];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[46];
	local[13]= fqv[188];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= argv[0];
	local[12]= fqv[46];
	local[13]= fqv[189];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= fqv[176];
	local[12]= local[6];
	local[13]= local[3];
	local[14]= makeflt(1.0000000000000000208167e-03);
	local[15]= argv[3];
	local[16]= fqv[5];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SCALEVEC(ctx,2,local+14); /*scale*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+13); /*v**/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)VMINUS(ctx,2,local+12); /*v-*/
	local[12]= w;
	local[13]= fqv[177];
	local[14]= local[3];
	local[15]= fqv[178];
	local[16]= local[10];
	local[17]= fqv[179];
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,8,local+11); /*list*/
	local[0]= w;
irtdynaBLK3241:
	ctx->vsp=local; return(local[0]);}

/*:calc-av-vel-acc-from-pos*/
static pointer irtdynaM3251cascaded_link_calc_av_vel_acc_from_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	if (w==NIL) goto irtdynaIF3253;
	local[1]= argv[0];
	local[2]= fqv[49];
	local[3]= fqv[190];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3254;
irtdynaIF3253:
	local[1]= argv[3];
irtdynaIF3254:
	local[2]= loadglobal(fqv[43]);
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	local[4]= w;
irtdynaWHL3255:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3256;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[0];
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= fqv[191];
	local[10]= argv[3];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[1];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3255;
irtdynaWHX3256:
	local[5]= NIL;
irtdynaBLK3257:
	w = NIL;
	w = local[2];
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[49];
	local[5]= fqv[192];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	if (w==NIL) goto irtdynaIF3258;
	local[3]= argv[0];
	local[4]= fqv[49];
	local[5]= fqv[192];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	goto irtdynaIF3259;
irtdynaIF3258:
	local[3]= local[2];
irtdynaIF3259:
	local[4]= local[0];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[46];
	local[7]= fqv[190];
	local[8]= argv[3];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= argv[0];
	local[6]= fqv[46];
	local[7]= fqv[192];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= fqv[173];
	local[6]= local[2];
	local[7]= fqv[175];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,4,local+5); /*list*/
	local[0]= w;
irtdynaBLK3252:
	ctx->vsp=local; return(local[0]);}

/*:calc-torque-from-ext-wrenches*/
static pointer irtdynaM3260cascaded_link_calc_torque_from_ext_wrenches(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[193], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3262;
	local[0] = NIL;
irtdynaKEY3262:
	if (n & (1<<1)) goto irtdynaKEY3263;
	local[1] = NIL;
irtdynaKEY3263:
	if (n & (1<<2)) goto irtdynaKEY3264;
	local[2] = NIL;
irtdynaKEY3264:
	if (n & (1<<3)) goto irtdynaKEY3265;
	local[3] = NIL;
irtdynaKEY3265:
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3266,env,argv,local);
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	if (local[3]==NIL) goto irtdynaIF3267;
	local[5]= local[3];
	goto irtdynaIF3268;
irtdynaIF3267:
	local[5]= argv[0];
	local[6]= fqv[194];
	local[7]= local[4];
	local[8]= fqv[195];
	local[9]= local[2];
	local[10]= fqv[196];
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3269,env,argv,local);
	local[12]= local[2];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	local[11]= w;
	local[12]= fqv[87];
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)LENGTH(ctx,1,local+13); /*length*/
	local[13]= w;
	local[14]= fqv[197];
	local[15]= T;
	ctx->vsp=local+16;
	w=(*ftab[18])(ctx,3,local+13,&ftab[18],fqv[198]); /*make-list*/
	local[13]= w;
	local[14]= fqv[86];
	local[15]= local[2];
	ctx->vsp=local+16;
	w=(pointer)LENGTH(ctx,1,local+15); /*length*/
	local[15]= w;
	local[16]= fqv[197];
	local[17]= T;
	ctx->vsp=local+18;
	w=(*ftab[18])(ctx,3,local+15,&ftab[18],fqv[198]); /*make-list*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,11,local+5); /*send*/
	local[5]= w;
irtdynaIF3268:
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,irtdynaCLO3270,env,argv,local);
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,3,local+6); /*mapcar*/
	local[6]= w;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)TRANSPOSE(ctx,1,local+7); /*transpose*/
	local[7]= w;
	local[8]= (pointer)get_sym_func(fqv[199]);
	local[9]= loadglobal(fqv[43]);
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,3,local+8); /*apply*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSFORM(ctx,2,local+7); /*transform*/
	local[7]= w;
	local[8]= loadglobal(fqv[43]);
	local[9]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,2,local+8); /*instantiate*/
	local[8]= w;
	local[9]= argv[0];
	local[10]= fqv[200];
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
irtdynaWHL3271:
	local[12]= local[10];
	w = local[11];
	if ((eusinteger_t)local[12] >= (eusinteger_t)w) goto irtdynaWHX3272;
	local[12]= local[8];
	local[13]= local[9];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= fqv[81];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+15;
	w=(*ftab[19])(ctx,2,local+13,&ftab[19],fqv[201]); /*position*/
	local[13]= w;
	local[14]= local[7];
	local[15]= local[10];
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SETELT(ctx,3,local+12); /*setelt*/
	local[12]= local[10];
	ctx->vsp=local+13;
	w=(pointer)ADD1(ctx,1,local+12); /*1+*/
	local[10] = w;
	goto irtdynaWHL3271;
irtdynaWHX3272:
	local[12]= NIL;
irtdynaBLK3273:
	w = NIL;
	w = local[8];
	local[0]= w;
irtdynaBLK3261:
	ctx->vsp=local; return(local[0]);}

/*:calc-zmp*/
static pointer irtdynaM3274cascaded_link_calc_zmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3278;}
	local[0]= argv[0];
	local[1]= fqv[160];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaENT3278:
	if (n>=4) { local[1]=(argv[3]); goto irtdynaENT3277;}
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[68];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
irtdynaENT3277:
irtdynaENT3276:
	ctx->vsp=local+2;
	n=parsekeyparams(fqv[202], &argv[4], n-4, local+2, 0);
	if (n & (1<<0)) goto irtdynaKEY3279;
	local[2] = makeflt(0.0000000000000000000000e+00);
irtdynaKEY3279:
	if (n & (1<<1)) goto irtdynaKEY3280;
	local[3] = makeflt(4.9999999999999975019982e-03);
irtdynaKEY3280:
	if (n & (1<<2)) goto irtdynaKEY3281;
	local[4] = T;
irtdynaKEY3281:
	if (n & (1<<3)) goto irtdynaKEY3282;
	local[5] = NIL;
irtdynaKEY3282:
	if (n & (1<<4)) goto irtdynaKEY3283;
	local[7]= argv[0];
	local[8]= fqv[161];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[6] = w;
irtdynaKEY3283:
	if (local[4]==NIL) goto irtdynaIF3284;
	local[7]= argv[0];
	local[8]= fqv[74];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtdynaCLO3286,env,argv,local);
	ctx->vsp=local+9;
	w=(*ftab[9])(ctx,2,local+7,&ftab[9],fqv[75]); /*all-child-links*/
	local[7]= argv[0];
	local[8]= fqv[203];
	local[9]= fqv[167];
	local[10]= local[3];
	local[11]= fqv[165];
	local[12]= local[0];
	local[13]= fqv[166];
	local[14]= local[1];
	local[15]= fqv[45];
	local[16]= local[5];
	local[17]= fqv[164];
	local[18]= NIL;
	local[19]= fqv[161];
	local[20]= local[6];
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,14,local+7); /*send*/
	local[7]= w;
	goto irtdynaIF3285;
irtdynaIF3284:
	local[7]= NIL;
irtdynaIF3285:
	local[7]= argv[0];
	local[8]= fqv[74];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= fqv[150];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[74];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[151];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[7];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[7];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[7];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	local[12]= local[8];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	local[13]= local[8];
	local[14]= makeint((eusinteger_t)1L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[8];
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= makeflt(1.0000000000000000208167e-03);
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,1,local+16); /*-*/
	local[16]= w;
	local[17]= local[15];
	local[18]= local[9];
	ctx->vsp=local+19;
	w=(pointer)TIMES(ctx,2,local+17); /***/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)PLUS(ctx,2,local+16); /*+*/
	local[16]= w;
	local[17]= local[11];
	ctx->vsp=local+18;
	w=(pointer)QUOTIENT(ctx,2,local+16); /*/*/
	local[16]= w;
	local[17]= local[12];
	local[18]= local[15];
	local[19]= local[10];
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,2,local+18); /***/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)PLUS(ctx,2,local+17); /*+*/
	local[17]= w;
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)MKFLTVEC(ctx,3,local+16); /*float-vector*/
	local[16]= w;
	local[17]= argv[0];
	local[18]= fqv[46];
	local[19]= fqv[204];
	local[20]= makeflt(1.0000000000000000000000e+03);
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[17]= argv[0];
	local[18]= fqv[46];
	local[19]= fqv[205];
	local[20]= makeint((eusinteger_t)0L);
	local[21]= makeint((eusinteger_t)0L);
	local[22]= local[14];
	local[23]= makeflt(1.0000000000000000208167e-03);
	local[24]= argv[0];
	local[25]= fqv[49];
	local[26]= fqv[204];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,3,local+24); /*send*/
	local[24]= w;
	local[25]= makeint((eusinteger_t)0L);
	ctx->vsp=local+26;
	w=(pointer)ELT(ctx,2,local+24); /*elt*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= local[10];
	local[25]= makeflt(-1.0000000000000000000000e+00);
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,3,local+23); /***/
	local[23]= w;
	local[24]= makeflt(1.0000000000000000208167e-03);
	local[25]= argv[0];
	local[26]= fqv[49];
	local[27]= fqv[204];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,3,local+25); /*send*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)1L);
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,2,local+24); /***/
	local[24]= w;
	local[25]= local[9];
	ctx->vsp=local+26;
	w=(pointer)TIMES(ctx,2,local+24); /***/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,3,local+22); /*+*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,3,local+20); /*float-vector*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[7]= argv[0];
	local[8]= fqv[49];
	local[9]= fqv[204];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[0]= w;
irtdynaBLK3275:
	ctx->vsp=local; return(local[0]);}

/*:calc-cop-from-force-moment*/
static pointer irtdynaM3287cascaded_link_calc_cop_from_force_moment(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[206], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3289;
	local[0] = makeint((eusinteger_t)1L);
irtdynaKEY3289:
	if (n & (1<<1)) goto irtdynaKEY3290;
	local[1] = NIL;
irtdynaKEY3290:
	local[2]= argv[5];
	local[3]= fqv[207];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= argv[5];
	local[4]= fqv[207];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000208167e-03);
	local[5]= argv[5];
	local[6]= fqv[41];
	local[7]= argv[4];
	local[8]= fqv[5];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SCALEVEC(ctx,2,local+4); /*scale*/
	local[4]= w;
	local[5]= local[2];
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,1,local+6); /*-*/
	local[6]= w;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,3,local+5); /*+*/
	local[5]= w;
	local[6]= local[2];
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,3,local+6); /*+*/
	local[6]= w;
	local[7]= local[2];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[7];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)LESSP(ctx,2,local+8); /*<*/
	if (w==NIL) goto irtdynaCON3292;
	local[8]= NIL;
	goto irtdynaCON3291;
irtdynaCON3292:
	if (local[1]==NIL) goto irtdynaCON3293;
	local[8]= fqv[208];
	local[9]= argv[5];
	local[10]= fqv[209];
	local[11]= makeflt(1.0000000000000000000000e+03);
	local[12]= local[5];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= local[6];
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,3,local+12); /*float-vector*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SCALEVEC(ctx,2,local+11); /*scale*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[210];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,4,local+8); /*list*/
	local[8]= w;
	goto irtdynaCON3291;
irtdynaCON3293:
	local[8]= argv[5];
	local[9]= fqv[209];
	local[10]= makeflt(1.0000000000000000000000e+03);
	local[11]= local[5];
	local[12]= local[7];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= local[6];
	local[13]= local[7];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)SCALEVEC(ctx,2,local+10); /*scale*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaCON3291;
irtdynaCON3294:
	local[8]= NIL;
irtdynaCON3291:
	w = local[8];
	local[0]= w;
irtdynaBLK3288:
	ctx->vsp=local; return(local[0]);}

/*:wrench-vector->wrench-list*/
static pointer irtdynaM3295cascaded_link_wrench_vector__wrench_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)6L);
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
irtdynaWHL3297:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto irtdynaWHX3298;
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[5]);
		local[5]=(makeint(i * j));}
	local[6]= makeint((eusinteger_t)3L);
	local[7]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[7]);
		local[7]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	w = local[0];
	ctx->vsp=local+5;
	local[0] = cons(ctx,local[4],w);
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)3L);
	local[6]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[6]);
		local[6]=(makeint(i * j));}
	w = local[6];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[5]= (pointer)((eusinteger_t)local[5] + (eusinteger_t)w);
	local[6]= makeint((eusinteger_t)6L);
	local[7]= makeint((eusinteger_t)6L);
	{ eusinteger_t i,j;
		j=intval(local[2]); i=intval(local[7]);
		local[7]=(makeint(i * j));}
	w = local[7];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[6]= (pointer)((eusinteger_t)local[6] + (eusinteger_t)w);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto irtdynaWHL3297;
irtdynaWHX3298:
	local[4]= NIL;
irtdynaBLK3299:
	w = NIL;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)REVERSE(ctx,1,local+2); /*reverse*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)REVERSE(ctx,1,local+3); /*reverse*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[0]= w;
irtdynaBLK3296:
	ctx->vsp=local; return(local[0]);}

/*:wrench-list->wrench-vector*/
static pointer irtdynaM3300cascaded_link_wrench_list__wrench_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= (pointer)get_sym_func(fqv[199]);
	local[1]= loadglobal(fqv[43]);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtdynaCLO3302,env,argv,local);
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,3,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
irtdynaBLK3301:
	ctx->vsp=local; return(local[0]);}

/*:calc-contact-wrenches-from-total-wrench*/
static pointer irtdynaM3303cascaded_link_calc_contact_wrenches_from_total_wrench(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[211], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3305;
	local[0] = NIL;
irtdynaKEY3305:
	if (n & (1<<1)) goto irtdynaKEY3306;
	local[2]= loadglobal(fqv[43]);
	local[3]= makeint((eusinteger_t)6L);
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LENGTH(ctx,1,local+4); /*length*/
	{ eusinteger_t i,j;
		j=intval(w); i=intval(local[3]);
		local[3]=(makeint(i * j));}
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,2,local+2,&ftab[20],fqv[212]); /*fill*/
	local[1] = w;
irtdynaKEY3306:
	if (local[0]!=NIL) goto irtdynaIF3307;
	local[2]= argv[0];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeflt(9.9999999999999974298988e-07);
	local[4]= loadglobal(fqv[147]);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,3,local+2); /***/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[2];
	local[6]= makeflt(1.0000000000000000208167e-03);
	local[7]= argv[0];
	local[8]= fqv[30];
	local[9]= NIL;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	local[7]= makeflt(-1.0000000000000000208167e-03);
	local[8]= argv[0];
	local[9]= fqv[30];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,3,local+7); /***/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)MKFLTVEC(ctx,6,local+3); /*float-vector*/
	local[0] = w;
	local[2]= local[0];
	goto irtdynaIF3308;
irtdynaIF3307:
	local[2]= NIL;
irtdynaIF3308:
	local[2]= argv[0];
	local[3]= fqv[94];
	local[4]= argv[0];
	local[5]= fqv[213];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[20];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,5,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TRANSFORM(ctx,2,local+2); /*transform*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)LENGTH(ctx,1,local+6); /*length*/
	local[6]= w;
irtdynaWHL3309:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtdynaWHX3310;
	local[7]= local[2];
	local[8]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	local[9]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	w = local[3];
	ctx->vsp=local+8;
	local[3] = cons(ctx,local[7],w);
	local[7]= local[2];
	local[8]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[8]);
		local[8]=(makeint(i * j));}
	w = makeint((eusinteger_t)3L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[8]= (pointer)((eusinteger_t)local[8] + (eusinteger_t)w);
	local[9]= local[5];
	{ eusinteger_t i,j;
		j=intval(makeint((eusinteger_t)6L)); i=intval(local[9]);
		local[9]=(makeint(i * j));}
	w = makeint((eusinteger_t)6L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[9]= (pointer)((eusinteger_t)local[9] + (eusinteger_t)w);
	ctx->vsp=local+10;
	w=(pointer)SUBSEQ(ctx,3,local+7); /*subseq*/
	local[7]= w;
	w = local[4];
	ctx->vsp=local+8;
	local[4] = cons(ctx,local[7],w);
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtdynaWHL3309;
irtdynaWHX3310:
	local[7]= NIL;
irtdynaBLK3311:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)REVERSE(ctx,1,local+5); /*reverse*/
	local[5]= w;
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)REVERSE(ctx,1,local+6); /*reverse*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,2,local+5); /*list*/
	local[0]= w;
irtdynaBLK3304:
	ctx->vsp=local; return(local[0]);}

/*:draw-torque*/
static pointer irtdynaM3312cascaded_link_draw_torque(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[214], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3314;
	local[0] = NIL;
irtdynaKEY3314:
	if (n & (1<<1)) goto irtdynaKEY3315;
	local[1] = makeint((eusinteger_t)2L);
irtdynaKEY3315:
	if (n & (1<<2)) goto irtdynaKEY3316;
	local[2] = makeint((eusinteger_t)100L);
irtdynaKEY3316:
	if (n & (1<<3)) goto irtdynaKEY3317;
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeflt(2.9999999999999982236432e-01);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[3] = w;
irtdynaKEY3317:
	if (n & (1<<4)) goto irtdynaKEY3318;
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[4] = w;
irtdynaKEY3318:
	if (n & (1<<5)) goto irtdynaKEY3319;
	local[5] = NIL;
irtdynaKEY3319:
	if (n & (1<<6)) goto irtdynaKEY3320;
	local[8]= argv[0];
	local[9]= fqv[157];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[6] = w;
irtdynaKEY3320:
	if (n & (1<<7)) goto irtdynaKEY3321;
	local[8]= argv[0];
	local[9]= fqv[215];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[7] = w;
irtdynaKEY3321:
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,irtdynaCLO3322,env,argv,local);
	local[9]= local[7];
	local[10]= local[6];
	local[11]= loadglobal(fqv[216]);
	ctx->vsp=local+12;
	w=(pointer)COERCE(ctx,2,local+10); /*coerce*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,3,local+8); /*mapcar*/
	if (local[0]==NIL) goto irtdynaIF3323;
	local[8]= argv[2];
	local[9]= fqv[217];
	local[10]= fqv[218];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3324;
irtdynaIF3323:
	local[8]= NIL;
irtdynaIF3324:
	w = local[8];
	local[0]= w;
irtdynaBLK3313:
	ctx->vsp=local; return(local[0]);}

/*:weight*/
static pointer irtdynaM3325cascaded_link_weight(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3328;}
	local[0]= T;
irtdynaENT3328:
irtdynaENT3327:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3329;
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3330;
irtdynaIF3329:
	local[1]= NIL;
irtdynaIF3330:
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[49];
	local[3]= fqv[47];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtdynaBLK3326:
	ctx->vsp=local; return(local[0]);}

/*:centroid*/
static pointer irtdynaM3331cascaded_link_centroid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3334;}
	local[0]= T;
irtdynaENT3334:
irtdynaENT3333:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3335;
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3336;
irtdynaIF3335:
	local[1]= NIL;
irtdynaIF3336:
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[49];
	local[3]= fqv[51];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtdynaBLK3332:
	ctx->vsp=local; return(local[0]);}

/*:inertia-tensor*/
static pointer irtdynaM3337cascaded_link_inertia_tensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtdynaENT3340;}
	local[0]= T;
irtdynaENT3340:
irtdynaENT3339:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtdynaIF3341;
	local[1]= argv[0];
	local[2]= fqv[80];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaIF3342;
irtdynaIF3341:
	local[1]= NIL;
irtdynaIF3342:
	local[1]= argv[0];
	local[2]= fqv[74];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[49];
	local[3]= fqv[50];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
irtdynaBLK3338:
	ctx->vsp=local; return(local[0]);}

/*:preview-control-dynamics-filter*/
static pointer irtdynaM3343cascaded_link_preview_control_dynamics_filter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[219], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3345;
	local[0] = loadglobal(fqv[220]);
irtdynaKEY3345:
	if (n & (1<<1)) goto irtdynaKEY3346;
	local[1] = fqv[221];
irtdynaKEY3346:
	if (n & (1<<2)) goto irtdynaKEY3347;
	local[2] = makeflt(7.9999999999999982236432e-01);
irtdynaKEY3347:
	ctx->vsp=local+3;
	local[3]= makeclosure(codevec,quotevec,irtdynaFLET3348,env,argv,local);
	w=argv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+5;
	w=irtdynaFLET3348(ctx,1,local+4,w);
	local[4]= loadglobal(fqv[222]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[223];
	local[7]= argv[2];
	local[8]= argv[0];
	local[9]= fqv[30];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	local[9]= fqv[224];
	local[10]= local[2];
	local[11]= fqv[225];
	local[12]= T;
	local[13]= fqv[226];
	local[14]= local[0];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,10,local+5); /*send*/
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)2L);
irtdynaWHL3349:
	local[8]= local[6];
	w = local[7];
	if ((eusinteger_t)local[8] >= (eusinteger_t)w) goto irtdynaWHX3350;
	local[8]= argv[0];
	local[9]= fqv[227];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)ADD1(ctx,1,local+8); /*1+*/
	local[6] = w;
	goto irtdynaWHL3349;
irtdynaWHX3350:
	local[8]= NIL;
irtdynaBLK3351:
	w = NIL;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= NIL;
	local[9]= NIL;
	local[10]= NIL;
	local[11]= argv[3];
	ctx->vsp=local+12;
	w=(pointer)COPYOBJ(ctx,1,local+11); /*copy-object*/
	local[11]= w;
irtdynaWHL3352:
	local[12]= local[4];
	local[13]= fqv[228];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	if (w!=NIL) goto irtdynaWHX3353;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11] = (w)->c.cons.cdr;
	w = local[12];
	local[10] = w;
	if (local[10]==NIL) goto irtdynaIF3355;
	local[12]= local[10];
	w = local[3];
	ctx->vsp=local+13;
	w=irtdynaFLET3348(ctx,1,local+12,w);
	local[7] = local[10];
	local[12]= local[7];
	goto irtdynaIF3356;
irtdynaIF3355:
	local[12]= local[7];
	w = local[3];
	ctx->vsp=local+13;
	w=irtdynaFLET3348(ctx,1,local+12,w);
	local[12]= w;
irtdynaIF3356:
	local[12]= argv[0];
	local[13]= fqv[227];
	local[14]= argv[0];
	local[15]= fqv[160];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= w;
	local[15]= argv[0];
	local[16]= fqv[68];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= fqv[167];
	local[17]= argv[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,6,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[204];
	w = local[10];
	w=memq(local[13],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	if (local[13]==NIL) goto irtdynaIF3357;
	local[9] = local[13];
	local[14]= local[9];
	goto irtdynaIF3358;
irtdynaIF3357:
	local[14]= local[9];
irtdynaIF3358:
	w = local[14];
	local[13]= w;
	local[14]= local[12];
	local[15]= local[13];
	ctx->vsp=local+16;
	w=(pointer)VMINUS(ctx,2,local+14); /*v-*/
	local[14]= w;
	local[15]= local[4];
	local[16]= fqv[229];
	if (local[10]==NIL) goto irtdynaIF3359;
	local[17]= local[14];
	goto irtdynaIF3360;
irtdynaIF3359:
	local[17]= NIL;
irtdynaIF3360:
	local[18]= local[10];
	local[19]= local[12];
	local[20]= argv[0];
	local[21]= fqv[30];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)COPYOBJ(ctx,1,local+20); /*copy-object*/
	local[20]= w;
	local[21]= local[13];
	ctx->vsp=local+22;
	w=(pointer)LIST(ctx,4,local+18); /*list*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,4,local+15); /*send*/
	local[5] = w;
	if (local[5]==NIL) goto irtdynaIF3361;
	local[15]= local[4];
	local[16]= fqv[230];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,2,local+15); /*list*/
	local[15]= w;
	w = local[6];
	ctx->vsp=local+16;
	local[6] = cons(ctx,local[15],w);
	local[15]= argv[0];
	local[16]= fqv[160];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= argv[0];
	local[17]= fqv[68];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= local[4];
	local[18]= fqv[230];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[17]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+18;
	w=irtdynaFLET3348(ctx,1,local+17,w);
	local[17]= local[1];
	local[18]= local[17];
	if (fqv[231]!=local[18]) goto irtdynaIF3363;
	local[18]= argv[0];
	local[19]= fqv[231];
	local[20]= fqv[232];
	local[21]= fqv[233];
	local[22]= fqv[234];
	local[23]= makeflt(9.9999999999999977795540e-02);
	local[24]= fqv[235];
	local[25]= argv[0];
	local[26]= fqv[30];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,2,local+25); /*send*/
	local[25]= w;
	local[26]= local[4];
	local[27]= fqv[236];
	ctx->vsp=local+28;
	w=(pointer)SEND(ctx,2,local+26); /*send*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)VMINUS(ctx,2,local+25); /*v-*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)SEND(ctx,8,local+18); /*send*/
	local[18]= w;
	goto irtdynaIF3364;
irtdynaIF3363:
	local[18]= local[17];
	if (fqv[221]!=local[18]) goto irtdynaIF3365;
	ctx->vsp=local+18;
	local[18]= makeclosure(codevec,quotevec,irtdynaCLO3367,env,argv,local);
	local[19]= fqv[237];
	ctx->vsp=local+20;
	w=(pointer)MAPCAR(ctx,2,local+18); /*mapcar*/
	local[18]= w;
	local[19]= argv[0];
	local[20]= fqv[238];
	local[21]= local[4];
	local[22]= fqv[236];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)MINUS(ctx,1,local+21); /*-*/
	local[21]= w;
	local[22]= local[4];
	local[23]= fqv[236];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	local[22]= w;
	local[23]= makeint((eusinteger_t)1L);
	ctx->vsp=local+24;
	w=(pointer)ELT(ctx,2,local+22); /*elt*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MINUS(ctx,1,local+22); /*-*/
	local[22]= w;
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(pointer)MKFLTVEC(ctx,3,local+21); /*float-vector*/
	local[21]= w;
	local[22]= fqv[239];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,4,local+19); /*send*/
	ctx->vsp=local+19;
	local[19]= makeclosure(codevec,quotevec,irtdynaCLO3368,env,argv,local);
	local[20]= fqv[240];
	local[21]= local[18];
	ctx->vsp=local+22;
	w=(pointer)MAPCAR(ctx,3,local+19); /*mapcar*/
	local[18]= w;
	goto irtdynaIF3366;
irtdynaIF3365:
	local[18]= NIL;
irtdynaIF3366:
irtdynaIF3364:
	w = local[18];
	local[17]= fqv[160];
	local[18]= argv[0];
	local[19]= fqv[160];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	local[19]= fqv[166];
	local[20]= argv[0];
	local[21]= fqv[74];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[68];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)LIST(ctx,4,local+17); /*list*/
	local[17]= w;
	w = local[8];
	ctx->vsp=local+18;
	local[8] = cons(ctx,local[17],w);
	local[17]= argv[0];
	local[18]= fqv[160];
	local[19]= local[15];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,3,local+17); /*send*/
	local[17]= argv[0];
	local[18]= fqv[241];
	local[19]= local[16];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,3,local+17); /*send*/
	local[15]= w;
	goto irtdynaIF3362;
irtdynaIF3361:
	local[15]= NIL;
irtdynaIF3362:
	w = local[15];
	goto irtdynaWHL3352;
irtdynaWHX3353:
	local[12]= NIL;
irtdynaBLK3354:
	local[12]= local[8];
	ctx->vsp=local+13;
	w=(pointer)REVERSE(ctx,1,local+12); /*reverse*/
	local[8] = w;
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)REVERSE(ctx,1,local+12); /*reverse*/
	local[6] = w;
	w=local[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w = local[3];
	ctx->vsp=local+13;
	w=irtdynaFLET3348(ctx,1,local+12,w);
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)2L);
irtdynaWHL3369:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtdynaWHX3370;
	local[14]= argv[0];
	local[15]= fqv[227];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,2,local+14); /*send*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtdynaWHL3369;
irtdynaWHX3370:
	local[14]= NIL;
irtdynaBLK3371:
	w = NIL;
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(*ftab[21])(ctx,1,local+12,&ftab[21],fqv[242]); /*objects*/
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,1,local+12); /*-*/
	local[12]= w;
	ctx->vsp=local+13;
	local[13]= makeclosure(codevec,quotevec,irtdynaCLO3372,env,argv,local);
	local[14]= local[8];
	local[15]= local[6];
	ctx->vsp=local+16;
	w=(pointer)MAPCAR(ctx,3,local+13); /*mapcar*/
	local[13]= w;
	ctx->vsp=local+14;
	local[14]= makeclosure(codevec,quotevec,irtdynaCLO3373,env,argv,local);
	local[15]= local[8];
	local[16]= local[13];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,3,local+14); /*mapcar*/
	local[0]= w;
irtdynaBLK3344:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3209(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[120];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= fqv[243];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= makeflt(1.0000000000000000208167e-03);
	local[1]= argv[2];
	local[2]= fqv[5];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+0); /*v**/
	local[0]= w;
	local[1]= argv[2];
	local[2]= fqv[120];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[244];
	local[3]= argv[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)VPLUS(ctx,2,local+3); /*v+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3230(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[181];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3231(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[136];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[46];
	local[2]= fqv[134];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3235(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[243];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[244];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3239(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[181];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaFLET3242(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,3,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= makeint((eusinteger_t)2L);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,4,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ABS(ctx,1,local+1); /*abs*/
	local[1]= w;
	local[2]= makeflt(0.0000000000000000000000e+00);
	local[3]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3374;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	goto irtdynaIF3375;
irtdynaIF3374:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[22])(ctx,1,local+1,&ftab[22],fqv[245]); /*acos*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)SIN(ctx,1,local+2); /*sin*/
	local[2]= w;
	local[3]= local[2];
	local[4]= makeflt(9.9999999999999949376344e-21);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto irtdynaIF3376;
	local[3]= local[1];
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SQRT(ctx,1,local+3); /*sqrt*/
	local[3]= w;
	local[4]= local[1];
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SQRT(ctx,1,local+4); /*sqrt*/
	local[4]= w;
	local[5]= local[1];
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SQRT(ctx,1,local+5); /*sqrt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[3]= w;
	goto irtdynaIF3377;
irtdynaIF3376:
	local[3]= makeflt(-5.0000000000000000000000e-01);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	local[4]= local[3];
	local[5]= argv[0];
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)1L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[0];
	local[7]= makeint((eusinteger_t)2L);
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	local[6]= local[3];
	local[7]= argv[0];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MINUS(ctx,2,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[3]= w;
irtdynaIF3377:
	w = local[3];
	local[1]= w;
irtdynaIF3375:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3266(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[91];
	local[2]= argv[0];
	local[3]= fqv[120];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3269(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	ctx->vsp=local+0;
	w=(*ftab[23])(ctx,0,local+0,&ftab[23],fqv[246]); /*make-coords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3270(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)CONCATENATE(ctx,3,local+0); /*concatenate*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3286(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[243];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[244];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3302(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[43]);
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)CONCATENATE(ctx,3,local+0); /*concatenate*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3322(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= argv[0];
	local[2]= fqv[155];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[77];
	local[3]= fqv[2];
	local[4]= *(ovafptr(argv[0],fqv[60]));
	local[5]= local[4];
	if (fqv[61]!=local[5]) goto irtdynaIF3378;
	local[5]= fqv[247];
	goto irtdynaIF3379;
irtdynaIF3378:
	local[5]= local[4];
	if (fqv[63]!=local[5]) goto irtdynaIF3380;
	local[5]= fqv[248];
	goto irtdynaIF3381;
irtdynaIF3380:
	local[5]= local[4];
	if (fqv[65]!=local[5]) goto irtdynaIF3382;
	local[5]= fqv[249];
	goto irtdynaIF3383;
irtdynaIF3382:
	local[5]= local[4];
	if (fqv[62]!=local[5]) goto irtdynaIF3384;
	local[5]= fqv[250];
	goto irtdynaIF3385;
irtdynaIF3384:
	local[5]= local[4];
	if (fqv[64]!=local[5]) goto irtdynaIF3386;
	local[5]= fqv[251];
	goto irtdynaIF3387;
irtdynaIF3386:
	local[5]= local[4];
	if (fqv[66]!=local[5]) goto irtdynaIF3388;
	local[5]= fqv[252];
	goto irtdynaIF3389;
irtdynaIF3388:
	if (T==NIL) goto irtdynaIF3390;
	local[5]= *(ovafptr(argv[0],fqv[60]));
	goto irtdynaIF3391;
irtdynaIF3390:
	local[5]= NIL;
irtdynaIF3391:
irtdynaIF3389:
irtdynaIF3387:
irtdynaIF3385:
irtdynaIF3383:
irtdynaIF3381:
irtdynaIF3379:
	w = local[5];
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,3,local+2); /*float-vector*/
	local[2]= w;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)VINNERPRODUCT(ctx,2,local+2); /*v.*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,1,local+2,&ftab[22],fqv[245]); /*acos*/
	local[2]= w;
	local[3]= local[2];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3392;
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,1,local+3,&ftab[14],fqv[184]); /*unit-matrix*/
	local[3]= w;
	goto irtdynaIF3393;
irtdynaIF3392:
	local[3]= local[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[0];
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w==NIL) goto irtdynaIF3394;
	local[6]= makeflt(1.0000000000000000000000e+00);
	goto irtdynaIF3395;
irtdynaIF3394:
	local[6]= makeflt(-1.0000000000000000000000e+00);
irtdynaIF3395:
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+4); /*v**/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+3); /*rotation-matrix*/
	local[3]= w;
irtdynaIF3393:
	local[4]= env->c.clo.env2[1];
	local[5]= env->c.clo.env2[3];
	if (local[3]!=NIL) goto irtdynaIF3396;
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(*ftab[14])(ctx,1,local+6,&ftab[14],fqv[184]); /*unit-matrix*/
	local[3] = w;
	local[6]= local[3];
	goto irtdynaIF3397;
irtdynaIF3396:
	local[6]= NIL;
irtdynaIF3397:
	if (env->c.clo.env2[5]==NIL) goto irtdynaIF3398;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	local[7]= env->c.clo.env2[5];
	ctx->vsp=local+8;
	w=(pointer)GREATERP(ctx,2,local+6); /*>*/
	if (w==NIL) goto irtdynaIF3398;
	local[6]= makeint((eusinteger_t)2L);
	local[7]= env->c.clo.env2[1];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	env->c.clo.env2[1] = w;
	env->c.clo.env2[3] = env->c.clo.env2[4];
	local[6]= env->c.clo.env2[3];
	goto irtdynaIF3399;
irtdynaIF3398:
	local[6]= NIL;
irtdynaIF3399:
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[217];
	local[8]= fqv[253];
	local[9]= env->c.clo.env2[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[217];
	local[8]= fqv[106];
	local[9]= env->c.clo.env2[3];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[254];
	local[8]= fqv[255];
	local[9]= argv[0];
	local[10]= fqv[77];
	local[11]= fqv[5];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= w;
	local[10]= fqv[256];
	local[11]= local[3];
	ctx->vsp=local+12;
	w=(*ftab[23])(ctx,4,local+8,&ftab[23],fqv[246]); /*make-coords*/
	local[8]= w;
	local[9]= fqv[257];
	local[10]= env->c.clo.env2[2];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)ABS(ctx,1,local+11); /*abs*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= fqv[258];
	local[12]= T;
	local[13]= fqv[259];
	local[14]= makeint((eusinteger_t)330L);
	ctx->vsp=local+15;
	w=(*ftab[24])(ctx,1,local+14,&ftab[24],fqv[260]); /*deg2rad*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,9,local+6); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaFLET3348(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[160];
	local[2]= fqv[160];
	w = argv[0];
	w=memq(local[2],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[261];
	local[2]= fqv[166];
	w = argv[0];
	w=memq(local[2],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[74];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3367(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3368(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	local[2]= fqv[263];
	local[3]= argv[1];
	local[4]= fqv[264];
	local[5]= makeflt(9.9999999999999977795540e-02);
	local[6]= fqv[265];
	local[7]= makeflt(9.9999999999999977795540e-02);
	ctx->vsp=local+8;
	w=(*ftab[24])(ctx,1,local+7,&ftab[24],fqv[260]); /*deg2rad*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,8,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3372(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[3];
	ctx->vsp=local+1;
	w=irtdynaFLET3348(ctx,1,local+0,w);
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[227];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[160];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= env->c.clo.env1[0];
	local[4]= fqv[68];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= fqv[167];
	local[5]= env->c.clo.env1[2];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
	local[1]= loadglobal(fqv[266]);
	local[2]= fqv[267];
	local[3]= fqv[218];
	local[4]= NIL;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= NIL;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)400L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= env->c.clo.env1[0];
	local[2]= fqv[30];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= NIL;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)300L);
	local[7]= fqv[106];
	local[8]= fqv[269];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= NIL;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)400L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= local[0];
	local[2]= fqv[268];
	local[3]= fqv[218];
	local[4]= T;
	local[5]= fqv[108];
	local[6]= makeint((eusinteger_t)300L);
	local[7]= fqv[106];
	local[8]= fqv[270];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,8,local+1); /*send*/
	ctx->vsp=local+1;
	w=(*ftab[25])(ctx,0,local+1,&ftab[25],fqv[271]); /*x::window-main-one*/
	local[1]= makeint((eusinteger_t)10000L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[272]); /*unix:usleep*/
	local[1]= env->c.clo.env2[12];
	local[2]= env->c.clo.env1[2];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	env->c.clo.env2[12] = w;
	local[1]= fqv[273];
	local[2]= env->c.clo.env2[12];
	local[3]= fqv[274];
	local[4]= local[0];
	local[5]= fqv[275];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.car;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= fqv[276];
	local[8]= env->c.clo.env1[0];
	local[9]= fqv[30];
	local[10]= NIL;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	local[9]= fqv[277];
	w=argv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(*ftab[27])(ctx,1,local+10,&ftab[27],fqv[278]); /*cadddr*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,10,local+1); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3373(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3400riccati_equation_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	argv[0]->c.obj.iv[3] = argv[4];
	argv[0]->c.obj.iv[5] = argv[5];
	argv[0]->c.obj.iv[6] = argv[6];
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[279]); /*array-dimension*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[279]); /*array-dimension*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[4] = w;
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
irtdynaBLK3401:
	ctx->vsp=local; return(local[0]);}

/*:solve*/
static pointer irtdynaM3402riccati_equation_solve(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(pointer)TRANSPOSE(ctx,1,local+3); /*transpose*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[28])(ctx,2,local+4,&ftab[28],fqv[279]); /*array-dimension*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(*ftab[28])(ctx,2,local+5,&ftab[28],fqv[279]); /*array-dimension*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[24]); /*make-matrix*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
irtdynaTAG3405:
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)10000L);
	ctx->vsp=local+8;
	w=(pointer)GREQP(ctx,2,local+6); /*>=*/
	if (w==NIL) goto irtdynaIF3406;
	w = NIL;
	ctx->vsp=local+6;
	local[5]=w;
	goto irtdynaBLK3404;
	goto irtdynaIF3407;
irtdynaIF3406:
	local[6]= NIL;
irtdynaIF3407:
	local[6]= argv[0]->c.obj.iv[4];
	local[7]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= argv[0]->c.obj.iv[2];
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[28])(ctx,2,local+8,&ftab[28],fqv[279]); /*array-dimension*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[14])(ctx,1,local+8,&ftab[14],fqv[184]); /*unit-matrix*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,2,local+7,&ftab[2],fqv[4]); /*scale-matrix*/
	local[7]= w;
	local[8]= local[2];
	local[9]= argv[0]->c.obj.iv[4];
	local[10]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[27]); /*m+*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[17])(ctx,1,local+7,&ftab[17],fqv[187]); /*inverse-matrix*/
	argv[0]->c.obj.iv[9] = w;
	local[7]= argv[0]->c.obj.iv[9];
	local[8]= local[2];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	argv[0]->c.obj.iv[7] = w;
	local[7]= local[1];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	local[8]= local[3];
	local[9]= argv[0]->c.obj.iv[5];
	local[10]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+11;
	w=(*ftab[2])(ctx,2,local+9,&ftab[2],fqv[4]); /*scale-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[6])(ctx,2,local+7,&ftab[6],fqv[27]); /*m+*/
	local[7]= w;
	local[8]= local[1];
	local[9]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,2,local+7,&ftab[16],fqv[186]); /*m-*/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[4];
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[186]); /*m-*/
	local[0] = w;
	local[8]= local[0]->c.obj.iv[1];
	local[9]= local[4]->c.obj.iv[1];
	local[10]= loadglobal(fqv[280]);
	local[11]= makeflt(9.9999999999999950039964e-03);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(*ftab[29])(ctx,3,local+8,&ftab[29],fqv[281]); /*eps-v=*/
	if (w==NIL) goto irtdynaIF3408;
	local[8]= argv[0]->c.obj.iv[1];
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,2,local+8,&ftab[16],fqv[186]); /*m-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TRANSPOSE(ctx,1,local+8); /*transpose*/
	argv[0]->c.obj.iv[8] = w;
	local[8]= argv[0]->c.obj.iv[4];
	local[9]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	ctx->vsp=local+8;
	local[0]=w;
	goto irtdynaBLK3403;
	goto irtdynaIF3409;
irtdynaIF3408:
	local[8]= NIL;
irtdynaIF3409:
	argv[0]->c.obj.iv[4] = local[7];
	w = argv[0]->c.obj.iv[4];
	local[6]= local[5];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	local[5] = local[6];
	w = NIL;
	ctx->vsp=local+6;
	goto irtdynaTAG3405;
	w = NIL;
	local[5]= w;
irtdynaBLK3404:
	local[5]= fqv[282];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,2,local+5,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtdynaBLK3403:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3410preview_controller_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[283], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3412;
	local[0] = NIL;
irtdynaKEY3412:
	if (n & (1<<1)) goto irtdynaKEY3413;
	local[1] = NIL;
irtdynaKEY3413:
	if (n & (1<<2)) goto irtdynaKEY3414;
	local[2] = NIL;
irtdynaKEY3414:
	if (n & (1<<3)) goto irtdynaKEY3415;
	local[3] = NIL;
irtdynaKEY3415:
	if (n & (1<<4)) goto irtdynaKEY3416;
	local[4] = NIL;
irtdynaKEY3416:
	if (n & (1<<5)) goto irtdynaKEY3417;
	local[5] = NIL;
irtdynaKEY3417:
	if (n & (1<<6)) goto irtdynaKEY3418;
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[6] = w;
irtdynaKEY3418:
	if (n & (1<<7)) goto irtdynaKEY3419;
	local[12]= local[5];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[7] = w;
irtdynaKEY3419:
	if (n & (1<<8)) goto irtdynaKEY3420;
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[8] = w;
irtdynaKEY3420:
	if (n & (1<<9)) goto irtdynaKEY3421;
	local[12]= loadglobal(fqv[43]);
	local[13]= local[3];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(*ftab[28])(ctx,2,local+13,&ftab[28],fqv[279]); /*array-dimension*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,2,local+12); /*instantiate*/
	local[9] = w;
irtdynaKEY3421:
	if (n & (1<<10)) goto irtdynaKEY3422;
	local[12]= local[4];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,2,local+12,&ftab[5],fqv[24]); /*make-matrix*/
	local[10] = w;
irtdynaKEY3422:
	if (n & (1<<11)) goto irtdynaKEY3423;
	local[11] = NIL;
irtdynaKEY3423:
	local[12]= local[2];
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)ROUND(ctx,1,local+12); /*round*/
	argv[0]->c.obj.iv[12] = w;
	argv[0]->c.obj.iv[16] = local[11];
	argv[0]->c.obj.iv[20] = local[7];
	argv[0]->c.obj.iv[21] = local[8];
	local[12]= argv[0];
	local[13]= *(ovafptr(argv[1],fqv[284]));
	local[14]= fqv[223];
	local[15]= local[3];
	local[16]= local[4];
	local[17]= local[5];
	local[18]= local[0];
	local[19]= local[1];
	ctx->vsp=local+20;
	w=(pointer)SENDMESSAGE(ctx,8,local+12); /*send-message*/
	argv[0]->c.obj.iv[15] = makeint((eusinteger_t)0L);
	if (argv[0]->c.obj.iv[10]!=NIL) goto irtdynaIF3424;
	local[12]= local[6];
	local[13]= makeint((eusinteger_t)1L);
	ctx->vsp=local+14;
	w=(*ftab[5])(ctx,2,local+12,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[10] = w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[6];
irtdynaWHL3426:
	local[14]= local[12];
	w = local[13];
	if ((eusinteger_t)local[14] >= (eusinteger_t)w) goto irtdynaWHX3427;
	local[14]= argv[0]->c.obj.iv[10];
	local[15]= local[12];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= local[9];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)ELT(ctx,2,local+17); /*elt*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)ASET(ctx,4,local+14); /*aset*/
	local[14]= local[12];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[12] = w;
	goto irtdynaWHL3426;
irtdynaWHX3427:
	local[14]= NIL;
irtdynaBLK3428:
	w = NIL;
	local[12]= w;
	goto irtdynaIF3425;
irtdynaIF3424:
	local[12]= NIL;
irtdynaIF3425:
	argv[0]->c.obj.iv[11] = local[10];
	local[12]= argv[0];
	local[13]= fqv[285];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= argv[0];
	local[13]= fqv[286];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	w = argv[0];
	local[0]= w;
irtdynaBLK3411:
	ctx->vsp=local; return(local[0]);}

/*:calc-f*/
static pointer irtdynaM3429preview_controller_calc_f(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[21];
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[13] = w;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[279]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[184]); /*unit-matrix*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[12];
irtdynaWHL3431:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3432;
	local[5]= argv[0]->c.obj.iv[5];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,2,local+5,&ftab[2],fqv[4]); /*scale-matrix*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[9];
	local[7]= local[1];
	local[8]= local[0];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,2,local+6); /*m**/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[8];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[0] = w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[21];
irtdynaWHL3434:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto irtdynaWHX3435;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= argv[0]->c.obj.iv[20];
irtdynaWHL3437:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtdynaWHX3438;
	local[11]= argv[0]->c.obj.iv[13];
	local[12]= local[7];
	local[13]= argv[0]->c.obj.iv[20];
	local[14]= local[3];
	ctx->vsp=local+15;
	w=(pointer)ADD1(ctx,1,local+14); /*1+*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= local[9];
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= local[6];
	local[15]= local[7];
	local[16]= local[9];
	ctx->vsp=local+17;
	w=(pointer)AREF(ctx,3,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ASET(ctx,4,local+11); /*aset*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtdynaWHL3437;
irtdynaWHX3438:
	local[11]= NIL;
irtdynaBLK3439:
	w = NIL;
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto irtdynaWHL3434;
irtdynaWHX3435:
	local[9]= NIL;
irtdynaBLK3436:
	w = NIL;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3431;
irtdynaWHX3432:
	local[5]= NIL;
irtdynaBLK3433:
	w = NIL;
	local[0]= w;
irtdynaBLK3430:
	ctx->vsp=local; return(local[0]);}

/*:calc-u*/
static pointer irtdynaM3440preview_controller_calc_u(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[186]); /*m-*/
	argv[0]->c.obj.iv[11] = w;
	w = argv[0]->c.obj.iv[11];
	local[0]= w;
irtdynaBLK3441:
	ctx->vsp=local; return(local[0]);}

/*:calc-xk*/
static pointer irtdynaM3442preview_controller_calc_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0];
	local[3]= fqv[287];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[27]); /*m+*/
	argv[0]->c.obj.iv[10] = w;
	w = argv[0]->c.obj.iv[10];
	local[0]= w;
irtdynaBLK3443:
	ctx->vsp=local; return(local[0]);}

/*:update-xk*/
static pointer irtdynaM3444preview_controller_update_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtdynaENT3447;}
	local[0]= NIL;
irtdynaENT3447:
irtdynaENT3446:
	if (n>4) maerror();
	if (argv[2]==NIL) goto irtdynaIF3448;
	if (argv[0]->c.obj.iv[19]!=NIL) goto irtdynaIF3450;
	local[1]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	argv[0]->c.obj.iv[15] = w;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	argv[0]->c.obj.iv[19] = w;
	local[1]= argv[0]->c.obj.iv[19];
	goto irtdynaIF3451;
irtdynaIF3450:
	local[1]= NIL;
irtdynaIF3451:
	if (argv[0]->c.obj.iv[14]!=NIL) goto irtdynaIF3452;
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,2,local+1,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[14] = w;
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[18])(ctx,1,local+1,&ftab[18],fqv[198]); /*make-list*/
	argv[0]->c.obj.iv[17] = w;
	if (argv[0]->c.obj.iv[16]==NIL) goto irtdynaIF3454;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
irtdynaWHL3456:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3457;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[20];
irtdynaWHL3459:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3460;
	local[5]= argv[0]->c.obj.iv[14];
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[2];
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,4,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3459;
irtdynaWHX3460:
	local[5]= NIL;
irtdynaBLK3461:
	w = NIL;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3456;
irtdynaWHX3457:
	local[3]= NIL;
irtdynaBLK3458:
	w = NIL;
	local[1]= w;
	goto irtdynaIF3455;
irtdynaIF3454:
	local[1]= NIL;
irtdynaIF3455:
	goto irtdynaIF3453;
irtdynaIF3452:
	local[1]= NIL;
irtdynaIF3453:
	if (argv[0]->c.obj.iv[16]!=NIL) goto irtdynaIF3462;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtdynaIF3464;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
irtdynaWHL3466:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3467;
	local[3]= argv[0]->c.obj.iv[14];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,4,local+3); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3466;
irtdynaWHX3467:
	local[3]= NIL;
irtdynaBLK3468:
	w = NIL;
	local[1]= argv[0]->c.obj.iv[17];
	local[2]= argv[0]->c.obj.iv[15];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SETELT(ctx,3,local+1); /*setelt*/
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto irtdynaBLK3445;
	goto irtdynaIF3465;
irtdynaIF3464:
	local[1]= NIL;
irtdynaIF3465:
	goto irtdynaIF3463;
irtdynaIF3462:
	local[1]= NIL;
irtdynaIF3463:
	goto irtdynaIF3449;
irtdynaIF3448:
	local[1]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+2;
	w=(pointer)SUB1(ctx,1,local+1); /*1-*/
	argv[0]->c.obj.iv[15] = w;
	local[1]= argv[0];
	local[2]= fqv[288];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[2] = w;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LSEQP(ctx,2,local+1); /*<=*/
	if (w==NIL) goto irtdynaIF3469;
	argv[0]->c.obj.iv[18] = T;
	local[1]= argv[0]->c.obj.iv[18];
	goto irtdynaIF3470;
irtdynaIF3469:
	local[1]= NIL;
irtdynaIF3470:
irtdynaIF3449:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[12];
irtdynaWHL3471:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3472;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[20];
irtdynaWHL3474:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto irtdynaWHX3475;
	local[5]= argv[0]->c.obj.iv[14];
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= argv[0]->c.obj.iv[14];
	local[9]= argv[0]->c.obj.iv[20];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)ADD1(ctx,1,local+10); /*1+*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)TIMES(ctx,2,local+9); /***/
	local[9]= w;
	local[10]= local[3];
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,4,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto irtdynaWHL3474;
irtdynaWHX3475:
	local[5]= NIL;
irtdynaBLK3476:
	w = NIL;
	local[3]= argv[0]->c.obj.iv[17];
	local[4]= local[1];
	local[5]= argv[0]->c.obj.iv[17];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SETELT(ctx,3,local+3); /*setelt*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3471;
irtdynaWHX3472:
	local[3]= NIL;
irtdynaBLK3473:
	w = NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
irtdynaWHL3477:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto irtdynaWHX3478;
	local[3]= argv[0]->c.obj.iv[14];
	local[4]= argv[0]->c.obj.iv[20];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[2];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,4,local+3); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto irtdynaWHL3477;
irtdynaWHX3478:
	local[3]= NIL;
irtdynaBLK3479:
	w = NIL;
	local[1]= argv[0]->c.obj.iv[17];
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SETELT(ctx,3,local+1); /*setelt*/
	local[1]= argv[0];
	local[2]= fqv[289];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	if (argv[0]->c.obj.iv[19]==NIL) goto irtdynaIF3480;
	if (argv[0]->c.obj.iv[18]!=NIL) goto irtdynaIF3480;
	local[1]= argv[0];
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[291];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[292];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	goto irtdynaIF3481;
irtdynaIF3480:
	local[1]= NIL;
irtdynaIF3481:
	w = local[1];
	local[0]= w;
irtdynaBLK3445:
	ctx->vsp=local; return(local[0]);}

/*:finishedp*/
static pointer irtdynaM3482preview_controller_finishedp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[18];
	local[0]= w;
irtdynaBLK3483:
	ctx->vsp=local; return(local[0]);}

/*:last-reference-output-vector*/
static pointer irtdynaM3484preview_controller_last_reference_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[14];
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
irtdynaBLK3485:
	ctx->vsp=local; return(local[0]);}

/*:current-reference-output-vector*/
static pointer irtdynaM3486preview_controller_current_reference_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[14];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
irtdynaBLK3487:
	ctx->vsp=local; return(local[0]);}

/*:current-state-vector*/
static pointer irtdynaM3488preview_controller_current_state_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[10];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[293]); /*matrix-column*/
	local[0]= w;
irtdynaBLK3489:
	ctx->vsp=local; return(local[0]);}

/*:current-output-vector*/
static pointer irtdynaM3490preview_controller_current_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[293]); /*matrix-column*/
	local[0]= w;
irtdynaBLK3491:
	ctx->vsp=local; return(local[0]);}

/*:current-additional-data*/
static pointer irtdynaM3492preview_controller_current_additional_data(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[17];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
irtdynaBLK3493:
	ctx->vsp=local; return(local[0]);}

/*:pass-preview-controller*/
static pointer irtdynaM3494preview_controller_pass_preview_controller(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
irtdynaWHL3496:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]!=NIL) goto irtdynaWHX3497;
	goto irtdynaWHL3496;
irtdynaWHX3497:
	local[2]= NIL;
irtdynaBLK3498:
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
irtdynaWHL3499:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto irtdynaWHX3500;
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto irtdynaWHL3499;
irtdynaWHX3500:
	local[2]= NIL;
irtdynaBLK3501:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)REVERSE(ctx,1,local+2); /*reverse*/
	local[0]= w;
irtdynaBLK3495:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3502extended_preview_controller_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[294], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3504;
	local[0] = NIL;
irtdynaKEY3504:
	if (n & (1<<1)) goto irtdynaKEY3505;
	local[1] = NIL;
irtdynaKEY3505:
	if (n & (1<<2)) goto irtdynaKEY3506;
	local[2] = NIL;
irtdynaKEY3506:
	if (n & (1<<3)) goto irtdynaKEY3507;
	local[3] = NIL;
irtdynaKEY3507:
	if (n & (1<<4)) goto irtdynaKEY3508;
	local[4] = NIL;
irtdynaKEY3508:
	if (n & (1<<5)) goto irtdynaKEY3509;
	local[5] = NIL;
irtdynaKEY3509:
	if (n & (1<<6)) goto irtdynaKEY3510;
	local[11]= loadglobal(fqv[43]);
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(*ftab[28])(ctx,2,local+12,&ftab[28],fqv[279]); /*array-dimension*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)INSTANTIATE(ctx,2,local+11); /*instantiate*/
	local[6] = w;
irtdynaKEY3510:
	if (n & (1<<7)) goto irtdynaKEY3511;
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[5])(ctx,2,local+11,&ftab[5],fqv[24]); /*make-matrix*/
	local[7] = w;
irtdynaKEY3511:
	if (n & (1<<8)) goto irtdynaKEY3512;
	local[11]= local[3];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	local[8] = w;
irtdynaKEY3512:
	if (n & (1<<9)) goto irtdynaKEY3513;
	local[9] = NIL;
irtdynaKEY3513:
	if (n & (1<<10)) goto irtdynaKEY3514;
	local[10] = NIL;
irtdynaKEY3514:
	argv[0]->c.obj.iv[22] = local[3];
	argv[0]->c.obj.iv[23] = local[4];
	argv[0]->c.obj.iv[24] = local[5];
	local[11]= argv[0]->c.obj.iv[24];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	argv[0]->c.obj.iv[20] = w;
	local[11]= argv[0]->c.obj.iv[23];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	argv[0]->c.obj.iv[21] = w;
	local[11]= argv[0]->c.obj.iv[22];
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(*ftab[28])(ctx,2,local+11,&ftab[28],fqv[279]); /*array-dimension*/
	local[11]= w;
	local[12]= argv[0]->c.obj.iv[20];
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[24];
	local[14]= argv[0]->c.obj.iv[22];
	ctx->vsp=local+15;
	w=(pointer)MATTIMES(ctx,2,local+13); /*m**/
	local[13]= w;
	local[14]= local[12];
	local[15]= local[12];
	ctx->vsp=local+16;
	w=(*ftab[5])(ctx,2,local+14,&ftab[5],fqv[24]); /*make-matrix*/
	local[14]= w;
	local[15]= argv[0]->c.obj.iv[24];
	local[16]= argv[0]->c.obj.iv[23];
	ctx->vsp=local+17;
	w=(pointer)MATTIMES(ctx,2,local+15); /*m**/
	local[15]= w;
	local[16]= local[12];
	local[17]= argv[0]->c.obj.iv[23];
	local[18]= makeint((eusinteger_t)1L);
	ctx->vsp=local+19;
	w=(*ftab[28])(ctx,2,local+17,&ftab[28],fqv[279]); /*array-dimension*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(*ftab[5])(ctx,2,local+16,&ftab[5],fqv[24]); /*make-matrix*/
	local[16]= w;
	local[17]= argv[0]->c.obj.iv[20];
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(*ftab[5])(ctx,2,local+17,&ftab[5],fqv[24]); /*make-matrix*/
	local[17]= w;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3515:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3516;
	local[20]= local[14];
	local[21]= local[18];
	local[22]= local[18];
	local[23]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+24;
	w=(pointer)ASET(ctx,4,local+20); /*aset*/
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3515;
irtdynaWHX3516:
	local[20]= NIL;
irtdynaBLK3517:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3518:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3519;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[11];
irtdynaWHL3521:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3522;
	local[22]= local[14];
	local[23]= local[18];
	local[24]= argv[0]->c.obj.iv[20];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	local[25]= local[13];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3521;
irtdynaWHX3522:
	local[22]= NIL;
irtdynaBLK3523:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3518;
irtdynaWHX3519:
	local[20]= NIL;
irtdynaBLK3520:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[11];
irtdynaWHL3524:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3525;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[11];
irtdynaWHL3527:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3528;
	local[22]= local[14];
	local[23]= argv[0]->c.obj.iv[20];
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	local[24]= argv[0]->c.obj.iv[20];
	local[25]= local[20];
	ctx->vsp=local+26;
	w=(pointer)PLUS(ctx,2,local+24); /*+*/
	local[24]= w;
	local[25]= argv[0]->c.obj.iv[22];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3527;
irtdynaWHX3528:
	local[22]= NIL;
irtdynaBLK3529:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3524;
irtdynaWHX3525:
	local[20]= NIL;
irtdynaBLK3526:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3530:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3531;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= argv[0]->c.obj.iv[21];
irtdynaWHL3533:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3534;
	local[22]= local[16];
	local[23]= local[18];
	local[24]= local[20];
	local[25]= local[15];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3533;
irtdynaWHX3534:
	local[22]= NIL;
irtdynaBLK3535:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3530;
irtdynaWHX3531:
	local[20]= NIL;
irtdynaBLK3532:
	w = NIL;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= local[11];
irtdynaWHL3536:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3537;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= argv[0]->c.obj.iv[21];
irtdynaWHL3539:
	local[22]= local[20];
	w = local[21];
	if ((eusinteger_t)local[22] >= (eusinteger_t)w) goto irtdynaWHX3540;
	local[22]= local[16];
	local[23]= argv[0]->c.obj.iv[20];
	local[24]= local[18];
	ctx->vsp=local+25;
	w=(pointer)PLUS(ctx,2,local+23); /*+*/
	local[23]= w;
	local[24]= local[20];
	local[25]= argv[0]->c.obj.iv[23];
	local[26]= local[18];
	local[27]= local[20];
	ctx->vsp=local+28;
	w=(pointer)AREF(ctx,3,local+25); /*aref*/
	local[25]= w;
	ctx->vsp=local+26;
	w=(pointer)ASET(ctx,4,local+22); /*aset*/
	local[22]= local[20];
	ctx->vsp=local+23;
	w=(pointer)ADD1(ctx,1,local+22); /*1+*/
	local[20] = w;
	goto irtdynaWHL3539;
irtdynaWHX3540:
	local[22]= NIL;
irtdynaBLK3541:
	w = NIL;
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3536;
irtdynaWHX3537:
	local[20]= NIL;
irtdynaBLK3538:
	w = NIL;
	if (local[10]==NIL) goto irtdynaIF3542;
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3544:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3545;
	local[20]= local[17];
	local[21]= local[18];
	local[22]= local[18];
	local[23]= local[10];
	local[24]= local[18];
	local[25]= local[18];
	ctx->vsp=local+26;
	w=(pointer)AREF(ctx,3,local+23); /*aref*/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)ASET(ctx,4,local+20); /*aset*/
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3544;
irtdynaWHX3545:
	local[20]= NIL;
irtdynaBLK3546:
	w = NIL;
	local[18]= w;
	goto irtdynaIF3543;
irtdynaIF3542:
	local[18]= makeint((eusinteger_t)0L);
	local[19]= argv[0]->c.obj.iv[20];
irtdynaWHL3547:
	local[20]= local[18];
	w = local[19];
	if ((eusinteger_t)local[20] >= (eusinteger_t)w) goto irtdynaWHX3548;
	local[20]= local[17];
	local[21]= local[18];
	local[22]= local[18];
	local[23]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+24;
	w=(pointer)ASET(ctx,4,local+20); /*aset*/
	local[20]= local[18];
	ctx->vsp=local+21;
	w=(pointer)ADD1(ctx,1,local+20); /*1+*/
	local[18] = w;
	goto irtdynaWHL3547;
irtdynaWHX3548:
	local[20]= NIL;
irtdynaBLK3549:
	w = NIL;
	local[18]= w;
irtdynaIF3543:
	local[18]= argv[0];
	local[19]= *(ovafptr(argv[1],fqv[284]));
	local[20]= fqv[223];
	local[21]= argv[2];
	local[22]= fqv[295];
	local[23]= local[14];
	local[24]= fqv[296];
	local[25]= local[16];
	local[26]= fqv[297];
	local[27]= local[17];
	local[28]= fqv[298];
	local[29]= local[8];
	local[30]= fqv[299];
	local[31]= local[0];
	local[32]= fqv[300];
	local[33]= local[1];
	local[34]= fqv[224];
	local[35]= local[2];
	local[36]= fqv[301];
	local[37]= local[6];
	local[38]= fqv[302];
	local[39]= local[7];
	local[40]= fqv[225];
	local[41]= local[9];
	local[42]= fqv[303];
	local[43]= argv[0]->c.obj.iv[20];
	local[44]= fqv[304];
	local[45]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+46;
	w=(pointer)SENDMESSAGE(ctx,28,local+18); /*send-message*/
	if (argv[0]->c.obj.iv[25]!=NIL) goto irtdynaIF3550;
	local[18]= local[12];
	local[19]= makeint((eusinteger_t)1L);
	ctx->vsp=local+20;
	w=(*ftab[5])(ctx,2,local+18,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[25] = w;
	local[18]= argv[0]->c.obj.iv[24];
	local[19]= argv[0]->c.obj.iv[10];
	ctx->vsp=local+20;
	w=(pointer)MATTIMES(ctx,2,local+18); /*m**/
	local[18]= w;
	local[19]= makeint((eusinteger_t)0L);
	local[20]= argv[0]->c.obj.iv[20];
irtdynaWHL3552:
	local[21]= local[19];
	w = local[20];
	if ((eusinteger_t)local[21] >= (eusinteger_t)w) goto irtdynaWHX3553;
	local[21]= argv[0]->c.obj.iv[25];
	local[22]= local[19];
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[18];
	local[25]= local[19];
	local[26]= makeint((eusinteger_t)0L);
	ctx->vsp=local+27;
	w=(pointer)AREF(ctx,3,local+24); /*aref*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)ASET(ctx,4,local+21); /*aset*/
	local[21]= local[19];
	ctx->vsp=local+22;
	w=(pointer)ADD1(ctx,1,local+21); /*1+*/
	local[19] = w;
	goto irtdynaWHL3552;
irtdynaWHX3553:
	local[21]= NIL;
irtdynaBLK3554:
	w = NIL;
	local[18]= w;
	goto irtdynaIF3551;
irtdynaIF3550:
	local[18]= NIL;
irtdynaIF3551:
	w = argv[0];
	local[0]= w;
irtdynaBLK3503:
	ctx->vsp=local; return(local[0]);}

/*:calc-f*/
static pointer irtdynaM3555extended_preview_controller_calc_f(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[21];
	local[1]= argv[0]->c.obj.iv[20];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[24]); /*make-matrix*/
	argv[0]->c.obj.iv[13] = w;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[279]); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[14])(ctx,1,local+0,&ftab[14],fqv[184]); /*unit-matrix*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)TRANSPOSE(ctx,1,local+1); /*transpose*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)TRANSPOSE(ctx,1,local+2); /*transpose*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[9];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MATTIMES(ctx,2,local+3); /*m**/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[5];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(*ftab[2])(ctx,2,local+4,&ftab[2],fqv[4]); /*scale-matrix*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[12];
irtdynaWHL3557:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto irtdynaWHX3558;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)SUB1(ctx,1,local+8); /*1-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)NUMEQUAL(ctx,2,local+7); /*=*/
	if (w==NIL) goto irtdynaIF3560;
	local[7]= argv[0]->c.obj.iv[4];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)MATTIMES(ctx,2,local+7); /*m**/
	local[7]= w;
	goto irtdynaIF3561;
irtdynaIF3560:
	local[7]= local[4];
irtdynaIF3561:
	local[8]= argv[0]->c.obj.iv[9];
	local[9]= local[1];
	local[10]= local[0];
	local[11]= local[7];
	ctx->vsp=local+12;
	w=(pointer)MATTIMES(ctx,2,local+10); /*m**/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MATTIMES(ctx,2,local+8); /*m**/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[8];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)MATTIMES(ctx,2,local+9); /*m**/
	local[0] = w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= argv[0]->c.obj.iv[21];
irtdynaWHL3562:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto irtdynaWHX3563;
	local[11]= makeint((eusinteger_t)0L);
	local[12]= argv[0]->c.obj.iv[20];
irtdynaWHL3565:
	local[13]= local[11];
	w = local[12];
	if ((eusinteger_t)local[13] >= (eusinteger_t)w) goto irtdynaWHX3566;
	local[13]= argv[0]->c.obj.iv[13];
	local[14]= local[9];
	local[15]= argv[0]->c.obj.iv[20];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)ADD1(ctx,1,local+16); /*1+*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)PLUS(ctx,2,local+15); /*+*/
	local[15]= w;
	local[16]= local[8];
	local[17]= local[9];
	local[18]= local[11];
	ctx->vsp=local+19;
	w=(pointer)AREF(ctx,3,local+16); /*aref*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)ASET(ctx,4,local+13); /*aset*/
	local[13]= local[11];
	ctx->vsp=local+14;
	w=(pointer)ADD1(ctx,1,local+13); /*1+*/
	local[11] = w;
	goto irtdynaWHL3565;
irtdynaWHX3566:
	local[13]= NIL;
irtdynaBLK3567:
	w = NIL;
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto irtdynaWHL3562;
irtdynaWHX3563:
	local[11]= NIL;
irtdynaBLK3564:
	w = NIL;
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto irtdynaWHL3557;
irtdynaWHX3558:
	local[7]= NIL;
irtdynaBLK3559:
	w = NIL;
	local[0]= w;
irtdynaBLK3556:
	ctx->vsp=local; return(local[0]);}

/*:calc-u*/
static pointer irtdynaM3568extended_preview_controller_calc_u(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[13];
	local[1]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[7];
	local[2]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[186]); /*m-*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[11];
	ctx->vsp=local+3;
	w=(*ftab[6])(ctx,2,local+1,&ftab[6],fqv[27]); /*m+*/
	argv[0]->c.obj.iv[11] = w;
	w = local[0];
	local[0]= w;
irtdynaBLK3569:
	ctx->vsp=local; return(local[0]);}

/*:calc-xk*/
static pointer irtdynaM3570extended_preview_controller_calc_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+2;
	w=(pointer)MATTIMES(ctx,2,local+0); /*m**/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0];
	local[3]= fqv[287];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MATTIMES(ctx,2,local+1); /*m**/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[27]); /*m+*/
	argv[0]->c.obj.iv[25] = w;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[22];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[28])(ctx,2,local+1,&ftab[28],fqv[279]); /*array-dimension*/
	local[1]= w;
irtdynaWHL3572:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto irtdynaWHX3573;
	local[2]= argv[0]->c.obj.iv[10];
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[0]->c.obj.iv[10];
	local[6]= local[0];
	local[7]= makeint((eusinteger_t)0L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[25];
	local[7]= argv[0]->c.obj.iv[20];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,4,local+2); /*aset*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto irtdynaWHL3572;
irtdynaWHX3573:
	local[2]= NIL;
irtdynaBLK3574:
	w = NIL;
	local[0]= w;
irtdynaBLK3571:
	ctx->vsp=local; return(local[0]);}

/*:current-output-vector*/
static pointer irtdynaM3575extended_preview_controller_current_output_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(*ftab[30])(ctx,2,local+0,&ftab[30],fqv[293]); /*matrix-column*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
irtdynaBLK3576:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3577preview_control_cart_table_cog_trajectory_generator_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[305], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3579;
	local[0] = makeint((eusinteger_t)1L);
irtdynaKEY3579:
	if (n & (1<<1)) goto irtdynaKEY3580;
	local[1] = makeflt(9.9999999999999974298988e-07);
irtdynaKEY3580:
	if (n & (1<<2)) goto irtdynaKEY3581;
	local[2] = makeflt(1.5999999999999996447286e+00);
irtdynaKEY3581:
	if (n & (1<<3)) goto irtdynaKEY3582;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,3,local+9); /*float-vector*/
	local[3] = w;
irtdynaKEY3582:
	if (n & (1<<4)) goto irtdynaKEY3583;
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)3L);
	local[11]= makeint((eusinteger_t)1L);
	local[12]= argv[2];
	local[13]= makeflt(5.0000000000000000000000e-01);
	local[14]= argv[2];
	local[15]= argv[2];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,3,local+13); /***/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)1L);
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,3,local+12); /*list*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,3,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[4] = w;
irtdynaKEY3583:
	if (n & (1<<5)) goto irtdynaKEY3584;
	local[9]= makeint((eusinteger_t)3L);
	local[10]= makeint((eusinteger_t)1L);
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= makeflt(6.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= argv[2];
	local[13]= argv[2];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,4,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	local[12]= makeflt(5.0000000000000000000000e-01);
	local[13]= argv[2];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,3,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	local[12]= w;
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[5] = w;
irtdynaKEY3584:
	if (n & (1<<6)) goto irtdynaKEY3585;
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)3L);
	local[11]= makeflt(1.0000000000000000000000e+00);
	local[12]= makeflt(0.0000000000000000000000e+00);
	local[13]= argv[3];
	local[14]= loadglobal(fqv[147]);
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MINUS(ctx,1,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,3,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[5])(ctx,3,local+9,&ftab[5],fqv[24]); /*make-matrix*/
	local[6] = w;
irtdynaKEY3585:
	if (n & (1<<7)) goto irtdynaKEY3586;
	local[7] = NIL;
irtdynaKEY3586:
	if (n & (1<<8)) goto irtdynaKEY3587;
	local[8] = loadglobal(fqv[306]);
irtdynaKEY3587:
	local[9]= local[8];
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[223];
	local[12]= argv[2];
	local[13]= fqv[299];
	local[14]= local[0];
	local[15]= fqv[300];
	local[16]= local[1];
	local[17]= fqv[224];
	local[18]= local[2];
	local[19]= fqv[301];
	local[20]= local[3];
	local[21]= makeint((eusinteger_t)0L);
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	local[22]= makeint((eusinteger_t)0L);
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,3,local+20); /*float-vector*/
	local[20]= w;
	local[21]= fqv[295];
	local[22]= local[4];
	local[23]= fqv[296];
	local[24]= local[5];
	local[25]= fqv[297];
	local[26]= local[6];
	local[27]= fqv[298];
	local[28]= makeint((eusinteger_t)3L);
	local[29]= fqv[225];
	local[30]= local[7];
	ctx->vsp=local+31;
	w=(pointer)SEND(ctx,21,local+10); /*send*/
	w = local[9];
	local[9]= w;
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,1,local+10); /*instantiate*/
	local[10]= w;
	local[11]= local[10];
	local[12]= fqv[223];
	local[13]= argv[2];
	local[14]= fqv[299];
	local[15]= local[0];
	local[16]= fqv[300];
	local[17]= local[1];
	local[18]= fqv[224];
	local[19]= local[2];
	local[20]= fqv[301];
	local[21]= local[3];
	local[22]= makeint((eusinteger_t)1L);
	ctx->vsp=local+23;
	w=(pointer)ELT(ctx,2,local+21); /*elt*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)0L);
	ctx->vsp=local+24;
	w=(pointer)MKFLTVEC(ctx,3,local+21); /*float-vector*/
	local[21]= w;
	local[22]= fqv[295];
	local[23]= local[4];
	local[24]= fqv[296];
	local[25]= local[5];
	local[26]= fqv[297];
	local[27]= local[6];
	local[28]= fqv[298];
	local[29]= makeint((eusinteger_t)3L);
	local[30]= fqv[225];
	local[31]= local[7];
	ctx->vsp=local+32;
	w=(pointer)SEND(ctx,21,local+11); /*send*/
	w = local[10];
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	argv[0]->c.obj.iv[1] = w;
	argv[0]->c.obj.iv[2] = argv[3];
	w = argv[0];
	local[0]= w;
irtdynaBLK3578:
	ctx->vsp=local; return(local[0]);}

/*:refcog*/
static pointer irtdynaM3588preview_control_cart_table_cog_trajectory_generator_refcog(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[291];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[291];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3589:
	ctx->vsp=local; return(local[0]);}

/*:cart-zmp*/
static pointer irtdynaM3590preview_control_cart_table_cog_trajectory_generator_cart_zmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[292];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[292];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3591:
	ctx->vsp=local; return(local[0]);}

/*:last-refzmp*/
static pointer irtdynaM3592preview_control_cart_table_cog_trajectory_generator_last_refzmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[288];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[288];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3593:
	ctx->vsp=local; return(local[0]);}

/*:current-refzmp*/
static pointer irtdynaM3594preview_control_cart_table_cog_trajectory_generator_current_refzmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[290];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[290];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,3,local+0); /*float-vector*/
	local[0]= w;
irtdynaBLK3595:
	ctx->vsp=local; return(local[0]);}

/*:update-xk*/
static pointer irtdynaM3596preview_control_cart_table_cog_trajectory_generator_update_xk(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto irtdynaENT3599;}
	local[0]= NIL;
irtdynaENT3599:
irtdynaENT3598:
	if (n>4) maerror();
	if (argv[2]==NIL) goto irtdynaIF3600;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)ELT(ctx,2,local+1); /*elt*/
	argv[0]->c.obj.iv[3] = w;
	local[1]= argv[0]->c.obj.iv[3];
	goto irtdynaIF3601;
irtdynaIF3600:
	local[1]= NIL;
irtdynaIF3601:
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= fqv[229];
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)SUBSEQ(ctx,3,local+3); /*subseq*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[229];
	local[4]= argv[2];
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)2L);
	ctx->vsp=local+7;
	w=(pointer)SUBSEQ(ctx,3,local+4); /*subseq*/
	local[4]= w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	if (local[2]==NIL) goto irtdynaAND3602;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
irtdynaAND3602:
	local[1] = local[2];
	if (local[1]==NIL) goto irtdynaIF3603;
	local[2]= argv[0];
	local[3]= fqv[307];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[236];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[308];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	goto irtdynaIF3604;
irtdynaIF3603:
	local[2]= NIL;
irtdynaIF3604:
	w = local[2];
	local[0]= w;
irtdynaBLK3597:
	ctx->vsp=local; return(local[0]);}

/*:finishedp*/
static pointer irtdynaM3605preview_control_cart_table_cog_trajectory_generator_finishedp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[228];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	if (w==NIL) goto irtdynaAND3607;
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[228];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaAND3607:
	w = local[0];
	local[0]= w;
irtdynaBLK3606:
	ctx->vsp=local; return(local[0]);}

/*:current-additional-data*/
static pointer irtdynaM3608preview_control_cart_table_cog_trajectory_generator_current_additional_data(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= fqv[230];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaBLK3609:
	ctx->vsp=local; return(local[0]);}

/*:pass-preview-controller*/
static pointer irtdynaM3610preview_control_cart_table_cog_trajectory_generator_pass_preview_controller(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
irtdynaWHL3612:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]!=NIL) goto irtdynaWHX3613;
	goto irtdynaWHL3612;
irtdynaWHX3613:
	local[2]= NIL;
irtdynaBLK3614:
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
irtdynaWHL3615:
	local[2]= argv[0];
	local[3]= fqv[229];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[4];
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[0] = w;
	if (local[0]==NIL) goto irtdynaWHX3616;
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto irtdynaWHL3615;
irtdynaWHX3616:
	local[2]= NIL;
irtdynaBLK3617:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)REVERSE(ctx,1,local+2); /*reverse*/
	local[0]= w;
irtdynaBLK3611:
	ctx->vsp=local; return(local[0]);}

/*:cog-z*/
static pointer irtdynaM3618preview_control_cart_table_cog_trajectory_generator_cog_z(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
irtdynaBLK3619:
	ctx->vsp=local; return(local[0]);}

/*:update-cog-z*/
static pointer irtdynaM3620preview_control_cart_table_cog_trajectory_generator_update_cog_z(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3622,env,argv,local);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtdynaBLK3621:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3622(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= *(ovafptr(argv[0],fqv[309]));
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)2L);
	local[3]= env->c.clo.env1[2];
	local[4]= loadglobal(fqv[147]);
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)QUOTIENT(ctx,2,local+3); /*/*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,1,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,4,local+0); /*aset*/
	local[0]= argv[0];
	local[1]= fqv[285];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[286];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtdynaM3623gait_generator_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	local[0]= NIL;
	local[1]= fqv[310];
irtdynaWHL3625:
	if (local[1]==NIL) goto irtdynaWHX3626;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= fqv[311];
	local[3]= fqv[312];
	local[4]= NIL;
	local[5]= fqv[313];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[31])(ctx,1,local+4,&ftab[31],fqv[314]); /*read-from-string*/
	local[4]= w;
	local[5]= fqv[315];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	local[5]= w;
	local[6]= fqv[316];
	local[7]= local[0];
	local[8]= fqv[317];
	local[9]= local[0];
	local[10]= fqv[318];
	local[11]= fqv[315];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)EVAL(ctx,1,local+2); /*eval*/
	goto irtdynaWHL3625;
irtdynaWHX3626:
	local[2]= NIL;
irtdynaBLK3627:
	w = NIL;
	w = argv[0];
	local[0]= w;
irtdynaBLK3624:
	ctx->vsp=local; return(local[0]);}

/*:get-footstep-limbs*/
static pointer irtdynaM3628gait_generator_get_footstep_limbs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3630,env,argv,local);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)MAPCAR(ctx,2,local+0); /*mapcar*/
	local[0]= w;
irtdynaBLK3629:
	ctx->vsp=local; return(local[0]);}

/*:get-counter-footstep-limbs*/
static pointer irtdynaM3631gait_generator_get_counter_footstep_limbs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!issymbol(w)) goto irtdynaIF3633;
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3635,env,argv,local);
	local[1]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[319]); /*remove-if*/
	local[0]= w;
	goto irtdynaIF3634;
irtdynaIF3633:
	local[0]= argv[0];
	local[1]= fqv[320];
	local[2]= argv[0];
	local[3]= fqv[321];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtdynaIF3634:
	w = local[0];
	local[0]= w;
irtdynaBLK3632:
	ctx->vsp=local; return(local[0]);}

/*:get-limbs-zmp-list*/
static pointer irtdynaM3636gait_generator_get_limbs_zmp_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3638,env,argv,local);
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,3,local+0); /*mapcar*/
	local[0]= w;
irtdynaBLK3637:
	ctx->vsp=local; return(local[0]);}

/*:get-limbs-zmp*/
static pointer irtdynaM3639gait_generator_get_limbs_zmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= (pointer)get_sym_func(fqv[322]);
	local[2]= argv[0];
	local[3]= fqv[323];
	local[4]= argv[2];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	local[2]= w;
	local[3]= fqv[324];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[33])(ctx,4,local+1,&ftab[33],fqv[325]); /*reduce*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SCALEVEC(ctx,2,local+0); /*scale*/
	local[0]= w;
irtdynaBLK3640:
	ctx->vsp=local; return(local[0]);}

/*:get-swing-limbs*/
static pointer irtdynaM3641gait_generator_get_swing_limbs(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,irtdynaCLO3643,env,argv,local);
	local[1]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+2;
	w=(*ftab[32])(ctx,2,local+0,&ftab[32],fqv[319]); /*remove-if*/
	local[0]= w;
irtdynaBLK3642:
	ctx->vsp=local; return(local[0]);}

/*:initialize-gait-parameter*/
static pointer irtdynaM3644gait_generator_initialize_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[326], &argv[5], n-5, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3646;
	local[0] = makeint((eusinteger_t)50L);
irtdynaKEY3646:
	if (n & (1<<1)) goto irtdynaKEY3647;
	local[1] = makeflt(1.9999999999999995559108e-01);
irtdynaKEY3647:
	if (n & (1<<2)) goto irtdynaKEY3648;
	local[2] = makeflt(1.5999999999999996447286e+00);
irtdynaKEY3648:
	if (n & (1<<3)) goto irtdynaKEY3649;
	local[3] = fqv[327];
irtdynaKEY3649:
	if (n & (1<<4)) goto irtdynaKEY3650;
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3651,env,argv,local);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)MAPCAN(ctx,2,local+11); /*mapcan*/
	local[4] = w;
irtdynaKEY3650:
	if (n & (1<<5)) goto irtdynaKEY3652;
	local[5] = makeflt(1.0000000000000000000000e+00);
irtdynaKEY3652:
	if (n & (1<<6)) goto irtdynaKEY3653;
	local[6] = makeflt(9.9999999999999974298988e-07);
irtdynaKEY3653:
	if (n & (1<<7)) goto irtdynaKEY3654;
	local[7] = makeint((eusinteger_t)1L);
irtdynaKEY3654:
	if (n & (1<<8)) goto irtdynaKEY3655;
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(*ftab[24])(ctx,1,local+11,&ftab[24],fqv[260]); /*deg2rad*/
	local[8] = w;
irtdynaKEY3655:
	if (n & (1<<9)) goto irtdynaKEY3656;
	local[9] = T;
irtdynaKEY3656:
	if (n & (1<<10)) goto irtdynaKEY3657;
	local[10] = T;
irtdynaKEY3657:
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,irtdynaCLO3658,env,argv,local);
	local[12]= argv[2];
	ctx->vsp=local+13;
	w=(pointer)MAPCAR(ctx,2,local+11); /*mapcar*/
	argv[0]->c.obj.iv[3] = w;
	local[11]= argv[3];
	local[12]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)ROUND(ctx,1,local+11); /*round*/
	argv[0]->c.obj.iv[12] = w;
	argv[0]->c.obj.iv[5] = NIL;
	argv[0]->c.obj.iv[4] = NIL;
	argv[0]->c.obj.iv[6] = NIL;
	argv[0]->c.obj.iv[8] = NIL;
	argv[0]->c.obj.iv[11] = NIL;
	argv[0]->c.obj.iv[14] = local[0];
	argv[0]->c.obj.iv[15] = local[1];
	argv[0]->c.obj.iv[16] = local[4];
	argv[0]->c.obj.iv[13] = argv[0]->c.obj.iv[12];
	argv[0]->c.obj.iv[17] = NIL;
	argv[0]->c.obj.iv[19] = local[3];
	argv[0]->c.obj.iv[21] = local[7];
	argv[0]->c.obj.iv[22] = local[8];
	argv[0]->c.obj.iv[20] = local[10];
	argv[0]->c.obj.iv[25] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[24] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[23] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[28] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[27] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[26] = makeint((eusinteger_t)0L);
	local[11]= argv[0];
	local[12]= fqv[321];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	local[12]= argv[0];
	local[13]= fqv[328];
	local[14]= argv[0];
	local[15]= fqv[320];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= argv[0];
	local[14]= fqv[329];
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtdynaCLO3659,env,argv,local);
	local[16]= local[12];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,2,local+15); /*mapcar*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= argv[0];
	local[14]= fqv[330];
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtdynaCLO3660,env,argv,local);
	local[16]= local[11];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,2,local+15); /*mapcar*/
	local[15]= w;
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[14]= (w)->c.cons.car;
	local[15]= argv[0];
	local[16]= fqv[331];
	local[17]= argv[0];
	local[18]= fqv[332];
	if (local[9]==NIL) goto irtdynaIF3661;
	local[19]= local[14];
	local[20]= local[13];
	ctx->vsp=local+21;
	w=(pointer)APPEND(ctx,2,local+19); /*append*/
	local[19]= w;
	goto irtdynaIF3662;
irtdynaIF3661:
	local[19]= local[14];
irtdynaIF3662:
	if (local[9]==NIL) goto irtdynaIF3663;
	local[20]= local[11];
	local[21]= local[12];
	ctx->vsp=local+22;
	w=(pointer)APPEND(ctx,2,local+20); /*append*/
	local[20]= w;
	goto irtdynaIF3664;
irtdynaIF3663:
	local[20]= local[11];
irtdynaIF3664:
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,4,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= argv[0];
	local[16]= fqv[333];
	local[17]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.cdr;
	w = local[15];
	local[15]= loadglobal(fqv[222]);
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,1,local+15); /*instantiate*/
	local[15]= w;
	local[16]= local[15];
	local[17]= fqv[223];
	local[18]= argv[0]->c.obj.iv[2];
	local[19]= argv[4];
	local[20]= makeint((eusinteger_t)2L);
	ctx->vsp=local+21;
	w=(pointer)ELT(ctx,2,local+19); /*elt*/
	local[19]= w;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= makeint((eusinteger_t)2L);
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)MINUS(ctx,2,local+19); /*-*/
	local[19]= w;
	local[20]= fqv[224];
	local[21]= local[2];
	local[22]= fqv[299];
	local[23]= local[5];
	local[24]= fqv[300];
	local[25]= local[6];
	local[26]= fqv[301];
	local[27]= argv[4];
	local[28]= fqv[226];
	local[29]= loadglobal(fqv[306]);
	ctx->vsp=local+30;
	w=(pointer)SEND(ctx,14,local+16); /*send*/
	w = local[15];
	argv[0]->c.obj.iv[18] = w;
	argv[0]->c.obj.iv[7] = local[14];
	local[15]= argv[0];
	local[16]= fqv[332];
	ctx->vsp=local+17;
	local[17]= makeclosure(codevec,quotevec,irtdynaCLO3665,env,argv,local);
	local[18]= argv[0];
	local[19]= fqv[320];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[58];
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,2,local+20,&ftab[7],fqv[29]); /*send-all*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)MAPCAR(ctx,2,local+17); /*mapcar*/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[320];
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[20]= (w)->c.cons.car;
	local[21]= fqv[58];
	ctx->vsp=local+22;
	w=(*ftab[7])(ctx,2,local+20,&ftab[7],fqv[29]); /*send-all*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,3,local+18); /*send*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,4,local+15); /*send*/
	argv[0]->c.obj.iv[9] = w;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[10] = (w)->c.cons.car;
	local[15]= argv[0];
	local[16]= fqv[334];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	w = T;
	local[0]= w;
irtdynaBLK3645:
	ctx->vsp=local; return(local[0]);}

/*:finalize-gait-parameter*/
static pointer irtdynaM3666gait_generator_finalize_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[0];
	local[3]= fqv[328];
	local[4]= argv[0];
	local[5]= fqv[320];
	local[6]= argv[0];
	local[7]= fqv[336];
	local[8]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+9;
	w=(pointer)REVERSE(ctx,1,local+8); /*reverse*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[329];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3668,env,argv,local);
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(*ftab[34])(ctx,1,local+5,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[330];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3669,env,argv,local);
	local[5]= argv[0];
	local[6]= fqv[336];
	local[7]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,3,local+5); /*send*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[331];
	local[4]= argv[0];
	local[5]= fqv[332];
	if (argv[0]->c.obj.iv[20]==NIL) goto irtdynaIF3670;
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	goto irtdynaIF3671;
irtdynaIF3670:
	local[6]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
irtdynaIF3671:
	if (argv[0]->c.obj.iv[20]==NIL) goto irtdynaIF3672;
	local[7]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= argv[0];
	local[9]= fqv[320];
	local[10]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,1,local+10,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10]= (w)->c.cons.car;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[7]= w;
	goto irtdynaIF3673;
irtdynaIF3672:
	local[7]= argv[0];
	local[8]= fqv[320];
	local[9]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+10;
	w=(*ftab[34])(ctx,1,local+9,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
irtdynaIF3673:
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[333];
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+3;
	w=(*ftab[34])(ctx,1,local+2,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.car;
	w = T;
	local[0]= w;
irtdynaBLK3667:
	ctx->vsp=local; return(local[0]);}

/*:make-gait-parameter*/
static pointer irtdynaM3674gait_generator_make_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[3] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,1,local+1,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= argv[0];
	local[3]= fqv[328];
	local[4]= argv[0];
	local[5]= fqv[320];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[329];
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,irtdynaCLO3676,env,argv,local);
	local[5]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+6;
	w=(*ftab[34])(ctx,1,local+5,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)MAPCAR(ctx,2,local+4); /*mapcar*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[330];
	local[4]= local[0];
	local[5]= fqv[337];
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,2,local+4,&ftab[7],fqv[29]); /*send-all*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[331];
	local[4]= argv[0];
	local[5]= fqv[332];
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(*ftab[34])(ctx,1,local+6,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+8;
	w=(*ftab[34])(ctx,1,local+7,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= argv[0];
	local[3]= fqv[333];
	local[4]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	w = T;
	local[0]= w;
irtdynaBLK3675:
	ctx->vsp=local; return(local[0]);}

/*:calc-hoffarbib-pos-vel-acc*/
static pointer irtdynaM3677gait_generator_calc_hoffarbib_pos_vel_acc(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=7) maerror();
	local[0]= makeflt(-9.0000000000000000000000e+00);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(-3.6000000000000000000000e+01);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(*ftab[35])(ctx,2,local+2,&ftab[35],fqv[338]); /*expt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= makeflt(6.0000000000000000000000e+01);
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)3L);
	ctx->vsp=local+4;
	w=(*ftab[35])(ctx,2,local+2,&ftab[35],fqv[338]); /*expt*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	local[2]= argv[3];
	local[3]= argv[6];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= argv[4];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	local[2]= argv[5];
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	local[3]= argv[6];
	local[4]= argv[0]->c.obj.iv[2];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,3,local+4); /*list*/
	local[0]= w;
irtdynaBLK3678:
	ctx->vsp=local; return(local[0]);}

/*:calc-current-swing-leg-coords*/
static pointer irtdynaM3679gait_generator_calc_current_swing_leg_coords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[339],w);
	ctx->vsp=local+3;
	n=parsekeyparams(fqv[340], &argv[5], n-5, local+3, 0);
	if (n & (1<<0)) goto irtdynaKEY3681;
	local[3] = fqv[341];
irtdynaKEY3681:
	if (n & (1<<1)) goto irtdynaKEY3682;
	local[4] = argv[0]->c.obj.iv[14];
irtdynaKEY3682:
	local[5]= local[3];
	local[6]= local[5];
	if (fqv[341]!=local[6]) goto irtdynaIF3683;
	local[6]= loadglobal(fqv[339]);
	local[7]= argv[3];
	local[8]= argv[4];
	ctx->vsp=local+9;
	w=(*ftab[36])(ctx,3,local+6,&ftab[36],fqv[342]); /*midcoords*/
	local[6]= w;
	goto irtdynaIF3684;
irtdynaIF3683:
	local[6]= local[5];
	if (fqv[343]!=local[6]) goto irtdynaIF3685;
	local[6]= argv[0];
	local[7]= fqv[344];
	local[8]= loadglobal(fqv[339]);
	local[9]= argv[3];
	local[10]= argv[4];
	local[11]= local[4];
	local[12]= fqv[345];
	local[13]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,8,local+6); /*send*/
	local[6]= w;
	goto irtdynaIF3686;
irtdynaIF3685:
	local[6]= NIL;
irtdynaIF3686:
irtdynaIF3684:
	w = local[6];
	local[5]= w;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
irtdynaBLK3680:
	ctx->vsp=local; return(local[0]);}

/*:calc-ratio-from-double-support-ratio*/
static pointer irtdynaM3687gait_generator_calc_ratio_from_double_support_ratio(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+3;
	w=(pointer)EUSFLOAT(ctx,1,local+2); /*float*/
	local[2]= w;
	local[3]= makeflt(5.0000000000000000000000e-01);
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,3,local+3); /***/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= local[1];
	local[3]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtdynaCON3690;
	local[2]= makeflt(0.0000000000000000000000e+00);
	goto irtdynaCON3689;
irtdynaCON3690:
	local[2]= local[1];
	local[3]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtdynaCON3691;
	local[2]= makeflt(1.0000000000000000000000e+00);
	goto irtdynaCON3689;
irtdynaCON3691:
	local[2]= local[1];
	goto irtdynaCON3689;
irtdynaCON3692:
	local[2]= NIL;
irtdynaCON3689:
	w = local[2];
	local[0]= w;
irtdynaBLK3688:
	ctx->vsp=local; return(local[0]);}

/*:calc-current-refzmp*/
static pointer irtdynaM3693gait_generator_calc_current_refzmp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= makeflt(5.0000000000000000000000e-01);
	local[2]= argv[0]->c.obj.iv[15];
	local[3]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,3,local+1); /***/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto irtdynaCON3696;
	local[2]= makeflt(-5.0000000000000000000000e-01);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,3,local+2,&ftab[37],fqv[346]); /*midpoint*/
	local[2]= w;
	goto irtdynaCON3695;
irtdynaCON3696:
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[12];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto irtdynaCON3697;
	local[2]= makeflt(5.0000000000000000000000e-01);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[12];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	local[3]= argv[3];
	local[4]= argv[4];
	ctx->vsp=local+5;
	w=(*ftab[37])(ctx,3,local+2,&ftab[37],fqv[346]); /*midpoint*/
	local[2]= w;
	goto irtdynaCON3695;
irtdynaCON3697:
	local[2]= argv[3];
	goto irtdynaCON3695;
irtdynaCON3698:
	local[2]= NIL;
irtdynaCON3695:
	w = local[2];
	local[0]= w;
irtdynaBLK3694:
	ctx->vsp=local; return(local[0]);}

/*:calc-one-tick-gait-parameter*/
static pointer irtdynaM3699gait_generator_calc_one_tick_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeflt(5.0000000000000000000000e-01);
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,3,local+0); /***/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)TRUNCATE(ctx,1,local+0); /*truncate*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[13];
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto irtdynaCON3702;
	argv[0]->c.obj.iv[28] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[27] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[26] = makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[26];
	goto irtdynaCON3701;
irtdynaCON3702:
	local[1]= argv[0]->c.obj.iv[13];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto irtdynaCON3703;
	argv[0]->c.obj.iv[28] = makeflt(1.0000000000000000000000e+00);
	argv[0]->c.obj.iv[27] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[26] = makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[26];
	goto irtdynaCON3701;
irtdynaCON3703:
	local[1]= argv[0];
	local[2]= fqv[347];
	local[3]= argv[0]->c.obj.iv[13];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= argv[0]->c.obj.iv[26];
	local[6]= argv[0]->c.obj.iv[27];
	local[7]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,7,local+1); /*send*/
	local[1]= w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[28] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[27] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[26] = (w)->c.cons.car;
	w = argv[0]->c.obj.iv[26];
	local[1]= w;
	goto irtdynaCON3701;
irtdynaCON3704:
	local[1]= NIL;
irtdynaCON3701:
	w = local[1];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtdynaCLO3705,env,argv,local);
	local[3]= argv[0]->c.obj.iv[7];
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,3,local+2); /*mapcar*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[348];
	local[5]= argv[0]->c.obj.iv[10];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= argv[0]->c.obj.iv[9];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0]->c.obj.iv[13];
	local[5]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+6;
	w=(pointer)NUMEQUAL(ctx,2,local+4); /*=*/
	if (w==NIL) goto irtdynaIF3706;
	argv[0]->c.obj.iv[25] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[24] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[23] = makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[23];
	goto irtdynaIF3707;
irtdynaIF3706:
	local[4]= NIL;
irtdynaIF3707:
	local[4]= argv[0];
	local[5]= fqv[347];
	local[6]= argv[0]->c.obj.iv[13];
	local[7]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= makeflt(1.0000000000000000000000e+00);
	local[8]= argv[0]->c.obj.iv[23];
	local[9]= argv[0]->c.obj.iv[24];
	local[10]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,7,local+4); /*send*/
	local[4]= w;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[25] = (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[24] = (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[23] = (w)->c.cons.car;
	w = argv[0]->c.obj.iv[23];
	local[4]= argv[0]->c.obj.iv[25];
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtdynaCLO3708,env,argv,local);
	local[6]= argv[0]->c.obj.iv[7];
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)MAPCAR(ctx,3,local+5); /*mapcar*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[320];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[18];
	local[8]= fqv[349];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[332];
	local[10]= local[5];
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)APPEND(ctx,2,local+10); /*append*/
	local[10]= w;
	local[11]= local[6];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,4,local+8); /*send*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)PLUS(ctx,2,local+7); /*+*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[12];
	local[6]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= argv[0]->c.obj.iv[15];
	local[8]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,3,local+6); /***/
	local[6]= w;
	local[7]= local[5];
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(pointer)LESSP(ctx,2,local+7); /*<*/
	if (w!=NIL) goto irtdynaOR3711;
	local[7]= local[5];
	local[8]= argv[0]->c.obj.iv[12];
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)GREATERP(ctx,2,local+7); /*>*/
	if (w!=NIL) goto irtdynaOR3711;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	ctx->vsp=local+8;
	w=(pointer)EUSFLOAT(ctx,1,local+7); /*float*/
	local[7]= w;
	local[8]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+9;
	w=(*ftab[4])(ctx,2,local+7,&ftab[4],fqv[22]); /*eps=*/
	if (w!=NIL) goto irtdynaOR3711;
	goto irtdynaIF3709;
irtdynaOR3711:
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtdynaCLO3712,env,argv,local);
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
	goto irtdynaIF3710;
irtdynaIF3709:
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,irtdynaCLO3713,env,argv,local);
	local[8]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+9;
	w=(pointer)MAPCAR(ctx,2,local+7); /*mapcar*/
	local[7]= w;
irtdynaIF3710:
	w = local[7];
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,6,local+0); /*list*/
	local[0]= w;
irtdynaBLK3700:
	ctx->vsp=local; return(local[0]);}

/*:proc-one-tick*/
static pointer irtdynaM3714gait_generator_proc_one_tick(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[350], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3716;
	local[0] = fqv[341];
irtdynaKEY3716:
	if (n & (1<<1)) goto irtdynaKEY3717;
	local[1] = fqv[351];
irtdynaKEY3717:
	if (n & (1<<2)) goto irtdynaKEY3718;
	local[2] = NIL;
irtdynaKEY3718:
	if (n & (1<<3)) goto irtdynaKEY3719;
	local[3] = NIL;
irtdynaKEY3719:
	if (argv[0]->c.obj.iv[5]==NIL) goto irtdynaIF3720;
	local[4]= argv[0];
	local[5]= fqv[352];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto irtdynaIF3721;
irtdynaIF3720:
	local[4]= NIL;
irtdynaIF3721:
	local[5]= argv[0]->c.obj.iv[18];
	local[6]= fqv[229];
	if (local[4]==NIL) goto irtdynaIF3722;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)3L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	goto irtdynaIF3723;
irtdynaIF3722:
	local[7]= NIL;
irtdynaIF3723:
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,4,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[18];
	local[7]= fqv[230];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	if (local[5]==NIL) goto irtdynaIF3724;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)4L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SETELT(ctx,3,local+7); /*setelt*/
	local[7]= w;
	goto irtdynaIF3725;
irtdynaIF3724:
	local[7]= NIL;
irtdynaIF3725:
	if (local[5]==NIL) goto irtdynaIF3726;
	if (local[1]==NIL) goto irtdynaIF3726;
	local[7]= argv[0];
	local[8]= fqv[353];
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)ELT(ctx,2,local+9); /*elt*/
	local[9]= w;
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)ELT(ctx,2,local+10); /*elt*/
	local[10]= w;
	local[11]= local[6];
	local[12]= makeint((eusinteger_t)2L);
	ctx->vsp=local+13;
	w=(pointer)ELT(ctx,2,local+11); /*elt*/
	local[11]= w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	local[13]= fqv[353];
	local[14]= local[1];
	local[15]= fqv[354];
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,10,local+7); /*send*/
	local[7]= w;
	if (local[3]==NIL) goto irtdynaIF3728;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)BUTLAST(ctx,2,local+8); /*butlast*/
	local[8]= w;
	w=local[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[9]= (w)->c.cons.car;
	local[10]= argv[0]->c.obj.iv[18];
	local[11]= fqv[308];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,2,local+9); /*list*/
	local[9]= w;
	local[10]= local[6];
	ctx->vsp=local+11;
	w=(*ftab[34])(ctx,1,local+10,&ftab[34],fqv[335]); /*last*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)APPEND(ctx,3,local+8); /*append*/
	local[8]= w;
	goto irtdynaIF3729;
irtdynaIF3728:
	local[8]= NIL;
irtdynaIF3729:
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[7]= w;
	goto irtdynaIF3727;
irtdynaIF3726:
	local[7]= NIL;
irtdynaIF3727:
	local[8]= makeint((eusinteger_t)0L);
	local[9]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+10;
	w=(pointer)SUB1(ctx,1,local+9); /*1-*/
	argv[0]->c.obj.iv[13] = w;
	local[9]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+10;
	w=(pointer)GREQP(ctx,2,local+8); /*>=*/
	if (w==NIL) goto irtdynaIF3730;
	local[8]= argv[0];
	local[9]= fqv[355];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	goto irtdynaIF3731;
irtdynaIF3730:
	local[8]= NIL;
irtdynaIF3731:
	w = local[7];
	local[0]= w;
irtdynaBLK3715:
	ctx->vsp=local; return(local[0]);}

/*:update-current-gait-parameter*/
static pointer irtdynaM3732gait_generator_update_current_gait_parameter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[10] = (w)->c.cons.car;
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	if (argv[0]->c.obj.iv[3]==NIL) goto irtdynaCON3735;
	local[1]= argv[0];
	local[2]= fqv[334];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto irtdynaCON3734;
irtdynaCON3735:
	if (argv[0]->c.obj.iv[17]!=NIL) goto irtdynaCON3736;
	local[1]= argv[0];
	local[2]= fqv[356];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	argv[0]->c.obj.iv[17] = T;
	local[1]= argv[0]->c.obj.iv[17];
	goto irtdynaCON3734;
irtdynaCON3736:
	local[1]= NIL;
irtdynaCON3734:
	argv[0]->c.obj.iv[13] = argv[0]->c.obj.iv[12];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[4] = (w)->c.cons.cdr;
	w = local[1];
	if (argv[0]->c.obj.iv[4]==NIL) goto irtdynaIF3737;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtdynaCLO3739,env,argv,local);
	local[2]= argv[0];
	local[3]= fqv[336];
	w=argv[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAR(ctx,2,local+1); /*mapcar*/
	local[1]= w;
	goto irtdynaIF3738;
irtdynaIF3737:
	local[1]= NIL;
irtdynaIF3738:
	argv[0]->c.obj.iv[7] = local[1];
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[5] = (w)->c.cons.cdr;
	w = local[1];
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[6] = (w)->c.cons.cdr;
	w = local[0];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[8] = (w)->c.cons.cdr;
	w = local[0];
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[11] = (w)->c.cons.cdr;
	w = local[0];
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.car==NIL) goto irtdynaIF3740;
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.car;
	local[0]= argv[0]->c.obj.iv[9];
	goto irtdynaIF3741;
irtdynaIF3740:
	w=argv[0]->c.obj.iv[8];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[9] = (w)->c.cons.car;
	local[0]= argv[0]->c.obj.iv[9];
irtdynaIF3741:
	w = local[0];
	local[0]= w;
irtdynaBLK3733:
	ctx->vsp=local; return(local[0]);}

/*:solve-angle-vector*/
static pointer irtdynaM3742gait_generator_solve_angle_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[357], &argv[6], n-6, local+0, 0);
	if (n & (1<<0)) goto irtdynaKEY3744;
	local[0] = fqv[351];
irtdynaKEY3744:
	if (n & (1<<1)) goto irtdynaKEY3745;
	local[1] = NIL;
irtdynaKEY3745:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[12])(ctx,1,local+2,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto irtdynaCON3747;
	local[2]= local[0];
	local[3]= argv[2];
	local[4]= argv[3];
	local[5]= argv[4];
	local[6]= argv[5];
	local[7]= argv[0]->c.obj.iv[1];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,7,local+2); /*apply*/
	local[2]= w;
	goto irtdynaCON3746;
irtdynaCON3747:
	w = local[0];
	if (!issymbol(w)) goto irtdynaCON3748;
	local[2]= argv[0];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(*ftab[38])(ctx,2,local+2,&ftab[38],fqv[358]); /*find-method*/
	if (w==NIL) goto irtdynaCON3748;
	local[2]= (pointer)get_sym_func(fqv[82]);
	local[3]= argv[0];
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= argv[3];
	local[7]= argv[4];
	local[8]= argv[5];
	local[9]= argv[0]->c.obj.iv[1];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,9,local+2); /*apply*/
	local[2]= w;
	goto irtdynaCON3746;
irtdynaCON3748:
	local[2]= fqv[359];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto irtdynaCON3746;
irtdynaCON3749:
	local[2]= NIL;
irtdynaCON3746:
	local[3]= local[2];
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= fqv[74];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[68];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[0]= w;
irtdynaBLK3743:
	ctx->vsp=local; return(local[0]);}

/*:solve-av-by-move-centroid-on-foot*/
static pointer irtdynaM3750gait_generator_solve_av_by_move_centroid_on_foot(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<7) maerror();
irtdynaRST3752:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-7);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[360], &argv[7], n-7, local+1, 1);
	if (n & (1<<0)) goto irtdynaKEY3753;
	local[1] = makeflt(3.5000000000000000000000e+00);
irtdynaKEY3753:
	if (n & (1<<1)) goto irtdynaKEY3754;
	local[2] = makeint((eusinteger_t)100L);
irtdynaKEY3754:
	if (n & (1<<2)) goto irtdynaKEY3755;
	local[3] = NIL;
irtdynaKEY3755:
	local[4]= argv[0];
	local[5]= fqv[320];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)APPEND(ctx,2,local+4); /*append*/
	local[4]= w;
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,irtdynaCLO3756,env,argv,local);
	local[6]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+7;
	w=(pointer)MAPCAR(ctx,2,local+5); /*mapcar*/
	local[5]= w;
	local[6]= argv[4];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	local[7]= fqv[264];
	w = local[0];
	if (memq(local[7],w)!=NIL) goto irtdynaIF3757;
	local[7]= local[0];
	local[8]= fqv[264];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3759,env,argv,local);
	local[10]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[0] = w;
	local[7]= local[0];
	goto irtdynaIF3758;
irtdynaIF3757:
	local[7]= NIL;
irtdynaIF3758:
	local[7]= fqv[265];
	w = local[0];
	if (memq(local[7],w)!=NIL) goto irtdynaIF3760;
	local[7]= local[0];
	local[8]= fqv[265];
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,irtdynaCLO3762,env,argv,local);
	local[10]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+11;
	w=(pointer)MAPCAR(ctx,2,local+9); /*mapcar*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,2,local+8); /*list*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)APPEND(ctx,2,local+7); /*append*/
	local[0] = w;
	local[7]= local[0];
	goto irtdynaIF3761;
irtdynaIF3760:
	local[7]= NIL;
irtdynaIF3761:
	local[7]= (pointer)get_sym_func(fqv[82]);
	local[8]= argv[6];
	local[9]= fqv[231];
	local[10]= fqv[232];
	local[11]= argv[0]->c.obj.iv[19];
	local[12]= fqv[235];
	local[13]= argv[5];
	local[14]= fqv[361];
	ctx->vsp=local+15;
	local[15]= makeclosure(codevec,quotevec,irtdynaCLO3763,env,argv,local);
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)MAPCAR(ctx,2,local+15); /*mapcar*/
	local[15]= w;
	local[16]= fqv[362];
	local[17]= local[1];
	local[18]= fqv[363];
	local[19]= local[2];
	local[20]= fqv[364];
	local[21]= local[3];
	local[22]= argv[6];
	local[23]= fqv[74];
	ctx->vsp=local+24;
	w=(pointer)SEND(ctx,2,local+22); /*send*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	ctx->vsp=local+23;
	local[23]= makeclosure(codevec,quotevec,irtdynaCLO3764,env,argv,local);
	ctx->vsp=local+24;
	w=(pointer)LIST(ctx,2,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,1,local+22); /*list*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)APPEND(ctx,2,local+21); /*append*/
	local[21]= w;
	local[22]= local[0];
	ctx->vsp=local+23;
	w=(pointer)APPLY(ctx,16,local+7); /*apply*/
	local[0]= w;
irtdynaBLK3751:
	ctx->vsp=local; return(local[0]);}

/*:cycloid-midpoint*/
static pointer irtdynaM3765gait_generator_cycloid_midpoint(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[339],w);
	ctx->vsp=local+3;
	n=parsekeyparams(fqv[365], &argv[6], n-6, local+3, 0);
	if (n & (1<<0)) goto irtdynaKEY3767;
	local[3] = makeflt(5.0000000000000000000000e-01);
irtdynaKEY3767:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[5];
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,3,local+4); /*float-vector*/
	local[4]= w;
	local[5]= local[3];
	local[6]= argv[3];
	local[7]= argv[4];
	ctx->vsp=local+8;
	w=(*ftab[37])(ctx,3,local+5,&ftab[37],fqv[346]); /*midpoint*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)VPLUS(ctx,2,local+4); /*v+*/
	local[4]= w;
	local[5]= loadglobal(fqv[339]);
	local[6]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto irtdynaIF3768;
	local[5]= argv[4];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
	goto irtdynaIF3769;
irtdynaIF3768:
	local[5]= local[4];
	local[6]= argv[3];
	ctx->vsp=local+7;
	w=(pointer)VMINUS(ctx,2,local+5); /*v-*/
	local[5]= w;
irtdynaIF3769:
	local[6]= argv[4];
	local[7]= argv[3];
	ctx->vsp=local+8;
	w=(pointer)VMINUS(ctx,2,local+6); /*v-*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ABS(ctx,1,local+7); /*abs*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+11;
	w=(pointer)MKFLTVEC(ctx,3,local+8); /*float-vector*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)SCALEVEC(ctx,2,local+7); /*scale*/
	local[7]= w;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)SETELT(ctx,3,local+8); /*setelt*/
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)SETELT(ctx,3,local+8); /*setelt*/
	local[8]= makeflt(2.0000000000000000000000e+00);
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)VNORM(ctx,1,local+9); /*norm*/
	{ double x,y;
		y=fltval(w); x=fltval(local[8]);
		local[8]=(makeflt(x * y));}
	local[9]= makeflt(3.1415926535897931159980e+00);
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[3]); /*normalize-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[8]= w;
	local[9]= local[7];
	local[10]= local[8];
	ctx->vsp=local+11;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+9); /*v**/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[1])(ctx,1,local+9,&ftab[1],fqv[3]); /*normalize-vector*/
	local[9]= w;
	local[10]= makeflt(6.2831853071795862319959e+00);
	local[11]= loadglobal(fqv[339]);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	local[11]= loadglobal(fqv[339]);
	local[12]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+13;
	w=(pointer)GREATERP(ctx,2,local+11); /*>*/
	if (w==NIL) goto irtdynaIF3770;
	local[11]= makeflt(-1.5707963267948965579990e+00);
	goto irtdynaIF3771;
irtdynaIF3770:
	local[11]= makeflt(0.0000000000000000000000e+00);
irtdynaIF3771:
	local[12]= makeflt(5.0000000000000000000000e-01);
	local[13]= local[10];
	local[14]= local[10];
	ctx->vsp=local+15;
	w=(pointer)SIN(ctx,1,local+14); /*sin*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= makeflt(0.0000000000000000000000e+00);
	local[13]= loadglobal(fqv[339]);
	local[14]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto irtdynaIF3772;
	local[13]= makeint((eusinteger_t)-1L);
	goto irtdynaIF3773;
irtdynaIF3772:
	local[13]= makeflt(0.0000000000000000000000e+00);
irtdynaIF3773:
	local[14]= makeflt(5.0000000000000000000000e-01);
	local[15]= makeflt(1.0000000000000000000000e+00);
	local[16]= local[10];
	ctx->vsp=local+17;
	w=(pointer)COS(ctx,1,local+16); /*cos*/
	{ double x,y;
		y=fltval(w); x=fltval(local[15]);
		local[15]=(makeflt(x - y));}
	{ double x,y;
		y=fltval(local[15]); x=fltval(local[14]);
		local[14]=(makeflt(x * y));}
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)MKFLTVEC(ctx,3,local+11); /*float-vector*/
	local[11]= w;
	local[12]= local[11];
	local[13]= local[8];
	local[14]= local[9];
	local[15]= local[7];
	ctx->vsp=local+16;
	w=(*ftab[39])(ctx,3,local+13,&ftab[39],fqv[366]); /*matrix*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TRANSFORM(ctx,2,local+12); /*transform*/
	local[12]= w;
	local[13]= local[12];
	local[14]= loadglobal(fqv[339]);
	local[15]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+16;
	w=(pointer)GREATERP(ctx,2,local+14); /*>*/
	if (w==NIL) goto irtdynaIF3774;
	local[14]= local[4];
	goto irtdynaIF3775;
irtdynaIF3774:
	local[14]= argv[3];
irtdynaIF3775:
	ctx->vsp=local+15;
	w=(pointer)VPLUS(ctx,2,local+13); /*v+*/
	local[4]= w;
	ctx->vsp=local+5;
	unbindx(ctx,1);
	w = local[4];
	local[0]= w;
irtdynaBLK3766:
	ctx->vsp=local; return(local[0]);}

/*:cycloid-midcoords*/
static pointer irtdynaM3776gait_generator_cycloid_midcoords(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<6) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[339],w);
	ctx->vsp=local+3;
	n=parsekeyparams(fqv[367], &argv[6], n-6, local+3, 0);
	if (n & (1<<0)) goto irtdynaKEY3778;
	local[3] = makeflt(5.0000000000000000000000e-01);
irtdynaKEY3778:
	if (n & (1<<1)) goto irtdynaKEY3779;
	local[4] = loadglobal(fqv[339]);
irtdynaKEY3779:
	local[5]= argv[0];
	local[6]= fqv[368];
	local[7]= loadglobal(fqv[339]);
	local[8]= argv[3];
	local[9]= fqv[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[4];
	local[10]= fqv[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= argv[5];
	local[11]= fqv[369];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,8,local+5); /*send*/
	local[5]= w;
	local[6]= fqv[255];
	local[7]= local[5];
	local[8]= fqv[256];
	local[9]= local[4];
	local[10]= argv[3];
	local[11]= argv[4];
	ctx->vsp=local+12;
	w=(*ftab[36])(ctx,3,local+9,&ftab[36],fqv[342]); /*midcoords*/
	local[9]= w;
	local[10]= fqv[25];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[23])(ctx,4,local+6,&ftab[23],fqv[246]); /*make-coords*/
	local[5]= w;
	ctx->vsp=local+6;
	unbindx(ctx,1);
	w = local[5];
	local[0]= w;
irtdynaBLK3777:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3630(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[370];
	ctx->vsp=local+2;
	w=(*ftab[38])(ctx,2,local+0,&ftab[38],fqv[358]); /*find-method*/
	if (w==NIL) goto irtdynaIF3780;
	local[0]= argv[0];
	local[1]= fqv[370];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtdynaIF3781;
irtdynaIF3780:
	local[0]= argv[0];
	local[1]= fqv[58];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
irtdynaIF3781:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3635(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtdynaCLO3782,env,argv,local);
	local[2]= env->c.clo.env1[0]->c.obj.iv[19];
	ctx->vsp=local+3;
	w=(*ftab[40])(ctx,2,local+1,&ftab[40],fqv[371]); /*remove-if-not*/
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3782(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env0->c.clo.env1[2];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3638(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[2];
	local[3]= argv[1];
	w = env->c.clo.env1[0]->c.obj.iv[16];
	w=memq(local[3],w);
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)VPLUS(ctx,2,local+0); /*v+*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3643(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env1[2];
	w = memq(local[0],w);
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3651(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)MKFLTVEC(ctx,3,local+1); /*float-vector*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3658(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!iscons(w)) goto irtdynaIF3783;
	local[0]= argv[0];
	goto irtdynaIF3784;
irtdynaIF3783:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
irtdynaIF3784:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3659(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3660(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3665(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0]->c.obj.iv[1];
	local[1]= argv[0];
	local[2]= fqv[262];
	local[3]= fqv[68];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3668(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[1];
	if (memq(local[0],w)==NIL) goto irtdynaIF3785;
	local[0]= env->c.clo.env1[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	goto irtdynaIF3786;
irtdynaIF3785:
	local[0]= env->c.clo.env1[0]->c.obj.iv[6];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[336];
	local[4]= env->c.clo.env2[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
irtdynaIF3786:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3669(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3676(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = env->c.clo.env2[1];
	if (memq(local[0],w)==NIL) goto irtdynaIF3787;
	local[0]= env->c.clo.env1[0]->c.obj.iv[5];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[1];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	goto irtdynaIF3788;
irtdynaIF3787:
	local[0]= env->c.clo.env1[0]->c.obj.iv[6];
	ctx->vsp=local+1;
	w=(*ftab[34])(ctx,1,local+0,&ftab[34],fqv[335]); /*last*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[336];
	local[4]= env->c.clo.env2[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
irtdynaIF3788:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3705(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= fqv[372];
	local[2]= env->c.clo.env1[0];
	local[3]= fqv[373];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= argv[1];
	local[5]= fqv[374];
	local[6]= env->c.clo.env1[2];
	local[7]= fqv[375];
	w=env->c.clo.env1[0]->c.obj.iv[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,9,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3708(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= env->c.clo.env2[4];
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[36])(ctx,3,local+0,&ftab[36],fqv[342]); /*midcoords*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3712(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = fqv[376];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3713(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w=env->c.clo.env1[0]->c.obj.iv[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (memq(local[0],w)==NIL) goto irtdynaIF3789;
	local[0]= fqv[376];
	goto irtdynaIF3790;
irtdynaIF3789:
	local[0]= fqv[377];
irtdynaIF3790:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3739(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=env->c.clo.env1[0]->c.obj.iv[5];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= argv[0];
	local[2]= env->c.clo.env2[0];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3756(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[4];
	ctx->vsp=local+2;
	w=(*ftab[19])(ctx,2,local+0,&ftab[19],fqv[201]); /*position*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3759(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[378];
	if (memq(local[0],w)==NIL) goto irtdynaIF3791;
	local[0]= env->c.clo.env1[0]->c.obj.iv[21];
	goto irtdynaIF3792;
irtdynaIF3791:
	local[0]= makeint((eusinteger_t)5L);
	local[1]= env->c.clo.env1[0]->c.obj.iv[21];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtdynaIF3792:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3762(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	w = fqv[379];
	if (memq(local[0],w)==NIL) goto irtdynaIF3793;
	local[0]= env->c.clo.env1[0]->c.obj.iv[22];
	goto irtdynaIF3794;
irtdynaIF3793:
	local[0]= makeint((eusinteger_t)5L);
	local[1]= env->c.clo.env1[0]->c.obj.iv[22];
	ctx->vsp=local+2;
	w=(pointer)TIMES(ctx,2,local+0); /***/
	local[0]= w;
irtdynaIF3794:
	ctx->vsp=local+1;
	w=(*ftab[24])(ctx,1,local+0,&ftab[24],fqv[260]); /*deg2rad*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3763(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env2[6];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3764(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= (pointer)get_sym_func(fqv[342]);
	local[1]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,irtdynaCLO3795,env,argv,local);
	local[3]= fqv[380];
	ctx->vsp=local+4;
	w=(pointer)MAPCAR(ctx,2,local+2); /*mapcar*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,3,local+0); /*apply*/
	local[0]= w;
	local[1]= env->c.clo.env1[6];
	local[2]= fqv[2];
	local[3]= env->c.clo.env2[4];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[3];
	if (fqv[381]!=local[4]) goto irtdynaIF3796;
	local[4]= fqv[382];
	goto irtdynaIF3797;
irtdynaIF3796:
	local[4]= local[3];
	if (fqv[383]!=local[4]) goto irtdynaIF3798;
	local[4]= fqv[384];
	goto irtdynaIF3799;
irtdynaIF3798:
	local[4]= NIL;
irtdynaIF3799:
irtdynaIF3797:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= local[0];
	local[3]= fqv[2];
	local[4]= fqv[385];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	local[3]= local[0];
	local[4]= fqv[207];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,3,local+3); /*send*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto irtdynaIF3800;
	local[3]= makeint((eusinteger_t)-1L);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SCALEVEC(ctx,2,local+3); /*scale*/
	local[1] = w;
	local[3]= local[1];
	goto irtdynaIF3801;
irtdynaIF3800:
	local[3]= NIL;
irtdynaIF3801:
	local[3]= NIL;
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,2,local+4); /*list*/
	local[4]= w;
irtdynaWHL3802:
	if (local[4]==NIL) goto irtdynaWHX3803;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	local[6]= makeint((eusinteger_t)2L);
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)SETELT(ctx,3,local+5); /*setelt*/
	goto irtdynaWHL3802;
irtdynaWHX3803:
	local[5]= NIL;
irtdynaBLK3804:
	w = NIL;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3805;
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)VNORM(ctx,1,local+3); /*norm*/
	local[3]= w;
	local[4]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+5;
	w=(*ftab[4])(ctx,2,local+3,&ftab[4],fqv[22]); /*eps=*/
	if (w==NIL) goto irtdynaIF3805;
	local[3]= makeflt(0.0000000000000000000000e+00);
	goto irtdynaIF3806;
irtdynaIF3805:
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[1])(ctx,1,local+3,&ftab[1],fqv[3]); /*normalize-vector*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[3]); /*normalize-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)VCROSSPRODUCT(ctx,2,local+3); /*v**/
	local[3]= w;
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[41])(ctx,1,local+3,&ftab[41],fqv[386]); /*asin*/
	local[3]= w;
irtdynaIF3806:
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)MKFLTVEC(ctx,6,local+4); /*float-vector*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtdynaCLO3795(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env0->c.clo.env2[6];
	local[1]= argv[0];
	local[2]= env->c.clo.env0->c.clo.env2[4];
	ctx->vsp=local+3;
	w=(*ftab[19])(ctx,2,local+1,&ftab[19],fqv[201]); /*position*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtdyna(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[387];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtdynaIF3807;
	local[0]= fqv[388];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[389],w);
	goto irtdynaIF3808;
irtdynaIF3807:
	local[0]= fqv[390];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtdynaIF3808:
	local[0]= fqv[391];
	ctx->vsp=local+1;
	w=(*ftab[42])(ctx,1,local+0,&ftab[42],fqv[392]); /*require*/
	local[0]= fqv[393];
	ctx->vsp=local+1;
	w=(*ftab[42])(ctx,1,local+0,&ftab[42],fqv[392]); /*require*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2837joint_calc_inertia_matrix,fqv[71],fqv[394],fqv[395]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[396],module,irtdynaF2835calc_inertia_matrix_rotational,fqv[397]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[398],module,irtdynaF2836calc_inertia_matrix_linear,fqv[399]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2854rotational_joint_calc_inertia_matrix,fqv[71],fqv[400],fqv[401]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2856linear_joint_calc_inertia_matrix,fqv[71],fqv[402],fqv[403]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2858omniwheel_joint_calc_inertia_matrix,fqv[71],fqv[404],fqv[405]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2860sphere_joint_calc_inertia_matrix,fqv[71],fqv[406],fqv[407]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM28626dof_joint_calc_inertia_matrix,fqv[71],fqv[408],fqv[409]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2864bodyset_link_append_weight_no_update,fqv[31],fqv[121],fqv[410]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2870bodyset_link_append_centroid_no_update,fqv[33],fqv[121],fqv[411]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2880bodyset_link_append_inertia_no_update,fqv[36],fqv[121],fqv[412]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2892bodyset_link_append_mass_properties,fqv[48],fqv[121],fqv[413]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2908bodyset_link_propagate_mass_properties,fqv[44],fqv[121],fqv[414]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2926bodyset_link_calc_inertia_matrix_column,fqv[83],fqv[121],fqv[415]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2955cascaded_link_update_mass_properties,fqv[80],fqv[416],fqv[417]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2963cascaded_link_calc_inertia_matrix_from_link_list,fqv[90],fqv[416],fqv[418]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM2991cascaded_link_calc_cog_jacobian_from_link_list,fqv[95],fqv[416],fqv[419]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3006cascaded_link_cog_jacobian_balance_nspace,fqv[420],fqv[416],fqv[421]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3016cascaded_link_calc_vel_for_cog,fqv[96],fqv[416],fqv[422]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3020cascaded_link_difference_cog_position,fqv[101],fqv[416],fqv[423]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3030cascaded_link_cog_convergence_check,fqv[424],fqv[416],fqv[425]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3048joint_calc_spacial_velocity_jacobian,fqv[135],fqv[394],fqv[426]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3051joint_calc_angular_velocity_jacobian,fqv[137],fqv[394],fqv[427]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3054joint_calc_spacial_acceleration_jacobian,fqv[139],fqv[394],fqv[428]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3057joint_calc_angular_acceleration_jacobian,fqv[142],fqv[394],fqv[429]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3060rotational_joint_calc_spacial_velocity_jacobian,fqv[135],fqv[400],fqv[430]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3062rotational_joint_calc_angular_velocity_jacobian,fqv[137],fqv[400],fqv[431]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3067rotational_joint_calc_spacial_acceleration_jacobian,fqv[139],fqv[400],fqv[432]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3069rotational_joint_calc_angular_acceleration_jacobian,fqv[142],fqv[400],fqv[433]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3071linear_joint_calc_spacial_velocity_jacobian,fqv[135],fqv[402],fqv[434]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3076linear_joint_calc_angular_velocity_jacobian,fqv[137],fqv[402],fqv[435]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3081linear_joint_calc_spacial_acceleration_jacobian,fqv[139],fqv[402],fqv[436]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3083linear_joint_calc_angular_acceleration_jacobian,fqv[142],fqv[402],fqv[437]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3088bodyset_link_reset_dynamics,fqv[438],fqv[121],fqv[439]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3090bodyset_link_angular_velocity,fqv[116],fqv[121],fqv[440]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3096bodyset_link_angular_acceleration,fqv[143],fqv[121],fqv[441]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3102bodyset_link_spacial_velocity,fqv[117],fqv[121],fqv[442]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3108bodyset_link_spacial_acceleration,fqv[140],fqv[121],fqv[443]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3114bodyset_link_force,fqv[150],fqv[121],fqv[444]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3116bodyset_link_moment,fqv[151],fqv[121],fqv[445]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3118bodyset_link_ext_force,fqv[243],fqv[121],fqv[446]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3124bodyset_link_ext_moment,fqv[244],fqv[121],fqv[447]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3130bodyset_link_forward_all_kinematics,fqv[144],fqv[121],fqv[448]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3158bodyset_link_inverse_dynamics,fqv[148],fqv[121],fqv[449]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3175cascaded_link_max_torque_vector,fqv[158],fqv[416],fqv[450]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3187cascaded_link_torque_ratio_vector,fqv[451],fqv[416],fqv[452]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3194cascaded_link_calc_torque_buffer_args,fqv[161],fqv[416],fqv[453]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3196cascaded_link_calc_torque,fqv[203],fqv[416],fqv[454]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3210cascaded_link_calc_torque_without_ext_wrench,fqv[163],fqv[416],fqv[455]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3220cascaded_link_calc_torque_from_vel_acc,fqv[169],fqv[416],fqv[456]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3240cascaded_link_calc_root_coords_vel_acc_from_pos,fqv[170],fqv[416],fqv[457]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3251cascaded_link_calc_av_vel_acc_from_pos,fqv[171],fqv[416],fqv[458]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3260cascaded_link_calc_torque_from_ext_wrenches,fqv[459],fqv[416],fqv[460]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3274cascaded_link_calc_zmp,fqv[227],fqv[416],fqv[461]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3287cascaded_link_calc_cop_from_force_moment,fqv[462],fqv[416],fqv[463]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3295cascaded_link_wrench_vector__wrench_list,fqv[464],fqv[416],fqv[465]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3300cascaded_link_wrench_list__wrench_vector,fqv[466],fqv[416],fqv[467]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3303cascaded_link_calc_contact_wrenches_from_total_wrench,fqv[468],fqv[416],fqv[469]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3312cascaded_link_draw_torque,fqv[470],fqv[416],fqv[471]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3325cascaded_link_weight,fqv[20],fqv[416],fqv[472]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3331cascaded_link_centroid,fqv[30],fqv[416],fqv[473]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3337cascaded_link_inertia_tensor,fqv[26],fqv[416],fqv[474]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3343cascaded_link_preview_control_dynamics_filter,fqv[475],fqv[416],fqv[476]);
	local[0]= fqv[477];
	local[1]= fqv[478];
	local[2]= fqv[477];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[480]);
	local[5]= fqv[481];
	local[6]= fqv[482];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3400riccati_equation_init,fqv[223],fqv[477],fqv[487]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3402riccati_equation_solve,fqv[285],fqv[477],fqv[488]);
	local[0]= fqv[220];
	local[1]= fqv[478];
	local[2]= fqv[220];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[477]);
	local[5]= fqv[481];
	local[6]= fqv[489];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3410preview_controller_init,fqv[223],fqv[220],fqv[490]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3429preview_controller_calc_f,fqv[286],fqv[220],fqv[491]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3440preview_controller_calc_u,fqv[287],fqv[220],fqv[492]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3442preview_controller_calc_xk,fqv[289],fqv[220],fqv[493]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3444preview_controller_update_xk,fqv[229],fqv[220],fqv[494]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3482preview_controller_finishedp,fqv[228],fqv[220],fqv[495]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3484preview_controller_last_reference_output_vector,fqv[288],fqv[220],fqv[496]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3486preview_controller_current_reference_output_vector,fqv[290],fqv[220],fqv[497]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3488preview_controller_current_state_vector,fqv[291],fqv[220],fqv[498]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3490preview_controller_current_output_vector,fqv[292],fqv[220],fqv[499]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3492preview_controller_current_additional_data,fqv[230],fqv[220],fqv[500]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3494preview_controller_pass_preview_controller,fqv[501],fqv[220],fqv[502]);
	local[0]= fqv[306];
	local[1]= fqv[478];
	local[2]= fqv[306];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[220]);
	local[5]= fqv[481];
	local[6]= fqv[503];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3502extended_preview_controller_init,fqv[223],fqv[306],fqv[504]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3555extended_preview_controller_calc_f,fqv[286],fqv[306],fqv[505]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3568extended_preview_controller_calc_u,fqv[287],fqv[306],fqv[506]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3570extended_preview_controller_calc_xk,fqv[289],fqv[306],fqv[507]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3575extended_preview_controller_current_output_vector,fqv[292],fqv[306],fqv[508]);
	local[0]= fqv[222];
	local[1]= fqv[478];
	local[2]= fqv[222];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[480]);
	local[5]= fqv[481];
	local[6]= fqv[509];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3577preview_control_cart_table_cog_trajectory_generator_init,fqv[223],fqv[222],fqv[510]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3588preview_control_cart_table_cog_trajectory_generator_refcog,fqv[236],fqv[222],fqv[511]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3590preview_control_cart_table_cog_trajectory_generator_cart_zmp,fqv[308],fqv[222],fqv[512]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3592preview_control_cart_table_cog_trajectory_generator_last_refzmp,fqv[513],fqv[222],fqv[514]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3594preview_control_cart_table_cog_trajectory_generator_current_refzmp,fqv[307],fqv[222],fqv[515]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3596preview_control_cart_table_cog_trajectory_generator_update_xk,fqv[229],fqv[222],fqv[516]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3605preview_control_cart_table_cog_trajectory_generator_finishedp,fqv[228],fqv[222],fqv[517]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3608preview_control_cart_table_cog_trajectory_generator_current_additional_data,fqv[230],fqv[222],fqv[518]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3610preview_control_cart_table_cog_trajectory_generator_pass_preview_controller,fqv[501],fqv[222],fqv[519]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3618preview_control_cart_table_cog_trajectory_generator_cog_z,fqv[349],fqv[222],fqv[520]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3620preview_control_cart_table_cog_trajectory_generator_update_cog_z,fqv[521],fqv[222],fqv[522]);
	local[0]= fqv[312];
	local[1]= fqv[478];
	local[2]= fqv[312];
	local[3]= fqv[479];
	local[4]= loadglobal(fqv[480]);
	local[5]= fqv[481];
	local[6]= fqv[523];
	local[7]= fqv[483];
	local[8]= NIL;
	local[9]= fqv[484];
	local[10]= NIL;
	local[11]= fqv[108];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[485];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[43])(ctx,13,local+2,&ftab[43],fqv[486]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3623gait_generator_init,fqv[223],fqv[312],fqv[524]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3628gait_generator_get_footstep_limbs,fqv[321],fqv[312],fqv[525]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3631gait_generator_get_counter_footstep_limbs,fqv[320],fqv[312],fqv[526]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3636gait_generator_get_limbs_zmp_list,fqv[323],fqv[312],fqv[527]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3639gait_generator_get_limbs_zmp,fqv[332],fqv[312],fqv[528]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3641gait_generator_get_swing_limbs,fqv[336],fqv[312],fqv[529]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3644gait_generator_initialize_gait_parameter,fqv[530],fqv[312],fqv[531]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3666gait_generator_finalize_gait_parameter,fqv[356],fqv[312],fqv[532]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3674gait_generator_make_gait_parameter,fqv[334],fqv[312],fqv[533]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3677gait_generator_calc_hoffarbib_pos_vel_acc,fqv[347],fqv[312],fqv[534]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3679gait_generator_calc_current_swing_leg_coords,fqv[372],fqv[312],fqv[535]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3687gait_generator_calc_ratio_from_double_support_ratio,fqv[373],fqv[312],fqv[536]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3693gait_generator_calc_current_refzmp,fqv[348],fqv[312],fqv[537]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3699gait_generator_calc_one_tick_gait_parameter,fqv[352],fqv[312],fqv[538]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3714gait_generator_proc_one_tick,fqv[539],fqv[312],fqv[540]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3732gait_generator_update_current_gait_parameter,fqv[355],fqv[312],fqv[541]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3742gait_generator_solve_angle_vector,fqv[353],fqv[312],fqv[542]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3750gait_generator_solve_av_by_move_centroid_on_foot,fqv[351],fqv[312],fqv[543]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3765gait_generator_cycloid_midpoint,fqv[368],fqv[312],fqv[544]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtdynaM3776gait_generator_cycloid_midcoords,fqv[344],fqv[312],fqv[545]);
	local[0]= fqv[546];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtdynaIF3809;
	local[0]= fqv[547];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[389],w);
	goto irtdynaIF3810;
irtdynaIF3809:
	local[0]= fqv[548];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtdynaIF3810:
	local[0]= fqv[549];
	ctx->vsp=local+1;
	w=(*ftab[44])(ctx,1,local+0,&ftab[44],fqv[550]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<45; i++) ftab[i]=fcallx;
}
