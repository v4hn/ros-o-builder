
"use strict";

let SetProfile = require('./SetProfile.js')

module.exports = {
  SetProfile: SetProfile,
};
