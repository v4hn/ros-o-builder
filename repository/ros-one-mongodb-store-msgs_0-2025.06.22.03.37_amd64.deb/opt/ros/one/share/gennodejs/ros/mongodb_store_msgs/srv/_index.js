
"use strict";

let MongoInsertMsg = require('./MongoInsertMsg.js')
let MongoQueryMsg = require('./MongoQueryMsg.js')
let MongoDeleteMsg = require('./MongoDeleteMsg.js')
let MongoQuerywithProjectionMsg = require('./MongoQuerywithProjectionMsg.js')
let MongoUpdateMsg = require('./MongoUpdateMsg.js')

module.exports = {
  MongoInsertMsg: MongoInsertMsg,
  MongoQueryMsg: MongoQueryMsg,
  MongoDeleteMsg: MongoDeleteMsg,
  MongoQuerywithProjectionMsg: MongoQuerywithProjectionMsg,
  MongoUpdateMsg: MongoUpdateMsg,
};
