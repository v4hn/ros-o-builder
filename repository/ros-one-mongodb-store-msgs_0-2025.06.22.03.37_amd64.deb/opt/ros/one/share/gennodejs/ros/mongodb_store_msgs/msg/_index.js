
"use strict";

let Insert = require('./Insert.js');
let StringPair = require('./StringPair.js');
let SerialisedMessage = require('./SerialisedMessage.js');
let StringList = require('./StringList.js');
let StringPairList = require('./StringPairList.js');
let MoveEntriesGoal = require('./MoveEntriesGoal.js');
let MoveEntriesResult = require('./MoveEntriesResult.js');
let MoveEntriesFeedback = require('./MoveEntriesFeedback.js');
let MoveEntriesActionFeedback = require('./MoveEntriesActionFeedback.js');
let MoveEntriesActionResult = require('./MoveEntriesActionResult.js');
let MoveEntriesActionGoal = require('./MoveEntriesActionGoal.js');
let MoveEntriesAction = require('./MoveEntriesAction.js');

module.exports = {
  Insert: Insert,
  StringPair: StringPair,
  SerialisedMessage: SerialisedMessage,
  StringList: StringList,
  StringPairList: StringPairList,
  MoveEntriesGoal: MoveEntriesGoal,
  MoveEntriesResult: MoveEntriesResult,
  MoveEntriesFeedback: MoveEntriesFeedback,
  MoveEntriesActionFeedback: MoveEntriesActionFeedback,
  MoveEntriesActionResult: MoveEntriesActionResult,
  MoveEntriesActionGoal: MoveEntriesActionGoal,
  MoveEntriesAction: MoveEntriesAction,
};
