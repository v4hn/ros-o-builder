char *makedate="Sat Sep 26 07:14:44 UTC 2026";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";
