void eusstart(x)
{ return;}
