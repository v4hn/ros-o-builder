
"use strict";

let SetTorqueLimit = require('./SetTorqueLimit.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let RestartController = require('./RestartController.js')
let StartController = require('./StartController.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let SetSpeed = require('./SetSpeed.js')
let TorqueEnable = require('./TorqueEnable.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let StopController = require('./StopController.js')

module.exports = {
  SetTorqueLimit: SetTorqueLimit,
  SetComplianceMargin: SetComplianceMargin,
  RestartController: RestartController,
  StartController: StartController,
  SetComplianceSlope: SetComplianceSlope,
  SetSpeed: SetSpeed,
  TorqueEnable: TorqueEnable,
  SetCompliancePunch: SetCompliancePunch,
  StopController: StopController,
};
