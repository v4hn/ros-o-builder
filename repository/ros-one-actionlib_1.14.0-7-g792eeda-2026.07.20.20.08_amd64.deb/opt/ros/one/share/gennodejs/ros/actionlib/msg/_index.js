
"use strict";

let TestActionFeedback = require('./TestActionFeedback.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestRequestResult = require('./TestRequestResult.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestResult = require('./TestResult.js');
let TestRequestAction = require('./TestRequestAction.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestGoal = require('./TestGoal.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestActionResult = require('./TestActionResult.js');
let TestAction = require('./TestAction.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');

module.exports = {
  TestActionFeedback: TestActionFeedback,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TwoIntsGoal: TwoIntsGoal,
  TwoIntsResult: TwoIntsResult,
  TestRequestResult: TestRequestResult,
  TwoIntsActionResult: TwoIntsActionResult,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TwoIntsAction: TwoIntsAction,
  TestActionGoal: TestActionGoal,
  TestResult: TestResult,
  TestRequestAction: TestRequestAction,
  TestRequestFeedback: TestRequestFeedback,
  TestRequestGoal: TestRequestGoal,
  TestGoal: TestGoal,
  TestRequestActionGoal: TestRequestActionGoal,
  TestRequestActionResult: TestRequestActionResult,
  TestFeedback: TestFeedback,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestActionResult: TestActionResult,
  TestAction: TestAction,
  TwoIntsFeedback: TwoIntsFeedback,
};
