
"use strict";

let ConfigResult = require('./ConfigResult.js');
let ConfigActionResult = require('./ConfigActionResult.js');
let ConfigGoal = require('./ConfigGoal.js');
let ConfigFeedback = require('./ConfigFeedback.js');
let ConfigActionGoal = require('./ConfigActionGoal.js');
let ConfigActionFeedback = require('./ConfigActionFeedback.js');
let ConfigAction = require('./ConfigAction.js');
let ImagePoint = require('./ImagePoint.js');
let ObjectInImage = require('./ObjectInImage.js');

module.exports = {
  ConfigResult: ConfigResult,
  ConfigActionResult: ConfigActionResult,
  ConfigGoal: ConfigGoal,
  ConfigFeedback: ConfigFeedback,
  ConfigActionGoal: ConfigActionGoal,
  ConfigActionFeedback: ConfigActionFeedback,
  ConfigAction: ConfigAction,
  ImagePoint: ImagePoint,
  ObjectInImage: ObjectInImage,
};
