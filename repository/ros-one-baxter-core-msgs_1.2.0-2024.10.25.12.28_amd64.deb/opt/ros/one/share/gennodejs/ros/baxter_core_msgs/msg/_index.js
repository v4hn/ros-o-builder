
"use strict";

let CameraSettings = require('./CameraSettings.js');
let RobustControllerStatus = require('./RobustControllerStatus.js');
let CameraControl = require('./CameraControl.js');
let DigitalOutputCommand = require('./DigitalOutputCommand.js');
let AssemblyState = require('./AssemblyState.js');
let DigitalIOState = require('./DigitalIOState.js');
let EndpointState = require('./EndpointState.js');
let JointCommand = require('./JointCommand.js');
let URDFConfiguration = require('./URDFConfiguration.js');
let NavigatorState = require('./NavigatorState.js');
let HeadPanCommand = require('./HeadPanCommand.js');
let HeadState = require('./HeadState.js');
let CollisionAvoidanceState = require('./CollisionAvoidanceState.js');
let EndEffectorProperties = require('./EndEffectorProperties.js');
let EndpointStates = require('./EndpointStates.js');
let CollisionDetectionState = require('./CollisionDetectionState.js');
let SEAJointState = require('./SEAJointState.js');
let NavigatorStates = require('./NavigatorStates.js');
let AnalogIOStates = require('./AnalogIOStates.js');
let AssemblyStates = require('./AssemblyStates.js');
let AnalogOutputCommand = require('./AnalogOutputCommand.js');
let DigitalIOStates = require('./DigitalIOStates.js');
let EndEffectorCommand = require('./EndEffectorCommand.js');
let AnalogIOState = require('./AnalogIOState.js');
let EndEffectorState = require('./EndEffectorState.js');

module.exports = {
  CameraSettings: CameraSettings,
  RobustControllerStatus: RobustControllerStatus,
  CameraControl: CameraControl,
  DigitalOutputCommand: DigitalOutputCommand,
  AssemblyState: AssemblyState,
  DigitalIOState: DigitalIOState,
  EndpointState: EndpointState,
  JointCommand: JointCommand,
  URDFConfiguration: URDFConfiguration,
  NavigatorState: NavigatorState,
  HeadPanCommand: HeadPanCommand,
  HeadState: HeadState,
  CollisionAvoidanceState: CollisionAvoidanceState,
  EndEffectorProperties: EndEffectorProperties,
  EndpointStates: EndpointStates,
  CollisionDetectionState: CollisionDetectionState,
  SEAJointState: SEAJointState,
  NavigatorStates: NavigatorStates,
  AnalogIOStates: AnalogIOStates,
  AssemblyStates: AssemblyStates,
  AnalogOutputCommand: AnalogOutputCommand,
  DigitalIOStates: DigitalIOStates,
  EndEffectorCommand: EndEffectorCommand,
  AnalogIOState: AnalogIOState,
  EndEffectorState: EndEffectorState,
};
