
"use strict";

let TeleportAbsolute = require('./TeleportAbsolute.js')
let SetPen = require('./SetPen.js')
let Spawn = require('./Spawn.js')
let Kill = require('./Kill.js')
let TeleportRelative = require('./TeleportRelative.js')

module.exports = {
  TeleportAbsolute: TeleportAbsolute,
  SetPen: SetPen,
  Spawn: Spawn,
  Kill: Kill,
  TeleportRelative: TeleportRelative,
};
