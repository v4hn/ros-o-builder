# Copyright 2025-2026 Inria

include_guard(GLOBAL)
cmake_minimum_required(VERSION 3.22)

#[============================================================================[
# `_jrl_init_dirs`

```cpp
_jrl_init_dirs()
```

**Type:** function


### Description
  Initialize the `_JRL_*_DIR` cache variables that point to well-known directories
  inside the jrl-cmakemodules repository (`top`, `modules`, `templates`, `docs`,
  `external-modules`, `find-modules`).
  Uses `CMAKE_CURRENT_FUNCTION_LIST_DIR` so the paths are always relative to this
  file, regardless of where `jrl.cmake` is included from.
  Variables are stored as `CACHE INTERNAL` so they are visible in every scope.
  The function is a no-op when the variables are already in the cache.


### Arguments
  None


### Example
```cmake
_jrl_init_dirs()
```
#]============================================================================]
function(_jrl_init_dirs)
    set(_JRL_TOP_DIR "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/.." CACHE INTERNAL "")
    set(_JRL_MODULES_DIR "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/../modules" CACHE INTERNAL "")
    set(_JRL_TEMPLATES_DIR "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/../templates" CACHE INTERNAL "")
    set(_JRL_DOCS_DIR "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/../docs" CACHE INTERNAL "")
    set(_JRL_EXTERNAL_MODULES_DIR
        "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/../external-modules"
        CACHE INTERNAL
        ""
    )
    set(_JRL_FIND_MODULES_DIR
        "${CMAKE_CURRENT_FUNCTION_LIST_DIR}/../find-modules"
        CACHE INTERNAL
        ""
    )
endfunction()

# Intialize the dirs variables.
_jrl_init_dirs()

#[============================================================================[
# `_jrl_check_valid_visibility`

```cpp
_jrl_check_valid_visibility(<visibility>)
```

**Type:** function


### Description
  Check if the visibility argument is valid (PRIVATE, PUBLIC or INTERFACE).
  Otherwise raise a fatal error.


### Arguments
* `visibility`: The visibility keyword to check.


### Example
```cmake
set(visibility PRIVATE)
_jrl_check_valid_visibility(${visibility})
```
#]============================================================================]
function(_jrl_check_valid_visibility visibility)
    set(vs PRIVATE PUBLIC INTERFACE)
    if(NOT ${visibility} IN_LIST vs)
        message(
            FATAL_ERROR
            "visibility (${visibility}) must be one of PRIVATE, PUBLIC or INTERFACE"
        )
    endif()
endfunction()

#[============================================================================[
# `_jrl_check_no_unrecognized_arguments`

```cpp
_jrl_check_no_unrecognized_arguments(<prefix>)
```

**Type:** function


### Description
  Check if there are unrecognized arguments after parsing with cmake_parse_arguments.
  This function checks if the variable `<prefix>_UNPARSED_ARGUMENTS` is defined and raises
  a fatal error if unrecognized arguments were found.


### Arguments
* `prefix`: The prefix used in the `cmake_parse_arguments()` call. Usually "arg"


### Example
```cmake
function(my_function)
    cmake_parse_arguments(arg "" "" "" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)
endfunction()
```
#]============================================================================]
function(_jrl_check_no_unrecognized_arguments prefix)
    if(DEFINED ${prefix}_UNPARSED_ARGUMENTS)
        string(REPLACE ";" " " unparsed_args "${${prefix}_UNPARSED_ARGUMENTS}")
        message(FATAL_ERROR "Unrecognized arguments: ${unparsed_args}")
    endif()
endfunction()

#[============================================================================[
# `_jrl_check`

```cpp
_jrl_check(
    <condition...>
    [ERROR_MESSAGE <msg>]
)
```

**Type:** function


### Description
  Evaluates a CMake `if()` condition. If the condition is false, raises a fatal error.
  Accepts the same condition syntax as CMake's `if()` command.


### Arguments
* `condition`: One or more condition tokens, using the same syntax as `if()`.
* `ERROR_MESSAGE`: Optional custom error message. If not provided, the condition tokens are shown.


### Example
```cmake
_jrl_check(DEFINED MY_VAR)
_jrl_check(TARGET my_target ERROR_MESSAGE "Call find_package first.")
_jrl_check("${MY_VAR}" STREQUAL "expected")
_jrl_check(3 GREATER 1)
```
#]============================================================================]
function(_jrl_check)
    cmake_parse_arguments(arg "" "ERROR_MESSAGE" "" ${ARGN})
    if(NOT (${arg_UNPARSED_ARGUMENTS}))
        if(arg_ERROR_MESSAGE)
            set(msg "${arg_ERROR_MESSAGE}")
        else()
            string(REPLACE ";" " " _cond_str "${arg_UNPARSED_ARGUMENTS}")
            set(msg "Condition failed: ${_cond_str}")
        endif()
        message(FATAL_ERROR "${msg}")
    endif()
endfunction()

#[============================================================================[
# `_jrl_check_var_defined`

```cmake
_jrl_check_var_defined(<var> [<message>])
```

**Type:** function


### Description
  Raises a fatal error if the variable `<var>` is not defined.


### Arguments
* `var`: Name of the variable to check.
* `message`: Optional custom error message. Default: "Variable '<var>' is not defined."


### Example
```cmake
_jrl_check_var_defined(MY_VAR)
_jrl_check_var_defined(MY_VAR "MY_VAR must be set before calling this function.")
```
#]============================================================================]
function(_jrl_check_var_defined var)
    if(ARGC GREATER 1)
        _jrl_check(DEFINED ${var} ERROR_MESSAGE "${ARGV1}")
    else()
        _jrl_check(DEFINED ${var} ERROR_MESSAGE "Variable '${var}' is not defined.")
    endif()
endfunction()

#[============================================================================[
# `_jrl_check_file_exists`

```cmake
_jrl_check_file_exists(<path> [<message>])
```

**Type:** function


### Description
  Raises a fatal error if `<path>` does not exist (file or directory).
  Uses CMake's `EXISTS` check, which is true for both files and directories.


### Arguments
* `path`: The filesystem path to check.
* `message`: Optional custom error message. Default: "File does not exist: '<path>'."


### Example
```cmake
_jrl_check_file_exists("/path/to/file.txt")
_jrl_check_file_exists("${MY_HEADER}" "Header not found. Check your include path.")
```
#]============================================================================]
function(_jrl_check_file_exists path)
    if(ARGC GREATER 1)
        _jrl_check(EXISTS "${path}" ERROR_MESSAGE "${ARGV1}")
    else()
        _jrl_check(EXISTS "${path}" ERROR_MESSAGE "File does not exist: '${path}'.")
    endif()
endfunction()

#[============================================================================[
# `_jrl_check_dir_exists`

```cmake
_jrl_check_dir_exists(<path> [<message>])
```

**Type:** function


### Description
  Raises a fatal error if `<path>` is not an existing directory.
  Uses CMake's `IS_DIRECTORY` check; plain files return false.


### Arguments
* `path`: The filesystem path to check.
* `message`: Optional custom error message. Default: "Directory does not exist: '<path>'."


### Example
```cmake
_jrl_check_dir_exists("/path/to/dir")
_jrl_check_dir_exists("${MY_INCLUDE_DIR}" "Include dir not found. Set MY_INCLUDE_DIR correctly.")
```
#]============================================================================]
function(_jrl_check_dir_exists path)
    if(ARGC GREATER 1)
        _jrl_check(IS_DIRECTORY "${path}" ERROR_MESSAGE "${ARGV1}")
    else()
        _jrl_check(IS_DIRECTORY "${path}" ERROR_MESSAGE "Directory does not exist: '${path}'.")
    endif()
endfunction()

#[============================================================================[
# `_jrl_check_target_exists`

```cmake
_jrl_check_target_exists(<target> [<message>])
```

**Type:** function


### Description
  Raises a fatal error if the CMake target `<target>` does not exist.


### Arguments
* `target`: Name of the CMake target to check.
* `message`: Optional custom error message. Default: "Target '<target>' does not exist."


### Example
```cmake
_jrl_check_target_exists(my_lib)
_jrl_check_target_exists(Eigen3::Eigen "Call find_package(Eigen3 REQUIRED) before using this.")
```
#]============================================================================]
function(_jrl_check_target_exists target)
    if(ARGC GREATER 1)
        _jrl_check(TARGET ${target} ERROR_MESSAGE "${ARGV1}")
    else()
        _jrl_check(TARGET ${target} ERROR_MESSAGE "Target '${target}' does not exist.")
    endif()
endfunction()

#[============================================================================[
# `jrl_copy_compile_commands_in_source_dir`

```cpp
jrl_copy_compile_commands_in_source_dir()
```

**Type:** function


### Description
  Copy compile_commands.json from the binary dir to the upper source directory for clangd support.
  See jrl_configure_copy_compile_commands_in_source_dir for more info.
  NOTE: This is volontarly a copy and not a symlink to avoid issues when the build directory is deleted (IDE are not happy about this).


### Arguments
  None


### Example
```cmake
jrl_copy_compile_commands_in_source_dir()
```
#]============================================================================]
function(jrl_copy_compile_commands_in_source_dir)
    set(source ${CMAKE_BINARY_DIR}/compile_commands.json)
    set(destination ${CMAKE_SOURCE_DIR}/compile_commands.json)

    if(CMAKE_EXPORT_COMPILE_COMMANDS AND EXISTS ${source})
        execute_process(
            COMMAND ${CMAKE_COMMAND} -E copy_if_different ${source} ${destination}
        )
    endif()
endfunction()

#[============================================================================[
# `jrl_configure_copy_compile_commands_in_source_dir`

```cpp
jrl_configure_copy_compile_commands_in_source_dir()
```

**Type:** function


### Description
  Configure copy of `compile_commands.json` to source directory at end of configuration step.
  This is useful for `clangd` when the build directory is not `<source_dir>/build` (ex: `<source_dir>/build/<config>`).
  Also makes `clangd` still available when the build directory is deleted but the `compile_commands.json` in the source directory is not.
  This copys the default behavior of the CMake extension for VSCode (`cmake.copyCompileCommands`).
  It is recommended to add `compile_commands.json` to `.gitignore` if you use this function.


### Arguments
  None


### Example
```cmake
jrl_configure_copy_compile_commands_in_source_dir()
```
#]============================================================================]
function(jrl_configure_copy_compile_commands_in_source_dir)
    cmake_language(DEFER DIRECTORY ${CMAKE_SOURCE_DIR} GET_CALL_IDS _ids)
    set(call_id 03e6a81d-6918-4da7-a4f4-a3dd74f61cef)
    if(NOT _ids OR NOT ${call_id} IN_LIST _ids)
        message(
            DEBUG
            "Configuring copy of compile_commands.json to source directory (CMAKE_SOURCE_DIR=${CMAKE_SOURCE_DIR}) at end of configuration step."
        )
        cmake_language(
            DEFER ID ${call_id} DIRECTORY ${CMAKE_SOURCE_DIR}
            CALL jrl_copy_compile_commands_in_source_dir
            ()
        )
    endif()
endfunction()

#[============================================================================[
# `_jrl_log_clear`

```cpp
_jrl_log_clear()
```

**Type:** function


### Description
  Clear the current log buffer.


### Arguments
  None


### Example
```cmake
_jrl_log_clear()
```
#]============================================================================]
function(_jrl_log_clear)
    set_property(GLOBAL PROPERTY _jrl_log_messages "")
endfunction()

#[============================================================================[
# `_jrl_log`

```cpp
_jrl_log(<msg>)
```

**Type:** function


### Description
  Log a message to the internal log buffer.
  Does not print anything to the console.


### Arguments
* `msg`: The message to log.


### Example
```cmake
_jrl_log("Something happened")
```
#]============================================================================]
function(_jrl_log msg)
    get_property(existing_msgs GLOBAL PROPERTY _jrl_log_messages)
    string(APPEND existing_msgs "${msg}\n")
    set_property(GLOBAL PROPERTY _jrl_log_messages "${existing_msgs}")
endfunction()

#[============================================================================[
# `_jrl_log_get`

```cpp
_jrl_log_get(<output_var>)
```

**Type:** function


### Description
  Get the current log buffer.


### Arguments
* `output_var`: Variable to store the log buffer content.


### Example
```cmake
_jrl_log_get(LOG_MSGS)
```
#]============================================================================]
function(_jrl_log_get output_var)
    get_property(log_msgs GLOBAL PROPERTY _jrl_log_messages)
    set(${output_var} "${log_msgs}" PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_include_ctest`

```cpp
jrl_include_ctest()
```

**Type:** macro


### Description
  Include CTest but simply prevent adding a lot of useless targets. Useful for IDEs.


### Arguments
  None


### Example
```cmake
jrl_include_ctest()
```
#]============================================================================]
macro(jrl_include_ctest)
    set_property(GLOBAL PROPERTY CTEST_TARGETS_ADDED 1)
    include(CTest)
endmacro()

#[============================================================================[
# `jrl_cmakemodules_get_version`

```cpp
jrl_cmakemodules_get_version(<output_var>)
```

**Type:** function


### Description
  Get the version of the jrl-cmakemodules package (via the jrl-cmakemodules_VERSION variable).


### Arguments
* `output_var`: Variable to store the version string.


### Example
```cmake
jrl_cmakemodules_get_version(v)
message(STATUS "jrl-cmakemodules version: ${v}")
```
#]============================================================================]
function(jrl_cmakemodules_get_version output_var)
    _jrl_check_var_defined(jrl-cmakemodules_VERSION
        "jrl-cmakemodules_VERSION variable is not defined.
        It is defined when adding the top-level jrl-cmakemodules CMakeLists or when found via find_package."
    )
    set(${output_var} ${jrl-cmakemodules_VERSION} PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_cmakemodules_get_commit`

```cpp
jrl_cmakemodules_get_commit(<output_var>)
```

**Type:** function


### Description
  Get the git commit hash of the jrl-cmakemodules repository, if available.


### Arguments
* `output_var`: Variable to store the commit hash.


### Example
```cmake
jrl_cmakemodules_get_commit(commit)
message(STATUS "jrl-cmakemodules commit: ${commit}")
```
#]============================================================================]
function(jrl_cmakemodules_get_commit output_var)
    if(DEFINED CACHE{_JRL_COMMIT})
        set(${output_var} "${_JRL_COMMIT}" PARENT_SCOPE)
        return()
    endif()

    find_program(GIT git QUIET)

    if(NOT GIT)
        message(DEBUG "Git executable not found, cannot get jrl-cmakemodules commit hash.")
        set(_JRL_COMMIT "" CACHE INTERNAL "Cached commit hash of jrl-cmakemodules")
        return()
    endif()

    execute_process(
        COMMAND ${GIT} rev-parse HEAD
        WORKING_DIRECTORY ${CMAKE_CURRENT_FUNCTION_LIST_DIR}
        OUTPUT_VARIABLE git_commit
        OUTPUT_STRIP_TRAILING_WHITESPACE
        ERROR_QUIET
    )

    # It might not be a git repository (e.g. downloaded zip archive)
    if(NOT git_commit)
        message(DEBUG "Could not get jrl-cmakemodules commit hash.")
        set(_JRL_COMMIT "" CACHE INTERNAL "Cached commit hash of jrl-cmakemodules")
        return()
    endif()

    set(_JRL_COMMIT "${git_commit}" CACHE INTERNAL "Cached commit hash of jrl-cmakemodules")
    set(${output_var} "${git_commit}" PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_print_banner`

```cpp
jrl_print_banner()
```

**Type:** function


### Description
  Print a banner with the jrl-cmakemodules version and some info.


### Arguments
  None


### Example
```cmake
jrl_print_banner()
```
#]============================================================================]
function(jrl_print_banner)
    jrl_cmakemodules_get_version(v)
    jrl_cmakemodules_get_commit(commit)
    if(commit)
        set(commit_msg "(commit: ${commit})")
    endif()

    message(
        STATUS
        "JRL CMake Modules v${v} ${commit_msg}
   Loaded from: ${CMAKE_CURRENT_FUNCTION_LIST_FILE}
    "
    )
endfunction()

#[============================================================================[
# `jrl_configure_default_build_type`

```cpp
jrl_configure_default_build_type(<build_type>)
```

**Type:** function


### Description
  Configures the default build type if none is specified.
  Usual values for <build_type> are: Debug, Release, MinSizeRel, RelWithDebInfo.


### Arguments
* `build_type`: The default build type to set.


### Example
```cmake
jrl_configure_default_build_type(RelWithDebInfo)
```
#]============================================================================]
function(jrl_configure_default_build_type build_type)
    set(standard_build_types Debug Release MinSizeRel RelWithDebInfo)
    if(NOT build_type IN_LIST standard_build_types)
        message(
            AUTHOR_WARNING
            "Unusual build type provided: ${build_type}, standard values are: ${standard_build_types}"
        )
    endif()

    # Check if environment variable CMAKE_BUILD_TYPE is set (single-config generators)
    if(DEFINED ENV{CMAKE_BUILD_TYPE})
        message(
            DEBUG
            "Environment variable CMAKE_BUILD_TYPE is set to '$ENV{CMAKE_BUILD_TYPE}', will not override it."
        )
        return()
    endif()

    if(NOT CMAKE_BUILD_TYPE AND NOT CMAKE_CONFIGURATION_TYPES)
        message(STATUS "Setting build type to '${build_type}' as none was specified.")
        set(CMAKE_BUILD_TYPE ${build_type} CACHE STRING "Choose the type of build." FORCE)
        # set the possible values of build type for cmake-gui
        set_property(CACHE CMAKE_BUILD_TYPE PROPERTY STRINGS ${standard_build_types})
    else()
        message(
            STATUS
            "Build type CMAKE_BUILD_TYPE: '${CMAKE_BUILD_TYPE}' CMAKE_CONFIGURATION_TYPES: '${CMAKE_CONFIGURATION_TYPES}'"
        )
    endif()
endfunction()

#[============================================================================[
# `jrl_configure_default_binary_dirs`

```cpp
jrl_configure_default_binary_dirs()
```

**Type:** macro


### Description
  Configures the default output directory for binaries and libraries to
  `${CMAKE_BINARY_DIR}/bin` and `${CMAKE_BINARY_DIR}/lib`.
  Implemented as a macro setting plain (non-cache) variables: it must be
  called directly from a project's `CMakeLists.txt` (not wrapped in a
  `function()`, or the variables it sets are lost), and it does not leak into
  a project that embeds this one via `add_subdirectory()`/`FetchContent`.
  Calling it from inside a `function()` throws an error.


### Arguments
  None


### Example
```cmake
jrl_configure_default_binary_dirs()
```
#]============================================================================]
macro(jrl_configure_default_binary_dirs)
    if(DEFINED CMAKE_CURRENT_FUNCTION)
        message(
            FATAL_ERROR
            "jrl_configure_default_binary_dirs() must be called directly from a CMakeLists.txt, not from inside function '${CMAKE_CURRENT_FUNCTION}()'.
            the output directories it sets would be lost when that function returns.
            "
        )
    endif()

    # doc: https://cmake.org/cmake/help/v3.22/manual/cmake-buildsystem.7.html#id47
    set(CMAKE_RUNTIME_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/bin) # For Unix/MacOS executables, Windows: .exe, .dll, .pyd
    set(CMAKE_LIBRARY_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/lib) # for Unix/MacOS shared libraries .so/.dylib and Windows: .lib (import libraries for shared libraries)
    set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/lib) # For static libraries add_library(STATIC ...) .a and Windows: .lib
    # /!\ MODULE libraries are dynamic libraries. On Windows, python modules are MODULE libraries, with pyd extension.
    #     They should be placed explicitely in lib/site-packages when building python extensions.
    foreach(_jrl_config Debug Release MinSizeRel RelWithDebInfo)
        string(TOUPPER ${_jrl_config} _jrl_config)
        set(CMAKE_RUNTIME_OUTPUT_DIRECTORY_${_jrl_config} ${CMAKE_BINARY_DIR}/bin)
        set(CMAKE_LIBRARY_OUTPUT_DIRECTORY_${_jrl_config} ${CMAKE_BINARY_DIR}/lib)
        set(CMAKE_ARCHIVE_OUTPUT_DIRECTORY_${_jrl_config} ${CMAKE_BINARY_DIR}/lib)
    endforeach()
    unset(_jrl_config)
endmacro()

#[============================================================================[
# `jrl_target_set_output_directory`

```cpp
jrl_target_set_output_directory(
    <target_name>
    OUTPUT_DIRECTORY <dir>
)
```

**Type:** function


### Description
  This function configures the `ARCHIVE_OUTPUT_DIRECTORY`,
  `LIBRARY_OUTPUT_DIRECTORY`, and `RUNTIME_OUTPUT_DIRECTORY` properties
  for the specified target.
  This is useful for python modules that need to be placed in a specific directory.


### Arguments
* `target_name`: The target to configure.
* `OUTPUT_DIRECTORY`: The directory where to put the output artifacts.


### Example
```cmake
jrl_target_set_output_directory(my_python_module_target OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/lib/site-packages)
```
#]============================================================================]
function(jrl_target_set_output_directory target_name)
    set(options)
    set(oneValueArgs OUTPUT_DIRECTORY)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)
    _jrl_check_target_exists(${target_name})
    _jrl_check_var_defined(arg_OUTPUT_DIRECTORY)

    set(dir ${arg_OUTPUT_DIRECTORY})

    set_target_properties(
        ${target_name}
        PROPERTIES
            RUNTIME_OUTPUT_DIRECTORY ${dir}
            LIBRARY_OUTPUT_DIRECTORY ${dir}
            ARCHIVE_OUTPUT_DIRECTORY ${dir}
    )

    foreach(config Debug Release MinSizeRel RelWithDebInfo)
        string(TOUPPER ${config} config)
        set_target_properties(
            ${target_name}
            PROPERTIES
                RUNTIME_OUTPUT_DIRECTORY_${config} ${dir}
                LIBRARY_OUTPUT_DIRECTORY_${config} ${dir}
                ARCHIVE_OUTPUT_DIRECTORY_${config} ${dir}
        )
    endforeach()
endfunction()

#[============================================================================[
# `jrl_configure_default_install_dirs`

```cpp
jrl_configure_default_install_dirs()
```

**Type:** function


### Description
  Configures the default install directories using GNUInstallDirs (bin, lib, include, etc.).
  Works on all platforms.


### Arguments
  None


### Example
```cmake
jrl_configure_default_install_dirs()
```
#]============================================================================]
function(jrl_configure_default_install_dirs)
    # Prevent the following warning on pure-cmake projects (i.e. defined with LANGUAGES NONE, like jrl-cmakemodules):
    # "Unable to determine default CMAKE_INSTALL_LIBDIR directory because no target architecture is known.
    # Please enable at least one language before including GNUInstallDirs"
    # ref: https://github.com/Kitware/CMake/blob/v4.2.3/Modules/GNUInstallDirs.cmake#L434C8-L435C75
    # issue: https://gitlab.kitware.com/cmake/cmake/-/issues/23461

    if(NOT DEFINED CMAKE_SIZEOF_VOID_P)
        set(CMAKE_SIZEOF_VOID_P 0)
    endif()

    include(GNUInstallDirs)
endfunction()

#[============================================================================[
# `jrl_configure_default_install_prefix`

```cpp
jrl_configure_default_install_prefix(<default_install_prefix>)
```

**Type:** function


### Description
  If not provided by the user, set a default CMAKE_INSTALL_PREFIX. Useful for IDEs.


### Arguments
* `default_install_prefix`: The default install prefix to set.


### Example
```cmake
jrl_configure_default_install_prefix(/opt/my_project)
```
#]============================================================================]
function(jrl_configure_default_install_prefix default_install_prefix)
    if(CMAKE_INSTALL_PREFIX_INITIALIZED_TO_DEFAULT)
        message(STATUS "Setting default install prefix to '${default_install_prefix}'")
        set(CMAKE_INSTALL_PREFIX
            ${default_install_prefix}
            CACHE PATH
            "Install path prefix, prepended onto relative install directories."
            FORCE
        )
        mark_as_advanced(CMAKE_INSTALL_PREFIX)
    endif()
endfunction()

#[============================================================================[
# `jrl_configure_uninstall_target`

```cpp
jrl_configure_uninstall_target()
```

**Type:** function


### Description
  Setup an uninstall target that can be used to uninstall the project.
  It will create a cmake_uninstall.cmake script next to the cmake_install.cmake script in the build directory.


### Arguments
  None


### Example
```cmake
jrl_configure_uninstall_target()
# And then cmake --build . --target uninstall
```
#]============================================================================]
function(jrl_configure_uninstall_target)
    if(TARGET uninstall)
        return()
    endif()

    configure_file(
        "${_JRL_TEMPLATES_DIR}/cmake_uninstall.cmake.in"
        "${CMAKE_CURRENT_BINARY_DIR}/cmake_uninstall.cmake"
        @ONLY
    )

    add_custom_target(
        uninstall
        COMMAND ${CMAKE_COMMAND} -P ${CMAKE_CURRENT_BINARY_DIR}/cmake_uninstall.cmake
    )
endfunction()

#[============================================================================[
# `jrl_configure_defaults`

```cpp
jrl_configure_defaults()
```

**Type:** macro


### Description
  Setup the default options for a project (opinionated defaults).
  * Default build type: Release
  * Default binary directories: ${CMAKE_BINARY_DIR}/bin and ${CMAKE_BINARY_DIR}/lib
  * Default install directories: via GNUInstallDirs (bin, lib, include, etc.)
  * Default install prefix: ${CMAKE_BINARY_DIR}/install
  * Copy compile_commands.json to source directory for clangd support (only if the build directory is not <source_dir>/build)
  * Add a `uninstall` target to uninstall the project.

  Must be called directly from a project's `CMakeLists.txt`, not wrapped in a `function()`. See `jrl_configure_default_binary_dirs`.


### Arguments
  None


### Example
```cmake
jrl_configure_defaults()
```
#]============================================================================]
macro(jrl_configure_defaults)
    jrl_configure_default_build_type(Release)
    jrl_configure_default_binary_dirs()
    jrl_configure_default_install_dirs()
    jrl_configure_default_install_prefix(${CMAKE_BINARY_DIR}/install)
    jrl_configure_copy_compile_commands_in_source_dir()
    jrl_configure_uninstall_target()
endmacro()

#[============================================================================[
# `jrl_get_cxx_compiler_id`

```cpp
jrl_get_cxx_compiler_id(<output_var>)
```

**Type:** function


### Description
  Get the CMAKE_CXX_COMPILER_ID variable, but also handles clang-cl and AppleClang exceptions.
  clang-cl is considered as MSVC, AppleClang as Clang.


### Arguments
* `output_var`: Variable to store the compiler ID.


### Example
```cmake
jrl_get_cxx_compiler_id(cxx_compiler_id)
message(STATUS "Compiler ID: ${cxx_compiler_id}")
```
#]============================================================================]
function(jrl_get_cxx_compiler_id output_var)
    _jrl_check_var_defined(CMAKE_CXX_COMPILER_ID)

    if(CMAKE_CXX_COMPILER_FRONTEND_VARIANT)
        set(cxx_compiler_id ${CMAKE_CXX_COMPILER_FRONTEND_VARIANT})
        set(${output_var} ${cxx_compiler_id} PARENT_SCOPE)
        return()
    endif()

    if(CMAKE_CXX_COMPILER_ID STREQUAL "AppleClang")
        set(cxx_compiler_id "Clang")
    elseif(CMAKE_CXX_COMPILER_ID STREQUAL "Clang" AND CMAKE_CXX_SIMULATE_ID STREQUAL "MSVC")
        set(cxx_compiler_id "MSVC")
    else()
        set(cxx_compiler_id ${CMAKE_CXX_COMPILER_ID})
    endif()

    set(${output_var} ${cxx_compiler_id} PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_target_set_default_compile_options`

```cpp
jrl_target_set_default_compile_options(
    <target_name>
    <visibility>
)
```

**Type:** function


### Description
  Enable the most common warnings for MSVC, GCC and Clang.

  **MSVC** (`/W4` level + adjustments):
  * `/W4` — Enable most warnings
  * `/wd4250` — Suppress "inherits via dominance"
  * `/wd4706` — Suppress assignment within conditional expression
  * `/wd5030` — Suppress unrecognized attribute warnings
  * `/wd4996` — Suppress "function may be unsafe" deprecation warnings
  * `/we4834` — Error on discarding return value of `[[nodiscard]]` function
  * `/we4062` — Error on unhandled enumerator in switch

  **GCC / Clang**:
  * `-Wall` — Enable most warnings
  * `-Wextra` — Enable extra warnings
  * `-Wconversion` — Warn on implicit type conversions that may lose data
  * `-Wpedantic` — Warn on non-standard C++ usage


### Arguments
* `target_name`: The target to modify.
* `visibility`: PRIVATE, PUBLIC or INTERFACE.


### Example
```cmake
jrl_target_set_default_compile_options(my_target INTERFACE)
```
#]============================================================================]
function(jrl_target_set_default_compile_options target_name visibility)
    _jrl_check_target_exists(${target_name})
    _jrl_check_valid_visibility(${visibility})

    jrl_get_cxx_compiler_id(cxx_compiler_id)

    if(cxx_compiler_id STREQUAL "MSVC")
        target_compile_options(
            ${target_name}
            ${visibility}
            /W4 # Enable most warnings
            /wd4250 # "Inherits via dominance" - happens with diamond inheritance, not really an issue
            /wd4706 # assignment within conditional expression
            /wd5030 # pointer or reference to potentially throwing function used in noexcept context
            /wd4996 # function may be unsafe
            /we4834 # discarding return value of function with 'nodiscard' attribute
            /we4062 # enumerator 'xyz' in switch of enum 'abc' is not handled
        )
    elseif(cxx_compiler_id STREQUAL "GNU" OR cxx_compiler_id STREQUAL "Clang")
        target_compile_options(
            ${target_name}
            ${visibility}
            -Wall # Enable most warnings
            -Wextra # Enable extra warnings
            -Wconversion # Warn on type conversions that may lose information
            -Wpedantic # Warn on non-standard C++ usage
        )
    else()
        message(WARNING "Unknown compiler '${cxx_compiler_id}'. No default compile options set.")
    endif()
endfunction()

#[============================================================================[
# `jrl_target_enforce_msvc_conformance`

```cpp
jrl_target_enforce_msvc_conformance(
    <target_name>
    <visibility>
)
```

**Type:** function


### Description
  Enforce MSVC C++ conformance mode so MSVC behaves more like GCC and Clang.
  If the compiler is not MSVC, this function does nothing.

  **MSVC** options applied:
  * `/permissive-`: Disable non-standard extensions (enables conformance mode)
  * `/Zc:__cplusplus`: Defines the `__cplusplus` compile definition
  * `/EHsc`: Enable standard C++ exception handling semantics
  * `/bigobj`: Increase the number of sections in object files (avoids C1128 fatal error)

### Arguments
* `target_name`: The target to modify.
* `visibility`: PRIVATE, PUBLIC or INTERFACE.


### Example
```cmake
jrl_target_enforce_msvc_conformance(my_target INTERFACE)
```
#]============================================================================]
function(jrl_target_enforce_msvc_conformance target_name visibility)
    _jrl_check_target_exists(${target_name})
    _jrl_check_valid_visibility(${visibility})

    jrl_get_cxx_compiler_id(cxx_compiler_id)
    if(NOT cxx_compiler_id STREQUAL "MSVC")
        return()
    endif()

    target_compile_options(
        ${target_name}
        ${visibility}
        /permissive-
        /Zc:__cplusplus
        /EHsc
        /bigobj
    )
endfunction()

#[============================================================================[
# `jrl_target_treat_all_warnings_as_errors`

```cpp
jrl_target_treat_all_warnings_as_errors(
    <target_name>
    <visibility>
)
```

**Type:** function


### Description
  Treat all warnings as errors for a targets (/WX for MSVC, -Werror for GCC/Clang).
  Can be disabled on the cmake cli with --compile-no-warning-as-error.


### Arguments
* `target_name`: The target to modify.
* `visibility`: PRIVATE, PUBLIC or INTERFACE.


### Example
```cmake
jrl_target_treat_all_warnings_as_errors(my_target PRIVATE)
```
#]============================================================================]
function(jrl_target_treat_all_warnings_as_errors target_name visibility)
    _jrl_check_target_exists(${target_name})
    _jrl_check_valid_visibility(${visibility})

    jrl_get_cxx_compiler_id(cxx_compiler_id)

    if(cxx_compiler_id STREQUAL "MSVC")
        target_compile_options(${target_name} ${visibility} /WX)
    elseif(cxx_compiler_id STREQUAL "GNU" OR cxx_compiler_id STREQUAL "Clang")
        target_compile_options(${target_name} ${visibility} -Werror)
    else()
        message(WARNING "Unknown compiler '${cxx_compiler_id}'. No warning as error flag set.")
    endif()
endfunction()

#[============================================================================[
# `_jrl_normalize_version`

```cpp
_jrl_normalize_version(
    <version_str>
    [VERSION_FULL <var>]
    [VERSION_FULL_WITH_TWEAK <var>]
    [VERSION_MAJOR <var>]
    [VERSION_MINOR <var>]
    [VERSION_PATCH <var>]
    [VERSION_TWEAK <var>]
)
```

**Type:** function


### Description
    Normalizes a version string into a 3 and 4-component version string (major.minor.patch.tweak),
    padding with zeros if necessary. It handles version strings with suffixes by extracting
    only the leading numeric part.
    Stops at the first non-numeric/non-dot character (like '-' in '-rc1').


### Arguments
    version_str: The version string to normalize.
    VERSION_FULL: Variable to store the normalized version without tweak (major.minor.patch).
    VERSION_FULL_WITH_TWEAK: Variable to store the full version with tweak (major.minor.patch.tweak).
    VERSION_MAJOR: Variable to store the major version component.
    VERSION_MINOR: Variable to store the minor version component.
    VERSION_PATCH: Variable to store the patch version component.
    VERSION_TWEAK: Variable to store the tweak version component.


### Example
```cmake
_jrl_normalize_version("1.2.3" VERSION_FULL v VERSION_MAJOR major)
# Examples:
# 1.2.3       -> VERSION_FULL=1.2.3  VERSION_FULL_WITH_TWEAK=1.2.3.0
# 1.2         -> VERSION_FULL=1.2.0  VERSION_FULL_WITH_TWEAK=1.2.0.0
# 4           -> VERSION_FULL=4.0.0  VERSION_FULL_WITH_TWEAK=4.0.0.0
# 1.0.5.2023  -> VERSION_FULL=1.0.5  VERSION_FULL_WITH_TWEAK=1.0.5.2023
# ""          -> VERSION_FULL=0.0.0  VERSION_FULL_WITH_TWEAK=0.0.0.0
# 2.5-rc1     -> VERSION_FULL=2.5.0  VERSION_FULL_WITH_TWEAK=2.5.0.0
```
#]============================================================================]
function(_jrl_normalize_version version_str)
    set(options)
    set(oneValueArgs
        VERSION_FULL
        VERSION_FULL_WITH_TWEAK
        VERSION_MAJOR
        VERSION_MINOR
        VERSION_PATCH
        VERSION_TWEAK
    )
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    string(REGEX MATCH "^[0-9.]+" clean_version "${version_str}")

    string(REPLACE "." ";" version_comp "${clean_version}")

    list(LENGTH version_comp len)

    if(len GREATER 0)
        list(GET version_comp 0 major)
    else()
        set(major 0)
    endif()

    if(len GREATER 1)
        list(GET version_comp 1 minor)
    else()
        set(minor 0)
    endif()

    if(len GREATER 2)
        list(GET version_comp 2 patch)
    else()
        set(patch 0)
    endif()

    if(len GREATER 3)
        list(GET version_comp 3 tweak)
    else()
        set(tweak 0)
    endif()

    set(version_full "${major}.${minor}.${patch}")
    set(version_full_with_tweak "${major}.${minor}.${patch}.${tweak}")

    if(arg_VERSION_MAJOR)
        set(${arg_VERSION_MAJOR} ${major} PARENT_SCOPE)
    endif()

    if(arg_VERSION_MINOR)
        set(${arg_VERSION_MINOR} ${minor} PARENT_SCOPE)
    endif()

    if(arg_VERSION_PATCH)
        set(${arg_VERSION_PATCH} ${patch} PARENT_SCOPE)
    endif()

    if(arg_VERSION_TWEAK)
        set(${arg_VERSION_TWEAK} ${tweak} PARENT_SCOPE)
    endif()

    if(arg_VERSION_FULL)
        set(${arg_VERSION_FULL} ${version_full} PARENT_SCOPE)
    endif()

    if(arg_VERSION_FULL_WITH_TWEAK)
        set(${arg_VERSION_FULL_WITH_TWEAK} ${version_full_with_tweak} PARENT_SCOPE)
    endif()
endfunction()

#[============================================================================[
# `_jrl_target_generate_header`

```cpp
_jrl_target_generate_header(
    <target_name>
    <visibility>
    FILENAME <header_name>
    TEMPLATE_FILE <template_file>
    [LIBRARY_NAME <library_name>]
    [GEN_DIR <gen_dir>]
    [TEMPLATE_VARIABLES <var1> <var2> ...]
    [SKIP_INSTALL]
)
```

**Type:** function


### Description
    Same as configure_file, but for target-specific generated headers.
    The generated header is added to the target's include directories and scheduled for installation
    (unless SKIP_INSTALL is specified).


### Arguments
* `target_name`: The target to which the header belongs.
* `visibility`: Visibility scope (PRIVATE, PUBLIC, INTERFACE).
* `FILENAME`: The relative path/name of the generated header (e.g., "my_project/my_header.hpp").
                  Must be a relative path. This determines how the file is included (e.g., #include <FILENAME>).
                  Default: <LIBRARY_NAME>/<header_filename>.hpp
* `TEMPLATE_FILE`: Path to the template file.
* `LIBRARY_NAME`: Name of the library. Used to create valid C identifiers.
                   LIBRARY_NAME will be used to create JRL_LIBRARY_NAME and JRL_LIBRARY_NAME_UPPERCASE variables for the template.
                   Default: <target_name>.
* `GEN_DIR`: Directory where the header is generated (default: ${CMAKE_CURRENT_BINARY_DIR}/generated/include).
              GEN_DIR will be added to the target's include directories with the specified visibility.
* `TEMPLATE_VARIABLES`: List of variables to be expanded in the template (they must be defined in the calling scope).
* `SKIP_INSTALL`: Do not install the generated header.


### Example
```cmake
_jrl_target_generate_header(mylib PUBLIC
    FILENAME my_project/my_header.hh
    TEMPLATE_FILE ${CMAKE_CURRENT_SOURCE_DIR}/templates/my_header.hpp.in
    LIBRARY_NAME my_project
    TEMPLATE_VARIABLES "VAR1;VAR2"
)
```
#]============================================================================]
function(_jrl_target_generate_header target_name visibility)
    set(options SKIP_INSTALL)
    set(oneValueArgs LIBRARY_NAME FILENAME TEMPLATE_FILE GEN_DIR)
    set(multiValueArgs TEMPLATE_VARIABLES)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_target_exists(${target_name})
    _jrl_check_valid_visibility(${visibility})
    _jrl_check_var_defined(arg_TEMPLATE_FILE)
    _jrl_check_file_exists(${arg_TEMPLATE_FILE})

    if(arg_LIBRARY_NAME)
        set(library_name ${arg_LIBRARY_NAME})
    else()
        set(library_name ${target_name})
    endif()

    string(MAKE_C_IDENTIFIER ${library_name} JRL_LIBRARY_NAME)
    string(TOUPPER ${JRL_LIBRARY_NAME} JRL_LIBRARY_NAME_UPPERCASE)

    if(arg_TEMPLATE_VARIABLES)
        set(template_variables ${arg_TEMPLATE_VARIABLES})
    else()
        set(template_variables "")
    endif()

    list(APPEND template_variables JRL_LIBRARY_NAME)
    list(APPEND template_variables JRL_LIBRARY_NAME_UPPERCASE)

    if(arg_FILENAME)
        if(IS_ABSOLUTE ${arg_FILENAME})
            message(
                FATAL_ERROR
                "FILENAME argument must be a relative path (ex: mylib/myheader.hpp), got absolute path: ${arg_FILENAME}"
            )
        endif()
        set(header_name ${arg_FILENAME})
    else()
        # Extract header name from template filename
        # Ex: /path/to/header_filename.hpp.in -> header_filename.hpp
        # Ex: header_filename.hpp.in -> header_filename.hpp
        cmake_path(REMOVE_EXTENSION arg_TEMPLATE_FILE LAST_ONLY OUTPUT_VARIABLE header_filepath)
        cmake_path(GET header_filepath FILENAME header_filename)
        set(header_name ${library_name}/${header_filename})
    endif()

    if(arg_GEN_DIR)
        set(gen_dir ${arg_GEN_DIR})
    else()
        set(gen_dir ${CMAKE_CURRENT_BINARY_DIR}/generated/include)
    endif()

    if(arg_TEMPLATE_VARIABLES)
        foreach(var_name IN LISTS arg_TEMPLATE_VARIABLES)
            set(${var_name} ${${var_name}})
        endforeach()
    endif()

    set(output_filepath ${gen_dir}/${header_name})

    configure_file(${arg_TEMPLATE_FILE} ${output_filepath} @ONLY)

    target_include_directories(${target_name} ${visibility} $<BUILD_INTERFACE:${gen_dir}>)

    if(arg_SKIP_INSTALL)
        return()
    endif()

    jrl_target_headers(${target_name} ${visibility}
        HEADERS ${output_filepath}
        BASE_DIRS ${gen_dir}
    )
endfunction()

#[============================================================================[
# `jrl_target_generate_warning_header`

```cpp
jrl_target_generate_warning_header(
    <target_name>
    <visibility>
    [<args>...]
)
```

**Type:** function


### Description
    Generate a <library_name>/warning.hpp header for a target.


### Arguments
* `target_name`: The target to which the header belongs.
* `visibility`: Visibility scope (PRIVATE, PUBLIC, INTERFACE).
* `<args>...`: Additional arguments passed to `_jrl_target_generate_header`.


### Example
```cmake
jrl_target_generate_warning_header(my_target PUBLIC
    LIBRARY_NAME mylib
    FILENAME mylib/warning.hh
)
```
#]============================================================================]
function(jrl_target_generate_warning_header)
    _jrl_target_generate_header(
        ${ARGV}
        TEMPLATE_FILE ${_JRL_TEMPLATES_DIR}/warning.hpp.in
    )
endfunction()

#[============================================================================[
# `jrl_target_generate_deprecated_header`

```cpp
jrl_target_generate_deprecated_header(
    <target_name>
    <visibility>
    [<args>...]
)
```

**Type:** function


### Description
    Generate a <library_name>/deprecated.hpp header for a target.


### Arguments
* `target_name`: The target to which the header belongs.
* `visibility`: Visibility scope (PRIVATE, PUBLIC, INTERFACE).
* `<args>...`: Additional arguments passed to `_jrl_target_generate_header`.


### Example
```cmake
jrl_target_generate_deprecated_header(my_target PUBLIC
    LIBRARY_NAME mylib
    FILENAME mylib/deprecated.hh
)
```
#]============================================================================]
function(jrl_target_generate_deprecated_header)
    _jrl_target_generate_header(
        ${ARGV}
        TEMPLATE_FILE ${_JRL_TEMPLATES_DIR}/deprecated.hpp.in
    )
endfunction()

#[============================================================================[
# `jrl_target_generate_tracy_header`

```cpp
jrl_target_generate_tracy_header(
    <target_name>
    <visibility>
    [<args>...]
)
```

**Type:** function


### Description
    Generate a <library_name>/tracy.hpp header for a target.


### Arguments
* `target_name`: The target to which the header belongs.
* `visibility`: Visibility scope (PRIVATE, PUBLIC, INTERFACE).
* `<args>...`: Additional arguments passed to `_jrl_target_generate_header`.


### Example
```cmake
jrl_target_generate_tracy_header(my_target PUBLIC
    LIBRARY_NAME mylib
    FILENAME mylib/tracy.hh
)
```
#]============================================================================]
function(jrl_target_generate_tracy_header)
    _jrl_target_generate_header(
        ${ARGV}
        TEMPLATE_FILE ${_JRL_TEMPLATES_DIR}/tracy.hpp.in
    )
endfunction()

#[============================================================================[
# `jrl_target_generate_config_header`

```cpp
jrl_target_generate_config_header(
    <target_name>
    <visibility>
    [VERSION <version>]
    [<args>...]
)
```

**Type:** function


### Description
    Generate a config header for a target.
    The generated header is added to the target's include directories and scheduled for installation
    (via jrl_export_package()).


### Arguments
* `target_name`: The target to which the header belongs.
* `visibility`: Visibility scope (PRIVATE, PUBLIC, INTERFACE).
* `VERSION`: The version string to include in the generated header. Otherwise uses the target's VERSION property, and otherwise the PROJECT_VERSION.
* `<args>...`: Additional keyword arguments forwarded to `_jrl_target_generate_header` (e.g. `LIBRARY_NAME`, `FILENAME`, `GEN_DIR`, `SKIP_INSTALL`).



### Example
```cmake
jrl_target_generate_config_header(mylib PUBLIC)
# Will generate mylib/config.hpp. Use with #include "mylib/config.hpp"
# This header will be installed automatically with the mylib target (via jrl_export_package()).

jrl_target_generate_config_header(mylib PRIVATE)
# Will generate mylib/config.hpp. Use with #include "mylib/config.hpp"
# This header will NOT be installed automatically.

jrl_target_generate_config_header(mylib INTERFACE
  LIBRARY_NAME myproject
  VERSION ${PROJECT_VERSION}
)
# Will generate myproject/config.hh. Use with #include "myproject/config.hh"
# Inside you will find MYPROJECT_LIBRARY_VERSION macros (not MYLIB_LIBRARY_VERSION).
```
#]============================================================================]
function(jrl_target_generate_config_header target_name visibility)
    set(options)
    set(oneValueArgs VERSION)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

    _jrl_check_target_exists(${target_name})
    _jrl_check_valid_visibility(${visibility})

    if(arg_VERSION)
        set(library_version ${arg_VERSION})
    else()
        get_property(library_version TARGET ${target_name} PROPERTY VERSION)
        if(NOT library_version)
            message(
                WARNING
                "Target ${target_name} does not have a VERSION property set, using the project version instead (PROJECT_VERSION=${PROJECT_VERSION}).
            To remove this warning, set the VERSION property on the target using:

                set_target_properties(${target_name} PROPERTIES VERSION \${PROJECT_VERSION})
            "
            )
            set(library_version ${PROJECT_VERSION})
        endif()
    endif()

    _jrl_normalize_version(${library_version}
        VERSION_FULL JRL_LIBRARY_VERSION
        VERSION_MAJOR JRL_LIBRARY_VERSION_MAJOR
        VERSION_MINOR JRL_LIBRARY_VERSION_MINOR
        VERSION_PATCH JRL_LIBRARY_VERSION_PATCH
    )

    set(template_variables
        JRL_LIBRARY_VERSION
        JRL_LIBRARY_VERSION_MAJOR
        JRL_LIBRARY_VERSION_MINOR
        JRL_LIBRARY_VERSION_PATCH
    )

    _jrl_target_generate_header(${target_name} ${visibility}
        ${arg_UNPARSED_ARGUMENTS}
        TEMPLATE_FILE ${_JRL_TEMPLATES_DIR}/config.hpp.in
        TEMPLATE_VARIABLES ${template_variables}
    )
endfunction()

#[============================================================================[
# `_jrl_search_package_module_file`

```cpp
_jrl_search_package_module_file(
    <package_name>
    <output_filepath>
)
```

**Type:** function


### Description
  Searches for a find module named Find<package>.cmake.
  It iterates over the CMAKE_MODULE_PATH and the find-modules directory.
  This function is used to determine which module file was used by jrl_find_package.


### Arguments
* `package_name`: The package name.
* `output_filepath`: Variable to store the found path.


### Example
```cmake
_jrl_search_package_module_file(Eigen module_file)
```
#]============================================================================]
function(_jrl_search_package_module_file package_name output_filepath)
    set(module_filename "Find${package_name}.cmake")
    set(found_module_file "")
    # QUESTION: Should we look into cmake builtin modules?
    # set(cmake_builtin_modules_path "${CMAKE_ROOT}/Modules")
    foreach(module_path IN LISTS CMAKE_MODULE_PATH _JRL_FIND_MODULES_DIR)
        set(candidate_filepath "${module_path}/${module_filename}")
        message(DEBUG "        Searching for package module file at: ${candidate_filepath}")
        if(EXISTS ${candidate_filepath})
            set(found_module_file ${candidate_filepath})
            break()
        endif()
    endforeach()

    set(${output_filepath} ${found_module_file} PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_export_dependency`

```cpp
jrl_export_dependency(
        PACKAGE_NAME <name>
        [FIND_PACKAGE_ARGS <args>...]
        [PACKAGE_VARIABLES <vars>...]
        [PACKAGE_TARGETS <targets>...]
        [EXPECTED_TARGETS <targets>...]
        [MODULE_FILE <path>]
)
```

**Type:** function


### Description
Records a dependency discovered with `jrl_find_package()` into a JSON array stored in the
global property `_jrl_${PROJECT_NAME}_package_dependencies`.

The content of this property is later consumed by `jrl_export_package()` to reverse the link
between link libraries and the `find_package` calls that provided them.

It is called **automatically** by `jrl_find_package()`.

Note that it could also be useful in scenarios where the dependency that was not
discovered with jrl_find_package(). In that case, only the package name and the targets
are relevant.


### Arguments
* `PACKAGE_NAME`: Name of the dependency package (e.g., Eigen3).
* `FIND_PACKAGE_ARGS`: The arguments originally passed to `find_package()` (list).
* `PACKAGE_VARIABLES`: Variables created by `find_package()` that should be tracked (list).
* `PACKAGE_TARGETS`: Imported targets created by `find_package()` that should be tracked (list).
* `EXPECTED_TARGETS`: The expected targets passed to `jrl_find_package()`. Only used for debugging in generate-dependencies.cmake.
* `MODULE_FILE`: Absolute path to the Find<Package>.cmake module used, if any.


### Example
```cmake
# Dummy example
jrl_export_dependency(
    PACKAGE_NAME Eigen3
    FIND_PACKAGE_ARGS "Eigen3;3.4;REQUIRED"
    PACKAGE_VARIABLES "Eigen3_FOUND;Eigen3_VERSION"
    PACKAGE_TARGETS "Eigen3::Eigen"
    MODULE_FILE ${CMAKE_CURRENT_LIST_DIR}/FindEigen3.cmake
)

# Manual export of a dependency not found with jrl_find_package
jrl_export_dependency(
    PACKAGE_NAME MyLib
    FIND_PACKAGE_ARGS "MyLib;REQUIRED"
    PACKAGE_TARGETS "MyLib::MyLib"
)
# If you `target_link_libraries(my_target PUBLIC MyLib::MyLib)`, then jrl_export_package() will
# know that MyLib is a dependency of your package, and add the following lines to the generated
# `<project_name>Config.cmake` file:

if(NOT TARGET MyLib::MyLib)
    find_dependency(MyLib REQUIRED)
endif()
```
#]============================================================================]
function(jrl_export_dependency)
    set(options)
    set(oneValueArgs PACKAGE_NAME MODULE_FILE)
    set(multiValueArgs FIND_PACKAGE_ARGS PACKAGE_VARIABLES PACKAGE_TARGETS EXPECTED_TARGETS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(arg_PACKAGE_NAME)

    get_property(pd_json GLOBAL PROPERTY _jrl_${PROJECT_NAME}_package_dependencies)
    if(NOT pd_json)
        string(JSON pd_json SET "{}" "package_dependencies" "[]")
    endif()

    # Save the information about this package in a json object
    set(json "{}")
    string(JSON json SET "${json}" "package_name" "\"${arg_PACKAGE_NAME}\"")
    string(JSON json SET "${json}" "find_package_args" "\"${arg_FIND_PACKAGE_ARGS}\"")
    string(JSON json SET "${json}" "package_variables" "\"${arg_PACKAGE_VARIABLES}\"")
    string(JSON json SET "${json}" "package_targets" "\"${arg_PACKAGE_TARGETS}\"")
    string(JSON json SET "${json}" "expected_targets" "\"${arg_EXPECTED_TARGETS}\"")
    string(JSON json SET "${json}" "module_file" "\"${arg_MODULE_FILE}\"")
    string(JSON package_dependencies_length LENGTH "${pd_json}" "package_dependencies")
    string(
        JSON pd_json
        SET "${pd_json}"
        "package_dependencies"
        ${package_dependencies_length}
        "${json}"
    )

    # Save the JSON object in a global property for later use
    # See jrl_print_dependencies_summary, jrl_export_package, etc.
    set_property(GLOBAL PROPERTY _jrl_${PROJECT_NAME}_package_dependencies "${pd_json}")
endfunction()

#[============================================================================[
# `jrl_find_package`

```cpp
jrl_find_package(
    <PackageName>
    [version]
    [COMPONENTS <comp>...]
    [REQUIRED]
    [EXPECTED_TARGETS <target>...]
)
```

**Type:** macro


### Description
  Wrapper around CMake's find_package used for dependency tracking and logging.
  It forwards the arguments provided to the standard CMake find_package, while adding some new arguments.
  It records the find_package arguments, the variables created, the imported targets, and the module file used (if any).
  All that info is used for later introspection and analysis. It is very useful for exporting package dependencies (see jrl_export_package()).
  After the jrl_find_package calls, use jrl_print_dependencies_summary() for printing an extensive analysis.


### Arguments
    <PackageName> [<version>] [REQUIRED] [COMPONENTS <components>...] - The same as find_package.
    EXPECTED_TARGETS <target>... - Optional list of targets expected to be imported by find_package().
    If all listed targets already exist (imported by another project for example), find_package() is skipped.


### Example
```cmake
jrl_find_package(Eigen 3.3 REQUIRED)
jrl_find_package(Boost REQUIRED COMPONENTS filesystem system)
jrl_find_package(Eigen3 CONFIG REQUIRED EXPECTED_TARGETS Eigen3::Eigen)
```
#]============================================================================]
macro(jrl_find_package)
    set(options)
    set(oneValueArgs)
    set(multiValueArgs EXPECTED_TARGETS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})

    # Check at least 1 argument (the package name) is provided
    if(ARGC EQUAL 0)
        message(
            FATAL_ERROR
            "jrl_find_package(<PackageName>) requires at least the package name as argument."
        )
    endif()

    message(STATUS "[${ARGV0}]")
    message(DEBUG "Executing jrl_find_package with args ${ARGV}")

    # Pkg name is the first argument of find_package(<pkg_name> ...)
    set(package_name ${ARGV0})

    # Throw an error if user provides EXPECTED_TARGETS without any value.
    if(arg_KEYWORDS_MISSING_VALUES)
        string(REPLACE ";" ", " missing_values_pp "${arg_KEYWORDS_MISSING_VALUES}")
        message(FATAL_ERROR "Missing values for keyword(s): ${missing_values_pp}")
    endif()

    set(expected_targets ${arg_EXPECTED_TARGETS})
    set(find_package_args ${arg_UNPARSED_ARGUMENTS})

    # We want to skip the find_package call if all expected targets are already present,
    # imported by another package for example.
    set(all_expected_targets_present TRUE)
    if(expected_targets)
        foreach(tgt IN LISTS expected_targets)
            if(NOT TARGET ${tgt})
                set(all_expected_targets_present FALSE)
                break()
            endif()
        endforeach()
    else()
        set(all_expected_targets_present FALSE)
    endif()

    set(skip_find_package FALSE)
    if(expected_targets AND all_expected_targets_present)
        set(skip_find_package TRUE)
    endif()

    # search for the module file only if CONFIG is not in the find_package args
    if(NOT "CONFIG" IN_LIST find_package_args)
        _jrl_search_package_module_file(${package_name} module_file)
    endif()

    if(module_file)
        cmake_path(CONVERT "${module_file}" TO_CMAKE_PATH_LIST module_file NORMALIZE)
        # Add the parent path to the CMAKE_MODULE_PATH
        cmake_path(GET module_file PARENT_PATH module_dir)
        set(cmake_module_path_backup ${CMAKE_MODULE_PATH})
        list(APPEND CMAKE_MODULE_PATH ${module_dir})
        message(STATUS "   Using custom module file: ${module_file}")
    endif()

    # Call find_package with the provided arguments
    string(REPLACE ";" " " fp_pp "${find_package_args}")
    message(STATUS "   Executing find_package(${fp_pp})")

    if(skip_find_package)
        message(
            STATUS
            "   All expected targets for ${package_name} are already present. Skipping find_package."
        )
        # Simulate how a regular jrl_find_package would detect the imported targets,
        # so that the rest of the code (logging, jrl_export_dependency) works as if we had called find_package.
        set(${package_name}_FOUND TRUE)
        set(package_targets ${expected_targets})
        set(package_variables "")
    else()
        # Saving the list of imported targets and variables BEFORE the call to find_package
        get_property(
            imported_targets_before
            DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
            PROPERTY IMPORTED_TARGETS
        )
        get_property(variables_before DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR} PROPERTY VARIABLES)

        find_package(${find_package_args})

        # Getting the list of imported targets and variables AFTER the call to find_package
        get_property(package_variables DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR} PROPERTY VARIABLES)
        get_property(
            package_targets
            DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}
            PROPERTY IMPORTED_TARGETS
        )
        list(REMOVE_ITEM package_variables ${variables_before} variables_before)
        list(REMOVE_ITEM package_targets ${imported_targets_before})
    endif()

    if(${package_name}_FOUND)
        message(DEBUG "   Executing find_package()...[OK]")
    else()
        message(DEBUG "   Executing find_package()...[NOT_FOUND]")
    endif()

    # Put back CMAKE_MODULE_PATH to its previous value
    if(module_dir)
        set(CMAKE_MODULE_PATH ${cmake_module_path_backup})
    endif()

    if(expected_targets)
        set(unmatched_expected_targets "")
        foreach(expected_target IN LISTS expected_targets)
            if(NOT expected_target IN_LIST package_targets)
                list(APPEND unmatched_expected_targets ${expected_target})
            endif()
        endforeach()

        if(unmatched_expected_targets)
            string(REPLACE ";" ", " expected_targets_pp "${expected_targets}")

            if(package_targets)
                string(REPLACE ";" ", " imported_targets_pp "${package_targets}")
            else()
                set(imported_targets_pp "<none>")
            endif()

            string(REPLACE ";" ", " unmatched_expected_targets_pp "${unmatched_expected_targets}")

            message(
                FATAL_ERROR
                "
Package '${package_name}' was expected to provide the following targets (via EXPECTED_TARGETS): ${expected_targets_pp}
But after executing find_package(${fp_pp}), the following targets were imported: ${imported_targets_pp}
The expected targets that were not imported are: ${unmatched_expected_targets_pp}
"
            )
        endif()
    endif()

    if(${package_name}_VERSION)
        message(STATUS "   Version found: ${${package_name}_VERSION}")
    endif()

    string(REPLACE ";" ", " package_variables_pp "${package_variables}")
    if(package_variables)
        message(DEBUG "   New variables detected: ${package_variables_pp}")
    else()
        message(DEBUG "   No new variables detected.")
    endif()

    string(REPLACE ";" ", " package_targets_pp "${package_targets}")
    if(package_targets)
        message(STATUS "   Imported targets detected: ${package_targets_pp}")
    else()
        message(STATUS "   No imported targets detected.")
    endif()

    jrl_export_dependency(
        PACKAGE_NAME ${package_name}
        FIND_PACKAGE_ARGS "${find_package_args}"
        PACKAGE_VARIABLES "${package_variables}"
        PACKAGE_TARGETS "${package_targets}"
        EXPECTED_TARGETS "${expected_targets}"
        MODULE_FILE "${module_file}"
    )

    # Unset temporary variables
    # jrl_find_package is a macro, so temporary variables leak into the caller scope
    unset(fp_pp)
    unset(package_name)
    unset(package_targets)
    unset(package_targets_pp)
    unset(package_variables)
    unset(package_variables_pp)
    unset(variables_before)
    unset(imported_targets_before)
    unset(module_file)
    unset(package_json)
    unset(expected_targets)
    unset(missing_values_pp)
    unset(all_expected_targets_present)
    unset(skip_find_package)
    unset(module_dir)
    unset(find_package_args)
    unset(unmatched_expected_targets)
    unset(expected_target)
    unset(expected_targets_pp)
    unset(imported_targets_pp)
    unset(unmatched_expected_targets_pp)
endmacro()

#[============================================================================[
# `jrl_print_dependencies_summary`

```cpp
jrl_print_dependencies_summary([DEPENDS <condition>])
```

**Type:** function


### Description
  Print a summary of all dependencies found via jrl_find_package, and some properties of their imported targets.


### Arguments
* `DEPENDS`: A conditional variable or expression that must evaluate to true for the summary to be printed.


### Example
```cmake
jrl_print_dependencies_summary(DEPENDS MY_TRUE_VAR)
jrl_print_dependencies_summary(DEPENDS [[DEFINED ENV{GITHUB_ACTION}]])
```
#]============================================================================]
function(jrl_print_dependencies_summary)
    set(options)
    set(oneValueArgs)
    set(multiValueArgs DEPENDS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    if(DEFINED arg_DEPENDS)
        set(eval_result ON)
        cmake_language(
            EVAL CODE
                "
            if(${arg_DEPENDS})
                set(eval_result ON)
            else()
                set(eval_result OFF)
            endif()
            "
        )
        if(NOT eval_result)
            message(
                DEBUG
                "jrl_print_dependencies_summary: DEPENDS condition '${arg_DEPENDS}' evaluated to false. Skipping summary."
            )
            return()
        endif()
    endif()

    _jrl_log_clear()

    get_property(deps GLOBAL PROPERTY _jrl_${PROJECT_NAME}_package_dependencies)
    if(NOT deps)
        message(STATUS "No dependencies found via jrl_find_package.")
        return()
    endif()

    _jrl_log("")
    _jrl_log("================= External Dependencies ======================================")
    _jrl_log("")

    string(JSON num_deps LENGTH "${deps}" "package_dependencies")
    math(EXPR max_idx "${num_deps} - 1")
    _jrl_log("${num_deps} dependencies declared jrl_find_package: ")
    foreach(i RANGE 0 ${max_idx})
        string(JSON package_name GET "${deps}" "package_dependencies" ${i} "package_name")
        string(JSON package_targets GET "${deps}" "package_dependencies" ${i} "package_targets")

        # Replace ; by , for better readability
        string(REPLACE ";" ", " package_targets_pp "${package_targets}")
        math(EXPR i "${i} + 1")
        _jrl_log("${i}/${num_deps} Package [${package_name}] imported targets [${package_targets_pp}]")

        # Print target properties
        if(package_targets STREQUAL "")
            continue()
        endif()

        set(properties_to_print
            NAME
            ALIASED_TARGET
            TYPE VERSION
            LOCATION
            INCLUDE_DIRECTORIES
            COMPILE_DEFINITIONS
            COMPILE_OPTIONS
            COMPILE_FEATURES
            COMPILE_FLAGS
            COMPILE_OPTIONS
            LINK_LIBRARIES
            LINK_OPTIONS
            INTERFACE_INCLUDE_DIRECTORIES
            INTERFACE_COMPILE_DEFINITIONS
            INTERFACE_COMPILE_OPTIONS
            INTERFACE_LINK_LIBRARIES
            INTERFACE_LINK_OPTIONS
            CXX_STANDARD
            CXX_EXTENSIONS
            CXX_STANDARD_REQUIRED
        )

        foreach(target IN LISTS package_targets)
            _jrl_log("")
            _jrl_log("  Properties for target [${target}]:")

            get_property(target_is_imported TARGET ${target} PROPERTY IMPORTED)

            foreach(prop IN LISTS properties_to_print)
                # The LOCATION property cannot be read from non-imported targets
                # (CMP0026). This happens when a dependency is built in-tree
                # (FetchContent / add_subdirectory / workspace scenario)
                if(prop STREQUAL "LOCATION" AND NOT target_is_imported)
                    continue()
                endif()

                get_property(is_property_set TARGET ${target} PROPERTY "${prop}" SET)

                if(is_property_set)
                    get_property(property TARGET ${target} PROPERTY "${prop}")

                    # Convert paths containing \ to / (Windows)
                    if(WIN32)
                        cmake_path(CONVERT "${property}" TO_CMAKE_PATH_LIST property NORMALIZE)
                    endif()

                    _jrl_pad_string("${prop}"      40 prop_padded)
                    _jrl_log("    ${prop_padded} = ${property}")
                endif()
            endforeach()
            _jrl_log("")
        endforeach()
    endforeach()

    _jrl_log_get(log_msg)
    message(STATUS "${log_msg}")
endfunction()

#[============================================================================[
# `_jrl_export_dependencies`

```cpp
_jrl_export_dependencies(
    [COMPONENT <component_name>]
    TARGETS <target1...>
    [GEN_DIR <gen_dir>]
    [INSTALL_DESTINATION <destination>]
)
```

**Type:** function


### Description
  This function analyzes the link libraries of the provided targets,
  determines which packages are needed and generates a <export_name>-dependencies.cmake file.
  This is more or less a cmake 3.22-compatible implementation of the cmake 3.29 export(SETUP) with CMAKE_EXPERIMENTAL_EXPORT_PACKAGE_DEPENDENCIES.
  # ref: https://cmake.org/cmake/help/latest/command/export.html#setup


### Arguments
* `COMPONENT`: The export component name. Use to get the full list of targets
* `TARGETS`: List of targets to analyze.
* `GEN_DIR`: Directory to generate the file.
* `INSTALL_DESTINATION`: Directory to install the file.


### Example
```cmake
_jrl_export_dependencies(TARGETS my_target)
```
#]============================================================================]
function(_jrl_export_dependencies)
    set(options)
    set(oneValueArgs INSTALL_DESTINATION GEN_DIR COMPONENT)
    set(multiValueArgs TARGETS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(arg_TARGETS)

    if(arg_GEN_DIR)
        set(GEN_DIR ${arg_GEN_DIR})
    else()
        set(GEN_DIR ${CMAKE_CURRENT_BINARY_DIR}/generated/cmake/${PROJECT_NAME})
    endif()

    if(arg_INSTALL_DESTINATION)
        set(INSTALL_DESTINATION ${arg_INSTALL_DESTINATION})
    else()
        set(INSTALL_DESTINATION lib/cmake/${PROJECT_NAME})
    endif()

    # Gather the interface link libraries of all targets present in the export component.
    # It contains external libraries but also buildsystem target, with or without generator expressions.
    set(all_interface_link_libraries "")
    foreach(target ${arg_TARGETS})
        get_target_property(interface_link_libraries ${target} INTERFACE_LINK_LIBRARIES)

        if(NOT interface_link_libraries)
            message(DEBUG "Target '${target}' has no INTERFACE_LINK_LIBRARIES.")
            continue()
        endif()

        list(APPEND all_interface_link_libraries ${interface_link_libraries})
    endforeach()

    list(REMOVE_DUPLICATES all_interface_link_libraries)

    # Get the complete list of exported targets
    # This is used to filter out the INTERFACE_LINK_LIBRARIES that are actually part of the same package
    # (and should not be added as dependencies in the generated <export_name>-dependencies.cmake file)
    set(all_exported_targets "")
    foreach(component ${declared_components})
        get_property(targets GLOBAL PROPERTY _jrl_${PROJECT_NAME}_${component}_targets)
        list(APPEND all_exported_targets ${targets})
    endforeach()

    message(
        DEBUG
        "All interface link libraries for targets '${arg_TARGETS}': ${all_interface_link_libraries}"
    )

    # Get the list of external dependencies recorded with jrl_find_package() and jrl_export_dependency()
    get_property(
        package_dependencies_json_content
        GLOBAL
        PROPERTY _jrl_${PROJECT_NAME}_package_dependencies
    )

    if(NOT package_dependencies_json_content)
        message(DEBUG "No package dependencies recorded with jrl_find_package()")
    endif()

    file(
        GENERATE OUTPUT ${GEN_DIR}/imported-libraries.cmake
        CONTENT
            "
# Generated file - do not edit
set(component_name [[${arg_COMPONENT}]])
set(all_exported_targets [[${all_exported_targets}]])

# The targets declared via jrl_add_export_component(NAME ${arg_COMPONENT} TARGETS ${arg_TARGETS})
set(export_component_targets [[${arg_TARGETS}]])

# The resolved list of all interface link libraries the targets above, after generator expression evaluation.
set(all_interface_link_libraries [[${all_interface_link_libraries}]])

# The list of external dependencies recorded via jrl_find_package()
set(package_dependencies_json_content [[${package_dependencies_json_content}]])
"
    )
    # needs @INSTALL_DESTINATION@
    configure_file(
        ${_JRL_TEMPLATES_DIR}/generate-dependencies.cmake.in
        ${GEN_DIR}/generate-dependencies.cmake
        @ONLY
    )
    install(SCRIPT ${GEN_DIR}/generate-dependencies.cmake)
endfunction()

#[============================================================================[
# `jrl_add_export_component`

```cpp
jrl_add_export_component(
    NAME <component_name>
    TARGETS <target1> <target2> ...
)
```

**Type:** function


### Description
  Add an export component with associated targets that will be exported as a CMake package component.
  Each export component will have its own <package>-component-<name>-targets.cmake
  and <package>-component-<name>-dependencies.cmake generated.
  Components are used with: find_package(<package> CONFIG REQUIRED COMPONENTS <component1> <component2> ...)


### Arguments
* `NAME`: The name of the component.
* `TARGETS`: The targets to associate with this component.


### Example
```cmake
jrl_add_export_component(NAME my_component TARGETS my_target)
```
#]============================================================================]
function(jrl_add_export_component)
    set(options)
    set(oneValueArgs NAME)
    set(multiValueArgs TARGETS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(PROJECT_NAME)
    _jrl_check_var_defined(arg_TARGETS)
    _jrl_check_var_defined(arg_NAME)

    # Check export component is not already declared
    get_property(existing_components GLOBAL PROPERTY _jrl_${PROJECT_NAME}_export_components)
    if(${arg_NAME} IN_LIST existing_components)
        message(
            FATAL_ERROR
            "Export component '${arg_NAME}' is already declared for project '${PROJECT_NAME}'."
        )
    endif()

    # Check if target is already in an export component
    foreach(component ${existing_components})
        get_property(component_targets GLOBAL PROPERTY _jrl_${PROJECT_NAME}_${component}_targets)
        foreach(target ${arg_TARGETS})
            if(${target} IN_LIST component_targets)
                message(
                    FATAL_ERROR
                    "Target '${target}' is already part of export component '${component}'. Cannot add it to export component '${arg_NAME}'."
                )
            endif()
        endforeach()
    endforeach()

    message(
        STATUS
        "Adding export component '${arg_NAME}' with targets: ${arg_TARGETS} (export name: ${PROJECT_NAME}::${arg_NAME})
        It makes this component available via: find_package(${PROJECT_NAME} CONFIG REQUIRED COMPONENTS ${arg_NAME})
        "
    )

    set_property(GLOBAL PROPERTY _jrl_${PROJECT_NAME}_export_components ${arg_NAME} APPEND)
    set_property(GLOBAL PROPERTY _jrl_${PROJECT_NAME}_${arg_NAME}_targets ${arg_TARGETS})
endfunction()

#[============================================================================[
# `jrl_target_headers`

```cpp
jrl_target_headers(
    <target>
    <visibility>
    HEADERS <list_of_headers>
    [BASE_DIRS <list_of_base_dirs>]
)
```

**Type:** function


### Description
  Declare headers for target to be installed later.
  * This function does not target_include_directories(), only stores them for installation.
  * Only PUBLIC and INTERFACE will be installed.
  * Each call is recorded as an object in the _jrl_install_headers_json target property, replayed by jrl_target_install_headers().
  * In CMake 3.23, we will use FILE_SETS instead of this trick.
  cf: https://cmake.org/cmake/help/latest/command/target_sources.html#file-sets


### Arguments
* `target`: The target.
* `visibility`: Visibility scope (usually PUBLIC or INTERFACE).
* `HEADERS`: List of headers.
* `BASE_DIRS`: List of base dirs (Optional, default is empty).


### Example
```cmake
jrl_target_headers(my_target PUBLIC HEADERS my_header.hpp)
```
#]============================================================================]
function(jrl_target_headers target visibility)
    set(options)
    set(oneValueArgs)
    set(multiValueArgs HEADERS BASE_DIRS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(arg_HEADERS)
    _jrl_check_target_exists(${target})
    _jrl_check_valid_visibility(${visibility})

    # Save the headers in a property of the target
    # NOTE: The PUBLIC_HEADER technically works, but does not support base_dirs
    # cf: https://cmake.org/cmake/help/latest/command/install.html#install
    # Only PUBLIC and INTERFACE headers are installed; skip PRIVATE headers.
    if(visibility STREQUAL "PRIVATE")
        message(
            AUTHOR_WARNING
            "Headers declared for target '${target}' with PRIVATE visibility will not be installed.
            Only PUBLIC and INTERFACE headers are installed.
            If you want to install these headers, change the visibility to PUBLIC or INTERFACE."
        )
        return()
    endif()
    # Record this call as an object in a JSON array on the target so each header keeps its own source dir and base dirs.
    get_target_property(headers_json ${target} _jrl_install_headers_json)
    if(NOT headers_json)
        string(JSON headers_json SET "{}" "records" "[]")
    endif()

    # Save the information about this call in a json object.
    set(record "{}")
    string(JSON record SET "${record}" "source_dir" "\"${CMAKE_CURRENT_SOURCE_DIR}\"")
    string(JSON record SET "${record}" "headers" "\"${arg_HEADERS}\"")
    string(JSON record SET "${record}" "base_dirs" "\"${arg_BASE_DIRS}\"")

    # Append the record to the "records" array.
    string(JSON records_length LENGTH "${headers_json}" "records")
    string(JSON headers_json SET "${headers_json}" "records" ${records_length} "${record}")

    set_property(TARGET ${target} PROPERTY _jrl_install_headers_json "${headers_json}")
endfunction()

#[============================================================================[
# `jrl_target_install_headers`

```cpp
jrl_target_install_headers(
    <target>
    [DESTINATION <destination>]
)
```

**Type:** function


### Description
  Install declared header for a given target and solve the relative path using the provided base dirs.
  It replays the per-call records stored as a JSON array in the _jrl_install_headers_json property set via jrl_target_headers().
  For a whole project, use jrl_install_headers() instead (which calls this function for each component, that contains targets).
  NOTE: this is done automatically in jrl_export_package() for all exported targets.


### Arguments
* `target`: The target.
* `DESTINATION`: Install destination (Optional, default is CMAKE_INSTALL_INCLUDEDIR).


### Example
```cmake
jrl_target_install_headers(my_target)
```
#]============================================================================]
function(jrl_target_install_headers target)
    set(options)
    set(oneValueArgs DESTINATION)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_target_exists(${target})

    if(arg_DESTINATION)
        set(install_destination ${arg_DESTINATION})
    else()
        _jrl_check_var_defined(CMAKE_INSTALL_INCLUDEDIR)
        set(install_destination ${CMAKE_INSTALL_INCLUDEDIR})
    endif()

    get_target_property(headers_json ${target} _jrl_install_headers_json)

    if(NOT headers_json)
        message(DEBUG "No headers declared for target '${target}'. Skipping installation.")
        return()
    endif()

    # Replay each recorded call as its own install block (see jrl_target_headers).
    string(JSON num_records LENGTH "${headers_json}" "records")
    math(EXPR max_idx "${num_records} - 1")
    foreach(record_index RANGE 0 ${max_idx})
        string(JSON current_source_dir GET "${headers_json}" "records" ${record_index} "source_dir")
        string(JSON headers GET "${headers_json}" "records" ${record_index} "headers")
        string(JSON base_dirs GET "${headers_json}" "records" ${record_index} "base_dirs")

        install(
            CODE
                "
# Generated file - do not edit
# Headers declared for target '${target}' (record ${record_index})
set(headers \"${headers}\")
set(base_dirs \"${base_dirs}\")
foreach(header \${headers})
    set(relative_header_path \"\")
    set(header_dir \"\")
    foreach(base_dir \${base_dirs})
        string(FIND \${header} \${base_dir} pos)
        if(pos EQUAL 0)
            string(REPLACE \${base_dir} \"\" relative_header_path \${header})
            string(REGEX REPLACE \"^/\" \"\" relative_header_path \${relative_header_path})
            break()
        endif()
    endforeach()

    if(IS_ABSOLUTE \${header})
        set(header_path \${header})
    else()
        set(header_path ${current_source_dir}/\${header})
    endif()

    if(relative_header_path)
        cmake_path(GET relative_header_path PARENT_PATH header_dir)
    endif()

    if(IS_ABSOLUTE ${install_destination})
        if(header_dir)
            file(INSTALL DESTINATION \"${install_destination}/\${header_dir}\" TYPE FILE FILES \${header_path})
        else()
            file(INSTALL DESTINATION \"${install_destination}\" TYPE FILE FILES \${header_path})
        endif()
    else()
        if(header_dir)
            file(INSTALL DESTINATION \"\${CMAKE_INSTALL_PREFIX}/${install_destination}/\${header_dir}\" TYPE FILE FILES \${header_path})
        else()
            file(INSTALL DESTINATION \"\${CMAKE_INSTALL_PREFIX}/${install_destination}\" TYPE FILE FILES \${header_path})
        endif()
    endif()
endforeach()
"
        )
    endforeach()
endfunction()

#[============================================================================[
# `jrl_install_headers`

```cpp
jrl_install_headers(
    [DESTINATION <destination>]
    [COMPONENTS <component1> <component2> ...]
)
```

**Type:** function


### Description
  For each component, install declared headers for all targets.
  See jrl_target_headers() to declare headers for a target.


### Arguments
* `DESTINATION`: Install destination (Optional, default is CMAKE_INSTALL_INCLUDEDIR).
* `COMPONENTS`: List of components (Optional, default is all declared components).


### Example
```cmake
jrl_install_headers()
```
#]============================================================================]
function(jrl_install_headers)
    set(options)
    set(oneValueArgs DESTINATION)
    set(multiValueArgs COMPONENTS)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(PROJECT_NAME)

    if(NOT arg_DESTINATION)
        set(install_destination ${CMAKE_INSTALL_INCLUDEDIR})
    else()
        set(install_destination ${arg_DESTINATION})
    endif()

    get_property(declared_components GLOBAL PROPERTY _jrl_${PROJECT_NAME}_export_components)

    set(components "")
    if(arg_COMPONENTS)
        set(components ${arg_COMPONENTS})
    else()
        if(NOT declared_components)
            message(
                FATAL_ERROR
                "No export components declared for project '${PROJECT_NAME}'. Cannot install headers. Use jrl_add_export_component() first."
            )
        endif()
        set(components ${declared_components})
        message(
            STATUS
            "Installing headers for all declared components. Declared components: [${declared_components}]"
        )
    endif()

    foreach(component ${components})
        if(NOT component IN_LIST declared_components)
            message(
                FATAL_ERROR
                "Component '${component}' is not declared for project '${PROJECT_NAME}'."
            )
        endif()

        get_property(targets GLOBAL PROPERTY _jrl_${PROJECT_NAME}_${component}_targets)
        if(NOT targets)
            message(WARNING "No targets found for component '${component}'. Skipping.")
            continue()
        endif()

        foreach(target ${targets})
            message(
                STATUS
                "Installing headers for target '${target}' of component '${component}' to '${install_destination}'"
            )
            jrl_target_install_headers(${target} DESTINATION ${install_destination})
        endforeach()
    endforeach()
endfunction()

#[============================================================================[
# `jrl_export_package`

```cpp
jrl_export_package(
    [PACKAGE_CONFIG_TEMPLATE <template>]
    [CMAKE_FILES_INSTALL_DIR <dir>]
    [PACKAGE_CONFIG_EXTRA_CONTENT <content>]
)
```

**Type:** function


### Description
  Export the CMake package with all its components (targets, headers, package modules, etc.)
  Generates and installs CMake package configuration files:
   - <INSTALL_DIR>/<package>/<package>Config.cmake
   - <INSTALL_DIR>/<package>/<package>ConfigVersion.cmake
   - <INSTALL_DIR>/<package>/<package>/<componentA>/targets.cmake
   - <INSTALL_DIR>/<package>/<package>/<componentA>/dependencies.cmake
   - <INSTALL_DIR>/<package>/<package>/<componentB>/targets.cmake
   - <INSTALL_DIR>/<package>/<package>/<componentB>/dependencies.cmake
  This is for c++ package export only. Python bindings should be handled separately.

  This function allows users to set the variable `<PACKAGE_NAME>_EXPORT_PACKAGE` to OFF to disable package export.
  The priority is as follows:
    1. Check if the environment variable is set
    2. Check if the CMake variable is set (can be a jrl_option() or a regular set())


### Arguments
* `PACKAGE_CONFIG_TEMPLATE`: Custom template for the config file.
* `CMAKE_FILES_INSTALL_DIR`: Directory to install the cmake files.
* `PACKAGE_CONFIG_EXTRA_CONTENT`: Extra content to append to the config file.


### Example
```cmake
jrl_export_package()
```
#]============================================================================]
function(jrl_export_package)
    set(options)
    set(oneValueArgs PACKAGE_CONFIG_TEMPLATE CMAKE_FILES_INSTALL_DIR PACKAGE_CONFIG_EXTRA_CONTENT)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    string(MAKE_C_IDENTIFIER ${PROJECT_NAME} project_name_identifier)
    string(TOUPPER ${project_name_identifier} project_name_identifier_upper)
    set(option_var_name "${project_name_identifier_upper}_EXPORT_PACKAGE")

    # 1. Check if the environment variable is set
    # 2. Check if the variable is set

    if(DEFINED ENV{${option_var_name}})
        set(execute_export_package $ENV{${option_var_name}})
        set(env "environment ")
    elseif(DEFINED ${option_var_name})
        set(execute_export_package ${${option_var_name}})
        set(env "")
    else()
        set(execute_export_package ON)
    endif()

    if(NOT ${execute_export_package})
        message(
            STATUS
            "(${CMAKE_CURRENT_FUNCTION}) Skipping package export because ${env}variable ${option_var_name} is set to OFF"
        )
        return()
    endif()

    message(
        STATUS
        "[${PROJECT_NAME}] Exporting package (${CMAKE_CURRENT_FUNCTION}).
        You can disable this step by setting the option ${option_var_name} to OFF.
    "
    )

    include(CMakePackageConfigHelpers)
    _jrl_check_var_defined(PROJECT_NAME)
    _jrl_check_var_defined(PROJECT_VERSION)
    _jrl_check_var_defined(CMAKE_INSTALL_BINDIR
        "CMAKE_INSTALL_BINDIR is not defined.
        Use jrl_configure_defaults(), or jrl_configure_default_install_dirs(), or include(GNUInstallDirs)."
    )
    _jrl_check_var_defined(CMAKE_INSTALL_INCLUDEDIR)

    if(arg_PACKAGE_CONFIG_TEMPLATE)
        set(package_config_template ${arg_PACKAGE_CONFIG_TEMPLATE})
    else()
        set(package_config_template ${_JRL_TEMPLATES_DIR}/config-components.cmake.in)
        set(using_default_template True)
    endif()

    if(arg_CMAKE_FILES_INSTALL_DIR)
        set(cmake_files_install_dir ${arg_CMAKE_FILES_INSTALL_DIR})
    else()
        set(cmake_files_install_dir lib/cmake/${PROJECT_NAME})
    endif()

    # NOTE: Expose as options if needed
    set(GEN_DIR ${CMAKE_CURRENT_BINARY_DIR}/generated/cmake/${PROJECT_NAME})
    set(PACKAGE_NAME ${PROJECT_NAME})
    set(PACKAGE_NAMESPACE "${PACKAGE_NAME}::")
    set(PACKAGE_CONFIG_FILENAME ${PACKAGE_NAME}Config.cmake)
    set(PACKAGE_VERSION ${PROJECT_VERSION})
    set(PACKAGE_VERSION_FILENAME ${PACKAGE_NAME}ConfigVersion.cmake) # Note: This needs to be config-version.cmake or ConfigVersion.cmake to work.
    set(PACKAGE_VERSION_COMPATIBILITY AnyNewerVersion)
    set(PACKAGE_VERSION_ARCH_INDEPENDENT "")
    set(NO_SET_AND_CHECK_MACRO "NO_SET_AND_CHECK_MACRO")
    set(NO_CHECK_REQUIRED_COMPONENTS_MACRO "NO_CHECK_REQUIRED_COMPONENTS_MACRO")

    # Dump package dependencies recorded with jrl_find_package()
    jrl_dump_package_dependencies_json(${GEN_DIR}/${PROJECT_NAME}-package-dependencies.json)

    # Get declared export components
    get_property(declared_components GLOBAL PROPERTY _jrl_${PROJECT_NAME}_export_components)
    if(using_default_template AND NOT declared_components)
        message(
            FATAL_ERROR
            "No export component declared for project '${PROJECT_NAME}'.
        The default config-components.cmake.in template requires at least one export component.
        Either add export-components via:
            jrl_add_export_component(NAME <comp_name> TARGETS [target1...])
        Or provide your own config template:
            jrl_export_package(PACKAGE_CONFIG_TEMPLATE <config-template.cmake.in>)
        "
        )
    endif()

    # <package>Config.cmake
    set(JRL_PACKAGE_CONFIG_EXTRA_CONTENT ${arg_PACKAGE_CONFIG_EXTRA_CONTENT})
    set(JRL_PROJECT_COMPONENTS ${declared_components})
    configure_package_config_file(
        ${package_config_template}
        ${GEN_DIR}/${PACKAGE_CONFIG_FILENAME}
        INSTALL_DESTINATION ${cmake_files_install_dir}
        ${NO_SET_AND_CHECK_MACRO}
        ${NO_CHECK_REQUIRED_COMPONENTS_MACRO}
    )
    install(FILES ${GEN_DIR}/${PACKAGE_CONFIG_FILENAME} DESTINATION ${cmake_files_install_dir})

    # <package>ConfigVersion.cmake
    write_basic_package_version_file(
        ${GEN_DIR}/${PACKAGE_VERSION_FILENAME}
        VERSION ${PACKAGE_VERSION}
        COMPATIBILITY ${PACKAGE_VERSION_COMPATIBILITY}
        ${PACKAGE_VERSION_ARCH_INDEPENDENT}
    )
    install(FILES ${GEN_DIR}/${PACKAGE_VERSION_FILENAME} DESTINATION ${cmake_files_install_dir})

    foreach(component ${declared_components})
        message(STATUS "Generating cmake module files for component '${component}'")

        get_property(targets GLOBAL PROPERTY _jrl_${PROJECT_NAME}_${component}_targets)

        foreach(target ${targets})
            message(
                STATUS
                "Installing headers for target '${target}' of component '${component}' to '${CMAKE_INSTALL_INCLUDEDIR}'"
            )
            jrl_target_install_headers(${target} DESTINATION ${CMAKE_INSTALL_INCLUDEDIR})
        endforeach()

        # <package>/<component>/dependencies.cmake
        _jrl_export_dependencies(
            COMPONENT ${component}
            TARGETS ${targets}
            GEN_DIR ${GEN_DIR}/${component}
            INSTALL_DESTINATION ${cmake_files_install_dir}/${component}
        )
        # Create the export for the component targets
        # AND the install rules for the targets (see jrl_add_export_component() comment)
        install(
            TARGETS ${targets}
            EXPORT ${PROJECT_NAME}-${component}
            RUNTIME DESTINATION ${CMAKE_INSTALL_BINDIR}
            LIBRARY DESTINATION ${CMAKE_INSTALL_LIBDIR}
            ARCHIVE DESTINATION ${CMAKE_INSTALL_LIBDIR}
        )
        # <package>/<component>/targets.cmake
        install(
            EXPORT ${PROJECT_NAME}-${component}
            FILE targets.cmake
            NAMESPACE ${PACKAGE_NAMESPACE}
            DESTINATION ${cmake_files_install_dir}/${component}
        )
    endforeach()
endfunction()

#[============================================================================[
# `jrl_dump_package_dependencies_json`

```cpp
jrl_dump_package_dependencies_json(<output>)
```

**Type:** function


### Description
  Internal function to dump the package dependencies recorded with jrl_find_package()
  It is called at the end of the configuration step via cmake_language(DEFER CALL ...)
  In the function jrl_export_package().


### Arguments
* `output`: The output file path.


### Example
```cmake
jrl_dump_package_dependencies_json(my_deps.json)
```
#]============================================================================]
function(jrl_dump_package_dependencies_json output)
    get_property(
        package_dependencies_json
        GLOBAL
        PROPERTY _jrl_${PROJECT_NAME}_package_dependencies
    )
    if(NOT package_dependencies_json)
        message(STATUS "No package dependencies recorded with jrl_find_package()")
        return()
    endif()
    message(STATUS "[${PROJECT_NAME}] Dumping package dependencies JSON to ${output}")
    file(WRITE ${output} "${package_dependencies_json}")
endfunction()

#[============================================================================[
# `jrl_legacy_option`

```cpp
jrl_legacy_option(
    NEW_OPTION <new_option_name>
    OLD_OPTION <old_option_name>
)
```

**Type:** function


### Description
  Migrate a legacy option value to a new option name and emit a deprecation warning.
  If the old option is defined, its value is migrated to the new option.
  The NEW_OPTION must already exist in the cache (created via jrl_option or option()).
  The help text is automatically retrieved from the NEW_OPTION cache property.


### Arguments
* `NEW_OPTION`: The current/new option name (must already exist in cache).
* `OLD_OPTION`: The deprecated/old option name to migrate from.


### Example
```cmake
jrl_legacy_option(
    NEW_OPTION BUILD_PYTHON
    OLD_OPTION BUILD_PYTHON_BINDINGS
)
```
#]============================================================================]
function(jrl_legacy_option)
    set(options)
    set(oneValueArgs NEW_OPTION OLD_OPTION)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    # Validate required arguments
    _jrl_check_var_defined(arg_NEW_OPTION)
    _jrl_check_var_defined(arg_OLD_OPTION)

    # Check that NEW_OPTION exists in cache
    get_property(cache_exists CACHE ${arg_NEW_OPTION} PROPERTY VALUE SET)
    if(NOT cache_exists)
        message(
            FATAL_ERROR
            "jrl_legacy_option: NEW_OPTION '${arg_NEW_OPTION}' does not exist in cache. "
            "The option must be created first (via jrl_option or option()) before calling jrl_legacy_option."
        )
    endif()

    # Get help text from cache property
    get_property(help_text CACHE ${arg_NEW_OPTION} PROPERTY HELPSTRING)
    if(NOT help_text)
        set(help_text "Option ${arg_NEW_OPTION}")
    endif()

    # Check if old option is defined
    if(DEFINED ${arg_OLD_OPTION})
        message(
            DEBUG
            "jrl_legacy_option: Found legacy variable '${arg_OLD_OPTION}' set to '${${arg_OLD_OPTION}}'"
        )
        message(
            DEPRECATION
            "Option '${arg_OLD_OPTION}' is deprecated. Please use '${arg_NEW_OPTION}' instead."
        )

        # Override NEW_OPTION with legacy value
        message(DEBUG "jrl_legacy_option: Migrating legacy value to '${arg_NEW_OPTION}'")
        set(${arg_NEW_OPTION} "${${arg_OLD_OPTION}}" CACHE BOOL "${help_text}" FORCE)
    endif()
endfunction()

#[============================================================================[
# `jrl_option`

```cpp
jrl_option(
    <name>
    <help_text>
    <default_value>
    [CONDITION <cmake_condition> [FALLBACK <fallback_value>]]
    [LEGACY_NAME <legacy_name>]
)
```

**Type:** function


### Description
  Declare a cache BOOL option with optional conditional availability and legacy name migration.
  When `CONDITION` evaluates to false, the option is forced to the `FALLBACK` value (default OFF) with FORCE and hidden.
  When `LEGACY_NAME` is set, its value is migrated to `<name>` and a deprecation
  warning is emitted.


### Arguments
* `name`: The option name.
* `help_text`: The cache entry help string.
* `default_value`: The default value (ON/OFF).
* `CONDITION`: CMake condition string to evaluate (optional). If false, the option will be forced to FALLBACK value.
* `FALLBACK`: Value to force when CONDITION is false (optional).
* `LEGACY_NAME`: Deprecated option name to migrate (optional).


### Example
```cmake
jrl_option(BUILD_TESTS "Build unit tests" ON)
jrl_option(
    BUILD_PYTHON
    "Build Python bindings"
    ON
    CONDITION "BUILD_SHARED_LIBS AND Python_FOUND"
    FALLBACK OFF
    LEGACY_NAME BUILD_PYTHON_BINDINGS
)
```
#]============================================================================]
function(jrl_option option_name help_text default_value)
    set(options)
    set(oneValueArgs CONDITION FALLBACK LEGACY_NAME)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    message(
        DEBUG
        "[${PROJECT_NAME}::jrl_option] Configuring option '${option_name}' (default: ${default_value})"
    )

    if(DEFINED arg_CONDITION)
        message(DEBUG "    Option has condition: ${arg_CONDITION}")
        _jrl_check_var_defined(arg_FALLBACK "FALLBACK argument must be provided when CONDITION is used.")
    endif()

    if(DEFINED arg_FALLBACK)
        set(fallback_value ${arg_FALLBACK})
        message(DEBUG "    Fallback value when condition is false: ${fallback_value}")
    endif()

    # Evaluate condition
    set(enable_option ON)
    if(arg_CONDITION)
        message(DEBUG "    Evaluating condition: ${arg_CONDITION}")

        # Evaluate the string condition
        cmake_language(
            EVAL CODE
                "
            if(${arg_CONDITION})
                set(enable_option ON)
            else()
                set(enable_option OFF)
            endif()
        "
        )

        if(enable_option)
            message(DEBUG "    Condition passed")
        else()
            message(
                DEBUG
                "    Condition failed, option will be set to fallback value '${fallback_value}' (hidden)"
            )
        endif()
    endif()

    # Set the option
    if(enable_option)
        if(DEFINED CACHE{${option_name}})
            message(DEBUG "    Option '${option_name}' already set to '${${option_name}}'")
            # Get the type and force it to be initialized. Right now, only BOOL options are supported, but this can be extended in the future if needed.
            get_property(type CACHE ${option_name} PROPERTY TYPE)
            if(type STREQUAL "UNINITIALIZED")
                message(
                    DEBUG
                    "    Option '${option_name}' is UNINITIALIZED, setting default value to BOOL:'${default_value}'"
                )
                set(${option_name} "${default_value}" CACHE BOOL "${help_text}")
            endif()
        else()
            message(DEBUG "    Setting option '${option_name}' to '${default_value}'")
            set(${option_name} "${default_value}" CACHE BOOL "${help_text}")
        endif()
    else()
        message(
            DEBUG
            "    Forcing option '${option_name}' to fallback value '${fallback_value}' (hidden)"
        )
        set(${option_name} "${fallback_value}" CACHE BOOL "${help_text}" FORCE)
        mark_as_advanced(${option_name})
    endif()

    # Handle legacy name (after option is created)
    if(arg_LEGACY_NAME)
        message(DEBUG "    Handling legacy option name '${arg_LEGACY_NAME}' for '${option_name}'")
        jrl_legacy_option(
            NEW_OPTION ${option_name}
            OLD_OPTION ${arg_LEGACY_NAME}
        )
    endif()

    set_property(
        GLOBAL
        PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_default_value ${default_value}
    )
    if(DEFINED arg_CONDITION)
        set_property(
            GLOBAL
            PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_condition "${arg_CONDITION}"
        )
    endif()
    if(DEFINED arg_LEGACY_NAME)
        set_property(
            GLOBAL
            PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_legacy_option "${arg_LEGACY_NAME}"
        )
    endif()
    set_property(GLOBAL PROPERTY _jrl_${PROJECT_NAME}_option_names ${option_name} APPEND)
endfunction()

#[============================================================================[
# `jrl_generate_options_markdown_summary`

```cpp
jrl_generate_options_markdown_summary(OUTPUT_FILE <output_file>)
```

**Type:** function


### Description
  Write a Markdown file summarising all options declared via `jrl_option()` for the current project.
  This helps maintaining an up-to-date documentation of the available options.
  The table contains the following columns:
  *Option*, *Type*, *Default value*, *Condition*, *Legacy Name*, *Description*.


### Arguments
* `OUTPUT_FILE`: Path of the Markdown file to generate (default: ${CMAKE_BINARY_DIR}/${PROJECT_NAME}_options.md).


### Example
```cmake
jrl_generate_options_markdown_summary(OUTPUT_FILE ${CMAKE_BINARY_DIR}/OPTIONS.md)
```
#]============================================================================]
function(jrl_generate_options_markdown_summary)
    set(options)
    set(oneValueArgs OUTPUT_FILE)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    if(arg_OUTPUT_FILE)
        set(output_file ${arg_OUTPUT_FILE})
    else()
        set(output_file "${CMAKE_BINARY_DIR}/${PROJECT_NAME}_options.md")
    endif()

    get_property(option_names GLOBAL PROPERTY _jrl_${PROJECT_NAME}_option_names)

    set(md "# ${PROJECT_NAME} - Declared Options\n\n")

    if(NOT option_names)
        string(APPEND md "_No options defined via `jrl_option`._\n")
        file(WRITE "${output_file}" "${md}")
        message(STATUS "[${PROJECT_NAME}] Options markdown summary written to: ${output_file}")
        return()
    endif()

    string(APPEND md "| Option | Type | Default value | Condition | Legacy Name | Description |\n")
    string(APPEND md "| ------ | ---- | ------------- | --------- | ----------- | ----------- |\n")

    foreach(option_name ${option_names})
        get_property(_type CACHE ${option_name} PROPERTY TYPE)
        get_property(_help CACHE ${option_name} PROPERTY HELPSTRING)
        get_property(
            _default
            GLOBAL
            PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_default_value
        )
        get_property(_cond GLOBAL PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_condition)
        get_property(
            _legacy
            GLOBAL
            PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_legacy_option
        )

        if(_cond)
            set(_cond_md "`${_cond}`")
        else()
            set(_cond_md "")
        endif()

        if(_legacy)
            set(_legacy_md "`${_legacy}`")
        else()
            set(_legacy_md "")
        endif()

        # Escape pipe characters that would break the Markdown table
        string(REPLACE "|" "\\|" _help "${_help}")
        string(REPLACE "|" "\\|" _cond_md "${_cond_md}")

        string(
            APPEND md
            "| `${option_name}` | `${_type}` | `${_default}` | ${_cond_md} | ${_legacy_md} | ${_help} |\n"
        )
    endforeach()

    # Check if the content of the file is different before writing to avoid unnecessary rewrites
    if(EXISTS "${output_file}")
        file(READ "${output_file}" existing_content)
        if(existing_content STREQUAL md)
            message(
                STATUS
                "[${PROJECT_NAME}] Options markdown summary is up-to-date: ${output_file}"
            )
            return()
        endif()
    endif()

    file(WRITE "${output_file}" "${md}")
    message(STATUS "[${PROJECT_NAME}] Options markdown summary written to: ${output_file}")
endfunction()

#[============================================================================[
# `_jrl_pad_string`

```cpp
_jrl_pad_string(
    <input>
    <width>
    <output_var>
)
```

**Type:** function


### Description
  Helper function: pad or truncate a string to a fixed width.


### Arguments
* `input`: The input string.
* `width`: The target width.
* `output_var`: The variable to store the result.


### Example
```cmake
_jrl_pad_string("foo" 10 padded_foo)
```
#]============================================================================]
function(_jrl_pad_string input width output_var)
    string(LENGTH "${input}" _len)
    if(_len GREATER width)
        # Truncate if too long
        string(SUBSTRING "${input}" 0 ${width} _padded)
    else()
        # Pad with spaces until desired width
        math(EXPR _pad "${width} - ${_len}")
        set(_spaces "")
        while(_pad GREATER 0)
            string(APPEND _spaces " ")
            math(EXPR _pad "${_pad} - 1")
        endwhile()
        set(_padded "${input}${_spaces}")
    endif()
    set(${output_var} "${_padded}" PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_print_options_summary`

```cpp
jrl_print_options_summary()
```

**Type:** function


### Description
  Print all options defined via jrl_option() in a nice table.


### Arguments
  None


### Example
```cmake
jrl_print_options_summary()
```
#]============================================================================]
function(jrl_print_options_summary)
    _jrl_log_clear()

    get_property(option_names GLOBAL PROPERTY _jrl_${PROJECT_NAME}_option_names)
    if(NOT option_names)
        message(STATUS "No options defined via jrl_option.")
        return()
    endif()

    _jrl_log("")
    _jrl_log("================= Configuration Summary ==========================================================")
    _jrl_log("")

    _jrl_pad_string("Option"      40 _menu_option)
    _jrl_pad_string("Type"        8  _menu_type)
    _jrl_pad_string("Value"       5  _menu_value)
    _jrl_pad_string("Default"     5  _menu_default)
    _jrl_pad_string("Description (default)" 25 _menu_description)
    _jrl_log("${_menu_option} | ${_menu_type} | ${_menu_value} | ${_menu_description}")
    _jrl_log("--------------------------------------------------------------------------------------------------")

    foreach(option_name ${option_names})
        get_property(_type CACHE ${option_name} PROPERTY TYPE)
        get_property(_val CACHE ${option_name} PROPERTY VALUE)
        get_property(
            _default
            GLOBAL
            PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_default_value
        )
        get_property(_help CACHE ${option_name} PROPERTY HELPSTRING)
        get_property(
            _legacy_option
            GLOBAL
            PROPERTY _jrl_${PROJECT_NAME}_option_${option_name}_legacy_option
        )

        _jrl_pad_string("${option_name}"      40 _name)
        _jrl_pad_string("${_type}"     8 _type)
        _jrl_pad_string("${_val}"      5 _val)
        _jrl_pad_string("${_help}"     30 _help)
        _jrl_pad_string("${_default}"  3 _default)

        _jrl_log("${_name} | ${_type} | ${_val} | ${_help} (${_default})")
        if(_legacy_option)
            _jrl_log("  (Legacy option: ${_legacy_option})")
        endif()
    endforeach()

    _jrl_log("--------------------------------------------------------------------------------------------------")
    _jrl_log("")

    _jrl_log_get(log_msgs)
    message(STATUS "${log_msgs}")
endfunction()

#[============================================================================[
# `jrl_python_get_interpreter`

```cpp
jrl_python_get_interpreter(<output_var>)
```

**Type:** function


### Description
  Get the python interpreter path from the Python::Interpreter target.


### Arguments
* `output_var`: The variable to store the path.


### Example
```cmake
jrl_python_get_interpreter(python_interpreter)
execute_process(COMMAND ${python_interpreter} -c "print('Hello from Python!')")
```
#]============================================================================]
function(jrl_python_get_interpreter output_var)
    _jrl_check_target_exists(Python::Interpreter
        "
        Python::Interpreter target not found.
        Call (jrl_)find_package(Python REQUIRED COMPONENTS Interpreter) first.
    "
    )
    get_target_property(python_interpreter Python::Interpreter LOCATION)
    if(WIN32)
        cmake_path(CONVERT "${python_interpreter}" TO_CMAKE_PATH_LIST python_interpreter NORMALIZE)
    endif()
    set(${output_var} ${python_interpreter} PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_find_python`

```cpp
jrl_find_python(
    [version]
    [REQUIRED]
    [COMPONENTS ...]
)
```

**Type:** macro


### Description
  Shortcut to find Python package and check main variables.


### Arguments
* `version`: Python version.
* `REQUIRED`: If set, the package is required.
* `COMPONENTS`: List of components.


### Example
```cmake
jrl_find_python(3.10 REQUIRED COMPONENTS Interpreter Development.Module)
```
#]============================================================================]
macro(jrl_find_python)
    jrl_find_package(Python ${ARGN})

    # On Windows, Python_SITELIB returns \. Let's convert it to /.
    cmake_path(CONVERT "${Python_SITELIB}" TO_CMAKE_PATH_LIST Python_SITELIB NORMALIZE)

    if(TARGET Python::Interpreter)
        jrl_python_get_interpreter(python_interpreter)
        set(python_interpreter_found true)
    else()
        set(python_interpreter_found false)
    endif()

    message(STATUS "   Python::Interpreter      : ${python_interpreter_found}")
    message(STATUS "     LOCATION               : ${python_interpreter}")
    message(STATUS "   Python_FOUND             : ${Python_FOUND}")
    message(STATUS "   Python_EXECUTABLE        : ${Python_EXECUTABLE}")
    message(STATUS "   Python_VERSION           : ${Python_VERSION}")
    message(STATUS "   Python_SITELIB           : ${Python_SITELIB}")
    message(STATUS "   Python_INCLUDE_DIRS      : ${Python_INCLUDE_DIRS}")
    message(STATUS "   Python_LIBRARIES         : ${Python_LIBRARIES}")
    message(STATUS "   Python_SOABI             : ${Python_SOABI}")
    message(STATUS "   Python_NumPy_FOUND       : ${Python_NumPy_FOUND}")
    message(STATUS "   Python_NumPy_VERSION     : ${Python_NumPy_VERSION}")
    message(STATUS "   Python_NumPy_INCLUDE_DIRS: ${Python_NumPy_INCLUDE_DIRS}")
endmacro()

#[============================================================================[
# `jrl_find_nanobind`

```cpp
jrl_find_nanobind([<args>...])
```

**Type:** macro


### Description
  Shortcut to find the nanobind package.
  It forwards all arguments to find_package(nanobind ...).
  Needs the python interpreter to be found first via jrl_find_python().


### Arguments
* `args`: Arguments forwarded to find_package(nanobind ...).


### Example
```cmake
jrl_find_python(3.10 REQUIRED COMPONENTS Interpreter Development.Module)
jrl_find_nanobind(2.5.0 CONFIG REQUIRED)
```
#]============================================================================]
macro(jrl_find_nanobind)
    jrl_python_get_interpreter(python)

    if("REQUIRED" IN_LIST ARGN)
        set(is_required True)
    endif()

    # Detect the installed nanobind package and import it into CMake
    # ref: https://nanobind.readthedocs.io/en/latest/building.html#finding-nanobind
    execute_process(
        COMMAND ${python} -m nanobind --cmake_dir
        OUTPUT_STRIP_TRAILING_WHITESPACE
        OUTPUT_VARIABLE nanobind_ROOT
        ERROR_VARIABLE nanobind_error
    )

    if(nanobind_error)
        unset(nanobind_ROOT)
    endif()

    if(NOT nanobind_ROOT AND is_required)
        message(
            SEND_ERROR
            "Failed to find nanobind package via 'python -m nanobind --cmake_dir': ${nanobind_error}"
        )
    endif()

    jrl_find_package(nanobind ${ARGN})

    if(nanobind_FOUND)
        if(nanobind_ROOT)
            message(STATUS "   Nanobind CMake Root: ${nanobind_ROOT}")
        endif()

        if(nanobind_DIR)
            # Installed via homebrew on macOS, brew install nanobind
            # This will give /opt/homebrew/share/nanobind/cmake
            message(STATUS "   Nanobind CMake dir: ${nanobind_DIR}")
        endif()
        # If you install nanobind with pip, it will include tsl-robin-map in <nanobind>/ext/robin_map
        # On macOS, brew install nanobind will not include tsl-robin-map, we need to install it via: brew install robin-map
        # Naturally, find_package(nanobind CONFIG REQUIRED) will succeed (nanobind_FOUND -> True), but the tsl-robin-map dependency will be missing, causing build errors.
        # So let's check if the headers are available, otherwise require tsl-robin-map explicitly.
        # UPDATE: fixed in https://github.com/Homebrew/homebrew-core/commit/bf0095fdd7e03bd3239afda4584951ee9305dc40
        # brew install nanobind now includes robin-map as a dependency.
        if(EXISTS "${nanobind_ROOT}/../ext/robin_map/include/tsl/robin_map.h")
            message(
                STATUS
                "   Nanobind's tsl-robin-map dependency found in '${nanobind_ROOT}/ext/robin_map'."
            )
        else()
            jrl_find_package(tsl-robin-map CONFIG REQUIRED)
        endif()
    endif()
endmacro()

#[============================================================================[
# `jrl_python_compile_all`

```cpp
jrl_python_compile_all(
    DIRECTORY <directory>
    [VERBOSE]
)
```

**Type:** function


### Description
  Compiles all the python files recursively in a given directory, via the compileall module.
  It creates the corresponding .pyc files in __pycache__ folders.


### Arguments
* `DIRECTORY`: The directory to compile.
* `VERBOSE`: If set, print more info.


### Example
```cmake
jrl_python_compile_all(DIRECTORY ${CMAKE_CURRENT_SOURCE_DIR}/my_python_package)
```
#]============================================================================]
function(jrl_python_compile_all)
    set(options VERBOSE)
    set(oneValueArgs DIRECTORY)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(arg_DIRECTORY)
    jrl_python_get_interpreter(python)

    if(arg_VERBOSE)
        message(STATUS "Compiling all Python files in directory '${arg_DIRECTORY}'")
        set(quiet_flag "")
    else()
        # Do not print the list of files compiled. If passed once, error messages will still be printed.
        # If passed twice (-qq), all output is suppressed.
        set(quiet_flag "-q")
    endif()

    set(cmd "${python} -m compileall ${arg_DIRECTORY} -j 0 ${quiet_flag}")

    if(arg_VERBOSE)
        message(DEBUG "Running command: '${cmd}'")
    endif()

    execute_process(
        COMMAND ${cmd}
        RESULT_VARIABLE result
        ERROR_VARIABLE error
        OUTPUT_STRIP_TRAILING_WHITESPACE
        WORKING_DIRECTORY ${arg_DIRECTORY}
    )

    if(error)
        message(
            FATAL_ERROR
            "Failed to compile Python files in directory '${arg_DIRECTORY}': ${error}"
        )
    endif()

    if(arg_VERBOSE)
        message(STATUS "Compiling all Python files in directory '${arg_DIRECTORY}'... OK.")
    endif()
endfunction()

#[============================================================================[
# `jrl_python_generate_init_py`

```cpp
jrl_python_generate_init_py(
    <module_target_name>
    OUTPUT_PATH <output_path>
    [TEMPLATE_FILE <template_file>]
)
```

**Type:** function


### Description
  Generates a __init__.py file for a given python module target.
  It computes all the relative paths to dlls it needs to add to os.add_dll_directory based on the target's LINK_LIBRARIES.
  The generated __init__.py will call the os.add_dll_directory(<relative_path/to/coal.dll>).


### Arguments
* `module_target_name`: The python module target name.
* `OUTPUT_PATH`: Path where to generate the init file.
* `TEMPLATE_FILE`: Custom template file.


### Example
```cmake
nanobind_add_module(coal_pywrap_nb module.cpp)
# Link the python module with the main pure c++ shared library 'coal'
target_link_libraries(coal_pywrap_nb PRIVATE coal)
jrl_target_set_output_directory(coal_pywrap_nb OUTPUT_DIRECTORY ${CMAKE_BINARY_DIR}/lib/site-packages/coal)

jrl_python_generate_init_py(
    coal_pywrap_nb
    OUTPUT_PATH ${CMAKE_BINARY_DIR}/lib/site-packages/coal/__init__.py
)
```
#]============================================================================]
function(jrl_python_generate_init_py name)
    set(options)
    set(oneValueArgs OUTPUT_PATH TEMPLATE_FILE)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_target_exists(${name})
    _jrl_check_var_defined(arg_OUTPUT_PATH)

    if(arg_TEMPLATE_FILE)
        set(template_file ${arg_TEMPLATE_FILE})
    else()
        set(template_file ${_JRL_TEMPLATES_DIR}/__init__.py.in)
    endif()

    get_target_property(python_module_link_libraries ${name} LINK_LIBRARIES)
    message(DEBUG "Python module '${name}' link libraries: [${python_module_link_libraries}]")

    set(dlls_to_link "")
    list(REMOVE_DUPLICATES python_module_link_libraries)
    foreach(target IN LISTS python_module_link_libraries)
        get_target_property(target_type ${target} TYPE)
        get_target_property(is_imported ${target} IMPORTED)
        message(
            DEBUG
            "Checking target '${target}' of type '${target_type}' for dll linking. Imported: '${is_imported}'"
        )

        if(
            target_type STREQUAL "SHARED_LIBRARY"
            OR target_type STREQUAL "MODULE_LIBRARY"
            AND NOT ${is_imported}
        )
            message(
                DEBUG
                "    => Adding target '${target}' to dlls to link for python module '${name}'"
            )
            list(APPEND dlls_to_link ${target})
        endif()
    endforeach()

    message(
        DEBUG
        "Python module '${name}' depends on the following buildsystem dlls: [${dlls_to_link}]"
    )

    # Get the relative paths between the python module and each dll
    set(all_rel_paths "")
    foreach(dll_name IN LISTS dlls_to_link)
        get_target_property(python_module_dir ${name} LIBRARY_OUTPUT_DIRECTORY)
        _jrl_check_var_defined(python_module_dir "LIBRARY_OUTPUT_DIRECTORY not set for target '${name}', add it using 'set_target_properties(<target> PROPERTIES LIBRARY_OUTPUT_DIRECTORY <dir>)'")

        get_target_property(dll_dir ${dll_name} RUNTIME_OUTPUT_DIRECTORY)
        _jrl_check_var_defined(dll_dir)

        file(RELATIVE_PATH rel_path ${python_module_dir} ${dll_dir})
        list(APPEND all_rel_paths ${rel_path})
    endforeach()

    # Final formatting to a Python list
    set(dll_dirs "[")
    foreach(rel_path IN LISTS all_rel_paths)
        string(APPEND dll_dirs "'${rel_path}',")
    endforeach()
    string(REGEX REPLACE ",$" "" dll_dirs "${dll_dirs}")
    string(APPEND dll_dirs "]")

    # Configure the __init__.py with PYTHON_MODULE_NAME and optional dll_dirs
    set(__MODULE_NAME__ "${name}")
    set(__DLL_DIRS__ "${dll_dirs}")
    configure_file(${template_file} ${arg_OUTPUT_PATH} @ONLY)
endfunction()

#[============================================================================[
# `jrl_check_python_module`

```cpp
jrl_check_python_module(
    <module_name>
    [REQUIRED]
    [QUIET]
)
```

**Type:** function


### Description
  Find if a python module is available, fills <module_name>_FOUND variable.
  Also fills <module_name>_VERSION variable if the module has a __version__ attribute.
  Displays messages based on REQUIRED and QUIET options.


### Arguments
* `module_name`: The python module name.
* `REQUIRED`: If set, the package is required.
* `QUIET`: If set, do not print messages.


### Example
```cmake
jrl_check_python_module(numpy REQUIRED)
```
#]============================================================================]
function(jrl_check_python_module module_name)
    set(options REQUIRED QUIET)
    set(oneValueArgs)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    jrl_python_get_interpreter(python)

    execute_process(
        COMMAND
            ${python} -c
            "import ${module_name}; print(getattr(${module_name}, '__version__', ''), end='')"
        RESULT_VARIABLE module_found
        OUTPUT_VARIABLE module_version
        ERROR_QUIET
        OUTPUT_STRIP_TRAILING_WHITESPACE
    )

    if(module_found STREQUAL 0)
        set(${module_name}_FOUND true PARENT_SCOPE)
        if(module_version)
            set(${module_name}_VERSION "${module_version}" PARENT_SCOPE)
            if(NOT arg_QUIET)
                message(STATUS "Python module '${module_name}' found (version: ${module_version}).")
            endif()
        else()
            if(NOT arg_QUIET)
                message(STATUS "Python module '${module_name}' found.")
            endif()
        endif()
    else()
        set(${module_name}_FOUND false PARENT_SCOPE)
        if(arg_REQUIRED)
            message(FATAL_ERROR "Required Python module '${module_name}' not found.")
        elseif(NOT arg_QUIET)
            message(WARNING "Python module '${module_name}' not found.")
        endif()
    endif()
endfunction()

#[============================================================================[
# `jrl_python_relative_site_packages`

```cpp
jrl_python_relative_site_packages(<output>)
```

**Type:** function


### Description
  Compute the relative path of the Python site-packages directory with respect to
  the Python data directory. It is the result of:
  ```python
    sysconfig.get_path('purelib')).relative_to(sysconfig.get_path('data')
  ```

  This function is used to compute the installation directory for Python bindings in
  in jrl_python_compute_install_dir(<output>), and for ros2 package files.

  NOTE: For installing Python bindings, use jrl_python_compute_install_dir() instead.


### Arguments
  <output> - Name of the variable to store the result.


### Example
```cmake
    jrl_python_relative_site_packages(python_relative_site_packages)
    message(STATUS "Python relative site-packages: ${python_relative_site_packages}")
```

#]============================================================================]
function(jrl_python_relative_site_packages output)
    jrl_python_get_interpreter(python)

    execute_process(
        COMMAND
            ${python} -c
            "
import sysconfig
from pathlib import Path
print(Path(sysconfig.get_path('purelib')).relative_to(sysconfig.get_path('data')))
            "
        OUTPUT_VARIABLE python_relative_site_packages
        ERROR_VARIABLE error
        OUTPUT_STRIP_TRAILING_WHITESPACE
    )

    if(error)
        message(
            FATAL_ERROR
            "Error while trying to compute the python relative site-packages: ${error}"
        )
    endif()

    # On Windows, convert to CMake path list (backslashes to slashes)
    if(WIN32)
        cmake_path(
            CONVERT "${python_relative_site_packages}"
            TO_CMAKE_PATH_LIST python_relative_site_packages
        )
    endif()

    set(${output} "${python_relative_site_packages}" PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_python_absolute_site_packages`

```cpp
jrl_python_absolute_site_packages(<output>)
```

**Type:** function


### Description
  Compute the absolute path of the Python site-packages directory with respect to
  the Python data directory. It is the result of:
  ```python
    sysconfig.get_path('purelib')
  ```

  This function is used to compute the installation directory for Python bindings in
  in jrl_python_compute_install_dir(<output>).

  NOTE: For installing Python bindings, use jrl_python_compute_install_dir() instead.


### Arguments
  <output> - Name of the variable to store the result.


### Example
```cmake
    jrl_python_absolute_site_packages(python_absolute_site_packages)
    message(STATUS "Python absolute site-packages: ${python_absolute_site_packages}")
```

#]============================================================================]
function(jrl_python_absolute_site_packages output)
    jrl_python_get_interpreter(python)

    execute_process(
        COMMAND
            ${python} -c
            "
import sysconfig
from pathlib import Path
print(Path(sysconfig.get_path('purelib')))
            "
        OUTPUT_VARIABLE python_absolute_site_packages
        ERROR_VARIABLE error
        OUTPUT_STRIP_TRAILING_WHITESPACE
    )

    if(error)
        message(
            FATAL_ERROR
            "Error while trying to compute the python absolute site-packages: ${error}"
        )
    endif()

    # On Windows, convert to CMake path list (backslashes to slashes)
    if(WIN32)
        cmake_path(
            CONVERT "${python_absolute_site_packages}"
            TO_CMAKE_PATH_LIST python_absolute_site_packages
        )
    endif()

    set(${output} "${python_absolute_site_packages}" PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_python_compute_install_dir`

```cpp
jrl_python_compute_install_dir(<output>)
```

**Type:** function


### Description
    Compute the installation directory for Python libraries.
    It chooses the installation based using the following priority:
 1. If <PROJECT_NAME_UPPER>_PYTHON_INSTALL_DIR is defined, its value is used.
    Usually passed via CMake command line: -D<PROJECT_NAME_UPPER>_PYTHON_INSTALL_DIR=<path>
    It is usually an absolute path to a specific site-packages folder.
    Note: <PROJECT_NAME_UPPER> is the PROJECT_NAME converted to a valid C identifier and in upper case.
 2. If <PROJECT_NAME_UPPER>_PYTHON_INSTALL_DIR **environment** variable is defined, its value is used.
 3. If running inside a CMeel environment (on Windows), the PYTHON_SITELIB variable is used.
    CMeel is detected when CMAKE_INSTALL_PREFIX contains "cmeel.prefix".
    The PYTHON_SITELIB variable is forwareded by CMeel.
 4. If running inside a Conda environment, on Windows, the absolute path to site-packages is used.
    It is the return value of: `sysconfig.get_path('purelib')`.
    Example: `C:/Users/You/Miniconda3/envs/myenv/Lib/site-packages`
 5. The relative path to site-packages is used.
    It is the result of: `sysconfig.get_path('purelib')).relative_to(sysconfig.get_path('data')`
    On macOS/Linux: `lib/python3.11/site-packages`
    On Windows: `Lib/site-packages`

#### Conda Windows Layout

On Conda Windows, the site-packages is located in the `Lib\site-packages` folder,
but the Conda native libraries (DLLs) are located in the `Library\bin` folder.
CMAKE_INSTALL_PREFIX is set to CMAKE_INSTALL_PREFIX=%PREFIX%\Library.
But the python libraries are installed in %PREFIX%\Lib\site-packages.

```
C:\Users\You\Miniconda3\envs\myenv\
├── python.exe                  # The Python Interpreter
├── pythonw.exe
├── DLLs\                       # Standard Python DLLs
├── Lib\
│   └── site-packages\          # <--- PURELIB IS HERE
│       ├── pandas\
│       ├── requests\
│       └── ...
├── Scripts\                    # Python Entry points (pip.exe, jupyter.exe)
├── Library\                    # <--- CONDA SPECIFIC FOLDER
│   ├── bin\                    # Native DLLs (libssl-1_1-x64.dll, mkl.dll)
│   ├── include\                # C Headers (.h files)
│   └── lib\                    # Link libraries (.lib)
└── ...
```

#### Conda Linux & macOS Layout (Unix)

On Unix Conda environments, the site-packages is located in the `lib/pythonX.Y/site-packages` folder,
and the Conda native libraries are located in the `lib/` folder, just like a standard installation.

```
/home/user/miniconda3/envs/myenv/
├── bin/                        # Executables (python, pip, jupyter)
├── include/                    # C Headers
├── lib/
│   ├── libssl.so               # Native shared libraries
│   └── python3.11/
│       └── site-packages/      # <--- PURELIB IS HERE
│           ├── pandas/
│           └── ...
└── ...
```


### Arguments
  <output> - Name of the variable to store the result.


### Example
```cmake
  jrl_python_compute_install_dir(python_install_dir)
  install(TARGETS my_python_module DESTINATION ${python_install_dir} ...)
```
#]============================================================================]
function(jrl_python_compute_install_dir output)
    string(MAKE_C_IDENTIFIER "${PROJECT_NAME}" project_name_identifier)
    string(TOUPPER "${project_name_identifier}" project_name_identifier)
    set(python_install_dir_var "${project_name_identifier}_PYTHON_INSTALL_DIR")

    # Case 1: override via the <PROJECT_NAME_UPPER>_PYTHON_INSTALL_DIR CMake variable
    if(DEFINED ${python_install_dir_var})
        set(pyinstall_dir "${${python_install_dir_var}}")

        # On Windows, convert to CMake path list (backslashes to slashes)
        if(WIN32)
            cmake_path(CONVERT "${pyinstall_dir}" TO_CMAKE_PATH_LIST pyinstall_dir NORMALIZE)
        endif()

        message(
            STATUS
            "Variable ${python_install_dir_var} is defined, using its value as python install dir.
    ${python_install_dir_var} : ${pyinstall_dir}
    Python install dir                 : ${pyinstall_dir}
            "
        )

        set(${output} ${pyinstall_dir} PARENT_SCOPE)
        return()
    endif()

    # Case 1b: override via the <PROJECT_NAME_UPPER>_PYTHON_INSTALL_DIR environment variable
    if(DEFINED ENV{${python_install_dir_var}})
        set(pyinstall_dir "$ENV{${python_install_dir_var}}")

        if(WIN32)
            cmake_path(CONVERT "${pyinstall_dir}" TO_CMAKE_PATH_LIST pyinstall_dir NORMALIZE)
        endif()
        message(
            STATUS
            "Environnement variable ${python_install_dir_var} is defined, using its value as python install dir.
    ${python_install_dir_var} : ${pyinstall_dir}
    Python install dir                 : ${pyinstall_dir}
            "
        )

        set(${output} ${pyinstall_dir} PARENT_SCOPE)
        return()
    endif()

    # Case 2: CMeel detection if the install prefix contains "cmeel.prefix"
    # This is a weak check until CMeel uses the proper cross-platform relative site-packages.
    # ref: https://github.com/cmake-wheel/cmeel/issues/252
    if(WIN32 AND DEFINED CMAKE_INSTALL_PREFIX)
        if(CMAKE_INSTALL_PREFIX MATCHES "cmeel.prefix")
            _jrl_check_var_defined(PYTHON_SITELIB "PYTHON_SITELIB variable must be defined when using CMeel environment.")
            if(WIN32)
                cmake_path(CONVERT "${PYTHON_SITELIB}" TO_CMAKE_PATH_LIST PYTHON_SITELIB NORMALIZE)
            endif()
            set(pyinstall_dir ${PYTHON_SITELIB})
            message(
                STATUS
                "CMeel environment detected, using the provided PYTHON_SITELIB as install dir.
        ${python_install_dir_var} : ${pyinstall_dir}
        Python install dir                 : ${pyinstall_dir}
            "
            )
            set(${output} ${pyinstall_dir} PARENT_SCOPE)
            return()
        endif()
    endif()

    # Case 3: Conda environment on Windows specific case
    if(WIN32 AND DEFINED ENV{CONDA_PREFIX})
        jrl_python_absolute_site_packages(python_absolute_site_packages)
        message(
            STATUS
            "Detected Conda environment on Windows, using absolute python site-packages as python install dir.
    CONDA_PREFIX               : $ENV{CONDA_PREFIX}
    Python site-packages (abs) : ${python_absolute_site_packages}
    Python install dir         : ${python_absolute_site_packages}

    You can override this behavior with the ${python_install_dir_var} variable (CMake or env variable).
            "
        )

        set(${output} "${python_absolute_site_packages}" PARENT_SCOPE)
        return()
    endif()

    # Case 4: Default case, use the relative site-packages path
    jrl_python_relative_site_packages(python_relative_site_packages)

    message(
        STATUS
        "Using default relative python site-packages as python install dir.
    Python site-packages (rel) : ${python_relative_site_packages}
    Python install dir         : ${python_relative_site_packages}

    You can override this behavior with the ${python_install_dir_var} variable (CMake or env variable).
    "
    )

    set(${output} "${python_relative_site_packages}" PARENT_SCOPE)
endfunction()

#[============================================================================[
# `jrl_check_python_module_name`

```cpp
jrl_check_python_module_name(<module_target>)
```

**Type:** function


### Description
  Check that the python module defined with NB_MODULE(<module_name>)
  or BOOST_PYTHON_MODULE(<module_name>) has the same name as the target: <module_name>.cpython-XY.so.
  Otherwise the module will fail to load in Python.
  NOTE: It verifies that the symbol PyInit_<module_name> exists in the built module.


### Arguments
* `module_target`: The python module target.


### Example
```cmake
jrl_check_python_module_name(my_module)
```
#]============================================================================]
function(jrl_check_python_module_name target)
    _jrl_check_target_exists(${target})
    set(script ${CMAKE_BINARY_DIR}/generated/cmake/${PROJECT_NAME}/check-python-module-name.cmake)
    file(
        CONFIGURE
        OUTPUT ${script}
        @ONLY
        CONTENT
            [[
if(NOT CMAKE_SCRIPT_MODE_FILE)
    message(FATAL_ERROR "This script is intended to be run in script mode only. Use -P <script>.")
endif()

if(NOT DEFINED MODULE_FILE)
    message(
        FATAL_ERROR
        "MODULE_FILE variable is not defined, please pass -DMODULE_FILE=<path_to_module_file> to the script"
    )
endif()

if(NOT DEFINED EXPECTED_MODULE_NAME)
    message(FATAL_ERROR "MODULE_FILE variable is not defined.")
endif()

file(STRINGS "${MODULE_FILE}" target_content REGEX "PyInit_([a-zA-Z0-9_]+)" LIMIT_COUNT 1)
string(REGEX MATCH "PyInit_([a-zA-Z0-9_]+)" _ "${target_content}")

if(NOT CMAKE_MATCH_1)
    message(
        FATAL_ERROR
        "Could not find PyInit function in module file: '${MODULE_FILE}'. Is this a valid Python module?"
    )
endif()

if(NOT CMAKE_MATCH_1 STREQUAL EXPECTED_MODULE_NAME)
    message(
        FATAL_ERROR
        "Module name mismatch for module file: '${MODULE_FILE}'. "
        "Expected: '${EXPECTED_MODULE_NAME}', Detected: '${CMAKE_MATCH_1}'"
    )
endif()

message(
    DEBUG
    "Python module name check passed for '${MODULE_FILE}'. Detected module name: '${CMAKE_MATCH_1}'"
)
]]
    )

    add_custom_command(
        TARGET ${target}
        POST_BUILD
        COMMAND
            ${CMAKE_COMMAND} -DMODULE_FILE=$<TARGET_FILE:${target}> -DEXPECTED_MODULE_NAME=${target}
            -P ${script}
        COMMENT "Checking 'PyInit_${target}' exists"
        VERBATIM
    )
endfunction()

#[============================================================================[
# `jrl_boostpy_add_module`

```cpp
jrl_boostpy_add_module(
    <name>
    [sources...]
)
```

**Type:** function


### Description
  Creates a Boost.Python module with the given name and sources.
  The library name will be in the form <name>-<SOABI>.so, where <SOABI> is the
  Python SOABI tag (e.g., cp39-cp39m-linux_x86_64).


### Arguments
* `name`: The name of the module.
* `sources`: Source files.


### Example
```cmake
jrl_boostpy_add_module(my_module module.cpp)
```
#]============================================================================]
function(jrl_boostpy_add_module name)
    _jrl_check(COMMAND python_add_library
        ERROR_MESSAGE "
    python_add_library(<name>) command not found.
    It is available in the FindPython module shipped with CMake.
    Use (jrl_)find_package(Python REQUIRED) before calling jrl_boostpy_add_module.
    Doc: https://cmake.org/cmake/help/latest/module/FindPython.html
    "
    )

    _jrl_check_target_exists(Boost::python
        "
    Boost::python target not found.
    Make sure you have Boost.Python using (jrl_)find_package(Boost REQUIRED COMPONENTS python).
    "
    )

    python_add_library(${name} MODULE WITH_SOABI ${ARGN})
    target_link_libraries(${name} PRIVATE Boost::python)
endfunction()

#[============================================================================[
# `jrl_boostpy_add_stubs`

```cpp
jrl_boostpy_add_stubs(
    <name>
    MODULE <module_path>
    OUTPUT_PATH <output_path>
    [PYTHON_PATH <python_path>]
    [DEPENDS <dep1> <dep2> ...]
    [VERBOSE]
)
```

**Type:** function


### Description
  Generates Boost.Python stubs for the given module using the pybind11-stubgen fork included in this repo.


### Arguments
* `name`: The target name.
* `MODULE`: The module to generate stubs for.
* `OUTPUT_PATH`: Output path.
* `PYTHON_PATH`: PYTHONPATH to use (optional).
* `DEPENDS`: Dependencies (optional).
* `VERBOSE`: Verbose output (optional).


### Example
```cmake
jrl_boostpy_add_stubs(my_stubs MODULE my_module OUTPUT_PATH ${CMAKE_BINARY_DIR})
```
#]============================================================================]
function(jrl_boostpy_add_stubs name)
    set(options VERBOSE)
    set(oneValueArgs MODULE OUTPUT_PATH PYTHON_PATH DEPENDS)
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    _jrl_check_var_defined(arg_MODULE)
    _jrl_check_var_defined(arg_OUTPUT_PATH)

    if(NOT arg_PYTHON_PATH)
        set(pythonpath "")
    else()
        set(pythonpath "PYTHONPATH=${arg_PYTHON_PATH}")
    endif()

    if(arg_VERBOSE)
        set(loglevel "--log-level=DEBUG")
    endif()

    set(stubgen_py ${_JRL_EXTERNAL_MODULES_DIR}/pybind11-stubgen-e48d1f1/pybind11_stubgen.py)
    cmake_path(CONVERT ${stubgen_py} TO_CMAKE_PATH_LIST stubgen_py NORMALIZE)
    _jrl_check_file_exists(${stubgen_py})

    jrl_python_get_interpreter(python)

    string(REPLACE "." "/" module_subpath ${arg_MODULE})
    # The stubs will be generated in <arg_OUTPUT_PATH>/<module_subpath>/__init__.pyi
    # Example: for module 'coal.coal_pywrap', the stubs will be in <arg_OUTPUT_PATH>/coal/coal_pywrap/__init__.pyi
    set(stub_output ${arg_OUTPUT_PATH}/${module_subpath}/__init__.pyi)

    add_custom_command(
        OUTPUT ${stub_output}
        COMMAND
            ${CMAKE_COMMAND} -E env ${pythonpath} ${python} ${stubgen_py} --output-dir
            ${arg_OUTPUT_PATH} ${arg_MODULE} ${loglevel} --boost-python --ignore-invalid=signature
            --no-setup-py --no-root-module-suffix
        WORKING_DIRECTORY ${CMAKE_CURRENT_BINARY_DIR}
        DEPENDS ${arg_DEPENDS}
        VERBATIM
        COMMENT "Generating Boost.Python stubs for module '${arg_MODULE}'"
    )
    add_custom_target(${name} ALL DEPENDS ${stub_output})
    if(arg_DEPENDS)
        add_dependencies(${name} ${arg_DEPENDS})
    endif()
endfunction()

#[============================================================================[
# `jrl_generate_ros2_package_files`

```cpp
jrl_generate_ros2_package_files(
    [INSTALL_CPP_PACKAGE_FILES <ON|OFF>]
    [INSTALL_PYTHON_PACKAGE_FILES <ON|OFF>]
    [PACKAGE_XML_PATH <path>]
    [DESTINATION <install destination>]
    [GEN_DIR <gen_dir>]
    [SKIP_INSTALL]
)
```

**Type:** function


### Description
  Generates the necessary files for a ROS 2 package to be discoverable by ament.
  It creates the following files:
   - ${GEN_DIR}/share/ament_index/resource_index/packages/<PROJECT_NAME>
   - ${GEN_DIR}/share/<PROJECT_NAME>/hook/ament_prefix_path.dsv
   - ${GEN_DIR}/share/<PROJECT_NAME>/hook/python_path.dsv

  By default, it installs all generated files to the CMAKE_INSTALL_DATAROOTDIR directory.
  You can override the installation destination using the DESTINATION argument.


### Arguments
* `INSTALL_CPP_PACKAGE_FILES`: Whether to install the C++ package files (default: ON).
* `INSTALL_PYTHON_PACKAGE_FILES`: Whether to install the Python package files (default: ON).
* `PACKAGE_XML_PATH`: Path to the package.xml file (default: ${CMAKE_CURRENT_SOURCE_DIR}/package.xml).
* `DESTINATION`: Installation destination for the generated files (default: CMAKE_INSTALL_DATAROOTDIR).
* `GEN_DIR`: Directory where to generate the files (default: ${CMAKE_BINARY_DIR}/generated/ros2/${PROJECT_NAME}/ros2).
* `SKIP_INSTALL`: If set, skips the installation of the generated files.


### Example
```cmake
jrl_generate_ros2_package_files()

jrl_generate_ros2_package_files(
    INSTALL_CPP_PACKAGE_FILES "NOT BUILD_STANDALONE_PYTHON_BINDINGS"
)
```
#]============================================================================]
function(jrl_generate_ros2_package_files)
    set(options SKIP_INSTALL)
    set(oneValueArgs
        INSTALL_CPP_PACKAGE_FILES
        INSTALL_PYTHON_PACKAGE_FILES
        PACKAGE_XML_PATH
        DESTINATION
        GEN_DIR
    )
    set(multiValueArgs)
    cmake_parse_arguments(arg "${options}" "${oneValueArgs}" "${multiValueArgs}" ${ARGN})
    _jrl_check_no_unrecognized_arguments(arg)

    message(STATUS "[${PROJECT_NAME}] Generating files for ament (ROS 2)")

    if(DEFINED arg_INSTALL_CPP_PACKAGE_FILES)
        cmake_language(
            EVAL CODE
                "
            if(${arg_INSTALL_CPP_PACKAGE_FILES})
                set(install_cpp_package_files True)
            else()
                set(install_cpp_package_files False)
            endif()
        "
        )
    else()
        set(install_cpp_package_files True)
    endif()

    if(DEFINED arg_INSTALL_PYTHON_PACKAGE_FILES)
        cmake_language(
            EVAL CODE
                "
            if(${arg_INSTALL_PYTHON_PACKAGE_FILES})
                set(install_python_package_files True)
            else()
                set(install_python_package_files False)
            endif()
        "
        )
    else()
        set(install_python_package_files True)
    endif()

    if(install_cpp_package_files)
        if(arg_PACKAGE_XML_PATH)
            _jrl_check_file_exists(${CMAKE_CURRENT_SOURCE_DIR}/${arg_PACKAGE_XML_PATH}
                "
            PACKAGE_XML_PATH file '${arg_PACKAGE_XML_PATH}' does not exist.
            Please provide a valid path to the package.xml file of your ROS 2 package.
            "
            )
            set(package_xml_path ${CMAKE_CURRENT_SOURCE_DIR}/${arg_PACKAGE_XML_PATH})
        else()
            set(package_xml_path ${CMAKE_CURRENT_SOURCE_DIR}/package.xml)
            _jrl_check_file_exists(${package_xml_path}
                "
                package.xml file not found at default location: '${package_xml_path}'.
                Please provide a valid path to the package.xml file of your ROS 2 package
                using the PACKAGE_XML_PATH argument.
                "
            )
        endif()
    endif()

    if(arg_GEN_DIR)
        set(GEN_DIR ${arg_GEN_DIR})
    else()
        set(GEN_DIR ${CMAKE_BINARY_DIR}/generated/ros2)
    endif()

    if(arg_DESTINATION)
        set(install_destination ${arg_DESTINATION})
    else()
        _jrl_check_var_defined(CMAKE_INSTALL_DATAROOTDIR
            "CMAKE_INSTALL_DATAROOTDIR is not defined.
            Use jrl_configure_defaults(), or jrl_configure_default_install_dirs(), or include(GNUInstallDirs)."
        )
        set(install_destination ${CMAKE_INSTALL_DATAROOTDIR})
    endif()

    if(install_cpp_package_files)
        file(
            GENERATE OUTPUT ${GEN_DIR}/share/ament_index/resource_index/packages/${PROJECT_NAME}
            CONTENT ""
        )

        file(
            GENERATE OUTPUT ${GEN_DIR}/share/${PROJECT_NAME}/hook/ament_prefix_path.dsv
            CONTENT "prepend-non-duplicate;AMENT_PREFIX_PATH;"
        )
        configure_file(${package_xml_path} ${GEN_DIR}/share/${PROJECT_NAME}/package.xml COPYONLY)
    endif()

    if(install_python_package_files)
        jrl_python_relative_site_packages(python_relative_site_packages)
        file(
            GENERATE OUTPUT ${GEN_DIR}/share/${PROJECT_NAME}/hook/python_path.dsv
            CONTENT "prepend-non-duplicate;PYTHONPATH;${python_relative_site_packages}"
        )
    endif()

    if(arg_SKIP_INSTALL)
        message(
            STATUS
            "[${PROJECT_NAME}] Skipping installation of ROS 2 package files as SKIP_INSTALL is set."
        )
        return()
    endif()

    if(install_cpp_package_files)
        install(
            FILES ${GEN_DIR}/share/ament_index/resource_index/packages/${PROJECT_NAME}
            DESTINATION ${install_destination}/ament_index/resource_index/packages
        )
        install(
            FILES ${GEN_DIR}/share/${PROJECT_NAME}/hook/ament_prefix_path.dsv
            DESTINATION ${install_destination}/${PROJECT_NAME}/hook
        )
        install(
            FILES ${GEN_DIR}/share/${PROJECT_NAME}/package.xml
            DESTINATION ${install_destination}/${PROJECT_NAME}
        )
    endif()

    if(install_python_package_files)
        install(
            FILES ${GEN_DIR}/share/${PROJECT_NAME}/hook/python_path.dsv
            DESTINATION ${install_destination}/${PROJECT_NAME}/hook
        )
    endif()
endfunction()

#[============================================================================[
# `_jrl_generate_api_doc`

```cpp
_jrl_generate_api_doc(
    <input_file>
    <output_file>
)
```

**Type:** function


### Description
  Parses the input CMake file for documentations block and
  generates a Markdown file with their content.


### Arguments
* `input_file`: The CMake file to parse.
* `output_file`: The Markdown file to generate.


### Example
```cmake
_jrl_generate_api_doc(${CMAKE_CURRENT_LIST_FILE} "API.md")
# or using the command line:
cmake -DGENERATE_API_DOC=ON -P v2/modules/jrl.cmake
```
#]============================================================================]
function(_jrl_generate_api_doc input_file output_file)
    _jrl_check_file_exists(${input_file})

    file(READ "${input_file}" content_raw)
    string(REGEX REPLACE "\r" "" content_raw "${content_raw}")

    # Escape semicolons so list operations don't split content.
    string(REPLACE ";" "\\;" content_escaped "${content_raw}")

    # Mark doc block boundaries.
    set(doc_start "__JRL_DOC_START__")
    set(doc_end "__JRL_DOC_END__")
    string(
        REGEX REPLACE "(^|\n)[ \t]*#\\[=+\\[[ \t]*\n"
        "\\1${doc_start}"
        content_marked
        "${content_escaped}"
    )
    string(REGEX REPLACE "\n[ \t]*#\\]=+\\][ \t]*" "${doc_end}" content_marked "${content_marked}")

    # Split on doc-start token.
    string(REPLACE "${doc_start}" ";" content_blocks "${content_marked}")

    set(markdown_content "")

    foreach(block IN LISTS content_blocks)
        string(FIND "${block}" "${doc_end}" end_pos)
        if(end_pos EQUAL -1)
            continue()
        endif()

        string(SUBSTRING "${block}" 0 ${end_pos} doc_block)
        # Restore escaped semicolons.
        string(REPLACE "\\;" ";" doc_block "${doc_block}")

        string(REGEX MATCH "# `([^`]+)`" _ "${doc_block}")
        if(CMAKE_MATCH_1)
            set(doc_name "${CMAKE_MATCH_1}")
            if(doc_name MATCHES "^_")
                message(STATUS "Skipping internal documentation for ${doc_name}")
            else()
                message(STATUS "Processing documentation for ${doc_name}")
                string(APPEND markdown_content "${doc_block}\n")
            endif()
        endif()
    endforeach()

    set(JRL_API_DOCUMENTATION "${markdown_content}")

    # Check if output file already exists
    set(output_file_exists false)
    set(output_file_old_content "")
    if(EXISTS ${output_file})
        set(output_file_exists true)
        file(READ ${output_file} output_file_old_content)
    endif()

    set(tmp_output_file ${output_file}.tmp)

    configure_file(${_JRL_TEMPLATES_DIR}/api.md.in ${tmp_output_file} @ONLY)

    # Check if the file is new or has been updated
    if(output_file_old_content STREQUAL "")
        file(COPY_FILE ${tmp_output_file} ${output_file})
        message(STATUS "API documentation created at '${output_file}'")
    else()
        file(READ ${tmp_output_file} output_file_new_content)
        if(output_file_old_content STREQUAL output_file_new_content)
            message(STATUS "API documentation already up to date at '${output_file}'")
        else()
            file(COPY_FILE ${tmp_output_file} ${output_file})
            message(STATUS "API documentation updated at '${output_file}'")
        endif()
    endif()

    message(DEBUG "Removing temporary file '${tmp_output_file}'")
    file(REMOVE ${tmp_output_file})
endfunction()

if(JRL_GENERATE_API_DOC)
    _jrl_generate_api_doc(${CMAKE_CURRENT_LIST_FILE} ${_JRL_DOCS_DIR}/api.md)
endif()
