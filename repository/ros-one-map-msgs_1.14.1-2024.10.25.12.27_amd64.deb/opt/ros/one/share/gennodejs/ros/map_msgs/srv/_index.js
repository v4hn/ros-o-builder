
"use strict";

let GetPointMap = require('./GetPointMap.js')
let ProjectedMapsInfo = require('./ProjectedMapsInfo.js')
let GetPointMapROI = require('./GetPointMapROI.js')
let SetMapProjections = require('./SetMapProjections.js')
let GetMapROI = require('./GetMapROI.js')
let SaveMap = require('./SaveMap.js')

module.exports = {
  GetPointMap: GetPointMap,
  ProjectedMapsInfo: ProjectedMapsInfo,
  GetPointMapROI: GetPointMapROI,
  SetMapProjections: SetMapProjections,
  GetMapROI: GetMapROI,
  SaveMap: SaveMap,
};
