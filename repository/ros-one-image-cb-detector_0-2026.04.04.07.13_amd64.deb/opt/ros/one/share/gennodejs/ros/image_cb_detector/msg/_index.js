
"use strict";

let ConfigAction = require('./ConfigAction.js');
let ConfigActionResult = require('./ConfigActionResult.js');
let ConfigFeedback = require('./ConfigFeedback.js');
let ConfigGoal = require('./ConfigGoal.js');
let ConfigResult = require('./ConfigResult.js');
let ConfigActionFeedback = require('./ConfigActionFeedback.js');
let ConfigActionGoal = require('./ConfigActionGoal.js');
let ImagePoint = require('./ImagePoint.js');
let ObjectInImage = require('./ObjectInImage.js');

module.exports = {
  ConfigAction: ConfigAction,
  ConfigActionResult: ConfigActionResult,
  ConfigFeedback: ConfigFeedback,
  ConfigGoal: ConfigGoal,
  ConfigResult: ConfigResult,
  ConfigActionFeedback: ConfigActionFeedback,
  ConfigActionGoal: ConfigActionGoal,
  ImagePoint: ImagePoint,
  ObjectInImage: ObjectInImage,
};
