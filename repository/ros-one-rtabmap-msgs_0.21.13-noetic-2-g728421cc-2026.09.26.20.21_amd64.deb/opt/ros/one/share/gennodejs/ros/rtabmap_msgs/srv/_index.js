
"use strict";

let LoadDatabase = require('./LoadDatabase.js')
let GetMap = require('./GetMap.js')
let GetPlan = require('./GetPlan.js')
let GlobalBundleAdjustment = require('./GlobalBundleAdjustment.js')
let PublishMap = require('./PublishMap.js')
let SetLabel = require('./SetLabel.js')
let GetMap2 = require('./GetMap2.js')
let GetNodeData = require('./GetNodeData.js')
let RemoveLabel = require('./RemoveLabel.js')
let ListLabels = require('./ListLabels.js')
let DetectMoreLoopClosures = require('./DetectMoreLoopClosures.js')
let SetGoal = require('./SetGoal.js')
let CleanupLocalGrids = require('./CleanupLocalGrids.js')
let GetNodesInRadius = require('./GetNodesInRadius.js')
let ResetPose = require('./ResetPose.js')
let AddLink = require('./AddLink.js')

module.exports = {
  LoadDatabase: LoadDatabase,
  GetMap: GetMap,
  GetPlan: GetPlan,
  GlobalBundleAdjustment: GlobalBundleAdjustment,
  PublishMap: PublishMap,
  SetLabel: SetLabel,
  GetMap2: GetMap2,
  GetNodeData: GetNodeData,
  RemoveLabel: RemoveLabel,
  ListLabels: ListLabels,
  DetectMoreLoopClosures: DetectMoreLoopClosures,
  SetGoal: SetGoal,
  CleanupLocalGrids: CleanupLocalGrids,
  GetNodesInRadius: GetNodesInRadius,
  ResetPose: ResetPose,
  AddLink: AddLink,
};
