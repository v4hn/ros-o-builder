
"use strict";

let TestAction = require('./TestAction.js');
let TwoIntsResult = require('./TwoIntsResult.js');
let TestResult = require('./TestResult.js');
let TwoIntsGoal = require('./TwoIntsGoal.js');
let TwoIntsActionGoal = require('./TwoIntsActionGoal.js');
let TestActionResult = require('./TestActionResult.js');
let TestGoal = require('./TestGoal.js');
let TestRequestActionGoal = require('./TestRequestActionGoal.js');
let TwoIntsFeedback = require('./TwoIntsFeedback.js');
let TestActionGoal = require('./TestActionGoal.js');
let TestRequestActionFeedback = require('./TestRequestActionFeedback.js');
let TestRequestActionResult = require('./TestRequestActionResult.js');
let TestFeedback = require('./TestFeedback.js');
let TwoIntsActionFeedback = require('./TwoIntsActionFeedback.js');
let TestRequestGoal = require('./TestRequestGoal.js');
let TestRequestFeedback = require('./TestRequestFeedback.js');
let TestRequestAction = require('./TestRequestAction.js');
let TwoIntsAction = require('./TwoIntsAction.js');
let TestActionFeedback = require('./TestActionFeedback.js');
let TwoIntsActionResult = require('./TwoIntsActionResult.js');
let TestRequestResult = require('./TestRequestResult.js');

module.exports = {
  TestAction: TestAction,
  TwoIntsResult: TwoIntsResult,
  TestResult: TestResult,
  TwoIntsGoal: TwoIntsGoal,
  TwoIntsActionGoal: TwoIntsActionGoal,
  TestActionResult: TestActionResult,
  TestGoal: TestGoal,
  TestRequestActionGoal: TestRequestActionGoal,
  TwoIntsFeedback: TwoIntsFeedback,
  TestActionGoal: TestActionGoal,
  TestRequestActionFeedback: TestRequestActionFeedback,
  TestRequestActionResult: TestRequestActionResult,
  TestFeedback: TestFeedback,
  TwoIntsActionFeedback: TwoIntsActionFeedback,
  TestRequestGoal: TestRequestGoal,
  TestRequestFeedback: TestRequestFeedback,
  TestRequestAction: TestRequestAction,
  TwoIntsAction: TwoIntsAction,
  TestActionFeedback: TestActionFeedback,
  TwoIntsActionResult: TwoIntsActionResult,
  TestRequestResult: TestRequestResult,
};
