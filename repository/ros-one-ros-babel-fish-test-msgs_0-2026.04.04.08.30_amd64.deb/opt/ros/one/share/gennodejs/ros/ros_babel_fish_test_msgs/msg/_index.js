
"use strict";

let TestMessage = require('./TestMessage.js');
let TestArray = require('./TestArray.js');
let TestSubArray = require('./TestSubArray.js');
let SimpleTestAction = require('./SimpleTestAction.js');
let SimpleTestFeedback = require('./SimpleTestFeedback.js');
let SimpleTestActionResult = require('./SimpleTestActionResult.js');
let SimpleTestResult = require('./SimpleTestResult.js');
let SimpleTestActionFeedback = require('./SimpleTestActionFeedback.js');
let SimpleTestActionGoal = require('./SimpleTestActionGoal.js');
let SimpleTestGoal = require('./SimpleTestGoal.js');

module.exports = {
  TestMessage: TestMessage,
  TestArray: TestArray,
  TestSubArray: TestSubArray,
  SimpleTestAction: SimpleTestAction,
  SimpleTestFeedback: SimpleTestFeedback,
  SimpleTestActionResult: SimpleTestActionResult,
  SimpleTestResult: SimpleTestResult,
  SimpleTestActionFeedback: SimpleTestActionFeedback,
  SimpleTestActionGoal: SimpleTestActionGoal,
  SimpleTestGoal: SimpleTestGoal,
};
