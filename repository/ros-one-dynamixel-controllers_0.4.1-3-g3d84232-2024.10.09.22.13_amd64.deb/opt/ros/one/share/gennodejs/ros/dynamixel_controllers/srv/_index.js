
"use strict";

let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')
let RestartController = require('./RestartController.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let TorqueEnable = require('./TorqueEnable.js')
let StopController = require('./StopController.js')
let SetSpeed = require('./SetSpeed.js')
let StartController = require('./StartController.js')

module.exports = {
  SetCompliancePunch: SetCompliancePunch,
  SetComplianceSlope: SetComplianceSlope,
  SetTorqueLimit: SetTorqueLimit,
  RestartController: RestartController,
  SetComplianceMargin: SetComplianceMargin,
  TorqueEnable: TorqueEnable,
  StopController: StopController,
  SetSpeed: SetSpeed,
  StartController: StartController,
};
