
"use strict";

let IOComponentCommand = require('./IOComponentCommand.js');
let InteractionControlCommand = require('./InteractionControlCommand.js');
let IONodeStatus = require('./IONodeStatus.js');
let IODeviceStatus = require('./IODeviceStatus.js');
let RobotAssemblyState = require('./RobotAssemblyState.js');
let DigitalIOState = require('./DigitalIOState.js');
let URDFConfiguration = require('./URDFConfiguration.js');
let IONodeConfiguration = require('./IONodeConfiguration.js');
let HeadPanCommand = require('./HeadPanCommand.js');
let AnalogIOStates = require('./AnalogIOStates.js');
let CollisionAvoidanceState = require('./CollisionAvoidanceState.js');
let HeadState = require('./HeadState.js');
let EndpointNamesArray = require('./EndpointNamesArray.js');
let DigitalIOStates = require('./DigitalIOStates.js');
let AnalogIOState = require('./AnalogIOState.js');
let IOStatus = require('./IOStatus.js');
let DigitalOutputCommand = require('./DigitalOutputCommand.js');
let HomingCommand = require('./HomingCommand.js');
let JointCommand = require('./JointCommand.js');
let IOComponentConfiguration = require('./IOComponentConfiguration.js');
let EndpointStates = require('./EndpointStates.js');
let IODeviceConfiguration = require('./IODeviceConfiguration.js');
let IOComponentStatus = require('./IOComponentStatus.js');
let InteractionControlState = require('./InteractionControlState.js');
let IODataStatus = require('./IODataStatus.js');
let EndpointState = require('./EndpointState.js');
let CameraControl = require('./CameraControl.js');
let HomingState = require('./HomingState.js');
let NavigatorStates = require('./NavigatorStates.js');
let CameraSettings = require('./CameraSettings.js');
let NavigatorState = require('./NavigatorState.js');
let SEAJointState = require('./SEAJointState.js');
let JointLimits = require('./JointLimits.js');
let CollisionDetectionState = require('./CollisionDetectionState.js');
let AnalogOutputCommand = require('./AnalogOutputCommand.js');
let CalibrationCommandActionGoal = require('./CalibrationCommandActionGoal.js');
let CalibrationCommandResult = require('./CalibrationCommandResult.js');
let CalibrationCommandActionResult = require('./CalibrationCommandActionResult.js');
let CalibrationCommandGoal = require('./CalibrationCommandGoal.js');
let CalibrationCommandFeedback = require('./CalibrationCommandFeedback.js');
let CalibrationCommandAction = require('./CalibrationCommandAction.js');
let CalibrationCommandActionFeedback = require('./CalibrationCommandActionFeedback.js');

module.exports = {
  IOComponentCommand: IOComponentCommand,
  InteractionControlCommand: InteractionControlCommand,
  IONodeStatus: IONodeStatus,
  IODeviceStatus: IODeviceStatus,
  RobotAssemblyState: RobotAssemblyState,
  DigitalIOState: DigitalIOState,
  URDFConfiguration: URDFConfiguration,
  IONodeConfiguration: IONodeConfiguration,
  HeadPanCommand: HeadPanCommand,
  AnalogIOStates: AnalogIOStates,
  CollisionAvoidanceState: CollisionAvoidanceState,
  HeadState: HeadState,
  EndpointNamesArray: EndpointNamesArray,
  DigitalIOStates: DigitalIOStates,
  AnalogIOState: AnalogIOState,
  IOStatus: IOStatus,
  DigitalOutputCommand: DigitalOutputCommand,
  HomingCommand: HomingCommand,
  JointCommand: JointCommand,
  IOComponentConfiguration: IOComponentConfiguration,
  EndpointStates: EndpointStates,
  IODeviceConfiguration: IODeviceConfiguration,
  IOComponentStatus: IOComponentStatus,
  InteractionControlState: InteractionControlState,
  IODataStatus: IODataStatus,
  EndpointState: EndpointState,
  CameraControl: CameraControl,
  HomingState: HomingState,
  NavigatorStates: NavigatorStates,
  CameraSettings: CameraSettings,
  NavigatorState: NavigatorState,
  SEAJointState: SEAJointState,
  JointLimits: JointLimits,
  CollisionDetectionState: CollisionDetectionState,
  AnalogOutputCommand: AnalogOutputCommand,
  CalibrationCommandActionGoal: CalibrationCommandActionGoal,
  CalibrationCommandResult: CalibrationCommandResult,
  CalibrationCommandActionResult: CalibrationCommandActionResult,
  CalibrationCommandGoal: CalibrationCommandGoal,
  CalibrationCommandFeedback: CalibrationCommandFeedback,
  CalibrationCommandAction: CalibrationCommandAction,
  CalibrationCommandActionFeedback: CalibrationCommandActionFeedback,
};
