// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let RawFTDataSample = require('./RawFTDataSample.js');

//-----------------------------------------------------------

class RawFTData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.samples = null;
      this.sample_count = null;
      this.missed_samples = null;
    }
    else {
      if (initObj.hasOwnProperty('samples')) {
        this.samples = initObj.samples
      }
      else {
        this.samples = [];
      }
      if (initObj.hasOwnProperty('sample_count')) {
        this.sample_count = initObj.sample_count
      }
      else {
        this.sample_count = 0;
      }
      if (initObj.hasOwnProperty('missed_samples')) {
        this.missed_samples = initObj.missed_samples
      }
      else {
        this.missed_samples = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RawFTData
    // Serialize message field [samples]
    // Serialize the length for message field [samples]
    bufferOffset = _serializer.uint32(obj.samples.length, buffer, bufferOffset);
    obj.samples.forEach((val) => {
      bufferOffset = RawFTDataSample.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [sample_count]
    bufferOffset = _serializer.int64(obj.sample_count, buffer, bufferOffset);
    // Serialize message field [missed_samples]
    bufferOffset = _serializer.int64(obj.missed_samples, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RawFTData
    let len;
    let data = new RawFTData(null);
    // Deserialize message field [samples]
    // Deserialize array length for message field [samples]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.samples = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.samples[i] = RawFTDataSample.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [sample_count]
    data.sample_count = _deserializer.int64(buffer, bufferOffset);
    // Deserialize message field [missed_samples]
    data.missed_samples = _deserializer.int64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.samples.forEach((val) => {
      length += RawFTDataSample.getMessageSize(val);
    });
    return length + 20;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/RawFTData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '85f5ed45095367bfb8fb2e57954c0b89';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Raw Data from WG035 F/T input via WG006 (gripper MCB).
    RawFTDataSample[] samples  # The realtime loop receives upto 4 new samples each 1hKhz cycle 
    int64 sample_count         # Counts number of samples
    int64 missed_samples       # Counts number of samples that were missed
    ================================================================================
    MSG: ethercat_hardware/RawFTDataSample
    # One raw Data sample from WG035 F/T input via WG006 (gripper MCB).
    uint64  sample_count
    int16[] data
    uint16  vhalf
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RawFTData(null);
    if (msg.samples !== undefined) {
      resolved.samples = new Array(msg.samples.length);
      for (let i = 0; i < resolved.samples.length; ++i) {
        resolved.samples[i] = RawFTDataSample.Resolve(msg.samples[i]);
      }
    }
    else {
      resolved.samples = []
    }

    if (msg.sample_count !== undefined) {
      resolved.sample_count = msg.sample_count;
    }
    else {
      resolved.sample_count = 0
    }

    if (msg.missed_samples !== undefined) {
      resolved.missed_samples = msg.missed_samples;
    }
    else {
      resolved.missed_samples = 0
    }

    return resolved;
    }
};

module.exports = RawFTData;
