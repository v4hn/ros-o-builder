// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ActuatorInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.id = null;
      this.name = null;
      this.robot_name = null;
      this.motor_make = null;
      this.motor_model = null;
      this.max_current = null;
      this.speed_constant = null;
      this.motor_resistance = null;
      this.motor_torque_constant = null;
      this.encoder_reduction = null;
      this.pulses_per_revolution = null;
    }
    else {
      if (initObj.hasOwnProperty('id')) {
        this.id = initObj.id
      }
      else {
        this.id = 0;
      }
      if (initObj.hasOwnProperty('name')) {
        this.name = initObj.name
      }
      else {
        this.name = '';
      }
      if (initObj.hasOwnProperty('robot_name')) {
        this.robot_name = initObj.robot_name
      }
      else {
        this.robot_name = '';
      }
      if (initObj.hasOwnProperty('motor_make')) {
        this.motor_make = initObj.motor_make
      }
      else {
        this.motor_make = '';
      }
      if (initObj.hasOwnProperty('motor_model')) {
        this.motor_model = initObj.motor_model
      }
      else {
        this.motor_model = '';
      }
      if (initObj.hasOwnProperty('max_current')) {
        this.max_current = initObj.max_current
      }
      else {
        this.max_current = 0.0;
      }
      if (initObj.hasOwnProperty('speed_constant')) {
        this.speed_constant = initObj.speed_constant
      }
      else {
        this.speed_constant = 0.0;
      }
      if (initObj.hasOwnProperty('motor_resistance')) {
        this.motor_resistance = initObj.motor_resistance
      }
      else {
        this.motor_resistance = 0.0;
      }
      if (initObj.hasOwnProperty('motor_torque_constant')) {
        this.motor_torque_constant = initObj.motor_torque_constant
      }
      else {
        this.motor_torque_constant = 0.0;
      }
      if (initObj.hasOwnProperty('encoder_reduction')) {
        this.encoder_reduction = initObj.encoder_reduction
      }
      else {
        this.encoder_reduction = 0.0;
      }
      if (initObj.hasOwnProperty('pulses_per_revolution')) {
        this.pulses_per_revolution = initObj.pulses_per_revolution
      }
      else {
        this.pulses_per_revolution = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ActuatorInfo
    // Serialize message field [id]
    bufferOffset = _serializer.uint32(obj.id, buffer, bufferOffset);
    // Serialize message field [name]
    bufferOffset = _serializer.string(obj.name, buffer, bufferOffset);
    // Serialize message field [robot_name]
    bufferOffset = _serializer.string(obj.robot_name, buffer, bufferOffset);
    // Serialize message field [motor_make]
    bufferOffset = _serializer.string(obj.motor_make, buffer, bufferOffset);
    // Serialize message field [motor_model]
    bufferOffset = _serializer.string(obj.motor_model, buffer, bufferOffset);
    // Serialize message field [max_current]
    bufferOffset = _serializer.float64(obj.max_current, buffer, bufferOffset);
    // Serialize message field [speed_constant]
    bufferOffset = _serializer.float64(obj.speed_constant, buffer, bufferOffset);
    // Serialize message field [motor_resistance]
    bufferOffset = _serializer.float64(obj.motor_resistance, buffer, bufferOffset);
    // Serialize message field [motor_torque_constant]
    bufferOffset = _serializer.float64(obj.motor_torque_constant, buffer, bufferOffset);
    // Serialize message field [encoder_reduction]
    bufferOffset = _serializer.float64(obj.encoder_reduction, buffer, bufferOffset);
    // Serialize message field [pulses_per_revolution]
    bufferOffset = _serializer.float64(obj.pulses_per_revolution, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ActuatorInfo
    let len;
    let data = new ActuatorInfo(null);
    // Deserialize message field [id]
    data.id = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [name]
    data.name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [robot_name]
    data.robot_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [motor_make]
    data.motor_make = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [motor_model]
    data.motor_model = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [max_current]
    data.max_current = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [speed_constant]
    data.speed_constant = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [motor_resistance]
    data.motor_resistance = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [motor_torque_constant]
    data.motor_torque_constant = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [encoder_reduction]
    data.encoder_reduction = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pulses_per_revolution]
    data.pulses_per_revolution = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.name);
    length += _getByteLength(object.robot_name);
    length += _getByteLength(object.motor_make);
    length += _getByteLength(object.motor_model);
    return length + 68;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/ActuatorInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '40f44d8ec4380adc0b63713486eecb09';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    uint32 id
    string name
    string robot_name
    string motor_make
    string motor_model
    float64 max_current
    float64 speed_constant
    float64 motor_resistance
    float64 motor_torque_constant
    float64 encoder_reduction
    float64 pulses_per_revolution
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ActuatorInfo(null);
    if (msg.id !== undefined) {
      resolved.id = msg.id;
    }
    else {
      resolved.id = 0
    }

    if (msg.name !== undefined) {
      resolved.name = msg.name;
    }
    else {
      resolved.name = ''
    }

    if (msg.robot_name !== undefined) {
      resolved.robot_name = msg.robot_name;
    }
    else {
      resolved.robot_name = ''
    }

    if (msg.motor_make !== undefined) {
      resolved.motor_make = msg.motor_make;
    }
    else {
      resolved.motor_make = ''
    }

    if (msg.motor_model !== undefined) {
      resolved.motor_model = msg.motor_model;
    }
    else {
      resolved.motor_model = ''
    }

    if (msg.max_current !== undefined) {
      resolved.max_current = msg.max_current;
    }
    else {
      resolved.max_current = 0.0
    }

    if (msg.speed_constant !== undefined) {
      resolved.speed_constant = msg.speed_constant;
    }
    else {
      resolved.speed_constant = 0.0
    }

    if (msg.motor_resistance !== undefined) {
      resolved.motor_resistance = msg.motor_resistance;
    }
    else {
      resolved.motor_resistance = 0.0
    }

    if (msg.motor_torque_constant !== undefined) {
      resolved.motor_torque_constant = msg.motor_torque_constant;
    }
    else {
      resolved.motor_torque_constant = 0.0
    }

    if (msg.encoder_reduction !== undefined) {
      resolved.encoder_reduction = msg.encoder_reduction;
    }
    else {
      resolved.encoder_reduction = 0.0
    }

    if (msg.pulses_per_revolution !== undefined) {
      resolved.pulses_per_revolution = msg.pulses_per_revolution;
    }
    else {
      resolved.pulses_per_revolution = 0.0
    }

    return resolved;
    }
};

module.exports = ActuatorInfo;
