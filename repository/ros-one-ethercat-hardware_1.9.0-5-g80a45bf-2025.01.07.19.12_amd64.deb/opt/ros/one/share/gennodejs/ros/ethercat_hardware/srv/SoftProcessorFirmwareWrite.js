// Auto-generated. Do not edit!

// (in-package ethercat_hardware.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------


//-----------------------------------------------------------

class SoftProcessorFirmwareWriteRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.actuator_name = null;
      this.processor_name = null;
      this.instructions = null;
    }
    else {
      if (initObj.hasOwnProperty('actuator_name')) {
        this.actuator_name = initObj.actuator_name
      }
      else {
        this.actuator_name = '';
      }
      if (initObj.hasOwnProperty('processor_name')) {
        this.processor_name = initObj.processor_name
      }
      else {
        this.processor_name = '';
      }
      if (initObj.hasOwnProperty('instructions')) {
        this.instructions = initObj.instructions
      }
      else {
        this.instructions = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SoftProcessorFirmwareWriteRequest
    // Serialize message field [actuator_name]
    bufferOffset = _serializer.string(obj.actuator_name, buffer, bufferOffset);
    // Serialize message field [processor_name]
    bufferOffset = _serializer.string(obj.processor_name, buffer, bufferOffset);
    // Serialize message field [instructions]
    bufferOffset = _arraySerializer.uint32(obj.instructions, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SoftProcessorFirmwareWriteRequest
    let len;
    let data = new SoftProcessorFirmwareWriteRequest(null);
    // Deserialize message field [actuator_name]
    data.actuator_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [processor_name]
    data.processor_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [instructions]
    data.instructions = _arrayDeserializer.uint32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.actuator_name);
    length += _getByteLength(object.processor_name);
    length += 4 * object.instructions.length;
    return length + 12;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ethercat_hardware/SoftProcessorFirmwareWriteRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '5234f035d5f911e880df479ac901a6e0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string actuator_name     # name of actuator that soft-processor is part of (ex : r_gripper_motor)
    string processor_name    # name of soft-processor to firmware to write
                             # certain devices may have more than one soft-processor
    uint32[] instructions    # list of firmware binary instructions 
                             # not all soft-processors instructions use all 32bits for each instruction, 
                             # non-used bit should be zero-filled
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SoftProcessorFirmwareWriteRequest(null);
    if (msg.actuator_name !== undefined) {
      resolved.actuator_name = msg.actuator_name;
    }
    else {
      resolved.actuator_name = ''
    }

    if (msg.processor_name !== undefined) {
      resolved.processor_name = msg.processor_name;
    }
    else {
      resolved.processor_name = ''
    }

    if (msg.instructions !== undefined) {
      resolved.instructions = msg.instructions;
    }
    else {
      resolved.instructions = []
    }

    return resolved;
    }
};

class SoftProcessorFirmwareWriteResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.success = null;
      this.error_msg = null;
    }
    else {
      if (initObj.hasOwnProperty('success')) {
        this.success = initObj.success
      }
      else {
        this.success = false;
      }
      if (initObj.hasOwnProperty('error_msg')) {
        this.error_msg = initObj.error_msg
      }
      else {
        this.error_msg = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SoftProcessorFirmwareWriteResponse
    // Serialize message field [success]
    bufferOffset = _serializer.bool(obj.success, buffer, bufferOffset);
    // Serialize message field [error_msg]
    bufferOffset = _serializer.string(obj.error_msg, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SoftProcessorFirmwareWriteResponse
    let len;
    let data = new SoftProcessorFirmwareWriteResponse(null);
    // Deserialize message field [success]
    data.success = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [error_msg]
    data.error_msg = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.error_msg);
    return length + 5;
  }

  static datatype() {
    // Returns string type for a service object
    return 'ethercat_hardware/SoftProcessorFirmwareWriteResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'd006c48be24db1173a071ca9af4c8179';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool success             # true if firmware was successfully writen to device
    string error_msg         # descriptive error message if call was not successful
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SoftProcessorFirmwareWriteResponse(null);
    if (msg.success !== undefined) {
      resolved.success = msg.success;
    }
    else {
      resolved.success = false
    }

    if (msg.error_msg !== undefined) {
      resolved.error_msg = msg.error_msg;
    }
    else {
      resolved.error_msg = ''
    }

    return resolved;
    }
};

module.exports = {
  Request: SoftProcessorFirmwareWriteRequest,
  Response: SoftProcessorFirmwareWriteResponse,
  md5sum() { return '4505835b16c43769db7131458325563c'; },
  datatype() { return 'ethercat_hardware/SoftProcessorFirmwareWrite'; }
};
