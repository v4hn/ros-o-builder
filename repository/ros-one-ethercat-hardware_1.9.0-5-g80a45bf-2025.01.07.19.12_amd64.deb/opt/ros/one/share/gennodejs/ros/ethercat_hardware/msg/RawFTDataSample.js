// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class RawFTDataSample {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.sample_count = null;
      this.data = null;
      this.vhalf = null;
    }
    else {
      if (initObj.hasOwnProperty('sample_count')) {
        this.sample_count = initObj.sample_count
      }
      else {
        this.sample_count = 0;
      }
      if (initObj.hasOwnProperty('data')) {
        this.data = initObj.data
      }
      else {
        this.data = [];
      }
      if (initObj.hasOwnProperty('vhalf')) {
        this.vhalf = initObj.vhalf
      }
      else {
        this.vhalf = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type RawFTDataSample
    // Serialize message field [sample_count]
    bufferOffset = _serializer.uint64(obj.sample_count, buffer, bufferOffset);
    // Serialize message field [data]
    bufferOffset = _arraySerializer.int16(obj.data, buffer, bufferOffset, null);
    // Serialize message field [vhalf]
    bufferOffset = _serializer.uint16(obj.vhalf, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type RawFTDataSample
    let len;
    let data = new RawFTDataSample(null);
    // Deserialize message field [sample_count]
    data.sample_count = _deserializer.uint64(buffer, bufferOffset);
    // Deserialize message field [data]
    data.data = _arrayDeserializer.int16(buffer, bufferOffset, null)
    // Deserialize message field [vhalf]
    data.vhalf = _deserializer.uint16(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 2 * object.data.length;
    return length + 14;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/RawFTDataSample';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '6c3b6e352fd24802b2d95b606df80de6';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # One raw Data sample from WG035 F/T input via WG006 (gripper MCB).
    uint64  sample_count
    int16[] data
    uint16  vhalf
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new RawFTDataSample(null);
    if (msg.sample_count !== undefined) {
      resolved.sample_count = msg.sample_count;
    }
    else {
      resolved.sample_count = 0
    }

    if (msg.data !== undefined) {
      resolved.data = msg.data;
    }
    else {
      resolved.data = []
    }

    if (msg.vhalf !== undefined) {
      resolved.vhalf = msg.vhalf;
    }
    else {
      resolved.vhalf = 0
    }

    return resolved;
    }
};

module.exports = RawFTDataSample;
