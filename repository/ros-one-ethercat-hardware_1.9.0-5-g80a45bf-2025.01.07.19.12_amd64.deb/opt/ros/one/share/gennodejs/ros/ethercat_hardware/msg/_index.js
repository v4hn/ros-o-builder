
"use strict";

let BoardInfo = require('./BoardInfo.js');
let MotorTemperature = require('./MotorTemperature.js');
let MotorTrace = require('./MotorTrace.js');
let ActuatorInfo = require('./ActuatorInfo.js');
let RawFTData = require('./RawFTData.js');
let RawFTDataSample = require('./RawFTDataSample.js');
let MotorTraceSample = require('./MotorTraceSample.js');

module.exports = {
  BoardInfo: BoardInfo,
  MotorTemperature: MotorTemperature,
  MotorTrace: MotorTrace,
  ActuatorInfo: ActuatorInfo,
  RawFTData: RawFTData,
  RawFTDataSample: RawFTDataSample,
  MotorTraceSample: MotorTraceSample,
};
