
"use strict";

let SoftProcessorFirmwareWrite = require('./SoftProcessorFirmwareWrite.js')
let SoftProcessorFirmwareRead = require('./SoftProcessorFirmwareRead.js')
let SoftProcessorReset = require('./SoftProcessorReset.js')

module.exports = {
  SoftProcessorFirmwareWrite: SoftProcessorFirmwareWrite,
  SoftProcessorFirmwareRead: SoftProcessorFirmwareRead,
  SoftProcessorReset: SoftProcessorReset,
};
