// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class BoardInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.description = null;
      this.product_code = null;
      this.pcb = null;
      this.pca = null;
      this.serial = null;
      this.firmware_major = null;
      this.firmware_minor = null;
      this.board_resistance = null;
      this.max_pwm_ratio = null;
      this.hw_max_current = null;
      this.poor_measured_motor_voltage = null;
    }
    else {
      if (initObj.hasOwnProperty('description')) {
        this.description = initObj.description
      }
      else {
        this.description = '';
      }
      if (initObj.hasOwnProperty('product_code')) {
        this.product_code = initObj.product_code
      }
      else {
        this.product_code = 0;
      }
      if (initObj.hasOwnProperty('pcb')) {
        this.pcb = initObj.pcb
      }
      else {
        this.pcb = 0;
      }
      if (initObj.hasOwnProperty('pca')) {
        this.pca = initObj.pca
      }
      else {
        this.pca = 0;
      }
      if (initObj.hasOwnProperty('serial')) {
        this.serial = initObj.serial
      }
      else {
        this.serial = 0;
      }
      if (initObj.hasOwnProperty('firmware_major')) {
        this.firmware_major = initObj.firmware_major
      }
      else {
        this.firmware_major = 0;
      }
      if (initObj.hasOwnProperty('firmware_minor')) {
        this.firmware_minor = initObj.firmware_minor
      }
      else {
        this.firmware_minor = 0;
      }
      if (initObj.hasOwnProperty('board_resistance')) {
        this.board_resistance = initObj.board_resistance
      }
      else {
        this.board_resistance = 0.0;
      }
      if (initObj.hasOwnProperty('max_pwm_ratio')) {
        this.max_pwm_ratio = initObj.max_pwm_ratio
      }
      else {
        this.max_pwm_ratio = 0.0;
      }
      if (initObj.hasOwnProperty('hw_max_current')) {
        this.hw_max_current = initObj.hw_max_current
      }
      else {
        this.hw_max_current = 0.0;
      }
      if (initObj.hasOwnProperty('poor_measured_motor_voltage')) {
        this.poor_measured_motor_voltage = initObj.poor_measured_motor_voltage
      }
      else {
        this.poor_measured_motor_voltage = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type BoardInfo
    // Serialize message field [description]
    bufferOffset = _serializer.string(obj.description, buffer, bufferOffset);
    // Serialize message field [product_code]
    bufferOffset = _serializer.uint32(obj.product_code, buffer, bufferOffset);
    // Serialize message field [pcb]
    bufferOffset = _serializer.uint32(obj.pcb, buffer, bufferOffset);
    // Serialize message field [pca]
    bufferOffset = _serializer.uint32(obj.pca, buffer, bufferOffset);
    // Serialize message field [serial]
    bufferOffset = _serializer.uint32(obj.serial, buffer, bufferOffset);
    // Serialize message field [firmware_major]
    bufferOffset = _serializer.uint32(obj.firmware_major, buffer, bufferOffset);
    // Serialize message field [firmware_minor]
    bufferOffset = _serializer.uint32(obj.firmware_minor, buffer, bufferOffset);
    // Serialize message field [board_resistance]
    bufferOffset = _serializer.float64(obj.board_resistance, buffer, bufferOffset);
    // Serialize message field [max_pwm_ratio]
    bufferOffset = _serializer.float64(obj.max_pwm_ratio, buffer, bufferOffset);
    // Serialize message field [hw_max_current]
    bufferOffset = _serializer.float64(obj.hw_max_current, buffer, bufferOffset);
    // Serialize message field [poor_measured_motor_voltage]
    bufferOffset = _serializer.bool(obj.poor_measured_motor_voltage, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type BoardInfo
    let len;
    let data = new BoardInfo(null);
    // Deserialize message field [description]
    data.description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [product_code]
    data.product_code = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [pcb]
    data.pcb = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [pca]
    data.pca = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [serial]
    data.serial = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [firmware_major]
    data.firmware_major = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [firmware_minor]
    data.firmware_minor = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [board_resistance]
    data.board_resistance = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [max_pwm_ratio]
    data.max_pwm_ratio = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [hw_max_current]
    data.hw_max_current = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [poor_measured_motor_voltage]
    data.poor_measured_motor_voltage = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.description);
    return length + 53;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/BoardInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'ffcb87ef2725c5fab7d0d8fcd4c7e7bc';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string description
    uint32 product_code
    uint32 pcb
    uint32 pca
    uint32 serial
    uint32 firmware_major
    uint32 firmware_minor
    float64 board_resistance
    float64 max_pwm_ratio
    float64 hw_max_current
    bool poor_measured_motor_voltage
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new BoardInfo(null);
    if (msg.description !== undefined) {
      resolved.description = msg.description;
    }
    else {
      resolved.description = ''
    }

    if (msg.product_code !== undefined) {
      resolved.product_code = msg.product_code;
    }
    else {
      resolved.product_code = 0
    }

    if (msg.pcb !== undefined) {
      resolved.pcb = msg.pcb;
    }
    else {
      resolved.pcb = 0
    }

    if (msg.pca !== undefined) {
      resolved.pca = msg.pca;
    }
    else {
      resolved.pca = 0
    }

    if (msg.serial !== undefined) {
      resolved.serial = msg.serial;
    }
    else {
      resolved.serial = 0
    }

    if (msg.firmware_major !== undefined) {
      resolved.firmware_major = msg.firmware_major;
    }
    else {
      resolved.firmware_major = 0
    }

    if (msg.firmware_minor !== undefined) {
      resolved.firmware_minor = msg.firmware_minor;
    }
    else {
      resolved.firmware_minor = 0
    }

    if (msg.board_resistance !== undefined) {
      resolved.board_resistance = msg.board_resistance;
    }
    else {
      resolved.board_resistance = 0.0
    }

    if (msg.max_pwm_ratio !== undefined) {
      resolved.max_pwm_ratio = msg.max_pwm_ratio;
    }
    else {
      resolved.max_pwm_ratio = 0.0
    }

    if (msg.hw_max_current !== undefined) {
      resolved.hw_max_current = msg.hw_max_current;
    }
    else {
      resolved.hw_max_current = 0.0
    }

    if (msg.poor_measured_motor_voltage !== undefined) {
      resolved.poor_measured_motor_voltage = msg.poor_measured_motor_voltage;
    }
    else {
      resolved.poor_measured_motor_voltage = false
    }

    return resolved;
    }
};

module.exports = BoardInfo;
