// Auto-generated. Do not edit!

// (in-package ethercat_hardware.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class MotorTraceSample {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.enabled = null;
      this.supply_voltage = null;
      this.measured_motor_voltage = null;
      this.programmed_pwm = null;
      this.executed_current = null;
      this.measured_current = null;
      this.velocity = null;
      this.encoder_position = null;
      this.encoder_error_count = null;
      this.motor_voltage_error_limit = null;
      this.filtered_motor_voltage_error = null;
      this.filtered_abs_motor_voltage_error = null;
      this.filtered_measured_voltage_error = null;
      this.filtered_abs_measured_voltage_error = null;
      this.filtered_current_error = null;
      this.filtered_abs_current_error = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = 0.0;
      }
      if (initObj.hasOwnProperty('enabled')) {
        this.enabled = initObj.enabled
      }
      else {
        this.enabled = false;
      }
      if (initObj.hasOwnProperty('supply_voltage')) {
        this.supply_voltage = initObj.supply_voltage
      }
      else {
        this.supply_voltage = 0.0;
      }
      if (initObj.hasOwnProperty('measured_motor_voltage')) {
        this.measured_motor_voltage = initObj.measured_motor_voltage
      }
      else {
        this.measured_motor_voltage = 0.0;
      }
      if (initObj.hasOwnProperty('programmed_pwm')) {
        this.programmed_pwm = initObj.programmed_pwm
      }
      else {
        this.programmed_pwm = 0.0;
      }
      if (initObj.hasOwnProperty('executed_current')) {
        this.executed_current = initObj.executed_current
      }
      else {
        this.executed_current = 0.0;
      }
      if (initObj.hasOwnProperty('measured_current')) {
        this.measured_current = initObj.measured_current
      }
      else {
        this.measured_current = 0.0;
      }
      if (initObj.hasOwnProperty('velocity')) {
        this.velocity = initObj.velocity
      }
      else {
        this.velocity = 0.0;
      }
      if (initObj.hasOwnProperty('encoder_position')) {
        this.encoder_position = initObj.encoder_position
      }
      else {
        this.encoder_position = 0.0;
      }
      if (initObj.hasOwnProperty('encoder_error_count')) {
        this.encoder_error_count = initObj.encoder_error_count
      }
      else {
        this.encoder_error_count = 0;
      }
      if (initObj.hasOwnProperty('motor_voltage_error_limit')) {
        this.motor_voltage_error_limit = initObj.motor_voltage_error_limit
      }
      else {
        this.motor_voltage_error_limit = 0.0;
      }
      if (initObj.hasOwnProperty('filtered_motor_voltage_error')) {
        this.filtered_motor_voltage_error = initObj.filtered_motor_voltage_error
      }
      else {
        this.filtered_motor_voltage_error = 0.0;
      }
      if (initObj.hasOwnProperty('filtered_abs_motor_voltage_error')) {
        this.filtered_abs_motor_voltage_error = initObj.filtered_abs_motor_voltage_error
      }
      else {
        this.filtered_abs_motor_voltage_error = 0.0;
      }
      if (initObj.hasOwnProperty('filtered_measured_voltage_error')) {
        this.filtered_measured_voltage_error = initObj.filtered_measured_voltage_error
      }
      else {
        this.filtered_measured_voltage_error = 0.0;
      }
      if (initObj.hasOwnProperty('filtered_abs_measured_voltage_error')) {
        this.filtered_abs_measured_voltage_error = initObj.filtered_abs_measured_voltage_error
      }
      else {
        this.filtered_abs_measured_voltage_error = 0.0;
      }
      if (initObj.hasOwnProperty('filtered_current_error')) {
        this.filtered_current_error = initObj.filtered_current_error
      }
      else {
        this.filtered_current_error = 0.0;
      }
      if (initObj.hasOwnProperty('filtered_abs_current_error')) {
        this.filtered_abs_current_error = initObj.filtered_abs_current_error
      }
      else {
        this.filtered_abs_current_error = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type MotorTraceSample
    // Serialize message field [timestamp]
    bufferOffset = _serializer.float64(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [enabled]
    bufferOffset = _serializer.bool(obj.enabled, buffer, bufferOffset);
    // Serialize message field [supply_voltage]
    bufferOffset = _serializer.float64(obj.supply_voltage, buffer, bufferOffset);
    // Serialize message field [measured_motor_voltage]
    bufferOffset = _serializer.float64(obj.measured_motor_voltage, buffer, bufferOffset);
    // Serialize message field [programmed_pwm]
    bufferOffset = _serializer.float64(obj.programmed_pwm, buffer, bufferOffset);
    // Serialize message field [executed_current]
    bufferOffset = _serializer.float64(obj.executed_current, buffer, bufferOffset);
    // Serialize message field [measured_current]
    bufferOffset = _serializer.float64(obj.measured_current, buffer, bufferOffset);
    // Serialize message field [velocity]
    bufferOffset = _serializer.float64(obj.velocity, buffer, bufferOffset);
    // Serialize message field [encoder_position]
    bufferOffset = _serializer.float64(obj.encoder_position, buffer, bufferOffset);
    // Serialize message field [encoder_error_count]
    bufferOffset = _serializer.uint32(obj.encoder_error_count, buffer, bufferOffset);
    // Serialize message field [motor_voltage_error_limit]
    bufferOffset = _serializer.float64(obj.motor_voltage_error_limit, buffer, bufferOffset);
    // Serialize message field [filtered_motor_voltage_error]
    bufferOffset = _serializer.float64(obj.filtered_motor_voltage_error, buffer, bufferOffset);
    // Serialize message field [filtered_abs_motor_voltage_error]
    bufferOffset = _serializer.float64(obj.filtered_abs_motor_voltage_error, buffer, bufferOffset);
    // Serialize message field [filtered_measured_voltage_error]
    bufferOffset = _serializer.float64(obj.filtered_measured_voltage_error, buffer, bufferOffset);
    // Serialize message field [filtered_abs_measured_voltage_error]
    bufferOffset = _serializer.float64(obj.filtered_abs_measured_voltage_error, buffer, bufferOffset);
    // Serialize message field [filtered_current_error]
    bufferOffset = _serializer.float64(obj.filtered_current_error, buffer, bufferOffset);
    // Serialize message field [filtered_abs_current_error]
    bufferOffset = _serializer.float64(obj.filtered_abs_current_error, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type MotorTraceSample
    let len;
    let data = new MotorTraceSample(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [enabled]
    data.enabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [supply_voltage]
    data.supply_voltage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [measured_motor_voltage]
    data.measured_motor_voltage = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [programmed_pwm]
    data.programmed_pwm = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [executed_current]
    data.executed_current = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [measured_current]
    data.measured_current = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [velocity]
    data.velocity = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [encoder_position]
    data.encoder_position = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [encoder_error_count]
    data.encoder_error_count = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [motor_voltage_error_limit]
    data.motor_voltage_error_limit = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [filtered_motor_voltage_error]
    data.filtered_motor_voltage_error = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [filtered_abs_motor_voltage_error]
    data.filtered_abs_motor_voltage_error = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [filtered_measured_voltage_error]
    data.filtered_measured_voltage_error = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [filtered_abs_measured_voltage_error]
    data.filtered_abs_measured_voltage_error = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [filtered_current_error]
    data.filtered_current_error = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [filtered_abs_current_error]
    data.filtered_abs_current_error = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 125;
  }

  static datatype() {
    // Returns string type for a message object
    return 'ethercat_hardware/MotorTraceSample';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '3734a66334bc2033448f9c561d39c5e0';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float64 timestamp
    bool    enabled
    float64 supply_voltage
    float64 measured_motor_voltage
    float64 programmed_pwm
    float64 executed_current
    float64 measured_current
    float64 velocity
    float64 encoder_position
    uint32  encoder_error_count
    float64 motor_voltage_error_limit
    float64 filtered_motor_voltage_error
    float64 filtered_abs_motor_voltage_error
    float64 filtered_measured_voltage_error
    float64 filtered_abs_measured_voltage_error
    float64 filtered_current_error
    float64 filtered_abs_current_error
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new MotorTraceSample(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = 0.0
    }

    if (msg.enabled !== undefined) {
      resolved.enabled = msg.enabled;
    }
    else {
      resolved.enabled = false
    }

    if (msg.supply_voltage !== undefined) {
      resolved.supply_voltage = msg.supply_voltage;
    }
    else {
      resolved.supply_voltage = 0.0
    }

    if (msg.measured_motor_voltage !== undefined) {
      resolved.measured_motor_voltage = msg.measured_motor_voltage;
    }
    else {
      resolved.measured_motor_voltage = 0.0
    }

    if (msg.programmed_pwm !== undefined) {
      resolved.programmed_pwm = msg.programmed_pwm;
    }
    else {
      resolved.programmed_pwm = 0.0
    }

    if (msg.executed_current !== undefined) {
      resolved.executed_current = msg.executed_current;
    }
    else {
      resolved.executed_current = 0.0
    }

    if (msg.measured_current !== undefined) {
      resolved.measured_current = msg.measured_current;
    }
    else {
      resolved.measured_current = 0.0
    }

    if (msg.velocity !== undefined) {
      resolved.velocity = msg.velocity;
    }
    else {
      resolved.velocity = 0.0
    }

    if (msg.encoder_position !== undefined) {
      resolved.encoder_position = msg.encoder_position;
    }
    else {
      resolved.encoder_position = 0.0
    }

    if (msg.encoder_error_count !== undefined) {
      resolved.encoder_error_count = msg.encoder_error_count;
    }
    else {
      resolved.encoder_error_count = 0
    }

    if (msg.motor_voltage_error_limit !== undefined) {
      resolved.motor_voltage_error_limit = msg.motor_voltage_error_limit;
    }
    else {
      resolved.motor_voltage_error_limit = 0.0
    }

    if (msg.filtered_motor_voltage_error !== undefined) {
      resolved.filtered_motor_voltage_error = msg.filtered_motor_voltage_error;
    }
    else {
      resolved.filtered_motor_voltage_error = 0.0
    }

    if (msg.filtered_abs_motor_voltage_error !== undefined) {
      resolved.filtered_abs_motor_voltage_error = msg.filtered_abs_motor_voltage_error;
    }
    else {
      resolved.filtered_abs_motor_voltage_error = 0.0
    }

    if (msg.filtered_measured_voltage_error !== undefined) {
      resolved.filtered_measured_voltage_error = msg.filtered_measured_voltage_error;
    }
    else {
      resolved.filtered_measured_voltage_error = 0.0
    }

    if (msg.filtered_abs_measured_voltage_error !== undefined) {
      resolved.filtered_abs_measured_voltage_error = msg.filtered_abs_measured_voltage_error;
    }
    else {
      resolved.filtered_abs_measured_voltage_error = 0.0
    }

    if (msg.filtered_current_error !== undefined) {
      resolved.filtered_current_error = msg.filtered_current_error;
    }
    else {
      resolved.filtered_current_error = 0.0
    }

    if (msg.filtered_abs_current_error !== undefined) {
      resolved.filtered_abs_current_error = msg.filtered_abs_current_error;
    }
    else {
      resolved.filtered_abs_current_error = 0.0
    }

    return resolved;
    }
};

module.exports = MotorTraceSample;
