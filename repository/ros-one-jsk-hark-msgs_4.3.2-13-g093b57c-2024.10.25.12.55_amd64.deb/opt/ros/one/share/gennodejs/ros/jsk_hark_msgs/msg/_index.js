
"use strict";

let HarkPower = require('./HarkPower.js');

module.exports = {
  HarkPower: HarkPower,
};
