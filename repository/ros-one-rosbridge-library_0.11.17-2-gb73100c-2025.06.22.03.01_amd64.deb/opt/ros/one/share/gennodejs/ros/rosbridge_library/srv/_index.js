
"use strict";

let AddTwoInts = require('./AddTwoInts.js')
let TestMultipleResponseFields = require('./TestMultipleResponseFields.js')
let TestMultipleRequestFields = require('./TestMultipleRequestFields.js')
let TestRequestOnly = require('./TestRequestOnly.js')
let TestNestedService = require('./TestNestedService.js')
let TestArrayRequest = require('./TestArrayRequest.js')
let TestResponseOnly = require('./TestResponseOnly.js')
let TestRequestAndResponse = require('./TestRequestAndResponse.js')
let TestEmpty = require('./TestEmpty.js')
let SendBytes = require('./SendBytes.js')

module.exports = {
  AddTwoInts: AddTwoInts,
  TestMultipleResponseFields: TestMultipleResponseFields,
  TestMultipleRequestFields: TestMultipleRequestFields,
  TestRequestOnly: TestRequestOnly,
  TestNestedService: TestNestedService,
  TestArrayRequest: TestArrayRequest,
  TestResponseOnly: TestResponseOnly,
  TestRequestAndResponse: TestRequestAndResponse,
  TestEmpty: TestEmpty,
  SendBytes: SendBytes,
};
