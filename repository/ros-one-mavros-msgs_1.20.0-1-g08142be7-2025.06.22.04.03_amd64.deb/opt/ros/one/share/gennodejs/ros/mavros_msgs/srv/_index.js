
"use strict";

let FileRemove = require('./FileRemove.js')
let CommandAck = require('./CommandAck.js')
let ParamSet = require('./ParamSet.js')
let WaypointClear = require('./WaypointClear.js')
let WaypointPull = require('./WaypointPull.js')
let FileOpen = require('./FileOpen.js')
let FileChecksum = require('./FileChecksum.js')
let CommandVtolTransition = require('./CommandVtolTransition.js')
let LogRequestEnd = require('./LogRequestEnd.js')
let SetMode = require('./SetMode.js')
let FileRemoveDir = require('./FileRemoveDir.js')
let CommandHome = require('./CommandHome.js')
let FileRename = require('./FileRename.js')
let CommandBool = require('./CommandBool.js')
let MessageInterval = require('./MessageInterval.js')
let LogRequestData = require('./LogRequestData.js')
let SetMavFrame = require('./SetMavFrame.js')
let WaypointSetCurrent = require('./WaypointSetCurrent.js')
let CommandInt = require('./CommandInt.js')
let VehicleInfoGet = require('./VehicleInfoGet.js')
let ParamGet = require('./ParamGet.js')
let CommandTriggerInterval = require('./CommandTriggerInterval.js')
let FileClose = require('./FileClose.js')
let FileMakeDir = require('./FileMakeDir.js')
let FileRead = require('./FileRead.js')
let CommandLong = require('./CommandLong.js')
let FileList = require('./FileList.js')
let CommandTriggerControl = require('./CommandTriggerControl.js')
let FileWrite = require('./FileWrite.js')
let ParamPush = require('./ParamPush.js')
let FileTruncate = require('./FileTruncate.js')
let LogRequestList = require('./LogRequestList.js')
let CommandTOL = require('./CommandTOL.js')
let WaypointPush = require('./WaypointPush.js')
let StreamRate = require('./StreamRate.js')
let ParamPull = require('./ParamPull.js')
let MountConfigure = require('./MountConfigure.js')

module.exports = {
  FileRemove: FileRemove,
  CommandAck: CommandAck,
  ParamSet: ParamSet,
  WaypointClear: WaypointClear,
  WaypointPull: WaypointPull,
  FileOpen: FileOpen,
  FileChecksum: FileChecksum,
  CommandVtolTransition: CommandVtolTransition,
  LogRequestEnd: LogRequestEnd,
  SetMode: SetMode,
  FileRemoveDir: FileRemoveDir,
  CommandHome: CommandHome,
  FileRename: FileRename,
  CommandBool: CommandBool,
  MessageInterval: MessageInterval,
  LogRequestData: LogRequestData,
  SetMavFrame: SetMavFrame,
  WaypointSetCurrent: WaypointSetCurrent,
  CommandInt: CommandInt,
  VehicleInfoGet: VehicleInfoGet,
  ParamGet: ParamGet,
  CommandTriggerInterval: CommandTriggerInterval,
  FileClose: FileClose,
  FileMakeDir: FileMakeDir,
  FileRead: FileRead,
  CommandLong: CommandLong,
  FileList: FileList,
  CommandTriggerControl: CommandTriggerControl,
  FileWrite: FileWrite,
  ParamPush: ParamPush,
  FileTruncate: FileTruncate,
  LogRequestList: LogRequestList,
  CommandTOL: CommandTOL,
  WaypointPush: WaypointPush,
  StreamRate: StreamRate,
  ParamPull: ParamPull,
  MountConfigure: MountConfigure,
};
