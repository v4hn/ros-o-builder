set(image_cb_detector_MESSAGE_FILES "msg/ConfigAction.msg;msg/ConfigActionGoal.msg;msg/ConfigActionResult.msg;msg/ConfigActionFeedback.msg;msg/ConfigGoal.msg;msg/ConfigResult.msg;msg/ConfigFeedback.msg;msg/ImagePoint.msg;msg/ObjectInImage.msg")
set(image_cb_detector_SERVICE_FILES "")
