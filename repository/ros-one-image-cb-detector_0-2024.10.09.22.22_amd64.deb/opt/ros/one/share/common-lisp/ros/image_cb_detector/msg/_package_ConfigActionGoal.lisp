(cl:in-package image_cb_detector-msg)
(cl:export '(HEADER-VAL
          HEADER
          GOAL_ID-VAL
          GOAL_ID
          GOAL-VAL
          GOAL
))