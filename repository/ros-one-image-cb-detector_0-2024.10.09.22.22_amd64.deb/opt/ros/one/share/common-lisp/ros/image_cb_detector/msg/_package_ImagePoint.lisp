(cl:in-package image_cb_detector-msg)
(cl:export '(X-VAL
          X
          Y-VAL
          Y
))