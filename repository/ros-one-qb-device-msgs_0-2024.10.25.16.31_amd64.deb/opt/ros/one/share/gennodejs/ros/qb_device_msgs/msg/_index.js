
"use strict";

let DeviceConnectionInfo = require('./DeviceConnectionInfo.js');
let StateStamped = require('./StateStamped.js');
let ResourceData = require('./ResourceData.js');
let Info = require('./Info.js');
let State = require('./State.js');
let ConnectionState = require('./ConnectionState.js');

module.exports = {
  DeviceConnectionInfo: DeviceConnectionInfo,
  StateStamped: StateStamped,
  ResourceData: ResourceData,
  Info: Info,
  State: State,
  ConnectionState: ConnectionState,
};
