
"use strict";

let Pose = require('./Pose.js');
let Color = require('./Color.js');

module.exports = {
  Pose: Pose,
  Color: Color,
};
