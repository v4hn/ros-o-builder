
"use strict";

let FibonacciFeedback = require('./FibonacciFeedback.js');
let AveragingAction = require('./AveragingAction.js');
let FibonacciAction = require('./FibonacciAction.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let AveragingResult = require('./AveragingResult.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let FibonacciResult = require('./FibonacciResult.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let AveragingGoal = require('./AveragingGoal.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');

module.exports = {
  FibonacciFeedback: FibonacciFeedback,
  AveragingAction: AveragingAction,
  FibonacciAction: FibonacciAction,
  AveragingActionGoal: AveragingActionGoal,
  AveragingActionResult: AveragingActionResult,
  AveragingActionFeedback: AveragingActionFeedback,
  FibonacciGoal: FibonacciGoal,
  FibonacciActionGoal: FibonacciActionGoal,
  AveragingResult: AveragingResult,
  FibonacciActionFeedback: FibonacciActionFeedback,
  FibonacciResult: FibonacciResult,
  AveragingFeedback: AveragingFeedback,
  AveragingGoal: AveragingGoal,
  FibonacciActionResult: FibonacciActionResult,
};
