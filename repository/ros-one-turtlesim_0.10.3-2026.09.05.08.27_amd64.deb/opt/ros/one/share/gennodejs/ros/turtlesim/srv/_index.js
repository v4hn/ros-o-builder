
"use strict";

let TeleportRelative = require('./TeleportRelative.js')
let Spawn = require('./Spawn.js')
let Kill = require('./Kill.js')
let SetPen = require('./SetPen.js')
let TeleportAbsolute = require('./TeleportAbsolute.js')

module.exports = {
  TeleportRelative: TeleportRelative,
  Spawn: Spawn,
  Kill: Kill,
  SetPen: SetPen,
  TeleportAbsolute: TeleportAbsolute,
};
