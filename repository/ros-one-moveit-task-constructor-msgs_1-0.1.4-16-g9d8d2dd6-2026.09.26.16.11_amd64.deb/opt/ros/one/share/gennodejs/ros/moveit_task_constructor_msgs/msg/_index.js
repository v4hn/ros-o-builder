
"use strict";

let StageDescription = require('./StageDescription.js');
let TaskDescription = require('./TaskDescription.js');
let StageStatistics = require('./StageStatistics.js');
let SubSolution = require('./SubSolution.js');
let TaskStatistics = require('./TaskStatistics.js');
let TrajectoryExecutionInfo = require('./TrajectoryExecutionInfo.js');
let Solution = require('./Solution.js');
let Property = require('./Property.js');
let SubTrajectory = require('./SubTrajectory.js');
let SolutionInfo = require('./SolutionInfo.js');
let ExecuteTaskSolutionActionFeedback = require('./ExecuteTaskSolutionActionFeedback.js');
let ExecuteTaskSolutionResult = require('./ExecuteTaskSolutionResult.js');
let ExecuteTaskSolutionAction = require('./ExecuteTaskSolutionAction.js');
let ExecuteTaskSolutionFeedback = require('./ExecuteTaskSolutionFeedback.js');
let ExecuteTaskSolutionActionResult = require('./ExecuteTaskSolutionActionResult.js');
let ExecuteTaskSolutionGoal = require('./ExecuteTaskSolutionGoal.js');
let ExecuteTaskSolutionActionGoal = require('./ExecuteTaskSolutionActionGoal.js');

module.exports = {
  StageDescription: StageDescription,
  TaskDescription: TaskDescription,
  StageStatistics: StageStatistics,
  SubSolution: SubSolution,
  TaskStatistics: TaskStatistics,
  TrajectoryExecutionInfo: TrajectoryExecutionInfo,
  Solution: Solution,
  Property: Property,
  SubTrajectory: SubTrajectory,
  SolutionInfo: SolutionInfo,
  ExecuteTaskSolutionActionFeedback: ExecuteTaskSolutionActionFeedback,
  ExecuteTaskSolutionResult: ExecuteTaskSolutionResult,
  ExecuteTaskSolutionAction: ExecuteTaskSolutionAction,
  ExecuteTaskSolutionFeedback: ExecuteTaskSolutionFeedback,
  ExecuteTaskSolutionActionResult: ExecuteTaskSolutionActionResult,
  ExecuteTaskSolutionGoal: ExecuteTaskSolutionGoal,
  ExecuteTaskSolutionActionGoal: ExecuteTaskSolutionActionGoal,
};
