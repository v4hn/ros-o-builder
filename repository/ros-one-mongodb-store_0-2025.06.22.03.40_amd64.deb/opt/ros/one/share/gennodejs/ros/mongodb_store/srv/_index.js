
"use strict";

let SetParam = require('./SetParam.js')
let MongoInsert = require('./MongoInsert.js')
let MongoUpdate = require('./MongoUpdate.js')
let MongoFind = require('./MongoFind.js')
let GetParam = require('./GetParam.js')

module.exports = {
  SetParam: SetParam,
  MongoInsert: MongoInsert,
  MongoUpdate: MongoUpdate,
  MongoFind: MongoFind,
  GetParam: GetParam,
};
