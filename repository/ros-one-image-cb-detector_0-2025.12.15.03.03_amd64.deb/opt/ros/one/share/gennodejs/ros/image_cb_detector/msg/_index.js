
"use strict";

let ConfigActionFeedback = require('./ConfigActionFeedback.js');
let ConfigActionResult = require('./ConfigActionResult.js');
let ConfigResult = require('./ConfigResult.js');
let ConfigGoal = require('./ConfigGoal.js');
let ConfigAction = require('./ConfigAction.js');
let ConfigActionGoal = require('./ConfigActionGoal.js');
let ConfigFeedback = require('./ConfigFeedback.js');
let ObjectInImage = require('./ObjectInImage.js');
let ImagePoint = require('./ImagePoint.js');

module.exports = {
  ConfigActionFeedback: ConfigActionFeedback,
  ConfigActionResult: ConfigActionResult,
  ConfigResult: ConfigResult,
  ConfigGoal: ConfigGoal,
  ConfigAction: ConfigAction,
  ConfigActionGoal: ConfigActionGoal,
  ConfigFeedback: ConfigFeedback,
  ObjectInImage: ObjectInImage,
  ImagePoint: ImagePoint,
};
