// Auto-generated. Do not edit!

// (in-package pgm_learner.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let GraphStructure = require('../msg/GraphStructure.js');
let LinearGaussianGraphState = require('../msg/LinearGaussianGraphState.js');

//-----------------------------------------------------------

let LinearGaussianNode = require('../msg/LinearGaussianNode.js');

//-----------------------------------------------------------

class LinearGaussianParameterEstimationRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.graph = null;
      this.states = null;
    }
    else {
      if (initObj.hasOwnProperty('graph')) {
        this.graph = initObj.graph
      }
      else {
        this.graph = new GraphStructure();
      }
      if (initObj.hasOwnProperty('states')) {
        this.states = initObj.states
      }
      else {
        this.states = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinearGaussianParameterEstimationRequest
    // Serialize message field [graph]
    bufferOffset = GraphStructure.serialize(obj.graph, buffer, bufferOffset);
    // Serialize message field [states]
    // Serialize the length for message field [states]
    bufferOffset = _serializer.uint32(obj.states.length, buffer, bufferOffset);
    obj.states.forEach((val) => {
      bufferOffset = LinearGaussianGraphState.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinearGaussianParameterEstimationRequest
    let len;
    let data = new LinearGaussianParameterEstimationRequest(null);
    // Deserialize message field [graph]
    data.graph = GraphStructure.deserialize(buffer, bufferOffset);
    // Deserialize message field [states]
    // Deserialize array length for message field [states]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.states = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.states[i] = LinearGaussianGraphState.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += GraphStructure.getMessageSize(object.graph);
    object.states.forEach((val) => {
      length += LinearGaussianGraphState.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/LinearGaussianParameterEstimationRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8c1ba4d6cf70003845d5e35223229532';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/GraphStructure graph # graph skeleton
    pgm_learner/LinearGaussianGraphState[] states # trial data
    
    ================================================================================
    MSG: pgm_learner/GraphStructure
    string[] nodes
    pgm_learner/GraphEdge[] edges
    
    ================================================================================
    MSG: pgm_learner/GraphEdge
    string node_from
    string node_to
    
    ================================================================================
    MSG: pgm_learner/LinearGaussianGraphState
    pgm_learner/LinearGaussianNodeState[] node_states
    
    ================================================================================
    MSG: pgm_learner/LinearGaussianNodeState
    string node
    float32 state
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinearGaussianParameterEstimationRequest(null);
    if (msg.graph !== undefined) {
      resolved.graph = GraphStructure.Resolve(msg.graph)
    }
    else {
      resolved.graph = new GraphStructure()
    }

    if (msg.states !== undefined) {
      resolved.states = new Array(msg.states.length);
      for (let i = 0; i < resolved.states.length; ++i) {
        resolved.states[i] = LinearGaussianGraphState.Resolve(msg.states[i]);
      }
    }
    else {
      resolved.states = []
    }

    return resolved;
    }
};

class LinearGaussianParameterEstimationResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.nodes = null;
    }
    else {
      if (initObj.hasOwnProperty('nodes')) {
        this.nodes = initObj.nodes
      }
      else {
        this.nodes = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type LinearGaussianParameterEstimationResponse
    // Serialize message field [nodes]
    // Serialize the length for message field [nodes]
    bufferOffset = _serializer.uint32(obj.nodes.length, buffer, bufferOffset);
    obj.nodes.forEach((val) => {
      bufferOffset = LinearGaussianNode.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type LinearGaussianParameterEstimationResponse
    let len;
    let data = new LinearGaussianParameterEstimationResponse(null);
    // Deserialize message field [nodes]
    // Deserialize array length for message field [nodes]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.nodes = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.nodes[i] = LinearGaussianNode.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.nodes.forEach((val) => {
      length += LinearGaussianNode.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'pgm_learner/LinearGaussianParameterEstimationResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f083fa6aa9eee204da186b10e3de3230';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    pgm_learner/LinearGaussianNode[] nodes # information of each nodes
    
    
    ================================================================================
    MSG: pgm_learner/LinearGaussianNode
    string name
    string[] parents
    string[] children
    
    float32 mean
    float32 variance
    
    float32[] mean_scalar # scalar for parents
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new LinearGaussianParameterEstimationResponse(null);
    if (msg.nodes !== undefined) {
      resolved.nodes = new Array(msg.nodes.length);
      for (let i = 0; i < resolved.nodes.length; ++i) {
        resolved.nodes[i] = LinearGaussianNode.Resolve(msg.nodes[i]);
      }
    }
    else {
      resolved.nodes = []
    }

    return resolved;
    }
};

module.exports = {
  Request: LinearGaussianParameterEstimationRequest,
  Response: LinearGaussianParameterEstimationResponse,
  md5sum() { return '0dcac92874fe4c5badf892fef99ed657'; },
  datatype() { return 'pgm_learner/LinearGaussianParameterEstimation'; }
};
