
"use strict";

let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');

module.exports = {
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorGoal: FaceDetectorGoal,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorActionResult: FaceDetectorActionResult,
};
