
"use strict";

let Duration = require('./Duration.js');
let UInt8 = require('./UInt8.js');
let Int64 = require('./Int64.js');
let Int32 = require('./Int32.js');
let Char = require('./Char.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let UInt32 = require('./UInt32.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let Empty = require('./Empty.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let Byte = require('./Byte.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let Int16 = require('./Int16.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let Time = require('./Time.js');
let Float64 = require('./Float64.js');
let String = require('./String.js');
let Bool = require('./Bool.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Float32 = require('./Float32.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let UInt16 = require('./UInt16.js');
let Int8 = require('./Int8.js');
let UInt64 = require('./UInt64.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let ColorRGBA = require('./ColorRGBA.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Header = require('./Header.js');
let Float64MultiArray = require('./Float64MultiArray.js');

module.exports = {
  Duration: Duration,
  UInt8: UInt8,
  Int64: Int64,
  Int32: Int32,
  Char: Char,
  Float32MultiArray: Float32MultiArray,
  UInt32: UInt32,
  MultiArrayLayout: MultiArrayLayout,
  Empty: Empty,
  UInt8MultiArray: UInt8MultiArray,
  Int8MultiArray: Int8MultiArray,
  Byte: Byte,
  Int16MultiArray: Int16MultiArray,
  Int16: Int16,
  Int32MultiArray: Int32MultiArray,
  Time: Time,
  Float64: Float64,
  String: String,
  Bool: Bool,
  Int64MultiArray: Int64MultiArray,
  MultiArrayDimension: MultiArrayDimension,
  Float32: Float32,
  UInt16MultiArray: UInt16MultiArray,
  ByteMultiArray: ByteMultiArray,
  UInt16: UInt16,
  Int8: Int8,
  UInt64: UInt64,
  UInt64MultiArray: UInt64MultiArray,
  ColorRGBA: ColorRGBA,
  UInt32MultiArray: UInt32MultiArray,
  Header: Header,
  Float64MultiArray: Float64MultiArray,
};
