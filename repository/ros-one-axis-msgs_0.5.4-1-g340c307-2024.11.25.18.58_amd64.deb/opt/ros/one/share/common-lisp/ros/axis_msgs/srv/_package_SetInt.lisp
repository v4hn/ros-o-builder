(cl:in-package axis_msgs-srv)
(cl:export '(DATA-VAL
          DATA
          SUCCESS-VAL
          SUCCESS
          MESSAGE-VAL
          MESSAGE
))