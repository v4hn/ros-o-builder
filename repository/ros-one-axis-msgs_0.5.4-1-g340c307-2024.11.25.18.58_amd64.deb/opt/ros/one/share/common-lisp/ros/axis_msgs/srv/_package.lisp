(cl:defpackage axis_msgs-srv
  (:use )
  (:export
   "SETINT"
   "<SETINT-REQUEST>"
   "SETINT-REQUEST"
   "<SETINT-RESPONSE>"
   "SETINT-RESPONSE"
  ))

