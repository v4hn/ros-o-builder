(cl:in-package axis_msgs-msg)
(cl:export '(PAN-VAL
          PAN
          TILT-VAL
          TILT
          ZOOM-VAL
          ZOOM
))