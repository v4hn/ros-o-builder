(cl:in-package axis_msgs-msg)
(cl:export '(PAN-VAL
          PAN
          TILT-VAL
          TILT
          ZOOM-VAL
          ZOOM
          PAN_SPEED-VAL
          PAN_SPEED
          TILT_SPEED-VAL
          TILT_SPEED
          ZOOM_SPEED-VAL
          ZOOM_SPEED
          FOCUS-VAL
          FOCUS
          BRIGHTNESS-VAL
          BRIGHTNESS
          IRIS-VAL
          IRIS
          AUTOFOCUS-VAL
          AUTOFOCUS
          AUTOIRIS-VAL
          AUTOIRIS
))