; Auto-generated. Do not edit!


(cl:in-package axis_msgs-msg)


;//! \htmlinclude Ptz.msg.html

(cl:defclass <Ptz> (roslisp-msg-protocol:ros-message)
  ((pan
    :reader pan
    :initarg :pan
    :type cl:float
    :initform 0.0)
   (tilt
    :reader tilt
    :initarg :tilt
    :type cl:float
    :initform 0.0)
   (zoom
    :reader zoom
    :initarg :zoom
    :type cl:float
    :initform 0.0))
)

(cl:defclass Ptz (<Ptz>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <Ptz>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'Ptz)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name axis_msgs-msg:<Ptz> is deprecated: use axis_msgs-msg:Ptz instead.")))

(cl:ensure-generic-function 'pan-val :lambda-list '(m))
(cl:defmethod pan-val ((m <Ptz>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader axis_msgs-msg:pan-val is deprecated.  Use axis_msgs-msg:pan instead.")
  (pan m))

(cl:ensure-generic-function 'tilt-val :lambda-list '(m))
(cl:defmethod tilt-val ((m <Ptz>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader axis_msgs-msg:tilt-val is deprecated.  Use axis_msgs-msg:tilt instead.")
  (tilt m))

(cl:ensure-generic-function 'zoom-val :lambda-list '(m))
(cl:defmethod zoom-val ((m <Ptz>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader axis_msgs-msg:zoom-val is deprecated.  Use axis_msgs-msg:zoom instead.")
  (zoom m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <Ptz>) ostream)
  "Serializes a message object of type '<Ptz>"
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'pan))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'tilt))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'zoom))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <Ptz>) istream)
  "Deserializes a message object of type '<Ptz>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'pan) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'tilt) (roslisp-utils:decode-single-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'zoom) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<Ptz>)))
  "Returns string type for a message object of type '<Ptz>"
  "axis_msgs/Ptz")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'Ptz)))
  "Returns string type for a message object of type 'Ptz"
  "axis_msgs/Ptz")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<Ptz>)))
  "Returns md5sum for a message object of type '<Ptz>"
  "eef4827ef5b8ba89a8c9fa0810a30294")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'Ptz)))
  "Returns md5sum for a message object of type 'Ptz"
  "eef4827ef5b8ba89a8c9fa0810a30294")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<Ptz>)))
  "Returns full string definition for message of type '<Ptz>"
  (cl:format cl:nil "# The pan position or velocity of the camera, in radians or rad/s~%# 0.0 is forward / stopped~%# + is to the left (anticlockwise)~%# - is to the right (clockwise)~%# Valid ranges:~%#  position: -pi to pi~%#  speed: -2.61 to +2.61 (max 150 deg/s)~%float32 pan~%~%# The tilt position or velocity of the camera, in radians or rad/s~%# 0.0 is parallel with the camera's base / stopped~%# + is upward~%# - is downward~%# Valid ranges:~%#  position: -pi/2 to pi/2~%#  speed: -2.61 to +2.61 (max 150 deg/s)~%float32 tilt~%~%# The camera's zoom level or speed~%# The allowed range varies depending on whether we're using position or velocity control~%# Valid ranges:~%#  position: 0 to 9999~%#  speed: -100 to 100~%float32 zoom~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'Ptz)))
  "Returns full string definition for message of type 'Ptz"
  (cl:format cl:nil "# The pan position or velocity of the camera, in radians or rad/s~%# 0.0 is forward / stopped~%# + is to the left (anticlockwise)~%# - is to the right (clockwise)~%# Valid ranges:~%#  position: -pi to pi~%#  speed: -2.61 to +2.61 (max 150 deg/s)~%float32 pan~%~%# The tilt position or velocity of the camera, in radians or rad/s~%# 0.0 is parallel with the camera's base / stopped~%# + is upward~%# - is downward~%# Valid ranges:~%#  position: -pi/2 to pi/2~%#  speed: -2.61 to +2.61 (max 150 deg/s)~%float32 tilt~%~%# The camera's zoom level or speed~%# The allowed range varies depending on whether we're using position or velocity control~%# Valid ranges:~%#  position: 0 to 9999~%#  speed: -100 to 100~%float32 zoom~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <Ptz>))
  (cl:+ 0
     4
     4
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <Ptz>))
  "Converts a ROS message object to a list"
  (cl:list 'Ptz
    (cl:cons ':pan (pan msg))
    (cl:cons ':tilt (tilt msg))
    (cl:cons ':zoom (zoom msg))
))
