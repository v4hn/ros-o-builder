
"use strict";

let Solution = require('./Solution.js');
let TaskStatistics = require('./TaskStatistics.js');
let Property = require('./Property.js');
let StageStatistics = require('./StageStatistics.js');
let TaskDescription = require('./TaskDescription.js');
let TrajectoryExecutionInfo = require('./TrajectoryExecutionInfo.js');
let SubTrajectory = require('./SubTrajectory.js');
let SolutionInfo = require('./SolutionInfo.js');
let SubSolution = require('./SubSolution.js');
let StageDescription = require('./StageDescription.js');
let ExecuteTaskSolutionResult = require('./ExecuteTaskSolutionResult.js');
let ExecuteTaskSolutionGoal = require('./ExecuteTaskSolutionGoal.js');
let ExecuteTaskSolutionActionResult = require('./ExecuteTaskSolutionActionResult.js');
let ExecuteTaskSolutionActionGoal = require('./ExecuteTaskSolutionActionGoal.js');
let ExecuteTaskSolutionActionFeedback = require('./ExecuteTaskSolutionActionFeedback.js');
let ExecuteTaskSolutionAction = require('./ExecuteTaskSolutionAction.js');
let ExecuteTaskSolutionFeedback = require('./ExecuteTaskSolutionFeedback.js');

module.exports = {
  Solution: Solution,
  TaskStatistics: TaskStatistics,
  Property: Property,
  StageStatistics: StageStatistics,
  TaskDescription: TaskDescription,
  TrajectoryExecutionInfo: TrajectoryExecutionInfo,
  SubTrajectory: SubTrajectory,
  SolutionInfo: SolutionInfo,
  SubSolution: SubSolution,
  StageDescription: StageDescription,
  ExecuteTaskSolutionResult: ExecuteTaskSolutionResult,
  ExecuteTaskSolutionGoal: ExecuteTaskSolutionGoal,
  ExecuteTaskSolutionActionResult: ExecuteTaskSolutionActionResult,
  ExecuteTaskSolutionActionGoal: ExecuteTaskSolutionActionGoal,
  ExecuteTaskSolutionActionFeedback: ExecuteTaskSolutionActionFeedback,
  ExecuteTaskSolutionAction: ExecuteTaskSolutionAction,
  ExecuteTaskSolutionFeedback: ExecuteTaskSolutionFeedback,
};
