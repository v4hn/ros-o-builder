
"use strict";

let Point2DStamped = require('./Point2DStamped.js');
let MomentArrayStamped = require('./MomentArrayStamped.js');
let Contour = require('./Contour.js');
let FlowStamped = require('./FlowStamped.js');
let FaceArrayStamped = require('./FaceArrayStamped.js');
let RotatedRectArrayStamped = require('./RotatedRectArrayStamped.js');
let RotatedRect = require('./RotatedRect.js');
let Size = require('./Size.js');
let Point2DArrayStamped = require('./Point2DArrayStamped.js');
let ContourArray = require('./ContourArray.js');
let MomentArray = require('./MomentArray.js');
let CircleArray = require('./CircleArray.js');
let Point2D = require('./Point2D.js');
let Point2DArray = require('./Point2DArray.js');
let FlowArrayStamped = require('./FlowArrayStamped.js');
let Face = require('./Face.js');
let Rect = require('./Rect.js');
let LineArray = require('./LineArray.js');
let FlowArray = require('./FlowArray.js');
let RectArrayStamped = require('./RectArrayStamped.js');
let Circle = require('./Circle.js');
let Line = require('./Line.js');
let RotatedRectStamped = require('./RotatedRectStamped.js');
let Flow = require('./Flow.js');
let Moment = require('./Moment.js');
let ContourArrayStamped = require('./ContourArrayStamped.js');
let FaceArray = require('./FaceArray.js');
let RectArray = require('./RectArray.js');
let LineArrayStamped = require('./LineArrayStamped.js');
let CircleArrayStamped = require('./CircleArrayStamped.js');
let RotatedRectArray = require('./RotatedRectArray.js');

module.exports = {
  Point2DStamped: Point2DStamped,
  MomentArrayStamped: MomentArrayStamped,
  Contour: Contour,
  FlowStamped: FlowStamped,
  FaceArrayStamped: FaceArrayStamped,
  RotatedRectArrayStamped: RotatedRectArrayStamped,
  RotatedRect: RotatedRect,
  Size: Size,
  Point2DArrayStamped: Point2DArrayStamped,
  ContourArray: ContourArray,
  MomentArray: MomentArray,
  CircleArray: CircleArray,
  Point2D: Point2D,
  Point2DArray: Point2DArray,
  FlowArrayStamped: FlowArrayStamped,
  Face: Face,
  Rect: Rect,
  LineArray: LineArray,
  FlowArray: FlowArray,
  RectArrayStamped: RectArrayStamped,
  Circle: Circle,
  Line: Line,
  RotatedRectStamped: RotatedRectStamped,
  Flow: Flow,
  Moment: Moment,
  ContourArrayStamped: ContourArrayStamped,
  FaceArray: FaceArray,
  RectArray: RectArray,
  LineArrayStamped: LineArrayStamped,
  CircleArrayStamped: CircleArrayStamped,
  RotatedRectArray: RotatedRectArray,
};
