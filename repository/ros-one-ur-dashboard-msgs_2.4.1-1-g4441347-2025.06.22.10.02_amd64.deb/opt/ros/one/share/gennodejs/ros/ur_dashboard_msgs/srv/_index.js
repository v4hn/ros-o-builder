
"use strict";

let AddToLog = require('./AddToLog.js')
let IsProgramRunning = require('./IsProgramRunning.js')
let GetProgramState = require('./GetProgramState.js')
let RawRequest = require('./RawRequest.js')
let IsInRemoteControl = require('./IsInRemoteControl.js')
let Load = require('./Load.js')
let GetRobotMode = require('./GetRobotMode.js')
let IsProgramSaved = require('./IsProgramSaved.js')
let Popup = require('./Popup.js')
let GetLoadedProgram = require('./GetLoadedProgram.js')
let GetSafetyMode = require('./GetSafetyMode.js')

module.exports = {
  AddToLog: AddToLog,
  IsProgramRunning: IsProgramRunning,
  GetProgramState: GetProgramState,
  RawRequest: RawRequest,
  IsInRemoteControl: IsInRemoteControl,
  Load: Load,
  GetRobotMode: GetRobotMode,
  IsProgramSaved: IsProgramSaved,
  Popup: Popup,
  GetLoadedProgram: GetLoadedProgram,
  GetSafetyMode: GetSafetyMode,
};
