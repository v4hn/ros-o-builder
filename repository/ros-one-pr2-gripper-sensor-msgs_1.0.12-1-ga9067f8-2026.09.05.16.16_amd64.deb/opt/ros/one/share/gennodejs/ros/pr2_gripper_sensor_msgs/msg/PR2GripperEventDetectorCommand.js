// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperEventDetectorCommand {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.trigger_conditions = null;
      this.acceleration_trigger_magnitude = null;
      this.slip_trigger_magnitude = null;
    }
    else {
      if (initObj.hasOwnProperty('trigger_conditions')) {
        this.trigger_conditions = initObj.trigger_conditions
      }
      else {
        this.trigger_conditions = 0;
      }
      if (initObj.hasOwnProperty('acceleration_trigger_magnitude')) {
        this.acceleration_trigger_magnitude = initObj.acceleration_trigger_magnitude
      }
      else {
        this.acceleration_trigger_magnitude = 0.0;
      }
      if (initObj.hasOwnProperty('slip_trigger_magnitude')) {
        this.slip_trigger_magnitude = initObj.slip_trigger_magnitude
      }
      else {
        this.slip_trigger_magnitude = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperEventDetectorCommand
    // Serialize message field [trigger_conditions]
    bufferOffset = _serializer.int8(obj.trigger_conditions, buffer, bufferOffset);
    // Serialize message field [acceleration_trigger_magnitude]
    bufferOffset = _serializer.float64(obj.acceleration_trigger_magnitude, buffer, bufferOffset);
    // Serialize message field [slip_trigger_magnitude]
    bufferOffset = _serializer.float64(obj.slip_trigger_magnitude, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperEventDetectorCommand
    let len;
    let data = new PR2GripperEventDetectorCommand(null);
    // Deserialize message field [trigger_conditions]
    data.trigger_conditions = _deserializer.int8(buffer, bufferOffset);
    // Deserialize message field [acceleration_trigger_magnitude]
    data.acceleration_trigger_magnitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [slip_trigger_magnitude]
    data.slip_trigger_magnitude = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 17;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperEventDetectorCommand';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b91a7e1e863671a84c1d06e0cac3146e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # state variable that defines what events we would like to trigger on
    # Leaving this field blank will result in the robot triggering when 
    # anything touches the sides of the finger or an impact is detected
    # with the hand/arm.
    int8 trigger_conditions
    # definitions for our various trigger_conditions values
    # trigger on either acceleration contact or finger sensor side impact
    int8 FINGER_SIDE_IMPACT_OR_ACC = 0
    # tigger once  both slip and acceleration signals occur
    int8 SLIP_AND_ACC = 1 
    #  trigger on either slip, acceleration, or finger sensor side impact
    int8 FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC = 2
    # trigger only on slip information
    int8 SLIP = 3
    # trigger only on acceleration contact information
    int8 ACC = 4 
    
    
    # the amount of acceleration to trigger on (acceleration vector magnitude)
    # Units = m/s^2
    # The user needs to be concerned here about not setting the trigger too
    # low so that is set off by the robot's own motions.
    #
    # For large rapid motions, say by a motion planner, 5 m/s^2 is a good level
    # For small delicate controlled motions this can be set MUCH lower (try 2.0)
    #
    # NOTE: When moving the gripper joint (opening/closing the grippr)
    # the high gearing of the PR2 gripper causes large acceleration vibrations
    # which will cause triggering to occur. This is a known drawback of the PR2.
    #
    # NOTE: Leaving this value blank will result in a 0 m/s^2 trigger. If you
    # are using a trigger_conditions value that returns on acceleration contact
    # events then it will immediately exceed your trigger and return
    float64 acceleration_trigger_magnitude
    
    
    # the slip detector gain to trigger on (either finger) : try 0.01
    # higher values decrease slip sensitivty (to a point)
    # lower values increase sensitivity (to a point)
    #
    # NOTE: Leaving this value blank will result in the most sensitive slip level.
    float64 slip_trigger_magnitude
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperEventDetectorCommand(null);
    if (msg.trigger_conditions !== undefined) {
      resolved.trigger_conditions = msg.trigger_conditions;
    }
    else {
      resolved.trigger_conditions = 0
    }

    if (msg.acceleration_trigger_magnitude !== undefined) {
      resolved.acceleration_trigger_magnitude = msg.acceleration_trigger_magnitude;
    }
    else {
      resolved.acceleration_trigger_magnitude = 0.0
    }

    if (msg.slip_trigger_magnitude !== undefined) {
      resolved.slip_trigger_magnitude = msg.slip_trigger_magnitude;
    }
    else {
      resolved.slip_trigger_magnitude = 0.0
    }

    return resolved;
    }
};

// Constants for message
PR2GripperEventDetectorCommand.Constants = {
  FINGER_SIDE_IMPACT_OR_ACC: 0,
  SLIP_AND_ACC: 1,
  FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC: 2,
  SLIP: 3,
  ACC: 4,
}

module.exports = PR2GripperEventDetectorCommand;
