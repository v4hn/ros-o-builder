// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperSensorRTState {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.realtime_controller_state = null;
    }
    else {
      if (initObj.hasOwnProperty('realtime_controller_state')) {
        this.realtime_controller_state = initObj.realtime_controller_state
      }
      else {
        this.realtime_controller_state = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperSensorRTState
    // Serialize message field [realtime_controller_state]
    bufferOffset = _serializer.int8(obj.realtime_controller_state, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperSensorRTState
    let len;
    let data = new PR2GripperSensorRTState(null);
    // Deserialize message field [realtime_controller_state]
    data.realtime_controller_state = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperSensorRTState';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8109436c1f7237c52c00d885ed5755d7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # the control state of our realtime controller
    int8 realtime_controller_state
    
    # predefined values to indicate our realtime_controller_state
    int8 DISABLED = 0
    int8 POSITION_SERVO = 3
    int8 FORCE_SERVO = 4
    int8 FIND_CONTACT = 5
    int8 SLIP_SERVO = 6
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperSensorRTState(null);
    if (msg.realtime_controller_state !== undefined) {
      resolved.realtime_controller_state = msg.realtime_controller_state;
    }
    else {
      resolved.realtime_controller_state = 0
    }

    return resolved;
    }
};

// Constants for message
PR2GripperSensorRTState.Constants = {
  DISABLED: 0,
  POSITION_SERVO: 3,
  FORCE_SERVO: 4,
  FIND_CONTACT: 5,
  SLIP_SERVO: 6,
}

module.exports = PR2GripperSensorRTState;
