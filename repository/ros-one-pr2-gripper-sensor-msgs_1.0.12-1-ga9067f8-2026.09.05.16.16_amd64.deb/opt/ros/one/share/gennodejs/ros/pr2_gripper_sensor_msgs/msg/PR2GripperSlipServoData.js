// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PR2GripperSensorRTState = require('./PR2GripperSensorRTState.js');

//-----------------------------------------------------------

class PR2GripperSlipServoData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.deformation = null;
      this.left_fingertip_pad_force = null;
      this.right_fingertip_pad_force = null;
      this.joint_effort = null;
      this.slip_detected = null;
      this.deformation_limit_reached = null;
      this.fingertip_force_limit_reached = null;
      this.gripper_empty = null;
      this.rtstate = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('deformation')) {
        this.deformation = initObj.deformation
      }
      else {
        this.deformation = 0.0;
      }
      if (initObj.hasOwnProperty('left_fingertip_pad_force')) {
        this.left_fingertip_pad_force = initObj.left_fingertip_pad_force
      }
      else {
        this.left_fingertip_pad_force = 0.0;
      }
      if (initObj.hasOwnProperty('right_fingertip_pad_force')) {
        this.right_fingertip_pad_force = initObj.right_fingertip_pad_force
      }
      else {
        this.right_fingertip_pad_force = 0.0;
      }
      if (initObj.hasOwnProperty('joint_effort')) {
        this.joint_effort = initObj.joint_effort
      }
      else {
        this.joint_effort = 0.0;
      }
      if (initObj.hasOwnProperty('slip_detected')) {
        this.slip_detected = initObj.slip_detected
      }
      else {
        this.slip_detected = false;
      }
      if (initObj.hasOwnProperty('deformation_limit_reached')) {
        this.deformation_limit_reached = initObj.deformation_limit_reached
      }
      else {
        this.deformation_limit_reached = false;
      }
      if (initObj.hasOwnProperty('fingertip_force_limit_reached')) {
        this.fingertip_force_limit_reached = initObj.fingertip_force_limit_reached
      }
      else {
        this.fingertip_force_limit_reached = false;
      }
      if (initObj.hasOwnProperty('gripper_empty')) {
        this.gripper_empty = initObj.gripper_empty
      }
      else {
        this.gripper_empty = false;
      }
      if (initObj.hasOwnProperty('rtstate')) {
        this.rtstate = initObj.rtstate
      }
      else {
        this.rtstate = new PR2GripperSensorRTState();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperSlipServoData
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [deformation]
    bufferOffset = _serializer.float64(obj.deformation, buffer, bufferOffset);
    // Serialize message field [left_fingertip_pad_force]
    bufferOffset = _serializer.float64(obj.left_fingertip_pad_force, buffer, bufferOffset);
    // Serialize message field [right_fingertip_pad_force]
    bufferOffset = _serializer.float64(obj.right_fingertip_pad_force, buffer, bufferOffset);
    // Serialize message field [joint_effort]
    bufferOffset = _serializer.float64(obj.joint_effort, buffer, bufferOffset);
    // Serialize message field [slip_detected]
    bufferOffset = _serializer.bool(obj.slip_detected, buffer, bufferOffset);
    // Serialize message field [deformation_limit_reached]
    bufferOffset = _serializer.bool(obj.deformation_limit_reached, buffer, bufferOffset);
    // Serialize message field [fingertip_force_limit_reached]
    bufferOffset = _serializer.bool(obj.fingertip_force_limit_reached, buffer, bufferOffset);
    // Serialize message field [gripper_empty]
    bufferOffset = _serializer.bool(obj.gripper_empty, buffer, bufferOffset);
    // Serialize message field [rtstate]
    bufferOffset = PR2GripperSensorRTState.serialize(obj.rtstate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperSlipServoData
    let len;
    let data = new PR2GripperSlipServoData(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [deformation]
    data.deformation = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_fingertip_pad_force]
    data.left_fingertip_pad_force = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_fingertip_pad_force]
    data.right_fingertip_pad_force = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [joint_effort]
    data.joint_effort = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [slip_detected]
    data.slip_detected = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [deformation_limit_reached]
    data.deformation_limit_reached = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [fingertip_force_limit_reached]
    data.fingertip_force_limit_reached = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [gripper_empty]
    data.gripper_empty = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [rtstate]
    data.rtstate = PR2GripperSensorRTState.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 45;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperSlipServoData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'a49728a2e0c40706b3c9b74046f006aa';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # time the data was recorded at
    time stamp
    
    # the amount of deformation from action start (in meters)
    float64 deformation
    
    # the force experinced by the finger Pads  (N)
    # NOTE:this ignores data from the edges of the finger pressure
    float64 left_fingertip_pad_force
    float64 right_fingertip_pad_force
    
    # the current virtual parallel joint effort of the gripper (in N)
    float64 joint_effort
    
    # true if the object recently slipped
    bool slip_detected
    
    # true if we are at or exceeding the deformation limit
    # (see wiki page and param server for more info)
    bool deformation_limit_reached
    
    # true if we are at or exceeding our force 
    # (see wiki page and param server for more info)
    bool fingertip_force_limit_reached
    
    # true if the controller thinks the gripper is empty
    # (see wiki page for more info)
    bool gripper_empty
    
    # the control state of our realtime controller
    PR2GripperSensorRTState rtstate
    ================================================================================
    MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState
    # the control state of our realtime controller
    int8 realtime_controller_state
    
    # predefined values to indicate our realtime_controller_state
    int8 DISABLED = 0
    int8 POSITION_SERVO = 3
    int8 FORCE_SERVO = 4
    int8 FIND_CONTACT = 5
    int8 SLIP_SERVO = 6
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperSlipServoData(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.deformation !== undefined) {
      resolved.deformation = msg.deformation;
    }
    else {
      resolved.deformation = 0.0
    }

    if (msg.left_fingertip_pad_force !== undefined) {
      resolved.left_fingertip_pad_force = msg.left_fingertip_pad_force;
    }
    else {
      resolved.left_fingertip_pad_force = 0.0
    }

    if (msg.right_fingertip_pad_force !== undefined) {
      resolved.right_fingertip_pad_force = msg.right_fingertip_pad_force;
    }
    else {
      resolved.right_fingertip_pad_force = 0.0
    }

    if (msg.joint_effort !== undefined) {
      resolved.joint_effort = msg.joint_effort;
    }
    else {
      resolved.joint_effort = 0.0
    }

    if (msg.slip_detected !== undefined) {
      resolved.slip_detected = msg.slip_detected;
    }
    else {
      resolved.slip_detected = false
    }

    if (msg.deformation_limit_reached !== undefined) {
      resolved.deformation_limit_reached = msg.deformation_limit_reached;
    }
    else {
      resolved.deformation_limit_reached = false
    }

    if (msg.fingertip_force_limit_reached !== undefined) {
      resolved.fingertip_force_limit_reached = msg.fingertip_force_limit_reached;
    }
    else {
      resolved.fingertip_force_limit_reached = false
    }

    if (msg.gripper_empty !== undefined) {
      resolved.gripper_empty = msg.gripper_empty;
    }
    else {
      resolved.gripper_empty = false
    }

    if (msg.rtstate !== undefined) {
      resolved.rtstate = PR2GripperSensorRTState.Resolve(msg.rtstate)
    }
    else {
      resolved.rtstate = new PR2GripperSensorRTState()
    }

    return resolved;
    }
};

module.exports = PR2GripperSlipServoData;
