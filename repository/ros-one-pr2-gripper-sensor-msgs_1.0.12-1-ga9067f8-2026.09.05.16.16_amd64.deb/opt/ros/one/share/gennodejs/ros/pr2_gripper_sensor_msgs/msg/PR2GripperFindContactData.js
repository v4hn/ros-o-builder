// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PR2GripperSensorRTState = require('./PR2GripperSensorRTState.js');

//-----------------------------------------------------------

class PR2GripperFindContactData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.contact_conditions_met = null;
      this.left_fingertip_pad_contact = null;
      this.right_fingertip_pad_contact = null;
      this.left_fingertip_pad_force = null;
      this.right_fingertip_pad_force = null;
      this.joint_position = null;
      this.joint_effort = null;
      this.rtstate = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('contact_conditions_met')) {
        this.contact_conditions_met = initObj.contact_conditions_met
      }
      else {
        this.contact_conditions_met = false;
      }
      if (initObj.hasOwnProperty('left_fingertip_pad_contact')) {
        this.left_fingertip_pad_contact = initObj.left_fingertip_pad_contact
      }
      else {
        this.left_fingertip_pad_contact = false;
      }
      if (initObj.hasOwnProperty('right_fingertip_pad_contact')) {
        this.right_fingertip_pad_contact = initObj.right_fingertip_pad_contact
      }
      else {
        this.right_fingertip_pad_contact = false;
      }
      if (initObj.hasOwnProperty('left_fingertip_pad_force')) {
        this.left_fingertip_pad_force = initObj.left_fingertip_pad_force
      }
      else {
        this.left_fingertip_pad_force = 0.0;
      }
      if (initObj.hasOwnProperty('right_fingertip_pad_force')) {
        this.right_fingertip_pad_force = initObj.right_fingertip_pad_force
      }
      else {
        this.right_fingertip_pad_force = 0.0;
      }
      if (initObj.hasOwnProperty('joint_position')) {
        this.joint_position = initObj.joint_position
      }
      else {
        this.joint_position = 0.0;
      }
      if (initObj.hasOwnProperty('joint_effort')) {
        this.joint_effort = initObj.joint_effort
      }
      else {
        this.joint_effort = 0.0;
      }
      if (initObj.hasOwnProperty('rtstate')) {
        this.rtstate = initObj.rtstate
      }
      else {
        this.rtstate = new PR2GripperSensorRTState();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperFindContactData
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [contact_conditions_met]
    bufferOffset = _serializer.bool(obj.contact_conditions_met, buffer, bufferOffset);
    // Serialize message field [left_fingertip_pad_contact]
    bufferOffset = _serializer.bool(obj.left_fingertip_pad_contact, buffer, bufferOffset);
    // Serialize message field [right_fingertip_pad_contact]
    bufferOffset = _serializer.bool(obj.right_fingertip_pad_contact, buffer, bufferOffset);
    // Serialize message field [left_fingertip_pad_force]
    bufferOffset = _serializer.float64(obj.left_fingertip_pad_force, buffer, bufferOffset);
    // Serialize message field [right_fingertip_pad_force]
    bufferOffset = _serializer.float64(obj.right_fingertip_pad_force, buffer, bufferOffset);
    // Serialize message field [joint_position]
    bufferOffset = _serializer.float64(obj.joint_position, buffer, bufferOffset);
    // Serialize message field [joint_effort]
    bufferOffset = _serializer.float64(obj.joint_effort, buffer, bufferOffset);
    // Serialize message field [rtstate]
    bufferOffset = PR2GripperSensorRTState.serialize(obj.rtstate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperFindContactData
    let len;
    let data = new PR2GripperFindContactData(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [contact_conditions_met]
    data.contact_conditions_met = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [left_fingertip_pad_contact]
    data.left_fingertip_pad_contact = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [right_fingertip_pad_contact]
    data.right_fingertip_pad_contact = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [left_fingertip_pad_force]
    data.left_fingertip_pad_force = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_fingertip_pad_force]
    data.right_fingertip_pad_force = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [joint_position]
    data.joint_position = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [joint_effort]
    data.joint_effort = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [rtstate]
    data.rtstate = PR2GripperSensorRTState.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 44;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperFindContactData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'bc53e3dc7d19b896ca9b5ea205d54b91';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Time the data was recorded at
    time stamp
    
    # true when our contact conditions have been met
    # (see PR2GripperFindContact command)
    bool contact_conditions_met
    
    # the finger contact conditions 
    # true if the finger experienced a contact event
    #
    # contact events are defined as contact with the fingerpads
    # as either steady-state or high-freq force events
    bool left_fingertip_pad_contact
    bool right_fingertip_pad_contact
    
    # the force experinced by the finger Pads  (N)
    # NOTE:this ignores data from the edges of the finger pressure
    float64 left_fingertip_pad_force
    float64 right_fingertip_pad_force
    
    # the current joint position (m)
    float64 joint_position
    
    # the virtual (parallel) joint effort (N)
    float64 joint_effort
    
    # the control state of our realtime controller
    PR2GripperSensorRTState rtstate
    ================================================================================
    MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState
    # the control state of our realtime controller
    int8 realtime_controller_state
    
    # predefined values to indicate our realtime_controller_state
    int8 DISABLED = 0
    int8 POSITION_SERVO = 3
    int8 FORCE_SERVO = 4
    int8 FIND_CONTACT = 5
    int8 SLIP_SERVO = 6
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperFindContactData(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.contact_conditions_met !== undefined) {
      resolved.contact_conditions_met = msg.contact_conditions_met;
    }
    else {
      resolved.contact_conditions_met = false
    }

    if (msg.left_fingertip_pad_contact !== undefined) {
      resolved.left_fingertip_pad_contact = msg.left_fingertip_pad_contact;
    }
    else {
      resolved.left_fingertip_pad_contact = false
    }

    if (msg.right_fingertip_pad_contact !== undefined) {
      resolved.right_fingertip_pad_contact = msg.right_fingertip_pad_contact;
    }
    else {
      resolved.right_fingertip_pad_contact = false
    }

    if (msg.left_fingertip_pad_force !== undefined) {
      resolved.left_fingertip_pad_force = msg.left_fingertip_pad_force;
    }
    else {
      resolved.left_fingertip_pad_force = 0.0
    }

    if (msg.right_fingertip_pad_force !== undefined) {
      resolved.right_fingertip_pad_force = msg.right_fingertip_pad_force;
    }
    else {
      resolved.right_fingertip_pad_force = 0.0
    }

    if (msg.joint_position !== undefined) {
      resolved.joint_position = msg.joint_position;
    }
    else {
      resolved.joint_position = 0.0
    }

    if (msg.joint_effort !== undefined) {
      resolved.joint_effort = msg.joint_effort;
    }
    else {
      resolved.joint_effort = 0.0
    }

    if (msg.rtstate !== undefined) {
      resolved.rtstate = PR2GripperSensorRTState.Resolve(msg.rtstate)
    }
    else {
      resolved.rtstate = new PR2GripperSensorRTState()
    }

    return resolved;
    }
};

module.exports = PR2GripperFindContactData;
