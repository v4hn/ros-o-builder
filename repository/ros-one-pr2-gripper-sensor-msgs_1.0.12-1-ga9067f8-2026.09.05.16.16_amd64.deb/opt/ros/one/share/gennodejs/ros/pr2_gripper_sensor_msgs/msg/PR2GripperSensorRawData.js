// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperSensorRawData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.left_finger_pad_force = null;
      this.right_finger_pad_force = null;
      this.left_finger_pad_force_filtered = null;
      this.right_finger_pad_force_filtered = null;
      this.left_finger_pad_forces = null;
      this.right_finger_pad_forces = null;
      this.left_finger_pad_forces_filtered = null;
      this.right_finger_pad_forces_filtered = null;
      this.acc_x_raw = null;
      this.acc_y_raw = null;
      this.acc_z_raw = null;
      this.acc_x_filtered = null;
      this.acc_y_filtered = null;
      this.acc_z_filtered = null;
      this.left_contact = null;
      this.right_contact = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('left_finger_pad_force')) {
        this.left_finger_pad_force = initObj.left_finger_pad_force
      }
      else {
        this.left_finger_pad_force = 0.0;
      }
      if (initObj.hasOwnProperty('right_finger_pad_force')) {
        this.right_finger_pad_force = initObj.right_finger_pad_force
      }
      else {
        this.right_finger_pad_force = 0.0;
      }
      if (initObj.hasOwnProperty('left_finger_pad_force_filtered')) {
        this.left_finger_pad_force_filtered = initObj.left_finger_pad_force_filtered
      }
      else {
        this.left_finger_pad_force_filtered = 0.0;
      }
      if (initObj.hasOwnProperty('right_finger_pad_force_filtered')) {
        this.right_finger_pad_force_filtered = initObj.right_finger_pad_force_filtered
      }
      else {
        this.right_finger_pad_force_filtered = 0.0;
      }
      if (initObj.hasOwnProperty('left_finger_pad_forces')) {
        this.left_finger_pad_forces = initObj.left_finger_pad_forces
      }
      else {
        this.left_finger_pad_forces = new Array(22).fill(0);
      }
      if (initObj.hasOwnProperty('right_finger_pad_forces')) {
        this.right_finger_pad_forces = initObj.right_finger_pad_forces
      }
      else {
        this.right_finger_pad_forces = new Array(22).fill(0);
      }
      if (initObj.hasOwnProperty('left_finger_pad_forces_filtered')) {
        this.left_finger_pad_forces_filtered = initObj.left_finger_pad_forces_filtered
      }
      else {
        this.left_finger_pad_forces_filtered = new Array(22).fill(0);
      }
      if (initObj.hasOwnProperty('right_finger_pad_forces_filtered')) {
        this.right_finger_pad_forces_filtered = initObj.right_finger_pad_forces_filtered
      }
      else {
        this.right_finger_pad_forces_filtered = new Array(22).fill(0);
      }
      if (initObj.hasOwnProperty('acc_x_raw')) {
        this.acc_x_raw = initObj.acc_x_raw
      }
      else {
        this.acc_x_raw = 0.0;
      }
      if (initObj.hasOwnProperty('acc_y_raw')) {
        this.acc_y_raw = initObj.acc_y_raw
      }
      else {
        this.acc_y_raw = 0.0;
      }
      if (initObj.hasOwnProperty('acc_z_raw')) {
        this.acc_z_raw = initObj.acc_z_raw
      }
      else {
        this.acc_z_raw = 0.0;
      }
      if (initObj.hasOwnProperty('acc_x_filtered')) {
        this.acc_x_filtered = initObj.acc_x_filtered
      }
      else {
        this.acc_x_filtered = 0.0;
      }
      if (initObj.hasOwnProperty('acc_y_filtered')) {
        this.acc_y_filtered = initObj.acc_y_filtered
      }
      else {
        this.acc_y_filtered = 0.0;
      }
      if (initObj.hasOwnProperty('acc_z_filtered')) {
        this.acc_z_filtered = initObj.acc_z_filtered
      }
      else {
        this.acc_z_filtered = 0.0;
      }
      if (initObj.hasOwnProperty('left_contact')) {
        this.left_contact = initObj.left_contact
      }
      else {
        this.left_contact = false;
      }
      if (initObj.hasOwnProperty('right_contact')) {
        this.right_contact = initObj.right_contact
      }
      else {
        this.right_contact = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperSensorRawData
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [left_finger_pad_force]
    bufferOffset = _serializer.float64(obj.left_finger_pad_force, buffer, bufferOffset);
    // Serialize message field [right_finger_pad_force]
    bufferOffset = _serializer.float64(obj.right_finger_pad_force, buffer, bufferOffset);
    // Serialize message field [left_finger_pad_force_filtered]
    bufferOffset = _serializer.float64(obj.left_finger_pad_force_filtered, buffer, bufferOffset);
    // Serialize message field [right_finger_pad_force_filtered]
    bufferOffset = _serializer.float64(obj.right_finger_pad_force_filtered, buffer, bufferOffset);
    // Check that the constant length array field [left_finger_pad_forces] has the right length
    if (obj.left_finger_pad_forces.length !== 22) {
      throw new Error('Unable to serialize array field left_finger_pad_forces - length must be 22')
    }
    // Serialize message field [left_finger_pad_forces]
    bufferOffset = _arraySerializer.float64(obj.left_finger_pad_forces, buffer, bufferOffset, 22);
    // Check that the constant length array field [right_finger_pad_forces] has the right length
    if (obj.right_finger_pad_forces.length !== 22) {
      throw new Error('Unable to serialize array field right_finger_pad_forces - length must be 22')
    }
    // Serialize message field [right_finger_pad_forces]
    bufferOffset = _arraySerializer.float64(obj.right_finger_pad_forces, buffer, bufferOffset, 22);
    // Check that the constant length array field [left_finger_pad_forces_filtered] has the right length
    if (obj.left_finger_pad_forces_filtered.length !== 22) {
      throw new Error('Unable to serialize array field left_finger_pad_forces_filtered - length must be 22')
    }
    // Serialize message field [left_finger_pad_forces_filtered]
    bufferOffset = _arraySerializer.float64(obj.left_finger_pad_forces_filtered, buffer, bufferOffset, 22);
    // Check that the constant length array field [right_finger_pad_forces_filtered] has the right length
    if (obj.right_finger_pad_forces_filtered.length !== 22) {
      throw new Error('Unable to serialize array field right_finger_pad_forces_filtered - length must be 22')
    }
    // Serialize message field [right_finger_pad_forces_filtered]
    bufferOffset = _arraySerializer.float64(obj.right_finger_pad_forces_filtered, buffer, bufferOffset, 22);
    // Serialize message field [acc_x_raw]
    bufferOffset = _serializer.float64(obj.acc_x_raw, buffer, bufferOffset);
    // Serialize message field [acc_y_raw]
    bufferOffset = _serializer.float64(obj.acc_y_raw, buffer, bufferOffset);
    // Serialize message field [acc_z_raw]
    bufferOffset = _serializer.float64(obj.acc_z_raw, buffer, bufferOffset);
    // Serialize message field [acc_x_filtered]
    bufferOffset = _serializer.float64(obj.acc_x_filtered, buffer, bufferOffset);
    // Serialize message field [acc_y_filtered]
    bufferOffset = _serializer.float64(obj.acc_y_filtered, buffer, bufferOffset);
    // Serialize message field [acc_z_filtered]
    bufferOffset = _serializer.float64(obj.acc_z_filtered, buffer, bufferOffset);
    // Serialize message field [left_contact]
    bufferOffset = _serializer.bool(obj.left_contact, buffer, bufferOffset);
    // Serialize message field [right_contact]
    bufferOffset = _serializer.bool(obj.right_contact, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperSensorRawData
    let len;
    let data = new PR2GripperSensorRawData(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [left_finger_pad_force]
    data.left_finger_pad_force = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_finger_pad_force]
    data.right_finger_pad_force = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_finger_pad_force_filtered]
    data.left_finger_pad_force_filtered = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [right_finger_pad_force_filtered]
    data.right_finger_pad_force_filtered = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_finger_pad_forces]
    data.left_finger_pad_forces = _arrayDeserializer.float64(buffer, bufferOffset, 22)
    // Deserialize message field [right_finger_pad_forces]
    data.right_finger_pad_forces = _arrayDeserializer.float64(buffer, bufferOffset, 22)
    // Deserialize message field [left_finger_pad_forces_filtered]
    data.left_finger_pad_forces_filtered = _arrayDeserializer.float64(buffer, bufferOffset, 22)
    // Deserialize message field [right_finger_pad_forces_filtered]
    data.right_finger_pad_forces_filtered = _arrayDeserializer.float64(buffer, bufferOffset, 22)
    // Deserialize message field [acc_x_raw]
    data.acc_x_raw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acc_y_raw]
    data.acc_y_raw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acc_z_raw]
    data.acc_z_raw = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acc_x_filtered]
    data.acc_x_filtered = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acc_y_filtered]
    data.acc_y_filtered = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acc_z_filtered]
    data.acc_z_filtered = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [left_contact]
    data.left_contact = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [right_contact]
    data.right_contact = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 794;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperSensorRawData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '696a1f2e6969deb0bc6998636ae1b17e';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # NOTE: This message is only for debugging purposes. It is not intended for API usage - and is not published under release code.
    
    # Standard ROS header
    time stamp
    
    # corrected for zero contact
    float64 left_finger_pad_force
    float64 right_finger_pad_force
    
    # filtered values : high pass filter at 5 Hz after correcting for zero contact
    float64 left_finger_pad_force_filtered
    float64 right_finger_pad_force_filtered
    
    # corrected for zero contact
    float64[22] left_finger_pad_forces
    float64[22] right_finger_pad_forces
    
    # filtered values : high pass filter at 5 Hz after correcting for zero contact
    float64[22] left_finger_pad_forces_filtered
    float64[22] right_finger_pad_forces_filtered
    
    # raw acceleration values
    float64 acc_x_raw
    float64 acc_y_raw
    float64 acc_z_raw
    
    # filtered acceleration values
    float64 acc_x_filtered
    float64 acc_y_filtered
    float64 acc_z_filtered
    
    # boolean variables indicating whether contact exists or not
    bool left_contact
    bool right_contact
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperSensorRawData(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.left_finger_pad_force !== undefined) {
      resolved.left_finger_pad_force = msg.left_finger_pad_force;
    }
    else {
      resolved.left_finger_pad_force = 0.0
    }

    if (msg.right_finger_pad_force !== undefined) {
      resolved.right_finger_pad_force = msg.right_finger_pad_force;
    }
    else {
      resolved.right_finger_pad_force = 0.0
    }

    if (msg.left_finger_pad_force_filtered !== undefined) {
      resolved.left_finger_pad_force_filtered = msg.left_finger_pad_force_filtered;
    }
    else {
      resolved.left_finger_pad_force_filtered = 0.0
    }

    if (msg.right_finger_pad_force_filtered !== undefined) {
      resolved.right_finger_pad_force_filtered = msg.right_finger_pad_force_filtered;
    }
    else {
      resolved.right_finger_pad_force_filtered = 0.0
    }

    if (msg.left_finger_pad_forces !== undefined) {
      resolved.left_finger_pad_forces = msg.left_finger_pad_forces;
    }
    else {
      resolved.left_finger_pad_forces = new Array(22).fill(0)
    }

    if (msg.right_finger_pad_forces !== undefined) {
      resolved.right_finger_pad_forces = msg.right_finger_pad_forces;
    }
    else {
      resolved.right_finger_pad_forces = new Array(22).fill(0)
    }

    if (msg.left_finger_pad_forces_filtered !== undefined) {
      resolved.left_finger_pad_forces_filtered = msg.left_finger_pad_forces_filtered;
    }
    else {
      resolved.left_finger_pad_forces_filtered = new Array(22).fill(0)
    }

    if (msg.right_finger_pad_forces_filtered !== undefined) {
      resolved.right_finger_pad_forces_filtered = msg.right_finger_pad_forces_filtered;
    }
    else {
      resolved.right_finger_pad_forces_filtered = new Array(22).fill(0)
    }

    if (msg.acc_x_raw !== undefined) {
      resolved.acc_x_raw = msg.acc_x_raw;
    }
    else {
      resolved.acc_x_raw = 0.0
    }

    if (msg.acc_y_raw !== undefined) {
      resolved.acc_y_raw = msg.acc_y_raw;
    }
    else {
      resolved.acc_y_raw = 0.0
    }

    if (msg.acc_z_raw !== undefined) {
      resolved.acc_z_raw = msg.acc_z_raw;
    }
    else {
      resolved.acc_z_raw = 0.0
    }

    if (msg.acc_x_filtered !== undefined) {
      resolved.acc_x_filtered = msg.acc_x_filtered;
    }
    else {
      resolved.acc_x_filtered = 0.0
    }

    if (msg.acc_y_filtered !== undefined) {
      resolved.acc_y_filtered = msg.acc_y_filtered;
    }
    else {
      resolved.acc_y_filtered = 0.0
    }

    if (msg.acc_z_filtered !== undefined) {
      resolved.acc_z_filtered = msg.acc_z_filtered;
    }
    else {
      resolved.acc_z_filtered = 0.0
    }

    if (msg.left_contact !== undefined) {
      resolved.left_contact = msg.left_contact;
    }
    else {
      resolved.left_contact = false
    }

    if (msg.right_contact !== undefined) {
      resolved.right_contact = msg.right_contact;
    }
    else {
      resolved.right_contact = false
    }

    return resolved;
    }
};

module.exports = PR2GripperSensorRawData;
