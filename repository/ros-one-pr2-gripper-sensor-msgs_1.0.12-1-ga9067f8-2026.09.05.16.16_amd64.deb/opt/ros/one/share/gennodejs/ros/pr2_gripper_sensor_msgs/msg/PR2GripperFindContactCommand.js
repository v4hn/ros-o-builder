// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperFindContactCommand {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.zero_fingertip_sensors = null;
      this.contact_conditions = null;
    }
    else {
      if (initObj.hasOwnProperty('zero_fingertip_sensors')) {
        this.zero_fingertip_sensors = initObj.zero_fingertip_sensors
      }
      else {
        this.zero_fingertip_sensors = false;
      }
      if (initObj.hasOwnProperty('contact_conditions')) {
        this.contact_conditions = initObj.contact_conditions
      }
      else {
        this.contact_conditions = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperFindContactCommand
    // Serialize message field [zero_fingertip_sensors]
    bufferOffset = _serializer.bool(obj.zero_fingertip_sensors, buffer, bufferOffset);
    // Serialize message field [contact_conditions]
    bufferOffset = _serializer.int8(obj.contact_conditions, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperFindContactCommand
    let len;
    let data = new PR2GripperFindContactCommand(null);
    // Deserialize message field [zero_fingertip_sensors]
    data.zero_fingertip_sensors = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [contact_conditions]
    data.contact_conditions = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 2;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperFindContactCommand';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4a38a1a8e495aae86921ef2b292ec260';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # set true if you want to calibrate the fingertip sensors on the start
    # of the find_contact action. While this is not necessary (and
    # the default value will not calibrate the sensors) for best 
    # performance it is recommended that you set this to true each time 
    # you are calling find_contact and are confident the fingertips are 
    # not touching anything
    # NOTE: SHOULD ONLY BE TRUE WHEN BOTH FINGERS ARE TOUCHING NOTHING
    bool zero_fingertip_sensors
    
    # the finger contact conditions that determine what our goal is
    # Leaving this field blank will result in the robot closing until
    # contact on BOTH fingers is achieved
    int8 contact_conditions
    
    # predefined values for the above contact_conditions variable
    int8 BOTH = 0   # both fingers must make contact
    int8 LEFT = 1   # just the left finger 
    int8 RIGHT = 2  # just the right finger
    int8 EITHER = 3 # either finger, we don't care which
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperFindContactCommand(null);
    if (msg.zero_fingertip_sensors !== undefined) {
      resolved.zero_fingertip_sensors = msg.zero_fingertip_sensors;
    }
    else {
      resolved.zero_fingertip_sensors = false
    }

    if (msg.contact_conditions !== undefined) {
      resolved.contact_conditions = msg.contact_conditions;
    }
    else {
      resolved.contact_conditions = 0
    }

    return resolved;
    }
};

// Constants for message
PR2GripperFindContactCommand.Constants = {
  BOTH: 0,
  LEFT: 1,
  RIGHT: 2,
  EITHER: 3,
}

module.exports = PR2GripperFindContactCommand;
