// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let PR2GripperSensorRTState = require('./PR2GripperSensorRTState.js');

//-----------------------------------------------------------

class PR2GripperReleaseData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.rtstate = null;
    }
    else {
      if (initObj.hasOwnProperty('rtstate')) {
        this.rtstate = initObj.rtstate
      }
      else {
        this.rtstate = new PR2GripperSensorRTState();
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperReleaseData
    // Serialize message field [rtstate]
    bufferOffset = PR2GripperSensorRTState.serialize(obj.rtstate, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperReleaseData
    let len;
    let data = new PR2GripperReleaseData(null);
    // Deserialize message field [rtstate]
    data.rtstate = PR2GripperSensorRTState.deserialize(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperReleaseData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2c917fd7a48bc8daa7ae36787c8b7a82';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # the control state of our realtime controller
    PR2GripperSensorRTState rtstate
    ================================================================================
    MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState
    # the control state of our realtime controller
    int8 realtime_controller_state
    
    # predefined values to indicate our realtime_controller_state
    int8 DISABLED = 0
    int8 POSITION_SERVO = 3
    int8 FORCE_SERVO = 4
    int8 FIND_CONTACT = 5
    int8 SLIP_SERVO = 6
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperReleaseData(null);
    if (msg.rtstate !== undefined) {
      resolved.rtstate = PR2GripperSensorRTState.Resolve(msg.rtstate)
    }
    else {
      resolved.rtstate = new PR2GripperSensorRTState()
    }

    return resolved;
    }
};

module.exports = PR2GripperReleaseData;
