// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperEventDetectorData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.stamp = null;
      this.trigger_conditions_met = null;
      this.slip_event = null;
      this.acceleration_event = null;
      this.acceleration_vector = null;
    }
    else {
      if (initObj.hasOwnProperty('stamp')) {
        this.stamp = initObj.stamp
      }
      else {
        this.stamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('trigger_conditions_met')) {
        this.trigger_conditions_met = initObj.trigger_conditions_met
      }
      else {
        this.trigger_conditions_met = false;
      }
      if (initObj.hasOwnProperty('slip_event')) {
        this.slip_event = initObj.slip_event
      }
      else {
        this.slip_event = false;
      }
      if (initObj.hasOwnProperty('acceleration_event')) {
        this.acceleration_event = initObj.acceleration_event
      }
      else {
        this.acceleration_event = false;
      }
      if (initObj.hasOwnProperty('acceleration_vector')) {
        this.acceleration_vector = initObj.acceleration_vector
      }
      else {
        this.acceleration_vector = new Array(3).fill(0);
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperEventDetectorData
    // Serialize message field [stamp]
    bufferOffset = _serializer.time(obj.stamp, buffer, bufferOffset);
    // Serialize message field [trigger_conditions_met]
    bufferOffset = _serializer.bool(obj.trigger_conditions_met, buffer, bufferOffset);
    // Serialize message field [slip_event]
    bufferOffset = _serializer.bool(obj.slip_event, buffer, bufferOffset);
    // Serialize message field [acceleration_event]
    bufferOffset = _serializer.bool(obj.acceleration_event, buffer, bufferOffset);
    // Check that the constant length array field [acceleration_vector] has the right length
    if (obj.acceleration_vector.length !== 3) {
      throw new Error('Unable to serialize array field acceleration_vector - length must be 3')
    }
    // Serialize message field [acceleration_vector]
    bufferOffset = _arraySerializer.float64(obj.acceleration_vector, buffer, bufferOffset, 3);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperEventDetectorData
    let len;
    let data = new PR2GripperEventDetectorData(null);
    // Deserialize message field [stamp]
    data.stamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [trigger_conditions_met]
    data.trigger_conditions_met = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [slip_event]
    data.slip_event = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [acceleration_event]
    data.acceleration_event = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [acceleration_vector]
    data.acceleration_vector = _arrayDeserializer.float64(buffer, bufferOffset, 3)
    return data;
  }

  static getMessageSize(object) {
    return 35;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperEventDetectorData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '9536d682ef6215440ecc47846d4117c2';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Time the data was recorded at
    time stamp
    
    # true if the trigger conditions have been met 
    # (see PR2GripperEventDetectorCommand)
    bool trigger_conditions_met
    
    # true if the pressure sensors detected a slip event
    # slip events occur when the finger pressure sensors
    # high-freq. content exceeds the slip_trigger_magnitude variable
    # (see PR2GripperEventDetectorCommand)
    bool slip_event
    
    # true if the hand-mounted accelerometer detected a contact acceleration
    # acceleration events occur when the palm accelerometer
    # high-freq. content exceeds the acc_trigger_magnitude variable
    # (see PR2GripperEventDetectorCommand)
    bool acceleration_event
    
    # the high-freq acceleration vector that was last seen (x,y,z)
    float64[3] acceleration_vector
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperEventDetectorData(null);
    if (msg.stamp !== undefined) {
      resolved.stamp = msg.stamp;
    }
    else {
      resolved.stamp = {secs: 0, nsecs: 0}
    }

    if (msg.trigger_conditions_met !== undefined) {
      resolved.trigger_conditions_met = msg.trigger_conditions_met;
    }
    else {
      resolved.trigger_conditions_met = false
    }

    if (msg.slip_event !== undefined) {
      resolved.slip_event = msg.slip_event;
    }
    else {
      resolved.slip_event = false
    }

    if (msg.acceleration_event !== undefined) {
      resolved.acceleration_event = msg.acceleration_event;
    }
    else {
      resolved.acceleration_event = false
    }

    if (msg.acceleration_vector !== undefined) {
      resolved.acceleration_vector = msg.acceleration_vector;
    }
    else {
      resolved.acceleration_vector = new Array(3).fill(0)
    }

    return resolved;
    }
};

module.exports = PR2GripperEventDetectorData;
