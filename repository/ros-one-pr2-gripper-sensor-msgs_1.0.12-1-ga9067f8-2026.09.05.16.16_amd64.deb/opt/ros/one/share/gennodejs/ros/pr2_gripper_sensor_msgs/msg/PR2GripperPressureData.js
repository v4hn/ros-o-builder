// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperPressureData {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.pressure_left = null;
      this.pressure_right = null;
      this.rostime = null;
    }
    else {
      if (initObj.hasOwnProperty('pressure_left')) {
        this.pressure_left = initObj.pressure_left
      }
      else {
        this.pressure_left = new Array(22).fill(0);
      }
      if (initObj.hasOwnProperty('pressure_right')) {
        this.pressure_right = initObj.pressure_right
      }
      else {
        this.pressure_right = new Array(22).fill(0);
      }
      if (initObj.hasOwnProperty('rostime')) {
        this.rostime = initObj.rostime
      }
      else {
        this.rostime = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperPressureData
    // Check that the constant length array field [pressure_left] has the right length
    if (obj.pressure_left.length !== 22) {
      throw new Error('Unable to serialize array field pressure_left - length must be 22')
    }
    // Serialize message field [pressure_left]
    bufferOffset = _arraySerializer.float64(obj.pressure_left, buffer, bufferOffset, 22);
    // Check that the constant length array field [pressure_right] has the right length
    if (obj.pressure_right.length !== 22) {
      throw new Error('Unable to serialize array field pressure_right - length must be 22')
    }
    // Serialize message field [pressure_right]
    bufferOffset = _arraySerializer.float64(obj.pressure_right, buffer, bufferOffset, 22);
    // Serialize message field [rostime]
    bufferOffset = _serializer.float64(obj.rostime, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperPressureData
    let len;
    let data = new PR2GripperPressureData(null);
    // Deserialize message field [pressure_left]
    data.pressure_left = _arrayDeserializer.float64(buffer, bufferOffset, 22)
    // Deserialize message field [pressure_right]
    data.pressure_right = _arrayDeserializer.float64(buffer, bufferOffset, 22)
    // Deserialize message field [rostime]
    data.rostime = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 360;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperPressureData';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'b69255f5117bf05fdcd1e83d4e6ab779';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Note: This message is intended for internal package use only and is NOT a part of the public API. This data is not publicaly published in ROS.
    
    # the pressure array for the left and right fingers
    float64[22] pressure_left
    float64[22] pressure_right
    
    float64 rostime
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperPressureData(null);
    if (msg.pressure_left !== undefined) {
      resolved.pressure_left = msg.pressure_left;
    }
    else {
      resolved.pressure_left = new Array(22).fill(0)
    }

    if (msg.pressure_right !== undefined) {
      resolved.pressure_right = msg.pressure_right;
    }
    else {
      resolved.pressure_right = new Array(22).fill(0)
    }

    if (msg.rostime !== undefined) {
      resolved.rostime = msg.rostime;
    }
    else {
      resolved.rostime = 0.0
    }

    return resolved;
    }
};

module.exports = PR2GripperPressureData;
