// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperForceServoCommand {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.fingertip_force = null;
    }
    else {
      if (initObj.hasOwnProperty('fingertip_force')) {
        this.fingertip_force = initObj.fingertip_force
      }
      else {
        this.fingertip_force = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperForceServoCommand
    // Serialize message field [fingertip_force]
    bufferOffset = _serializer.float64(obj.fingertip_force, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperForceServoCommand
    let len;
    let data = new PR2GripperForceServoCommand(null);
    // Deserialize message field [fingertip_force]
    data.fingertip_force = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperForceServoCommand';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'dd4b2a0dfafa27b67d2002841f544379';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # the amount of fingertip force (in Newtons) to apply.
    # NOTE: the joint will squeeze until each finger reaches this level
    # values < 0 (opening force) are ignored
    #
    # 10 N can crack an egg or crush a soda can.
    # 15 N can firmly pick up a can of soup.
    # Experiment on your own.
    #
    float64 fingertip_force
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperForceServoCommand(null);
    if (msg.fingertip_force !== undefined) {
      resolved.fingertip_force = msg.fingertip_force;
    }
    else {
      resolved.fingertip_force = 0.0
    }

    return resolved;
    }
};

module.exports = PR2GripperForceServoCommand;
