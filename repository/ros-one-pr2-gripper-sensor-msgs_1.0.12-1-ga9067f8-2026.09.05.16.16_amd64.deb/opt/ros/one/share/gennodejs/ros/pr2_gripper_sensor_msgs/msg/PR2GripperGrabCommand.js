// Auto-generated. Do not edit!

// (in-package pr2_gripper_sensor_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class PR2GripperGrabCommand {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.hardness_gain = null;
    }
    else {
      if (initObj.hasOwnProperty('hardness_gain')) {
        this.hardness_gain = initObj.hardness_gain
      }
      else {
        this.hardness_gain = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type PR2GripperGrabCommand
    // Serialize message field [hardness_gain]
    bufferOffset = _serializer.float64(obj.hardness_gain, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type PR2GripperGrabCommand
    let len;
    let data = new PR2GripperGrabCommand(null);
    // Deserialize message field [hardness_gain]
    data.hardness_gain = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'pr2_gripper_sensor_msgs/PR2GripperGrabCommand';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'cf286b093615060c79527896d36bf694';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # The gain to use to evaluate how hard an object should be
    # grasped after it is contacted. This is based on hardness
    # estimation as outlined in TRO paper (see wiki).
    # 
    # Try 0.03
    #
    # Units (N/(m/s^2))
    float64 hardness_gain
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new PR2GripperGrabCommand(null);
    if (msg.hardness_gain !== undefined) {
      resolved.hardness_gain = msg.hardness_gain;
    }
    else {
      resolved.hardness_gain = 0.0
    }

    return resolved;
    }
};

module.exports = PR2GripperGrabCommand;
