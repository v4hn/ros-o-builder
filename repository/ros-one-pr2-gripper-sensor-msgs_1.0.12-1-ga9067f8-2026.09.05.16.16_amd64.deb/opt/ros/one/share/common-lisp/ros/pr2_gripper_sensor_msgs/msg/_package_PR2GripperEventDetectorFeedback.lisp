(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(DATA-VAL
          DATA
))