; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperGrabCommand.msg.html

(cl:defclass <PR2GripperGrabCommand> (roslisp-msg-protocol:ros-message)
  ((hardness_gain
    :reader hardness_gain
    :initarg :hardness_gain
    :type cl:float
    :initform 0.0))
)

(cl:defclass PR2GripperGrabCommand (<PR2GripperGrabCommand>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperGrabCommand>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperGrabCommand)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperGrabCommand> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperGrabCommand instead.")))

(cl:ensure-generic-function 'hardness_gain-val :lambda-list '(m))
(cl:defmethod hardness_gain-val ((m <PR2GripperGrabCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:hardness_gain-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:hardness_gain instead.")
  (hardness_gain m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperGrabCommand>) ostream)
  "Serializes a message object of type '<PR2GripperGrabCommand>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'hardness_gain))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperGrabCommand>) istream)
  "Deserializes a message object of type '<PR2GripperGrabCommand>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'hardness_gain) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperGrabCommand>)))
  "Returns string type for a message object of type '<PR2GripperGrabCommand>"
  "pr2_gripper_sensor_msgs/PR2GripperGrabCommand")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperGrabCommand)))
  "Returns string type for a message object of type 'PR2GripperGrabCommand"
  "pr2_gripper_sensor_msgs/PR2GripperGrabCommand")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperGrabCommand>)))
  "Returns md5sum for a message object of type '<PR2GripperGrabCommand>"
  "cf286b093615060c79527896d36bf694")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperGrabCommand)))
  "Returns md5sum for a message object of type 'PR2GripperGrabCommand"
  "cf286b093615060c79527896d36bf694")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperGrabCommand>)))
  "Returns full string definition for message of type '<PR2GripperGrabCommand>"
  (cl:format cl:nil "# The gain to use to evaluate how hard an object should be~%# grasped after it is contacted. This is based on hardness~%# estimation as outlined in TRO paper (see wiki).~%# ~%# Try 0.03~%#~%# Units (N/(m/s^2))~%float64 hardness_gain~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperGrabCommand)))
  "Returns full string definition for message of type 'PR2GripperGrabCommand"
  (cl:format cl:nil "# The gain to use to evaluate how hard an object should be~%# grasped after it is contacted. This is based on hardness~%# estimation as outlined in TRO paper (see wiki).~%# ~%# Try 0.03~%#~%# Units (N/(m/s^2))~%float64 hardness_gain~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperGrabCommand>))
  (cl:+ 0
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperGrabCommand>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperGrabCommand
    (cl:cons ':hardness_gain (hardness_gain msg))
))
