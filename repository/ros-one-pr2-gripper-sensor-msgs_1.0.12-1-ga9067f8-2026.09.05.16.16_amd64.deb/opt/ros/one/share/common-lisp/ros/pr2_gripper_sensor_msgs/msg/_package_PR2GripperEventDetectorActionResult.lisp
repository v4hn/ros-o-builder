(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          RESULT-VAL
          RESULT
))