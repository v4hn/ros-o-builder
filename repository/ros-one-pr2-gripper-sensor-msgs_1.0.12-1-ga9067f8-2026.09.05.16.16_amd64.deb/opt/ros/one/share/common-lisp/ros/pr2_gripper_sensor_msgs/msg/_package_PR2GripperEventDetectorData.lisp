(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          TRIGGER_CONDITIONS_MET-VAL
          TRIGGER_CONDITIONS_MET
          SLIP_EVENT-VAL
          SLIP_EVENT
          ACCELERATION_EVENT-VAL
          ACCELERATION_EVENT
          ACCELERATION_VECTOR-VAL
          ACCELERATION_VECTOR
))