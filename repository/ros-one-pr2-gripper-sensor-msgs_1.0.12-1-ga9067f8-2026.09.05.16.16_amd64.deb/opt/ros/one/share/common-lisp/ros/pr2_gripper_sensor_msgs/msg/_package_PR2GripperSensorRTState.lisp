(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(REALTIME_CONTROLLER_STATE-VAL
          REALTIME_CONTROLLER_STATE
))