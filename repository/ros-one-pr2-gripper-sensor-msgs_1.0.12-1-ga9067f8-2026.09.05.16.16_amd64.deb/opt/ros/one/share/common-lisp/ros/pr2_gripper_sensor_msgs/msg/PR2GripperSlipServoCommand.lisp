; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperSlipServoCommand.msg.html

(cl:defclass <PR2GripperSlipServoCommand> (roslisp-msg-protocol:ros-message)
  ()
)

(cl:defclass PR2GripperSlipServoCommand (<PR2GripperSlipServoCommand>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperSlipServoCommand>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperSlipServoCommand)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperSlipServoCommand> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperSlipServoCommand instead.")))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperSlipServoCommand>) ostream)
  "Serializes a message object of type '<PR2GripperSlipServoCommand>"
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperSlipServoCommand>) istream)
  "Deserializes a message object of type '<PR2GripperSlipServoCommand>"
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperSlipServoCommand>)))
  "Returns string type for a message object of type '<PR2GripperSlipServoCommand>"
  "pr2_gripper_sensor_msgs/PR2GripperSlipServoCommand")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperSlipServoCommand)))
  "Returns string type for a message object of type 'PR2GripperSlipServoCommand"
  "pr2_gripper_sensor_msgs/PR2GripperSlipServoCommand")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperSlipServoCommand>)))
  "Returns md5sum for a message object of type '<PR2GripperSlipServoCommand>"
  "d41d8cd98f00b204e9800998ecf8427e")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperSlipServoCommand)))
  "Returns md5sum for a message object of type 'PR2GripperSlipServoCommand"
  "d41d8cd98f00b204e9800998ecf8427e")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperSlipServoCommand>)))
  "Returns full string definition for message of type '<PR2GripperSlipServoCommand>"
  (cl:format cl:nil "# this command is currently blank, but may see additional variable~%# additions in the future~%~%# see the param server documentation for a list of variables that effect~%# slip servo performance~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperSlipServoCommand)))
  "Returns full string definition for message of type 'PR2GripperSlipServoCommand"
  (cl:format cl:nil "# this command is currently blank, but may see additional variable~%# additions in the future~%~%# see the param server documentation for a list of variables that effect~%# slip servo performance~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperSlipServoCommand>))
  (cl:+ 0
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperSlipServoCommand>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperSlipServoCommand
))
