; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperSlipServoData.msg.html

(cl:defclass <PR2GripperSlipServoData> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (deformation
    :reader deformation
    :initarg :deformation
    :type cl:float
    :initform 0.0)
   (left_fingertip_pad_force
    :reader left_fingertip_pad_force
    :initarg :left_fingertip_pad_force
    :type cl:float
    :initform 0.0)
   (right_fingertip_pad_force
    :reader right_fingertip_pad_force
    :initarg :right_fingertip_pad_force
    :type cl:float
    :initform 0.0)
   (joint_effort
    :reader joint_effort
    :initarg :joint_effort
    :type cl:float
    :initform 0.0)
   (slip_detected
    :reader slip_detected
    :initarg :slip_detected
    :type cl:boolean
    :initform cl:nil)
   (deformation_limit_reached
    :reader deformation_limit_reached
    :initarg :deformation_limit_reached
    :type cl:boolean
    :initform cl:nil)
   (fingertip_force_limit_reached
    :reader fingertip_force_limit_reached
    :initarg :fingertip_force_limit_reached
    :type cl:boolean
    :initform cl:nil)
   (gripper_empty
    :reader gripper_empty
    :initarg :gripper_empty
    :type cl:boolean
    :initform cl:nil)
   (rtstate
    :reader rtstate
    :initarg :rtstate
    :type pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState
    :initform (cl:make-instance 'pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState)))
)

(cl:defclass PR2GripperSlipServoData (<PR2GripperSlipServoData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperSlipServoData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperSlipServoData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperSlipServoData> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperSlipServoData instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:stamp-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'deformation-val :lambda-list '(m))
(cl:defmethod deformation-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:deformation-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:deformation instead.")
  (deformation m))

(cl:ensure-generic-function 'left_fingertip_pad_force-val :lambda-list '(m))
(cl:defmethod left_fingertip_pad_force-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:left_fingertip_pad_force-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:left_fingertip_pad_force instead.")
  (left_fingertip_pad_force m))

(cl:ensure-generic-function 'right_fingertip_pad_force-val :lambda-list '(m))
(cl:defmethod right_fingertip_pad_force-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:right_fingertip_pad_force-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:right_fingertip_pad_force instead.")
  (right_fingertip_pad_force m))

(cl:ensure-generic-function 'joint_effort-val :lambda-list '(m))
(cl:defmethod joint_effort-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:joint_effort-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:joint_effort instead.")
  (joint_effort m))

(cl:ensure-generic-function 'slip_detected-val :lambda-list '(m))
(cl:defmethod slip_detected-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:slip_detected-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:slip_detected instead.")
  (slip_detected m))

(cl:ensure-generic-function 'deformation_limit_reached-val :lambda-list '(m))
(cl:defmethod deformation_limit_reached-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:deformation_limit_reached-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:deformation_limit_reached instead.")
  (deformation_limit_reached m))

(cl:ensure-generic-function 'fingertip_force_limit_reached-val :lambda-list '(m))
(cl:defmethod fingertip_force_limit_reached-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:fingertip_force_limit_reached-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:fingertip_force_limit_reached instead.")
  (fingertip_force_limit_reached m))

(cl:ensure-generic-function 'gripper_empty-val :lambda-list '(m))
(cl:defmethod gripper_empty-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:gripper_empty-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:gripper_empty instead.")
  (gripper_empty m))

(cl:ensure-generic-function 'rtstate-val :lambda-list '(m))
(cl:defmethod rtstate-val ((m <PR2GripperSlipServoData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:rtstate-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:rtstate instead.")
  (rtstate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperSlipServoData>) ostream)
  "Serializes a message object of type '<PR2GripperSlipServoData>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'deformation))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'left_fingertip_pad_force))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'right_fingertip_pad_force))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'joint_effort))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'slip_detected) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'deformation_limit_reached) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'fingertip_force_limit_reached) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'gripper_empty) 1 0)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'rtstate) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperSlipServoData>) istream)
  "Deserializes a message object of type '<PR2GripperSlipServoData>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'deformation) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'left_fingertip_pad_force) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'right_fingertip_pad_force) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'joint_effort) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'slip_detected) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'deformation_limit_reached) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'fingertip_force_limit_reached) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'gripper_empty) (cl:not (cl:zerop (cl:read-byte istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'rtstate) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperSlipServoData>)))
  "Returns string type for a message object of type '<PR2GripperSlipServoData>"
  "pr2_gripper_sensor_msgs/PR2GripperSlipServoData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperSlipServoData)))
  "Returns string type for a message object of type 'PR2GripperSlipServoData"
  "pr2_gripper_sensor_msgs/PR2GripperSlipServoData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperSlipServoData>)))
  "Returns md5sum for a message object of type '<PR2GripperSlipServoData>"
  "a49728a2e0c40706b3c9b74046f006aa")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperSlipServoData)))
  "Returns md5sum for a message object of type 'PR2GripperSlipServoData"
  "a49728a2e0c40706b3c9b74046f006aa")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperSlipServoData>)))
  "Returns full string definition for message of type '<PR2GripperSlipServoData>"
  (cl:format cl:nil "# time the data was recorded at~%time stamp~%~%# the amount of deformation from action start (in meters)~%float64 deformation~%~%# the force experinced by the finger Pads  (N)~%# NOTE:this ignores data from the edges of the finger pressure~%float64 left_fingertip_pad_force~%float64 right_fingertip_pad_force~%~%# the current virtual parallel joint effort of the gripper (in N)~%float64 joint_effort~%~%# true if the object recently slipped~%bool slip_detected~%~%# true if we are at or exceeding the deformation limit~%# (see wiki page and param server for more info)~%bool deformation_limit_reached~%~%# true if we are at or exceeding our force ~%# (see wiki page and param server for more info)~%bool fingertip_force_limit_reached~%~%# true if the controller thinks the gripper is empty~%# (see wiki page for more info)~%bool gripper_empty~%~%# the control state of our realtime controller~%PR2GripperSensorRTState rtstate~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState~%# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperSlipServoData)))
  "Returns full string definition for message of type 'PR2GripperSlipServoData"
  (cl:format cl:nil "# time the data was recorded at~%time stamp~%~%# the amount of deformation from action start (in meters)~%float64 deformation~%~%# the force experinced by the finger Pads  (N)~%# NOTE:this ignores data from the edges of the finger pressure~%float64 left_fingertip_pad_force~%float64 right_fingertip_pad_force~%~%# the current virtual parallel joint effort of the gripper (in N)~%float64 joint_effort~%~%# true if the object recently slipped~%bool slip_detected~%~%# true if we are at or exceeding the deformation limit~%# (see wiki page and param server for more info)~%bool deformation_limit_reached~%~%# true if we are at or exceeding our force ~%# (see wiki page and param server for more info)~%bool fingertip_force_limit_reached~%~%# true if the controller thinks the gripper is empty~%# (see wiki page for more info)~%bool gripper_empty~%~%# the control state of our realtime controller~%PR2GripperSensorRTState rtstate~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState~%# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperSlipServoData>))
  (cl:+ 0
     8
     8
     8
     8
     8
     1
     1
     1
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'rtstate))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperSlipServoData>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperSlipServoData
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':deformation (deformation msg))
    (cl:cons ':left_fingertip_pad_force (left_fingertip_pad_force msg))
    (cl:cons ':right_fingertip_pad_force (right_fingertip_pad_force msg))
    (cl:cons ':joint_effort (joint_effort msg))
    (cl:cons ':slip_detected (slip_detected msg))
    (cl:cons ':deformation_limit_reached (deformation_limit_reached msg))
    (cl:cons ':fingertip_force_limit_reached (fingertip_force_limit_reached msg))
    (cl:cons ':gripper_empty (gripper_empty msg))
    (cl:cons ':rtstate (rtstate msg))
))
