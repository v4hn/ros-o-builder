; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperFindContactCommand.msg.html

(cl:defclass <PR2GripperFindContactCommand> (roslisp-msg-protocol:ros-message)
  ((zero_fingertip_sensors
    :reader zero_fingertip_sensors
    :initarg :zero_fingertip_sensors
    :type cl:boolean
    :initform cl:nil)
   (contact_conditions
    :reader contact_conditions
    :initarg :contact_conditions
    :type cl:fixnum
    :initform 0))
)

(cl:defclass PR2GripperFindContactCommand (<PR2GripperFindContactCommand>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperFindContactCommand>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperFindContactCommand)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperFindContactCommand> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperFindContactCommand instead.")))

(cl:ensure-generic-function 'zero_fingertip_sensors-val :lambda-list '(m))
(cl:defmethod zero_fingertip_sensors-val ((m <PR2GripperFindContactCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:zero_fingertip_sensors-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:zero_fingertip_sensors instead.")
  (zero_fingertip_sensors m))

(cl:ensure-generic-function 'contact_conditions-val :lambda-list '(m))
(cl:defmethod contact_conditions-val ((m <PR2GripperFindContactCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:contact_conditions-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:contact_conditions instead.")
  (contact_conditions m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<PR2GripperFindContactCommand>)))
    "Constants for message type '<PR2GripperFindContactCommand>"
  '((:BOTH . 0)
    (:LEFT . 1)
    (:RIGHT . 2)
    (:EITHER . 3))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'PR2GripperFindContactCommand)))
    "Constants for message type 'PR2GripperFindContactCommand"
  '((:BOTH . 0)
    (:LEFT . 1)
    (:RIGHT . 2)
    (:EITHER . 3))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperFindContactCommand>) ostream)
  "Serializes a message object of type '<PR2GripperFindContactCommand>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'zero_fingertip_sensors) 1 0)) ostream)
  (cl:let* ((signed (cl:slot-value msg 'contact_conditions)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperFindContactCommand>) istream)
  "Deserializes a message object of type '<PR2GripperFindContactCommand>"
    (cl:setf (cl:slot-value msg 'zero_fingertip_sensors) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'contact_conditions) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperFindContactCommand>)))
  "Returns string type for a message object of type '<PR2GripperFindContactCommand>"
  "pr2_gripper_sensor_msgs/PR2GripperFindContactCommand")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperFindContactCommand)))
  "Returns string type for a message object of type 'PR2GripperFindContactCommand"
  "pr2_gripper_sensor_msgs/PR2GripperFindContactCommand")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperFindContactCommand>)))
  "Returns md5sum for a message object of type '<PR2GripperFindContactCommand>"
  "4a38a1a8e495aae86921ef2b292ec260")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperFindContactCommand)))
  "Returns md5sum for a message object of type 'PR2GripperFindContactCommand"
  "4a38a1a8e495aae86921ef2b292ec260")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperFindContactCommand>)))
  "Returns full string definition for message of type '<PR2GripperFindContactCommand>"
  (cl:format cl:nil "# set true if you want to calibrate the fingertip sensors on the start~%# of the find_contact action. While this is not necessary (and~%# the default value will not calibrate the sensors) for best ~%# performance it is recommended that you set this to true each time ~%# you are calling find_contact and are confident the fingertips are ~%# not touching anything~%# NOTE: SHOULD ONLY BE TRUE WHEN BOTH FINGERS ARE TOUCHING NOTHING~%bool zero_fingertip_sensors~%~%# the finger contact conditions that determine what our goal is~%# Leaving this field blank will result in the robot closing until~%# contact on BOTH fingers is achieved~%int8 contact_conditions~%~%# predefined values for the above contact_conditions variable~%int8 BOTH = 0   # both fingers must make contact~%int8 LEFT = 1   # just the left finger ~%int8 RIGHT = 2  # just the right finger~%int8 EITHER = 3 # either finger, we don't care which~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperFindContactCommand)))
  "Returns full string definition for message of type 'PR2GripperFindContactCommand"
  (cl:format cl:nil "# set true if you want to calibrate the fingertip sensors on the start~%# of the find_contact action. While this is not necessary (and~%# the default value will not calibrate the sensors) for best ~%# performance it is recommended that you set this to true each time ~%# you are calling find_contact and are confident the fingertips are ~%# not touching anything~%# NOTE: SHOULD ONLY BE TRUE WHEN BOTH FINGERS ARE TOUCHING NOTHING~%bool zero_fingertip_sensors~%~%# the finger contact conditions that determine what our goal is~%# Leaving this field blank will result in the robot closing until~%# contact on BOTH fingers is achieved~%int8 contact_conditions~%~%# predefined values for the above contact_conditions variable~%int8 BOTH = 0   # both fingers must make contact~%int8 LEFT = 1   # just the left finger ~%int8 RIGHT = 2  # just the right finger~%int8 EITHER = 3 # either finger, we don't care which~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperFindContactCommand>))
  (cl:+ 0
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperFindContactCommand>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperFindContactCommand
    (cl:cons ':zero_fingertip_sensors (zero_fingertip_sensors msg))
    (cl:cons ':contact_conditions (contact_conditions msg))
))
