; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperPressureData.msg.html

(cl:defclass <PR2GripperPressureData> (roslisp-msg-protocol:ros-message)
  ((pressure_left
    :reader pressure_left
    :initarg :pressure_left
    :type (cl:vector cl:float)
   :initform (cl:make-array 22 :element-type 'cl:float :initial-element 0.0))
   (pressure_right
    :reader pressure_right
    :initarg :pressure_right
    :type (cl:vector cl:float)
   :initform (cl:make-array 22 :element-type 'cl:float :initial-element 0.0))
   (rostime
    :reader rostime
    :initarg :rostime
    :type cl:float
    :initform 0.0))
)

(cl:defclass PR2GripperPressureData (<PR2GripperPressureData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperPressureData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperPressureData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperPressureData> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperPressureData instead.")))

(cl:ensure-generic-function 'pressure_left-val :lambda-list '(m))
(cl:defmethod pressure_left-val ((m <PR2GripperPressureData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:pressure_left-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:pressure_left instead.")
  (pressure_left m))

(cl:ensure-generic-function 'pressure_right-val :lambda-list '(m))
(cl:defmethod pressure_right-val ((m <PR2GripperPressureData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:pressure_right-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:pressure_right instead.")
  (pressure_right m))

(cl:ensure-generic-function 'rostime-val :lambda-list '(m))
(cl:defmethod rostime-val ((m <PR2GripperPressureData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:rostime-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:rostime instead.")
  (rostime m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperPressureData>) ostream)
  "Serializes a message object of type '<PR2GripperPressureData>"
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'pressure_left))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'pressure_right))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'rostime))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperPressureData>) istream)
  "Deserializes a message object of type '<PR2GripperPressureData>"
  (cl:setf (cl:slot-value msg 'pressure_left) (cl:make-array 22))
  (cl:let ((vals (cl:slot-value msg 'pressure_left)))
    (cl:dotimes (i 22)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  (cl:setf (cl:slot-value msg 'pressure_right) (cl:make-array 22))
  (cl:let ((vals (cl:slot-value msg 'pressure_right)))
    (cl:dotimes (i 22)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'rostime) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperPressureData>)))
  "Returns string type for a message object of type '<PR2GripperPressureData>"
  "pr2_gripper_sensor_msgs/PR2GripperPressureData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperPressureData)))
  "Returns string type for a message object of type 'PR2GripperPressureData"
  "pr2_gripper_sensor_msgs/PR2GripperPressureData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperPressureData>)))
  "Returns md5sum for a message object of type '<PR2GripperPressureData>"
  "b69255f5117bf05fdcd1e83d4e6ab779")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperPressureData)))
  "Returns md5sum for a message object of type 'PR2GripperPressureData"
  "b69255f5117bf05fdcd1e83d4e6ab779")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperPressureData>)))
  "Returns full string definition for message of type '<PR2GripperPressureData>"
  (cl:format cl:nil "# Note: This message is intended for internal package use only and is NOT a part of the public API. This data is not publicaly published in ROS.~%~%# the pressure array for the left and right fingers~%float64[22] pressure_left~%float64[22] pressure_right~%~%float64 rostime~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperPressureData)))
  "Returns full string definition for message of type 'PR2GripperPressureData"
  (cl:format cl:nil "# Note: This message is intended for internal package use only and is NOT a part of the public API. This data is not publicaly published in ROS.~%~%# the pressure array for the left and right fingers~%float64[22] pressure_left~%float64[22] pressure_right~%~%float64 rostime~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperPressureData>))
  (cl:+ 0
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'pressure_left) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'pressure_right) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperPressureData>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperPressureData
    (cl:cons ':pressure_left (pressure_left msg))
    (cl:cons ':pressure_right (pressure_right msg))
    (cl:cons ':rostime (rostime msg))
))
