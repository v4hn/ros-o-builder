(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(STAMP-VAL
          STAMP
          LEFT_FINGERTIP_PAD_FORCE-VAL
          LEFT_FINGERTIP_PAD_FORCE
          RIGHT_FINGERTIP_PAD_FORCE-VAL
          RIGHT_FINGERTIP_PAD_FORCE
          JOINT_EFFORT-VAL
          JOINT_EFFORT
          FORCE_ACHIEVED-VAL
          FORCE_ACHIEVED
          RTSTATE-VAL
          RTSTATE
))