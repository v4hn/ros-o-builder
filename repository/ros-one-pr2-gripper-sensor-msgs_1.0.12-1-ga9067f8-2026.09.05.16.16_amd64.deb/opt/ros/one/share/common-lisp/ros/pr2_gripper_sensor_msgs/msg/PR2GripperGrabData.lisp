; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperGrabData.msg.html

(cl:defclass <PR2GripperGrabData> (roslisp-msg-protocol:ros-message)
  ((rtstate
    :reader rtstate
    :initarg :rtstate
    :type pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState
    :initform (cl:make-instance 'pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState)))
)

(cl:defclass PR2GripperGrabData (<PR2GripperGrabData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperGrabData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperGrabData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperGrabData> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperGrabData instead.")))

(cl:ensure-generic-function 'rtstate-val :lambda-list '(m))
(cl:defmethod rtstate-val ((m <PR2GripperGrabData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:rtstate-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:rtstate instead.")
  (rtstate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperGrabData>) ostream)
  "Serializes a message object of type '<PR2GripperGrabData>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'rtstate) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperGrabData>) istream)
  "Deserializes a message object of type '<PR2GripperGrabData>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'rtstate) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperGrabData>)))
  "Returns string type for a message object of type '<PR2GripperGrabData>"
  "pr2_gripper_sensor_msgs/PR2GripperGrabData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperGrabData)))
  "Returns string type for a message object of type 'PR2GripperGrabData"
  "pr2_gripper_sensor_msgs/PR2GripperGrabData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperGrabData>)))
  "Returns md5sum for a message object of type '<PR2GripperGrabData>"
  "2c917fd7a48bc8daa7ae36787c8b7a82")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperGrabData)))
  "Returns md5sum for a message object of type 'PR2GripperGrabData"
  "2c917fd7a48bc8daa7ae36787c8b7a82")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperGrabData>)))
  "Returns full string definition for message of type '<PR2GripperGrabData>"
  (cl:format cl:nil "# the control state of our realtime controller~%PR2GripperSensorRTState rtstate~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState~%# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperGrabData)))
  "Returns full string definition for message of type 'PR2GripperGrabData"
  (cl:format cl:nil "# the control state of our realtime controller~%PR2GripperSensorRTState rtstate~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState~%# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperGrabData>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'rtstate))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperGrabData>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperGrabData
    (cl:cons ':rtstate (rtstate msg))
))
