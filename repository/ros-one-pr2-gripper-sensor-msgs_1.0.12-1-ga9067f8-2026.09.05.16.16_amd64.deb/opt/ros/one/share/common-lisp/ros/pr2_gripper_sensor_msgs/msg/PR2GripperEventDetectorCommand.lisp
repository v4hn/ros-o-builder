; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperEventDetectorCommand.msg.html

(cl:defclass <PR2GripperEventDetectorCommand> (roslisp-msg-protocol:ros-message)
  ((trigger_conditions
    :reader trigger_conditions
    :initarg :trigger_conditions
    :type cl:fixnum
    :initform 0)
   (acceleration_trigger_magnitude
    :reader acceleration_trigger_magnitude
    :initarg :acceleration_trigger_magnitude
    :type cl:float
    :initform 0.0)
   (slip_trigger_magnitude
    :reader slip_trigger_magnitude
    :initarg :slip_trigger_magnitude
    :type cl:float
    :initform 0.0))
)

(cl:defclass PR2GripperEventDetectorCommand (<PR2GripperEventDetectorCommand>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperEventDetectorCommand>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperEventDetectorCommand)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperEventDetectorCommand> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperEventDetectorCommand instead.")))

(cl:ensure-generic-function 'trigger_conditions-val :lambda-list '(m))
(cl:defmethod trigger_conditions-val ((m <PR2GripperEventDetectorCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:trigger_conditions-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:trigger_conditions instead.")
  (trigger_conditions m))

(cl:ensure-generic-function 'acceleration_trigger_magnitude-val :lambda-list '(m))
(cl:defmethod acceleration_trigger_magnitude-val ((m <PR2GripperEventDetectorCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acceleration_trigger_magnitude-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acceleration_trigger_magnitude instead.")
  (acceleration_trigger_magnitude m))

(cl:ensure-generic-function 'slip_trigger_magnitude-val :lambda-list '(m))
(cl:defmethod slip_trigger_magnitude-val ((m <PR2GripperEventDetectorCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:slip_trigger_magnitude-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:slip_trigger_magnitude instead.")
  (slip_trigger_magnitude m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<PR2GripperEventDetectorCommand>)))
    "Constants for message type '<PR2GripperEventDetectorCommand>"
  '((:FINGER_SIDE_IMPACT_OR_ACC . 0)
    (:SLIP_AND_ACC . 1)
    (:FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC . 2)
    (:SLIP . 3)
    (:ACC . 4))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'PR2GripperEventDetectorCommand)))
    "Constants for message type 'PR2GripperEventDetectorCommand"
  '((:FINGER_SIDE_IMPACT_OR_ACC . 0)
    (:SLIP_AND_ACC . 1)
    (:FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC . 2)
    (:SLIP . 3)
    (:ACC . 4))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperEventDetectorCommand>) ostream)
  "Serializes a message object of type '<PR2GripperEventDetectorCommand>"
  (cl:let* ((signed (cl:slot-value msg 'trigger_conditions)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acceleration_trigger_magnitude))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'slip_trigger_magnitude))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperEventDetectorCommand>) istream)
  "Deserializes a message object of type '<PR2GripperEventDetectorCommand>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'trigger_conditions) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acceleration_trigger_magnitude) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'slip_trigger_magnitude) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperEventDetectorCommand>)))
  "Returns string type for a message object of type '<PR2GripperEventDetectorCommand>"
  "pr2_gripper_sensor_msgs/PR2GripperEventDetectorCommand")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperEventDetectorCommand)))
  "Returns string type for a message object of type 'PR2GripperEventDetectorCommand"
  "pr2_gripper_sensor_msgs/PR2GripperEventDetectorCommand")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperEventDetectorCommand>)))
  "Returns md5sum for a message object of type '<PR2GripperEventDetectorCommand>"
  "b91a7e1e863671a84c1d06e0cac3146e")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperEventDetectorCommand)))
  "Returns md5sum for a message object of type 'PR2GripperEventDetectorCommand"
  "b91a7e1e863671a84c1d06e0cac3146e")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperEventDetectorCommand>)))
  "Returns full string definition for message of type '<PR2GripperEventDetectorCommand>"
  (cl:format cl:nil "# state variable that defines what events we would like to trigger on~%# Leaving this field blank will result in the robot triggering when ~%# anything touches the sides of the finger or an impact is detected~%# with the hand/arm.~%int8 trigger_conditions~%# definitions for our various trigger_conditions values~%# trigger on either acceleration contact or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_ACC = 0~%# tigger once  both slip and acceleration signals occur~%int8 SLIP_AND_ACC = 1 ~%#  trigger on either slip, acceleration, or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC = 2~%# trigger only on slip information~%int8 SLIP = 3~%# trigger only on acceleration contact information~%int8 ACC = 4 ~%~%~%# the amount of acceleration to trigger on (acceleration vector magnitude)~%# Units = m/s^2~%# The user needs to be concerned here about not setting the trigger too~%# low so that is set off by the robot's own motions.~%#~%# For large rapid motions, say by a motion planner, 5 m/s^2 is a good level~%# For small delicate controlled motions this can be set MUCH lower (try 2.0)~%#~%# NOTE: When moving the gripper joint (opening/closing the grippr)~%# the high gearing of the PR2 gripper causes large acceleration vibrations~%# which will cause triggering to occur. This is a known drawback of the PR2.~%#~%# NOTE: Leaving this value blank will result in a 0 m/s^2 trigger. If you~%# are using a trigger_conditions value that returns on acceleration contact~%# events then it will immediately exceed your trigger and return~%float64 acceleration_trigger_magnitude~%~%~%# the slip detector gain to trigger on (either finger) : try 0.01~%# higher values decrease slip sensitivty (to a point)~%# lower values increase sensitivity (to a point)~%#~%# NOTE: Leaving this value blank will result in the most sensitive slip level.~%float64 slip_trigger_magnitude~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperEventDetectorCommand)))
  "Returns full string definition for message of type 'PR2GripperEventDetectorCommand"
  (cl:format cl:nil "# state variable that defines what events we would like to trigger on~%# Leaving this field blank will result in the robot triggering when ~%# anything touches the sides of the finger or an impact is detected~%# with the hand/arm.~%int8 trigger_conditions~%# definitions for our various trigger_conditions values~%# trigger on either acceleration contact or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_ACC = 0~%# tigger once  both slip and acceleration signals occur~%int8 SLIP_AND_ACC = 1 ~%#  trigger on either slip, acceleration, or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC = 2~%# trigger only on slip information~%int8 SLIP = 3~%# trigger only on acceleration contact information~%int8 ACC = 4 ~%~%~%# the amount of acceleration to trigger on (acceleration vector magnitude)~%# Units = m/s^2~%# The user needs to be concerned here about not setting the trigger too~%# low so that is set off by the robot's own motions.~%#~%# For large rapid motions, say by a motion planner, 5 m/s^2 is a good level~%# For small delicate controlled motions this can be set MUCH lower (try 2.0)~%#~%# NOTE: When moving the gripper joint (opening/closing the grippr)~%# the high gearing of the PR2 gripper causes large acceleration vibrations~%# which will cause triggering to occur. This is a known drawback of the PR2.~%#~%# NOTE: Leaving this value blank will result in a 0 m/s^2 trigger. If you~%# are using a trigger_conditions value that returns on acceleration contact~%# events then it will immediately exceed your trigger and return~%float64 acceleration_trigger_magnitude~%~%~%# the slip detector gain to trigger on (either finger) : try 0.01~%# higher values decrease slip sensitivty (to a point)~%# lower values increase sensitivity (to a point)~%#~%# NOTE: Leaving this value blank will result in the most sensitive slip level.~%float64 slip_trigger_magnitude~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperEventDetectorCommand>))
  (cl:+ 0
     1
     8
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperEventDetectorCommand>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperEventDetectorCommand
    (cl:cons ':trigger_conditions (trigger_conditions msg))
    (cl:cons ':acceleration_trigger_magnitude (acceleration_trigger_magnitude msg))
    (cl:cons ':slip_trigger_magnitude (slip_trigger_magnitude msg))
))
