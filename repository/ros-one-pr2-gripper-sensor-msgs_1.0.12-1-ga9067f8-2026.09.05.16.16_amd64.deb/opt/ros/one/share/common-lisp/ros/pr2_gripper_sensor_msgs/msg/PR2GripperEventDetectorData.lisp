; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperEventDetectorData.msg.html

(cl:defclass <PR2GripperEventDetectorData> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (trigger_conditions_met
    :reader trigger_conditions_met
    :initarg :trigger_conditions_met
    :type cl:boolean
    :initform cl:nil)
   (slip_event
    :reader slip_event
    :initarg :slip_event
    :type cl:boolean
    :initform cl:nil)
   (acceleration_event
    :reader acceleration_event
    :initarg :acceleration_event
    :type cl:boolean
    :initform cl:nil)
   (acceleration_vector
    :reader acceleration_vector
    :initarg :acceleration_vector
    :type (cl:vector cl:float)
   :initform (cl:make-array 3 :element-type 'cl:float :initial-element 0.0)))
)

(cl:defclass PR2GripperEventDetectorData (<PR2GripperEventDetectorData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperEventDetectorData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperEventDetectorData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperEventDetectorData> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperEventDetectorData instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <PR2GripperEventDetectorData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:stamp-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'trigger_conditions_met-val :lambda-list '(m))
(cl:defmethod trigger_conditions_met-val ((m <PR2GripperEventDetectorData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:trigger_conditions_met-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:trigger_conditions_met instead.")
  (trigger_conditions_met m))

(cl:ensure-generic-function 'slip_event-val :lambda-list '(m))
(cl:defmethod slip_event-val ((m <PR2GripperEventDetectorData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:slip_event-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:slip_event instead.")
  (slip_event m))

(cl:ensure-generic-function 'acceleration_event-val :lambda-list '(m))
(cl:defmethod acceleration_event-val ((m <PR2GripperEventDetectorData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acceleration_event-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acceleration_event instead.")
  (acceleration_event m))

(cl:ensure-generic-function 'acceleration_vector-val :lambda-list '(m))
(cl:defmethod acceleration_vector-val ((m <PR2GripperEventDetectorData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acceleration_vector-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acceleration_vector instead.")
  (acceleration_vector m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperEventDetectorData>) ostream)
  "Serializes a message object of type '<PR2GripperEventDetectorData>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'trigger_conditions_met) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'slip_event) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'acceleration_event) 1 0)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'acceleration_vector))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperEventDetectorData>) istream)
  "Deserializes a message object of type '<PR2GripperEventDetectorData>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:slot-value msg 'trigger_conditions_met) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'slip_event) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'acceleration_event) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:setf (cl:slot-value msg 'acceleration_vector) (cl:make-array 3))
  (cl:let ((vals (cl:slot-value msg 'acceleration_vector)))
    (cl:dotimes (i 3)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperEventDetectorData>)))
  "Returns string type for a message object of type '<PR2GripperEventDetectorData>"
  "pr2_gripper_sensor_msgs/PR2GripperEventDetectorData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperEventDetectorData)))
  "Returns string type for a message object of type 'PR2GripperEventDetectorData"
  "pr2_gripper_sensor_msgs/PR2GripperEventDetectorData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperEventDetectorData>)))
  "Returns md5sum for a message object of type '<PR2GripperEventDetectorData>"
  "9536d682ef6215440ecc47846d4117c2")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperEventDetectorData)))
  "Returns md5sum for a message object of type 'PR2GripperEventDetectorData"
  "9536d682ef6215440ecc47846d4117c2")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperEventDetectorData>)))
  "Returns full string definition for message of type '<PR2GripperEventDetectorData>"
  (cl:format cl:nil "# Time the data was recorded at~%time stamp~%~%# true if the trigger conditions have been met ~%# (see PR2GripperEventDetectorCommand)~%bool trigger_conditions_met~%~%# true if the pressure sensors detected a slip event~%# slip events occur when the finger pressure sensors~%# high-freq. content exceeds the slip_trigger_magnitude variable~%# (see PR2GripperEventDetectorCommand)~%bool slip_event~%~%# true if the hand-mounted accelerometer detected a contact acceleration~%# acceleration events occur when the palm accelerometer~%# high-freq. content exceeds the acc_trigger_magnitude variable~%# (see PR2GripperEventDetectorCommand)~%bool acceleration_event~%~%# the high-freq acceleration vector that was last seen (x,y,z)~%float64[3] acceleration_vector~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperEventDetectorData)))
  "Returns full string definition for message of type 'PR2GripperEventDetectorData"
  (cl:format cl:nil "# Time the data was recorded at~%time stamp~%~%# true if the trigger conditions have been met ~%# (see PR2GripperEventDetectorCommand)~%bool trigger_conditions_met~%~%# true if the pressure sensors detected a slip event~%# slip events occur when the finger pressure sensors~%# high-freq. content exceeds the slip_trigger_magnitude variable~%# (see PR2GripperEventDetectorCommand)~%bool slip_event~%~%# true if the hand-mounted accelerometer detected a contact acceleration~%# acceleration events occur when the palm accelerometer~%# high-freq. content exceeds the acc_trigger_magnitude variable~%# (see PR2GripperEventDetectorCommand)~%bool acceleration_event~%~%# the high-freq acceleration vector that was last seen (x,y,z)~%float64[3] acceleration_vector~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperEventDetectorData>))
  (cl:+ 0
     8
     1
     1
     1
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'acceleration_vector) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperEventDetectorData>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperEventDetectorData
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':trigger_conditions_met (trigger_conditions_met msg))
    (cl:cons ':slip_event (slip_event msg))
    (cl:cons ':acceleration_event (acceleration_event msg))
    (cl:cons ':acceleration_vector (acceleration_vector msg))
))
