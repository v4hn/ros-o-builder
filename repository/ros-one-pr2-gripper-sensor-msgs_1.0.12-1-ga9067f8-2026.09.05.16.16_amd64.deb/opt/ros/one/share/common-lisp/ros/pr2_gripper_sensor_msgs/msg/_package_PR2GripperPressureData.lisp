(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(PRESSURE_LEFT-VAL
          PRESSURE_LEFT
          PRESSURE_RIGHT-VAL
          PRESSURE_RIGHT
          ROSTIME-VAL
          ROSTIME
))