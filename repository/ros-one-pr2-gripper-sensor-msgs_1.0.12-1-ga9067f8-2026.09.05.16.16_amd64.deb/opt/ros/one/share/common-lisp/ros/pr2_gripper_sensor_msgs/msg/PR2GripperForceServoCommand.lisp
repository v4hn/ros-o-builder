; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperForceServoCommand.msg.html

(cl:defclass <PR2GripperForceServoCommand> (roslisp-msg-protocol:ros-message)
  ((fingertip_force
    :reader fingertip_force
    :initarg :fingertip_force
    :type cl:float
    :initform 0.0))
)

(cl:defclass PR2GripperForceServoCommand (<PR2GripperForceServoCommand>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperForceServoCommand>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperForceServoCommand)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperForceServoCommand> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperForceServoCommand instead.")))

(cl:ensure-generic-function 'fingertip_force-val :lambda-list '(m))
(cl:defmethod fingertip_force-val ((m <PR2GripperForceServoCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:fingertip_force-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:fingertip_force instead.")
  (fingertip_force m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperForceServoCommand>) ostream)
  "Serializes a message object of type '<PR2GripperForceServoCommand>"
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'fingertip_force))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperForceServoCommand>) istream)
  "Deserializes a message object of type '<PR2GripperForceServoCommand>"
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'fingertip_force) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperForceServoCommand>)))
  "Returns string type for a message object of type '<PR2GripperForceServoCommand>"
  "pr2_gripper_sensor_msgs/PR2GripperForceServoCommand")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperForceServoCommand)))
  "Returns string type for a message object of type 'PR2GripperForceServoCommand"
  "pr2_gripper_sensor_msgs/PR2GripperForceServoCommand")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperForceServoCommand>)))
  "Returns md5sum for a message object of type '<PR2GripperForceServoCommand>"
  "dd4b2a0dfafa27b67d2002841f544379")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperForceServoCommand)))
  "Returns md5sum for a message object of type 'PR2GripperForceServoCommand"
  "dd4b2a0dfafa27b67d2002841f544379")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperForceServoCommand>)))
  "Returns full string definition for message of type '<PR2GripperForceServoCommand>"
  (cl:format cl:nil "# the amount of fingertip force (in Newtons) to apply.~%# NOTE: the joint will squeeze until each finger reaches this level~%# values < 0 (opening force) are ignored~%#~%# 10 N can crack an egg or crush a soda can.~%# 15 N can firmly pick up a can of soup.~%# Experiment on your own.~%#~%float64 fingertip_force~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperForceServoCommand)))
  "Returns full string definition for message of type 'PR2GripperForceServoCommand"
  (cl:format cl:nil "# the amount of fingertip force (in Newtons) to apply.~%# NOTE: the joint will squeeze until each finger reaches this level~%# values < 0 (opening force) are ignored~%#~%# 10 N can crack an egg or crush a soda can.~%# 15 N can firmly pick up a can of soup.~%# Experiment on your own.~%#~%float64 fingertip_force~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperForceServoCommand>))
  (cl:+ 0
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperForceServoCommand>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperForceServoCommand
    (cl:cons ':fingertip_force (fingertip_force msg))
))
