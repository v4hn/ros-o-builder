(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(HARDNESS_GAIN-VAL
          HARDNESS_GAIN
))