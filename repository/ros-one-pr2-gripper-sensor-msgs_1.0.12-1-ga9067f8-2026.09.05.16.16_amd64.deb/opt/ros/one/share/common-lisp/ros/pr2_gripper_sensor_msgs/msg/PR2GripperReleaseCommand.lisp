; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperReleaseCommand.msg.html

(cl:defclass <PR2GripperReleaseCommand> (roslisp-msg-protocol:ros-message)
  ((event
    :reader event
    :initarg :event
    :type pr2_gripper_sensor_msgs-msg:PR2GripperEventDetectorCommand
    :initform (cl:make-instance 'pr2_gripper_sensor_msgs-msg:PR2GripperEventDetectorCommand)))
)

(cl:defclass PR2GripperReleaseCommand (<PR2GripperReleaseCommand>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperReleaseCommand>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperReleaseCommand)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperReleaseCommand> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperReleaseCommand instead.")))

(cl:ensure-generic-function 'event-val :lambda-list '(m))
(cl:defmethod event-val ((m <PR2GripperReleaseCommand>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:event-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:event instead.")
  (event m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperReleaseCommand>) ostream)
  "Serializes a message object of type '<PR2GripperReleaseCommand>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'event) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperReleaseCommand>) istream)
  "Deserializes a message object of type '<PR2GripperReleaseCommand>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'event) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperReleaseCommand>)))
  "Returns string type for a message object of type '<PR2GripperReleaseCommand>"
  "pr2_gripper_sensor_msgs/PR2GripperReleaseCommand")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperReleaseCommand)))
  "Returns string type for a message object of type 'PR2GripperReleaseCommand"
  "pr2_gripper_sensor_msgs/PR2GripperReleaseCommand")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperReleaseCommand>)))
  "Returns md5sum for a message object of type '<PR2GripperReleaseCommand>"
  "e62b08129864bf301ed0a1335e6158dc")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperReleaseCommand)))
  "Returns md5sum for a message object of type 'PR2GripperReleaseCommand"
  "e62b08129864bf301ed0a1335e6158dc")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperReleaseCommand>)))
  "Returns full string definition for message of type '<PR2GripperReleaseCommand>"
  (cl:format cl:nil "# the event conditions we would like to trigger the robot to release on~%PR2GripperEventDetectorCommand event~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperEventDetectorCommand~%# state variable that defines what events we would like to trigger on~%# Leaving this field blank will result in the robot triggering when ~%# anything touches the sides of the finger or an impact is detected~%# with the hand/arm.~%int8 trigger_conditions~%# definitions for our various trigger_conditions values~%# trigger on either acceleration contact or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_ACC = 0~%# tigger once  both slip and acceleration signals occur~%int8 SLIP_AND_ACC = 1 ~%#  trigger on either slip, acceleration, or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC = 2~%# trigger only on slip information~%int8 SLIP = 3~%# trigger only on acceleration contact information~%int8 ACC = 4 ~%~%~%# the amount of acceleration to trigger on (acceleration vector magnitude)~%# Units = m/s^2~%# The user needs to be concerned here about not setting the trigger too~%# low so that is set off by the robot's own motions.~%#~%# For large rapid motions, say by a motion planner, 5 m/s^2 is a good level~%# For small delicate controlled motions this can be set MUCH lower (try 2.0)~%#~%# NOTE: When moving the gripper joint (opening/closing the grippr)~%# the high gearing of the PR2 gripper causes large acceleration vibrations~%# which will cause triggering to occur. This is a known drawback of the PR2.~%#~%# NOTE: Leaving this value blank will result in a 0 m/s^2 trigger. If you~%# are using a trigger_conditions value that returns on acceleration contact~%# events then it will immediately exceed your trigger and return~%float64 acceleration_trigger_magnitude~%~%~%# the slip detector gain to trigger on (either finger) : try 0.01~%# higher values decrease slip sensitivty (to a point)~%# lower values increase sensitivity (to a point)~%#~%# NOTE: Leaving this value blank will result in the most sensitive slip level.~%float64 slip_trigger_magnitude~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperReleaseCommand)))
  "Returns full string definition for message of type 'PR2GripperReleaseCommand"
  (cl:format cl:nil "# the event conditions we would like to trigger the robot to release on~%PR2GripperEventDetectorCommand event~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperEventDetectorCommand~%# state variable that defines what events we would like to trigger on~%# Leaving this field blank will result in the robot triggering when ~%# anything touches the sides of the finger or an impact is detected~%# with the hand/arm.~%int8 trigger_conditions~%# definitions for our various trigger_conditions values~%# trigger on either acceleration contact or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_ACC = 0~%# tigger once  both slip and acceleration signals occur~%int8 SLIP_AND_ACC = 1 ~%#  trigger on either slip, acceleration, or finger sensor side impact~%int8 FINGER_SIDE_IMPACT_OR_SLIP_OR_ACC = 2~%# trigger only on slip information~%int8 SLIP = 3~%# trigger only on acceleration contact information~%int8 ACC = 4 ~%~%~%# the amount of acceleration to trigger on (acceleration vector magnitude)~%# Units = m/s^2~%# The user needs to be concerned here about not setting the trigger too~%# low so that is set off by the robot's own motions.~%#~%# For large rapid motions, say by a motion planner, 5 m/s^2 is a good level~%# For small delicate controlled motions this can be set MUCH lower (try 2.0)~%#~%# NOTE: When moving the gripper joint (opening/closing the grippr)~%# the high gearing of the PR2 gripper causes large acceleration vibrations~%# which will cause triggering to occur. This is a known drawback of the PR2.~%#~%# NOTE: Leaving this value blank will result in a 0 m/s^2 trigger. If you~%# are using a trigger_conditions value that returns on acceleration contact~%# events then it will immediately exceed your trigger and return~%float64 acceleration_trigger_magnitude~%~%~%# the slip detector gain to trigger on (either finger) : try 0.01~%# higher values decrease slip sensitivty (to a point)~%# lower values increase sensitivity (to a point)~%#~%# NOTE: Leaving this value blank will result in the most sensitive slip level.~%float64 slip_trigger_magnitude~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperReleaseCommand>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'event))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperReleaseCommand>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperReleaseCommand
    (cl:cons ':event (event msg))
))
