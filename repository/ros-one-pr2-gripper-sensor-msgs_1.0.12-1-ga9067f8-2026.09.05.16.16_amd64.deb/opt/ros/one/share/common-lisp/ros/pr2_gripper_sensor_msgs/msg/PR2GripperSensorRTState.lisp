; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperSensorRTState.msg.html

(cl:defclass <PR2GripperSensorRTState> (roslisp-msg-protocol:ros-message)
  ((realtime_controller_state
    :reader realtime_controller_state
    :initarg :realtime_controller_state
    :type cl:fixnum
    :initform 0))
)

(cl:defclass PR2GripperSensorRTState (<PR2GripperSensorRTState>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperSensorRTState>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperSensorRTState)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperSensorRTState> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState instead.")))

(cl:ensure-generic-function 'realtime_controller_state-val :lambda-list '(m))
(cl:defmethod realtime_controller_state-val ((m <PR2GripperSensorRTState>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:realtime_controller_state-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:realtime_controller_state instead.")
  (realtime_controller_state m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<PR2GripperSensorRTState>)))
    "Constants for message type '<PR2GripperSensorRTState>"
  '((:DISABLED . 0)
    (:POSITION_SERVO . 3)
    (:FORCE_SERVO . 4)
    (:FIND_CONTACT . 5)
    (:SLIP_SERVO . 6))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'PR2GripperSensorRTState)))
    "Constants for message type 'PR2GripperSensorRTState"
  '((:DISABLED . 0)
    (:POSITION_SERVO . 3)
    (:FORCE_SERVO . 4)
    (:FIND_CONTACT . 5)
    (:SLIP_SERVO . 6))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperSensorRTState>) ostream)
  "Serializes a message object of type '<PR2GripperSensorRTState>"
  (cl:let* ((signed (cl:slot-value msg 'realtime_controller_state)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperSensorRTState>) istream)
  "Deserializes a message object of type '<PR2GripperSensorRTState>"
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'realtime_controller_state) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperSensorRTState>)))
  "Returns string type for a message object of type '<PR2GripperSensorRTState>"
  "pr2_gripper_sensor_msgs/PR2GripperSensorRTState")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperSensorRTState)))
  "Returns string type for a message object of type 'PR2GripperSensorRTState"
  "pr2_gripper_sensor_msgs/PR2GripperSensorRTState")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperSensorRTState>)))
  "Returns md5sum for a message object of type '<PR2GripperSensorRTState>"
  "8109436c1f7237c52c00d885ed5755d7")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperSensorRTState)))
  "Returns md5sum for a message object of type 'PR2GripperSensorRTState"
  "8109436c1f7237c52c00d885ed5755d7")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperSensorRTState>)))
  "Returns full string definition for message of type '<PR2GripperSensorRTState>"
  (cl:format cl:nil "# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperSensorRTState)))
  "Returns full string definition for message of type 'PR2GripperSensorRTState"
  (cl:format cl:nil "# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperSensorRTState>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperSensorRTState>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperSensorRTState
    (cl:cons ':realtime_controller_state (realtime_controller_state msg))
))
