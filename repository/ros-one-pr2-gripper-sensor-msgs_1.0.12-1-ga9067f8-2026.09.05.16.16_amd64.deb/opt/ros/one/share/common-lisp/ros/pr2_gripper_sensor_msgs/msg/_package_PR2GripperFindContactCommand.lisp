(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(ZERO_FINGERTIP_SENSORS-VAL
          ZERO_FINGERTIP_SENSORS
          CONTACT_CONDITIONS-VAL
          CONTACT_CONDITIONS
))