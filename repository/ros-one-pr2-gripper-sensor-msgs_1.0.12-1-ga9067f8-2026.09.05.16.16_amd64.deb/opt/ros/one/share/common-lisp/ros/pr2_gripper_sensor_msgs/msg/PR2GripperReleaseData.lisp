; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperReleaseData.msg.html

(cl:defclass <PR2GripperReleaseData> (roslisp-msg-protocol:ros-message)
  ((rtstate
    :reader rtstate
    :initarg :rtstate
    :type pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState
    :initform (cl:make-instance 'pr2_gripper_sensor_msgs-msg:PR2GripperSensorRTState)))
)

(cl:defclass PR2GripperReleaseData (<PR2GripperReleaseData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperReleaseData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperReleaseData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperReleaseData> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperReleaseData instead.")))

(cl:ensure-generic-function 'rtstate-val :lambda-list '(m))
(cl:defmethod rtstate-val ((m <PR2GripperReleaseData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:rtstate-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:rtstate instead.")
  (rtstate m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperReleaseData>) ostream)
  "Serializes a message object of type '<PR2GripperReleaseData>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'rtstate) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperReleaseData>) istream)
  "Deserializes a message object of type '<PR2GripperReleaseData>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'rtstate) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperReleaseData>)))
  "Returns string type for a message object of type '<PR2GripperReleaseData>"
  "pr2_gripper_sensor_msgs/PR2GripperReleaseData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperReleaseData)))
  "Returns string type for a message object of type 'PR2GripperReleaseData"
  "pr2_gripper_sensor_msgs/PR2GripperReleaseData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperReleaseData>)))
  "Returns md5sum for a message object of type '<PR2GripperReleaseData>"
  "2c917fd7a48bc8daa7ae36787c8b7a82")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperReleaseData)))
  "Returns md5sum for a message object of type 'PR2GripperReleaseData"
  "2c917fd7a48bc8daa7ae36787c8b7a82")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperReleaseData>)))
  "Returns full string definition for message of type '<PR2GripperReleaseData>"
  (cl:format cl:nil "# the control state of our realtime controller~%PR2GripperSensorRTState rtstate~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState~%# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperReleaseData)))
  "Returns full string definition for message of type 'PR2GripperReleaseData"
  (cl:format cl:nil "# the control state of our realtime controller~%PR2GripperSensorRTState rtstate~%================================================================================~%MSG: pr2_gripper_sensor_msgs/PR2GripperSensorRTState~%# the control state of our realtime controller~%int8 realtime_controller_state~%~%# predefined values to indicate our realtime_controller_state~%int8 DISABLED = 0~%int8 POSITION_SERVO = 3~%int8 FORCE_SERVO = 4~%int8 FIND_CONTACT = 5~%int8 SLIP_SERVO = 6~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperReleaseData>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'rtstate))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperReleaseData>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperReleaseData
    (cl:cons ':rtstate (rtstate msg))
))
