(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(FINGERTIP_FORCE-VAL
          FINGERTIP_FORCE
))