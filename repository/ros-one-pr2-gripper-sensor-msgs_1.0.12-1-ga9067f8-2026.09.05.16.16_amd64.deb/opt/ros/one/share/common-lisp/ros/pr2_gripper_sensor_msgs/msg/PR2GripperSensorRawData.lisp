; Auto-generated. Do not edit!


(cl:in-package pr2_gripper_sensor_msgs-msg)


;//! \htmlinclude PR2GripperSensorRawData.msg.html

(cl:defclass <PR2GripperSensorRawData> (roslisp-msg-protocol:ros-message)
  ((stamp
    :reader stamp
    :initarg :stamp
    :type cl:real
    :initform 0)
   (left_finger_pad_force
    :reader left_finger_pad_force
    :initarg :left_finger_pad_force
    :type cl:float
    :initform 0.0)
   (right_finger_pad_force
    :reader right_finger_pad_force
    :initarg :right_finger_pad_force
    :type cl:float
    :initform 0.0)
   (left_finger_pad_force_filtered
    :reader left_finger_pad_force_filtered
    :initarg :left_finger_pad_force_filtered
    :type cl:float
    :initform 0.0)
   (right_finger_pad_force_filtered
    :reader right_finger_pad_force_filtered
    :initarg :right_finger_pad_force_filtered
    :type cl:float
    :initform 0.0)
   (left_finger_pad_forces
    :reader left_finger_pad_forces
    :initarg :left_finger_pad_forces
    :type (cl:vector cl:float)
   :initform (cl:make-array 22 :element-type 'cl:float :initial-element 0.0))
   (right_finger_pad_forces
    :reader right_finger_pad_forces
    :initarg :right_finger_pad_forces
    :type (cl:vector cl:float)
   :initform (cl:make-array 22 :element-type 'cl:float :initial-element 0.0))
   (left_finger_pad_forces_filtered
    :reader left_finger_pad_forces_filtered
    :initarg :left_finger_pad_forces_filtered
    :type (cl:vector cl:float)
   :initform (cl:make-array 22 :element-type 'cl:float :initial-element 0.0))
   (right_finger_pad_forces_filtered
    :reader right_finger_pad_forces_filtered
    :initarg :right_finger_pad_forces_filtered
    :type (cl:vector cl:float)
   :initform (cl:make-array 22 :element-type 'cl:float :initial-element 0.0))
   (acc_x_raw
    :reader acc_x_raw
    :initarg :acc_x_raw
    :type cl:float
    :initform 0.0)
   (acc_y_raw
    :reader acc_y_raw
    :initarg :acc_y_raw
    :type cl:float
    :initform 0.0)
   (acc_z_raw
    :reader acc_z_raw
    :initarg :acc_z_raw
    :type cl:float
    :initform 0.0)
   (acc_x_filtered
    :reader acc_x_filtered
    :initarg :acc_x_filtered
    :type cl:float
    :initform 0.0)
   (acc_y_filtered
    :reader acc_y_filtered
    :initarg :acc_y_filtered
    :type cl:float
    :initform 0.0)
   (acc_z_filtered
    :reader acc_z_filtered
    :initarg :acc_z_filtered
    :type cl:float
    :initform 0.0)
   (left_contact
    :reader left_contact
    :initarg :left_contact
    :type cl:boolean
    :initform cl:nil)
   (right_contact
    :reader right_contact
    :initarg :right_contact
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass PR2GripperSensorRawData (<PR2GripperSensorRawData>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PR2GripperSensorRawData>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PR2GripperSensorRawData)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name pr2_gripper_sensor_msgs-msg:<PR2GripperSensorRawData> is deprecated: use pr2_gripper_sensor_msgs-msg:PR2GripperSensorRawData instead.")))

(cl:ensure-generic-function 'stamp-val :lambda-list '(m))
(cl:defmethod stamp-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:stamp-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:stamp instead.")
  (stamp m))

(cl:ensure-generic-function 'left_finger_pad_force-val :lambda-list '(m))
(cl:defmethod left_finger_pad_force-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:left_finger_pad_force-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:left_finger_pad_force instead.")
  (left_finger_pad_force m))

(cl:ensure-generic-function 'right_finger_pad_force-val :lambda-list '(m))
(cl:defmethod right_finger_pad_force-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:right_finger_pad_force-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:right_finger_pad_force instead.")
  (right_finger_pad_force m))

(cl:ensure-generic-function 'left_finger_pad_force_filtered-val :lambda-list '(m))
(cl:defmethod left_finger_pad_force_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:left_finger_pad_force_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:left_finger_pad_force_filtered instead.")
  (left_finger_pad_force_filtered m))

(cl:ensure-generic-function 'right_finger_pad_force_filtered-val :lambda-list '(m))
(cl:defmethod right_finger_pad_force_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:right_finger_pad_force_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:right_finger_pad_force_filtered instead.")
  (right_finger_pad_force_filtered m))

(cl:ensure-generic-function 'left_finger_pad_forces-val :lambda-list '(m))
(cl:defmethod left_finger_pad_forces-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:left_finger_pad_forces-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:left_finger_pad_forces instead.")
  (left_finger_pad_forces m))

(cl:ensure-generic-function 'right_finger_pad_forces-val :lambda-list '(m))
(cl:defmethod right_finger_pad_forces-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:right_finger_pad_forces-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:right_finger_pad_forces instead.")
  (right_finger_pad_forces m))

(cl:ensure-generic-function 'left_finger_pad_forces_filtered-val :lambda-list '(m))
(cl:defmethod left_finger_pad_forces_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:left_finger_pad_forces_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:left_finger_pad_forces_filtered instead.")
  (left_finger_pad_forces_filtered m))

(cl:ensure-generic-function 'right_finger_pad_forces_filtered-val :lambda-list '(m))
(cl:defmethod right_finger_pad_forces_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:right_finger_pad_forces_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:right_finger_pad_forces_filtered instead.")
  (right_finger_pad_forces_filtered m))

(cl:ensure-generic-function 'acc_x_raw-val :lambda-list '(m))
(cl:defmethod acc_x_raw-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acc_x_raw-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acc_x_raw instead.")
  (acc_x_raw m))

(cl:ensure-generic-function 'acc_y_raw-val :lambda-list '(m))
(cl:defmethod acc_y_raw-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acc_y_raw-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acc_y_raw instead.")
  (acc_y_raw m))

(cl:ensure-generic-function 'acc_z_raw-val :lambda-list '(m))
(cl:defmethod acc_z_raw-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acc_z_raw-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acc_z_raw instead.")
  (acc_z_raw m))

(cl:ensure-generic-function 'acc_x_filtered-val :lambda-list '(m))
(cl:defmethod acc_x_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acc_x_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acc_x_filtered instead.")
  (acc_x_filtered m))

(cl:ensure-generic-function 'acc_y_filtered-val :lambda-list '(m))
(cl:defmethod acc_y_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acc_y_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acc_y_filtered instead.")
  (acc_y_filtered m))

(cl:ensure-generic-function 'acc_z_filtered-val :lambda-list '(m))
(cl:defmethod acc_z_filtered-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:acc_z_filtered-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:acc_z_filtered instead.")
  (acc_z_filtered m))

(cl:ensure-generic-function 'left_contact-val :lambda-list '(m))
(cl:defmethod left_contact-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:left_contact-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:left_contact instead.")
  (left_contact m))

(cl:ensure-generic-function 'right_contact-val :lambda-list '(m))
(cl:defmethod right_contact-val ((m <PR2GripperSensorRawData>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader pr2_gripper_sensor_msgs-msg:right_contact-val is deprecated.  Use pr2_gripper_sensor_msgs-msg:right_contact instead.")
  (right_contact m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PR2GripperSensorRawData>) ostream)
  "Serializes a message object of type '<PR2GripperSensorRawData>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'stamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'stamp) (cl:floor (cl:slot-value msg 'stamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'left_finger_pad_force))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'right_finger_pad_force))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'left_finger_pad_force_filtered))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'right_finger_pad_force_filtered))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'left_finger_pad_forces))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'right_finger_pad_forces))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'left_finger_pad_forces_filtered))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'right_finger_pad_forces_filtered))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acc_x_raw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acc_y_raw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acc_z_raw))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acc_x_filtered))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acc_y_filtered))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acc_z_filtered))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'left_contact) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'right_contact) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PR2GripperSensorRawData>) istream)
  "Deserializes a message object of type '<PR2GripperSensorRawData>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'stamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'left_finger_pad_force) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'right_finger_pad_force) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'left_finger_pad_force_filtered) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'right_finger_pad_force_filtered) (roslisp-utils:decode-double-float-bits bits)))
  (cl:setf (cl:slot-value msg 'left_finger_pad_forces) (cl:make-array 22))
  (cl:let ((vals (cl:slot-value msg 'left_finger_pad_forces)))
    (cl:dotimes (i 22)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  (cl:setf (cl:slot-value msg 'right_finger_pad_forces) (cl:make-array 22))
  (cl:let ((vals (cl:slot-value msg 'right_finger_pad_forces)))
    (cl:dotimes (i 22)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  (cl:setf (cl:slot-value msg 'left_finger_pad_forces_filtered) (cl:make-array 22))
  (cl:let ((vals (cl:slot-value msg 'left_finger_pad_forces_filtered)))
    (cl:dotimes (i 22)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  (cl:setf (cl:slot-value msg 'right_finger_pad_forces_filtered) (cl:make-array 22))
  (cl:let ((vals (cl:slot-value msg 'right_finger_pad_forces_filtered)))
    (cl:dotimes (i 22)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acc_x_raw) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acc_y_raw) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acc_z_raw) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acc_x_filtered) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acc_y_filtered) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acc_z_filtered) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'left_contact) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'right_contact) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PR2GripperSensorRawData>)))
  "Returns string type for a message object of type '<PR2GripperSensorRawData>"
  "pr2_gripper_sensor_msgs/PR2GripperSensorRawData")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PR2GripperSensorRawData)))
  "Returns string type for a message object of type 'PR2GripperSensorRawData"
  "pr2_gripper_sensor_msgs/PR2GripperSensorRawData")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PR2GripperSensorRawData>)))
  "Returns md5sum for a message object of type '<PR2GripperSensorRawData>"
  "696a1f2e6969deb0bc6998636ae1b17e")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PR2GripperSensorRawData)))
  "Returns md5sum for a message object of type 'PR2GripperSensorRawData"
  "696a1f2e6969deb0bc6998636ae1b17e")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PR2GripperSensorRawData>)))
  "Returns full string definition for message of type '<PR2GripperSensorRawData>"
  (cl:format cl:nil "# NOTE: This message is only for debugging purposes. It is not intended for API usage - and is not published under release code.~%~%# Standard ROS header~%time stamp~%~%# corrected for zero contact~%float64 left_finger_pad_force~%float64 right_finger_pad_force~%~%# filtered values : high pass filter at 5 Hz after correcting for zero contact~%float64 left_finger_pad_force_filtered~%float64 right_finger_pad_force_filtered~%~%# corrected for zero contact~%float64[22] left_finger_pad_forces~%float64[22] right_finger_pad_forces~%~%# filtered values : high pass filter at 5 Hz after correcting for zero contact~%float64[22] left_finger_pad_forces_filtered~%float64[22] right_finger_pad_forces_filtered~%~%# raw acceleration values~%float64 acc_x_raw~%float64 acc_y_raw~%float64 acc_z_raw~%~%# filtered acceleration values~%float64 acc_x_filtered~%float64 acc_y_filtered~%float64 acc_z_filtered~%~%# boolean variables indicating whether contact exists or not~%bool left_contact~%bool right_contact~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PR2GripperSensorRawData)))
  "Returns full string definition for message of type 'PR2GripperSensorRawData"
  (cl:format cl:nil "# NOTE: This message is only for debugging purposes. It is not intended for API usage - and is not published under release code.~%~%# Standard ROS header~%time stamp~%~%# corrected for zero contact~%float64 left_finger_pad_force~%float64 right_finger_pad_force~%~%# filtered values : high pass filter at 5 Hz after correcting for zero contact~%float64 left_finger_pad_force_filtered~%float64 right_finger_pad_force_filtered~%~%# corrected for zero contact~%float64[22] left_finger_pad_forces~%float64[22] right_finger_pad_forces~%~%# filtered values : high pass filter at 5 Hz after correcting for zero contact~%float64[22] left_finger_pad_forces_filtered~%float64[22] right_finger_pad_forces_filtered~%~%# raw acceleration values~%float64 acc_x_raw~%float64 acc_y_raw~%float64 acc_z_raw~%~%# filtered acceleration values~%float64 acc_x_filtered~%float64 acc_y_filtered~%float64 acc_z_filtered~%~%# boolean variables indicating whether contact exists or not~%bool left_contact~%bool right_contact~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PR2GripperSensorRawData>))
  (cl:+ 0
     8
     8
     8
     8
     8
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'left_finger_pad_forces) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'right_finger_pad_forces) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'left_finger_pad_forces_filtered) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'right_finger_pad_forces_filtered) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     8
     8
     8
     8
     8
     8
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PR2GripperSensorRawData>))
  "Converts a ROS message object to a list"
  (cl:list 'PR2GripperSensorRawData
    (cl:cons ':stamp (stamp msg))
    (cl:cons ':left_finger_pad_force (left_finger_pad_force msg))
    (cl:cons ':right_finger_pad_force (right_finger_pad_force msg))
    (cl:cons ':left_finger_pad_force_filtered (left_finger_pad_force_filtered msg))
    (cl:cons ':right_finger_pad_force_filtered (right_finger_pad_force_filtered msg))
    (cl:cons ':left_finger_pad_forces (left_finger_pad_forces msg))
    (cl:cons ':right_finger_pad_forces (right_finger_pad_forces msg))
    (cl:cons ':left_finger_pad_forces_filtered (left_finger_pad_forces_filtered msg))
    (cl:cons ':right_finger_pad_forces_filtered (right_finger_pad_forces_filtered msg))
    (cl:cons ':acc_x_raw (acc_x_raw msg))
    (cl:cons ':acc_y_raw (acc_y_raw msg))
    (cl:cons ':acc_z_raw (acc_z_raw msg))
    (cl:cons ':acc_x_filtered (acc_x_filtered msg))
    (cl:cons ':acc_y_filtered (acc_y_filtered msg))
    (cl:cons ':acc_z_filtered (acc_z_filtered msg))
    (cl:cons ':left_contact (left_contact msg))
    (cl:cons ':right_contact (right_contact msg))
))
