(cl:in-package pr2_gripper_sensor_msgs-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          FEEDBACK-VAL
          FEEDBACK
))