
"use strict";

let Illuminance = require('./Illuminance.js');
let PointCloud = require('./PointCloud.js');
let JointState = require('./JointState.js');
let LaserScan = require('./LaserScan.js');
let FluidPressure = require('./FluidPressure.js');
let Temperature = require('./Temperature.js');
let PointCloud2 = require('./PointCloud2.js');
let RegionOfInterest = require('./RegionOfInterest.js');
let MagneticField = require('./MagneticField.js');
let NavSatFix = require('./NavSatFix.js');
let Image = require('./Image.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let CompressedImage = require('./CompressedImage.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let Joy = require('./Joy.js');
let Imu = require('./Imu.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let BatteryState = require('./BatteryState.js');
let NavSatStatus = require('./NavSatStatus.js');
let JoyFeedback = require('./JoyFeedback.js');
let LaserEcho = require('./LaserEcho.js');
let TimeReference = require('./TimeReference.js');
let PointField = require('./PointField.js');
let RelativeHumidity = require('./RelativeHumidity.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let CameraInfo = require('./CameraInfo.js');
let Range = require('./Range.js');

module.exports = {
  Illuminance: Illuminance,
  PointCloud: PointCloud,
  JointState: JointState,
  LaserScan: LaserScan,
  FluidPressure: FluidPressure,
  Temperature: Temperature,
  PointCloud2: PointCloud2,
  RegionOfInterest: RegionOfInterest,
  MagneticField: MagneticField,
  NavSatFix: NavSatFix,
  Image: Image,
  MultiDOFJointState: MultiDOFJointState,
  CompressedImage: CompressedImage,
  MultiEchoLaserScan: MultiEchoLaserScan,
  Joy: Joy,
  Imu: Imu,
  ChannelFloat32: ChannelFloat32,
  BatteryState: BatteryState,
  NavSatStatus: NavSatStatus,
  JoyFeedback: JoyFeedback,
  LaserEcho: LaserEcho,
  TimeReference: TimeReference,
  PointField: PointField,
  RelativeHumidity: RelativeHumidity,
  JoyFeedbackArray: JoyFeedbackArray,
  CameraInfo: CameraInfo,
  Range: Range,
};
