
"use strict";

let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let JointStatistics = require('./JointStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');

module.exports = {
  SwitchControllerActionResult: SwitchControllerActionResult,
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerResult: SwitchControllerResult,
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  JointStatistics: JointStatistics,
  MechanismStatistics: MechanismStatistics,
  ActuatorStatistics: ActuatorStatistics,
  ControllerStatistics: ControllerStatistics,
};
