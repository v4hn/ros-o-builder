
"use strict";

let TaskStatistics = require('./TaskStatistics.js');
let SubSolution = require('./SubSolution.js');
let TrajectoryExecutionInfo = require('./TrajectoryExecutionInfo.js');
let Solution = require('./Solution.js');
let SolutionInfo = require('./SolutionInfo.js');
let SubTrajectory = require('./SubTrajectory.js');
let TaskDescription = require('./TaskDescription.js');
let StageStatistics = require('./StageStatistics.js');
let StageDescription = require('./StageDescription.js');
let Property = require('./Property.js');
let ExecuteTaskSolutionActionResult = require('./ExecuteTaskSolutionActionResult.js');
let ExecuteTaskSolutionFeedback = require('./ExecuteTaskSolutionFeedback.js');
let ExecuteTaskSolutionActionFeedback = require('./ExecuteTaskSolutionActionFeedback.js');
let ExecuteTaskSolutionResult = require('./ExecuteTaskSolutionResult.js');
let ExecuteTaskSolutionActionGoal = require('./ExecuteTaskSolutionActionGoal.js');
let ExecuteTaskSolutionAction = require('./ExecuteTaskSolutionAction.js');
let ExecuteTaskSolutionGoal = require('./ExecuteTaskSolutionGoal.js');

module.exports = {
  TaskStatistics: TaskStatistics,
  SubSolution: SubSolution,
  TrajectoryExecutionInfo: TrajectoryExecutionInfo,
  Solution: Solution,
  SolutionInfo: SolutionInfo,
  SubTrajectory: SubTrajectory,
  TaskDescription: TaskDescription,
  StageStatistics: StageStatistics,
  StageDescription: StageDescription,
  Property: Property,
  ExecuteTaskSolutionActionResult: ExecuteTaskSolutionActionResult,
  ExecuteTaskSolutionFeedback: ExecuteTaskSolutionFeedback,
  ExecuteTaskSolutionActionFeedback: ExecuteTaskSolutionActionFeedback,
  ExecuteTaskSolutionResult: ExecuteTaskSolutionResult,
  ExecuteTaskSolutionActionGoal: ExecuteTaskSolutionActionGoal,
  ExecuteTaskSolutionAction: ExecuteTaskSolutionAction,
  ExecuteTaskSolutionGoal: ExecuteTaskSolutionGoal,
};
