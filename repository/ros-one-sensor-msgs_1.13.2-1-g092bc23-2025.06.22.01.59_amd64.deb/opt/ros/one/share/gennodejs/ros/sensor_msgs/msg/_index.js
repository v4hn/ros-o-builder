
"use strict";

let RelativeHumidity = require('./RelativeHumidity.js');
let CameraInfo = require('./CameraInfo.js');
let MultiDOFJointState = require('./MultiDOFJointState.js');
let CompressedImage = require('./CompressedImage.js');
let Range = require('./Range.js');
let BatteryState = require('./BatteryState.js');
let NavSatFix = require('./NavSatFix.js');
let LaserEcho = require('./LaserEcho.js');
let Imu = require('./Imu.js');
let Illuminance = require('./Illuminance.js');
let Image = require('./Image.js');
let Joy = require('./Joy.js');
let TimeReference = require('./TimeReference.js');
let JoyFeedbackArray = require('./JoyFeedbackArray.js');
let PointCloud = require('./PointCloud.js');
let RegionOfInterest = require('./RegionOfInterest.js');
let PointField = require('./PointField.js');
let JoyFeedback = require('./JoyFeedback.js');
let NavSatStatus = require('./NavSatStatus.js');
let JointState = require('./JointState.js');
let PointCloud2 = require('./PointCloud2.js');
let ChannelFloat32 = require('./ChannelFloat32.js');
let FluidPressure = require('./FluidPressure.js');
let MultiEchoLaserScan = require('./MultiEchoLaserScan.js');
let Temperature = require('./Temperature.js');
let MagneticField = require('./MagneticField.js');
let LaserScan = require('./LaserScan.js');

module.exports = {
  RelativeHumidity: RelativeHumidity,
  CameraInfo: CameraInfo,
  MultiDOFJointState: MultiDOFJointState,
  CompressedImage: CompressedImage,
  Range: Range,
  BatteryState: BatteryState,
  NavSatFix: NavSatFix,
  LaserEcho: LaserEcho,
  Imu: Imu,
  Illuminance: Illuminance,
  Image: Image,
  Joy: Joy,
  TimeReference: TimeReference,
  JoyFeedbackArray: JoyFeedbackArray,
  PointCloud: PointCloud,
  RegionOfInterest: RegionOfInterest,
  PointField: PointField,
  JoyFeedback: JoyFeedback,
  NavSatStatus: NavSatStatus,
  JointState: JointState,
  PointCloud2: PointCloud2,
  ChannelFloat32: ChannelFloat32,
  FluidPressure: FluidPressure,
  MultiEchoLaserScan: MultiEchoLaserScan,
  Temperature: Temperature,
  MagneticField: MagneticField,
  LaserScan: LaserScan,
};
