
"use strict";

let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let RecognizedObject = require('./RecognizedObject.js');
let ObjectInformation = require('./ObjectInformation.js');
let Table = require('./Table.js');
let ObjectType = require('./ObjectType.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let TableArray = require('./TableArray.js');

module.exports = {
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  RecognizedObject: RecognizedObject,
  ObjectInformation: ObjectInformation,
  Table: Table,
  ObjectType: ObjectType,
  RecognizedObjectArray: RecognizedObjectArray,
  TableArray: TableArray,
};
