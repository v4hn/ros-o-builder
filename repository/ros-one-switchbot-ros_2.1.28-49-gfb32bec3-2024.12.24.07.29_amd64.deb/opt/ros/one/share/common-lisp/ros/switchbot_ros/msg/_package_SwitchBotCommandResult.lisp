(cl:in-package switchbot_ros-msg)
(cl:export '(DONE-VAL
          DONE
))