(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          BATTERY-VAL
          BATTERY
          POWER-VAL
          POWER
          DEVICE_MODE-VAL
          DEVICE_MODE
))