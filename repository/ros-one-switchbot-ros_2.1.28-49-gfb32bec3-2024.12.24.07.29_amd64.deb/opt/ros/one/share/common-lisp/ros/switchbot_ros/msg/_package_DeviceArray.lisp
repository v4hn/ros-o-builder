(cl:in-package switchbot_ros-msg)
(cl:export '(DEVICES-VAL
          DEVICES
))