(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          FEEDBACK-VAL
          FEEDBACK
))