(cl:in-package switchbot_ros-msg)
(cl:export '(STATUS-VAL
          STATUS
))