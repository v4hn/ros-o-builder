// Auto-generated. Do not edit!

// (in-package switchbot_ros.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let std_msgs = _finder('std_msgs');

//-----------------------------------------------------------

class Bot {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.header = null;
      this.battery = null;
      this.power = null;
      this.device_mode = null;
    }
    else {
      if (initObj.hasOwnProperty('header')) {
        this.header = initObj.header
      }
      else {
        this.header = new std_msgs.msg.Header();
      }
      if (initObj.hasOwnProperty('battery')) {
        this.battery = initObj.battery
      }
      else {
        this.battery = 0.0;
      }
      if (initObj.hasOwnProperty('power')) {
        this.power = initObj.power
      }
      else {
        this.power = false;
      }
      if (initObj.hasOwnProperty('device_mode')) {
        this.device_mode = initObj.device_mode
      }
      else {
        this.device_mode = '';
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type Bot
    // Serialize message field [header]
    bufferOffset = std_msgs.msg.Header.serialize(obj.header, buffer, bufferOffset);
    // Serialize message field [battery]
    bufferOffset = _serializer.float64(obj.battery, buffer, bufferOffset);
    // Serialize message field [power]
    bufferOffset = _serializer.bool(obj.power, buffer, bufferOffset);
    // Serialize message field [device_mode]
    bufferOffset = _serializer.string(obj.device_mode, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type Bot
    let len;
    let data = new Bot(null);
    // Deserialize message field [header]
    data.header = std_msgs.msg.Header.deserialize(buffer, bufferOffset);
    // Deserialize message field [battery]
    data.battery = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [power]
    data.power = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [device_mode]
    data.device_mode = _deserializer.string(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += std_msgs.msg.Header.getMessageSize(object.header);
    length += _getByteLength(object.device_mode);
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'switchbot_ros/Bot';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '2b3c1d42dc6799ac69c485a7805ddf85';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    string DEVICEMODE_PRESS     = "pressMode"
    string DEVICEMODE_SWITCH    = "switchMode"
    string DEVICEMODE_CUSTOMIZE = "customizeMode"
    
    Header  header       # timestamp
    
    float64 battery      # the current battery level, 0-100
    
    bool    power        # ON/OFF state True/False
    string  device_mode  # pressMode, switchMode, or customizeMode
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new Bot(null);
    if (msg.header !== undefined) {
      resolved.header = std_msgs.msg.Header.Resolve(msg.header)
    }
    else {
      resolved.header = new std_msgs.msg.Header()
    }

    if (msg.battery !== undefined) {
      resolved.battery = msg.battery;
    }
    else {
      resolved.battery = 0.0
    }

    if (msg.power !== undefined) {
      resolved.power = msg.power;
    }
    else {
      resolved.power = false
    }

    if (msg.device_mode !== undefined) {
      resolved.device_mode = msg.device_mode;
    }
    else {
      resolved.device_mode = ''
    }

    return resolved;
    }
};

// Constants for message
Bot.Constants = {
  DEVICEMODE_PRESS: '"pressMode"',
  DEVICEMODE_SWITCH: '"switchMode"',
  DEVICEMODE_CUSTOMIZE: '"customizeMode"',
}

module.exports = Bot;
