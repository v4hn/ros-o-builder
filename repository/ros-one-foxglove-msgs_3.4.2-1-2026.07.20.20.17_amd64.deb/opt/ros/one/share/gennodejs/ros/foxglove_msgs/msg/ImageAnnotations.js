// Auto-generated. Do not edit!

// (in-package foxglove_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let CircleAnnotation = require('./CircleAnnotation.js');
let PointsAnnotation = require('./PointsAnnotation.js');
let TextAnnotation = require('./TextAnnotation.js');
let KeyValuePair = require('./KeyValuePair.js');

//-----------------------------------------------------------

class ImageAnnotations {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.timestamp = null;
      this.circles = null;
      this.points = null;
      this.texts = null;
      this.metadata = null;
    }
    else {
      if (initObj.hasOwnProperty('timestamp')) {
        this.timestamp = initObj.timestamp
      }
      else {
        this.timestamp = {secs: 0, nsecs: 0};
      }
      if (initObj.hasOwnProperty('circles')) {
        this.circles = initObj.circles
      }
      else {
        this.circles = [];
      }
      if (initObj.hasOwnProperty('points')) {
        this.points = initObj.points
      }
      else {
        this.points = [];
      }
      if (initObj.hasOwnProperty('texts')) {
        this.texts = initObj.texts
      }
      else {
        this.texts = [];
      }
      if (initObj.hasOwnProperty('metadata')) {
        this.metadata = initObj.metadata
      }
      else {
        this.metadata = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ImageAnnotations
    // Serialize message field [timestamp]
    bufferOffset = _serializer.time(obj.timestamp, buffer, bufferOffset);
    // Serialize message field [circles]
    // Serialize the length for message field [circles]
    bufferOffset = _serializer.uint32(obj.circles.length, buffer, bufferOffset);
    obj.circles.forEach((val) => {
      bufferOffset = CircleAnnotation.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [points]
    // Serialize the length for message field [points]
    bufferOffset = _serializer.uint32(obj.points.length, buffer, bufferOffset);
    obj.points.forEach((val) => {
      bufferOffset = PointsAnnotation.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [texts]
    // Serialize the length for message field [texts]
    bufferOffset = _serializer.uint32(obj.texts.length, buffer, bufferOffset);
    obj.texts.forEach((val) => {
      bufferOffset = TextAnnotation.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [metadata]
    // Serialize the length for message field [metadata]
    bufferOffset = _serializer.uint32(obj.metadata.length, buffer, bufferOffset);
    obj.metadata.forEach((val) => {
      bufferOffset = KeyValuePair.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ImageAnnotations
    let len;
    let data = new ImageAnnotations(null);
    // Deserialize message field [timestamp]
    data.timestamp = _deserializer.time(buffer, bufferOffset);
    // Deserialize message field [circles]
    // Deserialize array length for message field [circles]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.circles = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.circles[i] = CircleAnnotation.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [points]
    // Deserialize array length for message field [points]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.points = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.points[i] = PointsAnnotation.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [texts]
    // Deserialize array length for message field [texts]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.texts = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.texts[i] = TextAnnotation.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [metadata]
    // Deserialize array length for message field [metadata]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.metadata = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.metadata[i] = KeyValuePair.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.circles.forEach((val) => {
      length += CircleAnnotation.getMessageSize(val);
    });
    object.points.forEach((val) => {
      length += PointsAnnotation.getMessageSize(val);
    });
    object.texts.forEach((val) => {
      length += TextAnnotation.getMessageSize(val);
    });
    object.metadata.forEach((val) => {
      length += KeyValuePair.getMessageSize(val);
    });
    return length + 24;
  }

  static datatype() {
    // Returns string type for a message object
    return 'foxglove_msgs/ImageAnnotations';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '269aff4675381418078cf591128b77ac';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # foxglove_msgs/ImageAnnotations
    # Array of annotations for a 2D image
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # Timestamp of the image annotations. When set, individual annotation timestamps will be ignored.
    time timestamp
    
    # Circle annotations
    foxglove_msgs/CircleAnnotation[] circles
    
    # Points annotations
    foxglove_msgs/PointsAnnotation[] points
    
    # Text annotations
    foxglove_msgs/TextAnnotation[] texts
    
    # Additional user-provided metadata associated with the image annotations. Keys must be unique within this object. Per-annotation metadata takes precedence over these values.
    foxglove_msgs/KeyValuePair[] metadata
    
    ================================================================================
    MSG: foxglove_msgs/CircleAnnotation
    # foxglove_msgs/CircleAnnotation
    # A circle annotation on a 2D image
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # Timestamp of circle
    time timestamp
    
    # Center of the circle in 2D image coordinates (pixels).
    # The coordinate uses the top-left corner of the top-left pixel of the image as the origin.
    foxglove_msgs/Point2 position
    
    # Circle diameter in pixels
    float64 diameter
    
    # Line thickness in pixels
    float64 thickness
    
    # Fill color
    foxglove_msgs/Color fill_color
    
    # Outline color
    foxglove_msgs/Color outline_color
    
    # Additional user-provided metadata associated with this annotation. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    ================================================================================
    MSG: foxglove_msgs/Point2
    # foxglove_msgs/Point2
    # A point representing a position in 2D space
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # x coordinate position
    float64 x
    
    # y coordinate position
    float64 y
    
    ================================================================================
    MSG: foxglove_msgs/Color
    # foxglove_msgs/Color
    # A color in RGBA format
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # Red value between 0 and 1
    float64 r
    
    # Green value between 0 and 1
    float64 g
    
    # Blue value between 0 and 1
    float64 b
    
    # Alpha value between 0 and 1
    float64 a
    
    ================================================================================
    MSG: foxglove_msgs/KeyValuePair
    # foxglove_msgs/KeyValuePair
    # A key with its associated value
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # Key
    string key
    
    # Value
    string value
    
    ================================================================================
    MSG: foxglove_msgs/PointsAnnotation
    # foxglove_msgs/PointsAnnotation
    # An array of points on a 2D image
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # Timestamp of annotation
    time timestamp
    
    # Unknown points annotation type
    uint8 UNKNOWN=0
    
    # Individual points: 0, 1, 2, ...
    uint8 POINTS=1
    
    # Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0
    uint8 LINE_LOOP=2
    
    # Connected line segments: 0-1, 1-2, ..., (n-1)-n
    uint8 LINE_STRIP=3
    
    # Individual line segments: 0-1, 2-3, 4-5, ...
    uint8 LINE_LIST=4
    
    # Type of points annotation to draw
    uint8 type
    
    # Points in 2D image coordinates (pixels).
    # These coordinates use the top-left corner of the top-left pixel of the image as the origin.
    foxglove_msgs/Point2[] points
    
    # Outline color
    foxglove_msgs/Color outline_color
    
    # Per-point colors, if `type` is `POINTS`, or per-segment stroke colors, if `type` is `LINE_LIST`, `LINE_STRIP` or `LINE_LOOP`.
    foxglove_msgs/Color[] outline_colors
    
    # Fill color
    foxglove_msgs/Color fill_color
    
    # Stroke thickness in pixels
    float64 thickness
    
    # Additional user-provided metadata associated with this annotation. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    ================================================================================
    MSG: foxglove_msgs/TextAnnotation
    # foxglove_msgs/TextAnnotation
    # A text label on a 2D image
    
    # Generated by https://github.com/foxglove/foxglove-sdk
    
    # Timestamp of annotation
    time timestamp
    
    # Bottom-left origin of the text label in 2D image coordinates (pixels).
    # The coordinate uses the top-left corner of the top-left pixel of the image as the origin.
    foxglove_msgs/Point2 position
    
    # Text to display
    string text
    
    # Font size in pixels
    float64 font_size
    
    # Text color
    foxglove_msgs/Color text_color
    
    # Background fill color
    foxglove_msgs/Color background_color
    
    # Additional user-provided metadata associated with this annotation. Keys must be unique.
    foxglove_msgs/KeyValuePair[] metadata
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ImageAnnotations(null);
    if (msg.timestamp !== undefined) {
      resolved.timestamp = msg.timestamp;
    }
    else {
      resolved.timestamp = {secs: 0, nsecs: 0}
    }

    if (msg.circles !== undefined) {
      resolved.circles = new Array(msg.circles.length);
      for (let i = 0; i < resolved.circles.length; ++i) {
        resolved.circles[i] = CircleAnnotation.Resolve(msg.circles[i]);
      }
    }
    else {
      resolved.circles = []
    }

    if (msg.points !== undefined) {
      resolved.points = new Array(msg.points.length);
      for (let i = 0; i < resolved.points.length; ++i) {
        resolved.points[i] = PointsAnnotation.Resolve(msg.points[i]);
      }
    }
    else {
      resolved.points = []
    }

    if (msg.texts !== undefined) {
      resolved.texts = new Array(msg.texts.length);
      for (let i = 0; i < resolved.texts.length; ++i) {
        resolved.texts[i] = TextAnnotation.Resolve(msg.texts[i]);
      }
    }
    else {
      resolved.texts = []
    }

    if (msg.metadata !== undefined) {
      resolved.metadata = new Array(msg.metadata.length);
      for (let i = 0; i < resolved.metadata.length; ++i) {
        resolved.metadata[i] = KeyValuePair.Resolve(msg.metadata[i]);
      }
    }
    else {
      resolved.metadata = []
    }

    return resolved;
    }
};

module.exports = ImageAnnotations;
