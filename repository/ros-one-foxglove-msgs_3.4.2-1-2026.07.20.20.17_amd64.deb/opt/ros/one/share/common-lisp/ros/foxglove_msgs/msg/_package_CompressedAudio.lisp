(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          DATA-VAL
          DATA
          FORMAT-VAL
          FORMAT
))