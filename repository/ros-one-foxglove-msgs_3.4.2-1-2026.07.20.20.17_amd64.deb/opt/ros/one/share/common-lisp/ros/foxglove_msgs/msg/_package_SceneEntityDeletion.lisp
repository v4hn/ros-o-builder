(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          TYPE-VAL
          TYPE
          ID-VAL
          ID
))