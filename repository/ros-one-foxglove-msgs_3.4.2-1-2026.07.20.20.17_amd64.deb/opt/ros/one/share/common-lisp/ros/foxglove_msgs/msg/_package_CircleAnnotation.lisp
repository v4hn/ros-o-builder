(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          POSITION-VAL
          POSITION
          DIAMETER-VAL
          DIAMETER
          THICKNESS-VAL
          THICKNESS
          FILL_COLOR-VAL
          FILL_COLOR
          OUTLINE_COLOR-VAL
          OUTLINE_COLOR
          METADATA-VAL
          METADATA
))