; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude PointCloud.msg.html

(cl:defclass <PointCloud> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform "")
   (pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (point_stride
    :reader point_stride
    :initarg :point_stride
    :type cl:integer
    :initform 0)
   (fields
    :reader fields
    :initarg :fields
    :type (cl:vector foxglove_msgs-msg:PackedElementField)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:PackedElementField :initial-element (cl:make-instance 'foxglove_msgs-msg:PackedElementField)))
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass PointCloud (<PointCloud>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PointCloud>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PointCloud)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<PointCloud> is deprecated: use foxglove_msgs-msg:PointCloud instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <PointCloud>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <PointCloud>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:frame_id-val is deprecated.  Use foxglove_msgs-msg:frame_id instead.")
  (frame_id m))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <PointCloud>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'point_stride-val :lambda-list '(m))
(cl:defmethod point_stride-val ((m <PointCloud>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:point_stride-val is deprecated.  Use foxglove_msgs-msg:point_stride instead.")
  (point_stride m))

(cl:ensure-generic-function 'fields-val :lambda-list '(m))
(cl:defmethod fields-val ((m <PointCloud>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:fields-val is deprecated.  Use foxglove_msgs-msg:fields instead.")
  (fields m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <PointCloud>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:data-val is deprecated.  Use foxglove_msgs-msg:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PointCloud>) ostream)
  "Serializes a message object of type '<PointCloud>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'point_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'point_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'point_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'point_stride)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'fields))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'fields))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PointCloud>) istream)
  "Deserializes a message object of type '<PointCloud>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'point_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'point_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'point_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'point_stride)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'fields) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'fields)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:PackedElementField))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PointCloud>)))
  "Returns string type for a message object of type '<PointCloud>"
  "foxglove_msgs/PointCloud")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PointCloud)))
  "Returns string type for a message object of type 'PointCloud"
  "foxglove_msgs/PointCloud")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PointCloud>)))
  "Returns md5sum for a message object of type '<PointCloud>"
  "46355bb42c332657eb232925c4a8f134")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PointCloud)))
  "Returns md5sum for a message object of type 'PointCloud"
  "46355bb42c332657eb232925c4a8f134")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PointCloud>)))
  "Returns full string definition for message of type '<PointCloud>"
  (cl:format cl:nil "# foxglove_msgs/PointCloud~%# A collection of N-dimensional points, which may contain additional fields with information like normals, intensity, etc.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of point cloud~%time timestamp~%~%# Frame of reference~%string frame_id~%~%# The origin of the point cloud relative to the frame of reference~%geometry_msgs/Pose pose~%~%# Number of bytes between points in the `data`~%uint32 point_stride~%~%# Fields in `data`. At least 2 coordinate fields from `x`, `y`, and `z` are required for each point's position; `red`, `green`, `blue`, and `alpha` are optional for customizing each point's color.~%foxglove_msgs/PackedElementField[] fields~%~%# Point data, interpreted using `fields`~%uint8[] data~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/PackedElementField~%# foxglove_msgs/PackedElementField~%# A field present within each element in a byte array of packed elements.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Name of the field~%string name~%~%# Byte offset from start of data buffer~%uint32 offset~%~%# Unknown numeric type~%uint8 UNKNOWN=0~%~%# Unsigned 8-bit integer~%uint8 UINT8=1~%~%# Signed 8-bit integer~%uint8 INT8=2~%~%# Unsigned 16-bit integer~%uint8 UINT16=3~%~%# Signed 16-bit integer~%uint8 INT16=4~%~%# Unsigned 32-bit integer~%uint8 UINT32=5~%~%# Signed 32-bit integer~%uint8 INT32=6~%~%# 32-bit floating-point number~%uint8 FLOAT32=7~%~%# 64-bit floating-point number~%uint8 FLOAT64=8~%~%# Type of data in the field. Integers are stored using little-endian byte order.~%uint8 type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PointCloud)))
  "Returns full string definition for message of type 'PointCloud"
  (cl:format cl:nil "# foxglove_msgs/PointCloud~%# A collection of N-dimensional points, which may contain additional fields with information like normals, intensity, etc.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of point cloud~%time timestamp~%~%# Frame of reference~%string frame_id~%~%# The origin of the point cloud relative to the frame of reference~%geometry_msgs/Pose pose~%~%# Number of bytes between points in the `data`~%uint32 point_stride~%~%# Fields in `data`. At least 2 coordinate fields from `x`, `y`, and `z` are required for each point's position; `red`, `green`, `blue`, and `alpha` are optional for customizing each point's color.~%foxglove_msgs/PackedElementField[] fields~%~%# Point data, interpreted using `fields`~%uint8[] data~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/PackedElementField~%# foxglove_msgs/PackedElementField~%# A field present within each element in a byte array of packed elements.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Name of the field~%string name~%~%# Byte offset from start of data buffer~%uint32 offset~%~%# Unknown numeric type~%uint8 UNKNOWN=0~%~%# Unsigned 8-bit integer~%uint8 UINT8=1~%~%# Signed 8-bit integer~%uint8 INT8=2~%~%# Unsigned 16-bit integer~%uint8 UINT16=3~%~%# Signed 16-bit integer~%uint8 INT16=4~%~%# Unsigned 32-bit integer~%uint8 UINT32=5~%~%# Signed 32-bit integer~%uint8 INT32=6~%~%# 32-bit floating-point number~%uint8 FLOAT32=7~%~%# 64-bit floating-point number~%uint8 FLOAT64=8~%~%# Type of data in the field. Integers are stored using little-endian byte order.~%uint8 type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PointCloud>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'frame_id))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'fields) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PointCloud>))
  "Converts a ROS message object to a list"
  (cl:list 'PointCloud
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':frame_id (frame_id msg))
    (cl:cons ':pose (pose msg))
    (cl:cons ':point_stride (point_stride msg))
    (cl:cons ':fields (fields msg))
    (cl:cons ':data (data msg))
))
