(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          POSE-VAL
          POSE
          ROW_COUNT-VAL
          ROW_COUNT
          COLUMN_COUNT-VAL
          COLUMN_COUNT
          CELL_SIZE-VAL
          CELL_SIZE
          SLICE_STRIDE-VAL
          SLICE_STRIDE
          ROW_STRIDE-VAL
          ROW_STRIDE
          CELL_STRIDE-VAL
          CELL_STRIDE
          FIELDS-VAL
          FIELDS
          DATA-VAL
          DATA
))