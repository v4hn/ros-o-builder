(cl:in-package foxglove_msgs-msg)
(cl:export '(POSE-VAL
          POSE
          SHAFT_LENGTH-VAL
          SHAFT_LENGTH
          SHAFT_DIAMETER-VAL
          SHAFT_DIAMETER
          HEAD_LENGTH-VAL
          HEAD_LENGTH
          HEAD_DIAMETER-VAL
          HEAD_DIAMETER
          COLOR-VAL
          COLOR
))