(cl:in-package foxglove_msgs-msg)
(cl:export '(X-VAL
          X
          Y-VAL
          Y
))