; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude PointsAnnotation.msg.html

(cl:defclass <PointsAnnotation> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0)
   (points
    :reader points
    :initarg :points
    :type (cl:vector foxglove_msgs-msg:Point2)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:Point2 :initial-element (cl:make-instance 'foxglove_msgs-msg:Point2)))
   (outline_color
    :reader outline_color
    :initarg :outline_color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (outline_colors
    :reader outline_colors
    :initarg :outline_colors
    :type (cl:vector foxglove_msgs-msg:Color)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:Color :initial-element (cl:make-instance 'foxglove_msgs-msg:Color)))
   (fill_color
    :reader fill_color
    :initarg :fill_color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (thickness
    :reader thickness
    :initarg :thickness
    :type cl:float
    :initform 0.0)
   (metadata
    :reader metadata
    :initarg :metadata
    :type (cl:vector foxglove_msgs-msg:KeyValuePair)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:KeyValuePair :initial-element (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))))
)

(cl:defclass PointsAnnotation (<PointsAnnotation>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PointsAnnotation>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PointsAnnotation)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<PointsAnnotation> is deprecated: use foxglove_msgs-msg:PointsAnnotation instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:type-val is deprecated.  Use foxglove_msgs-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'points-val :lambda-list '(m))
(cl:defmethod points-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:points-val is deprecated.  Use foxglove_msgs-msg:points instead.")
  (points m))

(cl:ensure-generic-function 'outline_color-val :lambda-list '(m))
(cl:defmethod outline_color-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:outline_color-val is deprecated.  Use foxglove_msgs-msg:outline_color instead.")
  (outline_color m))

(cl:ensure-generic-function 'outline_colors-val :lambda-list '(m))
(cl:defmethod outline_colors-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:outline_colors-val is deprecated.  Use foxglove_msgs-msg:outline_colors instead.")
  (outline_colors m))

(cl:ensure-generic-function 'fill_color-val :lambda-list '(m))
(cl:defmethod fill_color-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:fill_color-val is deprecated.  Use foxglove_msgs-msg:fill_color instead.")
  (fill_color m))

(cl:ensure-generic-function 'thickness-val :lambda-list '(m))
(cl:defmethod thickness-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:thickness-val is deprecated.  Use foxglove_msgs-msg:thickness instead.")
  (thickness m))

(cl:ensure-generic-function 'metadata-val :lambda-list '(m))
(cl:defmethod metadata-val ((m <PointsAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:metadata-val is deprecated.  Use foxglove_msgs-msg:metadata instead.")
  (metadata m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<PointsAnnotation>)))
    "Constants for message type '<PointsAnnotation>"
  '((:UNKNOWN . 0)
    (:POINTS . 1)
    (:LINE_LOOP . 2)
    (:LINE_STRIP . 3)
    (:LINE_LIST . 4))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'PointsAnnotation)))
    "Constants for message type 'PointsAnnotation"
  '((:UNKNOWN . 0)
    (:POINTS . 1)
    (:LINE_LOOP . 2)
    (:LINE_STRIP . 3)
    (:LINE_LIST . 4))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PointsAnnotation>) ostream)
  "Serializes a message object of type '<PointsAnnotation>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'points))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'outline_color) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'outline_colors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'outline_colors))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'fill_color) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'thickness))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'metadata))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'metadata))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PointsAnnotation>) istream)
  "Deserializes a message object of type '<PointsAnnotation>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:Point2))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'outline_color) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'outline_colors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'outline_colors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:Color))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'fill_color) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'thickness) (roslisp-utils:decode-double-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'metadata) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'metadata)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PointsAnnotation>)))
  "Returns string type for a message object of type '<PointsAnnotation>"
  "foxglove_msgs/PointsAnnotation")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PointsAnnotation)))
  "Returns string type for a message object of type 'PointsAnnotation"
  "foxglove_msgs/PointsAnnotation")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PointsAnnotation>)))
  "Returns md5sum for a message object of type '<PointsAnnotation>"
  "37bf761197bff34981e3d3d22a93f4a5")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PointsAnnotation)))
  "Returns md5sum for a message object of type 'PointsAnnotation"
  "37bf761197bff34981e3d3d22a93f4a5")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PointsAnnotation>)))
  "Returns full string definition for message of type '<PointsAnnotation>"
  (cl:format cl:nil "# foxglove_msgs/PointsAnnotation~%# An array of points on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Unknown points annotation type~%uint8 UNKNOWN=0~%~%# Individual points: 0, 1, 2, ...~%uint8 POINTS=1~%~%# Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0~%uint8 LINE_LOOP=2~%~%# Connected line segments: 0-1, 1-2, ..., (n-1)-n~%uint8 LINE_STRIP=3~%~%# Individual line segments: 0-1, 2-3, 4-5, ...~%uint8 LINE_LIST=4~%~%# Type of points annotation to draw~%uint8 type~%~%# Points in 2D image coordinates (pixels).~%# These coordinates use the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2[] points~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Per-point colors, if `type` is `POINTS`, or per-segment stroke colors, if `type` is `LINE_LIST`, `LINE_STRIP` or `LINE_LOOP`.~%foxglove_msgs/Color[] outline_colors~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Stroke thickness in pixels~%float64 thickness~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PointsAnnotation)))
  "Returns full string definition for message of type 'PointsAnnotation"
  (cl:format cl:nil "# foxglove_msgs/PointsAnnotation~%# An array of points on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Unknown points annotation type~%uint8 UNKNOWN=0~%~%# Individual points: 0, 1, 2, ...~%uint8 POINTS=1~%~%# Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0~%uint8 LINE_LOOP=2~%~%# Connected line segments: 0-1, 1-2, ..., (n-1)-n~%uint8 LINE_STRIP=3~%~%# Individual line segments: 0-1, 2-3, 4-5, ...~%uint8 LINE_LIST=4~%~%# Type of points annotation to draw~%uint8 type~%~%# Points in 2D image coordinates (pixels).~%# These coordinates use the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2[] points~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Per-point colors, if `type` is `POINTS`, or per-segment stroke colors, if `type` is `LINE_LIST`, `LINE_STRIP` or `LINE_LOOP`.~%foxglove_msgs/Color[] outline_colors~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Stroke thickness in pixels~%float64 thickness~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PointsAnnotation>))
  (cl:+ 0
     8
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'outline_color))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'outline_colors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'fill_color))
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'metadata) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PointsAnnotation>))
  "Converts a ROS message object to a list"
  (cl:list 'PointsAnnotation
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':type (type msg))
    (cl:cons ':points (points msg))
    (cl:cons ':outline_color (outline_color msg))
    (cl:cons ':outline_colors (outline_colors msg))
    (cl:cons ':fill_color (fill_color msg))
    (cl:cons ':thickness (thickness msg))
    (cl:cons ':metadata (metadata msg))
))
