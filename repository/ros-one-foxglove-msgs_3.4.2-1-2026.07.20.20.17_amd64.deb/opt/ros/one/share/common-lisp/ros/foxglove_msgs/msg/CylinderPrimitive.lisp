; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude CylinderPrimitive.msg.html

(cl:defclass <CylinderPrimitive> (roslisp-msg-protocol:ros-message)
  ((pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (size
    :reader size
    :initarg :size
    :type geometry_msgs-msg:Vector3
    :initform (cl:make-instance 'geometry_msgs-msg:Vector3))
   (bottom_scale
    :reader bottom_scale
    :initarg :bottom_scale
    :type cl:float
    :initform 0.0)
   (top_scale
    :reader top_scale
    :initarg :top_scale
    :type cl:float
    :initform 0.0)
   (color
    :reader color
    :initarg :color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color)))
)

(cl:defclass CylinderPrimitive (<CylinderPrimitive>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CylinderPrimitive>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CylinderPrimitive)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<CylinderPrimitive> is deprecated: use foxglove_msgs-msg:CylinderPrimitive instead.")))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <CylinderPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'size-val :lambda-list '(m))
(cl:defmethod size-val ((m <CylinderPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:size-val is deprecated.  Use foxglove_msgs-msg:size instead.")
  (size m))

(cl:ensure-generic-function 'bottom_scale-val :lambda-list '(m))
(cl:defmethod bottom_scale-val ((m <CylinderPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:bottom_scale-val is deprecated.  Use foxglove_msgs-msg:bottom_scale instead.")
  (bottom_scale m))

(cl:ensure-generic-function 'top_scale-val :lambda-list '(m))
(cl:defmethod top_scale-val ((m <CylinderPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:top_scale-val is deprecated.  Use foxglove_msgs-msg:top_scale instead.")
  (top_scale m))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <CylinderPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:color-val is deprecated.  Use foxglove_msgs-msg:color instead.")
  (color m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CylinderPrimitive>) ostream)
  "Serializes a message object of type '<CylinderPrimitive>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'size) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'bottom_scale))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'top_scale))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CylinderPrimitive>) istream)
  "Deserializes a message object of type '<CylinderPrimitive>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'size) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'bottom_scale) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'top_scale) (roslisp-utils:decode-double-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CylinderPrimitive>)))
  "Returns string type for a message object of type '<CylinderPrimitive>"
  "foxglove_msgs/CylinderPrimitive")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CylinderPrimitive)))
  "Returns string type for a message object of type 'CylinderPrimitive"
  "foxglove_msgs/CylinderPrimitive")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CylinderPrimitive>)))
  "Returns md5sum for a message object of type '<CylinderPrimitive>"
  "95a94410f04d20228465a960c3c3f66f")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CylinderPrimitive)))
  "Returns md5sum for a message object of type 'CylinderPrimitive"
  "95a94410f04d20228465a960c3c3f66f")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CylinderPrimitive>)))
  "Returns full string definition for message of type '<CylinderPrimitive>"
  (cl:format cl:nil "# foxglove_msgs/CylinderPrimitive~%# A primitive representing a cylinder, elliptic cylinder, or truncated cone~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Position of the center of the cylinder and orientation of the cylinder. The flat face(s) are perpendicular to the z-axis.~%geometry_msgs/Pose pose~%~%# Size of the cylinder's bounding box~%geometry_msgs/Vector3 size~%~%# 0-1, ratio of the diameter of the cylinder's bottom face (min z) to the bottom of the bounding box~%float64 bottom_scale~%~%# 0-1, ratio of the diameter of the cylinder's top face (max z) to the top of the bounding box~%float64 top_scale~%~%# Color of the cylinder~%foxglove_msgs/Color color~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CylinderPrimitive)))
  "Returns full string definition for message of type 'CylinderPrimitive"
  (cl:format cl:nil "# foxglove_msgs/CylinderPrimitive~%# A primitive representing a cylinder, elliptic cylinder, or truncated cone~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Position of the center of the cylinder and orientation of the cylinder. The flat face(s) are perpendicular to the z-axis.~%geometry_msgs/Pose pose~%~%# Size of the cylinder's bounding box~%geometry_msgs/Vector3 size~%~%# 0-1, ratio of the diameter of the cylinder's bottom face (min z) to the bottom of the bounding box~%float64 bottom_scale~%~%# 0-1, ratio of the diameter of the cylinder's top face (max z) to the top of the bounding box~%float64 top_scale~%~%# Color of the cylinder~%foxglove_msgs/Color color~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CylinderPrimitive>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'size))
     8
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CylinderPrimitive>))
  "Converts a ROS message object to a list"
  (cl:list 'CylinderPrimitive
    (cl:cons ':pose (pose msg))
    (cl:cons ':size (size msg))
    (cl:cons ':bottom_scale (bottom_scale msg))
    (cl:cons ':top_scale (top_scale msg))
    (cl:cons ':color (color msg))
))
