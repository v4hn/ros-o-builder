(cl:in-package foxglove_msgs-msg)
(cl:export '(NAME-VAL
          NAME
          POSITION-VAL
          POSITION
          VELOCITY-VAL
          VELOCITY
          ACCELERATION-VAL
          ACCELERATION
          EFFORT-VAL
          EFFORT
))