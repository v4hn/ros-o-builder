(cl:in-package foxglove_msgs-msg)
(cl:export '(DELETIONS-VAL
          DELETIONS
          ENTITIES-VAL
          ENTITIES
))