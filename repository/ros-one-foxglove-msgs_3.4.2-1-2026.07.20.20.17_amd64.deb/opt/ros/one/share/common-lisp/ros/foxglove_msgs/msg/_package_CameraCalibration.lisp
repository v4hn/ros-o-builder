(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          WIDTH-VAL
          WIDTH
          HEIGHT-VAL
          HEIGHT
          DISTORTION_MODEL-VAL
          DISTORTION_MODEL
          D-VAL
          D
          K-VAL
          K
          R-VAL
          R
          P-VAL
          P
))