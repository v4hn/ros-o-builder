; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude TriangleListPrimitive.msg.html

(cl:defclass <TriangleListPrimitive> (roslisp-msg-protocol:ros-message)
  ((pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (points
    :reader points
    :initarg :points
    :type (cl:vector geometry_msgs-msg:Point)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Point :initial-element (cl:make-instance 'geometry_msgs-msg:Point)))
   (color
    :reader color
    :initarg :color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (colors
    :reader colors
    :initarg :colors
    :type (cl:vector foxglove_msgs-msg:Color)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:Color :initial-element (cl:make-instance 'foxglove_msgs-msg:Color)))
   (indices
    :reader indices
    :initarg :indices
    :type (cl:vector cl:integer)
   :initform (cl:make-array 0 :element-type 'cl:integer :initial-element 0)))
)

(cl:defclass TriangleListPrimitive (<TriangleListPrimitive>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TriangleListPrimitive>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TriangleListPrimitive)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<TriangleListPrimitive> is deprecated: use foxglove_msgs-msg:TriangleListPrimitive instead.")))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <TriangleListPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'points-val :lambda-list '(m))
(cl:defmethod points-val ((m <TriangleListPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:points-val is deprecated.  Use foxglove_msgs-msg:points instead.")
  (points m))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <TriangleListPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:color-val is deprecated.  Use foxglove_msgs-msg:color instead.")
  (color m))

(cl:ensure-generic-function 'colors-val :lambda-list '(m))
(cl:defmethod colors-val ((m <TriangleListPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:colors-val is deprecated.  Use foxglove_msgs-msg:colors instead.")
  (colors m))

(cl:ensure-generic-function 'indices-val :lambda-list '(m))
(cl:defmethod indices-val ((m <TriangleListPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:indices-val is deprecated.  Use foxglove_msgs-msg:indices instead.")
  (indices m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TriangleListPrimitive>) ostream)
  "Serializes a message object of type '<TriangleListPrimitive>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'points))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'colors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'colors))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'indices))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) ele) ostream))
   (cl:slot-value msg 'indices))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TriangleListPrimitive>) istream)
  "Deserializes a message object of type '<TriangleListPrimitive>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Point))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'colors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'colors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:Color))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'indices) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'indices)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TriangleListPrimitive>)))
  "Returns string type for a message object of type '<TriangleListPrimitive>"
  "foxglove_msgs/TriangleListPrimitive")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TriangleListPrimitive)))
  "Returns string type for a message object of type 'TriangleListPrimitive"
  "foxglove_msgs/TriangleListPrimitive")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TriangleListPrimitive>)))
  "Returns md5sum for a message object of type '<TriangleListPrimitive>"
  "31ba9e95731d693961104fd1f10cfb75")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TriangleListPrimitive)))
  "Returns md5sum for a message object of type 'TriangleListPrimitive"
  "31ba9e95731d693961104fd1f10cfb75")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TriangleListPrimitive>)))
  "Returns full string definition for message of type '<TriangleListPrimitive>"
  (cl:format cl:nil "# foxglove_msgs/TriangleListPrimitive~%# A primitive representing a set of triangles or a surface tiled by triangles~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Origin of triangles relative to reference frame~%geometry_msgs/Pose pose~%~%# Vertices to use for triangles, interpreted as a list of triples (0-1-2, 3-4-5, ...)~%geometry_msgs/Point[] points~%~%# Solid color to use for the whole shape. Ignored if `colors` is non-empty.~%foxglove_msgs/Color color~%~%# Per-vertex colors (if specified, must have the same length as `points`).~%foxglove_msgs/Color[] colors~%~%# Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.~%# ~%# If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).~%uint32[] indices~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TriangleListPrimitive)))
  "Returns full string definition for message of type 'TriangleListPrimitive"
  (cl:format cl:nil "# foxglove_msgs/TriangleListPrimitive~%# A primitive representing a set of triangles or a surface tiled by triangles~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Origin of triangles relative to reference frame~%geometry_msgs/Pose pose~%~%# Vertices to use for triangles, interpreted as a list of triples (0-1-2, 3-4-5, ...)~%geometry_msgs/Point[] points~%~%# Solid color to use for the whole shape. Ignored if `colors` is non-empty.~%foxglove_msgs/Color color~%~%# Per-vertex colors (if specified, must have the same length as `points`).~%foxglove_msgs/Color[] colors~%~%# Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.~%# ~%# If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).~%uint32[] indices~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TriangleListPrimitive>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'colors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'indices) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TriangleListPrimitive>))
  "Converts a ROS message object to a list"
  (cl:list 'TriangleListPrimitive
    (cl:cons ':pose (pose msg))
    (cl:cons ':points (points msg))
    (cl:cons ':color (color msg))
    (cl:cons ':colors (colors msg))
    (cl:cons ':indices (indices msg))
))
