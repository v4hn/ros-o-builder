(cl:in-package foxglove_msgs-msg)
(cl:export '(NAME-VAL
          NAME
          OFFSET-VAL
          OFFSET
          TYPE-VAL
          TYPE
))