(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          POSE-VAL
          POSE
          DATA-VAL
          DATA
          FORMAT-VAL
          FORMAT
))