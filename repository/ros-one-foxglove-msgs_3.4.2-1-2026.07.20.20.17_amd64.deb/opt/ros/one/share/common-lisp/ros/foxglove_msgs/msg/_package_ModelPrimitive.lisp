(cl:in-package foxglove_msgs-msg)
(cl:export '(POSE-VAL
          POSE
          SCALE-VAL
          SCALE
          COLOR-VAL
          COLOR
          OVERRIDE_COLOR-VAL
          OVERRIDE_COLOR
          URL-VAL
          URL
          MEDIA_TYPE-VAL
          MEDIA_TYPE
          DATA-VAL
          DATA
))