(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          DATA-VAL
          DATA
          FORMAT-VAL
          FORMAT
          SAMPLE_RATE-VAL
          SAMPLE_RATE
          NUMBER_OF_CHANNELS-VAL
          NUMBER_OF_CHANNELS
))