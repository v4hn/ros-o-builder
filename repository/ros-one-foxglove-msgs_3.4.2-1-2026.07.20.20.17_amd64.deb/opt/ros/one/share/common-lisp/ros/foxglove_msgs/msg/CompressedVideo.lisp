; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude CompressedVideo.msg.html

(cl:defclass <CompressedVideo> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform "")
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0))
   (format
    :reader format
    :initarg :format
    :type cl:string
    :initform ""))
)

(cl:defclass CompressedVideo (<CompressedVideo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CompressedVideo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CompressedVideo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<CompressedVideo> is deprecated: use foxglove_msgs-msg:CompressedVideo instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <CompressedVideo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <CompressedVideo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:frame_id-val is deprecated.  Use foxglove_msgs-msg:frame_id instead.")
  (frame_id m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <CompressedVideo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:data-val is deprecated.  Use foxglove_msgs-msg:data instead.")
  (data m))

(cl:ensure-generic-function 'format-val :lambda-list '(m))
(cl:defmethod format-val ((m <CompressedVideo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:format-val is deprecated.  Use foxglove_msgs-msg:format instead.")
  (format m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CompressedVideo>) ostream)
  "Serializes a message object of type '<CompressedVideo>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'format))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'format))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CompressedVideo>) istream)
  "Deserializes a message object of type '<CompressedVideo>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'format) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'format) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CompressedVideo>)))
  "Returns string type for a message object of type '<CompressedVideo>"
  "foxglove_msgs/CompressedVideo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CompressedVideo)))
  "Returns string type for a message object of type 'CompressedVideo"
  "foxglove_msgs/CompressedVideo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CompressedVideo>)))
  "Returns md5sum for a message object of type '<CompressedVideo>"
  "c5ea945275bc0729ed72f42e057a67bd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CompressedVideo)))
  "Returns md5sum for a message object of type 'CompressedVideo"
  "c5ea945275bc0729ed72f42e057a67bd")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CompressedVideo>)))
  "Returns full string definition for message of type '<CompressedVideo>"
  (cl:format cl:nil "# foxglove_msgs/CompressedVideo~%# A single frame of a compressed video bitstream~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of video frame~%time timestamp~%~%# Frame of reference for the video.~%# ~%# The origin of the frame is the optical center of the camera. +x points to the right in the video, +y points down, and +z points into the plane of the video.~%string frame_id~%~%# Compressed video frame data.~%# ~%# For packet-based video codecs this data must begin and end on packet boundaries (no partial packets), and must contain enough video packets to decode exactly one image (either a keyframe or delta frame). Note: Foxglove does not support video streams that include B frames because they require lookahead.~%# ~%# Specifically, the requirements for different `format` values are:~%# ~%# - `h264`~%#   - Use Annex B formatted data~%#   - Each CompressedVideo message should contain enough NAL units to decode exactly one video frame~%#   - Each message containing a key frame (IDR) must also include a SPS NAL unit~%# ~%# - `h265` (HEVC)~%#   - Use Annex B formatted data~%#   - Each CompressedVideo message should contain enough NAL units to decode exactly one video frame~%#   - Each message containing a key frame (IRAP) must also include relevant VPS/SPS/PPS NAL units~%# ~%# - `vp9`~%#   - Each CompressedVideo message should contain exactly one video frame~%# ~%# - `av1`~%#   - Use the \"Low overhead bitstream format\" (section 5.2)~%#   - Each CompressedVideo message should contain enough OBUs to decode exactly one video frame~%#   - Each message containing a key frame must also include a Sequence Header OBU~%uint8[] data~%~%# Video format.~%# ~%# Supported values: `h264`, `h265`, `vp9`, `av1`.~%# ~%# Note: compressed video support is subject to hardware limitations and patent licensing, so not all encodings may be supported on all platforms. See more about [H.265 support](https://caniuse.com/hevc), [VP9 support](https://caniuse.com/webm), and [AV1 support](https://caniuse.com/av1).~%string format~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CompressedVideo)))
  "Returns full string definition for message of type 'CompressedVideo"
  (cl:format cl:nil "# foxglove_msgs/CompressedVideo~%# A single frame of a compressed video bitstream~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of video frame~%time timestamp~%~%# Frame of reference for the video.~%# ~%# The origin of the frame is the optical center of the camera. +x points to the right in the video, +y points down, and +z points into the plane of the video.~%string frame_id~%~%# Compressed video frame data.~%# ~%# For packet-based video codecs this data must begin and end on packet boundaries (no partial packets), and must contain enough video packets to decode exactly one image (either a keyframe or delta frame). Note: Foxglove does not support video streams that include B frames because they require lookahead.~%# ~%# Specifically, the requirements for different `format` values are:~%# ~%# - `h264`~%#   - Use Annex B formatted data~%#   - Each CompressedVideo message should contain enough NAL units to decode exactly one video frame~%#   - Each message containing a key frame (IDR) must also include a SPS NAL unit~%# ~%# - `h265` (HEVC)~%#   - Use Annex B formatted data~%#   - Each CompressedVideo message should contain enough NAL units to decode exactly one video frame~%#   - Each message containing a key frame (IRAP) must also include relevant VPS/SPS/PPS NAL units~%# ~%# - `vp9`~%#   - Each CompressedVideo message should contain exactly one video frame~%# ~%# - `av1`~%#   - Use the \"Low overhead bitstream format\" (section 5.2)~%#   - Each CompressedVideo message should contain enough OBUs to decode exactly one video frame~%#   - Each message containing a key frame must also include a Sequence Header OBU~%uint8[] data~%~%# Video format.~%# ~%# Supported values: `h264`, `h265`, `vp9`, `av1`.~%# ~%# Note: compressed video support is subject to hardware limitations and patent licensing, so not all encodings may be supported on all platforms. See more about [H.265 support](https://caniuse.com/hevc), [VP9 support](https://caniuse.com/webm), and [AV1 support](https://caniuse.com/av1).~%string format~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CompressedVideo>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'frame_id))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     4 (cl:length (cl:slot-value msg 'format))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CompressedVideo>))
  "Converts a ROS message object to a list"
  (cl:list 'CompressedVideo
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':frame_id (frame_id msg))
    (cl:cons ':data (data msg))
    (cl:cons ':format (format msg))
))
