; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude LinePrimitive.msg.html

(cl:defclass <LinePrimitive> (roslisp-msg-protocol:ros-message)
  ((type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0)
   (pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (thickness
    :reader thickness
    :initarg :thickness
    :type cl:float
    :initform 0.0)
   (scale_invariant
    :reader scale_invariant
    :initarg :scale_invariant
    :type cl:boolean
    :initform cl:nil)
   (points
    :reader points
    :initarg :points
    :type (cl:vector geometry_msgs-msg:Point)
   :initform (cl:make-array 0 :element-type 'geometry_msgs-msg:Point :initial-element (cl:make-instance 'geometry_msgs-msg:Point)))
   (color
    :reader color
    :initarg :color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (colors
    :reader colors
    :initarg :colors
    :type (cl:vector foxglove_msgs-msg:Color)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:Color :initial-element (cl:make-instance 'foxglove_msgs-msg:Color)))
   (indices
    :reader indices
    :initarg :indices
    :type (cl:vector cl:integer)
   :initform (cl:make-array 0 :element-type 'cl:integer :initial-element 0)))
)

(cl:defclass LinePrimitive (<LinePrimitive>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <LinePrimitive>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'LinePrimitive)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<LinePrimitive> is deprecated: use foxglove_msgs-msg:LinePrimitive instead.")))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:type-val is deprecated.  Use foxglove_msgs-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'thickness-val :lambda-list '(m))
(cl:defmethod thickness-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:thickness-val is deprecated.  Use foxglove_msgs-msg:thickness instead.")
  (thickness m))

(cl:ensure-generic-function 'scale_invariant-val :lambda-list '(m))
(cl:defmethod scale_invariant-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:scale_invariant-val is deprecated.  Use foxglove_msgs-msg:scale_invariant instead.")
  (scale_invariant m))

(cl:ensure-generic-function 'points-val :lambda-list '(m))
(cl:defmethod points-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:points-val is deprecated.  Use foxglove_msgs-msg:points instead.")
  (points m))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:color-val is deprecated.  Use foxglove_msgs-msg:color instead.")
  (color m))

(cl:ensure-generic-function 'colors-val :lambda-list '(m))
(cl:defmethod colors-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:colors-val is deprecated.  Use foxglove_msgs-msg:colors instead.")
  (colors m))

(cl:ensure-generic-function 'indices-val :lambda-list '(m))
(cl:defmethod indices-val ((m <LinePrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:indices-val is deprecated.  Use foxglove_msgs-msg:indices instead.")
  (indices m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<LinePrimitive>)))
    "Constants for message type '<LinePrimitive>"
  '((:LINE_STRIP . 0)
    (:LINE_LOOP . 1)
    (:LINE_LIST . 2))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'LinePrimitive)))
    "Constants for message type 'LinePrimitive"
  '((:LINE_STRIP . 0)
    (:LINE_LOOP . 1)
    (:LINE_LIST . 2))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <LinePrimitive>) ostream)
  "Serializes a message object of type '<LinePrimitive>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'thickness))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'scale_invariant) 1 0)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'points))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'colors))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'colors))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'indices))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) ele) ostream))
   (cl:slot-value msg 'indices))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <LinePrimitive>) istream)
  "Deserializes a message object of type '<LinePrimitive>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'thickness) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'scale_invariant) (cl:not (cl:zerop (cl:read-byte istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'geometry_msgs-msg:Point))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'colors) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'colors)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:Color))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'indices) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'indices)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<LinePrimitive>)))
  "Returns string type for a message object of type '<LinePrimitive>"
  "foxglove_msgs/LinePrimitive")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'LinePrimitive)))
  "Returns string type for a message object of type 'LinePrimitive"
  "foxglove_msgs/LinePrimitive")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<LinePrimitive>)))
  "Returns md5sum for a message object of type '<LinePrimitive>"
  "6c2f969386c9a9fb9365fdf2a22d851c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'LinePrimitive)))
  "Returns md5sum for a message object of type 'LinePrimitive"
  "6c2f969386c9a9fb9365fdf2a22d851c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<LinePrimitive>)))
  "Returns full string definition for message of type '<LinePrimitive>"
  (cl:format cl:nil "# foxglove_msgs/LinePrimitive~%# A primitive representing a series of points connected by lines~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Connected line segments: 0-1, 1-2, ..., (n-1)-n~%uint8 LINE_STRIP=0~%~%# Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0~%uint8 LINE_LOOP=1~%~%# Individual line segments: 0-1, 2-3, 4-5, ...~%uint8 LINE_LIST=2~%~%# Drawing primitive to use for lines~%uint8 type~%~%# Origin of lines relative to reference frame~%geometry_msgs/Pose pose~%~%# Line thickness~%float64 thickness~%~%# Indicates whether `thickness` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)~%bool scale_invariant~%~%# Points along the line~%geometry_msgs/Point[] points~%~%# Solid color to use for the whole line. Ignored if `colors` is non-empty.~%foxglove_msgs/Color color~%~%# Per-point colors (if non-empty, must have the same length as `points`).~%foxglove_msgs/Color[] colors~%~%# Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.~%# ~%# If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).~%uint32[] indices~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'LinePrimitive)))
  "Returns full string definition for message of type 'LinePrimitive"
  (cl:format cl:nil "# foxglove_msgs/LinePrimitive~%# A primitive representing a series of points connected by lines~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Connected line segments: 0-1, 1-2, ..., (n-1)-n~%uint8 LINE_STRIP=0~%~%# Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0~%uint8 LINE_LOOP=1~%~%# Individual line segments: 0-1, 2-3, 4-5, ...~%uint8 LINE_LIST=2~%~%# Drawing primitive to use for lines~%uint8 type~%~%# Origin of lines relative to reference frame~%geometry_msgs/Pose pose~%~%# Line thickness~%float64 thickness~%~%# Indicates whether `thickness` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)~%bool scale_invariant~%~%# Points along the line~%geometry_msgs/Point[] points~%~%# Solid color to use for the whole line. Ignored if `colors` is non-empty.~%foxglove_msgs/Color color~%~%# Per-point colors (if non-empty, must have the same length as `points`).~%foxglove_msgs/Color[] colors~%~%# Indices into the `points` and `colors` attribute arrays, which can be used to avoid duplicating attribute data.~%# ~%# If omitted or empty, indexing will not be used. This default behavior is equivalent to specifying [0, 1, ..., N-1] for the indices (where N is the number of `points` provided).~%uint32[] indices~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <LinePrimitive>))
  (cl:+ 0
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     8
     1
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'colors) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'indices) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 4)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <LinePrimitive>))
  "Converts a ROS message object to a list"
  (cl:list 'LinePrimitive
    (cl:cons ':type (type msg))
    (cl:cons ':pose (pose msg))
    (cl:cons ':thickness (thickness msg))
    (cl:cons ':scale_invariant (scale_invariant msg))
    (cl:cons ':points (points msg))
    (cl:cons ':color (color msg))
    (cl:cons ':colors (colors msg))
    (cl:cons ':indices (indices msg))
))
