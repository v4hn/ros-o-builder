(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          BODY_FRAME_ID-VAL
          BODY_FRAME_ID
          POSE-VAL
          POSE
          LINEAR_VELOCITY-VAL
          LINEAR_VELOCITY
          ANGULAR_VELOCITY-VAL
          ANGULAR_VELOCITY
          POSE_COVARIANCE-VAL
          POSE_COVARIANCE
          VELOCITY_COVARIANCE-VAL
          VELOCITY_COVARIANCE
          METADATA-VAL
          METADATA
))