; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude RawImage.msg.html

(cl:defclass <RawImage> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform "")
   (width
    :reader width
    :initarg :width
    :type cl:integer
    :initform 0)
   (height
    :reader height
    :initarg :height
    :type cl:integer
    :initform 0)
   (encoding
    :reader encoding
    :initarg :encoding
    :type cl:string
    :initform "")
   (step
    :reader step
    :initarg :step
    :type cl:integer
    :initform 0)
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass RawImage (<RawImage>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <RawImage>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'RawImage)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<RawImage> is deprecated: use foxglove_msgs-msg:RawImage instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:frame_id-val is deprecated.  Use foxglove_msgs-msg:frame_id instead.")
  (frame_id m))

(cl:ensure-generic-function 'width-val :lambda-list '(m))
(cl:defmethod width-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:width-val is deprecated.  Use foxglove_msgs-msg:width instead.")
  (width m))

(cl:ensure-generic-function 'height-val :lambda-list '(m))
(cl:defmethod height-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:height-val is deprecated.  Use foxglove_msgs-msg:height instead.")
  (height m))

(cl:ensure-generic-function 'encoding-val :lambda-list '(m))
(cl:defmethod encoding-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:encoding-val is deprecated.  Use foxglove_msgs-msg:encoding instead.")
  (encoding m))

(cl:ensure-generic-function 'step-val :lambda-list '(m))
(cl:defmethod step-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:step-val is deprecated.  Use foxglove_msgs-msg:step instead.")
  (step m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <RawImage>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:data-val is deprecated.  Use foxglove_msgs-msg:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <RawImage>) ostream)
  "Serializes a message object of type '<RawImage>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'height)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'encoding))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'encoding))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'step)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'step)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'step)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'step)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <RawImage>) istream)
  "Deserializes a message object of type '<RawImage>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'height)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'encoding) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'encoding) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'step)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'step)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'step)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'step)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<RawImage>)))
  "Returns string type for a message object of type '<RawImage>"
  "foxglove_msgs/RawImage")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'RawImage)))
  "Returns string type for a message object of type 'RawImage"
  "foxglove_msgs/RawImage")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<RawImage>)))
  "Returns md5sum for a message object of type '<RawImage>"
  "1cd47908cbbed66c19b5a9d29d111381")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'RawImage)))
  "Returns md5sum for a message object of type 'RawImage"
  "1cd47908cbbed66c19b5a9d29d111381")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<RawImage>)))
  "Returns full string definition for message of type '<RawImage>"
  (cl:format cl:nil "# foxglove_msgs/RawImage~%# A raw image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of image~%time timestamp~%~%# Frame of reference for the image. The origin of the frame is the optical center of the camera. +x points to the right in the image, +y points down, and +z points into the plane of the image.~%string frame_id~%~%# Image width in pixels~%uint32 width~%~%# Image height in pixels~%uint32 height~%~%# Encoding of the raw image data. See the `data` field description for supported values.~%string encoding~%~%# Byte length of a single row. This is usually some multiple of `width` depending on the encoding, but can be greater to incorporate padding.~%uint32 step~%~%# Raw image data.~%# ~%# For each `encoding` value, the `data` field contains image pixel data serialized as follows:~%# ~%# - `yuv422` or `uyvy`:~%#   - Pixel colors are decomposed into [Y'UV](https://en.wikipedia.org/wiki/Y%E2%80%B2UV) channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - U and V values are shared between horizontal pairs of pixels. Each pair of output pixels is serialized as [U, Y1, V, Y2].~%#   - `step` must be greater than or equal to `width` * 2.~%# - `yuv422_yuy2` or  `yuyv`:~%#   - Pixel colors are decomposed into [Y'UV](https://en.wikipedia.org/wiki/Y%E2%80%B2UV) channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - U and V values are shared between horizontal pairs of pixels. Each pair of output pixels is encoded as [Y1, U, Y2, V].~%#   - `step` must be greater than or equal to `width` * 2.~%# - `nv12`:~%#   - Pixel colors are decomposed into [Y'UV](https://en.wikipedia.org/wiki/Y%E2%80%B2UV) channels using 4:2:0 chroma subsampling. The data is stored in [NV12](https://www.kernel.org/doc/html/v4.10/media/uapi/v4l/pixfmt-nv12.html) semi-planar layout with two contiguous planes: a Y (luma) plane followed by an interleaved UV (chroma) plane.~%#   - All channel values are represented as unsigned 8-bit integers.~%#   - Both planes use `step` as their row stride.~%#   - The Y plane contains one luma value per pixel (`step` * `height` bytes).~%#   - The UV plane contains interleaved U, V chroma pairs, subsampled by a factor of 2 in both dimensions (`width`/2 pairs per row, `height`/2 rows, `step` * `height`/2 bytes). Each U, V pair is shared by a 2x2 block of pixels.~%#   - `width` and `height` must be even.~%#   - `step` must be greater than or equal to `width`.~%#   - Total `data` length is `step` * `height` * 3/2 bytes.~%# - `rgb8`:~%#   - Pixel colors are decomposed into Red, Green, and Blue channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is serialized as [R, G, B].~%#   - `step` must be greater than or equal to `width` * 3.~%# - `rgba8`:~%#   - Pixel colors are decomposed into Red, Green, Blue, and Alpha channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is serialized as [R, G, B, Alpha].~%#   - `step` must be greater than or equal to `width` * 4.~%# - `bgr8` or `8UC3`:~%#   - Pixel colors are decomposed into Blue, Green, and Red channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is serialized as [B, G, R].~%#   - `step` must be greater than or equal to `width` * 3.~%# - `bgra8`:~%#   - Pixel colors are decomposed into Blue, Green, Red, and Alpha channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is encoded as [B, G, R, Alpha].~%#   - `step` must be greater than or equal to `width` * 4.~%# - `32FC1`:~%#   - Pixel brightness is represented as a single-channel, 32-bit little-endian IEEE 754 floating-point value, ranging from 0.0 (black) to 1.0 (white).~%#   - `step` must be greater than or equal to `width` * 4.~%# - `bayer_rggb8`, `bayer_bggr8`, `bayer_gbrg8`, or `bayer_grbg8`:~%#   - Pixel colors are decomposed into Red, Blue and Green channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers, and serialized in a 2x2 bayer filter pattern.~%#   - The order of the four letters after `bayer_` determine the layout, so for `bayer_wxyz8` the pattern is:~%#   ```text~%#   w | x~%#   - + -~%#   y | z~%#   ```~%#   - `step` must be greater than or equal to `width`.~%# - `mono8` or `8UC1`:~%#   - Pixel brightness is represented as unsigned 8-bit integers.~%#   - `step` must be greater than or equal to `width`.~%# - `mono16` or `16UC1`:~%#   - Pixel brightness is represented as 16-bit unsigned little-endian integers. Rendering of these values is controlled in [Image panel color mode settings](https://docs.foxglove.dev/docs/visualization/panels/image#general).~%#   - `step` must be greater than or equal to `width` * 2.~%uint8[] data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'RawImage)))
  "Returns full string definition for message of type 'RawImage"
  (cl:format cl:nil "# foxglove_msgs/RawImage~%# A raw image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of image~%time timestamp~%~%# Frame of reference for the image. The origin of the frame is the optical center of the camera. +x points to the right in the image, +y points down, and +z points into the plane of the image.~%string frame_id~%~%# Image width in pixels~%uint32 width~%~%# Image height in pixels~%uint32 height~%~%# Encoding of the raw image data. See the `data` field description for supported values.~%string encoding~%~%# Byte length of a single row. This is usually some multiple of `width` depending on the encoding, but can be greater to incorporate padding.~%uint32 step~%~%# Raw image data.~%# ~%# For each `encoding` value, the `data` field contains image pixel data serialized as follows:~%# ~%# - `yuv422` or `uyvy`:~%#   - Pixel colors are decomposed into [Y'UV](https://en.wikipedia.org/wiki/Y%E2%80%B2UV) channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - U and V values are shared between horizontal pairs of pixels. Each pair of output pixels is serialized as [U, Y1, V, Y2].~%#   - `step` must be greater than or equal to `width` * 2.~%# - `yuv422_yuy2` or  `yuyv`:~%#   - Pixel colors are decomposed into [Y'UV](https://en.wikipedia.org/wiki/Y%E2%80%B2UV) channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - U and V values are shared between horizontal pairs of pixels. Each pair of output pixels is encoded as [Y1, U, Y2, V].~%#   - `step` must be greater than or equal to `width` * 2.~%# - `nv12`:~%#   - Pixel colors are decomposed into [Y'UV](https://en.wikipedia.org/wiki/Y%E2%80%B2UV) channels using 4:2:0 chroma subsampling. The data is stored in [NV12](https://www.kernel.org/doc/html/v4.10/media/uapi/v4l/pixfmt-nv12.html) semi-planar layout with two contiguous planes: a Y (luma) plane followed by an interleaved UV (chroma) plane.~%#   - All channel values are represented as unsigned 8-bit integers.~%#   - Both planes use `step` as their row stride.~%#   - The Y plane contains one luma value per pixel (`step` * `height` bytes).~%#   - The UV plane contains interleaved U, V chroma pairs, subsampled by a factor of 2 in both dimensions (`width`/2 pairs per row, `height`/2 rows, `step` * `height`/2 bytes). Each U, V pair is shared by a 2x2 block of pixels.~%#   - `width` and `height` must be even.~%#   - `step` must be greater than or equal to `width`.~%#   - Total `data` length is `step` * `height` * 3/2 bytes.~%# - `rgb8`:~%#   - Pixel colors are decomposed into Red, Green, and Blue channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is serialized as [R, G, B].~%#   - `step` must be greater than or equal to `width` * 3.~%# - `rgba8`:~%#   - Pixel colors are decomposed into Red, Green, Blue, and Alpha channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is serialized as [R, G, B, Alpha].~%#   - `step` must be greater than or equal to `width` * 4.~%# - `bgr8` or `8UC3`:~%#   - Pixel colors are decomposed into Blue, Green, and Red channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is serialized as [B, G, R].~%#   - `step` must be greater than or equal to `width` * 3.~%# - `bgra8`:~%#   - Pixel colors are decomposed into Blue, Green, Red, and Alpha channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers.~%#   - Each output pixel is encoded as [B, G, R, Alpha].~%#   - `step` must be greater than or equal to `width` * 4.~%# - `32FC1`:~%#   - Pixel brightness is represented as a single-channel, 32-bit little-endian IEEE 754 floating-point value, ranging from 0.0 (black) to 1.0 (white).~%#   - `step` must be greater than or equal to `width` * 4.~%# - `bayer_rggb8`, `bayer_bggr8`, `bayer_gbrg8`, or `bayer_grbg8`:~%#   - Pixel colors are decomposed into Red, Blue and Green channels.~%#   - Pixel channel values are represented as unsigned 8-bit integers, and serialized in a 2x2 bayer filter pattern.~%#   - The order of the four letters after `bayer_` determine the layout, so for `bayer_wxyz8` the pattern is:~%#   ```text~%#   w | x~%#   - + -~%#   y | z~%#   ```~%#   - `step` must be greater than or equal to `width`.~%# - `mono8` or `8UC1`:~%#   - Pixel brightness is represented as unsigned 8-bit integers.~%#   - `step` must be greater than or equal to `width`.~%# - `mono16` or `16UC1`:~%#   - Pixel brightness is represented as 16-bit unsigned little-endian integers. Rendering of these values is controlled in [Image panel color mode settings](https://docs.foxglove.dev/docs/visualization/panels/image#general).~%#   - `step` must be greater than or equal to `width` * 2.~%uint8[] data~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <RawImage>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'frame_id))
     4
     4
     4 (cl:length (cl:slot-value msg 'encoding))
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <RawImage>))
  "Converts a ROS message object to a list"
  (cl:list 'RawImage
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':frame_id (frame_id msg))
    (cl:cons ':width (width msg))
    (cl:cons ':height (height msg))
    (cl:cons ':encoding (encoding msg))
    (cl:cons ':step (step msg))
    (cl:cons ':data (data msg))
))
