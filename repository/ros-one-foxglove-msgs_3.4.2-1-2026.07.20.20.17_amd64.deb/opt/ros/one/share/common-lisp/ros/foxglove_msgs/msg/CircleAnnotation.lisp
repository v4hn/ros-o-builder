; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude CircleAnnotation.msg.html

(cl:defclass <CircleAnnotation> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (position
    :reader position
    :initarg :position
    :type foxglove_msgs-msg:Point2
    :initform (cl:make-instance 'foxglove_msgs-msg:Point2))
   (diameter
    :reader diameter
    :initarg :diameter
    :type cl:float
    :initform 0.0)
   (thickness
    :reader thickness
    :initarg :thickness
    :type cl:float
    :initform 0.0)
   (fill_color
    :reader fill_color
    :initarg :fill_color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (outline_color
    :reader outline_color
    :initarg :outline_color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (metadata
    :reader metadata
    :initarg :metadata
    :type (cl:vector foxglove_msgs-msg:KeyValuePair)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:KeyValuePair :initial-element (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))))
)

(cl:defclass CircleAnnotation (<CircleAnnotation>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CircleAnnotation>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CircleAnnotation)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<CircleAnnotation> is deprecated: use foxglove_msgs-msg:CircleAnnotation instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'position-val :lambda-list '(m))
(cl:defmethod position-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:position-val is deprecated.  Use foxglove_msgs-msg:position instead.")
  (position m))

(cl:ensure-generic-function 'diameter-val :lambda-list '(m))
(cl:defmethod diameter-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:diameter-val is deprecated.  Use foxglove_msgs-msg:diameter instead.")
  (diameter m))

(cl:ensure-generic-function 'thickness-val :lambda-list '(m))
(cl:defmethod thickness-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:thickness-val is deprecated.  Use foxglove_msgs-msg:thickness instead.")
  (thickness m))

(cl:ensure-generic-function 'fill_color-val :lambda-list '(m))
(cl:defmethod fill_color-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:fill_color-val is deprecated.  Use foxglove_msgs-msg:fill_color instead.")
  (fill_color m))

(cl:ensure-generic-function 'outline_color-val :lambda-list '(m))
(cl:defmethod outline_color-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:outline_color-val is deprecated.  Use foxglove_msgs-msg:outline_color instead.")
  (outline_color m))

(cl:ensure-generic-function 'metadata-val :lambda-list '(m))
(cl:defmethod metadata-val ((m <CircleAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:metadata-val is deprecated.  Use foxglove_msgs-msg:metadata instead.")
  (metadata m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CircleAnnotation>) ostream)
  "Serializes a message object of type '<CircleAnnotation>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'position) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'diameter))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'thickness))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'fill_color) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'outline_color) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'metadata))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'metadata))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CircleAnnotation>) istream)
  "Deserializes a message object of type '<CircleAnnotation>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'position) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'diameter) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'thickness) (roslisp-utils:decode-double-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'fill_color) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'outline_color) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'metadata) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'metadata)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CircleAnnotation>)))
  "Returns string type for a message object of type '<CircleAnnotation>"
  "foxglove_msgs/CircleAnnotation")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CircleAnnotation)))
  "Returns string type for a message object of type 'CircleAnnotation"
  "foxglove_msgs/CircleAnnotation")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CircleAnnotation>)))
  "Returns md5sum for a message object of type '<CircleAnnotation>"
  "c6cdbecc2aed1711215df4398550aa97")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CircleAnnotation)))
  "Returns md5sum for a message object of type 'CircleAnnotation"
  "c6cdbecc2aed1711215df4398550aa97")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CircleAnnotation>)))
  "Returns full string definition for message of type '<CircleAnnotation>"
  (cl:format cl:nil "# foxglove_msgs/CircleAnnotation~%# A circle annotation on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of circle~%time timestamp~%~%# Center of the circle in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Circle diameter in pixels~%float64 diameter~%~%# Line thickness in pixels~%float64 thickness~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CircleAnnotation)))
  "Returns full string definition for message of type 'CircleAnnotation"
  (cl:format cl:nil "# foxglove_msgs/CircleAnnotation~%# A circle annotation on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of circle~%time timestamp~%~%# Center of the circle in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Circle diameter in pixels~%float64 diameter~%~%# Line thickness in pixels~%float64 thickness~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CircleAnnotation>))
  (cl:+ 0
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'position))
     8
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'fill_color))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'outline_color))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'metadata) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CircleAnnotation>))
  "Converts a ROS message object to a list"
  (cl:list 'CircleAnnotation
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':position (position msg))
    (cl:cons ':diameter (diameter msg))
    (cl:cons ':thickness (thickness msg))
    (cl:cons ':fill_color (fill_color msg))
    (cl:cons ':outline_color (outline_color msg))
    (cl:cons ':metadata (metadata msg))
))
