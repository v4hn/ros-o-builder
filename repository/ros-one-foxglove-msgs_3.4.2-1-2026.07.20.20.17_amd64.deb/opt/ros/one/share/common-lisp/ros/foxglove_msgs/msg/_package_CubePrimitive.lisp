(cl:in-package foxglove_msgs-msg)
(cl:export '(POSE-VAL
          POSE
          SIZE-VAL
          SIZE
          COLOR-VAL
          COLOR
))