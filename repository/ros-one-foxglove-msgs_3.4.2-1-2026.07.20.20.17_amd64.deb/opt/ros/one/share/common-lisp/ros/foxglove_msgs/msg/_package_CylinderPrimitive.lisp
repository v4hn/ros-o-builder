(cl:in-package foxglove_msgs-msg)
(cl:export '(POSE-VAL
          POSE
          SIZE-VAL
          SIZE
          BOTTOM_SCALE-VAL
          BOTTOM_SCALE
          TOP_SCALE-VAL
          TOP_SCALE
          COLOR-VAL
          COLOR
))