(cl:in-package foxglove_msgs-msg)
(cl:export '(POSE-VAL
          POSE
          BILLBOARD-VAL
          BILLBOARD
          FONT_SIZE-VAL
          FONT_SIZE
          SCALE_INVARIANT-VAL
          SCALE_INVARIANT
          COLOR-VAL
          COLOR
          TEXT-VAL
          TEXT
))