; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude ImageAnnotations.msg.html

(cl:defclass <ImageAnnotations> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (circles
    :reader circles
    :initarg :circles
    :type (cl:vector foxglove_msgs-msg:CircleAnnotation)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:CircleAnnotation :initial-element (cl:make-instance 'foxglove_msgs-msg:CircleAnnotation)))
   (points
    :reader points
    :initarg :points
    :type (cl:vector foxglove_msgs-msg:PointsAnnotation)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:PointsAnnotation :initial-element (cl:make-instance 'foxglove_msgs-msg:PointsAnnotation)))
   (texts
    :reader texts
    :initarg :texts
    :type (cl:vector foxglove_msgs-msg:TextAnnotation)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:TextAnnotation :initial-element (cl:make-instance 'foxglove_msgs-msg:TextAnnotation)))
   (metadata
    :reader metadata
    :initarg :metadata
    :type (cl:vector foxglove_msgs-msg:KeyValuePair)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:KeyValuePair :initial-element (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))))
)

(cl:defclass ImageAnnotations (<ImageAnnotations>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ImageAnnotations>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ImageAnnotations)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<ImageAnnotations> is deprecated: use foxglove_msgs-msg:ImageAnnotations instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <ImageAnnotations>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'circles-val :lambda-list '(m))
(cl:defmethod circles-val ((m <ImageAnnotations>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:circles-val is deprecated.  Use foxglove_msgs-msg:circles instead.")
  (circles m))

(cl:ensure-generic-function 'points-val :lambda-list '(m))
(cl:defmethod points-val ((m <ImageAnnotations>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:points-val is deprecated.  Use foxglove_msgs-msg:points instead.")
  (points m))

(cl:ensure-generic-function 'texts-val :lambda-list '(m))
(cl:defmethod texts-val ((m <ImageAnnotations>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:texts-val is deprecated.  Use foxglove_msgs-msg:texts instead.")
  (texts m))

(cl:ensure-generic-function 'metadata-val :lambda-list '(m))
(cl:defmethod metadata-val ((m <ImageAnnotations>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:metadata-val is deprecated.  Use foxglove_msgs-msg:metadata instead.")
  (metadata m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ImageAnnotations>) ostream)
  "Serializes a message object of type '<ImageAnnotations>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'circles))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'circles))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'points))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'points))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'texts))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'texts))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'metadata))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'metadata))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ImageAnnotations>) istream)
  "Deserializes a message object of type '<ImageAnnotations>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'circles) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'circles)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:CircleAnnotation))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'points) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'points)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:PointsAnnotation))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'texts) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'texts)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:TextAnnotation))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'metadata) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'metadata)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ImageAnnotations>)))
  "Returns string type for a message object of type '<ImageAnnotations>"
  "foxglove_msgs/ImageAnnotations")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ImageAnnotations)))
  "Returns string type for a message object of type 'ImageAnnotations"
  "foxglove_msgs/ImageAnnotations")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ImageAnnotations>)))
  "Returns md5sum for a message object of type '<ImageAnnotations>"
  "269aff4675381418078cf591128b77ac")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ImageAnnotations)))
  "Returns md5sum for a message object of type 'ImageAnnotations"
  "269aff4675381418078cf591128b77ac")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ImageAnnotations>)))
  "Returns full string definition for message of type '<ImageAnnotations>"
  (cl:format cl:nil "# foxglove_msgs/ImageAnnotations~%# Array of annotations for a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the image annotations. When set, individual annotation timestamps will be ignored.~%time timestamp~%~%# Circle annotations~%foxglove_msgs/CircleAnnotation[] circles~%~%# Points annotations~%foxglove_msgs/PointsAnnotation[] points~%~%# Text annotations~%foxglove_msgs/TextAnnotation[] texts~%~%# Additional user-provided metadata associated with the image annotations. Keys must be unique within this object. Per-annotation metadata takes precedence over these values.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/CircleAnnotation~%# foxglove_msgs/CircleAnnotation~%# A circle annotation on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of circle~%time timestamp~%~%# Center of the circle in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Circle diameter in pixels~%float64 diameter~%~%# Line thickness in pixels~%float64 thickness~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%================================================================================~%MSG: foxglove_msgs/PointsAnnotation~%# foxglove_msgs/PointsAnnotation~%# An array of points on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Unknown points annotation type~%uint8 UNKNOWN=0~%~%# Individual points: 0, 1, 2, ...~%uint8 POINTS=1~%~%# Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0~%uint8 LINE_LOOP=2~%~%# Connected line segments: 0-1, 1-2, ..., (n-1)-n~%uint8 LINE_STRIP=3~%~%# Individual line segments: 0-1, 2-3, 4-5, ...~%uint8 LINE_LIST=4~%~%# Type of points annotation to draw~%uint8 type~%~%# Points in 2D image coordinates (pixels).~%# These coordinates use the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2[] points~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Per-point colors, if `type` is `POINTS`, or per-segment stroke colors, if `type` is `LINE_LIST`, `LINE_STRIP` or `LINE_LOOP`.~%foxglove_msgs/Color[] outline_colors~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Stroke thickness in pixels~%float64 thickness~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/TextAnnotation~%# foxglove_msgs/TextAnnotation~%# A text label on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Bottom-left origin of the text label in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Text to display~%string text~%~%# Font size in pixels~%float64 font_size~%~%# Text color~%foxglove_msgs/Color text_color~%~%# Background fill color~%foxglove_msgs/Color background_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ImageAnnotations)))
  "Returns full string definition for message of type 'ImageAnnotations"
  (cl:format cl:nil "# foxglove_msgs/ImageAnnotations~%# Array of annotations for a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the image annotations. When set, individual annotation timestamps will be ignored.~%time timestamp~%~%# Circle annotations~%foxglove_msgs/CircleAnnotation[] circles~%~%# Points annotations~%foxglove_msgs/PointsAnnotation[] points~%~%# Text annotations~%foxglove_msgs/TextAnnotation[] texts~%~%# Additional user-provided metadata associated with the image annotations. Keys must be unique within this object. Per-annotation metadata takes precedence over these values.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/CircleAnnotation~%# foxglove_msgs/CircleAnnotation~%# A circle annotation on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of circle~%time timestamp~%~%# Center of the circle in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Circle diameter in pixels~%float64 diameter~%~%# Line thickness in pixels~%float64 thickness~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%================================================================================~%MSG: foxglove_msgs/PointsAnnotation~%# foxglove_msgs/PointsAnnotation~%# An array of points on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Unknown points annotation type~%uint8 UNKNOWN=0~%~%# Individual points: 0, 1, 2, ...~%uint8 POINTS=1~%~%# Closed polygon: 0-1, 1-2, ..., (n-1)-n, n-0~%uint8 LINE_LOOP=2~%~%# Connected line segments: 0-1, 1-2, ..., (n-1)-n~%uint8 LINE_STRIP=3~%~%# Individual line segments: 0-1, 2-3, 4-5, ...~%uint8 LINE_LIST=4~%~%# Type of points annotation to draw~%uint8 type~%~%# Points in 2D image coordinates (pixels).~%# These coordinates use the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2[] points~%~%# Outline color~%foxglove_msgs/Color outline_color~%~%# Per-point colors, if `type` is `POINTS`, or per-segment stroke colors, if `type` is `LINE_LIST`, `LINE_STRIP` or `LINE_LOOP`.~%foxglove_msgs/Color[] outline_colors~%~%# Fill color~%foxglove_msgs/Color fill_color~%~%# Stroke thickness in pixels~%float64 thickness~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/TextAnnotation~%# foxglove_msgs/TextAnnotation~%# A text label on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Bottom-left origin of the text label in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Text to display~%string text~%~%# Font size in pixels~%float64 font_size~%~%# Text color~%foxglove_msgs/Color text_color~%~%# Background fill color~%foxglove_msgs/Color background_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ImageAnnotations>))
  (cl:+ 0
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'circles) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'points) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'texts) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'metadata) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ImageAnnotations>))
  "Converts a ROS message object to a list"
  (cl:list 'ImageAnnotations
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':circles (circles msg))
    (cl:cons ':points (points msg))
    (cl:cons ':texts (texts msg))
    (cl:cons ':metadata (metadata msg))
))
