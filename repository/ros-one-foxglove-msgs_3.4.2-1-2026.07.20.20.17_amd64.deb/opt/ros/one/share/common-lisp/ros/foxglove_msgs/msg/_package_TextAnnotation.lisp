(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          POSITION-VAL
          POSITION
          TEXT-VAL
          TEXT
          FONT_SIZE-VAL
          FONT_SIZE
          TEXT_COLOR-VAL
          TEXT_COLOR
          BACKGROUND_COLOR-VAL
          BACKGROUND_COLOR
          METADATA-VAL
          METADATA
))