; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude JointStates.msg.html

(cl:defclass <JointStates> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (joints
    :reader joints
    :initarg :joints
    :type (cl:vector foxglove_msgs-msg:JointState)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:JointState :initial-element (cl:make-instance 'foxglove_msgs-msg:JointState))))
)

(cl:defclass JointStates (<JointStates>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <JointStates>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'JointStates)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<JointStates> is deprecated: use foxglove_msgs-msg:JointStates instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <JointStates>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'joints-val :lambda-list '(m))
(cl:defmethod joints-val ((m <JointStates>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:joints-val is deprecated.  Use foxglove_msgs-msg:joints instead.")
  (joints m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <JointStates>) ostream)
  "Serializes a message object of type '<JointStates>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'joints))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'joints))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <JointStates>) istream)
  "Deserializes a message object of type '<JointStates>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'joints) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'joints)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:JointState))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<JointStates>)))
  "Returns string type for a message object of type '<JointStates>"
  "foxglove_msgs/JointStates")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'JointStates)))
  "Returns string type for a message object of type 'JointStates"
  "foxglove_msgs/JointStates")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<JointStates>)))
  "Returns md5sum for a message object of type '<JointStates>"
  "fec3db8caf3a6ed0850d7d1cc8730c95")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'JointStates)))
  "Returns md5sum for a message object of type 'JointStates"
  "fec3db8caf3a6ed0850d7d1cc8730c95")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<JointStates>)))
  "Returns full string definition for message of type '<JointStates>"
  (cl:format cl:nil "# foxglove_msgs/JointStates~%# The state of a set of joints at a given time.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the joint states~%time timestamp~%~%# Joint states~%foxglove_msgs/JointState[] joints~%~%================================================================================~%MSG: foxglove_msgs/JointState~%# foxglove_msgs/JointState~%# The state of a single joint (revolute or prismatic).~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Joint name~%string name~%~%# Joint position. Radians for revolute joints, meters for prismatic joints. (NaN indicates this value is not set)~%float64 position~%~%# Joint velocity. Rad/s for revolute joints, m/s for prismatic joints. (NaN indicates this value is not set)~%float64 velocity~%~%# Joint acceleration. Rad/s² for revolute joints, m/s² for prismatic joints. (NaN indicates this value is not set)~%float64 acceleration~%~%# Joint effort (force or torque). Nm for revolute joints, N for prismatic joints. (NaN indicates this value is not set)~%float64 effort~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'JointStates)))
  "Returns full string definition for message of type 'JointStates"
  (cl:format cl:nil "# foxglove_msgs/JointStates~%# The state of a set of joints at a given time.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the joint states~%time timestamp~%~%# Joint states~%foxglove_msgs/JointState[] joints~%~%================================================================================~%MSG: foxglove_msgs/JointState~%# foxglove_msgs/JointState~%# The state of a single joint (revolute or prismatic).~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Joint name~%string name~%~%# Joint position. Radians for revolute joints, meters for prismatic joints. (NaN indicates this value is not set)~%float64 position~%~%# Joint velocity. Rad/s for revolute joints, m/s for prismatic joints. (NaN indicates this value is not set)~%float64 velocity~%~%# Joint acceleration. Rad/s² for revolute joints, m/s² for prismatic joints. (NaN indicates this value is not set)~%float64 acceleration~%~%# Joint effort (force or torque). Nm for revolute joints, N for prismatic joints. (NaN indicates this value is not set)~%float64 effort~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <JointStates>))
  (cl:+ 0
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'joints) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <JointStates>))
  "Converts a ROS message object to a list"
  (cl:list 'JointStates
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':joints (joints msg))
))
