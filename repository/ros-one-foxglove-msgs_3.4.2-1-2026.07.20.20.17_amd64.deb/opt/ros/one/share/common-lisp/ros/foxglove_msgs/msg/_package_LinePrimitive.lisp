(cl:in-package foxglove_msgs-msg)
(cl:export '(TYPE-VAL
          TYPE
          POSE-VAL
          POSE
          THICKNESS-VAL
          THICKNESS
          SCALE_INVARIANT-VAL
          SCALE_INVARIANT
          POINTS-VAL
          POINTS
          COLOR-VAL
          COLOR
          COLORS-VAL
          COLORS
          INDICES-VAL
          INDICES
))