; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude SceneEntityDeletion.msg.html

(cl:defclass <SceneEntityDeletion> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0)
   (id
    :reader id
    :initarg :id
    :type cl:string
    :initform ""))
)

(cl:defclass SceneEntityDeletion (<SceneEntityDeletion>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SceneEntityDeletion>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SceneEntityDeletion)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<SceneEntityDeletion> is deprecated: use foxglove_msgs-msg:SceneEntityDeletion instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <SceneEntityDeletion>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <SceneEntityDeletion>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:type-val is deprecated.  Use foxglove_msgs-msg:type instead.")
  (type m))

(cl:ensure-generic-function 'id-val :lambda-list '(m))
(cl:defmethod id-val ((m <SceneEntityDeletion>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:id-val is deprecated.  Use foxglove_msgs-msg:id instead.")
  (id m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<SceneEntityDeletion>)))
    "Constants for message type '<SceneEntityDeletion>"
  '((:MATCHING_ID . 0)
    (:ALL . 1))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'SceneEntityDeletion)))
    "Constants for message type 'SceneEntityDeletion"
  '((:MATCHING_ID . 0)
    (:ALL . 1))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SceneEntityDeletion>) ostream)
  "Serializes a message object of type '<SceneEntityDeletion>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'id))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SceneEntityDeletion>) istream)
  "Deserializes a message object of type '<SceneEntityDeletion>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SceneEntityDeletion>)))
  "Returns string type for a message object of type '<SceneEntityDeletion>"
  "foxglove_msgs/SceneEntityDeletion")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SceneEntityDeletion)))
  "Returns string type for a message object of type 'SceneEntityDeletion"
  "foxglove_msgs/SceneEntityDeletion")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SceneEntityDeletion>)))
  "Returns md5sum for a message object of type '<SceneEntityDeletion>"
  "bf62b4d6dc69e291c6322fca1d751d4c")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SceneEntityDeletion)))
  "Returns md5sum for a message object of type 'SceneEntityDeletion"
  "bf62b4d6dc69e291c6322fca1d751d4c")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SceneEntityDeletion>)))
  "Returns full string definition for message of type '<SceneEntityDeletion>"
  (cl:format cl:nil "# foxglove_msgs/SceneEntityDeletion~%# Command to remove previously published entities~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the deletion. Only matching entities earlier than this timestamp will be deleted.~%time timestamp~%~%# Delete the existing entity on the same topic that has the provided `id`~%uint8 MATCHING_ID=0~%~%# Delete all existing entities on the same topic~%uint8 ALL=1~%~%# Type of deletion action to perform~%uint8 type~%~%# Identifier which must match if `type` is `MATCHING_ID`.~%string id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SceneEntityDeletion)))
  "Returns full string definition for message of type 'SceneEntityDeletion"
  (cl:format cl:nil "# foxglove_msgs/SceneEntityDeletion~%# Command to remove previously published entities~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of the deletion. Only matching entities earlier than this timestamp will be deleted.~%time timestamp~%~%# Delete the existing entity on the same topic that has the provided `id`~%uint8 MATCHING_ID=0~%~%# Delete all existing entities on the same topic~%uint8 ALL=1~%~%# Type of deletion action to perform~%uint8 type~%~%# Identifier which must match if `type` is `MATCHING_ID`.~%string id~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SceneEntityDeletion>))
  (cl:+ 0
     8
     1
     4 (cl:length (cl:slot-value msg 'id))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SceneEntityDeletion>))
  "Converts a ROS message object to a list"
  (cl:list 'SceneEntityDeletion
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':type (type msg))
    (cl:cons ':id (id msg))
))
