(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          LEVEL-VAL
          LEVEL
          MESSAGE-VAL
          MESSAGE
          NAME-VAL
          NAME
          FILE-VAL
          FILE
          LINE-VAL
          LINE
))