(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          WIDTH-VAL
          WIDTH
          HEIGHT-VAL
          HEIGHT
          ENCODING-VAL
          ENCODING
          STEP-VAL
          STEP
          DATA-VAL
          DATA
))