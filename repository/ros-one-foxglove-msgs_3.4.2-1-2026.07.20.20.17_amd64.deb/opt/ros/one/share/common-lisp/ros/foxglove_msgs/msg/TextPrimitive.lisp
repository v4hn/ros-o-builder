; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude TextPrimitive.msg.html

(cl:defclass <TextPrimitive> (roslisp-msg-protocol:ros-message)
  ((pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (billboard
    :reader billboard
    :initarg :billboard
    :type cl:boolean
    :initform cl:nil)
   (font_size
    :reader font_size
    :initarg :font_size
    :type cl:float
    :initform 0.0)
   (scale_invariant
    :reader scale_invariant
    :initarg :scale_invariant
    :type cl:boolean
    :initform cl:nil)
   (color
    :reader color
    :initarg :color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (text
    :reader text
    :initarg :text
    :type cl:string
    :initform ""))
)

(cl:defclass TextPrimitive (<TextPrimitive>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TextPrimitive>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TextPrimitive)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<TextPrimitive> is deprecated: use foxglove_msgs-msg:TextPrimitive instead.")))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <TextPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'billboard-val :lambda-list '(m))
(cl:defmethod billboard-val ((m <TextPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:billboard-val is deprecated.  Use foxglove_msgs-msg:billboard instead.")
  (billboard m))

(cl:ensure-generic-function 'font_size-val :lambda-list '(m))
(cl:defmethod font_size-val ((m <TextPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:font_size-val is deprecated.  Use foxglove_msgs-msg:font_size instead.")
  (font_size m))

(cl:ensure-generic-function 'scale_invariant-val :lambda-list '(m))
(cl:defmethod scale_invariant-val ((m <TextPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:scale_invariant-val is deprecated.  Use foxglove_msgs-msg:scale_invariant instead.")
  (scale_invariant m))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <TextPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:color-val is deprecated.  Use foxglove_msgs-msg:color instead.")
  (color m))

(cl:ensure-generic-function 'text-val :lambda-list '(m))
(cl:defmethod text-val ((m <TextPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:text-val is deprecated.  Use foxglove_msgs-msg:text instead.")
  (text m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TextPrimitive>) ostream)
  "Serializes a message object of type '<TextPrimitive>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'billboard) 1 0)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'font_size))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'scale_invariant) 1 0)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'text))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'text))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TextPrimitive>) istream)
  "Deserializes a message object of type '<TextPrimitive>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:setf (cl:slot-value msg 'billboard) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'font_size) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:slot-value msg 'scale_invariant) (cl:not (cl:zerop (cl:read-byte istream))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'text) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'text) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TextPrimitive>)))
  "Returns string type for a message object of type '<TextPrimitive>"
  "foxglove_msgs/TextPrimitive")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TextPrimitive)))
  "Returns string type for a message object of type 'TextPrimitive"
  "foxglove_msgs/TextPrimitive")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TextPrimitive>)))
  "Returns md5sum for a message object of type '<TextPrimitive>"
  "bec1b8536471438a5b2697ab2d6c5ca1")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TextPrimitive)))
  "Returns md5sum for a message object of type 'TextPrimitive"
  "bec1b8536471438a5b2697ab2d6c5ca1")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TextPrimitive>)))
  "Returns full string definition for message of type '<TextPrimitive>"
  (cl:format cl:nil "# foxglove_msgs/TextPrimitive~%# A primitive representing a text label~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Position of the center of the text box and orientation of the text. Identity orientation means the text is oriented in the xy-plane and flows from -x to +x.~%geometry_msgs/Pose pose~%~%# Whether the text should respect `pose.orientation` (false) or always face the camera (true)~%bool billboard~%~%# Font size (height of one line of text)~%float64 font_size~%~%# Indicates whether `font_size` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)~%bool scale_invariant~%~%# Color of the text~%foxglove_msgs/Color color~%~%# Text~%string text~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TextPrimitive)))
  "Returns full string definition for message of type 'TextPrimitive"
  (cl:format cl:nil "# foxglove_msgs/TextPrimitive~%# A primitive representing a text label~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Position of the center of the text box and orientation of the text. Identity orientation means the text is oriented in the xy-plane and flows from -x to +x.~%geometry_msgs/Pose pose~%~%# Whether the text should respect `pose.orientation` (false) or always face the camera (true)~%bool billboard~%~%# Font size (height of one line of text)~%float64 font_size~%~%# Indicates whether `font_size` is a fixed size in screen pixels (true), or specified in world coordinates and scales with distance from the camera (false)~%bool scale_invariant~%~%# Color of the text~%foxglove_msgs/Color color~%~%# Text~%string text~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TextPrimitive>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     1
     8
     1
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
     4 (cl:length (cl:slot-value msg 'text))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TextPrimitive>))
  "Converts a ROS message object to a list"
  (cl:list 'TextPrimitive
    (cl:cons ':pose (pose msg))
    (cl:cons ':billboard (billboard msg))
    (cl:cons ':font_size (font_size msg))
    (cl:cons ':scale_invariant (scale_invariant msg))
    (cl:cons ':color (color msg))
    (cl:cons ':text (text msg))
))
