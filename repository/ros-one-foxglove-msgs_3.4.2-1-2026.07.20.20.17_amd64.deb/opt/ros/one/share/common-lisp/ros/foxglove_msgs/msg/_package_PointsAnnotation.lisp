(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          TYPE-VAL
          TYPE
          POINTS-VAL
          POINTS
          OUTLINE_COLOR-VAL
          OUTLINE_COLOR
          OUTLINE_COLORS-VAL
          OUTLINE_COLORS
          FILL_COLOR-VAL
          FILL_COLOR
          THICKNESS-VAL
          THICKNESS
          METADATA-VAL
          METADATA
))