(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          LATITUDE-VAL
          LATITUDE
          LONGITUDE-VAL
          LONGITUDE
          ALTITUDE-VAL
          ALTITUDE
          POSITION_COVARIANCE-VAL
          POSITION_COVARIANCE
          POSITION_COVARIANCE_TYPE-VAL
          POSITION_COVARIANCE_TYPE
          HEADING-VAL
          HEADING
          VELOCITY-VAL
          VELOCITY
          COLOR-VAL
          COLOR
          METADATA-VAL
          METADATA
))