(cl:in-package foxglove_msgs-msg)
(cl:export '(GEOJSON-VAL
          GEOJSON
))