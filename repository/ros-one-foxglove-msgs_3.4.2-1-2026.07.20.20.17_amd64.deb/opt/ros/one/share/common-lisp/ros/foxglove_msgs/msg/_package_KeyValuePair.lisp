(cl:in-package foxglove_msgs-msg)
(cl:export '(KEY-VAL
          KEY
          VALUE-VAL
          VALUE
))