(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          PARENT_FRAME_ID-VAL
          PARENT_FRAME_ID
          CHILD_FRAME_ID-VAL
          CHILD_FRAME_ID
          TRANSLATION-VAL
          TRANSLATION
          ROTATION-VAL
          ROTATION
))