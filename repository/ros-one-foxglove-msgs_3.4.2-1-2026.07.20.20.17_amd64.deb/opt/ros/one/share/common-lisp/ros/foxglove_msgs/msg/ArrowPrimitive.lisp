; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude ArrowPrimitive.msg.html

(cl:defclass <ArrowPrimitive> (roslisp-msg-protocol:ros-message)
  ((pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (shaft_length
    :reader shaft_length
    :initarg :shaft_length
    :type cl:float
    :initform 0.0)
   (shaft_diameter
    :reader shaft_diameter
    :initarg :shaft_diameter
    :type cl:float
    :initform 0.0)
   (head_length
    :reader head_length
    :initarg :head_length
    :type cl:float
    :initform 0.0)
   (head_diameter
    :reader head_diameter
    :initarg :head_diameter
    :type cl:float
    :initform 0.0)
   (color
    :reader color
    :initarg :color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color)))
)

(cl:defclass ArrowPrimitive (<ArrowPrimitive>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ArrowPrimitive>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ArrowPrimitive)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<ArrowPrimitive> is deprecated: use foxglove_msgs-msg:ArrowPrimitive instead.")))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <ArrowPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'shaft_length-val :lambda-list '(m))
(cl:defmethod shaft_length-val ((m <ArrowPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:shaft_length-val is deprecated.  Use foxglove_msgs-msg:shaft_length instead.")
  (shaft_length m))

(cl:ensure-generic-function 'shaft_diameter-val :lambda-list '(m))
(cl:defmethod shaft_diameter-val ((m <ArrowPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:shaft_diameter-val is deprecated.  Use foxglove_msgs-msg:shaft_diameter instead.")
  (shaft_diameter m))

(cl:ensure-generic-function 'head_length-val :lambda-list '(m))
(cl:defmethod head_length-val ((m <ArrowPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:head_length-val is deprecated.  Use foxglove_msgs-msg:head_length instead.")
  (head_length m))

(cl:ensure-generic-function 'head_diameter-val :lambda-list '(m))
(cl:defmethod head_diameter-val ((m <ArrowPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:head_diameter-val is deprecated.  Use foxglove_msgs-msg:head_diameter instead.")
  (head_diameter m))

(cl:ensure-generic-function 'color-val :lambda-list '(m))
(cl:defmethod color-val ((m <ArrowPrimitive>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:color-val is deprecated.  Use foxglove_msgs-msg:color instead.")
  (color m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ArrowPrimitive>) ostream)
  "Serializes a message object of type '<ArrowPrimitive>"
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'shaft_length))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'shaft_diameter))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'head_length))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'head_diameter))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'color) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ArrowPrimitive>) istream)
  "Deserializes a message object of type '<ArrowPrimitive>"
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'shaft_length) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'shaft_diameter) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'head_length) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'head_diameter) (roslisp-utils:decode-double-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'color) istream)
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ArrowPrimitive>)))
  "Returns string type for a message object of type '<ArrowPrimitive>"
  "foxglove_msgs/ArrowPrimitive")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ArrowPrimitive)))
  "Returns string type for a message object of type 'ArrowPrimitive"
  "foxglove_msgs/ArrowPrimitive")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ArrowPrimitive>)))
  "Returns md5sum for a message object of type '<ArrowPrimitive>"
  "77e318e0b3af1677ad44f4bc5480659a")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ArrowPrimitive)))
  "Returns md5sum for a message object of type 'ArrowPrimitive"
  "77e318e0b3af1677ad44f4bc5480659a")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ArrowPrimitive>)))
  "Returns full string definition for message of type '<ArrowPrimitive>"
  (cl:format cl:nil "# foxglove_msgs/ArrowPrimitive~%# A primitive representing an arrow~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Position of the arrow's tail and orientation of the arrow. Identity orientation means the arrow points in the +x direction.~%geometry_msgs/Pose pose~%~%# Length of the arrow shaft~%float64 shaft_length~%~%# Diameter of the arrow shaft~%float64 shaft_diameter~%~%# Length of the arrow head~%float64 head_length~%~%# Diameter of the arrow head~%float64 head_diameter~%~%# Color of the arrow~%foxglove_msgs/Color color~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ArrowPrimitive)))
  "Returns full string definition for message of type 'ArrowPrimitive"
  (cl:format cl:nil "# foxglove_msgs/ArrowPrimitive~%# A primitive representing an arrow~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Position of the arrow's tail and orientation of the arrow. Identity orientation means the arrow points in the +x direction.~%geometry_msgs/Pose pose~%~%# Length of the arrow shaft~%float64 shaft_length~%~%# Diameter of the arrow shaft~%float64 shaft_diameter~%~%# Length of the arrow head~%float64 head_length~%~%# Diameter of the arrow head~%float64 head_diameter~%~%# Color of the arrow~%foxglove_msgs/Color color~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ArrowPrimitive>))
  (cl:+ 0
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     8
     8
     8
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'color))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ArrowPrimitive>))
  "Converts a ROS message object to a list"
  (cl:list 'ArrowPrimitive
    (cl:cons ':pose (pose msg))
    (cl:cons ':shaft_length (shaft_length msg))
    (cl:cons ':shaft_diameter (shaft_diameter msg))
    (cl:cons ':head_length (head_length msg))
    (cl:cons ':head_diameter (head_diameter msg))
    (cl:cons ':color (color msg))
))
