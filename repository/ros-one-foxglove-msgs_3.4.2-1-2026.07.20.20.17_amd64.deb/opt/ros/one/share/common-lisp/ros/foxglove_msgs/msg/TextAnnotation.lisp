; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude TextAnnotation.msg.html

(cl:defclass <TextAnnotation> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (position
    :reader position
    :initarg :position
    :type foxglove_msgs-msg:Point2
    :initform (cl:make-instance 'foxglove_msgs-msg:Point2))
   (text
    :reader text
    :initarg :text
    :type cl:string
    :initform "")
   (font_size
    :reader font_size
    :initarg :font_size
    :type cl:float
    :initform 0.0)
   (text_color
    :reader text_color
    :initarg :text_color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (background_color
    :reader background_color
    :initarg :background_color
    :type foxglove_msgs-msg:Color
    :initform (cl:make-instance 'foxglove_msgs-msg:Color))
   (metadata
    :reader metadata
    :initarg :metadata
    :type (cl:vector foxglove_msgs-msg:KeyValuePair)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:KeyValuePair :initial-element (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))))
)

(cl:defclass TextAnnotation (<TextAnnotation>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <TextAnnotation>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'TextAnnotation)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<TextAnnotation> is deprecated: use foxglove_msgs-msg:TextAnnotation instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'position-val :lambda-list '(m))
(cl:defmethod position-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:position-val is deprecated.  Use foxglove_msgs-msg:position instead.")
  (position m))

(cl:ensure-generic-function 'text-val :lambda-list '(m))
(cl:defmethod text-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:text-val is deprecated.  Use foxglove_msgs-msg:text instead.")
  (text m))

(cl:ensure-generic-function 'font_size-val :lambda-list '(m))
(cl:defmethod font_size-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:font_size-val is deprecated.  Use foxglove_msgs-msg:font_size instead.")
  (font_size m))

(cl:ensure-generic-function 'text_color-val :lambda-list '(m))
(cl:defmethod text_color-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:text_color-val is deprecated.  Use foxglove_msgs-msg:text_color instead.")
  (text_color m))

(cl:ensure-generic-function 'background_color-val :lambda-list '(m))
(cl:defmethod background_color-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:background_color-val is deprecated.  Use foxglove_msgs-msg:background_color instead.")
  (background_color m))

(cl:ensure-generic-function 'metadata-val :lambda-list '(m))
(cl:defmethod metadata-val ((m <TextAnnotation>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:metadata-val is deprecated.  Use foxglove_msgs-msg:metadata instead.")
  (metadata m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <TextAnnotation>) ostream)
  "Serializes a message object of type '<TextAnnotation>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'position) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'text))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'text))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'font_size))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'text_color) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'background_color) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'metadata))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'metadata))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <TextAnnotation>) istream)
  "Deserializes a message object of type '<TextAnnotation>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'position) istream)
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'text) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'text) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'font_size) (roslisp-utils:decode-double-float-bits bits)))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'text_color) istream)
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'background_color) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'metadata) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'metadata)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:KeyValuePair))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<TextAnnotation>)))
  "Returns string type for a message object of type '<TextAnnotation>"
  "foxglove_msgs/TextAnnotation")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'TextAnnotation)))
  "Returns string type for a message object of type 'TextAnnotation"
  "foxglove_msgs/TextAnnotation")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<TextAnnotation>)))
  "Returns md5sum for a message object of type '<TextAnnotation>"
  "5c6a161e941136fa1fe44c232e2b7aa0")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'TextAnnotation)))
  "Returns md5sum for a message object of type 'TextAnnotation"
  "5c6a161e941136fa1fe44c232e2b7aa0")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<TextAnnotation>)))
  "Returns full string definition for message of type '<TextAnnotation>"
  (cl:format cl:nil "# foxglove_msgs/TextAnnotation~%# A text label on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Bottom-left origin of the text label in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Text to display~%string text~%~%# Font size in pixels~%float64 font_size~%~%# Text color~%foxglove_msgs/Color text_color~%~%# Background fill color~%foxglove_msgs/Color background_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'TextAnnotation)))
  "Returns full string definition for message of type 'TextAnnotation"
  (cl:format cl:nil "# foxglove_msgs/TextAnnotation~%# A text label on a 2D image~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of annotation~%time timestamp~%~%# Bottom-left origin of the text label in 2D image coordinates (pixels).~%# The coordinate uses the top-left corner of the top-left pixel of the image as the origin.~%foxglove_msgs/Point2 position~%~%# Text to display~%string text~%~%# Font size in pixels~%float64 font_size~%~%# Text color~%foxglove_msgs/Color text_color~%~%# Background fill color~%foxglove_msgs/Color background_color~%~%# Additional user-provided metadata associated with this annotation. Keys must be unique.~%foxglove_msgs/KeyValuePair[] metadata~%~%================================================================================~%MSG: foxglove_msgs/Point2~%# foxglove_msgs/Point2~%# A point representing a position in 2D space~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# x coordinate position~%float64 x~%~%# y coordinate position~%float64 y~%~%================================================================================~%MSG: foxglove_msgs/Color~%# foxglove_msgs/Color~%# A color in RGBA format~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Red value between 0 and 1~%float64 r~%~%# Green value between 0 and 1~%float64 g~%~%# Blue value between 0 and 1~%float64 b~%~%# Alpha value between 0 and 1~%float64 a~%~%================================================================================~%MSG: foxglove_msgs/KeyValuePair~%# foxglove_msgs/KeyValuePair~%# A key with its associated value~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Key~%string key~%~%# Value~%string value~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <TextAnnotation>))
  (cl:+ 0
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'position))
     4 (cl:length (cl:slot-value msg 'text))
     8
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'text_color))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'background_color))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'metadata) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <TextAnnotation>))
  "Converts a ROS message object to a list"
  (cl:list 'TextAnnotation
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':position (position msg))
    (cl:cons ':text (text msg))
    (cl:cons ':font_size (font_size msg))
    (cl:cons ':text_color (text_color msg))
    (cl:cons ':background_color (background_color msg))
    (cl:cons ':metadata (metadata msg))
))
