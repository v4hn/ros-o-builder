; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude VoxelGrid.msg.html

(cl:defclass <VoxelGrid> (roslisp-msg-protocol:ros-message)
  ((timestamp
    :reader timestamp
    :initarg :timestamp
    :type cl:real
    :initform 0)
   (frame_id
    :reader frame_id
    :initarg :frame_id
    :type cl:string
    :initform "")
   (pose
    :reader pose
    :initarg :pose
    :type geometry_msgs-msg:Pose
    :initform (cl:make-instance 'geometry_msgs-msg:Pose))
   (row_count
    :reader row_count
    :initarg :row_count
    :type cl:integer
    :initform 0)
   (column_count
    :reader column_count
    :initarg :column_count
    :type cl:integer
    :initform 0)
   (cell_size
    :reader cell_size
    :initarg :cell_size
    :type geometry_msgs-msg:Vector3
    :initform (cl:make-instance 'geometry_msgs-msg:Vector3))
   (slice_stride
    :reader slice_stride
    :initarg :slice_stride
    :type cl:integer
    :initform 0)
   (row_stride
    :reader row_stride
    :initarg :row_stride
    :type cl:integer
    :initform 0)
   (cell_stride
    :reader cell_stride
    :initarg :cell_stride
    :type cl:integer
    :initform 0)
   (fields
    :reader fields
    :initarg :fields
    :type (cl:vector foxglove_msgs-msg:PackedElementField)
   :initform (cl:make-array 0 :element-type 'foxglove_msgs-msg:PackedElementField :initial-element (cl:make-instance 'foxglove_msgs-msg:PackedElementField)))
   (data
    :reader data
    :initarg :data
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass VoxelGrid (<VoxelGrid>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <VoxelGrid>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'VoxelGrid)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<VoxelGrid> is deprecated: use foxglove_msgs-msg:VoxelGrid instead.")))

(cl:ensure-generic-function 'timestamp-val :lambda-list '(m))
(cl:defmethod timestamp-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:timestamp-val is deprecated.  Use foxglove_msgs-msg:timestamp instead.")
  (timestamp m))

(cl:ensure-generic-function 'frame_id-val :lambda-list '(m))
(cl:defmethod frame_id-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:frame_id-val is deprecated.  Use foxglove_msgs-msg:frame_id instead.")
  (frame_id m))

(cl:ensure-generic-function 'pose-val :lambda-list '(m))
(cl:defmethod pose-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:pose-val is deprecated.  Use foxglove_msgs-msg:pose instead.")
  (pose m))

(cl:ensure-generic-function 'row_count-val :lambda-list '(m))
(cl:defmethod row_count-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:row_count-val is deprecated.  Use foxglove_msgs-msg:row_count instead.")
  (row_count m))

(cl:ensure-generic-function 'column_count-val :lambda-list '(m))
(cl:defmethod column_count-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:column_count-val is deprecated.  Use foxglove_msgs-msg:column_count instead.")
  (column_count m))

(cl:ensure-generic-function 'cell_size-val :lambda-list '(m))
(cl:defmethod cell_size-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:cell_size-val is deprecated.  Use foxglove_msgs-msg:cell_size instead.")
  (cell_size m))

(cl:ensure-generic-function 'slice_stride-val :lambda-list '(m))
(cl:defmethod slice_stride-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:slice_stride-val is deprecated.  Use foxglove_msgs-msg:slice_stride instead.")
  (slice_stride m))

(cl:ensure-generic-function 'row_stride-val :lambda-list '(m))
(cl:defmethod row_stride-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:row_stride-val is deprecated.  Use foxglove_msgs-msg:row_stride instead.")
  (row_stride m))

(cl:ensure-generic-function 'cell_stride-val :lambda-list '(m))
(cl:defmethod cell_stride-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:cell_stride-val is deprecated.  Use foxglove_msgs-msg:cell_stride instead.")
  (cell_stride m))

(cl:ensure-generic-function 'fields-val :lambda-list '(m))
(cl:defmethod fields-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:fields-val is deprecated.  Use foxglove_msgs-msg:fields instead.")
  (fields m))

(cl:ensure-generic-function 'data-val :lambda-list '(m))
(cl:defmethod data-val ((m <VoxelGrid>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:data-val is deprecated.  Use foxglove_msgs-msg:data instead.")
  (data m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <VoxelGrid>) ostream)
  "Serializes a message object of type '<VoxelGrid>"
  (cl:let ((__sec (cl:floor (cl:slot-value msg 'timestamp)))
        (__nsec (cl:round (cl:* 1e9 (cl:- (cl:slot-value msg 'timestamp) (cl:floor (cl:slot-value msg 'timestamp)))))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __sec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 0) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __nsec) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __nsec) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'frame_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'frame_id))
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'pose) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'row_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'row_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'row_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'row_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'column_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'column_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'column_count)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'column_count)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'cell_size) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'slice_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'slice_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'slice_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'slice_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'row_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'row_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'row_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'row_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cell_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'cell_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'cell_stride)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'cell_stride)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'fields))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'fields))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'data))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'data))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <VoxelGrid>) istream)
  "Deserializes a message object of type '<VoxelGrid>"
    (cl:let ((__sec 0) (__nsec 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __sec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 0) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __nsec) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __nsec) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'timestamp) (cl:+ (cl:coerce __sec 'cl:double-float) (cl:/ __nsec 1e9))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frame_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'frame_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'pose) istream)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'row_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'row_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'row_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'row_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'column_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'column_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'column_count)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'column_count)) (cl:read-byte istream))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'cell_size) istream)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'slice_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'slice_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'slice_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'slice_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'row_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'row_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'row_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'row_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'cell_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'cell_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'cell_stride)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'cell_stride)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'fields) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'fields)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'foxglove_msgs-msg:PackedElementField))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'data) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'data)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<VoxelGrid>)))
  "Returns string type for a message object of type '<VoxelGrid>"
  "foxglove_msgs/VoxelGrid")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'VoxelGrid)))
  "Returns string type for a message object of type 'VoxelGrid"
  "foxglove_msgs/VoxelGrid")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<VoxelGrid>)))
  "Returns md5sum for a message object of type '<VoxelGrid>"
  "3dd4034cf3096d2a0d33d0a78d5624c9")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'VoxelGrid)))
  "Returns md5sum for a message object of type 'VoxelGrid"
  "3dd4034cf3096d2a0d33d0a78d5624c9")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<VoxelGrid>)))
  "Returns full string definition for message of type '<VoxelGrid>"
  (cl:format cl:nil "# foxglove_msgs/VoxelGrid~%# A 3D grid of data~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of grid~%time timestamp~%~%# Frame of reference~%string frame_id~%~%# Origin of the grid’s lower-front-left corner in the reference frame. The grid’s pose is defined relative to this corner, so an untransformed grid with an identity orientation has this corner at the origin.~%geometry_msgs/Pose pose~%~%# Number of grid rows~%uint32 row_count~%~%# Number of grid columns~%uint32 column_count~%~%# Size of single grid cell along x, y, and z axes, relative to `pose`~%geometry_msgs/Vector3 cell_size~%~%# Number of bytes between depth slices in `data`~%uint32 slice_stride~%~%# Number of bytes between rows in `data`~%uint32 row_stride~%~%# Number of bytes between cells within a row in `data`~%uint32 cell_stride~%~%# Fields in `data`. `red`, `green`, `blue`, and `alpha` are optional for customizing the grid's color.~%foxglove_msgs/PackedElementField[] fields~%~%# Grid cell data, interpreted using `fields`, in depth-major, row-major (Z-Y-X) order.~%# For the data element starting at byte offset i, the coordinates of its corner closest to the origin will be:~%# ~%# - z = i / slice_stride * cell_size.z~%# - y = (i % slice_stride) / row_stride * cell_size.y~%# - x = (i % row_stride) / cell_stride * cell_size.x~%uint8[] data~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: foxglove_msgs/PackedElementField~%# foxglove_msgs/PackedElementField~%# A field present within each element in a byte array of packed elements.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Name of the field~%string name~%~%# Byte offset from start of data buffer~%uint32 offset~%~%# Unknown numeric type~%uint8 UNKNOWN=0~%~%# Unsigned 8-bit integer~%uint8 UINT8=1~%~%# Signed 8-bit integer~%uint8 INT8=2~%~%# Unsigned 16-bit integer~%uint8 UINT16=3~%~%# Signed 16-bit integer~%uint8 INT16=4~%~%# Unsigned 32-bit integer~%uint8 UINT32=5~%~%# Signed 32-bit integer~%uint8 INT32=6~%~%# 32-bit floating-point number~%uint8 FLOAT32=7~%~%# 64-bit floating-point number~%uint8 FLOAT64=8~%~%# Type of data in the field. Integers are stored using little-endian byte order.~%uint8 type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'VoxelGrid)))
  "Returns full string definition for message of type 'VoxelGrid"
  (cl:format cl:nil "# foxglove_msgs/VoxelGrid~%# A 3D grid of data~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Timestamp of grid~%time timestamp~%~%# Frame of reference~%string frame_id~%~%# Origin of the grid’s lower-front-left corner in the reference frame. The grid’s pose is defined relative to this corner, so an untransformed grid with an identity orientation has this corner at the origin.~%geometry_msgs/Pose pose~%~%# Number of grid rows~%uint32 row_count~%~%# Number of grid columns~%uint32 column_count~%~%# Size of single grid cell along x, y, and z axes, relative to `pose`~%geometry_msgs/Vector3 cell_size~%~%# Number of bytes between depth slices in `data`~%uint32 slice_stride~%~%# Number of bytes between rows in `data`~%uint32 row_stride~%~%# Number of bytes between cells within a row in `data`~%uint32 cell_stride~%~%# Fields in `data`. `red`, `green`, `blue`, and `alpha` are optional for customizing the grid's color.~%foxglove_msgs/PackedElementField[] fields~%~%# Grid cell data, interpreted using `fields`, in depth-major, row-major (Z-Y-X) order.~%# For the data element starting at byte offset i, the coordinates of its corner closest to the origin will be:~%# ~%# - z = i / slice_stride * cell_size.z~%# - y = (i % slice_stride) / row_stride * cell_size.y~%# - x = (i % row_stride) / cell_stride * cell_size.x~%uint8[] data~%~%================================================================================~%MSG: geometry_msgs/Pose~%# A representation of pose in free space, composed of position and orientation. ~%Point position~%Quaternion orientation~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Quaternion~%# This represents an orientation in free space in quaternion form.~%~%float64 x~%float64 y~%float64 z~%float64 w~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%================================================================================~%MSG: foxglove_msgs/PackedElementField~%# foxglove_msgs/PackedElementField~%# A field present within each element in a byte array of packed elements.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Name of the field~%string name~%~%# Byte offset from start of data buffer~%uint32 offset~%~%# Unknown numeric type~%uint8 UNKNOWN=0~%~%# Unsigned 8-bit integer~%uint8 UINT8=1~%~%# Signed 8-bit integer~%uint8 INT8=2~%~%# Unsigned 16-bit integer~%uint8 UINT16=3~%~%# Signed 16-bit integer~%uint8 INT16=4~%~%# Unsigned 32-bit integer~%uint8 UINT32=5~%~%# Signed 32-bit integer~%uint8 INT32=6~%~%# 32-bit floating-point number~%uint8 FLOAT32=7~%~%# 64-bit floating-point number~%uint8 FLOAT64=8~%~%# Type of data in the field. Integers are stored using little-endian byte order.~%uint8 type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <VoxelGrid>))
  (cl:+ 0
     8
     4 (cl:length (cl:slot-value msg 'frame_id))
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'pose))
     4
     4
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'cell_size))
     4
     4
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'fields) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'data) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <VoxelGrid>))
  "Converts a ROS message object to a list"
  (cl:list 'VoxelGrid
    (cl:cons ':timestamp (timestamp msg))
    (cl:cons ':frame_id (frame_id msg))
    (cl:cons ':pose (pose msg))
    (cl:cons ':row_count (row_count msg))
    (cl:cons ':column_count (column_count msg))
    (cl:cons ':cell_size (cell_size msg))
    (cl:cons ':slice_stride (slice_stride msg))
    (cl:cons ':row_stride (row_stride msg))
    (cl:cons ':cell_stride (cell_stride msg))
    (cl:cons ':fields (fields msg))
    (cl:cons ':data (data msg))
))
