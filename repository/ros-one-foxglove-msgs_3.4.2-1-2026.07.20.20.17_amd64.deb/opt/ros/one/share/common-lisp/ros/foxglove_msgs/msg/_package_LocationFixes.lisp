(cl:in-package foxglove_msgs-msg)
(cl:export '(FIXES-VAL
          FIXES
))