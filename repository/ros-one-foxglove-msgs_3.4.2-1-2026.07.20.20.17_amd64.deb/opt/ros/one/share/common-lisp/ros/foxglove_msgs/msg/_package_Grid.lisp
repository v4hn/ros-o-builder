(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          POSE-VAL
          POSE
          COLUMN_COUNT-VAL
          COLUMN_COUNT
          CELL_SIZE-VAL
          CELL_SIZE
          ROW_STRIDE-VAL
          ROW_STRIDE
          CELL_STRIDE-VAL
          CELL_STRIDE
          FIELDS-VAL
          FIELDS
          DATA-VAL
          DATA
))