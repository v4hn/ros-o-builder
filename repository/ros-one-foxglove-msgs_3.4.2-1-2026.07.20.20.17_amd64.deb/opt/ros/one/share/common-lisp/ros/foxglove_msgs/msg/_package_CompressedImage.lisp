(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          DATA-VAL
          DATA
          FORMAT-VAL
          FORMAT
))