; Auto-generated. Do not edit!


(cl:in-package foxglove_msgs-msg)


;//! \htmlinclude PackedElementField.msg.html

(cl:defclass <PackedElementField> (roslisp-msg-protocol:ros-message)
  ((name
    :reader name
    :initarg :name
    :type cl:string
    :initform "")
   (offset
    :reader offset
    :initarg :offset
    :type cl:integer
    :initform 0)
   (type
    :reader type
    :initarg :type
    :type cl:fixnum
    :initform 0))
)

(cl:defclass PackedElementField (<PackedElementField>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <PackedElementField>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'PackedElementField)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name foxglove_msgs-msg:<PackedElementField> is deprecated: use foxglove_msgs-msg:PackedElementField instead.")))

(cl:ensure-generic-function 'name-val :lambda-list '(m))
(cl:defmethod name-val ((m <PackedElementField>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:name-val is deprecated.  Use foxglove_msgs-msg:name instead.")
  (name m))

(cl:ensure-generic-function 'offset-val :lambda-list '(m))
(cl:defmethod offset-val ((m <PackedElementField>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:offset-val is deprecated.  Use foxglove_msgs-msg:offset instead.")
  (offset m))

(cl:ensure-generic-function 'type-val :lambda-list '(m))
(cl:defmethod type-val ((m <PackedElementField>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader foxglove_msgs-msg:type-val is deprecated.  Use foxglove_msgs-msg:type instead.")
  (type m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<PackedElementField>)))
    "Constants for message type '<PackedElementField>"
  '((:UNKNOWN . 0)
    (:UINT8 . 1)
    (:INT8 . 2)
    (:UINT16 . 3)
    (:INT16 . 4)
    (:UINT32 . 5)
    (:INT32 . 6)
    (:FLOAT32 . 7)
    (:FLOAT64 . 8))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'PackedElementField)))
    "Constants for message type 'PackedElementField"
  '((:UNKNOWN . 0)
    (:UINT8 . 1)
    (:INT8 . 2)
    (:UINT16 . 3)
    (:INT16 . 4)
    (:UINT32 . 5)
    (:INT32 . 6)
    (:FLOAT32 . 7)
    (:FLOAT64 . 8))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <PackedElementField>) ostream)
  "Serializes a message object of type '<PackedElementField>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'name))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'offset)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'offset)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'offset)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'offset)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <PackedElementField>) istream)
  "Deserializes a message object of type '<PackedElementField>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'offset)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'offset)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'offset)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'offset)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'type)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<PackedElementField>)))
  "Returns string type for a message object of type '<PackedElementField>"
  "foxglove_msgs/PackedElementField")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'PackedElementField)))
  "Returns string type for a message object of type 'PackedElementField"
  "foxglove_msgs/PackedElementField")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<PackedElementField>)))
  "Returns md5sum for a message object of type '<PackedElementField>"
  "df41f15dfb434e3b15eedc0c7e914a83")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'PackedElementField)))
  "Returns md5sum for a message object of type 'PackedElementField"
  "df41f15dfb434e3b15eedc0c7e914a83")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<PackedElementField>)))
  "Returns full string definition for message of type '<PackedElementField>"
  (cl:format cl:nil "# foxglove_msgs/PackedElementField~%# A field present within each element in a byte array of packed elements.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Name of the field~%string name~%~%# Byte offset from start of data buffer~%uint32 offset~%~%# Unknown numeric type~%uint8 UNKNOWN=0~%~%# Unsigned 8-bit integer~%uint8 UINT8=1~%~%# Signed 8-bit integer~%uint8 INT8=2~%~%# Unsigned 16-bit integer~%uint8 UINT16=3~%~%# Signed 16-bit integer~%uint8 INT16=4~%~%# Unsigned 32-bit integer~%uint8 UINT32=5~%~%# Signed 32-bit integer~%uint8 INT32=6~%~%# 32-bit floating-point number~%uint8 FLOAT32=7~%~%# 64-bit floating-point number~%uint8 FLOAT64=8~%~%# Type of data in the field. Integers are stored using little-endian byte order.~%uint8 type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'PackedElementField)))
  "Returns full string definition for message of type 'PackedElementField"
  (cl:format cl:nil "# foxglove_msgs/PackedElementField~%# A field present within each element in a byte array of packed elements.~%~%# Generated by https://github.com/foxglove/foxglove-sdk~%~%# Name of the field~%string name~%~%# Byte offset from start of data buffer~%uint32 offset~%~%# Unknown numeric type~%uint8 UNKNOWN=0~%~%# Unsigned 8-bit integer~%uint8 UINT8=1~%~%# Signed 8-bit integer~%uint8 INT8=2~%~%# Unsigned 16-bit integer~%uint8 UINT16=3~%~%# Signed 16-bit integer~%uint8 INT16=4~%~%# Unsigned 32-bit integer~%uint8 UINT32=5~%~%# Signed 32-bit integer~%uint8 INT32=6~%~%# 32-bit floating-point number~%uint8 FLOAT32=7~%~%# 64-bit floating-point number~%uint8 FLOAT64=8~%~%# Type of data in the field. Integers are stored using little-endian byte order.~%uint8 type~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <PackedElementField>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'name))
     4
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <PackedElementField>))
  "Converts a ROS message object to a list"
  (cl:list 'PackedElementField
    (cl:cons ':name (name msg))
    (cl:cons ':offset (offset msg))
    (cl:cons ':type (type msg))
))
