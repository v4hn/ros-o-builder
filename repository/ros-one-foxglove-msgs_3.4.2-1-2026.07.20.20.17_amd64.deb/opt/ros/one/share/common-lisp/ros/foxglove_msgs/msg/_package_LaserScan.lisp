(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          FRAME_ID-VAL
          FRAME_ID
          POSE-VAL
          POSE
          START_ANGLE-VAL
          START_ANGLE
          END_ANGLE-VAL
          END_ANGLE
          RANGES-VAL
          RANGES
          INTENSITIES-VAL
          INTENSITIES
))