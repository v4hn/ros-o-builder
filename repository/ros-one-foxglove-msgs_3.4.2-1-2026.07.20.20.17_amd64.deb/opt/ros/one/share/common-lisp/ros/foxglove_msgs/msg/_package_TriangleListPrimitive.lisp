(cl:in-package foxglove_msgs-msg)
(cl:export '(POSE-VAL
          POSE
          POINTS-VAL
          POINTS
          COLOR-VAL
          COLOR
          COLORS-VAL
          COLORS
          INDICES-VAL
          INDICES
))