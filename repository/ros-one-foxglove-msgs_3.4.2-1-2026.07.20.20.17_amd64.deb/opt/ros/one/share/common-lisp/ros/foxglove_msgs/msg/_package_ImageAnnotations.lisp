(cl:in-package foxglove_msgs-msg)
(cl:export '(TIMESTAMP-VAL
          TIMESTAMP
          CIRCLES-VAL
          CIRCLES
          POINTS-VAL
          POINTS
          TEXTS-VAL
          TEXTS
          METADATA-VAL
          METADATA
))