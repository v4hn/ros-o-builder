# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${foxglove_msgs_DIR}/.." "msg" foxglove_msgs_MSG_INCLUDE_DIRS UNIQUE)
set(foxglove_msgs_MSG_DEPENDENCIES geometry_msgs)
