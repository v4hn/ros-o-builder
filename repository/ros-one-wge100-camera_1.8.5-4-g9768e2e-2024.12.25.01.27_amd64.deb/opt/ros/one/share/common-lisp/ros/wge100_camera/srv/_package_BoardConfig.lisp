(cl:in-package wge100_camera-srv)
(cl:export '(SERIAL-VAL
          SERIAL
          MAC-VAL
          MAC
          SUCCESS-VAL
          SUCCESS
))