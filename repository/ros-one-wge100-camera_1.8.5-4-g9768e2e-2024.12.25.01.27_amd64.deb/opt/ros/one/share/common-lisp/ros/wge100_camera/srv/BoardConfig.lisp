; Auto-generated. Do not edit!


(cl:in-package wge100_camera-srv)


;//! \htmlinclude BoardConfig-request.msg.html

(cl:defclass <BoardConfig-request> (roslisp-msg-protocol:ros-message)
  ((serial
    :reader serial
    :initarg :serial
    :type cl:integer
    :initform 0)
   (mac
    :reader mac
    :initarg :mac
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0)))
)

(cl:defclass BoardConfig-request (<BoardConfig-request>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <BoardConfig-request>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'BoardConfig-request)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name wge100_camera-srv:<BoardConfig-request> is deprecated: use wge100_camera-srv:BoardConfig-request instead.")))

(cl:ensure-generic-function 'serial-val :lambda-list '(m))
(cl:defmethod serial-val ((m <BoardConfig-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wge100_camera-srv:serial-val is deprecated.  Use wge100_camera-srv:serial instead.")
  (serial m))

(cl:ensure-generic-function 'mac-val :lambda-list '(m))
(cl:defmethod mac-val ((m <BoardConfig-request>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wge100_camera-srv:mac-val is deprecated.  Use wge100_camera-srv:mac instead.")
  (mac m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <BoardConfig-request>) ostream)
  "Serializes a message object of type '<BoardConfig-request>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'serial)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'serial)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'serial)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'serial)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'mac))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'mac))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <BoardConfig-request>) istream)
  "Deserializes a message object of type '<BoardConfig-request>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'serial)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'serial)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'serial)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'serial)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'mac) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'mac)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<BoardConfig-request>)))
  "Returns string type for a service object of type '<BoardConfig-request>"
  "wge100_camera/BoardConfigRequest")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'BoardConfig-request)))
  "Returns string type for a service object of type 'BoardConfig-request"
  "wge100_camera/BoardConfigRequest")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<BoardConfig-request>)))
  "Returns md5sum for a message object of type '<BoardConfig-request>"
  "785c6974990d2659ed40a68807b3f3bd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'BoardConfig-request)))
  "Returns md5sum for a message object of type 'BoardConfig-request"
  "785c6974990d2659ed40a68807b3f3bd")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<BoardConfig-request>)))
  "Returns full string definition for message of type '<BoardConfig-request>"
  (cl:format cl:nil "# Used to configure a camera's MAC address and serial number. This is a~%# one-time only operation for a camera.~%uint32 serial # Serial number~%uint8[] mac # MAC address, should be 6 bytes long~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'BoardConfig-request)))
  "Returns full string definition for message of type 'BoardConfig-request"
  (cl:format cl:nil "# Used to configure a camera's MAC address and serial number. This is a~%# one-time only operation for a camera.~%uint32 serial # Serial number~%uint8[] mac # MAC address, should be 6 bytes long~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <BoardConfig-request>))
  (cl:+ 0
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'mac) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <BoardConfig-request>))
  "Converts a ROS message object to a list"
  (cl:list 'BoardConfig-request
    (cl:cons ':serial (serial msg))
    (cl:cons ':mac (mac msg))
))
;//! \htmlinclude BoardConfig-response.msg.html

(cl:defclass <BoardConfig-response> (roslisp-msg-protocol:ros-message)
  ((success
    :reader success
    :initarg :success
    :type cl:fixnum
    :initform 0))
)

(cl:defclass BoardConfig-response (<BoardConfig-response>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <BoardConfig-response>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'BoardConfig-response)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name wge100_camera-srv:<BoardConfig-response> is deprecated: use wge100_camera-srv:BoardConfig-response instead.")))

(cl:ensure-generic-function 'success-val :lambda-list '(m))
(cl:defmethod success-val ((m <BoardConfig-response>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader wge100_camera-srv:success-val is deprecated.  Use wge100_camera-srv:success instead.")
  (success m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <BoardConfig-response>) ostream)
  "Serializes a message object of type '<BoardConfig-response>"
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'success)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <BoardConfig-response>) istream)
  "Deserializes a message object of type '<BoardConfig-response>"
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'success)) (cl:read-byte istream))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<BoardConfig-response>)))
  "Returns string type for a service object of type '<BoardConfig-response>"
  "wge100_camera/BoardConfigResponse")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'BoardConfig-response)))
  "Returns string type for a service object of type 'BoardConfig-response"
  "wge100_camera/BoardConfigResponse")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<BoardConfig-response>)))
  "Returns md5sum for a message object of type '<BoardConfig-response>"
  "785c6974990d2659ed40a68807b3f3bd")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'BoardConfig-response)))
  "Returns md5sum for a message object of type 'BoardConfig-response"
  "785c6974990d2659ed40a68807b3f3bd")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<BoardConfig-response>)))
  "Returns full string definition for message of type '<BoardConfig-response>"
  (cl:format cl:nil "uint8 success # 1 means success, 0 means failure~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'BoardConfig-response)))
  "Returns full string definition for message of type 'BoardConfig-response"
  (cl:format cl:nil "uint8 success # 1 means success, 0 means failure~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <BoardConfig-response>))
  (cl:+ 0
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <BoardConfig-response>))
  "Converts a ROS message object to a list"
  (cl:list 'BoardConfig-response
    (cl:cons ':success (success msg))
))
(cl:defmethod roslisp-msg-protocol:service-request-type ((msg (cl:eql 'BoardConfig)))
  'BoardConfig-request)
(cl:defmethod roslisp-msg-protocol:service-response-type ((msg (cl:eql 'BoardConfig)))
  'BoardConfig-response)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'BoardConfig)))
  "Returns string type for a service object of type '<BoardConfig>"
  "wge100_camera/BoardConfig")