
"use strict";

let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');
let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');

module.exports = {
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorGoal: FaceDetectorGoal,
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
};
