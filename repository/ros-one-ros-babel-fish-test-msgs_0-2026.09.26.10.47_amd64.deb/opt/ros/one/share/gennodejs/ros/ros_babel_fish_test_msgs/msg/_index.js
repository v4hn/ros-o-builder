
"use strict";

let TestMessage = require('./TestMessage.js');
let TestSubArray = require('./TestSubArray.js');
let TestArray = require('./TestArray.js');
let SimpleTestAction = require('./SimpleTestAction.js');
let SimpleTestGoal = require('./SimpleTestGoal.js');
let SimpleTestActionGoal = require('./SimpleTestActionGoal.js');
let SimpleTestFeedback = require('./SimpleTestFeedback.js');
let SimpleTestActionResult = require('./SimpleTestActionResult.js');
let SimpleTestActionFeedback = require('./SimpleTestActionFeedback.js');
let SimpleTestResult = require('./SimpleTestResult.js');

module.exports = {
  TestMessage: TestMessage,
  TestSubArray: TestSubArray,
  TestArray: TestArray,
  SimpleTestAction: SimpleTestAction,
  SimpleTestGoal: SimpleTestGoal,
  SimpleTestActionGoal: SimpleTestActionGoal,
  SimpleTestFeedback: SimpleTestFeedback,
  SimpleTestActionResult: SimpleTestActionResult,
  SimpleTestActionFeedback: SimpleTestActionFeedback,
  SimpleTestResult: SimpleTestResult,
};
