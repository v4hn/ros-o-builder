(cl:defpackage voice_text-srv
  (:use )
  (:export
   "TEXTTOSPEECH"
   "<TEXTTOSPEECH-REQUEST>"
   "TEXTTOSPEECH-REQUEST"
   "<TEXTTOSPEECH-RESPONSE>"
   "TEXTTOSPEECH-RESPONSE"
  ))

