# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${voice_text_DIR}/.." "" voice_text_MSG_INCLUDE_DIRS UNIQUE)
set(voice_text_MSG_DEPENDENCIES )
