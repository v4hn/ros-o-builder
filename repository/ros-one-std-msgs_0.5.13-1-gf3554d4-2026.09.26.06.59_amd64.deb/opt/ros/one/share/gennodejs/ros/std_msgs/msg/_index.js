
"use strict";

let Empty = require('./Empty.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let UInt8 = require('./UInt8.js');
let Int8 = require('./Int8.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Float64 = require('./Float64.js');
let Header = require('./Header.js');
let Bool = require('./Bool.js');
let Duration = require('./Duration.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let UInt64 = require('./UInt64.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let UInt8MultiArray = require('./UInt8MultiArray.js');
let Int32 = require('./Int32.js');
let UInt16 = require('./UInt16.js');
let String = require('./String.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Int16 = require('./Int16.js');
let UInt32 = require('./UInt32.js');
let Char = require('./Char.js');
let ColorRGBA = require('./ColorRGBA.js');
let Time = require('./Time.js');
let Byte = require('./Byte.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let Float64MultiArray = require('./Float64MultiArray.js');
let Float32 = require('./Float32.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let Int64 = require('./Int64.js');

module.exports = {
  Empty: Empty,
  ByteMultiArray: ByteMultiArray,
  UInt8: UInt8,
  Int8: Int8,
  Float32MultiArray: Float32MultiArray,
  UInt32MultiArray: UInt32MultiArray,
  Float64: Float64,
  Header: Header,
  Bool: Bool,
  Duration: Duration,
  UInt64MultiArray: UInt64MultiArray,
  Int64MultiArray: Int64MultiArray,
  Int8MultiArray: Int8MultiArray,
  UInt64: UInt64,
  UInt16MultiArray: UInt16MultiArray,
  UInt8MultiArray: UInt8MultiArray,
  Int32: Int32,
  UInt16: UInt16,
  String: String,
  MultiArrayDimension: MultiArrayDimension,
  Int16: Int16,
  UInt32: UInt32,
  Char: Char,
  ColorRGBA: ColorRGBA,
  Time: Time,
  Byte: Byte,
  Int16MultiArray: Int16MultiArray,
  Int32MultiArray: Int32MultiArray,
  Float64MultiArray: Float64MultiArray,
  Float32: Float32,
  MultiArrayLayout: MultiArrayLayout,
  Int64: Int64,
};
