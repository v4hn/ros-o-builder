
"use strict";

let TouchEvent = require('./TouchEvent.js');
let DeviceSensor = require('./DeviceSensor.js');
let Tablet = require('./Tablet.js');
let VoiceMessage = require('./VoiceMessage.js');
let Gravity = require('./Gravity.js');
let MultiTouch = require('./MultiTouch.js');
let Touch = require('./Touch.js');
let AndroidSensor = require('./AndroidSensor.js');
let MagneticField = require('./MagneticField.js');
let Action = require('./Action.js');
let SlackMessage = require('./SlackMessage.js');

module.exports = {
  TouchEvent: TouchEvent,
  DeviceSensor: DeviceSensor,
  Tablet: Tablet,
  VoiceMessage: VoiceMessage,
  Gravity: Gravity,
  MultiTouch: MultiTouch,
  Touch: Touch,
  AndroidSensor: AndroidSensor,
  MagneticField: MagneticField,
  Action: Action,
  SlackMessage: SlackMessage,
};
