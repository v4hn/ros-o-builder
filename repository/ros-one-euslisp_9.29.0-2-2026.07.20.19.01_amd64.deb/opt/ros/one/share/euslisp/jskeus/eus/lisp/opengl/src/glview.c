/* ./glview.c :  entry=glview */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "glview.h"
#pragma init (register_glview)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___glview();
extern pointer build_quote_vector();
static int register_glview()
  { add_module_initializer("___glview", ___glview);}

static pointer glviewF139geometry__default_viewsurface();
static pointer glviewF140resetperspective();
static pointer glviewF141gldraw();
static pointer glviewF142swapb();
static pointer glviewF143position_light();

/*:create*/
static pointer glviewM144colormaterial_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[0], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto glviewKEY146;
	local[0] = NIL;
glviewKEY146:
	if (n & (1<<1)) goto glviewKEY147;
	local[8]= makeflt(2.9999999999999982236432e-01);
	local[9]= makeflt(5.0000000000000000000000e-01);
	local[10]= makeflt(6.9999999999999973354647e-01);
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(pointer)MKFLTVEC(ctx,4,local+8); /*float-vector*/
	local[1] = w;
glviewKEY147:
	if (n & (1<<2)) goto glviewKEY148;
	local[8]= makeflt(9.9999999999999977795540e-02);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[2] = w;
glviewKEY148:
	if (n & (1<<3)) goto glviewKEY149;
	local[8]= makeflt(1.0000000000000000000000e+00);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[3] = w;
glviewKEY149:
	if (n & (1<<4)) goto glviewKEY150;
	local[8]= makeflt(1.9999999999999995559108e-01);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[4] = w;
glviewKEY150:
	if (n & (1<<5)) goto glviewKEY151;
	local[8]= makeflt(9.9999999999999977795540e-02);
	local[9]= local[3];
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[5] = w;
glviewKEY151:
	if (n & (1<<6)) goto glviewKEY152;
	local[6] = makeflt(2.0000000000000000000000e+01);
glviewKEY152:
	if (n & (1<<7)) goto glviewKEY153;
	local[7] = makeflt(0.0000000000000000000000e+00);
glviewKEY153:
	if (local[0]==NIL) goto glviewIF154;
	local[8]= argv[0];
	local[9]= fqv[1];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= w;
	goto glviewIF155;
glviewIF154:
	local[8]= NIL;
glviewIF155:
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)COPYSEQ(ctx,1,local+8); /*copy-seq*/
	argv[0]->c.obj.iv[2] = w;
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)COPYSEQ(ctx,1,local+8); /*copy-seq*/
	argv[0]->c.obj.iv[3] = w;
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)COPYSEQ(ctx,1,local+8); /*copy-seq*/
	argv[0]->c.obj.iv[4] = w;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)COPYSEQ(ctx,1,local+8); /*copy-seq*/
	argv[0]->c.obj.iv[5] = w;
	argv[0]->c.obj.iv[6] = local[6];
	argv[0]->c.obj.iv[7] = local[7];
	w = argv[0];
	local[0]= w;
glviewBLK145:
	ctx->vsp=local; return(local[0]);}

/*:ambient*/
static pointer glviewM156colormaterial_ambient(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT162;}
	local[0]= NIL;
glviewENT162:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT161;}
	local[1]= local[0];
glviewENT161:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT160;}
	local[2]= local[0];
glviewENT160:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT159;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT159:
glviewENT158:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON164;
	local[4]= argv[0]->c.obj.iv[2];
	goto glviewCON163;
glviewCON164:
	w = local[0];
	if (!numberp(w)) goto glviewCON165;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[2] = w;
	local[4]= argv[0]->c.obj.iv[2];
	goto glviewCON163;
glviewCON165:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON166;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[2] = w;
	local[4]= argv[0]->c.obj.iv[2];
	goto glviewCON163;
glviewCON166:
	local[4]= fqv[3];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON163;
glviewCON167:
	local[4]= NIL;
glviewCON163:
	w = local[4];
	local[0]= w;
glviewBLK157:
	ctx->vsp=local; return(local[0]);}

/*:diffuse*/
static pointer glviewM168colormaterial_diffuse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT174;}
	local[0]= NIL;
glviewENT174:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT173;}
	local[1]= local[0];
glviewENT173:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT172;}
	local[2]= local[0];
glviewENT172:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT171;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT171:
glviewENT170:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON176;
	local[4]= argv[0]->c.obj.iv[3];
	goto glviewCON175;
glviewCON176:
	w = local[0];
	if (!numberp(w)) goto glviewCON177;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[4]= argv[0]->c.obj.iv[3];
	goto glviewCON175;
glviewCON177:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON178;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[3] = w;
	local[4]= argv[0]->c.obj.iv[3];
	goto glviewCON175;
glviewCON178:
	local[4]= fqv[4];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON175;
glviewCON179:
	local[4]= NIL;
glviewCON175:
	w = local[4];
	local[0]= w;
glviewBLK169:
	ctx->vsp=local; return(local[0]);}

/*:specular*/
static pointer glviewM180colormaterial_specular(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT186;}
	local[0]= NIL;
glviewENT186:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT185;}
	local[1]= local[0];
glviewENT185:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT184;}
	local[2]= local[0];
glviewENT184:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT183;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT183:
glviewENT182:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON188;
	local[4]= argv[0]->c.obj.iv[4];
	goto glviewCON187;
glviewCON188:
	w = local[0];
	if (!numberp(w)) goto glviewCON189;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[4] = w;
	local[4]= argv[0]->c.obj.iv[4];
	goto glviewCON187;
glviewCON189:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON190;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[4] = w;
	local[4]= argv[0]->c.obj.iv[4];
	goto glviewCON187;
glviewCON190:
	local[4]= fqv[5];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON187;
glviewCON191:
	local[4]= NIL;
glviewCON187:
	w = local[4];
	local[0]= w;
glviewBLK181:
	ctx->vsp=local; return(local[0]);}

/*:emission*/
static pointer glviewM192colormaterial_emission(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT198;}
	local[0]= NIL;
glviewENT198:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT197;}
	local[1]= local[0];
glviewENT197:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT196;}
	local[2]= local[0];
glviewENT196:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT195;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT195:
glviewENT194:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON200;
	local[4]= argv[0]->c.obj.iv[5];
	goto glviewCON199;
glviewCON200:
	w = local[0];
	if (!numberp(w)) goto glviewCON201;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[5] = w;
	local[4]= argv[0]->c.obj.iv[5];
	goto glviewCON199;
glviewCON201:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON202;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[5] = w;
	local[4]= argv[0]->c.obj.iv[5];
	goto glviewCON199;
glviewCON202:
	local[4]= fqv[6];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON199;
glviewCON203:
	local[4]= NIL;
glviewCON199:
	w = local[4];
	local[0]= w;
glviewBLK193:
	ctx->vsp=local; return(local[0]);}

/*:shininess*/
static pointer glviewM204colormaterial_shininess(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT207;}
	local[0]= NIL;
glviewENT207:
glviewENT206:
	if (n>3) maerror();
	if (local[0]!=NIL) goto glviewCON209;
	local[1]= argv[0]->c.obj.iv[6];
	goto glviewCON208;
glviewCON209:
	w = local[0];
	if (!numberp(w)) goto glviewCON210;
	argv[0]->c.obj.iv[6] = local[0];
	local[1]= argv[0]->c.obj.iv[6];
	goto glviewCON208;
glviewCON210:
	local[1]= fqv[7];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto glviewCON208;
glviewCON211:
	local[1]= NIL;
glviewCON208:
	w = local[1];
	local[0]= w;
glviewBLK205:
	ctx->vsp=local; return(local[0]);}

/*:transparency*/
static pointer glviewM212colormaterial_transparency(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT215;}
	local[0]= NIL;
glviewENT215:
glviewENT214:
	if (n>3) maerror();
	if (local[0]!=NIL) goto glviewCON217;
	local[1]= argv[0]->c.obj.iv[7];
	goto glviewCON216;
glviewCON217:
	w = local[0];
	if (!numberp(w)) goto glviewCON218;
	argv[0]->c.obj.iv[7] = local[0];
	local[1]= argv[0]->c.obj.iv[7];
	goto glviewCON216;
glviewCON218:
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto glviewCON216;
glviewCON219:
	local[1]= NIL;
glviewCON216:
	w = local[1];
	local[0]= w;
glviewBLK213:
	ctx->vsp=local; return(local[0]);}

/*:opengl*/
static pointer glviewM220colormaterial_opengl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)1032L);
	local[1]= makeint((eusinteger_t)4608L);
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[0]= makeint((eusinteger_t)1032L);
	local[1]= makeint((eusinteger_t)4609L);
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[0]= makeint((eusinteger_t)1032L);
	local[1]= makeint((eusinteger_t)4610L);
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[0]= makeint((eusinteger_t)1032L);
	local[1]= makeint((eusinteger_t)5632L);
	local[2]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[0]= makeint((eusinteger_t)1032L);
	local[1]= makeint((eusinteger_t)5633L);
	local[2]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+3;
	w=(pointer)MKFLTVEC(ctx,1,local+2); /*float-vector*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,3,local+0,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[0]= w;
glviewBLK221:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer glviewM222lightsource_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[10], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto glviewKEY224;
	local[4]= makeflt(5.0000000000000000000000e-01);
	local[5]= makeflt(5.0000000000000000000000e-01);
	local[6]= makeflt(5.0000000000000000000000e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	local[0] = w;
glviewKEY224:
	if (n & (1<<1)) goto glviewKEY225;
	local[4]= makeflt(7.9999999999999982236432e-01);
	local[5]= makeflt(7.9999999999999982236432e-01);
	local[6]= makeflt(7.9999999999999982236432e-01);
	local[7]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	local[1] = w;
glviewKEY225:
	if (n & (1<<2)) goto glviewKEY226;
	local[4]= makeflt(6.9999999999999973354647e-01);
	local[5]= makeflt(6.9999999999999973354647e-01);
	local[6]= makeflt(6.9999999999999973354647e-01);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	local[2] = w;
glviewKEY226:
	if (n & (1<<3)) goto glviewKEY227;
	local[4]= makeflt(1.0000000000000000000000e+03);
	local[5]= makeflt(2.0000000000000000000000e+03);
	local[6]= makeflt(1.0000000000000000000000e+05);
	local[7]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	local[3] = w;
glviewKEY227:
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = local[0];
	argv[0]->c.obj.iv[3] = local[1];
	argv[0]->c.obj.iv[4] = local[2];
	argv[0]->c.obj.iv[5] = local[3];
	w = argv[0];
	local[0]= w;
glviewBLK223:
	ctx->vsp=local; return(local[0]);}

/*:light-id*/
static pointer glviewM228lightsource_light_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)16384L);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
glviewBLK229:
	ctx->vsp=local; return(local[0]);}

/*:ambient*/
static pointer glviewM230lightsource_ambient(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT236;}
	local[0]= NIL;
glviewENT236:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT235;}
	local[1]= local[0];
glviewENT235:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT234;}
	local[2]= local[0];
glviewENT234:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT233;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT233:
glviewENT232:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON238;
	local[4]= argv[0]->c.obj.iv[2];
	goto glviewCON237;
glviewCON238:
	w = local[0];
	if (!numberp(w)) goto glviewCON239;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[2] = w;
	local[4]= argv[0]->c.obj.iv[2];
	goto glviewCON237;
glviewCON239:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON240;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[2] = w;
	local[4]= argv[0]->c.obj.iv[2];
	goto glviewCON237;
glviewCON240:
	local[4]= fqv[11];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON237;
glviewCON241:
	local[4]= NIL;
glviewCON237:
	w = local[4];
	local[0]= w;
glviewBLK231:
	ctx->vsp=local; return(local[0]);}

/*:diffuse*/
static pointer glviewM242lightsource_diffuse(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT248;}
	local[0]= NIL;
glviewENT248:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT247;}
	local[1]= local[0];
glviewENT247:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT246;}
	local[2]= local[0];
glviewENT246:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT245;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT245:
glviewENT244:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON250;
	local[4]= argv[0]->c.obj.iv[3];
	goto glviewCON249;
glviewCON250:
	w = local[0];
	if (!numberp(w)) goto glviewCON251;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[3] = w;
	local[4]= argv[0]->c.obj.iv[3];
	goto glviewCON249;
glviewCON251:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON252;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[3] = w;
	local[4]= argv[0]->c.obj.iv[3];
	goto glviewCON249;
glviewCON252:
	local[4]= fqv[12];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON249;
glviewCON253:
	local[4]= NIL;
glviewCON249:
	w = local[4];
	local[0]= w;
glviewBLK243:
	ctx->vsp=local; return(local[0]);}

/*:specular*/
static pointer glviewM254lightsource_specular(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT260;}
	local[0]= NIL;
glviewENT260:
	if (n>=4) { local[1]=(argv[3]); goto glviewENT259;}
	local[1]= local[0];
glviewENT259:
	if (n>=5) { local[2]=(argv[4]); goto glviewENT258;}
	local[2]= local[0];
glviewENT258:
	if (n>=6) { local[3]=(argv[5]); goto glviewENT257;}
	local[3]= makeint((eusinteger_t)1L);
glviewENT257:
glviewENT256:
	if (n>6) maerror();
	if (local[0]!=NIL) goto glviewCON262;
	local[4]= argv[0]->c.obj.iv[4];
	goto glviewCON261;
glviewCON262:
	w = local[0];
	if (!numberp(w)) goto glviewCON263;
	local[4]= local[0];
	local[5]= local[1];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	argv[0]->c.obj.iv[4] = w;
	local[4]= argv[0]->c.obj.iv[4];
	goto glviewCON261;
glviewCON263:
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,1,local+4,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON264;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[4] = w;
	local[4]= argv[0]->c.obj.iv[4];
	goto glviewCON261;
glviewCON264:
	local[4]= fqv[13];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto glviewCON261;
glviewCON265:
	local[4]= NIL;
glviewCON261:
	w = local[4];
	local[0]= w;
glviewBLK255:
	ctx->vsp=local; return(local[0]);}

/*:position*/
static pointer glviewM266lightsource_position(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT269;}
	local[0]= NIL;
glviewENT269:
glviewENT268:
	if (n>3) maerror();
	if (local[0]!=NIL) goto glviewCON271;
	local[1]= argv[0]->c.obj.iv[5];
	goto glviewCON270;
glviewCON271:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON272;
	argv[0]->c.obj.iv[5] = local[0];
	local[1]= argv[0]->c.obj.iv[5];
	goto glviewCON270;
glviewCON272:
	local[1]= NIL;
glviewCON270:
	w = local[1];
	local[0]= w;
glviewBLK267:
	ctx->vsp=local; return(local[0]);}

/*:move*/
static pointer glviewM273lightsource_move(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+3;
	w=(pointer)VPLUS(ctx,3,local+0); /*v+*/
	local[0]= w;
glviewBLK274:
	ctx->vsp=local; return(local[0]);}

/*:enable*/
static pointer glviewM275lightsource_enable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[14];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[2])(ctx,1,local+0,&ftab[2],fqv[15]); /*glenable*/
	local[0]= w;
glviewBLK276:
	ctx->vsp=local; return(local[0]);}

/*:disable*/
static pointer glviewM277lightsource_disable(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[14];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[3])(ctx,1,local+0,&ftab[3],fqv[16]); /*gldisable*/
	local[0]= w;
glviewBLK278:
	ctx->vsp=local; return(local[0]);}

/*:opengl*/
static pointer glviewM279lightsource_opengl(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)16384L);
	local[1]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)4608L);
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)4609L);
	local[3]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)4610L);
	local[3]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,1,local+1,&ftab[2],fqv[15]); /*glenable*/
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
glviewBLK280:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer glviewM281glviewsurface_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
glviewRST283:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[18], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto glviewKEY284;
	local[1] = makeint((eusinteger_t)0L);
glviewKEY284:
	if (n & (1<<1)) goto glviewKEY285;
	local[2] = makeint((eusinteger_t)0L);
glviewKEY285:
	if (n & (1<<2)) goto glviewKEY286;
	local[3] = makeint((eusinteger_t)256L);
glviewKEY286:
	if (n & (1<<3)) goto glviewKEY287;
	local[4] = local[3];
glviewKEY287:
	if (n & (1<<4)) goto glviewKEY288;
	local[5] = local[3];
glviewKEY288:
	if (n & (1<<5)) goto glviewKEY289;
	local[6] = makeint((eusinteger_t)0L);
glviewKEY289:
	if (n & (1<<6)) goto glviewKEY290;
	local[8]= fqv[19];
	ctx->vsp=local+9;
	w=(pointer)GENSYM(ctx,1,local+8); /*gensym*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(*ftab[5])(ctx,1,local+8,&ftab[5],fqv[20]); /*string*/
	local[7] = w;
glviewKEY290:
	local[8]= argv[0];
	local[9]= fqv[21];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[22];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[23];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= argv[0];
	local[9]= fqv[24];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,3,local+8); /*send*/
	local[8]= loadglobal(fqv[25]);
	local[9]= loadglobal(fqv[25]);
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,1,local+9,&ftab[6],fqv[26]); /*x:defaultscreen*/
	local[9]= w;
	local[10]= loadglobal(fqv[27]);
	ctx->vsp=local+11;
	w=(*ftab[7])(ctx,3,local+8,&ftab[7],fqv[28]); /*glxchoosevisual*/
	argv[0]->c.obj.iv[14] = w;
	local[8]= loadglobal(fqv[25]);
	local[9]= argv[0]->c.obj.iv[14];
	local[10]= local[6];
	local[11]= makeint((eusinteger_t)1L);
	ctx->vsp=local+12;
	w=(*ftab[8])(ctx,4,local+8,&ftab[8],fqv[29]); /*glxcreatecontext*/
	argv[0]->c.obj.iv[15] = w;
	if (argv[0]->c.obj.iv[2]!=NIL) goto glviewIF291;
	local[8]= (pointer)get_sym_func(fqv[30]);
	local[9]= argv[0];
	local[10]= *(ovafptr(argv[1],fqv[31]));
	local[11]= fqv[32];
	local[12]= fqv[33];
	local[13]= argv[0]->c.obj.iv[14];
	local[14]= makeint((eusinteger_t)20L);
	ctx->vsp=local+15;
	w=(pointer)PLUS(ctx,2,local+13); /*+*/
	local[13]= w;
	local[14]= fqv[34];
	ctx->vsp=local+15;
	w=(pointer)PEEK(ctx,2,local+13); /*system:peek*/
	local[13]= w;
	local[14]= fqv[35];
	local[15]= argv[0]->c.obj.iv[14];
	local[16]= fqv[36];
	ctx->vsp=local+17;
	w=(pointer)PEEK(ctx,2,local+15); /*system:peek*/
	local[15]= w;
	local[16]= fqv[37];
	local[17]= local[7];
	local[18]= local[0];
	ctx->vsp=local+19;
	w=(pointer)APPLY(ctx,11,local+8); /*apply*/
	local[8]= w;
	goto glviewIF292;
glviewIF291:
	local[8]= NIL;
glviewIF292:
	local[8]= loadglobal(fqv[25]);
	local[9]= argv[0]->c.obj.iv[2];
	local[10]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+11;
	w=(*ftab[9])(ctx,3,local+8,&ftab[9],fqv[38]); /*glxmakecurrent*/
	local[8]= argv[0];
	local[9]= fqv[39];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= loadglobal(fqv[40]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[32];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= fqv[41];
	local[13]= makeflt(1.9999999999999995559108e-01);
	local[14]= makeflt(1.9999999999999995559108e-01);
	local[15]= makeflt(1.9999999999999995559108e-01);
	local[16]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,4,local+13); /*float-vector*/
	local[13]= w;
	local[14]= fqv[42];
	local[15]= makeflt(5.0000000000000000000000e-01);
	local[16]= makeflt(5.0000000000000000000000e-01);
	local[17]= makeflt(5.0000000000000000000000e-01);
	local[18]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+19;
	w=(pointer)MKFLTVEC(ctx,4,local+15); /*float-vector*/
	local[15]= w;
	local[16]= fqv[43];
	local[17]= makeflt(2.9999999999999982236432e-01);
	local[18]= makeflt(2.9999999999999982236432e-01);
	local[19]= makeflt(2.9999999999999982236432e-01);
	local[20]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,4,local+17); /*float-vector*/
	local[17]= w;
	local[18]= fqv[44];
	local[19]= makeflt(0.0000000000000000000000e+00);
	local[20]= makeflt(0.0000000000000000000000e+00);
	local[21]= makeflt(1.0000000000000000000000e+00);
	local[22]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,4,local+19); /*float-vector*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,11,local+9); /*send*/
	w = local[8];
	local[8]= w;
	storeglobal(fqv[45],w);
	local[8]= loadglobal(fqv[40]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[32];
	local[11]= makeint((eusinteger_t)1L);
	local[12]= fqv[41];
	local[13]= makeflt(2.9999999999999982236432e-01);
	local[14]= makeflt(2.9999999999999982236432e-01);
	local[15]= makeflt(2.9999999999999982236432e-01);
	local[16]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,4,local+13); /*float-vector*/
	local[13]= w;
	local[14]= fqv[42];
	local[15]= makeflt(5.9999999999999964472863e-01);
	local[16]= makeflt(9.9999999999999977795540e-02);
	local[17]= makeflt(9.9999999999999977795540e-02);
	local[18]= makeflt(7.9999999999999982236432e-01);
	ctx->vsp=local+19;
	w=(pointer)MKFLTVEC(ctx,4,local+15); /*float-vector*/
	local[15]= w;
	local[16]= fqv[43];
	local[17]= makeflt(2.9999999999999982236432e-01);
	local[18]= makeflt(2.9999999999999982236432e-01);
	local[19]= makeflt(2.9999999999999982236432e-01);
	local[20]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,4,local+17); /*float-vector*/
	local[17]= w;
	local[18]= fqv[44];
	local[19]= makeflt(5.0000000000000000000000e+03);
	local[20]= makeflt(1.0000000000000000000000e+03);
	local[21]= makeflt(7.0000000000000000000000e+03);
	local[22]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,4,local+19); /*float-vector*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,11,local+9); /*send*/
	w = local[8];
	local[8]= w;
	storeglobal(fqv[46],w);
	local[8]= loadglobal(fqv[40]);
	ctx->vsp=local+9;
	w=(pointer)INSTANTIATE(ctx,1,local+8); /*instantiate*/
	local[8]= w;
	local[9]= local[8];
	local[10]= fqv[32];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= fqv[41];
	local[13]= makeflt(2.9999999999999982236432e-01);
	local[14]= makeflt(2.9999999999999982236432e-01);
	local[15]= makeflt(2.9999999999999982236432e-01);
	local[16]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,4,local+13); /*float-vector*/
	local[13]= w;
	local[14]= fqv[42];
	local[15]= makeflt(9.9999999999999977795540e-02);
	local[16]= makeflt(9.9999999999999977795540e-02);
	local[17]= makeflt(6.9999999999999973354647e-01);
	local[18]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+19;
	w=(pointer)MKFLTVEC(ctx,4,local+15); /*float-vector*/
	local[15]= w;
	local[16]= fqv[43];
	local[17]= makeflt(2.9999999999999982236432e-01);
	local[18]= makeflt(2.9999999999999982236432e-01);
	local[19]= makeflt(2.9999999999999982236432e-01);
	local[20]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+21;
	w=(pointer)MKFLTVEC(ctx,4,local+17); /*float-vector*/
	local[17]= w;
	local[18]= fqv[44];
	local[19]= makeflt(-1.5000000000000000000000e+04);
	local[20]= makeflt(0.0000000000000000000000e+00);
	local[21]= makeflt(2.0000000000000000000000e+03);
	local[22]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,4,local+19); /*float-vector*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,11,local+9); /*send*/
	w = local[8];
	local[8]= w;
	storeglobal(fqv[47],w);
	local[8]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,1,local+8,&ftab[2],fqv[15]); /*glenable*/
	local[8]= loadglobal(fqv[45]);
	local[9]= fqv[48];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= loadglobal(fqv[46]);
	local[9]= fqv[48];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= loadglobal(fqv[47]);
	local[9]= fqv[48];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= makeint((eusinteger_t)2304L);
	ctx->vsp=local+9;
	w=(*ftab[10])(ctx,1,local+8,&ftab[10],fqv[49]); /*glfrontface*/
	local[8]= makeint((eusinteger_t)3456L);
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,1,local+8,&ftab[2],fqv[15]); /*glenable*/
	local[8]= makeint((eusinteger_t)2977L);
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,1,local+8,&ftab[2],fqv[15]); /*glenable*/
	local[8]= makeint((eusinteger_t)513L);
	ctx->vsp=local+9;
	w=(*ftab[11])(ctx,1,local+8,&ftab[11],fqv[50]); /*gldepthfunc*/
	local[8]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+9;
	w=(*ftab[2])(ctx,1,local+8,&ftab[2],fqv[15]); /*glenable*/
	local[8]= makeint((eusinteger_t)7425L);
	ctx->vsp=local+9;
	w=(*ftab[12])(ctx,1,local+8,&ftab[12],fqv[51]); /*glshademodel*/
	local[8]= makeint((eusinteger_t)3317L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[52]); /*glpixelstorei*/
	local[8]= makeint((eusinteger_t)3553L);
	local[9]= makeint((eusinteger_t)10242L);
	local[10]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,3,local+8,&ftab[14],fqv[53]); /*gltexparameteri*/
	local[8]= makeint((eusinteger_t)3553L);
	local[9]= makeint((eusinteger_t)10243L);
	local[10]= makeint((eusinteger_t)10497L);
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,3,local+8,&ftab[14],fqv[53]); /*gltexparameteri*/
	local[8]= makeint((eusinteger_t)3553L);
	local[9]= makeint((eusinteger_t)10240L);
	local[10]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,3,local+8,&ftab[14],fqv[53]); /*gltexparameteri*/
	local[8]= makeint((eusinteger_t)3553L);
	local[9]= makeint((eusinteger_t)10241L);
	local[10]= makeint((eusinteger_t)9728L);
	ctx->vsp=local+11;
	w=(*ftab[14])(ctx,3,local+8,&ftab[14],fqv[53]); /*gltexparameteri*/
	local[8]= makeint((eusinteger_t)8960L);
	local[9]= makeint((eusinteger_t)8704L);
	local[10]= makeint((eusinteger_t)8448L);
	ctx->vsp=local+11;
	w=(*ftab[15])(ctx,3,local+8,&ftab[15],fqv[54]); /*gltexenvi*/
	local[8]= makeint((eusinteger_t)16384L);
	w = makeint((eusinteger_t)256L);
	local[8]= (pointer)((eusinteger_t)local[8] | (eusinteger_t)w);
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,1,local+8,&ftab[16],fqv[55]); /*glclear*/
	local[8]= loadglobal(fqv[25]);
	local[9]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[56]); /*glxswapbuffers*/
	local[8]= makeint((eusinteger_t)16384L);
	w = makeint((eusinteger_t)256L);
	local[8]= (pointer)((eusinteger_t)local[8] | (eusinteger_t)w);
	ctx->vsp=local+9;
	w=(*ftab[16])(ctx,1,local+8,&ftab[16],fqv[55]); /*glclear*/
	local[8]= loadglobal(fqv[25]);
	local[9]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+10;
	w=(*ftab[17])(ctx,2,local+8,&ftab[17],fqv[56]); /*glxswapbuffers*/
	ctx->vsp=local+8;
	w=(*ftab[18])(ctx,0,local+8,&ftab[18],fqv[57]); /*glunewtess*/
	local[8]= w;
	storeglobal(fqv[58],w);
	local[8]= loadglobal(fqv[58]);
	local[9]= makeint((eusinteger_t)100100L);
	local[10]= *(ovafptr((pointer)get_sym_func(fqv[59]),fqv[60]));
	local[11]= *(ovafptr((pointer)get_sym_func(fqv[59]),fqv[61]));
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,4,local+8,&ftab[19],fqv[62]); /*glutesscallbackl*/
	local[8]= loadglobal(fqv[58]);
	local[9]= makeint((eusinteger_t)100101L);
	local[10]= *(ovafptr((pointer)get_sym_func(fqv[63]),fqv[60]));
	local[11]= *(ovafptr((pointer)get_sym_func(fqv[63]),fqv[61]));
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,4,local+8,&ftab[19],fqv[62]); /*glutesscallbackl*/
	local[8]= loadglobal(fqv[58]);
	local[9]= makeint((eusinteger_t)100102L);
	local[10]= *(ovafptr((pointer)get_sym_func(fqv[64]),fqv[60]));
	local[11]= *(ovafptr((pointer)get_sym_func(fqv[64]),fqv[61]));
	ctx->vsp=local+12;
	w=(*ftab[19])(ctx,4,local+8,&ftab[19],fqv[62]); /*glutesscallbackl*/
	w = argv[0];
	local[0]= w;
glviewBLK282:
	ctx->vsp=local; return(local[0]);}

/*:material*/
static pointer glviewM293glviewsurface_material(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto glviewENT299;}
	local[0]= NIL;
glviewENT299:
	if (n>=5) { local[1]=(argv[4]); goto glviewENT298;}
	local[1]= NIL;
glviewENT298:
	if (n>=6) { local[2]=(argv[5]); goto glviewENT297;}
	local[2]= NIL;
glviewENT297:
	if (n>=7) { local[3]=(argv[6]); goto glviewENT296;}
	local[3]= NIL;
glviewENT296:
glviewENT295:
	if (n>7) maerror();
	if (local[0]!=NIL) goto glviewIF300;
	local[0] = argv[2]->c.obj.iv[3];
	local[1] = argv[2]->c.obj.iv[4];
	local[2] = argv[2]->c.obj.iv[5];
	local[3] = argv[2]->c.obj.iv[6];
	argv[2] = argv[2]->c.obj.iv[2];
	local[4]= argv[2];
	goto glviewIF301;
glviewIF300:
	local[4]= NIL;
glviewIF301:
	local[4]= makeint((eusinteger_t)1032L);
	local[5]= makeint((eusinteger_t)4608L);
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,3,local+4,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[4]= makeint((eusinteger_t)1032L);
	local[5]= makeint((eusinteger_t)4609L);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,3,local+4,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[4]= makeint((eusinteger_t)1032L);
	local[5]= makeint((eusinteger_t)4610L);
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,3,local+4,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[4]= makeint((eusinteger_t)1032L);
	local[5]= makeint((eusinteger_t)5632L);
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,3,local+4,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[4]= makeint((eusinteger_t)1032L);
	local[5]= makeint((eusinteger_t)5633L);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,1,local+6); /*float-vector*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(*ftab[1])(ctx,3,local+4,&ftab[1],fqv[9]); /*glmaterialfv*/
	local[0]= w;
glviewBLK294:
	ctx->vsp=local; return(local[0]);}

/*:color*/
static pointer glviewM302glviewsurface_color(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT305;}
	local[0]= NIL;
glviewENT305:
glviewENT304:
	if (n>3) maerror();
	if (local[0]!=NIL) goto glviewIF306;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)MKFLTVEC(ctx,4,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2816L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,2,local+2,&ftab[20],fqv[65]); /*glgetfloatv*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)3L);
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	ctx->vsp=local+2;
	local[0]=w;
	goto glviewBLK303;
	w = local[2];
	local[1]= w;
	goto glviewIF307;
glviewIF306:
	local[1]= NIL;
glviewIF307:
	local[1]= local[0];
	local[2]= loadglobal(fqv[66]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w==NIL) goto glviewIF308;
	local[0] = local[0]->c.obj.iv[0];
	local[1]= local[0];
	goto glviewIF309;
glviewIF308:
	local[1]= NIL;
glviewIF309:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= local[1];
	if (fqv[67]!=local[2]) goto glviewIF310;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[21])(ctx,1,local+2,&ftab[21],fqv[68]); /*glcolor3fv*/
	local[2]= w;
	goto glviewIF311;
glviewIF310:
	local[2]= local[1];
	if (fqv[69]!=local[2]) goto glviewIF312;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[22])(ctx,1,local+2,&ftab[22],fqv[70]); /*glcolor4fv*/
	local[2]= w;
	goto glviewIF313;
glviewIF312:
	if (T==NIL) goto glviewIF314;
	local[2]= fqv[71];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto glviewIF315;
glviewIF314:
	local[2]= NIL;
glviewIF315:
glviewIF313:
glviewIF311:
	w = local[2];
	local[0]= w;
glviewBLK303:
	ctx->vsp=local; return(local[0]);}

/*:line-width*/
static pointer glviewM316glviewsurface_line_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT319;}
	local[0]= NIL;
glviewENT319:
glviewENT318:
	if (n>3) maerror();
	if (local[0]==NIL) goto glviewIF320;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[23])(ctx,1,local+1,&ftab[23],fqv[72]); /*gllinewidth*/
	local[1]= w;
	goto glviewIF321;
glviewIF320:
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,1,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2849L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,2,local+2,&ftab[20],fqv[65]); /*glgetfloatv*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[1]= w;
glviewIF321:
	w = local[1];
	local[0]= w;
glviewBLK317:
	ctx->vsp=local; return(local[0]);}

/*:point-size*/
static pointer glviewM322glviewsurface_point_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT325;}
	local[0]= NIL;
glviewENT325:
glviewENT324:
	if (n>3) maerror();
	if (local[0]==NIL) goto glviewIF326;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)EUSFLOAT(ctx,1,local+1); /*float*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[24])(ctx,1,local+1,&ftab[24],fqv[73]); /*glpointsize*/
	local[1]= w;
	goto glviewIF327;
glviewIF326:
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,1,local+1); /*float-vector*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2833L);
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(*ftab[20])(ctx,2,local+2,&ftab[20],fqv[65]); /*glgetfloatv*/
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[1]= w;
glviewIF327:
	w = local[1];
	local[0]= w;
glviewBLK323:
	ctx->vsp=local; return(local[0]);}

/*:window*/
static pointer glviewM328glviewsurface_window(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
glviewBLK329:
	ctx->vsp=local; return(local[0]);}

/*:3d-mode*/
static pointer glviewM330glviewsurface_3d_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto glviewIF332;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[5];
	local[2]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)QUOTIENT(ctx,2,local+1); /*/*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,1,local+1); /*-*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[25])(ctx,4,local+0,&ftab[25],fqv[74]); /*glviewport*/
	local[0]= w;
	goto glviewIF333;
glviewIF332:
	local[0]= argv[0]->c.obj.iv[6];
	local[1]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)2L);
	ctx->vsp=local+2;
	w=(pointer)QUOTIENT(ctx,2,local+0); /*/*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)MINUS(ctx,1,local+0); /*-*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[6];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[25])(ctx,4,local+0,&ftab[25],fqv[74]); /*glviewport*/
	local[0]= w;
glviewIF333:
	local[0]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+0;
	w=(*ftab[27])(ctx,0,local+0,&ftab[27],fqv[76]); /*glloadidentity*/
	local[0]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+1;
	w=(*ftab[2])(ctx,1,local+0,&ftab[2],fqv[15]); /*glenable*/
	local[0]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+1;
	w=(*ftab[2])(ctx,1,local+0,&ftab[2],fqv[15]); /*glenable*/
	local[0]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+0;
	w=(*ftab[27])(ctx,0,local+0,&ftab[27],fqv[76]); /*glloadidentity*/
	local[0]= w;
glviewBLK331:
	ctx->vsp=local; return(local[0]);}

/*:2d-mode*/
static pointer glviewM334glviewsurface_2d_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[77], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto glviewKEY336;
	local[0] = NIL;
glviewKEY336:
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+5;
	w=(*ftab[25])(ctx,4,local+1,&ftab[25],fqv[74]); /*glviewport*/
	local[1]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[75]); /*glmatrixmode*/
	if (local[0]==NIL) goto glviewIF337;
	ctx->vsp=local+1;
	w=(*ftab[28])(ctx,0,local+1,&ftab[28],fqv[78]); /*glpushmatrix*/
	local[1]= w;
	goto glviewIF338;
glviewIF337:
	local[1]= NIL;
glviewIF338:
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,0,local+1,&ftab[27],fqv[76]); /*glloadidentity*/
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[6];
	local[5]= makeflt(-1.0000000000000000000000e+00);
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,6,local+1); /*float-vector*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[29])(ctx,1,local+1,&ftab[29],fqv[79]); /*glorthofv*/
	local[1]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[16]); /*gldisable*/
	local[1]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[16]); /*gldisable*/
	local[1]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[75]); /*glmatrixmode*/
	if (local[0]==NIL) goto glviewIF339;
	ctx->vsp=local+1;
	w=(*ftab[28])(ctx,0,local+1,&ftab[28],fqv[78]); /*glpushmatrix*/
	local[1]= w;
	goto glviewIF340;
glviewIF339:
	local[1]= NIL;
glviewIF340:
	ctx->vsp=local+1;
	w=(*ftab[27])(ctx,0,local+1,&ftab[27],fqv[76]); /*glloadidentity*/
	local[0]= w;
glviewBLK335:
	ctx->vsp=local; return(local[0]);}

/*:pop-mode*/
static pointer glviewM341glviewsurface_pop_mode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+0;
	w=(*ftab[30])(ctx,0,local+0,&ftab[30],fqv[80]); /*glpopmatrix*/
	local[0]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+0;
	w=(*ftab[30])(ctx,0,local+0,&ftab[30],fqv[80]); /*glpopmatrix*/
	local[0]= w;
glviewBLK342:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer glviewM343glviewsurface_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT346;}
	local[0]= NIL;
glviewENT346:
glviewENT345:
	if (n>3) maerror();
	if (local[0]==NIL) goto glviewIF347;
	argv[0]->c.obj.iv[6] = local[0];
	local[1]= argv[0]->c.obj.iv[6];
	goto glviewIF348;
glviewIF347:
	local[1]= NIL;
glviewIF348:
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
glviewBLK344:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer glviewM349glviewsurface_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT352;}
	local[0]= NIL;
glviewENT352:
glviewENT351:
	if (n>3) maerror();
	if (local[0]==NIL) goto glviewIF353;
	argv[0]->c.obj.iv[5] = local[0];
	local[1]= argv[0]->c.obj.iv[5];
	goto glviewIF354;
glviewIF353:
	local[1]= NIL;
glviewIF354:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
glviewBLK350:
	ctx->vsp=local; return(local[0]);}

/*:pos*/
static pointer glviewM355glviewsurface_pos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+2;
	w=(pointer)MKINTVECTOR(ctx,2,local+0); /*integer-vector*/
	local[0]= w;
glviewBLK356:
	ctx->vsp=local; return(local[0]);}

/*:x*/
static pointer glviewM357glviewsurface_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT360;}
	local[0]= NIL;
glviewENT360:
glviewENT359:
	if (n>3) maerror();
	if (local[0]==NIL) goto glviewIF361;
	argv[0]->c.obj.iv[12] = local[0];
	local[1]= argv[0]->c.obj.iv[12];
	goto glviewIF362;
glviewIF361:
	local[1]= NIL;
glviewIF362:
	w = argv[0]->c.obj.iv[12];
	local[0]= w;
glviewBLK358:
	ctx->vsp=local; return(local[0]);}

/*:y*/
static pointer glviewM363glviewsurface_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto glviewENT366;}
	local[0]= NIL;
glviewENT366:
glviewENT365:
	if (n>3) maerror();
	if (local[0]==NIL) goto glviewIF367;
	argv[0]->c.obj.iv[13] = local[0];
	local[1]= argv[0]->c.obj.iv[13];
	goto glviewIF368;
glviewIF367:
	local[1]= NIL;
glviewIF368:
	w = argv[0]->c.obj.iv[13];
	local[0]= w;
glviewBLK364:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer glviewM369glviewsurface_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)16384L);
	w = makeint((eusinteger_t)256L);
	local[0]= (pointer)((eusinteger_t)local[0] | (eusinteger_t)w);
	ctx->vsp=local+1;
	w=(*ftab[16])(ctx,1,local+0,&ftab[16],fqv[55]); /*glclear*/
	local[0]= w;
glviewBLK370:
	ctx->vsp=local; return(local[0]);}

/*:glflush*/
static pointer glviewM371glviewsurface_glflush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	ctx->vsp=local+0;
	w=(*ftab[31])(ctx,0,local+0,&ftab[31],fqv[81]); /*glflush*/
	local[0]= loadglobal(fqv[25]);
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(*ftab[17])(ctx,2,local+0,&ftab[17],fqv[56]); /*glxswapbuffers*/
	local[0]= w;
glviewBLK372:
	ctx->vsp=local; return(local[0]);}

/*:point*/
static pointer glviewM373glviewsurface_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[82];
	local[2]= fqv[83];
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(*ftab[32])(ctx,1,local+0,&ftab[32],fqv[59]); /*glbegin*/
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	ctx->vsp=local+0;
	w=(*ftab[34])(ctx,0,local+0,&ftab[34],fqv[64]); /*glend*/
	local[0]= argv[0];
	local[1]= fqv[39];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
glviewBLK374:
	ctx->vsp=local; return(local[0]);}

/*:line*/
static pointer glviewM375glviewsurface_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0];
	local[1]= fqv[82];
	local[2]= fqv[83];
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)1L);
	ctx->vsp=local+1;
	w=(*ftab[32])(ctx,1,local+0,&ftab[32],fqv[59]); /*glbegin*/
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	local[0]= argv[4];
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	ctx->vsp=local+0;
	w=(*ftab[34])(ctx,0,local+0,&ftab[34],fqv[64]); /*glend*/
	local[0]= argv[0];
	local[1]= fqv[39];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
glviewBLK376:
	ctx->vsp=local; return(local[0]);}

/*:3d-point*/
static pointer glviewM377glviewsurface_3d_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[86], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto glviewKEY379;
	local[0] = T;
glviewKEY379:
	if (n & (1<<1)) goto glviewKEY380;
	local[1] = T;
glviewKEY380:
	if (local[0]==NIL) goto glviewIF381;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[16]); /*gldisable*/
	local[2]= w;
	goto glviewIF382;
glviewIF381:
	local[2]= NIL;
glviewIF382:
	if (local[1]==NIL) goto glviewIF383;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[16]); /*gldisable*/
	local[2]= w;
	goto glviewIF384;
glviewIF383:
	local[2]= NIL;
glviewIF384:
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(*ftab[32])(ctx,1,local+2,&ftab[32],fqv[59]); /*glbegin*/
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[35])(ctx,1,local+2,&ftab[35],fqv[87]); /*glvertex3fv*/
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,0,local+2,&ftab[34],fqv[64]); /*glend*/
	if (local[0]==NIL) goto glviewIF385;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[15]); /*glenable*/
	local[2]= w;
	goto glviewIF386;
glviewIF385:
	local[2]= NIL;
glviewIF386:
	if (local[1]==NIL) goto glviewIF387;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[15]); /*glenable*/
	local[2]= w;
	goto glviewIF388;
glviewIF387:
	local[2]= NIL;
glviewIF388:
	w = local[2];
	local[0]= w;
glviewBLK378:
	ctx->vsp=local; return(local[0]);}

/*:3d-line*/
static pointer glviewM389glviewsurface_3d_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[88], &argv[4], n-4, local+0, 0);
	if (n & (1<<0)) goto glviewKEY391;
	local[0] = T;
glviewKEY391:
	if (n & (1<<1)) goto glviewKEY392;
	local[1] = T;
glviewKEY392:
	if (local[0]==NIL) goto glviewIF393;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[16]); /*gldisable*/
	local[2]= w;
	goto glviewIF394;
glviewIF393:
	local[2]= NIL;
glviewIF394:
	if (local[1]==NIL) goto glviewIF395;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[16]); /*gldisable*/
	local[2]= w;
	goto glviewIF396;
glviewIF395:
	local[2]= NIL;
glviewIF396:
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[32])(ctx,1,local+2,&ftab[32],fqv[59]); /*glbegin*/
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[35])(ctx,1,local+2,&ftab[35],fqv[87]); /*glvertex3fv*/
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[35])(ctx,1,local+2,&ftab[35],fqv[87]); /*glvertex3fv*/
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,0,local+2,&ftab[34],fqv[64]); /*glend*/
	if (local[0]==NIL) goto glviewIF397;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[15]); /*glenable*/
	local[2]= w;
	goto glviewIF398;
glviewIF397:
	local[2]= NIL;
glviewIF398:
	if (local[1]==NIL) goto glviewIF399;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[15]); /*glenable*/
	local[2]= w;
	goto glviewIF400;
glviewIF399:
	local[2]= NIL;
glviewIF400:
	w = local[2];
	local[0]= w;
glviewBLK390:
	ctx->vsp=local; return(local[0]);}

/*:3d-lines*/
static pointer glviewM401glviewsurface_3d_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[89], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto glviewKEY403;
	local[0] = T;
glviewKEY403:
	if (n & (1<<1)) goto glviewKEY404;
	local[1] = T;
glviewKEY404:
	if (local[0]==NIL) goto glviewIF405;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[16]); /*gldisable*/
	local[2]= w;
	goto glviewIF406;
glviewIF405:
	local[2]= NIL;
glviewIF406:
	if (local[1]==NIL) goto glviewIF407;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[16]); /*gldisable*/
	local[2]= w;
	goto glviewIF408;
glviewIF407:
	local[2]= NIL;
glviewIF408:
	local[2]= makeint((eusinteger_t)3L);
	ctx->vsp=local+3;
	w=(*ftab[32])(ctx,1,local+2,&ftab[32],fqv[59]); /*glbegin*/
	local[2]= NIL;
	local[3]= argv[2];
glviewWHL409:
	if (local[3]==NIL) goto glviewWHX410;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[35])(ctx,1,local+4,&ftab[35],fqv[87]); /*glvertex3fv*/
	goto glviewWHL409;
glviewWHX410:
	local[4]= NIL;
glviewBLK411:
	w = NIL;
	ctx->vsp=local+2;
	w=(*ftab[34])(ctx,0,local+2,&ftab[34],fqv[64]); /*glend*/
	if (local[0]==NIL) goto glviewIF412;
	local[2]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[15]); /*glenable*/
	local[2]= w;
	goto glviewIF413;
glviewIF412:
	local[2]= NIL;
glviewIF413:
	if (local[1]==NIL) goto glviewIF414;
	local[2]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[15]); /*glenable*/
	local[2]= w;
	goto glviewIF415;
glviewIF414:
	local[2]= NIL;
glviewIF415:
	w = local[2];
	local[0]= w;
glviewBLK402:
	ctx->vsp=local; return(local[0]);}

/*:draw-faces*/
static pointer glviewM416glviewsurface_draw_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	ctx->vsp=local+0;
	local[0]= makeclosure(codevec,quotevec,glviewCLO418,env,argv,local);
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)MAPC(ctx,2,local+0); /*mapc*/
	local[0]= w;
glviewBLK417:
	ctx->vsp=local; return(local[0]);}

/*:rectangle*/
static pointer glviewM419glviewsurface_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=6) maerror();
	local[0]= argv[0];
	local[1]= fqv[82];
	local[2]= fqv[83];
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= makeint((eusinteger_t)9L);
	ctx->vsp=local+1;
	w=(*ftab[32])(ctx,1,local+0,&ftab[32],fqv[59]); /*glbegin*/
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	local[0]= argv[2];
	local[1]= argv[3];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= argv[3];
	local[2]= argv[5];
	ctx->vsp=local+3;
	w=(pointer)PLUS(ctx,2,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	local[0]= argv[2];
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)PLUS(ctx,2,local+0); /*+*/
	local[0]= w;
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)MKFLTVEC(ctx,2,local+0); /*float-vector*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[33])(ctx,1,local+0,&ftab[33],fqv[84]); /*glvertex2fv*/
	ctx->vsp=local+0;
	w=(*ftab[34])(ctx,0,local+0,&ftab[34],fqv[64]); /*glend*/
	local[0]= argv[0];
	local[1]= fqv[39];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[85];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
glviewBLK420:
	ctx->vsp=local; return(local[0]);}

/*:makecurrent*/
static pointer glviewM421glviewsurface_makecurrent(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[25]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[15];
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,3,local+0,&ftab[9],fqv[38]); /*glxmakecurrent*/
	local[0]= w;
glviewBLK422:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer glviewM423glviewsurface_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
glviewRST425:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0];
	local[2]= fqv[90];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
glviewBLK424:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer glviewM426glviewsurface_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[92];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[31]));
	local[2]= fqv[90];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= w;
glviewBLK427:
	ctx->vsp=local; return(local[0]);}

/*:write-to-image-file*/
static pointer glviewM428glviewsurface_write_to_image_file(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[93], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto glviewKEY430;
	local[0] = makeint((eusinteger_t)0L);
glviewKEY430:
	if (n & (1<<1)) goto glviewKEY431;
	local[1] = makeint((eusinteger_t)0L);
glviewKEY431:
	if (n & (1<<2)) goto glviewKEY432;
	local[2] = argv[0]->c.obj.iv[5];
glviewKEY432:
	if (n & (1<<3)) goto glviewKEY433;
	local[3] = argv[0]->c.obj.iv[6];
glviewKEY433:
	local[4]= argv[0];
	local[5]= fqv[94];
	local[6]= fqv[21];
	local[7]= local[0];
	local[8]= fqv[22];
	local[9]= local[1];
	local[10]= fqv[23];
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)SUB1(ctx,1,local+11); /*1-*/
	local[11]= w;
	local[12]= fqv[24];
	local[13]= local[3];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,10,local+4); /*send*/
	local[4]= w;
	local[5]= argv[2];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(*ftab[36])(ctx,2,local+5,&ftab[36],fqv[95]); /*image::write-image-file*/
	local[0]= w;
glviewBLK429:
	ctx->vsp=local; return(local[0]);}

/*:getglimage*/
static pointer glviewM434glviewsurface_getglimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[96], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto glviewKEY436;
	local[0] = makeint((eusinteger_t)0L);
glviewKEY436:
	if (n & (1<<1)) goto glviewKEY437;
	local[1] = makeint((eusinteger_t)0L);
glviewKEY437:
	if (n & (1<<2)) goto glviewKEY438;
	local[2] = argv[0]->c.obj.iv[5];
glviewKEY438:
	if (n & (1<<3)) goto glviewKEY439;
	local[3] = argv[0]->c.obj.iv[6];
glviewKEY439:
	if (n & (1<<4)) goto glviewKEY440;
	local[7]= local[2];
	local[8]= local[3];
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)TIMES(ctx,3,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[37])(ctx,1,local+7,&ftab[37],fqv[97]); /*make-string*/
	local[4] = w;
glviewKEY440:
	if (n & (1<<5)) goto glviewKEY441;
	local[5] = NIL;
glviewKEY441:
	if (n & (1<<6)) goto glviewKEY442;
	local[6] = makeint((eusinteger_t)1028L);
glviewKEY442:
	local[7]= loadglobal(fqv[98]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= local[7];
	local[9]= fqv[99];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= local[4];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,5,local+8); /*send*/
	w = local[7];
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[91];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= local[6];
	ctx->vsp=local+9;
	w=(*ftab[38])(ctx,1,local+8,&ftab[38],fqv[100]); /*glreadbuffer*/
	local[8]= makeint((eusinteger_t)3333L);
	local[9]= makeint((eusinteger_t)1L);
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,2,local+8,&ftab[13],fqv[52]); /*glpixelstorei*/
	local[8]= local[0];
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[3];
	local[12]= makeint((eusinteger_t)6407L);
	local[13]= makeint((eusinteger_t)5121L);
	local[14]= local[4];
	ctx->vsp=local+15;
	w=(*ftab[39])(ctx,7,local+8,&ftab[39],fqv[101]); /*glreadpixels*/
	if (local[5]==NIL) goto glviewIF443;
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(*ftab[40])(ctx,1,local+8,&ftab[40],fqv[102]); /*user::dvector2float-bytestring*/
	local[8]= w;
	local[9]= local[0];
	local[10]= local[1];
	local[11]= local[2];
	local[12]= local[3];
	local[13]= makeint((eusinteger_t)6402L);
	local[14]= makeint((eusinteger_t)5126L);
	local[15]= local[8];
	ctx->vsp=local+16;
	w=(*ftab[39])(ctx,7,local+9,&ftab[39],fqv[101]); /*glreadpixels*/
	local[9]= local[8];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(*ftab[41])(ctx,2,local+9,&ftab[41],fqv[103]); /*user::float-bytestring2dvector*/
	local[8]= w;
	goto glviewIF444;
glviewIF443:
	local[8]= NIL;
glviewIF444:
	local[8]= local[7];
	ctx->vsp=local+9;
	w=(*ftab[42])(ctx,1,local+8,&ftab[42],fqv[104]); /*transpose-image-rows*/
	w = local[7];
	local[0]= w;
glviewBLK435:
	ctx->vsp=local; return(local[0]);}

/*:string*/
static pointer glviewM445glviewsurface_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto glviewENT448;}
	local[0]= loadglobal(fqv[105]);
glviewENT448:
glviewENT447:
	if (n>6) maerror();
	local[1]= argv[0];
	local[2]= fqv[91];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+1;
	w=(*ftab[28])(ctx,0,local+1,&ftab[28],fqv[78]); /*glpushmatrix*/
	local[1]= argv[0];
	local[2]= fqv[82];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[106];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	if (local[0]==local[1]) goto glviewIF449;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= fqv[106];
	ctx->vsp=local+4;
	w=(pointer)PUTPROP(ctx,3,local+1); /*putprop*/
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)32L);
	local[3]= makeint((eusinteger_t)96L);
	local[4]= makeint((eusinteger_t)1000L);
	w = makeint((eusinteger_t)32L);
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[4]= (pointer)((eusinteger_t)local[4] + (eusinteger_t)w);
	ctx->vsp=local+5;
	w=(*ftab[43])(ctx,4,local+1,&ftab[43],fqv[107]); /*glxusexfont*/
	local[1]= w;
	goto glviewIF450;
glviewIF449:
	local[1]= NIL;
glviewIF450:
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)ROUND(ctx,1,local+1); /*round*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= fqv[24];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)ROUND(ctx,1,local+3); /*round*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(*ftab[44])(ctx,2,local+1,&ftab[44],fqv[108]); /*glrasterpos2i*/
	local[1]= makeint((eusinteger_t)1000L);
	ctx->vsp=local+2;
	w=(*ftab[45])(ctx,1,local+1,&ftab[45],fqv[109]); /*gllistbase*/
	local[1]= argv[4];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)5121L);
	local[3]= argv[4];
	ctx->vsp=local+4;
	w=(*ftab[46])(ctx,3,local+1,&ftab[46],fqv[110]); /*glcalllists*/
	local[1]= argv[0];
	local[2]= fqv[39];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+1;
	w=(*ftab[30])(ctx,0,local+1,&ftab[30],fqv[80]); /*glpopmatrix*/
	local[1]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+2;
	w=(*ftab[26])(ctx,1,local+1,&ftab[26],fqv[75]); /*glmatrixmode*/
	local[0]= w;
glviewBLK446:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glviewCLO418(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(*ftab[47])(ctx,3,local+0,&ftab[47],fqv[111]); /*draw-face*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*geometry::default-viewsurface*/
static pointer glviewF139geometry__default_viewsurface(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
glviewRST452:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= (pointer)get_sym_func(fqv[112]);
	local[2]= loadglobal(fqv[113]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= fqv[32];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[0]= w;
glviewBLK451:
	ctx->vsp=local; return(local[0]);}

/*:draw-point*/
static pointer glviewM453glviewsurface_draw_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[114];
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
glviewBLK454:
	ctx->vsp=local; return(local[0]);}

/*:draw-line*/
static pointer glviewM455glviewsurface_draw_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[115];
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	local[4]= argv[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[3];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
glviewBLK456:
	ctx->vsp=local; return(local[0]);}

/*:draw-rectangle*/
static pointer glviewM457glviewsurface_draw_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0];
	local[1]= fqv[116];
	local[2]= argv[2];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= argv[2];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	local[4]= argv[3];
	local[5]= argv[4];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,6,local+0); /*send*/
	local[0]= w;
glviewBLK458:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer glviewM459glpixmapsurface_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
glviewRST461:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[117], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto glviewKEY462;
	local[1] = makeint((eusinteger_t)256L);
glviewKEY462:
	if (n & (1<<1)) goto glviewKEY463;
	local[2] = local[1];
glviewKEY463:
	if (n & (1<<2)) goto glviewKEY464;
	local[3] = local[1];
glviewKEY464:
	local[4]= NIL;
	local[5]= loadglobal(fqv[25]);
	local[6]= loadglobal(fqv[25]);
	ctx->vsp=local+7;
	w=(*ftab[6])(ctx,1,local+6,&ftab[6],fqv[26]); /*x:defaultscreen*/
	local[6]= w;
	local[7]= loadglobal(fqv[27]);
	ctx->vsp=local+8;
	w=(*ftab[7])(ctx,3,local+5,&ftab[7],fqv[28]); /*glxchoosevisual*/
	argv[0]->c.obj.iv[14] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto glviewIF465;
	local[5]= loadglobal(fqv[25]);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[48])(ctx,2,local+5,&ftab[48],fqv[118]); /*x:sync*/
	local[5]= fqv[119];
	local[6]= argv[0]->c.obj.iv[14];
	ctx->vsp=local+7;
	w=(*ftab[49])(ctx,2,local+5,&ftab[49],fqv[120]); /*warn*/
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto glviewBLK460;
	goto glviewIF466;
glviewIF465:
	local[5]= NIL;
glviewIF466:
	local[5]= loadglobal(fqv[25]);
	local[6]= loadglobal(fqv[25]);
	ctx->vsp=local+7;
	w=(*ftab[50])(ctx,1,local+6,&ftab[50],fqv[121]); /*x:defaultrootwindow*/
	local[6]= w;
	local[7]= local[2];
	local[8]= local[3];
	local[9]= argv[0]->c.obj.iv[14];
	local[10]= makeint((eusinteger_t)20L);
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	local[10]= fqv[34];
	ctx->vsp=local+11;
	w=(pointer)PEEK(ctx,2,local+9); /*system:peek*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[51])(ctx,5,local+5,&ftab[51],fqv[122]); /*x:createpixmap*/
	local[4] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto glviewIF467;
	local[5]= loadglobal(fqv[25]);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[48])(ctx,2,local+5,&ftab[48],fqv[118]); /*x:sync*/
	local[5]= fqv[123];
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(*ftab[49])(ctx,2,local+5,&ftab[49],fqv[120]); /*warn*/
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto glviewBLK460;
	goto glviewIF468;
glviewIF467:
	local[5]= NIL;
glviewIF468:
	local[5]= loadglobal(fqv[25]);
	local[6]= argv[0]->c.obj.iv[14];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(*ftab[52])(ctx,3,local+5,&ftab[52],fqv[124]); /*glxcreateglxpixmap*/
	argv[0]->c.obj.iv[2] = w;
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto glviewIF469;
	local[5]= loadglobal(fqv[25]);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[48])(ctx,2,local+5,&ftab[48],fqv[118]); /*x:sync*/
	local[5]= fqv[125];
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(*ftab[49])(ctx,2,local+5,&ftab[49],fqv[120]); /*warn*/
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto glviewBLK460;
	goto glviewIF470;
glviewIF469:
	local[5]= NIL;
glviewIF470:
	local[5]= (pointer)get_sym_func(fqv[30]);
	local[6]= argv[0];
	local[7]= *(ovafptr(argv[1],fqv[31]));
	local[8]= fqv[32];
	local[9]= local[0];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,5,local+5); /*apply*/
	local[0]= w;
glviewBLK460:
	ctx->vsp=local; return(local[0]);}

/*:getglimage*/
static pointer glviewM471glpixmapsurface_getglimage(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
glviewRST473:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[126], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto glviewKEY474;
	local[1] = makeint((eusinteger_t)1029L);
glviewKEY474:
	local[2]= (pointer)get_sym_func(fqv[30]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[31]));
	local[5]= fqv[94];
	local[6]= fqv[127];
	local[7]= local[1];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,7,local+2); /*apply*/
	local[0]= w;
glviewBLK472:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer glviewM475glpixmapsurface_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	local[0]= loadglobal(fqv[25]);
	local[1]= loadglobal(fqv[25]);
	ctx->vsp=local+2;
	w=(*ftab[50])(ctx,1,local+1,&ftab[50],fqv[121]); /*x:defaultrootwindow*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= argv[3];
	local[4]= argv[0]->c.obj.iv[14];
	local[5]= makeint((eusinteger_t)20L);
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	local[5]= fqv[34];
	ctx->vsp=local+6;
	w=(pointer)PEEK(ctx,2,local+4); /*system:peek*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[51])(ctx,5,local+0,&ftab[51],fqv[122]); /*x:createpixmap*/
	local[0]= w;
	storeglobal(fqv[128],w);
	local[0]= argv[0];
	local[1]= fqv[90];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
glviewBLK476:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer glviewM477glpixmapsurface_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[91];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0];
	local[1]= fqv[92];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
glviewBLK478:
	ctx->vsp=local; return(local[0]);}

/*:draw-one*/
static pointer glviewM479geometry_viewer_draw_one(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w = argv[2];
	if (!numberp(w)) goto glviewCON482;
	local[0]= NIL;
	goto glviewCON481;
glviewCON482:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)LISTP(ctx,1,local+0); /*listp*/
	if (w==NIL) goto glviewCON483;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON485;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	local[1]= local[0];
	if (fqv[129]!=local[1]) goto glviewIF486;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[115];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)ELT(ctx,2,local+3); /*elt*/
	local[3]= w;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[5]= w;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= w;
	goto glviewIF487;
glviewIF486:
	local[1]= local[0];
	if (fqv[130]!=local[1]) goto glviewIF488;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= fqv[131];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto glviewIF489;
glviewIF488:
	if (T==NIL) goto glviewIF490;
	local[1]= fqv[132];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto glviewIF491;
glviewIF490:
	local[1]= NIL;
glviewIF491:
glviewIF489:
glviewIF487:
	w = local[1];
	local[0]= w;
	goto glviewCON484;
glviewCON485:
	local[0]= NIL;
	local[1]= argv[2];
glviewWHL493:
	if (local[1]==NIL) goto glviewWHX494;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[133];
	local[4]= local[0];
	local[5]= argv[3];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,4,local+2); /*send*/
	goto glviewWHL493;
glviewWHX494:
	local[2]= NIL;
glviewBLK495:
	w = NIL;
	local[0]= w;
	goto glviewCON484;
glviewCON492:
	local[0]= NIL;
glviewCON484:
	goto glviewCON481;
glviewCON483:
	local[0]= argv[2];
	local[1]= fqv[134];
	ctx->vsp=local+2;
	w=(*ftab[53])(ctx,2,local+0,&ftab[53],fqv[135]); /*find-method*/
	if (w==NIL) goto glviewCON496;
	local[0]= argv[2];
	local[1]= fqv[134];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON496:
	local[0]= argv[2];
	local[1]= fqv[136];
	ctx->vsp=local+2;
	w=(*ftab[53])(ctx,2,local+0,&ftab[53],fqv[135]); /*find-method*/
	if (w==NIL) goto glviewCON497;
	local[0]= argv[2];
	local[1]= fqv[137];
	ctx->vsp=local+2;
	w=(*ftab[53])(ctx,2,local+0,&ftab[53],fqv[135]); /*find-method*/
	if (w==NIL) goto glviewIF498;
	local[0]= argv[2];
	local[1]= fqv[137];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto glviewIF499;
glviewIF498:
	local[0]= NIL;
glviewIF499:
	local[0]= argv[0];
	local[1]= fqv[133];
	local[2]= argv[2];
	local[3]= fqv[136];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON497:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[138]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON500;
	local[0]= argv[2];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON500:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[66]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON501;
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= fqv[139];
	local[2]= argv[2]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON501:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[140]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON502;
	local[0]= argv[0];
	local[1]= fqv[141];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON502:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[142]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON503;
	local[0]= argv[0];
	local[1]= fqv[143];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON503:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[40]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON504;
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(pointer)PRINT(ctx,1,local+0); /*print*/
	local[0]= argv[2];
	local[1]= fqv[48];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON504:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[144]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON505;
	local[0]= argv[2];
	local[1]= fqv[137];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= loadglobal(fqv[113]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewIF506;
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[54])(ctx,2,local+0,&ftab[54],fqv[145]); /*draw-body*/
	local[0]= w;
	goto glviewIF507;
glviewIF506:
	local[0]= argv[2];
	local[1]= fqv[139];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= fqv[146];
	local[4]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
glviewWHL508:
	if (local[2]==NIL) goto glviewWHX509;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[141];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	goto glviewWHL508;
glviewWHX509:
	local[3]= NIL;
glviewBLK510:
	w = NIL;
	local[0]= w;
glviewIF507:
	goto glviewCON481;
glviewCON505:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[147]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON511;
	local[0]= argv[2];
	local[1]= fqv[137];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= loadglobal(fqv[113]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewIF512;
	local[0]= argv[0];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[54])(ctx,2,local+0,&ftab[54],fqv[145]); /*draw-body*/
	local[0]= w;
	goto glviewIF513;
glviewIF512:
	local[0]= argv[2];
	local[1]= fqv[139];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= NIL;
	local[2]= argv[2];
	local[3]= fqv[148];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
glviewWHL514:
	if (local[2]==NIL) goto glviewWHX515;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= argv[0];
	local[4]= fqv[141];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,4,local+3); /*send*/
	goto glviewWHL514;
glviewWHX515:
	local[3]= NIL;
glviewBLK516:
	w = NIL;
	local[0]= w;
glviewIF513:
	goto glviewCON481;
glviewCON511:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[149]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON517;
	local[0]= argv[0];
	local[1]= fqv[150];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON517:
	local[0]= argv[2];
	local[1]= loadglobal(fqv[151]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON518;
	local[0]= NIL;
	local[1]= argv[2];
	local[2]= fqv[148];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
glviewWHL519:
	if (local[1]==NIL) goto glviewWHX520;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[141];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	goto glviewWHL519;
glviewWHX520:
	local[2]= NIL;
glviewBLK521:
	w = NIL;
	local[0]= w;
	goto glviewCON481;
glviewCON518:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[2]); /*float-vector-p*/
	if (w==NIL) goto glviewCON522;
	local[0]= argv[0];
	local[1]= fqv[152];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= argv[3];
	goto glviewCON481;
glviewCON522:
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[55])(ctx,1,local+0,&ftab[55],fqv[153]); /*coordinates-p*/
	if (w==NIL) goto glviewCON523;
	local[0]= argv[0];
	local[1]= fqv[154];
	local[2]= argv[2];
	local[3]= fqv[137];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON523:
	local[0]= fqv[155];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto glviewCON524;
	local[0]= argv[2];
	local[1]= loadglobal(fqv[155]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	if (w==NIL) goto glviewCON524;
	local[0]= argv[0];
	local[1]= fqv[156];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto glviewCON481;
glviewCON524:
	local[0]= NIL;
glviewCON481:
	w = local[0];
	local[0]= w;
glviewBLK480:
	ctx->vsp=local; return(local[0]);}

/*:draw-faces*/
static pointer glviewM525geometry_viewer_draw_faces(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto glviewENT529;}
	local[0]= NIL;
glviewENT529:
	if (n>=5) { local[1]=(argv[4]); goto glviewENT528;}
	local[1]= NIL;
glviewENT528:
glviewENT527:
	if (n>5) maerror();
	ctx->vsp=local+2;
	local[2]= makeclosure(codevec,quotevec,glviewCLO530,env,argv,local);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)MAPC(ctx,2,local+2); /*mapc*/
	local[0]= w;
glviewBLK526:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer glviewCLO530(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= NIL;
	local[2]= NIL;
	ctx->vsp=local+3;
	w=(*ftab[47])(ctx,3,local+0,&ftab[47],fqv[111]); /*draw-face*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*resetperspective*/
static pointer glviewF140resetperspective(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[75]); /*glmatrixmode*/
	ctx->vsp=local+0;
	w=(*ftab[27])(ctx,0,local+0,&ftab[27],fqv[76]); /*glloadidentity*/
	local[0]= argv[0];
	local[1]= fqv[157];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)10L);
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)VNORM(ctx,1,local+2); /*norm*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAX(ctx,2,local+1); /*max*/
	local[1]= w;
	local[2]= local[1];
	local[3]= argv[0];
	local[4]= fqv[158];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,2,local+2); /*scale*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)VPLUS(ctx,2,local+2); /*v+*/
	local[2]= w;
	local[3]= argv[0];
	local[4]= fqv[159];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[160];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[56])(ctx,1,local+4,&ftab[56],fqv[161]); /*rad2deg*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= loadglobal(fqv[162]);
	local[7]= loadglobal(fqv[163]);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[57])(ctx,1,local+4,&ftab[57],fqv[164]); /*gluperspectivefv*/
	local[4]= loadglobal(fqv[165]);
	local[5]= local[0];
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)CONCATENATE(ctx,4,local+4); /*concatenate*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[58])(ctx,1,local+4,&ftab[58],fqv[166]); /*glulookatfv*/
	local[0]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+1;
	w=(*ftab[26])(ctx,1,local+0,&ftab[26],fqv[75]); /*glmatrixmode*/
	local[0]= w;
glviewBLK531:
	ctx->vsp=local; return(local[0]);}

/*gldraw*/
static pointer glviewF141gldraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
glviewRST533:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	local[2]= loadglobal(fqv[167]);
	ctx->vsp=local+3;
	w=(pointer)DERIVEDP(ctx,2,local+1); /*derivedp*/
	if (w==NIL) goto glviewIF534;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	goto glviewIF535;
glviewIF534:
	local[1]= loadglobal(fqv[168]);
glviewIF535:
	local[2]= local[1];
	local[3]= fqv[169];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[1];
	local[4]= fqv[170];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)glviewF140resetperspective(ctx,2,local+2); /*resetperspective*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[59])(ctx,1,local+2,&ftab[59],fqv[171]); /*cls*/
	local[2]= (pointer)get_sym_func(fqv[172]);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= local[1]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)glviewF142swapb(ctx,1,local+2); /*swapb*/
	local[0]= w;
glviewBLK532:
	ctx->vsp=local; return(local[0]);}

/*swapb*/
static pointer glviewF142swapb(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto glviewENT538;}
	local[0]= loadglobal(fqv[173]);
glviewENT538:
glviewENT537:
	if (n>1) maerror();
	local[1]= local[0];
	local[2]= fqv[92];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0]= w;
glviewBLK536:
	ctx->vsp=local; return(local[0]);}

/*position-light*/
static pointer glviewF143position_light(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= local[0];
	if (fqv[174]!=local[1]) goto glviewIF540;
	local[1]= makeint((eusinteger_t)16384L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF541;
glviewIF540:
	local[1]= local[0];
	if (fqv[175]!=local[1]) goto glviewIF542;
	local[1]= makeint((eusinteger_t)16385L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF543;
glviewIF542:
	local[1]= local[0];
	if (fqv[176]!=local[1]) goto glviewIF544;
	local[1]= makeint((eusinteger_t)16386L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF545;
glviewIF544:
	local[1]= local[0];
	if (fqv[177]!=local[1]) goto glviewIF546;
	local[1]= makeint((eusinteger_t)16387L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF547;
glviewIF546:
	local[1]= local[0];
	if (fqv[178]!=local[1]) goto glviewIF548;
	local[1]= makeint((eusinteger_t)16388L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF549;
glviewIF548:
	local[1]= local[0];
	if (fqv[179]!=local[1]) goto glviewIF550;
	local[1]= makeint((eusinteger_t)16389L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF551;
glviewIF550:
	local[1]= local[0];
	if (fqv[180]!=local[1]) goto glviewIF552;
	local[1]= makeint((eusinteger_t)16390L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF553;
glviewIF552:
	local[1]= local[0];
	if (fqv[181]!=local[1]) goto glviewIF554;
	local[1]= makeint((eusinteger_t)16391L);
	local[2]= makeint((eusinteger_t)4611L);
	local[3]= argv[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,3,local+1,&ftab[4],fqv[17]); /*gllightfv*/
	local[1]= w;
	goto glviewIF555;
glviewIF554:
	if (T==NIL) goto glviewIF556;
	local[1]= NIL;
	local[2]= fqv[182];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)XFORMAT(ctx,3,local+1); /*format*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto glviewIF557;
glviewIF556:
	local[1]= NIL;
glviewIF557:
glviewIF555:
glviewIF553:
glviewIF551:
glviewIF549:
glviewIF547:
glviewIF545:
glviewIF543:
glviewIF541:
	w = local[1];
	local[0]= w;
glviewBLK539:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___glview(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[183];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w!=NIL) goto glviewIF558;
	local[0]= fqv[184];
	ctx->vsp=local+1;
	w=(*ftab[60])(ctx,1,local+0,&ftab[60],fqv[185]); /*make-package*/
	local[0]= w;
	goto glviewIF559;
glviewIF558:
	local[0]= NIL;
glviewIF559:
	local[0]= fqv[186];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto glviewIF560;
	local[0]= fqv[187];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[188],w);
	goto glviewIF561;
glviewIF560:
	local[0]= fqv[189];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
glviewIF561:
	local[0]= fqv[190];
	local[1]= fqv[191];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[193];
	local[1]= fqv[194];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[195];
	local[1]= fqv[196];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[197];
	local[1]= fqv[198];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[199];
	local[1]= fqv[200];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[201];
	local[1]= fqv[202];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[203];
	local[1]= fqv[204];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[205];
	local[1]= fqv[206];
	ctx->vsp=local+2;
	w=(*ftab[61])(ctx,2,local+0,&ftab[61],fqv[192]); /*require*/
	local[0]= fqv[207];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[163];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glviewIF562;
	local[0]= fqv[163];
	local[1]= fqv[208];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[163];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glviewIF564;
	local[0]= fqv[163];
	local[1]= fqv[209];
	local[2]= makeflt(3.0000000000000000000000e+04);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewIF565;
glviewIF564:
	local[0]= NIL;
glviewIF565:
	local[0]= fqv[163];
	goto glviewIF563;
glviewIF562:
	local[0]= NIL;
glviewIF563:
	local[0]= fqv[162];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glviewIF566;
	local[0]= fqv[162];
	local[1]= fqv[208];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[162];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glviewIF568;
	local[0]= fqv[162];
	local[1]= fqv[209];
	local[2]= makeflt(2.0000000000000000000000e+02);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewIF569;
glviewIF568:
	local[0]= NIL;
glviewIF569:
	local[0]= fqv[162];
	goto glviewIF567;
glviewIF566:
	local[0]= NIL;
glviewIF567:
	local[0]= fqv[45];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glviewIF570;
	local[0]= fqv[45];
	local[1]= fqv[208];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[45];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glviewIF572;
	local[0]= fqv[45];
	local[1]= fqv[209];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewIF573;
glviewIF572:
	local[0]= NIL;
glviewIF573:
	local[0]= fqv[45];
	goto glviewIF571;
glviewIF570:
	local[0]= NIL;
glviewIF571:
	local[0]= fqv[46];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glviewIF574;
	local[0]= fqv[46];
	local[1]= fqv[208];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[46];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glviewIF576;
	local[0]= fqv[46];
	local[1]= fqv[209];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewIF577;
glviewIF576:
	local[0]= NIL;
glviewIF577:
	local[0]= fqv[46];
	goto glviewIF575;
glviewIF574:
	local[0]= NIL;
glviewIF575:
	local[0]= fqv[47];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glviewIF578;
	local[0]= fqv[47];
	local[1]= fqv[208];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[47];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glviewIF580;
	local[0]= fqv[47];
	local[1]= fqv[209];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewIF581;
glviewIF580:
	local[0]= NIL;
glviewIF581:
	local[0]= fqv[47];
	goto glviewIF579;
glviewIF578:
	local[0]= NIL;
glviewIF579:
	local[0]= fqv[27];
	local[1]= fqv[208];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto glviewIF582;
	local[0]= fqv[27];
	local[1]= fqv[208];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[27];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto glviewIF584;
	local[0]= fqv[27];
	local[1]= fqv[209];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= makeint((eusinteger_t)8L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)9L);
	local[6]= makeint((eusinteger_t)1L);
	local[7]= makeint((eusinteger_t)10L);
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)5L);
	local[10]= makeint((eusinteger_t)12L);
	local[11]= makeint((eusinteger_t)1L);
	local[12]= makeint((eusinteger_t)0L);
	ctx->vsp=local+13;
	w=(pointer)MKINTVECTOR(ctx,11,local+2); /*integer-vector*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto glviewIF585;
glviewIF584:
	local[0]= NIL;
glviewIF585:
	local[0]= fqv[27];
	goto glviewIF583;
glviewIF582:
	local[0]= NIL;
glviewIF583:
	local[0]= fqv[210];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM144colormaterial_create,fqv[32],fqv[138],fqv[211]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM156colormaterial_ambient,fqv[41],fqv[138],fqv[212]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM168colormaterial_diffuse,fqv[42],fqv[138],fqv[213]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM180colormaterial_specular,fqv[43],fqv[138],fqv[214]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM192colormaterial_emission,fqv[215],fqv[138],fqv[216]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM204colormaterial_shininess,fqv[217],fqv[138],fqv[218]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM212colormaterial_transparency,fqv[219],fqv[138],fqv[220]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM220colormaterial_opengl,fqv[48],fqv[138],fqv[221]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM222lightsource_create,fqv[32],fqv[40],fqv[222]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM228lightsource_light_id,fqv[14],fqv[40],fqv[223]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM230lightsource_ambient,fqv[41],fqv[40],fqv[224]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM242lightsource_diffuse,fqv[42],fqv[40],fqv[225]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM254lightsource_specular,fqv[43],fqv[40],fqv[226]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM266lightsource_position,fqv[44],fqv[40],fqv[227]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM273lightsource_move,fqv[228],fqv[40],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM275lightsource_enable,fqv[230],fqv[40],fqv[231]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM277lightsource_disable,fqv[232],fqv[40],fqv[233]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM279lightsource_opengl,fqv[48],fqv[40],fqv[234]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM281glviewsurface_create,fqv[32],fqv[113],fqv[235]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM293glviewsurface_material,fqv[236],fqv[113],fqv[237]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM302glviewsurface_color,fqv[139],fqv[113],fqv[238]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM316glviewsurface_line_width,fqv[239],fqv[113],fqv[240]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM322glviewsurface_point_size,fqv[241],fqv[113],fqv[242]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM328glviewsurface_window,fqv[243],fqv[113],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM330glviewsurface_3d_mode,fqv[39],fqv[113],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM334glviewsurface_2d_mode,fqv[82],fqv[113],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM341glviewsurface_pop_mode,fqv[85],fqv[113],fqv[247]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM343glviewsurface_height,fqv[24],fqv[113],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM349glviewsurface_width,fqv[23],fqv[113],fqv[249]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM355glviewsurface_pos,fqv[250],fqv[113],fqv[251]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM357glviewsurface_x,fqv[21],fqv[113],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM363glviewsurface_y,fqv[22],fqv[113],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM369glviewsurface_clear,fqv[254],fqv[113],fqv[255]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM371glviewsurface_glflush,fqv[92],fqv[113],fqv[256]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM373glviewsurface_point,fqv[114],fqv[113],fqv[257]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM375glviewsurface_line,fqv[115],fqv[113],fqv[258]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM377glviewsurface_3d_point,fqv[259],fqv[113],fqv[260]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM389glviewsurface_3d_line,fqv[131],fqv[113],fqv[261]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM401glviewsurface_3d_lines,fqv[262],fqv[113],fqv[263]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM416glviewsurface_draw_faces,fqv[150],fqv[113],fqv[264]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM419glviewsurface_rectangle,fqv[116],fqv[113],fqv[265]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM421glviewsurface_makecurrent,fqv[91],fqv[113],fqv[266]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM423glviewsurface_redraw,fqv[267],fqv[113],fqv[268]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM426glviewsurface_flush,fqv[90],fqv[113],fqv[269]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM428glviewsurface_write_to_image_file,fqv[270],fqv[113],fqv[271]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM434glviewsurface_getglimage,fqv[94],fqv[113],fqv[272]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM445glviewsurface_string,fqv[273],fqv[113],fqv[274]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[275],module,glviewF139geometry__default_viewsurface,fqv[276]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM453glviewsurface_draw_point,fqv[277],fqv[113],fqv[278]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM455glviewsurface_draw_line,fqv[279],fqv[113],fqv[280]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM457glviewsurface_draw_rectangle,fqv[281],fqv[113],fqv[282]);
	local[0]= fqv[283];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[284];
	local[1]= fqv[209];
	local[2]= fqv[284];
	local[3]= fqv[285];
	local[4]= loadglobal(fqv[113]);
	local[5]= fqv[286];
	local[6]= fqv[287];
	local[7]= fqv[288];
	local[8]= NIL;
	local[9]= fqv[289];
	local[10]= NIL;
	local[11]= fqv[290];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[291];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[62])(ctx,13,local+2,&ftab[62],fqv[292]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM459glpixmapsurface_create,fqv[32],fqv[284],fqv[293]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM471glpixmapsurface_getglimage,fqv[94],fqv[284],fqv[294]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM475glpixmapsurface_resize,fqv[295],fqv[284],fqv[296]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM477glpixmapsurface_flush,fqv[90],fqv[284],fqv[297]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM479geometry_viewer_draw_one,fqv[133],fqv[167],fqv[298]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,glviewM525geometry_viewer_draw_faces,fqv[150],fqv[167],fqv[299]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[300],module,glviewF140resetperspective,fqv[301]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[302],module,glviewF141gldraw,fqv[303]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[304],module,glviewF142swapb,fqv[305]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[306],module,glviewF143position_light,fqv[307]);
	local[0]= fqv[308];
	local[1]= fqv[309];
	ctx->vsp=local+2;
	w=(*ftab[63])(ctx,2,local+0,&ftab[63],fqv[310]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<64; i++) ftab[i]=fcallx;
}
