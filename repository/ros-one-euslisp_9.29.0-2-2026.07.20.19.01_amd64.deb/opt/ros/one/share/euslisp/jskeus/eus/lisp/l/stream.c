/* ./stream.c :  entry=stream */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "stream.h"
#pragma init (register_stream)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___stream();
extern pointer build_quote_vector();
static int register_stream()
  { add_module_initializer("___stream", ___stream);}

static pointer streamF1091reset_stream();
static pointer streamF1092make_two_way_stream();
static pointer streamF1093make_msgq_input_stream();
static pointer streamF1094make_msgq_output_stream();
static pointer streamF1095make_string_input_stream();
static pointer streamF1096make_string_output_stream();
static pointer streamF1097get_output_stream_string();
static pointer streamF1098read_from_string();
static pointer streamF1099princ_to_string();
static pointer streamF1100prin1_to_string();
static pointer streamF1101make_socket_address();
static pointer streamF1102make_socket_port();
static pointer streamF1103make_server_socket_stream();
static pointer streamF1104connect_sigalarm_handler();
static pointer streamF1105make_client_socket_stream();
static pointer streamF1106make_dgram_socket();
static pointer streamF1107connect_server();
static pointer streamF1108select_stream();
static pointer streamF1109sigio_handler();
static pointer streamF1110make_broadcast_stream();
static pointer streamF1111read_buffer();
static pointer streamF1112write_buffer();

/*:instream*/
static pointer streamM1113io_stream_instream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1116;}
	local[0]= NIL;
streamENT1116:
streamENT1115:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[0]); /*input-stream-p*/
	if (w==NIL) goto streamIF1117;
	argv[0]->c.obj.iv[1] = local[0];
	local[1]= argv[0]->c.obj.iv[1];
	goto streamIF1118;
streamIF1117:
	local[1]= NIL;
streamIF1118:
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
streamBLK1114:
	ctx->vsp=local; return(local[0]);}

/*:outstream*/
static pointer streamM1119io_stream_outstream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1122;}
	local[0]= NIL;
streamENT1122:
streamENT1121:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[1]); /*output-stream-p*/
	if (w==NIL) goto streamIF1123;
	argv[0]->c.obj.iv[2] = local[0];
	local[1]= argv[0]->c.obj.iv[2];
	goto streamIF1124;
streamIF1123:
	local[1]= NIL;
streamIF1124:
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
streamBLK1120:
	ctx->vsp=local; return(local[0]);}

/*:infd*/
static pointer streamM1125io_stream_infd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[2];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
streamBLK1126:
	ctx->vsp=local; return(local[0]);}

/*:outfd*/
static pointer streamM1127io_stream_outfd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
streamBLK1128:
	ctx->vsp=local; return(local[0]);}

/*:in*/
static pointer streamM1129io_stream_in(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
streamRST1131:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[4]);
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
streamBLK1130:
	ctx->vsp=local; return(local[0]);}

/*:out*/
static pointer streamM1132io_stream_out(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
streamRST1134:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[4]);
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
streamBLK1133:
	ctx->vsp=local; return(local[0]);}

/*:flag*/
static pointer streamM1135io_stream_flag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[5];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
streamBLK1136:
	ctx->vsp=local; return(local[0]);}

/*:async*/
static pointer streamM1137io_stream_async(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[6];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
streamBLK1138:
	ctx->vsp=local; return(local[0]);}

/*:fname*/
static pointer streamM1139io_stream_fname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= fqv[7];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
streamBLK1140:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1141io_stream_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	argv[0]->c.obj.iv[2] = argv[3];
	w = argv[0];
	local[0]= w;
streamBLK1142:
	ctx->vsp=local; return(local[0]);}

/*:reset*/
static pointer streamM1143stream_reset(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1146;}
	local[0]= NIL;
streamENT1146:
streamENT1145:
	if (n>3) maerror();
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	if (local[0]==NIL) goto streamIF1147;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	goto streamIF1148;
streamIF1147:
	local[1]= makeint((eusinteger_t)0L);
streamIF1148:
	argv[0]->c.obj.iv[4] = local[1];
	w = argv[0];
	local[0]= w;
streamBLK1144:
	ctx->vsp=local; return(local[0]);}

/*:discard*/
static pointer streamM1149stream_discard(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1152;}
	local[0]= makeint((eusinteger_t)1L);
streamENT1152:
streamENT1151:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[4];
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAX(ctx,2,local+1); /*max*/
	argv[0]->c.obj.iv[3] = w;
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
streamBLK1150:
	ctx->vsp=local; return(local[0]);}

/*:count*/
static pointer streamM1153stream_count(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
streamBLK1154:
	ctx->vsp=local; return(local[0]);}

/*:tail*/
static pointer streamM1155stream_tail(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1158;}
	local[0]= NIL;
streamENT1158:
streamENT1157:
	if (n>3) maerror();
	if (local[0]==NIL) goto streamIF1159;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	argv[0]->c.obj.iv[4] = w;
	local[1]= argv[0]->c.obj.iv[4];
	goto streamIF1160;
streamIF1159:
	local[1]= NIL;
streamIF1160:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
streamBLK1156:
	ctx->vsp=local; return(local[0]);}

/*:chars-left*/
static pointer streamM1161stream_chars_left(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
streamBLK1162:
	ctx->vsp=local; return(local[0]);}

/*:tail-string*/
static pointer streamM1163stream_tail_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= argv[0]->c.obj.iv[4];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
streamBLK1164:
	ctx->vsp=local; return(local[0]);}

/*:buffer*/
static pointer streamM1165stream_buffer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1169;}
	local[0]= NIL;
streamENT1169:
	if (n>=4) { local[1]=(argv[3]); goto streamENT1168;}
	local[1]= NIL;
streamENT1168:
streamENT1167:
	if (n>4) maerror();
	if (local[1]==NIL) goto streamCON1171;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	local[2]= w;
	goto streamCON1170;
streamCON1171:
	w = local[0];
	if (!isstring(w)) goto streamCON1172;
	argv[0]->c.obj.iv[2] = local[0];
	local[2]= argv[0]->c.obj.iv[2];
	goto streamCON1170;
streamCON1172:
	w = local[0];
	if (!isint(w)) goto streamCON1173;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,1,local+2,&ftab[2],fqv[8]); /*make-string*/
	argv[0]->c.obj.iv[2] = w;
	local[2]= argv[0]->c.obj.iv[2];
	goto streamCON1170;
streamCON1173:
	local[2]= argv[0]->c.obj.iv[2];
	goto streamCON1170;
streamCON1174:
	local[2]= NIL;
streamCON1170:
	w = local[2];
	local[0]= w;
streamBLK1166:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1175stream_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto streamENT1179;}
	local[0]= NIL;
streamENT1179:
	if (n>=6) { local[1]=(argv[5]); goto streamENT1178;}
	local[1]= NIL;
streamENT1178:
streamENT1177:
	if (n>6) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	w = argv[3];
	if (!isstring(w)) goto streamIF1180;
	local[2]= argv[3];
	goto streamIF1181;
streamIF1180:
	local[2]= loadglobal(fqv[9]);
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
streamIF1181:
	argv[0]->c.obj.iv[2] = local[2];
	w = local[0];
	if (!isint(w)) goto streamIF1182;
	local[2]= local[0];
	goto streamIF1183;
streamIF1182:
	local[2]= makeint((eusinteger_t)0L);
streamIF1183:
	argv[0]->c.obj.iv[3] = local[2];
	w = local[1];
	if (!isint(w)) goto streamIF1184;
	local[2]= local[1];
	goto streamIF1185;
streamIF1184:
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
streamIF1185:
	argv[0]->c.obj.iv[4] = local[2];
	w = argv[0];
	local[0]= w;
streamBLK1176:
	ctx->vsp=local; return(local[0]);}

/*reset-stream*/
static pointer streamF1091reset_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[10];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
streamBLK1186:
	ctx->vsp=local; return(local[0]);}

/*:fd*/
static pointer streamM1187file_stream_fd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
streamBLK1188:
	ctx->vsp=local; return(local[0]);}

/*:instream*/
static pointer streamM1189file_stream_instream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	if (fqv[11]!=local[0]) goto streamIF1191;
	local[0]= argv[0];
	goto streamIF1192;
streamIF1191:
	local[0]= NIL;
streamIF1192:
	w = local[0];
	local[0]= w;
streamBLK1190:
	ctx->vsp=local; return(local[0]);}

/*:outstream*/
static pointer streamM1193file_stream_outstream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	if (fqv[12]!=local[0]) goto streamIF1195;
	local[0]= argv[0];
	goto streamIF1196;
streamIF1195:
	local[0]= NIL;
streamIF1196:
	w = local[0];
	local[0]= w;
streamBLK1194:
	ctx->vsp=local; return(local[0]);}

/*:infd*/
static pointer streamM1197file_stream_infd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	if (fqv[11]!=local[0]) goto streamIF1199;
	local[0]= argv[0]->c.obj.iv[5];
	goto streamIF1200;
streamIF1199:
	local[0]= NIL;
streamIF1200:
	w = local[0];
	local[0]= w;
streamBLK1198:
	ctx->vsp=local; return(local[0]);}

/*:outfd*/
static pointer streamM1201file_stream_outfd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	if (fqv[12]!=local[0]) goto streamIF1203;
	local[0]= argv[0]->c.obj.iv[5];
	goto streamIF1204;
streamIF1203:
	local[0]= NIL;
streamIF1204:
	w = local[0];
	local[0]= w;
streamBLK1202:
	ctx->vsp=local; return(local[0]);}

/*:fname*/
static pointer streamM1205file_stream_fname(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[6];
	local[0]= w;
streamBLK1206:
	ctx->vsp=local; return(local[0]);}

/*:flag*/
static pointer streamM1207file_stream_flag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)3L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
streamBLK1208:
	ctx->vsp=local; return(local[0]);}

/*:async*/
static pointer streamM1209file_stream_async(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]==NIL) goto streamCON1212;
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)8192L);
	ctx->vsp=local+4;
	w=(pointer)LOGIOR(ctx,2,local+2); /*logior*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)8L);
	ctx->vsp=local+2;
	w=(pointer)GETPID(ctx,0,local+2); /*unix:getpid*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
	goto streamCON1211;
streamCON1212:
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)8192L);
	ctx->vsp=local+4;
	w=(pointer)LOGNOT(ctx,1,local+3); /*lognot*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LOGAND(ctx,2,local+2); /*logand*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
	goto streamCON1211;
streamCON1213:
	local[0]= NIL;
streamCON1211:
	w = local[0];
	local[0]= w;
streamBLK1210:
	ctx->vsp=local; return(local[0]);}

/*:nonblock*/
static pointer streamM1214file_stream_nonblock(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]==NIL) goto streamCON1217;
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= loadglobal(fqv[13]);
	ctx->vsp=local+4;
	w=(pointer)LOGIOR(ctx,2,local+2); /*logior*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)8L);
	ctx->vsp=local+2;
	w=(pointer)GETPID(ctx,0,local+2); /*unix:getpid*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
	goto streamCON1216;
streamCON1217:
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= loadglobal(fqv[13]);
	ctx->vsp=local+4;
	w=(pointer)LOGNOT(ctx,1,local+3); /*lognot*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LOGAND(ctx,2,local+2); /*logand*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
	goto streamCON1216;
streamCON1218:
	local[0]= NIL;
streamCON1216:
	w = local[0];
	local[0]= w;
streamBLK1215:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer streamM1219file_stream_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1222;}
	local[0]= T;
streamENT1222:
streamENT1221:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= (pointer)get_sym_func(fqv[14]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[15]));
	local[5]= fqv[16];
	local[6]= local[0];
	local[7]= NIL;
	local[8]= fqv[17];
	local[9]= argv[0]->c.obj.iv[6];
	local[10]= argv[0]->c.obj.iv[1];
	local[11]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+12;
	w=(pointer)LENGTH(ctx,1,local+11); /*length*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,5,local+7); /*format*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,7,local+2); /*apply*/
	local[0]= w;
streamBLK1220:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1223file_stream_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<5) maerror();
	if (n>=6) { local[0]=(argv[5]); goto streamENT1226;}
	local[0]= makeint((eusinteger_t)128L);
streamENT1226:
streamENT1225:
	if (n>6) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[15]));
	local[3]= fqv[18];
	local[4]= argv[4];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	argv[0]->c.obj.iv[5] = argv[2];
	argv[0]->c.obj.iv[6] = argv[3];
	argv[0]->c.obj.iv[4] = makeint((eusinteger_t)0L);
	w = argv[0];
	local[0]= w;
streamBLK1224:
	ctx->vsp=local; return(local[0]);}

/*:read-bytes*/
static pointer streamM1227file_stream_read_bytes(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto streamENT1231;}
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[2])(ctx,1,local+0,&ftab[2],fqv[8]); /*make-string*/
	local[0]= w;
streamENT1231:
	if (n>=5) { local[1]=(argv[4]); goto streamENT1230;}
	local[1]= makeint((eusinteger_t)0L);
streamENT1230:
streamENT1229:
	if (n>5) maerror();
	local[2]= NIL;
	w = local[0];
	if (isstring(w)) goto streamIF1232;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto streamIF1232;
	local[3]= fqv[19];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto streamIF1233;
streamIF1232:
	local[3]= NIL;
streamIF1233:
	local[3]= argv[0];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[2] = w;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,1,local+3,&ftab[3],fqv[21]); /*plusp*/
	if (w==NIL) goto streamIF1234;
	local[3]= local[0];
	local[4]= argv[0];
	local[5]= fqv[22];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= fqv[23];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(*ftab[4])(ctx,4,local+3,&ftab[4],fqv[24]); /*replace*/
	local[3]= argv[2];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)MIN(ctx,2,local+3); /*min*/
	local[2] = w;
	local[3]= argv[0]->c.obj.iv[3];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	argv[0]->c.obj.iv[3] = w;
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[1] = w;
	local[3]= local[1];
	goto streamIF1235;
streamIF1234:
	local[3]= NIL;
streamIF1235:
streamWHL1236:
	local[3]= local[1];
	local[4]= argv[2];
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto streamWHX1237;
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= local[0];
	local[5]= argv[2];
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	local[6]= local[1];
	ctx->vsp=local+7;
	w=(pointer)UNIXREAD(ctx,4,local+3); /*unix:uread*/
	local[2] = w;
	local[3]= local[2];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)LSEQP(ctx,2,local+3); /*<=*/
	if (w==NIL) goto streamIF1239;
	local[3]= fqv[25];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto streamIF1240;
streamIF1239:
	local[3]= NIL;
streamIF1240:
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[1] = w;
	goto streamWHL1236;
streamWHX1237:
	local[3]= NIL;
streamBLK1238:
	w = local[0];
	local[0]= w;
streamBLK1228:
	ctx->vsp=local; return(local[0]);}

/*:read-bytes-eof*/
static pointer streamM1241file_stream_read_bytes_eof(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[20];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[21]); /*plusp*/
	if (w==NIL) goto streamIF1243;
	local[2]= argv[0];
	local[3]= fqv[22];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[0] = w;
	local[2]= argv[0];
	local[3]= fqv[26];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	goto streamIF1244;
streamIF1243:
	local[2]= NIL;
streamIF1244:
streamWHL1245:
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)UNIXREAD(ctx,2,local+2); /*unix:uread*/
	local[1] = w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,1,local+2,&ftab[3],fqv[21]); /*plusp*/
	if (w==NIL) goto streamWHX1246;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	local[2]= w;
	w = local[0];
	ctx->vsp=local+3;
	local[0] = cons(ctx,local[2],w);
	goto streamWHL1245;
streamWHX1246:
	local[2]= NIL;
streamBLK1247:
	local[2]= (pointer)get_sym_func(fqv[27]);
	local[3]= loadglobal(fqv[9]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)NREVERSE(ctx,1,local+4); /*nreverse*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,3,local+2); /*apply*/
	local[0]= w;
streamBLK1242:
	ctx->vsp=local; return(local[0]);}

/*make-two-way-stream*/
static pointer streamF1092make_two_way_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= loadglobal(fqv[28]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= local[0];
	local[2]= fqv[18];
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	w = local[0];
	local[0]= w;
streamBLK1248:
	ctx->vsp=local; return(local[0]);}

/*make-msgq-input-stream*/
static pointer streamF1093make_msgq_input_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1251;}
	local[0]= makeint((eusinteger_t)128L);
streamENT1251:
streamENT1250:
	if (n>2) maerror();
	local[1]= loadglobal(fqv[29]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[18];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MSGGET(ctx,1,local+4); /*unix:msgget*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[11];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	local[0]= w;
streamBLK1249:
	ctx->vsp=local; return(local[0]);}

/*make-msgq-output-stream*/
static pointer streamF1094make_msgq_output_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1254;}
	local[0]= makeint((eusinteger_t)128L);
streamENT1254:
streamENT1253:
	if (n>2) maerror();
	local[1]= loadglobal(fqv[29]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[18];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)MSGGET(ctx,1,local+4); /*unix:msgget*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[12];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	local[0]= w;
streamBLK1252:
	ctx->vsp=local; return(local[0]);}

/*make-string-input-stream*/
static pointer streamF1095make_string_input_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1258;}
	local[0]= NIL;
streamENT1258:
	if (n>=3) { local[1]=(argv[2]); goto streamENT1257;}
	local[1]= NIL;
streamENT1257:
streamENT1256:
	if (n>3) maerror();
	w = argv[0];
	if (isstring(w)) goto streamIF1259;
	local[2]= fqv[30];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,1,local+2); /*error*/
	local[2]= w;
	goto streamIF1260;
streamIF1259:
	local[2]= NIL;
streamIF1260:
	local[2]= loadglobal(fqv[31]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[18];
	local[5]= fqv[11];
	local[6]= argv[0];
	local[7]= local[0];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	argv[0] = w;
	w = argv[0];
	local[0]= w;
streamBLK1255:
	ctx->vsp=local; return(local[0]);}

/*make-string-output-stream*/
static pointer streamF1096make_string_output_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto streamENT1265;}
	local[0]= makeint((eusinteger_t)64L);
streamENT1265:
	if (n>=2) { local[1]=(argv[1]); goto streamENT1264;}
	local[1]= NIL;
streamENT1264:
	if (n>=3) { local[2]=(argv[2]); goto streamENT1263;}
	local[2]= NIL;
streamENT1263:
streamENT1262:
	if (n>3) maerror();
	local[3]= loadglobal(fqv[31]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[18];
	local[6]= fqv[12];
	local[7]= local[0];
	local[8]= local[1];
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,6,local+4); /*send*/
	w = local[3];
	local[0] = w;
	w = local[0];
	local[0]= w;
streamBLK1261:
	ctx->vsp=local; return(local[0]);}

/*with-input-from-string*/
static pointer streamF1266(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
streamRST1268:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[32];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[33];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= fqv[34];
	local[6]= fqv[35];
	local[7]= fqv[36];
	local[8]= fqv[37];
	local[9]= argv[0];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[38];
	local[8]= fqv[35];
	local[9]= fqv[36];
	local[10]= fqv[37];
	local[11]= argv[0];
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[39];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[34];
	local[7]= fqv[35];
	local[8]= fqv[40];
	local[9]= fqv[37];
	local[10]= argv[0];
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[38];
	local[9]= fqv[35];
	local[10]= fqv[40];
	local[11]= fqv[37];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,1,local+11); /*list*/
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[39];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	w = local[0];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
streamBLK1267:
	ctx->vsp=local; return(local[0]);}

/*with-output-to-string*/
static pointer streamF1269(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
streamRST1271:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= fqv[32];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	local[3]= fqv[41];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	ctx->vsp=local+3;
	local[2]= cons(ctx,local[2],w);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,1,local+2); /*list*/
	local[2]= w;
	local[3]= local[0];
	local[4]= fqv[42];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)APPEND(ctx,2,local+3); /*append*/
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
streamBLK1270:
	ctx->vsp=local; return(local[0]);}

/*get-output-stream-string*/
static pointer streamF1097get_output_stream_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[2];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
streamBLK1272:
	ctx->vsp=local; return(local[0]);}

/*read-from-string*/
static pointer streamF1098read_from_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1276;}
	local[0]= T;
streamENT1276:
	if (n>=3) { local[1]=(argv[2]); goto streamENT1275;}
	local[1]= NIL;
streamENT1275:
streamENT1274:
	if (n>3) maerror();
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)streamF1095make_string_input_stream(ctx,1,local+2); /*make-string-input-stream*/
	local[2]= w;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)READ(ctx,3,local+2); /*read*/
	local[0]= w;
streamBLK1273:
	ctx->vsp=local; return(local[0]);}

/*princ-to-string*/
static pointer streamF1099princ_to_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1279;}
	local[0]= makeint((eusinteger_t)16L);
streamENT1279:
streamENT1278:
	if (n>2) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)streamF1096make_string_output_stream(ctx,1,local+1); /*make-string-output-stream*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)PRINC(ctx,2,local+2); /*princ*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)streamF1097get_output_stream_string(ctx,1,local+2); /*get-output-stream-string*/
	local[0]= w;
streamBLK1277:
	ctx->vsp=local; return(local[0]);}

/*prin1-to-string*/
static pointer streamF1100prin1_to_string(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1282;}
	local[0]= makeint((eusinteger_t)16L);
streamENT1282:
streamENT1281:
	if (n>2) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)streamF1096make_string_output_stream(ctx,1,local+1); /*make-string-output-stream*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)PRIN1(ctx,2,local+2); /*prin1*/
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)streamF1097get_output_stream_string(ctx,1,local+2); /*get-output-stream-string*/
	local[0]= w;
streamBLK1280:
	ctx->vsp=local; return(local[0]);}

/*:domain*/
static pointer streamM1283socket_address_domain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
streamBLK1284:
	ctx->vsp=local; return(local[0]);}

/*:port*/
static pointer streamM1285socket_address_port(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)2L);
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[5])(ctx,1,local+0,&ftab[5],fqv[44]); /*unix::ntohs*/
	local[0]= w;
streamBLK1286:
	ctx->vsp=local; return(local[0]);}

/*:host*/
static pointer streamM1287socket_address_host(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= makeint((eusinteger_t)8L);
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
streamBLK1288:
	ctx->vsp=local; return(local[0]);}

/*:next-port*/
static pointer streamM1289socket_address_next_port(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[45];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[6])(ctx,1,local+0,&ftab[6],fqv[46]); /*unix::htons*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= fqv[43];
	ctx->vsp=local+4;
	w=(pointer)POKE(ctx,4,local+0); /*system:poke*/
	local[0]= w;
streamBLK1290:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer streamM1291socket_address_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1294;}
	local[0]= T;
streamENT1294:
streamENT1293:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= *(ovafptr(argv[1],fqv[15]));
	local[3]= fqv[16];
	local[4]= local[0];
	local[5]= NIL;
	local[6]= fqv[47];
	local[7]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)4L));
	  w=makeint(local[7]->c.str.chars[i]);}
	local[7]= w;
	local[8]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)5L));
	  w=makeint(local[8]->c.str.chars[i]);}
	local[8]= w;
	local[9]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)6L));
	  w=makeint(local[9]->c.str.chars[i]);}
	local[9]= w;
	local[10]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)7L));
	  w=makeint(local[10]->c.str.chars[i]);}
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[45];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)XFORMAT(ctx,7,local+5); /*format*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SENDMESSAGE(ctx,5,local+1); /*send-message*/
	local[0]= w;
streamBLK1292:
	ctx->vsp=local; return(local[0]);}

/*make-socket-address*/
static pointer streamF1101make_socket_address(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[48], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto streamKEY1296;
	local[0] = makeint((eusinteger_t)2L);
streamKEY1296:
	if (n & (1<<1)) goto streamKEY1297;
	local[1] = NIL;
streamKEY1297:
	if (n & (1<<2)) goto streamKEY1298;
	local[2] = fqv[49];
streamKEY1298:
	if (n & (1<<3)) goto streamKEY1299;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)GETSERVBYNAME(ctx,1,local+6); /*unix:getservbyname*/
	local[3] = w;
streamKEY1299:
	if (n & (1<<4)) goto streamKEY1300;
	local[6]= fqv[50];
	ctx->vsp=local+7;
	w=(pointer)GETENV(ctx,1,local+6); /*unix:getenv*/
	local[4] = w;
streamKEY1300:
	if (n & (1<<5)) goto streamKEY1301;
	local[5] = NIL;
streamKEY1301:
	local[6]= local[0];
	if (makeint((eusinteger_t)1L)!=local[6]) goto streamCON1303;
	local[6]= loadglobal(fqv[51]);
	local[7]= makeint((eusinteger_t)16L);
	local[8]= makeint((eusinteger_t)2L);
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)LENGTH(ctx,1,local+9); /*length*/
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[8]= (pointer)((eusinteger_t)local[8] + (eusinteger_t)w);
	ctx->vsp=local+9;
	w=(pointer)MAX(ctx,2,local+7); /*max*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= local[1];
	local[9]= fqv[52];
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,4,local+7,&ftab[4],fqv[24]); /*replace*/
	local[7]= local[0];
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= fqv[43];
	ctx->vsp=local+11;
	w=(pointer)POKE(ctx,4,local+7); /*system:poke*/
	w = local[6];
	local[6]= w;
	goto streamCON1302;
streamCON1303:
	local[6]= local[0];
	if (makeint((eusinteger_t)2L)!=local[6]) goto streamCON1304;
	local[6]= loadglobal(fqv[51]);
	local[7]= makeint((eusinteger_t)16L);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,2,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[0];
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= fqv[43];
	ctx->vsp=local+11;
	w=(pointer)POKE(ctx,4,local+7); /*system:poke*/
	if (local[4]==NIL) goto streamIF1305;
	local[7]= local[4];
	if (fqv[53]!=local[7]) goto streamIF1307;
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)MKINTVECTOR(ctx,4,local+7); /*integer-vector*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[4] = w;
	local[7]= local[4];
	goto streamIF1308;
streamIF1307:
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)GETHOSTBYNAME(ctx,1,local+7); /*unix:gethostbyname*/
	local[4] = w;
	local[7]= local[4];
streamIF1308:
	w = local[4];
	if (!numberp(w)) goto streamIF1309;
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SYSERRLIST(ctx,1,local+7); /*unix:syserrlist*/
	ctx->vsp=local+7;
	local[0]=w;
	goto streamBLK1295;
	goto streamIF1310;
streamIF1309:
	local[7]= NIL;
streamIF1310:
	local[7]= local[6];
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	local[9]= fqv[52];
	local[10]= makeint((eusinteger_t)4L);
	ctx->vsp=local+11;
	w=(*ftab[4])(ctx,4,local+7,&ftab[4],fqv[24]); /*replace*/
	local[7]= w;
	goto streamIF1306;
streamIF1305:
	local[7]= NIL;
streamIF1306:
	if (local[2]==NIL) goto streamIF1311;
	local[7]= local[2];
	local[8]= local[5];
	ctx->vsp=local+9;
	w=(pointer)GETSERVBYNAME(ctx,2,local+7); /*unix:getservbyname*/
	local[2] = w;
	w = local[2];
	if (!numberp(w)) goto streamIF1313;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,1,local+7); /*-*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SYSERRLIST(ctx,1,local+7); /*unix:syserrlist*/
	ctx->vsp=local+7;
	local[0]=w;
	goto streamBLK1295;
	goto streamIF1314;
streamIF1313:
	local[7]= NIL;
streamIF1314:
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= fqv[43];
	ctx->vsp=local+11;
	w=(pointer)POKE(ctx,4,local+7); /*system:poke*/
	local[7]= w;
	goto streamIF1312;
streamIF1311:
	local[7]= NIL;
streamIF1312:
	if (local[3]==NIL) goto streamIF1315;
	w = local[3];
	if (!isstring(w)) goto streamIF1317;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)GETSERVBYNAME(ctx,1,local+7); /*unix:getservbyname*/
	local[3] = w;
	local[7]= local[3];
	goto streamIF1318;
streamIF1317:
	local[7]= NIL;
streamIF1318:
	w = local[3];
	if (!isint(w)) goto streamIF1319;
	local[7]= local[3];
	local[8]= makeint((eusinteger_t)0L);
	ctx->vsp=local+9;
	w=(pointer)GREQP(ctx,2,local+7); /*>=*/
	if (w==NIL) goto streamIF1319;
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(*ftab[6])(ctx,1,local+7,&ftab[6],fqv[46]); /*unix::htons*/
	local[7]= w;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= fqv[43];
	ctx->vsp=local+11;
	w=(pointer)POKE(ctx,4,local+7); /*system:poke*/
	local[7]= w;
	goto streamIF1320;
streamIF1319:
	local[7]= NIL;
streamIF1320:
	goto streamIF1316;
streamIF1315:
	local[7]= NIL;
streamIF1316:
	w = local[6];
	local[6]= w;
	goto streamCON1302;
streamCON1304:
	local[6]= NIL;
streamCON1302:
	w = local[6];
	local[0]= w;
streamBLK1295:
	ctx->vsp=local; return(local[0]);}

/*:domain*/
static pointer streamM1321socket_port_domain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
streamBLK1322:
	ctx->vsp=local; return(local[0]);}

/*:address*/
static pointer streamM1323socket_port_address(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
streamBLK1324:
	ctx->vsp=local; return(local[0]);}

/*:id*/
static pointer streamM1325socket_port_id(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
streamBLK1326:
	ctx->vsp=local; return(local[0]);}

/*:fd*/
static pointer streamM1327socket_port_fd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
streamBLK1328:
	ctx->vsp=local; return(local[0]);}

/*:infd*/
static pointer streamM1329socket_port_infd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[0];
	local[0]= w;
streamBLK1330:
	ctx->vsp=local; return(local[0]);}

/*:listen*/
static pointer streamM1331socket_port_listen(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1334;}
	local[0]= makeint((eusinteger_t)3L);
streamENT1334:
streamENT1333:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LISTEN(ctx,2,local+1); /*unix:listen*/
	local[0]= w;
streamBLK1332:
	ctx->vsp=local; return(local[0]);}

/*:accept*/
static pointer streamM1335socket_port_accept(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	w=(pointer)ACCEPT(ctx,1,local+0); /*unix:accept*/
	local[0]= w;
streamBLK1336:
	ctx->vsp=local; return(local[0]);}

/*:flag*/
static pointer streamM1337socket_port_flag(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= makeint((eusinteger_t)3L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
streamBLK1338:
	ctx->vsp=local; return(local[0]);}

/*:async*/
static pointer streamM1339socket_port_async(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[2]==NIL) goto streamCON1342;
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)8192L);
	ctx->vsp=local+4;
	w=(pointer)LOGIOR(ctx,2,local+2); /*logior*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= makeint((eusinteger_t)8L);
	ctx->vsp=local+2;
	w=(pointer)GETPID(ctx,0,local+2); /*unix:getpid*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
	goto streamCON1341;
streamCON1342:
	local[0]= argv[0]->c.obj.iv[0];
	local[1]= makeint((eusinteger_t)4L);
	local[2]= argv[0];
	local[3]= fqv[5];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)8192L);
	ctx->vsp=local+4;
	w=(pointer)LOGNOT(ctx,1,local+3); /*lognot*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LOGAND(ctx,2,local+2); /*logand*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)FCNTL(ctx,3,local+0); /*unix:fcntl*/
	local[0]= w;
	goto streamCON1341;
streamCON1343:
	local[0]= NIL;
streamCON1341:
	w = local[0];
	local[0]= w;
streamBLK1340:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1344socket_port_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[1] = argv[2];
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[54];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SOCKET(ctx,3,local+1); /*unix:socket*/
	argv[0]->c.obj.iv[0] = w;
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto streamIF1346;
	w = argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	local[0]=w;
	goto streamBLK1345;
	goto streamIF1347;
streamIF1346:
	local[1]= NIL;
streamIF1347:
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(pointer)BIND(ctx,2,local+1); /*unix:bind*/
	local[0] = w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LESSP(ctx,2,local+1); /*<*/
	if (w==NIL) goto streamCON1349;
	local[1]= fqv[55];
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,1,local+1,&ftab[7],fqv[56]); /*unix:perror*/
	local[1]= local[0];
	goto streamCON1348;
streamCON1349:
	local[1]= argv[0];
	local[2]= fqv[57];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[0] = w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w==NIL) goto streamIF1351;
	local[1]= argv[0];
	goto streamIF1352;
streamIF1351:
	local[1]= local[0];
streamIF1352:
	goto streamCON1348;
streamCON1350:
	local[1]= NIL;
streamCON1348:
	w = local[1];
	local[0]= w;
streamBLK1345:
	ctx->vsp=local; return(local[0]);}

/*make-socket-port*/
static pointer streamF1102make_socket_port(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[58]);
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
	local[1]= fqv[18];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
streamBLK1353:
	ctx->vsp=local; return(local[0]);}

/*:domain*/
static pointer streamM1354socket_stream_domain(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[3];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= fqv[43];
	ctx->vsp=local+3;
	w=(pointer)PEEK(ctx,3,local+0); /*system:peek*/
	local[0]= w;
streamBLK1355:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1356socket_stream_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
	if (n>=5) { local[0]=(argv[4]); goto streamENT1359;}
	local[0]= makeint((eusinteger_t)128L);
streamENT1359:
streamENT1358:
	if (n>5) maerror();
	argv[0]->c.obj.iv[4] = argv[2];
	local[1]= loadglobal(fqv[29]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[18];
	local[4]= argv[2];
	local[5]= fqv[59];
	local[6]= fqv[11];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	argv[0]->c.obj.iv[1] = w;
	local[1]= loadglobal(fqv[29]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[18];
	local[4]= argv[2];
	local[5]= fqv[60];
	local[6]= fqv[12];
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,6,local+2); /*send*/
	w = local[1];
	argv[0]->c.obj.iv[2] = w;
	argv[0]->c.obj.iv[3] = argv[3];
	w = argv[0];
	local[0]= w;
streamBLK1357:
	ctx->vsp=local; return(local[0]);}

/*make-server-socket-stream*/
static pointer streamF1103make_server_socket_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1362;}
	local[0]= makeint((eusinteger_t)512L);
streamENT1362:
streamENT1361:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[61];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
	w = local[1];
	if (!numberp(w)) goto streamIF1363;
	local[2]= local[1];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto streamIF1363;
	w = local[1];
	ctx->vsp=local+2;
	local[0]=w;
	goto streamBLK1360;
	goto streamIF1364;
streamIF1363:
	local[2]= NIL;
streamIF1364:
	local[2]= loadglobal(fqv[62]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[18];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	local[6]= argv[0];
	local[7]= fqv[63];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,5,local+3); /*send*/
	w = local[2];
	local[0]= w;
streamBLK1360:
	ctx->vsp=local; return(local[0]);}

/*connect-sigalarm-handler*/
static pointer streamF1104connect_sigalarm_handler(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= fqv[64];
	local[1]= loadglobal(fqv[65]);
	ctx->vsp=local+2;
	w=(*ftab[8])(ctx,2,local+0,&ftab[8],fqv[66]); /*warn*/
	local[0]= w;
streamBLK1365:
	ctx->vsp=local; return(local[0]);}

/*make-client-socket-stream*/
static pointer streamF1105make_client_socket_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1369;}
	local[0]= makeint((eusinteger_t)5L);
streamENT1369:
	if (n>=3) { local[1]=(argv[2]); goto streamENT1368;}
	local[1]= makeint((eusinteger_t)512L);
streamENT1368:
streamENT1367:
	if (n>3) maerror();
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0];
	local[5]= fqv[54];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)1L);
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)SOCKET(ctx,3,local+4); /*unix:socket*/
	local[2] = w;
	local[4]= local[2];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto streamIF1370;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)UNIXCLOSE(ctx,1,local+4); /*unix:uclose*/
	w = local[2];
	ctx->vsp=local+4;
	local[0]=w;
	goto streamBLK1366;
	goto streamIF1371;
streamIF1370:
	local[4]= NIL;
streamIF1371:
	local[4]= makeint((eusinteger_t)14L);
	local[5]= fqv[67];
	ctx->vsp=local+6;
	w=(pointer)SIGNAL(ctx,2,local+4); /*unix:signal*/
	local[4]= w;
	storeglobal(fqv[68],w);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)ALARM(ctx,1,local+4); /*unix:alarm*/
	ctx->vsp=local+4;
	w = makeclosure(codevec,quotevec,streamUWP1372,env,argv,local);
	local[4]=(pointer)(ctx->protfp); local[5]=w;
	ctx->protfp=(struct protectframe *)(local+4);
	local[6]= local[2];
	local[7]= argv[0];
	ctx->vsp=local+8;
	w=(pointer)CONNECT(ctx,2,local+6); /*unix:connect*/
	local[3] = w;
	w = local[3];
	ctx->vsp=local+6;
	streamUWP1372(ctx,0,local+6,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)LESSP(ctx,2,local+4); /*<*/
	if (w==NIL) goto streamIF1373;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)UNIXCLOSE(ctx,1,local+4); /*unix:uclose*/
	w = local[3];
	ctx->vsp=local+4;
	local[0]=w;
	goto streamBLK1366;
	goto streamIF1374;
streamIF1373:
	local[4]= NIL;
streamIF1374:
	local[4]= loadglobal(fqv[62]);
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,1,local+4); /*instantiate*/
	local[4]= w;
	local[5]= local[4];
	local[6]= fqv[18];
	local[7]= local[2];
	local[8]= argv[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,5,local+5); /*send*/
	w = local[4];
	local[0]= w;
streamBLK1366:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer streamUWP1372(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(pointer)ALARM(ctx,1,local+0); /*unix:alarm*/
	local[0]= makeint((eusinteger_t)14L);
	local[1]= loadglobal(fqv[68]);
	ctx->vsp=local+2;
	w=(pointer)SIGNAL(ctx,2,local+0); /*unix:signal*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*make-dgram-socket*/
static pointer streamF1106make_dgram_socket(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[54];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)2L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SOCKET(ctx,3,local+1); /*unix:socket*/
	local[0] = w;
	local[1]= local[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)BIND(ctx,2,local+1); /*unix:bind*/
	w = local[0];
	local[0]= w;
streamBLK1375:
	ctx->vsp=local; return(local[0]);}

/*connect-server*/
static pointer streamF1107connect_server(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1378;}
	local[0]= makeint((eusinteger_t)5L);
streamENT1378:
streamENT1377:
	if (n>3) maerror();
	local[1]= fqv[54];
	local[2]= makeint((eusinteger_t)2L);
	local[3]= fqv[69];
	local[4]= argv[0];
	local[5]= fqv[45];
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)streamF1101make_socket_address(ctx,6,local+1); /*make-socket-address*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)streamF1105make_client_socket_stream(ctx,2,local+1); /*make-client-socket-stream*/
	local[0]= w;
streamBLK1376:
	ctx->vsp=local; return(local[0]);}

/*select-stream*/
static pointer streamF1108select_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto streamENT1381;}
	local[0]= makeflt(0.0000000000000000000000e+00);
streamENT1381:
streamENT1380:
	if (n>2) maerror();
	local[1]= makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= NIL;
	local[5]= NIL;
	local[6]= argv[0];
streamWHL1382:
	if (local[6]==NIL) goto streamWHX1383;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[6];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6] = (w)->c.cons.cdr;
	w = local[7];
	local[5] = w;
	w = local[5];
	if (!isint(w)) goto streamCON1386;
	local[7]= local[5];
	goto streamCON1385;
streamCON1386:
	local[7]= local[5];
	local[8]= fqv[2];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	goto streamCON1385;
streamCON1387:
	local[7]= NIL;
streamCON1385:
	local[4] = local[7];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= local[1];
	local[9]= local[4];
	local[10]= makeint((eusinteger_t)1L);
	ctx->vsp=local+11;
	w=(pointer)DPB(ctx,4,local+7); /*dpb*/
	local[1] = w;
	local[7]= loadglobal(fqv[70]);
	local[8]= local[4];
	w = local[5];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[8]); v=local[7];
	  v->c.vec.v[i]=w;}
	goto streamWHL1382;
streamWHX1383:
	local[7]= NIL;
streamBLK1384:
	w = NIL;
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)SELECT_READ(ctx,2,local+5); /*unix:select-read-fd*/
	local[1] = w;
streamWHL1388:
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto streamWHX1389;
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)LOGTEST(ctx,2,local+5); /*logtest*/
	if (w==NIL) goto streamIF1391;
	local[5]= loadglobal(fqv[70]);
	{ register eusinteger_t i=intval(local[3]);
	  w=(local[5]->c.vec.v[i]);}
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto streamIF1392;
streamIF1391:
	local[5]= NIL;
streamIF1392:
	local[5]= local[1];
	local[6]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+7;
	w=(pointer)ASH(ctx,2,local+5); /*ash*/
	local[1] = w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto streamWHL1388;
streamWHX1389:
	local[5]= NIL;
streamBLK1390:
	w = local[2];
	local[0]= w;
streamBLK1379:
	ctx->vsp=local; return(local[0]);}

/*sigio-handler*/
static pointer streamF1109sigio_handler(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= loadglobal(fqv[71]);
	ctx->vsp=local+2;
	w=(pointer)streamF1108select_stream(ctx,1,local+1); /*select-stream*/
	local[1]= w;
streamWHL1394:
	if (local[1]==NIL) goto streamWHX1395;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= loadglobal(fqv[72]);
	w = local[0];
	if (!isint(w)) goto streamIF1397;
	local[3]= local[0];
	goto streamIF1398;
streamIF1397:
	local[3]= local[0];
	local[4]= fqv[2];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
streamIF1398:
	{ register eusinteger_t i=intval(local[3]);
	  w=(local[2]->c.vec.v[i]);}
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)FUNCALL(ctx,2,local+2); /*funcall*/
	goto streamWHL1394;
streamWHX1395:
	local[2]= NIL;
streamBLK1396:
	w = NIL;
	local[0]= w;
streamBLK1393:
	ctx->vsp=local; return(local[0]);}

/*def-async*/
static pointer streamF1399(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
streamRST1401:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-1);
	local[1]= NIL;
	local[2]= NIL;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	if ((w)->c.cons.cdr==NIL) goto streamCON1403;
	ctx->vsp=local+3;
	w=(pointer)GENSYM(ctx,0,local+3); /*gensym*/
	local[2] = w;
	local[3]= fqv[73];
	local[4]= local[2];
	w = local[0];
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto streamCON1402;
streamCON1403:
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	local[0] = NIL;
	local[3]= local[0];
	goto streamCON1402;
streamCON1404:
	local[3]= NIL;
streamCON1402:
	local[3]= fqv[74];
	local[4]= fqv[75];
	local[5]= argv[0];
	local[6]= fqv[71];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	local[5]= fqv[76];
	local[6]= fqv[77];
	local[7]= fqv[37];
	local[8]= fqv[78];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	local[5]= cons(ctx,local[5],w);
	local[6]= fqv[34];
	local[7]= fqv[79];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)LIST(ctx,1,local+8); /*list*/
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	local[8]= fqv[74];
	local[9]= fqv[80];
	local[10]= argv[0];
	local[11]= fqv[81];
	local[12]= fqv[82];
	local[13]= fqv[80];
	local[14]= argv[0];
	local[15]= fqv[83];
	local[16]= fqv[84];
	ctx->vsp=local+17;
	w=(pointer)LIST(ctx,1,local+16); /*list*/
	ctx->vsp=local+16;
	w = cons(ctx,local[15],w);
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	local[14]= fqv[85];
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,1,local+14); /*list*/
	ctx->vsp=local+14;
	w = cons(ctx,local[13],w);
	ctx->vsp=local+13;
	local[12]= cons(ctx,local[12],w);
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	local[10]= fqv[80];
	local[11]= argv[0];
	local[12]= fqv[86];
	local[13]= fqv[87];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= fqv[4];
	local[10]= argv[0];
	local[11]= fqv[6];
	local[12]= fqv[88];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	w = cons(ctx,local[10],w);
	ctx->vsp=local+10;
	local[9]= cons(ctx,local[9],w);
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	w = cons(ctx,local[7],w);
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	local[7]= fqv[89];
	local[8]= fqv[90];
	local[9]= fqv[72];
	local[10]= fqv[34];
	local[11]= fqv[79];
	local[12]= argv[0];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,1,local+12); /*list*/
	ctx->vsp=local+12;
	local[11]= cons(ctx,local[11],w);
	local[12]= argv[0];
	local[13]= fqv[4];
	local[14]= argv[0];
	local[15]= fqv[2];
	ctx->vsp=local+16;
	w=(pointer)LIST(ctx,1,local+15); /*list*/
	ctx->vsp=local+15;
	w = cons(ctx,local[14],w);
	ctx->vsp=local+14;
	local[13]= cons(ctx,local[13],w);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	ctx->vsp=local+13;
	w = cons(ctx,local[12],w);
	ctx->vsp=local+12;
	w = cons(ctx,local[11],w);
	ctx->vsp=local+11;
	local[10]= cons(ctx,local[10],w);
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,1,local+10); /*list*/
	ctx->vsp=local+10;
	w = cons(ctx,local[9],w);
	ctx->vsp=local+9;
	local[8]= cons(ctx,local[8],w);
	local[9]= local[2];
	ctx->vsp=local+10;
	w=(pointer)LIST(ctx,1,local+9); /*list*/
	ctx->vsp=local+9;
	w = cons(ctx,local[8],w);
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	ctx->vsp=local+7;
	w = cons(ctx,local[6],w);
	ctx->vsp=local+6;
	w = cons(ctx,local[5],w);
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
streamBLK1400:
	ctx->vsp=local; return(local[0]);}

/*:destinations*/
static pointer streamM1405broadcast_stream_destinations(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1408;}
	local[0]= NIL;
streamENT1408:
streamENT1407:
	if (n>3) maerror();
	if (local[0]==NIL) goto streamIF1409;
	local[1]= local[0];
	w = argv[0]->c.obj.iv[5];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[5] = cons(ctx,local[1],w);
	local[1]= argv[0]->c.obj.iv[5];
	goto streamIF1410;
streamIF1409:
	local[1]= NIL;
streamIF1410:
	w = argv[0]->c.obj.iv[5];
	local[0]= w;
streamBLK1406:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1411broadcast_stream_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[15]));
	local[2]= fqv[18];
	local[3]= fqv[12];
	local[4]= makeint((eusinteger_t)256L);
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	argv[0]->c.obj.iv[5] = argv[2];
	w = argv[0];
	local[0]= w;
streamBLK1412:
	ctx->vsp=local; return(local[0]);}

/*:flush*/
static pointer streamM1413broadcast_stream_flush(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[3];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto streamIF1415;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	local[1] = w;
	local[2]= local[1];
	goto streamIF1416;
streamIF1415:
	local[1] = argv[0]->c.obj.iv[2];
	local[2]= local[1];
streamIF1416:
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	local[2]= NIL;
	local[3]= argv[0]->c.obj.iv[5];
streamWHL1417:
	if (local[3]==NIL) goto streamWHX1418;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[1];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)PRINC(ctx,2,local+4); /*princ*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)FINOUT(ctx,1,local+4); /*finish-output*/
	goto streamWHL1417;
streamWHX1418:
	local[4]= NIL;
streamBLK1419:
	w = NIL;
	w = T;
	local[0]= w;
streamBLK1414:
	ctx->vsp=local; return(local[0]);}

/*:close*/
static pointer streamM1420broadcast_stream_close(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0]->c.obj.iv[5];
streamWHL1422:
	if (local[1]==NIL) goto streamWHX1423;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.cdr;
	w = local[2];
	local[0] = w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)CLOSE(ctx,1,local+2); /*close*/
	goto streamWHL1422;
streamWHX1423:
	local[2]= NIL;
streamBLK1424:
	w = NIL;
	local[0]= w;
streamBLK1421:
	ctx->vsp=local; return(local[0]);}

/*make-broadcast-stream*/
static pointer streamF1110make_broadcast_stream(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
streamRST1426:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= local[0];
streamWHL1427:
	if (local[4]==NIL) goto streamWHX1428;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)STREAMP(ctx,1,local+5); /*streamp*/
	if (w==NIL) goto streamIF1430;
	local[5]= local[3];
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
	goto streamIF1431;
streamIF1430:
	local[5]= local[3];
	local[6]= fqv[91];
	local[7]= fqv[12];
	ctx->vsp=local+8;
	w=(*ftab[9])(ctx,3,local+5,&ftab[9],fqv[92]); /*open*/
	local[5]= w;
	w = local[2];
	ctx->vsp=local+6;
	local[2] = cons(ctx,local[5],w);
	local[5]= local[2];
streamIF1431:
	goto streamWHL1427;
streamWHX1428:
	local[5]= NIL;
streamBLK1429:
	w = NIL;
	local[3]= loadglobal(fqv[93]);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,1,local+3); /*instantiate*/
	local[3]= w;
	local[4]= local[3];
	local[5]= fqv[18];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	w = local[3];
	local[0]= w;
streamBLK1425:
	ctx->vsp=local; return(local[0]);}

/*read-buffer*/
static pointer streamF1111read_buffer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1434;}
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
streamENT1434:
streamENT1433:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[91];
	local[3]= fqv[11];
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,3,local+1,&ftab[9],fqv[92]); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,streamUWP1435,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= makeint((eusinteger_t)0L);
streamWHL1436:
	local[5]= local[4];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LESSP(ctx,2,local+5); /*<*/
	if (w==NIL) goto streamWHX1437;
	local[5]= local[4];
	local[6]= local[1];
	local[7]= fqv[94];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= argv[1];
	local[8]= local[0];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)UNIXREAD(ctx,4,local+6); /*unix:uread*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)PLUS(ctx,2,local+5); /*+*/
	local[4] = w;
	goto streamWHL1436;
streamWHX1437:
	local[5]= NIL;
streamBLK1438:
	w = local[5];
	w = argv[1];
	ctx->vsp=local+4;
	streamUWP1435(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
streamBLK1432:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer streamUWP1435(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*write-buffer*/
static pointer streamF1112write_buffer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1441;}
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
streamENT1441:
streamENT1440:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= fqv[91];
	local[3]= fqv[12];
	ctx->vsp=local+4;
	w=(*ftab[9])(ctx,3,local+1,&ftab[9],fqv[92]); /*open*/
	local[1]= w;
	ctx->vsp=local+2;
	w = makeclosure(codevec,quotevec,streamUWP1442,env,argv,local);
	local[2]=(pointer)(ctx->protfp); local[3]=w;
	ctx->protfp=(struct protectframe *)(local+2);
	local[4]= local[1];
	local[5]= argv[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)UNIXWRITE(ctx,3,local+4); /*unix:write*/
	ctx->vsp=local+4;
	streamUWP1442(ctx,0,local+4,ctx->protfp->cleaner);
	ctx->protfp=ctx->protfp->protlink;
	local[0]= w;
streamBLK1439:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer streamUWP1442(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	local[0]= env->c.clo.env2[1];
	ctx->vsp=local+1;
	w=(pointer)CLOSE(ctx,1,local+0); /*close*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer streamM1443port_selector_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
streamRST1445:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= loadglobal(fqv[95]);
	local[2]= fqv[96];
	local[3]= fqv[97];
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,3,local+1,&ftab[10],fqv[98]); /*make-array*/
	argv[0]->c.obj.iv[1] = w;
	local[1]= loadglobal(fqv[95]);
	local[2]= fqv[96];
	local[3]= fqv[97];
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,3,local+1,&ftab[10],fqv[98]); /*make-array*/
	argv[0]->c.obj.iv[3] = w;
	local[1]= loadglobal(fqv[95]);
	ctx->vsp=local+2;
	w=(*ftab[10])(ctx,1,local+1,&ftab[10],fqv[98]); /*make-array*/
	argv[0]->c.obj.iv[2] = w;
	local[1]= NIL;
	local[2]= local[0];
streamWHL1446:
	if (local[2]==NIL) goto streamWHX1447;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= (pointer)get_sym_func(fqv[4]);
	local[4]= argv[0];
	local[5]= fqv[99];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[6]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.cdr;
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,6,local+3); /*apply*/
	goto streamWHL1446;
streamWHX1447:
	local[3]= NIL;
streamBLK1448:
	w = NIL;
	w = argv[0];
	local[0]= w;
streamBLK1444:
	ctx->vsp=local; return(local[0]);}

/*:get-stream-fd*/
static pointer streamM1449port_selector_get_stream_fd(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)STREAMP(ctx,1,local+1); /*streamp*/
	if (w==NIL) goto streamCON1452;
	local[1]= argv[2];
	local[2]= fqv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto streamCON1451;
streamCON1452:
	w = argv[2];
	if (!numberp(w)) goto streamCON1453;
	local[1]= argv[2];
	goto streamCON1451;
streamCON1453:
	local[1]= argv[2];
	local[2]= fqv[94];
	ctx->vsp=local+3;
	w=(*ftab[11])(ctx,2,local+1,&ftab[11],fqv[100]); /*find-method*/
	if (w==NIL) goto streamCON1454;
	local[1]= argv[2];
	local[2]= fqv[94];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	goto streamCON1451;
streamCON1454:
	local[1]= fqv[101];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto streamCON1451;
streamCON1455:
	local[1]= NIL;
streamCON1451:
	local[0] = local[1];
	local[1]= local[0];
	local[2]= loadglobal(fqv[95]);
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	if (w==NIL) goto streamIF1456;
	local[1]= fqv[102];
	ctx->vsp=local+2;
	w=(pointer)SIGERROR(ctx,1,local+1); /*error*/
	local[1]= w;
	goto streamIF1457;
streamIF1456:
	local[1]= NIL;
streamIF1457:
	w = local[0];
	local[0]= w;
streamBLK1450:
	ctx->vsp=local; return(local[0]);}

/*:add-port*/
static pointer streamM1458port_selector_add_port(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<4) maerror();
streamRST1460:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-4);
	local[1]= argv[0];
	local[2]= fqv[103];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= local[1];
	local[4]= argv[2];
	local[5]= argv[3];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LIST_STAR(ctx,3,local+4); /*list**/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[0]= w;
streamBLK1459:
	ctx->vsp=local; return(local[0]);}

/*:remove-port*/
static pointer streamM1461port_selector_remove_port(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[103];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= local[0];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)ASET(ctx,3,local+1); /*aset*/
	local[0]= w;
streamBLK1462:
	ctx->vsp=local; return(local[0]);}

/*:streams*/
static pointer streamM1463port_selector_streams(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= loadglobal(fqv[95]);
streamWHL1465:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto streamWHX1466;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	if (w==NIL) goto streamIF1468;
	local[3]= argv[0]->c.obj.iv[2];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto streamIF1469;
streamIF1468:
	local[3]= NIL;
streamIF1469:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto streamWHL1465;
streamWHX1466:
	local[3]= NIL;
streamBLK1467:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)NREVERSE(ctx,1,local+1); /*nreverse*/
	local[0]= w;
streamBLK1464:
	ctx->vsp=local; return(local[0]);}

/*:fds*/
static pointer streamM1470port_selector_fds(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= loadglobal(fqv[95]);
streamWHL1472:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto streamWHX1473;
	local[3]= makeint((eusinteger_t)1L);
	local[4]= argv[0]->c.obj.iv[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)NUMEQUAL(ctx,2,local+3); /*=*/
	if (w==NIL) goto streamIF1475;
	local[3]= local[1];
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto streamIF1476;
streamIF1475:
	local[3]= NIL;
streamIF1476:
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto streamWHL1472;
streamWHX1473:
	local[3]= NIL;
streamBLK1474:
	w = NIL;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)NREVERSE(ctx,1,local+1); /*nreverse*/
	local[0]= w;
streamBLK1471:
	ctx->vsp=local; return(local[0]);}

/*:select*/
static pointer streamM1477port_selector_select(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1480;}
	local[0]= makeflt(9.9999999999999977795540e-02);
streamENT1480:
streamENT1479:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+6;
	w=(*ftab[4])(ctx,2,local+4,&ftab[4],fqv[24]); /*replace*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= NIL;
	local[6]= NIL;
	local[7]= local[0];
	ctx->vsp=local+8;
	w=(pointer)SELECT(ctx,4,local+4); /*unix:select*/
	local[1] = w;
	local[4]= local[1];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto streamIF1481;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= loadglobal(fqv[95]);
streamWHL1483:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto streamWHX1484;
	local[6]= argv[0]->c.obj.iv[3];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)NUMEQUAL(ctx,2,local+6); /*=*/
	if (w==NIL) goto streamIF1486;
	local[6]= argv[0]->c.obj.iv[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[2] = w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(*ftab[12])(ctx,1,local+6,&ftab[12],fqv[104]); /*functionp*/
	if (w==NIL) goto streamIF1488;
	local[6]= local[2];
	local[7]= local[3];
	ctx->vsp=local+8;
	w=(pointer)APPLY(ctx,2,local+6); /*apply*/
	local[6]= w;
	goto streamIF1489;
streamIF1488:
	local[6]= (pointer)get_sym_func(fqv[4]);
	local[7]= local[2];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,3,local+6); /*apply*/
	local[6]= w;
streamIF1489:
	goto streamIF1487;
streamIF1486:
	local[6]= NIL;
streamIF1487:
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto streamWHL1483;
streamWHX1484:
	local[6]= NIL;
streamBLK1485:
	w = T;
	local[4]= w;
	goto streamIF1482;
streamIF1481:
	local[4]= NIL;
streamIF1482:
	w = local[4];
	local[0]= w;
streamBLK1478:
	ctx->vsp=local; return(local[0]);}

/*:select-loop*/
static pointer streamM1490port_selector_select_loop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto streamENT1494;}
	local[0]= makeflt(9.9999999999999977795540e-02);
streamENT1494:
	if (n>=4) { local[1]=(argv[3]); goto streamENT1493;}
	local[1]= NIL;
streamENT1493:
streamENT1492:
	ctx->vsp=local+2;
	local[2]= minilist(ctx,&argv[n],n-4);
	{jmp_buf jb;
	w = fqv[105];
	ctx->vsp=local+3;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto streamCAT1495;}
streamWHL1496:
	if (T==NIL) goto streamWHX1497;
	local[9]= argv[0];
	local[10]= fqv[106];
	local[11]= local[0];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	if (local[1]==NIL) goto streamIF1499;
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,2,local+9); /*apply*/
	local[9]= w;
	goto streamIF1500;
streamIF1499:
	local[9]= NIL;
streamIF1500:
	goto streamWHL1496;
streamWHX1497:
	local[9]= NIL;
streamBLK1498:
	w = local[9];
streamCAT1495:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[0]= w;
streamBLK1491:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___stream(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[107];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto streamIF1501;
	local[0]= fqv[108];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[109],w);
	goto streamIF1502;
streamIF1501:
	local[0]= fqv[110];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
streamIF1502:
	local[0]= fqv[111];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1113io_stream_instream,fqv[112],fqv[28],fqv[113]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1119io_stream_outstream,fqv[114],fqv[28],fqv[115]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1125io_stream_infd,fqv[2],fqv[28],fqv[116]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1127io_stream_outfd,fqv[3],fqv[28],fqv[117]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1129io_stream_in,fqv[118],fqv[28],fqv[119]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1132io_stream_out,fqv[120],fqv[28],fqv[121]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1135io_stream_flag,fqv[5],fqv[28],fqv[122]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1137io_stream_async,fqv[6],fqv[28],fqv[123]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1139io_stream_fname,fqv[7],fqv[28],fqv[124]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1141io_stream_init,fqv[18],fqv[28],fqv[125]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1143stream_reset,fqv[10],fqv[31],fqv[126]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1149stream_discard,fqv[26],fqv[31],fqv[127]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1153stream_count,fqv[128],fqv[31],fqv[129]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1155stream_tail,fqv[130],fqv[31],fqv[131]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1161stream_chars_left,fqv[20],fqv[31],fqv[132]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1163stream_tail_string,fqv[22],fqv[31],fqv[133]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1165stream_buffer,fqv[134],fqv[31],fqv[135]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1175stream_init,fqv[18],fqv[31],fqv[136]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[137],module,streamF1091reset_stream,fqv[138]);
	local[0]= fqv[85];
	local[1]= fqv[139];
	local[2]= makeint((eusinteger_t)8192L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[83];
	local[1]= fqv[139];
	local[2]= makeint((eusinteger_t)3L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[81];
	local[1]= fqv[139];
	local[2]= makeint((eusinteger_t)4L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[86];
	local[1]= fqv[139];
	local[2]= makeint((eusinteger_t)8L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1187file_stream_fd,fqv[94],fqv[29],fqv[140]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1189file_stream_instream,fqv[112],fqv[29],fqv[141]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1193file_stream_outstream,fqv[114],fqv[29],fqv[142]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1197file_stream_infd,fqv[2],fqv[29],fqv[143]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1201file_stream_outfd,fqv[3],fqv[29],fqv[144]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1205file_stream_fname,fqv[7],fqv[29],fqv[145]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1207file_stream_flag,fqv[5],fqv[29],fqv[146]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1209file_stream_async,fqv[6],fqv[29],fqv[147]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1214file_stream_nonblock,fqv[148],fqv[29],fqv[149]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1219file_stream_prin1,fqv[16],fqv[29],fqv[150]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1223file_stream_init,fqv[18],fqv[29],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1227file_stream_read_bytes,fqv[152],fqv[29],fqv[153]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1241file_stream_read_bytes_eof,fqv[154],fqv[29],fqv[155]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[156],module,streamF1092make_two_way_stream,fqv[157]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[158],module,streamF1093make_msgq_input_stream,fqv[159]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[160],module,streamF1094make_msgq_output_stream,fqv[161]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[33],module,streamF1095make_string_input_stream,fqv[162]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[41],module,streamF1096make_string_output_stream,fqv[163]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[164],module,streamF1266,fqv[165]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[166],module,streamF1269,fqv[167]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[42],module,streamF1097get_output_stream_string,fqv[168]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[169],module,streamF1098read_from_string,fqv[170]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[171],module,streamF1099princ_to_string,fqv[172]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[173],module,streamF1100prin1_to_string,fqv[174]);
	local[0]= fqv[51];
	local[1]= fqv[175];
	local[2]= fqv[51];
	local[3]= fqv[176];
	local[4]= loadglobal(fqv[9]);
	local[5]= fqv[177];
	local[6]= fqv[39];
	local[7]= fqv[178];
	local[8]= NIL;
	local[9]= fqv[96];
	local[10]= fqv[179];
	local[11]= fqv[180];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[181];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,13,local+2,&ftab[13],fqv[182]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1283socket_address_domain,fqv[54],fqv[51],fqv[183]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1285socket_address_port,fqv[45],fqv[51],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1287socket_address_host,fqv[69],fqv[51],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1289socket_address_next_port,fqv[186],fqv[51],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1291socket_address_prin1,fqv[16],fqv[51],fqv[188]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[189],module,streamF1101make_socket_address,fqv[190]);
	local[0]= fqv[58];
	local[1]= fqv[175];
	local[2]= fqv[58];
	local[3]= fqv[176];
	local[4]= loadglobal(fqv[191]);
	local[5]= fqv[177];
	local[6]= fqv[192];
	local[7]= fqv[178];
	local[8]= NIL;
	local[9]= fqv[96];
	local[10]= NIL;
	local[11]= fqv[180];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[181];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,13,local+2,&ftab[13],fqv[182]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[193];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1321socket_port_domain,fqv[54],fqv[58],fqv[194]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1323socket_port_address,fqv[63],fqv[58],fqv[195]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1325socket_port_id,fqv[196],fqv[58],fqv[197]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1327socket_port_fd,fqv[94],fqv[58],fqv[198]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1329socket_port_infd,fqv[2],fqv[58],fqv[199]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1331socket_port_listen,fqv[57],fqv[58],fqv[200]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1335socket_port_accept,fqv[61],fqv[58],fqv[201]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1337socket_port_flag,fqv[5],fqv[58],fqv[202]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1339socket_port_async,fqv[6],fqv[58],fqv[203]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1344socket_port_init,fqv[18],fqv[58],fqv[204]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[205],module,streamF1102make_socket_port,fqv[206]);
	local[0]= fqv[62];
	local[1]= fqv[175];
	local[2]= fqv[62];
	local[3]= fqv[176];
	local[4]= loadglobal(fqv[28]);
	local[5]= fqv[177];
	local[6]= fqv[207];
	local[7]= fqv[178];
	local[8]= NIL;
	local[9]= fqv[96];
	local[10]= NIL;
	local[11]= fqv[180];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[181];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,13,local+2,&ftab[13],fqv[182]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1354socket_stream_domain,fqv[54],fqv[62],fqv[208]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1356socket_stream_init,fqv[18],fqv[62],fqv[209]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[210],module,streamF1103make_server_socket_stream,fqv[211]);
	local[0]= fqv[68];
	local[1]= fqv[212];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto streamIF1503;
	local[0]= fqv[68];
	local[1]= fqv[212];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[68];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto streamIF1505;
	local[0]= fqv[68];
	local[1]= fqv[175];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto streamIF1506;
streamIF1505:
	local[0]= NIL;
streamIF1506:
	local[0]= fqv[68];
	goto streamIF1504;
streamIF1503:
	local[0]= NIL;
streamIF1504:
	ctx->vsp=local+0;
	compfun(ctx,fqv[67],module,streamF1104connect_sigalarm_handler,fqv[213]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[214],module,streamF1105make_client_socket_stream,fqv[215]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[216],module,streamF1106make_dgram_socket,fqv[217]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[218],module,streamF1107connect_server,fqv[219]);
	local[0]= fqv[70];
	local[1]= fqv[212];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto streamIF1507;
	local[0]= fqv[70];
	local[1]= fqv[212];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[70];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto streamIF1509;
	local[0]= fqv[70];
	local[1]= fqv[175];
	local[2]= loadglobal(fqv[220]);
	local[3]= makeint((eusinteger_t)32L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto streamIF1510;
streamIF1509:
	local[0]= NIL;
streamIF1510:
	local[0]= fqv[70];
	goto streamIF1508;
streamIF1507:
	local[0]= NIL;
streamIF1508:
	ctx->vsp=local+0;
	compfun(ctx,fqv[221],module,streamF1108select_stream,fqv[222]);
	local[0]= fqv[71];
	local[1]= fqv[212];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto streamIF1511;
	local[0]= fqv[71];
	local[1]= fqv[212];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[71];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto streamIF1513;
	local[0]= fqv[71];
	local[1]= fqv[175];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto streamIF1514;
streamIF1513:
	local[0]= NIL;
streamIF1514:
	local[0]= fqv[71];
	goto streamIF1512;
streamIF1511:
	local[0]= NIL;
streamIF1512:
	local[0]= fqv[72];
	local[1]= fqv[212];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto streamIF1515;
	local[0]= fqv[72];
	local[1]= fqv[212];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[72];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto streamIF1517;
	local[0]= fqv[72];
	local[1]= fqv[175];
	local[2]= loadglobal(fqv[220]);
	local[3]= makeint((eusinteger_t)32L);
	ctx->vsp=local+4;
	w=(pointer)INSTANTIATE(ctx,2,local+2); /*instantiate*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto streamIF1518;
streamIF1517:
	local[0]= NIL;
streamIF1518:
	local[0]= fqv[72];
	goto streamIF1516;
streamIF1515:
	local[0]= NIL;
streamIF1516:
	ctx->vsp=local+0;
	compfun(ctx,fqv[78],module,streamF1109sigio_handler,fqv[223]);
	ctx->vsp=local+0;
	compmacro(ctx,fqv[224],module,streamF1399,fqv[225]);
	local[0]= fqv[93];
	local[1]= fqv[175];
	local[2]= fqv[93];
	local[3]= fqv[176];
	local[4]= loadglobal(fqv[31]);
	local[5]= fqv[177];
	local[6]= fqv[226];
	local[7]= fqv[178];
	local[8]= NIL;
	local[9]= fqv[96];
	local[10]= NIL;
	local[11]= fqv[180];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[181];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,13,local+2,&ftab[13],fqv[182]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1405broadcast_stream_destinations,fqv[227],fqv[93],fqv[228]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1411broadcast_stream_init,fqv[18],fqv[93],fqv[229]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1413broadcast_stream_flush,fqv[230],fqv[93],fqv[231]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1420broadcast_stream_close,fqv[232],fqv[93],fqv[233]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[234],module,streamF1110make_broadcast_stream,fqv[235]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[236],module,streamF1111read_buffer,fqv[237]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[238],module,streamF1112write_buffer,fqv[239]);
	local[0]= fqv[95];
	local[1]= fqv[175];
	local[2]= makeint((eusinteger_t)64L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= fqv[240];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[241];
	local[1]= fqv[175];
	local[2]= fqv[241];
	local[3]= fqv[176];
	local[4]= loadglobal(fqv[242]);
	local[5]= fqv[177];
	local[6]= fqv[243];
	local[7]= fqv[178];
	local[8]= NIL;
	local[9]= fqv[96];
	local[10]= NIL;
	local[11]= fqv[180];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[181];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,13,local+2,&ftab[13],fqv[182]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1443port_selector_init,fqv[18],fqv[241],fqv[244]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1449port_selector_get_stream_fd,fqv[103],fqv[241],fqv[245]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1458port_selector_add_port,fqv[99],fqv[241],fqv[246]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1461port_selector_remove_port,fqv[247],fqv[241],fqv[248]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1463port_selector_streams,fqv[249],fqv[241],fqv[250]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1470port_selector_fds,fqv[251],fqv[241],fqv[252]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1477port_selector_select,fqv[106],fqv[241],fqv[253]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,streamM1490port_selector_select_loop,fqv[105],fqv[241],fqv[254]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<14; i++) ftab[i]=fcallx;
}
