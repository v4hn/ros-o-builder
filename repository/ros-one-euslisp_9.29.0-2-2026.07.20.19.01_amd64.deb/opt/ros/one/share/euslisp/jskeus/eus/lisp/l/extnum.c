/* ./extnum.c :  entry=extnum */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "extnum.h"
#pragma init (register_extnum)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___extnum();
extern pointer build_quote_vector();
static int register_extnum()
  { add_module_initializer("___extnum", ___extnum);}


/*:init*/
static pointer extnumM3758ratio_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[0] = argv[2];
	argv[0]->c.obj.iv[1] = argv[3];
	w = argv[0];
	local[0]= w;
extnumBLK3759:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer extnumM3760complex_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	argv[0]->c.obj.iv[0] = argv[2];
	argv[0]->c.obj.iv[1] = argv[3];
	w = argv[0];
	local[0]= w;
extnumBLK3761:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___extnum(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	ctx->vsp=local+0;
	addcmethod(ctx,module,extnumM3758ratio_init,fqv[0],fqv[1],fqv[2]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,extnumM3760complex_init,fqv[0],fqv[3],fqv[4]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{}
