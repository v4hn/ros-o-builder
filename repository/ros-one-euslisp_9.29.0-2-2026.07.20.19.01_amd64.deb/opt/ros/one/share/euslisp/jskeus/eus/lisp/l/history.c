/* ./history.c :  entry=history */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "history.h"
#pragma init (register_history)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___history();
extern pointer build_quote_vector();
static int register_history()
  { add_module_initializer("___history", ___history);}

static pointer historyF4176refresh_line();
static pointer historyF4177line_head();
static pointer historyF4178line_left();
static pointer historyF4179line_right();
static pointer historyF4180line_delch();
static pointer historyF4181line_delch_previous();
static pointer historyF4182line_tail();
static pointer historyF4183line_refresh();
static pointer historyF4184line_insert();
static pointer historyF4185line_clear();
static pointer historyF4186line_null();
static pointer historyF4187line_abort();
static pointer historyF4188line_end();
static pointer historyF4189line_edit();
static pointer historyF4190new_history();
static pointer historyF4191add_history();
static pointer historyF4192print_history();
static pointer historyF4193h();
static pointer historyF4194get_history();
static pointer historyF4195_();

/*refresh-line*/
static pointer historyF4176refresh_line(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*cursor-pos*/
	ctx->vsp=local+0;
	w=(*ftab[1])(ctx,0,local+0,&ftab[1],fqv[1]); /*erase-eol*/
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
historyWHL4197:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto historyWHX4198;
	local[2]= argv[0];
	local[3]= local[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)ELT(ctx,2,local+2); /*elt*/
	local[2]= w;
	local[3]= loadglobal(fqv[2]);
	ctx->vsp=local+4;
	w=(pointer)WRTBYTE(ctx,2,local+2); /*write-byte*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto historyWHL4197;
historyWHX4198:
	local[2]= NIL;
historyBLK4199:
	w = NIL;
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*cursor-pos*/
	local[0]= w;
historyBLK4196:
	ctx->vsp=local; return(local[0]);}

/*line-head*/
static pointer historyF4177line_head(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*cursor-pos*/
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4200:
	ctx->vsp=local; return(local[0]);}

/*line-left*/
static pointer historyF4178line_left(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto historyIF4202;
	ctx->vsp=local+0;
	w=(*ftab[2])(ctx,0,local+0,&ftab[2],fqv[3]); /*cursor-backward*/
	local[0]= w;
	goto historyIF4203;
historyIF4202:
	local[0]= NIL;
historyIF4203:
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAX(ctx,2,local+1); /*max*/
	local[1]= w;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4201:
	ctx->vsp=local; return(local[0]);}

/*line-right*/
static pointer historyF4179line_right(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto historyIF4205;
	ctx->vsp=local+0;
	w=(*ftab[3])(ctx,0,local+0,&ftab[3],fqv[4]); /*cursor-forward*/
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[2] = w;
	local[0]= argv[2];
	goto historyIF4206;
historyIF4205:
	local[0]= NIL;
historyIF4206:
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4204:
	ctx->vsp=local; return(local[0]);}

/*line-delch*/
static pointer historyF4180line_delch(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[3];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	if (w==NIL) goto historyIF4208;
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[5]); /*list-delete*/
	argv[1] = w;
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[3] = w;
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)historyF4176refresh_line(ctx,3,local+0); /*refresh-line*/
	local[0]= w;
	goto historyIF4209;
historyIF4208:
	local[0]= NIL;
historyIF4209:
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4207:
	ctx->vsp=local; return(local[0]);}

/*line-delch-previous*/
static pointer historyF4181line_delch_previous(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)GREATERP(ctx,2,local+0); /*>*/
	if (w==NIL) goto historyIF4211;
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[2] = w;
	local[0]= argv[1];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[5]); /*list-delete*/
	argv[1] = w;
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	argv[3] = w;
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)historyF4176refresh_line(ctx,3,local+0); /*refresh-line*/
	local[0]= w;
	goto historyIF4212;
historyIF4211:
	local[0]= NIL;
historyIF4212:
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4210:
	ctx->vsp=local; return(local[0]);}

/*line-tail*/
static pointer historyF4182line_tail(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*cursor-pos*/
	local[0]= argv[1];
	local[1]= argv[3];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4213:
	ctx->vsp=local; return(local[0]);}

/*line-refresh*/
static pointer historyF4183line_refresh(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[1];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)historyF4176refresh_line(ctx,3,local+0); /*refresh-line*/
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*cursor-pos*/
	local[0]= argv[1];
	local[1]= argv[3];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4214:
	ctx->vsp=local; return(local[0]);}

/*line-insert*/
static pointer historyF4184line_insert(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[2];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(*ftab[5])(ctx,3,local+0,&ftab[5],fqv[6]); /*list-insert*/
	argv[1] = w;
	local[0]= argv[3];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[3] = w;
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)historyF4176refresh_line(ctx,3,local+0); /*refresh-line*/
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	argv[2] = w;
	ctx->vsp=local+0;
	w=(*ftab[3])(ctx,0,local+0,&ftab[3],fqv[4]); /*cursor-forward*/
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4215:
	ctx->vsp=local; return(local[0]);}

/*line-clear*/
static pointer historyF4185line_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= makeint((eusinteger_t)0L);
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[0]); /*cursor-pos*/
	ctx->vsp=local+0;
	w=(*ftab[1])(ctx,0,local+0,&ftab[1],fqv[1]); /*erase-eol*/
	local[0]= fqv[7];
	local[1]= makeint((eusinteger_t)0L);
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4216:
	ctx->vsp=local; return(local[0]);}

/*line-null*/
static pointer historyF4186line_null(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[1];
	local[1]= argv[2];
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,3,local+0); /*list*/
	local[0]= w;
historyBLK4217:
	ctx->vsp=local; return(local[0]);}

/*line-abort*/
static pointer historyF4187line_abort(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= fqv[8];
	w = NIL;
	ctx->vsp=local+1;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[0];
	local[0]= w;
historyBLK4218:
	ctx->vsp=local; return(local[0]);}

/*line-end*/
static pointer historyF4188line_end(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= fqv[8];
	w = argv[1];
	ctx->vsp=local+1;
	throw(ctx,vpop(),w);
	error(E_NOCATCHER,NULL);
	w = local[0];
	local[0]= w;
historyBLK4219:
	ctx->vsp=local; return(local[0]);}

/*line-edit*/
static pointer historyF4189line_edit(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[9]);
	ctx->vsp=local+2;
	w=(pointer)COERCE(ctx,2,local+0); /*coerce*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
	local[4]= local[3];
	local[5]= NIL;
	local[6]= T;
	local[7]= fqv[10];
	local[8]= argv[0];
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,3,local+6); /*format*/
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,0,local+6,&ftab[6],fqv[11]); /*tty-raw*/
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(*ftab[0])(ctx,1,local+6,&ftab[0],fqv[0]); /*cursor-pos*/
	ctx->vsp=local+6;
	w=(pointer)FINOUT(ctx,0,local+6); /*finish-output*/
	ctx->vsp=local+6;
	w=(pointer)READCH(ctx,0,local+6); /*read-char*/
	local[2] = w;
	{jmp_buf jb;
	w = fqv[8];
	ctx->vsp=local+6;
	mkcatchframe(ctx,w,(jmp_buf *)jb);
	if ((w=(pointer)eussetjmp(jb))!=0) { /*fsp=vsp;*/ goto historyCAT4221;}
historyWHL4222:
	if (T==NIL) goto historyWHX4223;
	local[12]= loadglobal(fqv[12]);
	local[13]= local[2];
	ctx->vsp=local+14;
	w=(pointer)AREF(ctx,2,local+12); /*aref*/
	local[12]= w;
	local[13]= local[2];
	local[14]= local[0];
	local[15]= local[4];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)FUNCALL(ctx,5,local+12); /*funcall*/
	local[1] = w;
	local[12]= loadglobal(fqv[2]);
	ctx->vsp=local+13;
	w=(pointer)FINOUT(ctx,1,local+12); /*finish-output*/
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.car;
	ctx->vsp=local+12;
	w=(pointer)READCH(ctx,0,local+12); /*read-char*/
	local[2] = w;
	goto historyWHL4222;
historyWHX4223:
	local[12]= NIL;
historyBLK4224:
	w = local[12];
historyCAT4221:
	if (w==(pointer)(1)) w=makeint(0);
	restorecatch(ctx);};
	local[1] = w;
	ctx->vsp=local+6;
	w=(*ftab[7])(ctx,0,local+6,&ftab[7],fqv[13]); /*tty-cooked*/
	if (local[1]==NIL) goto historyIF4225;
	local[6]= local[0];
	local[7]= loadglobal(fqv[14]);
	ctx->vsp=local+8;
	w=(pointer)COERCE(ctx,2,local+6); /*coerce*/
	local[6]= w;
	goto historyIF4226;
historyIF4225:
	local[6]= NIL;
historyIF4226:
	w = local[6];
	local[0]= w;
historyBLK4220:
	ctx->vsp=local; return(local[0]);}

/*new-history*/
static pointer historyF4190new_history(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(*ftab[8])(ctx,1,local+0,&ftab[8],fqv[15]); /*make-array*/
	local[0]= w;
	storeglobal(fqv[16],w);
	local[0]= argv[0];
	storeglobal(fqv[17],local[0]);
	local[0]= makeint((eusinteger_t)0L);
	storeglobal(fqv[18],local[0]);
	local[0]= loadglobal(fqv[16]);
	local[1]= makeint((eusinteger_t)0L);
	local[2]= loadglobal(fqv[19]);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= w;
historyBLK4227:
	ctx->vsp=local; return(local[0]);}

/*add-history*/
static pointer historyF4191add_history(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= loadglobal(fqv[19]);
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	storeglobal(fqv[19],w);
	local[0]= loadglobal(fqv[18]);
	ctx->vsp=local+1;
	w=(pointer)ADD1(ctx,1,local+0); /*1+*/
	local[0]= w;
	storeglobal(fqv[18],w);
	local[0]= loadglobal(fqv[18]);
	local[1]= loadglobal(fqv[17]);
	ctx->vsp=local+2;
	w=(pointer)GREQP(ctx,2,local+0); /*>=*/
	if (w==NIL) goto historyIF4229;
	local[0]= loadglobal(fqv[17]);
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	local[0]= w;
	storeglobal(fqv[18],w);
	local[0]= loadglobal(fqv[16]);
	local[1]= loadglobal(fqv[16]);
	local[2]= fqv[20];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= fqv[21];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(*ftab[9])(ctx,6,local+0,&ftab[9],fqv[22]); /*replace*/
	local[0]= w;
	goto historyIF4230;
historyIF4229:
	local[0]= NIL;
historyIF4230:
	local[0]= loadglobal(fqv[16]);
	local[1]= loadglobal(fqv[18]);
	local[2]= loadglobal(fqv[19]);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= fqv[23];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w==NIL) goto historyIF4231;
	local[0]= loadglobal(fqv[23]);
	local[1]= fqv[24];
	ctx->vsp=local+2;
	w=(*ftab[10])(ctx,2,local+0,&ftab[10],fqv[25]); /*find-method*/
	if (w==NIL) goto historyIF4231;
	local[0]= loadglobal(fqv[23]);
	local[1]= fqv[24];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto historyIF4232;
historyIF4231:
	local[0]= NIL;
historyIF4232:
	w = loadglobal(fqv[16]);
	local[0]= w;
historyBLK4228:
	ctx->vsp=local; return(local[0]);}

/*print-history*/
static pointer historyF4192print_history(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto historyENT4235;}
	local[0]= loadglobal(fqv[2]);
historyENT4235:
historyENT4234:
	if (n>1) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= loadglobal(fqv[18]);
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[4]= w;
historyWHL4236:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto historyWHX4237;
	local[5]= loadglobal(fqv[16]);
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ELT(ctx,2,local+5); /*elt*/
	local[2] = w;
	w = local[2];
	if (!iscons(w)) goto historyIF4239;
	local[5]= local[0];
	local[6]= fqv[26];
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[7]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[8]= (w)->c.cons.car;
	ctx->vsp=local+9;
	w=(pointer)XFORMAT(ctx,4,local+5); /*format*/
	local[5]= w;
	goto historyIF4240;
historyIF4239:
	local[5]= NIL;
historyIF4240:
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto historyWHL4236;
historyWHX4237:
	local[5]= NIL;
historyBLK4238:
	w = NIL;
	local[0]= w;
historyBLK4233:
	ctx->vsp=local; return(local[0]);}

/*h*/
static pointer historyF4193h(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=0) maerror();
	ctx->vsp=local+0;
	w=(pointer)historyF4192print_history(ctx,0,local+0); /*print-history*/
	local[0]= w;
historyBLK4241:
	ctx->vsp=local; return(local[0]);}

/*get-history*/
static pointer historyF4194get_history(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = argv[0];
	if (!numberp(w)) goto historyIF4243;
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)LSEQP(ctx,2,local+0); /*<=*/
	if (w==NIL) goto historyIF4245;
	local[0]= loadglobal(fqv[16]);
	local[1]= loadglobal(fqv[18]);
	local[2]= argv[0];
	local[3]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,3,local+1); /*+*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	goto historyIF4246;
historyIF4245:
	local[0]= loadglobal(fqv[16]);
	local[1]= loadglobal(fqv[18]);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0];
	local[4]= loadglobal(fqv[16]);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,3,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAX(ctx,2,local+2); /*max*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ELT(ctx,2,local+0); /*elt*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
historyIF4246:
	goto historyIF4244;
historyIF4243:
	local[0]= loadglobal(fqv[18]);
	ctx->vsp=local+1;
	w=(pointer)SUB1(ctx,1,local+0); /*1-*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,1,local+1,&ftab[11],fqv[14]); /*string*/
	local[1]= w;
	local[2]= NIL;
historyTAG4248:
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	ctx->vsp=local+5;
	w=(pointer)LSEQP(ctx,2,local+3); /*<=*/
	if (w==NIL) goto historyIF4249;
	w = NIL;
	ctx->vsp=local+3;
	local[0]=w;
	goto historyBLK4247;
	goto historyIF4250;
historyIF4249:
	local[3]= NIL;
historyIF4250:
	local[3]= local[1];
	local[4]= loadglobal(fqv[16]);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(*ftab[11])(ctx,1,local+4,&ftab[11],fqv[14]); /*string*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[12])(ctx,2,local+3,&ftab[12],fqv[27]); /*substringp*/
	if (w==NIL) goto historyIF4251;
	w = local[2];
	ctx->vsp=local+3;
	local[0]=w;
	goto historyBLK4242;
	goto historyIF4252;
historyIF4251:
	local[3]= NIL;
historyIF4252:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SUB1(ctx,1,local+3); /*1-*/
	local[3]= w;
	local[0] = local[3];
	w = NIL;
	ctx->vsp=local+3;
	goto historyTAG4248;
	w = NIL;
	local[0]= w;
historyBLK4247:
historyIF4244:
	w = local[0];
	local[0]= w;
historyBLK4242:
	ctx->vsp=local; return(local[0]);}

/*!*/
static pointer historyF4195_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto historyENT4255;}
	local[0]= makeint((eusinteger_t)0L);
historyENT4255:
historyENT4254:
	if (n>1) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)historyF4194get_history(ctx,1,local+1); /*get-history*/
	local[1]= w;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)historyF4189line_edit(ctx,1,local+2); /*line-edit*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TERPRI(ctx,0,local+3); /*terpri*/
	if (local[2]==NIL) goto historyCON4257;
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(pointer)historyF4191add_history(ctx,1,local+3); /*add-history*/
	local[3]= local[2];
	ctx->vsp=local+4;
	w=(*ftab[13])(ctx,1,local+3,&ftab[13],fqv[28]); /*make-string-input-stream*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[14])(ctx,1,local+3,&ftab[14],fqv[29]); /*evaluate-stream*/
	local[3]= w;
	goto historyCON4256;
historyCON4257:
	local[3]= NIL;
	goto historyCON4256;
historyCON4258:
	local[3]= NIL;
historyCON4256:
	w = local[3];
	local[0]= w;
historyBLK4253:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___history(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[30];
	local[1]= fqv[31];
	ctx->vsp=local+2;
	w=(*ftab[15])(ctx,2,local+0,&ftab[15],fqv[32]); /*require*/
	local[0]= fqv[33];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[12];
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto historyIF4259;
	local[0]= fqv[12];
	local[1]= fqv[34];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[12];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto historyIF4261;
	local[0]= fqv[12];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)128L);
	ctx->vsp=local+3;
	w=(*ftab[8])(ctx,1,local+2,&ftab[8],fqv[15]); /*make-array*/
	local[2]= w;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto historyIF4262;
historyIF4261:
	local[0]= NIL;
historyIF4262:
	local[0]= fqv[12];
	goto historyIF4260;
historyIF4259:
	local[0]= NIL;
historyIF4260:
	ctx->vsp=local+0;
	compfun(ctx,fqv[36],module,historyF4176refresh_line,fqv[37]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[38],module,historyF4177line_head,fqv[39]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[40],module,historyF4178line_left,fqv[41]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[42],module,historyF4179line_right,fqv[43]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[44],module,historyF4180line_delch,fqv[45]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[46],module,historyF4181line_delch_previous,fqv[47]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[48],module,historyF4182line_tail,fqv[49]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[50],module,historyF4183line_refresh,fqv[51]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[52],module,historyF4184line_insert,fqv[53]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[54],module,historyF4185line_clear,fqv[55]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[56],module,historyF4186line_null,fqv[57]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[58],module,historyF4187line_abort,fqv[59]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[60],module,historyF4188line_end,fqv[61]);
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)128L);
historyWHL4263:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto historyWHX4264;
	local[2]= loadglobal(fqv[12]);
	local[3]= local[0];
	local[4]= fqv[52];
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto historyWHL4263;
historyWHX4264:
	local[2]= NIL;
historyBLK4265:
	w = NIL;
	local[0]= makeint((eusinteger_t)0L);
	local[1]= makeint((eusinteger_t)32L);
historyWHL4266:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto historyWHX4267;
	local[2]= loadglobal(fqv[12]);
	local[3]= local[0];
	local[4]= fqv[56];
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto historyWHL4266;
historyWHX4267:
	local[2]= NIL;
historyBLK4268:
	w = NIL;
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)1L);
	local[2]= fqv[38];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)2L);
	local[2]= fqv[40];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)3L);
	local[2]= fqv[58];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)4L);
	local[2]= fqv[44];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)6L);
	local[2]= fqv[42];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)7L);
	local[2]= fqv[50];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)8L);
	local[2]= fqv[40];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)10L);
	local[2]= fqv[60];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)11L);
	local[2]= fqv[42];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)12L);
	local[2]= fqv[48];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)13L);
	local[2]= fqv[60];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)18L);
	local[2]= fqv[50];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)21L);
	local[2]= fqv[54];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	local[0]= loadglobal(fqv[12]);
	local[1]= makeint((eusinteger_t)127L);
	local[2]= fqv[46];
	ctx->vsp=local+3;
	w=(pointer)ASET(ctx,3,local+0); /*aset*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[8],module,historyF4189line_edit,fqv[62]);
	local[0]= fqv[17];
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto historyIF4269;
	local[0]= fqv[17];
	local[1]= fqv[34];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[17];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto historyIF4271;
	local[0]= fqv[17];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)50L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto historyIF4272;
historyIF4271:
	local[0]= NIL;
historyIF4272:
	local[0]= fqv[17];
	goto historyIF4270;
historyIF4269:
	local[0]= NIL;
historyIF4270:
	local[0]= fqv[16];
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto historyIF4273;
	local[0]= fqv[16];
	local[1]= fqv[34];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[16];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto historyIF4275;
	local[0]= fqv[16];
	local[1]= fqv[35];
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto historyIF4276;
historyIF4275:
	local[0]= NIL;
historyIF4276:
	local[0]= fqv[16];
	goto historyIF4274;
historyIF4273:
	local[0]= NIL;
historyIF4274:
	local[0]= fqv[18];
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto historyIF4277;
	local[0]= fqv[18];
	local[1]= fqv[34];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[18];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto historyIF4279;
	local[0]= fqv[18];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto historyIF4280;
historyIF4279:
	local[0]= NIL;
historyIF4280:
	local[0]= fqv[18];
	goto historyIF4278;
historyIF4277:
	local[0]= NIL;
historyIF4278:
	local[0]= fqv[19];
	local[1]= fqv[34];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)EQ(ctx,2,local+0); /*eql*/
	if (w==NIL) goto historyIF4281;
	local[0]= fqv[19];
	local[1]= fqv[34];
	local[2]= makeint((eusinteger_t)2L);
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[19];
	ctx->vsp=local+1;
	w=(pointer)BOUNDP(ctx,1,local+0); /*boundp*/
	if (w!=NIL) goto historyIF4283;
	local[0]= fqv[19];
	local[1]= fqv[35];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
	goto historyIF4284;
historyIF4283:
	local[0]= NIL;
historyIF4284:
	local[0]= fqv[19];
	goto historyIF4282;
historyIF4281:
	local[0]= NIL;
historyIF4282:
	ctx->vsp=local+0;
	compfun(ctx,fqv[63],module,historyF4190new_history,fqv[64]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[65],module,historyF4191add_history,fqv[66]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[67],module,historyF4192print_history,fqv[68]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[69],module,historyF4193h,fqv[70]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[71],module,historyF4194get_history,fqv[72]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[73],module,historyF4195_,fqv[74]);
	local[0]= fqv[75];
	local[1]= fqv[76];
	ctx->vsp=local+2;
	w=(*ftab[16])(ctx,2,local+0,&ftab[16],fqv[77]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<17; i++) ftab[i]=fcallx;
}
