char *makedate="Mon Jul 20 19:03:13 UTC 2026";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";
