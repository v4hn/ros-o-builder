/* ./hashtab.c :  entry=hashtab */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "hashtab.h"
#pragma init (register_hashtab)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___hashtab();
extern pointer build_quote_vector();
static int register_hashtab()
  { add_module_initializer("___hashtab", ___hashtab);}

static pointer hashtabF3431make_hash_table();
static pointer hashtabF3432gethash();
static pointer hashtabF3433sethash();
static pointer hashtabF3434remhash();
static pointer hashtabF3435hash_table_p();
static pointer hashtabF3436maphash();
static pointer hashtabF3437clrhash();

/*:size*/
static pointer hashtabM3438hash_table_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
hashtabBLK3439:
	ctx->vsp=local; return(local[0]);}

/*:find*/
static pointer hashtabM3440hash_table_find(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)MOD(ctx,2,local+0); /*mod*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)ABS(ctx,1,local+0); /*abs*/
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
hashtabWHL3442:
	if (T==NIL) goto hashtabWHX3443;
	local[3]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[3]->c.vec.v[i]);}
	local[1] = w;
	local[3]= argv[0]->c.obj.iv[5];
	local[4]= local[1];
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)FUNCALL(ctx,3,local+3); /*funcall*/
	if (w==NIL) goto hashtabIF3445;
	w = local[0];
	ctx->vsp=local+3;
	local[0]=w;
	goto hashtabBLK3441;
	goto hashtabIF3446;
hashtabIF3445:
	local[3]= NIL;
hashtabIF3446:
	local[3]= local[1];
	if (argv[0]->c.obj.iv[7]!=local[3]) goto hashtabIF3447;
	if (local[2]!=NIL) goto hashtabIF3449;
	local[2] = local[0];
	local[3]= local[2];
	goto hashtabIF3450;
hashtabIF3449:
	local[3]= NIL;
hashtabIF3450:
	local[3]= local[2];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)PLUS(ctx,2,local+3); /*+*/
	ctx->vsp=local+3;
	local[0]=w;
	goto hashtabBLK3441;
	goto hashtabIF3448;
hashtabIF3447:
	local[3]= NIL;
hashtabIF3448:
	local[3]= local[1];
	if (argv[0]->c.obj.iv[8]!=local[3]) goto hashtabIF3451;
	if (local[2]!=NIL) goto hashtabIF3453;
	local[2] = local[0];
	local[3]= local[2];
	goto hashtabIF3454;
hashtabIF3453:
	local[3]= NIL;
hashtabIF3454:
	goto hashtabIF3452;
hashtabIF3451:
	local[3]= NIL;
hashtabIF3452:
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[0] = w;
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+5;
	w=(pointer)GREQP(ctx,2,local+3); /*>=*/
	if (w==NIL) goto hashtabIF3455;
	local[0] = makeint((eusinteger_t)0L);
	local[3]= local[0];
	goto hashtabIF3456;
hashtabIF3455:
	local[3]= NIL;
hashtabIF3456:
	goto hashtabWHL3442;
hashtabWHX3443:
	local[3]= NIL;
hashtabBLK3444:
	w = NIL;
	local[0]= w;
hashtabBLK3441:
	ctx->vsp=local; return(local[0]);}

/*:get*/
static pointer hashtabM3457hash_table_get(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	if (w==NIL) goto hashtabIF3459;
	local[1]= argv[0]->c.obj.iv[9];
	goto hashtabIF3460;
hashtabIF3459:
	local[1]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[0]);
	  w=(local[1]->c.vec.v[i]);}
	local[1]= w;
hashtabIF3460:
	w = local[1];
	local[0]= w;
hashtabBLK3458:
	ctx->vsp=local; return(local[0]);}

/*:enter*/
static pointer hashtabM3461hash_table_enter(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)GREQP(ctx,2,local+1); /*>=*/
	if (w==NIL) goto hashtabIF3463;
	local[1]= argv[0]->c.obj.iv[3];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)GREATERP(ctx,2,local+1); /*>*/
	if (w==NIL) goto hashtabIF3465;
	local[1]= argv[0];
	local[2]= fqv[1];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= argv[0];
	local[2]= fqv[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[0] = w;
	local[1]= local[0];
	goto hashtabIF3466;
hashtabIF3465:
	local[1]= NIL;
hashtabIF3466:
	local[1]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+2;
	w=(pointer)ADD1(ctx,1,local+1); /*1+*/
	argv[0]->c.obj.iv[3] = w;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[0] = w;
	local[1]= local[0];
	goto hashtabIF3464;
hashtabIF3463:
	local[1]= NIL;
hashtabIF3464:
	local[1]= argv[0]->c.obj.iv[0];
	local[2]= local[0];
	w = argv[2];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.vec.v[i]=w;}
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= local[0];
	w = argv[3];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[2]); v=local[1];
	  v->c.vec.v[i]=w;}
	w = argv[3];
	local[0]= w;
hashtabBLK3462:
	ctx->vsp=local; return(local[0]);}

/*:delete*/
static pointer hashtabM3467hash_table_delete(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= local[0];
	local[3]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+4;
	w=(pointer)LESSP(ctx,2,local+2); /*<*/
	if (w==NIL) goto hashtabIF3469;
	local[2]= argv[0]->c.obj.iv[3];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	argv[0]->c.obj.iv[3] = w;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= local[0];
	w = argv[0]->c.obj.iv[8];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.vec.v[i]=w;}
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	w = NIL;
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.vec.v[i]=w;}
	local[2]= w;
	goto hashtabIF3470;
hashtabIF3469:
	local[2]= NIL;
hashtabIF3470:
	w = local[2];
	local[0]= w;
hashtabBLK3468:
	ctx->vsp=local; return(local[0]);}

/*:extend*/
static pointer hashtabM3471hash_table_extend(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)2L);
	{ eusinteger_t i,j;
		j=intval(argv[0]->c.obj.iv[2]); i=intval(local[0]);
		local[0]=(makeint(i * j));}
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[2]); /*make-array*/
	local[1]= w;
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[0])(ctx,1,local+2,&ftab[0],fqv[2]); /*make-array*/
	local[2]= w;
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
hashtabWHL3473:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto hashtabWHX3474;
	local[6]= local[1];
	local[7]= local[4];
	w = argv[0]->c.obj.iv[7];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[7]); v=local[6];
	  v->c.vec.v[i]=w;}
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto hashtabWHL3473;
hashtabWHX3474:
	local[6]= NIL;
hashtabBLK3475:
	w = NIL;
	local[3] = argv[0]->c.obj.iv[0];
	argv[0]->c.obj.iv[0] = local[1];
	local[1] = local[3];
	local[3] = argv[0]->c.obj.iv[1];
	argv[0]->c.obj.iv[1] = local[2];
	local[2] = local[3];
	local[3] = argv[0]->c.obj.iv[2];
	argv[0]->c.obj.iv[2] = local[0];
	local[0] = local[3];
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
hashtabWHL3476:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto hashtabWHX3477;
	local[6]= local[1];
	{ register eusinteger_t i=intval(local[4]);
	  w=(local[6]->c.vec.v[i]);}
	local[3] = w;
	local[6]= local[3];
	if (argv[0]->c.obj.iv[7]==local[6]) goto hashtabIF3479;
	local[6]= local[3];
	if (argv[0]->c.obj.iv[8]==local[6]) goto hashtabIF3479;
	local[6]= argv[0];
	local[7]= fqv[3];
	local[8]= local[3];
	local[9]= local[2];
	{ register eusinteger_t i=intval(local[4]);
	  w=(local[9]->c.vec.v[i]);}
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,4,local+6); /*send*/
	local[6]= w;
	goto hashtabIF3480;
hashtabIF3479:
	local[6]= NIL;
hashtabIF3480:
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto hashtabWHL3476;
hashtabWHX3477:
	local[6]= NIL;
hashtabBLK3478:
	w = NIL;
	w = argv[0];
	local[0]= w;
hashtabBLK3472:
	ctx->vsp=local; return(local[0]);}

/*:hash*/
static pointer hashtabM3481hash_table_hash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	ctx->vsp=local+1;
	w=(*ftab[1])(ctx,1,local+0,&ftab[1],fqv[4]); /*string*/
	argv[2] = w;
	local[0]= argv[0]->c.obj.iv[4];
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(*ftab[1])(ctx,1,local+1,&ftab[1],fqv[4]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)FUNCALL(ctx,2,local+0); /*funcall*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+2;
	w=(pointer)MOD(ctx,2,local+0); /*mod*/
	local[0]= w;
hashtabBLK3482:
	ctx->vsp=local; return(local[0]);}

/*:map*/
static pointer hashtabM3483hash_table_map(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[2];
hashtabWHL3485:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto hashtabWHX3486;
	local[4]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[4]->c.vec.v[i]);}
	local[0] = w;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3488;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3488;
	local[4]= argv[2];
	local[5]= local[0];
	local[6]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[6]->c.vec.v[i]);}
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)FUNCALL(ctx,3,local+4); /*funcall*/
	local[4]= w;
	goto hashtabIF3489;
hashtabIF3488:
	local[4]= NIL;
hashtabIF3489:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto hashtabWHL3485;
hashtabWHX3486:
	local[4]= NIL;
hashtabBLK3487:
	w = NIL;
	local[0]= w;
hashtabBLK3484:
	ctx->vsp=local; return(local[0]);}

/*:list-values*/
static pointer hashtabM3490hash_table_list_values(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[2];
hashtabWHL3492:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto hashtabWHX3493;
	local[4]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[4]->c.vec.v[i]);}
	local[0] = w;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3495;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3495;
	local[4]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[4]->c.vec.v[i]);}
	local[4]= w;
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto hashtabIF3496;
hashtabIF3495:
	local[4]= NIL;
hashtabIF3496:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto hashtabWHL3492;
hashtabWHX3493:
	local[4]= NIL;
hashtabBLK3494:
	w = NIL;
	w = local[1];
	local[0]= w;
hashtabBLK3491:
	ctx->vsp=local; return(local[0]);}

/*:list-keys*/
static pointer hashtabM3497hash_table_list_keys(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[2];
hashtabWHL3499:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto hashtabWHX3500;
	local[4]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[4]->c.vec.v[i]);}
	local[0] = w;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3502;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3502;
	local[4]= local[0];
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto hashtabIF3503;
hashtabIF3502:
	local[4]= NIL;
hashtabIF3503:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto hashtabWHL3499;
hashtabWHX3500:
	local[4]= NIL;
hashtabBLK3501:
	w = NIL;
	w = local[1];
	local[0]= w;
hashtabBLK3498:
	ctx->vsp=local; return(local[0]);}

/*:list*/
static pointer hashtabM3504hash_table_list(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[2];
hashtabWHL3506:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto hashtabWHX3507;
	local[4]= argv[0]->c.obj.iv[0];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[4]->c.vec.v[i]);}
	local[0] = w;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3509;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[8];
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w!=NIL) goto hashtabIF3509;
	local[4]= local[0];
	local[5]= argv[0]->c.obj.iv[1];
	{ register eusinteger_t i=intval(local[2]);
	  w=(local[5]->c.vec.v[i]);}
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[1];
	goto hashtabIF3510;
hashtabIF3509:
	local[4]= NIL;
hashtabIF3510:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto hashtabWHL3506;
hashtabWHX3507:
	local[4]= NIL;
hashtabBLK3508:
	w = NIL;
	w = local[1];
	local[0]= w;
hashtabBLK3505:
	ctx->vsp=local; return(local[0]);}

/*:hash-function*/
static pointer hashtabM3511hash_table_hash_function(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto hashtabENT3514;}
	local[0]= NIL;
hashtabENT3514:
hashtabENT3513:
	if (n>3) maerror();
	if (local[0]==NIL) goto hashtabIF3515;
	argv[0]->c.obj.iv[4] = local[0];
	local[1]= argv[0]->c.obj.iv[4];
	goto hashtabIF3516;
hashtabIF3515:
	local[1]= NIL;
hashtabIF3516:
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
hashtabBLK3512:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer hashtabM3517hash_table_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[2];
hashtabWHL3519:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto hashtabWHX3520;
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= local[0];
	w = argv[0]->c.obj.iv[7];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.vec.v[i]=w;}
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= local[0];
	w = NIL;
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[3]); v=local[2];
	  v->c.vec.v[i]=w;}
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto hashtabWHL3519;
hashtabWHX3520:
	local[2]= NIL;
hashtabBLK3521:
	w = NIL;
	w = argv[0];
	local[0]= w;
hashtabBLK3518:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer hashtabM3522hash_table_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto hashtabENT3525;}
	local[0]= T;
hashtabENT3525:
hashtabENT3524:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= (pointer)get_sym_func(fqv[5]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[6]));
	local[5]= fqv[7];
	local[6]= local[0];
	local[7]= NIL;
	local[8]= fqv[8];
	local[9]= argv[0]->c.obj.iv[3];
	local[10]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,4,local+7); /*format*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,7,local+2); /*apply*/
	local[0]= w;
hashtabBLK3523:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer hashtabM3526hash_table_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[9], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto hashtabKEY3528;
	local[0] = NIL;
hashtabKEY3528:
	if (n & (1<<1)) goto hashtabKEY3529;
	local[1] = makeint((eusinteger_t)10L);
hashtabKEY3529:
	if (n & (1<<2)) goto hashtabKEY3530;
	local[2] = (pointer)get_sym_func(fqv[10]);
hashtabKEY3530:
	if (n & (1<<3)) goto hashtabKEY3531;
	local[3] = makeflt(2.0000000000000000000000e+00);
hashtabKEY3531:
	if (n & (1<<4)) goto hashtabKEY3532;
	local[4] = (pointer)get_sym_func(fqv[11]);
hashtabKEY3532:
	argv[0]->c.obj.iv[2] = local[1];
	local[5]= loadglobal(fqv[12]);
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	argv[0]->c.obj.iv[0] = w;
	local[5]= loadglobal(fqv[12]);
	local[6]= argv[0]->c.obj.iv[2];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	argv[0]->c.obj.iv[1] = w;
	argv[0]->c.obj.iv[4] = local[4];
	argv[0]->c.obj.iv[5] = local[2];
	local[5]= fqv[13];
	ctx->vsp=local+6;
	w=(pointer)GENSYM(ctx,1,local+5); /*gensym*/
	argv[0]->c.obj.iv[7] = w;
	local[5]= fqv[14];
	ctx->vsp=local+6;
	w=(pointer)GENSYM(ctx,1,local+5); /*gensym*/
	argv[0]->c.obj.iv[8] = w;
	argv[0]->c.obj.iv[9] = local[0];
	argv[0]->c.obj.iv[3] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[6] = local[3];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= local[1];
hashtabWHL3533:
	local[7]= local[5];
	w = local[6];
	if ((eusinteger_t)local[7] >= (eusinteger_t)w) goto hashtabWHX3534;
	local[7]= argv[0]->c.obj.iv[0];
	local[8]= local[5];
	w = argv[0]->c.obj.iv[7];
	{ register eusinteger_t i; register pointer v;
	  i=intval(local[8]); v=local[7];
	  v->c.vec.v[i]=w;}
	local[7]= local[5];
	ctx->vsp=local+8;
	w=(pointer)ADD1(ctx,1,local+7); /*1+*/
	local[5] = w;
	goto hashtabWHL3533;
hashtabWHX3534:
	local[7]= NIL;
hashtabBLK3535:
	w = NIL;
	w = argv[0];
	local[0]= w;
hashtabBLK3527:
	ctx->vsp=local; return(local[0]);}

/*make-hash-table*/
static pointer hashtabF3431make_hash_table(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[15], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto hashtabKEY3537;
	local[0] = makeint((eusinteger_t)10L);
hashtabKEY3537:
	if (n & (1<<1)) goto hashtabKEY3538;
	local[1] = (pointer)get_sym_func(fqv[10]);
hashtabKEY3538:
	if (n & (1<<2)) goto hashtabKEY3539;
	local[2] = makeflt(1.6999999999999992894573e+00);
hashtabKEY3539:
	if (n & (1<<3)) goto hashtabKEY3540;
	local[3] = (pointer)get_sym_func(fqv[11]);
hashtabKEY3540:
	if (n & (1<<4)) goto hashtabKEY3541;
	local[4] = NIL;
hashtabKEY3541:
	local[5]= loadglobal(fqv[16]);
	ctx->vsp=local+6;
	w=(pointer)INSTANTIATE(ctx,1,local+5); /*instantiate*/
	local[5]= w;
	local[6]= local[5];
	local[7]= fqv[17];
	local[8]= fqv[18];
	local[9]= local[0];
	local[10]= fqv[19];
	local[11]= local[1];
	local[12]= fqv[20];
	local[13]= local[2];
	local[14]= fqv[21];
	local[15]= local[3];
	local[16]= fqv[22];
	local[17]= local[4];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,12,local+6); /*send*/
	w = local[5];
	local[0]= w;
hashtabBLK3536:
	ctx->vsp=local; return(local[0]);}

/*gethash*/
static pointer hashtabF3432gethash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[23];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hashtabBLK3542:
	ctx->vsp=local; return(local[0]);}

/*sethash*/
static pointer hashtabF3433sethash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[1];
	local[1]= fqv[3];
	local[2]= argv[0];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
hashtabBLK3543:
	ctx->vsp=local; return(local[0]);}

/*remhash*/
static pointer hashtabF3434remhash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[24];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hashtabBLK3544:
	ctx->vsp=local; return(local[0]);}

/*hash-table-p*/
static pointer hashtabF3435hash_table_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[16]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
hashtabBLK3545:
	ctx->vsp=local; return(local[0]);}

/*maphash*/
static pointer hashtabF3436maphash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[1];
	local[1]= fqv[25];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
hashtabBLK3546:
	ctx->vsp=local; return(local[0]);}

/*clrhash*/
static pointer hashtabF3437clrhash(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= fqv[26];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
hashtabBLK3547:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer hashtabM3548queue_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[0] = NIL;
	argv[0]->c.obj.iv[1] = NIL;
	w = argv[0];
	local[0]= w;
hashtabBLK3549:
	ctx->vsp=local; return(local[0]);}

/*:length*/
static pointer hashtabM3550queue_length(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
hashtabBLK3551:
	ctx->vsp=local; return(local[0]);}

/*:empty?*/
static pointer hashtabM3552queue_empty_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = ((argv[0]->c.obj.iv[0])==NIL?T:NIL);
	local[0]= w;
hashtabBLK3553:
	ctx->vsp=local; return(local[0]);}

/*:trim*/
static pointer hashtabM3554queue_trim(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= makeint((eusinteger_t)0L);
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
hashtabWHL3556:
	local[2]= local[0];
	w = local[1];
	if ((eusinteger_t)local[2] >= (eusinteger_t)w) goto hashtabWHX3557;
	local[2]= argv[0];
	local[3]= fqv[27];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[0] = w;
	goto hashtabWHL3556;
hashtabWHX3557:
	local[2]= NIL;
hashtabBLK3558:
	w = NIL;
	local[0]= w;
hashtabBLK3555:
	ctx->vsp=local; return(local[0]);}

/*:dequeue*/
static pointer hashtabM3559queue_dequeue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto hashtabENT3562;}
	local[0]= NIL;
hashtabENT3562:
hashtabENT3561:
	if (n>3) maerror();
	if (argv[0]->c.obj.iv[0]!=NIL) goto hashtabCON3564;
	if (local[0]==NIL) goto hashtabIF3565;
	local[1]= fqv[28];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SIGERROR(ctx,2,local+1); /*error*/
	local[1]= w;
	goto hashtabIF3566;
hashtabIF3565:
	local[1]= NIL;
hashtabIF3566:
	goto hashtabCON3563;
hashtabCON3564:
	local[1]= argv[0]->c.obj.iv[0];
	if (argv[0]->c.obj.iv[1]!=local[1]) goto hashtabCON3567;
	w=argv[0]->c.obj.iv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	argv[0]->c.obj.iv[0] = NIL;
	argv[0]->c.obj.iv[1] = NIL;
	w = local[1];
	local[1]= w;
	goto hashtabCON3563;
hashtabCON3567:
	w=argv[0]->c.obj.iv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	w=argv[0]->c.obj.iv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[0] = (w)->c.cons.cdr;
	w = local[1];
	local[1]= w;
	goto hashtabCON3563;
hashtabCON3568:
	local[1]= NIL;
hashtabCON3563:
	w = local[1];
	local[0]= w;
hashtabBLK3560:
	ctx->vsp=local; return(local[0]);}

/*:enqueue*/
static pointer hashtabM3569queue_enqueue(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[1]==NIL) goto hashtabCON3572;
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[2];
	w = NIL;
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	ctx->vsp=local+2;
	w=(pointer)RPLACD2(ctx,2,local+0); /*rplacd2*/
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0]->c.obj.iv[1] = (w)->c.cons.cdr;
	local[0]= argv[0]->c.obj.iv[1];
	goto hashtabCON3571;
hashtabCON3572:
	local[0]= argv[2];
	w = NIL;
	ctx->vsp=local+1;
	argv[0]->c.obj.iv[1] = cons(ctx,local[0],w);
	argv[0]->c.obj.iv[0] = argv[0]->c.obj.iv[1];
	local[0]= argv[0]->c.obj.iv[0];
	goto hashtabCON3571;
hashtabCON3573:
	local[0]= NIL;
hashtabCON3571:
	w = argv[2];
	local[0]= w;
hashtabBLK3570:
	ctx->vsp=local; return(local[0]);}

/*:search*/
static pointer hashtabM3574queue_search(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto hashtabENT3577;}
	local[0]= (pointer)get_sym_func(fqv[29]);
hashtabENT3577:
hashtabENT3576:
	if (n>4) maerror();
	local[1]= argv[2];
	local[2]= argv[0]->c.obj.iv[0];
	local[3]= fqv[19];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,4,local+1,&ftab[2],fqv[30]); /*find*/
	local[0]= w;
hashtabBLK3575:
	ctx->vsp=local; return(local[0]);}

/*:delete*/
static pointer hashtabM3578queue_delete(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto hashtabENT3582;}
	local[0]= (pointer)get_sym_func(fqv[29]);
hashtabENT3582:
	if (n>=5) { local[1]=(argv[4]); goto hashtabENT3581;}
	local[1]= makeint((eusinteger_t)1L);
hashtabENT3581:
hashtabENT3580:
	if (n>5) maerror();
	local[2]= argv[2];
	local[3]= argv[0]->c.obj.iv[0];
	local[4]= fqv[19];
	local[5]= local[0];
	local[6]= fqv[31];
	local[7]= local[1];
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,6,local+2,&ftab[3],fqv[32]); /*delete*/
	argv[0]->c.obj.iv[0] = w;
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(*ftab[4])(ctx,1,local+2,&ftab[4],fqv[33]); /*last*/
	argv[0]->c.obj.iv[1] = w;
	w = argv[0];
	local[0]= w;
hashtabBLK3579:
	ctx->vsp=local; return(local[0]);}

/*:first*/
static pointer hashtabM3583queue_first(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
hashtabBLK3584:
	ctx->vsp=local; return(local[0]);}

/*:last*/
static pointer hashtabM3585queue_last(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w=argv[0]->c.obj.iv[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
hashtabBLK3586:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___hashtab(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[34];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto hashtabIF3587;
	local[0]= fqv[35];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[36],w);
	goto hashtabIF3588;
hashtabIF3587:
	local[0]= fqv[37];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
hashtabIF3588:
	local[0]= fqv[38];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[16];
	local[1]= fqv[39];
	local[2]= fqv[16];
	local[3]= fqv[40];
	local[4]= loadglobal(fqv[41]);
	local[5]= fqv[42];
	local[6]= fqv[43];
	local[7]= fqv[44];
	local[8]= NIL;
	local[9]= fqv[45];
	local[10]= NIL;
	local[11]= fqv[18];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[46];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,13,local+2,&ftab[5],fqv[47]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= fqv[48];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3438hash_table_size,fqv[18],fqv[16],fqv[49]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3440hash_table_find,fqv[0],fqv[16],fqv[50]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3457hash_table_get,fqv[23],fqv[16],fqv[51]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3461hash_table_enter,fqv[3],fqv[16],fqv[52]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3467hash_table_delete,fqv[24],fqv[16],fqv[53]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3471hash_table_extend,fqv[1],fqv[16],fqv[54]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3481hash_table_hash,fqv[21],fqv[16],fqv[55]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3483hash_table_map,fqv[25],fqv[16],fqv[56]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3490hash_table_list_values,fqv[57],fqv[16],fqv[58]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3497hash_table_list_keys,fqv[59],fqv[16],fqv[60]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3504hash_table_list,fqv[61],fqv[16],fqv[62]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3511hash_table_hash_function,fqv[63],fqv[16],fqv[64]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3517hash_table_clear,fqv[26],fqv[16],fqv[65]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3522hash_table_prin1,fqv[7],fqv[16],fqv[66]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3526hash_table_init,fqv[17],fqv[16],fqv[67]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[68],module,hashtabF3431make_hash_table,fqv[69]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[70],module,hashtabF3432gethash,fqv[71]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[72],module,hashtabF3433sethash,fqv[73]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[74],module,hashtabF3434remhash,fqv[75]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[76],module,hashtabF3435hash_table_p,fqv[77]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[78],module,hashtabF3436maphash,fqv[79]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[80],module,hashtabF3437clrhash,fqv[81]);
	local[0]= fqv[82];
	local[1]= fqv[39];
	local[2]= fqv[82];
	local[3]= fqv[40];
	local[4]= loadglobal(fqv[83]);
	local[5]= fqv[42];
	local[6]= fqv[84];
	local[7]= fqv[44];
	local[8]= NIL;
	local[9]= fqv[45];
	local[10]= NIL;
	local[11]= fqv[18];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[46];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[5])(ctx,13,local+2,&ftab[5],fqv[47]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3548queue_init,fqv[17],fqv[82],fqv[85]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3550queue_length,fqv[86],fqv[82],fqv[87]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3552queue_empty_,fqv[88],fqv[82],fqv[89]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3554queue_trim,fqv[90],fqv[82],fqv[91]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3559queue_dequeue,fqv[27],fqv[82],fqv[92]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3569queue_enqueue,fqv[93],fqv[82],fqv[94]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3574queue_search,fqv[95],fqv[82],fqv[96]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3578queue_delete,fqv[24],fqv[82],fqv[97]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3583queue_first,fqv[98],fqv[82],fqv[99]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,hashtabM3585queue_last,fqv[100],fqv[82],fqv[101]);
	local[0]= fqv[102];
	local[1]= fqv[103];
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[104]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<7; i++) ftab[i]=fcallx;
}
