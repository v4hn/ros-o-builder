/* ./array.c :  entry=array */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "array.h"
#pragma init (register_array)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___array();
extern pointer build_quote_vector();
static int register_array()
  { add_module_initializer("___array", ___array);}

static pointer arrayF3223fill_initial_contents();
static pointer arrayF3224make_array();
static pointer arrayF3225array_total_size();
static pointer arrayF3226fill_pointer();
static pointer arrayF3227array_rank();
static pointer arrayF3228array_dimensions();
static pointer arrayF3229array_dimension();
static pointer arrayF3230array_vector();
static pointer arrayF3231row_major_aref();
static pointer arrayF3232list_dimensions();
static pointer arrayF3233read_array();
static pointer arrayF3234read_float_array();
static pointer arrayF3235read_integer_array();
static pointer arrayF3236float_vector_p();
static pointer arrayF3237integer_vector_p();
static pointer arrayF3238bit_vector_p();
static pointer arrayF3239matrixp();
static pointer arrayF3240make_matrix();
static pointer arrayF3241matrix_row();
static pointer arrayF3242matrix_column();
static pointer arrayF3243set_matrix_row();
static pointer arrayF3244set_matrix_column();
static pointer arrayF3245replace_matrix();
static pointer arrayF3246copy_matrix();
static pointer arrayF3247scale_matrix();
static pointer arrayF3248matrix();
static pointer arrayF3249acos();
static pointer arrayF3250asin();
static pointer arrayF3251unit_matrix();
static pointer arrayF3252m__();
static pointer arrayF3253simultaneous_equation();
static pointer arrayF3254inverse_matrix();
static pointer arrayF3255vector_x();
static pointer arrayF3256vector_y();
static pointer arrayF3257vector_z();
static pointer arrayF3258v_();
static pointer arrayF3259euler_matrix();
static pointer arrayF3260rpy_matrix();

/*:elmtype*/
static pointer arrayM3261vectorclass_elmtype(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[8];
	local[0]= w;
arrayBLK3262:
	ctx->vsp=local; return(local[0]);}

/*:element-type*/
static pointer arrayM3263vectorclass_element_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[8];
	local[1]= fqv[0];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,2,local+0,&ftab[0],fqv[1]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	local[0]= w;
arrayBLK3264:
	ctx->vsp=local; return(local[0]);}

/*:elmtype*/
static pointer arrayM3265vector_elmtype(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	local[1]= fqv[2];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
arrayBLK3266:
	ctx->vsp=local; return(local[0]);}

/*:element-type*/
static pointer arrayM3267vector_element_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	local[1]= fqv[3];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
arrayBLK3268:
	ctx->vsp=local; return(local[0]);}

/*:element-type*/
static pointer arrayM3269array_element_type(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)arrayF3236float_vector_p(ctx,1,local+0); /*float-vector-p*/
	if (w==NIL) goto arrayCON3272;
	local[0]= fqv[4];
	goto arrayCON3271;
arrayCON3272:
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)arrayF3237integer_vector_p(ctx,1,local+0); /*integer-vector-p*/
	if (w==NIL) goto arrayCON3273;
	local[0]= fqv[5];
	goto arrayCON3271;
arrayCON3273:
	w = argv[0]->c.obj.iv[1];
	if (!isstring(w)) goto arrayCON3274;
	local[0]= fqv[6];
	goto arrayCON3271;
arrayCON3274:
	local[0]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+1;
	w=(pointer)arrayF3238bit_vector_p(ctx,1,local+0); /*bit-vector-p*/
	if (w==NIL) goto arrayCON3275;
	local[0]= fqv[7];
	goto arrayCON3271;
arrayCON3275:
	local[0]= T;
	goto arrayCON3271;
arrayCON3276:
	local[0]= NIL;
arrayCON3271:
	w = local[0];
	local[0]= w;
arrayBLK3270:
	ctx->vsp=local; return(local[0]);}

/*fill-initial-contents*/
static pointer arrayF3223fill_initial_contents(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= makeint((eusinteger_t)0L);
	if (argv[2]==NIL) goto arrayCON3279;
	local[2]= (pointer)get_sym_func(fqv[8]);
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[1] = w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
arrayWHL3280:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto arrayWHX3281;
	local[4]= argv[0];
	local[5]= argv[1];
	local[6]= argv[2];
	local[7]= argv[3];
	local[8]= local[2];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)arrayF3223fill_initial_contents(ctx,4,local+4); /*fill-initial-contents*/
	local[4]= argv[1];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	argv[1] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto arrayWHL3280;
arrayWHX3281:
	local[4]= NIL;
arrayBLK3282:
	w = NIL;
	local[2]= w;
	goto arrayCON3278;
arrayCON3279:
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
arrayWHL3284:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto arrayWHX3285;
	local[4]= argv[0];
	local[5]= argv[1];
	local[6]= argv[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)ELT(ctx,2,local+6); /*elt*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)ASET(ctx,3,local+4); /*aset*/
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	argv[1] = w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[1] = w;
	local[4]= local[1];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)GREATERP(ctx,2,local+4); /*>*/
	if (w==NIL) goto arrayIF3287;
	local[4]= fqv[9];
	ctx->vsp=local+5;
	w=(pointer)SIGERROR(ctx,1,local+4); /*error*/
	local[4]= w;
	goto arrayIF3288;
arrayIF3287:
	local[4]= NIL;
arrayIF3288:
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto arrayWHL3284;
arrayWHX3285:
	local[4]= NIL;
arrayBLK3286:
	w = NIL;
	local[2]= w;
	goto arrayCON3278;
arrayCON3283:
	local[2]= NIL;
arrayCON3278:
	w = argv[0];
	local[0]= w;
arrayBLK3277:
	ctx->vsp=local; return(local[0]);}

/*make-array*/
static pointer arrayF3224make_array(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[10], &argv[1], n-1, local+0, 0);
	if (n & (1<<0)) goto arrayKEY3290;
	local[0] = loadglobal(fqv[11]);
arrayKEY3290:
	if (n & (1<<1)) goto arrayKEY3291;
	local[1] = NIL;
arrayKEY3291:
	if (n & (1<<2)) goto arrayKEY3292;
	local[2] = NIL;
arrayKEY3292:
	if (n & (1<<3)) goto arrayKEY3293;
	local[3] = makeint((eusinteger_t)0L);
arrayKEY3293:
	if (n & (1<<4)) goto arrayKEY3294;
	local[4] = NIL;
arrayKEY3294:
	if (n & (1<<5)) goto arrayKEY3295;
	local[5] = NIL;
arrayKEY3295:
	if (n & (1<<6)) goto arrayKEY3296;
	local[6] = NIL;
arrayKEY3296:
	if (n & (1<<7)) goto arrayKEY3297;
	local[7] = NIL;
arrayKEY3297:
	if (n & (1<<8)) goto arrayKEY3298;
	local[8] = NIL;
arrayKEY3298:
	if (n & (1<<9)) goto arrayKEY3299;
	local[9] = NIL;
arrayKEY3299:
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)CLASSP(ctx,1,local+13); /*classp*/
	if (w!=NIL) goto arrayIF3300;
	local[13]= local[0];
	local[14]= local[13];
	w = fqv[12];
	if (memq(local[14],w)==NIL) goto arrayIF3302;
	local[14]= loadglobal(fqv[13]);
	goto arrayIF3303;
arrayIF3302:
	local[14]= local[13];
	w = fqv[14];
	if (memq(local[14],w)==NIL) goto arrayIF3304;
	local[14]= loadglobal(fqv[15]);
	goto arrayIF3305;
arrayIF3304:
	local[14]= local[13];
	w = fqv[16];
	if (memq(local[14],w)==NIL) goto arrayIF3306;
	local[14]= loadglobal(fqv[17]);
	goto arrayIF3307;
arrayIF3306:
	local[14]= local[13];
	w = fqv[18];
	if (memq(local[14],w)==NIL) goto arrayIF3308;
	local[14]= loadglobal(fqv[19]);
	goto arrayIF3309;
arrayIF3308:
	if (T==NIL) goto arrayIF3310;
	local[14]= loadglobal(fqv[11]);
	goto arrayIF3311;
arrayIF3310:
	local[14]= NIL;
arrayIF3311:
arrayIF3309:
arrayIF3307:
arrayIF3305:
arrayIF3303:
	w = local[14];
	local[0] = w;
	local[13]= local[0];
	goto arrayIF3301;
arrayIF3300:
	local[13]= NIL;
arrayIF3301:
	w = argv[0];
	if (!isint(w)) goto arrayCON3313;
	local[13]= local[0];
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(pointer)INSTANTIATE(ctx,2,local+13); /*instantiate*/
	local[11] = w;
	local[12] = local[11];
	local[13]= argv[0];
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,1,local+13); /*list*/
	argv[0] = w;
	local[13]= argv[0];
	goto arrayCON3312;
arrayCON3313:
	local[13]= loadglobal(fqv[20]);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,1,local+13); /*instantiate*/
	local[12] = w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= argv[0];
	ctx->vsp=local+15;
	w=(pointer)LENGTH(ctx,1,local+14); /*length*/
	local[14]= w;
	local[15]= (pointer)get_sym_func(fqv[8]);
	local[16]= argv[0];
	ctx->vsp=local+17;
	w=(pointer)APPLY(ctx,2,local+15); /*apply*/
	local[15]= w;
	local[16]= local[14];
	local[17]= makeint((eusinteger_t)7L);
	ctx->vsp=local+18;
	w=(pointer)GREATERP(ctx,2,local+16); /*>*/
	if (w==NIL) goto arrayIF3315;
	local[16]= fqv[21];
	ctx->vsp=local+17;
	w=(pointer)SIGERROR(ctx,1,local+16); /*error*/
	local[16]= w;
	goto arrayIF3316;
arrayIF3315:
	local[16]= NIL;
arrayIF3316:
	local[16]= (pointer)get_sym_func(fqv[22]);
	local[17]= argv[0];
	ctx->vsp=local+18;
	w=(*ftab[1])(ctx,2,local+16,&ftab[1],fqv[23]); /*every*/
	if (w!=NIL) goto arrayIF3317;
	local[16]= fqv[24];
	ctx->vsp=local+17;
	w=(pointer)SIGERROR(ctx,1,local+16); /*error*/
	local[16]= w;
	goto arrayIF3318;
arrayIF3317:
	local[16]= NIL;
arrayIF3318:
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)VECTORP(ctx,1,local+16); /*vectorp*/
	if (w==NIL) goto arrayCON3320;
	local[16]= local[2];
	goto arrayCON3319;
arrayCON3320:
	local[16]= local[2];
	ctx->vsp=local+17;
	w=(pointer)ARRAYP(ctx,1,local+16); /*arrayp*/
	if (w==NIL) goto arrayCON3321;
	local[16]= local[2]->c.obj.iv[1];
	goto arrayCON3319;
arrayCON3321:
	local[16]= local[0];
	local[17]= makeint((eusinteger_t)1L);
	local[18]= local[15];
	ctx->vsp=local+19;
	w=(pointer)MAX(ctx,2,local+17); /*max*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)INSTANTIATE(ctx,2,local+16); /*instantiate*/
	local[16]= w;
	goto arrayCON3319;
arrayCON3322:
	local[16]= NIL;
arrayCON3319:
	local[11] = local[16];
	local[16]= local[14];
	local[17]= local[16];
	*(ovafptr(local[12],fqv[25])) = local[17];
	local[16]= local[11];
	local[17]= local[16];
	w = local[12];
	w->c.obj.iv[1] = local[17];
	w = local[1];
	if (!numberp(w)) goto arrayIF3323;
	local[16]= local[1];
	goto arrayIF3324;
arrayIF3323:
	if (local[1]==NIL) goto arrayIF3325;
	local[16]= local[15];
	goto arrayIF3326;
arrayIF3325:
	local[16]= NIL;
arrayIF3326:
arrayIF3324:
	local[17]= local[16];
	w = local[12];
	w->c.obj.iv[3] = local[17];
	local[16]= local[3];
	local[17]= local[16];
	w = local[12];
	w->c.obj.iv[4] = local[17];
	local[16]= makeint((eusinteger_t)0L);
arrayTAG3328:
	local[17]= local[16];
	local[18]= local[14];
	ctx->vsp=local+19;
	w=(pointer)GREQP(ctx,2,local+17); /*>=*/
	if (w==NIL) goto arrayIF3329;
	w = NIL;
	ctx->vsp=local+17;
	local[16]=w;
	goto arrayBLK3327;
	goto arrayIF3330;
arrayIF3329:
	local[17]= NIL;
arrayIF3330:
	local[17]= local[12];
	local[18]= loadglobal(fqv[20]);
	local[19]= local[16];
	local[20]= makeint((eusinteger_t)5L);
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	local[20]= argv[0];
	local[21]= local[16];
	ctx->vsp=local+22;
	w=(pointer)ELT(ctx,2,local+20); /*elt*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SETSLOT(ctx,4,local+17); /*setslot*/
	local[17]= local[16];
	ctx->vsp=local+18;
	w=(pointer)ADD1(ctx,1,local+17); /*1+*/
	local[17]= w;
	local[16] = local[17];
	w = NIL;
	ctx->vsp=local+17;
	goto arrayTAG3328;
	w = NIL;
	local[16]= w;
arrayBLK3327:
	w = local[16];
	local[13]= w;
	goto arrayCON3312;
arrayCON3314:
	local[13]= NIL;
arrayCON3312:
	if (local[6]==NIL) goto arrayIF3331;
	local[13]= local[11];
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(*ftab[2])(ctx,2,local+13,&ftab[2],fqv[26]); /*fill*/
	local[13]= w;
	goto arrayIF3332;
arrayIF3331:
	local[13]= NIL;
arrayIF3332:
	if (local[5]==NIL) goto arrayIF3333;
	local[13]= local[11];
	local[14]= makeint((eusinteger_t)0L);
	local[15]= argv[0];
	local[16]= local[5];
	ctx->vsp=local+17;
	w=(pointer)arrayF3223fill_initial_contents(ctx,4,local+13); /*fill-initial-contents*/
	local[13]= w;
	goto arrayIF3334;
arrayIF3333:
	local[13]= NIL;
arrayIF3334:
	w = local[12];
	local[0]= w;
arrayBLK3289:
	ctx->vsp=local; return(local[0]);}

/*array-total-size*/
static pointer arrayF3225array_total_size(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= *(ovafptr(argv[0],fqv[25]));
	local[1]= makeint((eusinteger_t)1L);
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
arrayWHL3336:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto arrayWHX3337;
	local[4]= local[1];
	local[5]= argv[0];
	local[6]= loadglobal(fqv[20]);
	local[7]= makeint((eusinteger_t)5L);
	w = local[2];
#if sun4 || vax || mips || alpha || Linux
	w=(pointer)((eusinteger_t)w-2);
#endif
	local[7]= (pointer)((eusinteger_t)local[7] + (eusinteger_t)w);
	ctx->vsp=local+8;
	w=(pointer)SLOT(ctx,3,local+5); /*slot*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)TIMES(ctx,2,local+4); /***/
	local[1] = w;
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto arrayWHL3336;
arrayWHX3337:
	local[4]= NIL;
arrayBLK3338:
	w = NIL;
	w = local[1];
	local[0]= w;
arrayBLK3335:
	ctx->vsp=local; return(local[0]);}

/*fill-pointer*/
static pointer arrayF3226fill_pointer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)ARRAYP(ctx,1,local+0); /*arrayp*/
	if (w==NIL) goto arrayIF3340;
	local[0]= *(ovafptr(argv[0],fqv[27]));
	goto arrayIF3341;
arrayIF3340:
	local[0]= fqv[28];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
arrayIF3341:
	w = local[0];
	local[0]= w;
arrayBLK3339:
	ctx->vsp=local; return(local[0]);}

/*array-rank*/
static pointer arrayF3227array_rank(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = *(ovafptr(argv[0],fqv[25]));
	local[0]= w;
arrayBLK3342:
	ctx->vsp=local; return(local[0]);}

/*array-dimensions*/
static pointer arrayF3228array_dimensions(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= *(ovafptr(argv[0],fqv[25]));
	local[1]= NIL;
arrayWHL3344:
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)GREATERP(ctx,2,local+2); /*>*/
	if (w==NIL) goto arrayWHX3345;
	local[2]= argv[0];
	local[3]= loadglobal(fqv[20]);
	local[4]= makeint((eusinteger_t)5L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)SUB1(ctx,1,local+5); /*1-*/
	local[0] = w;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)PLUS(ctx,2,local+4); /*+*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SLOT(ctx,3,local+2); /*slot*/
	local[2]= w;
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto arrayWHL3344;
arrayWHX3345:
	local[2]= NIL;
arrayBLK3346:
	w = local[1];
	local[0]= w;
arrayBLK3343:
	ctx->vsp=local; return(local[0]);}

/*array-dimension*/
static pointer arrayF3229array_dimension(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)ARRAYP(ctx,1,local+0); /*arrayp*/
	if (w==NIL) goto arrayIF3348;
	local[0]= argv[0];
	local[1]= loadglobal(fqv[20]);
	local[2]= makeint((eusinteger_t)5L);
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)PLUS(ctx,2,local+2); /*+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SLOT(ctx,3,local+0); /*slot*/
	local[0]= w;
	goto arrayIF3349;
arrayIF3348:
	local[0]= NIL;
arrayIF3349:
	w = local[0];
	local[0]= w;
arrayBLK3347:
	ctx->vsp=local; return(local[0]);}

/*array-vector*/
static pointer arrayF3230array_vector(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)VECTORP(ctx,1,local+0); /*vectorp*/
	if (w==NIL) goto arrayCON3352;
	local[0]= argv[0];
	goto arrayCON3351;
arrayCON3352:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)ARRAYP(ctx,1,local+0); /*arrayp*/
	if (w==NIL) goto arrayCON3353;
	local[0]= argv[0]->c.obj.iv[1];
	goto arrayCON3351;
arrayCON3353:
	local[0]= fqv[29];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
	goto arrayCON3351;
arrayCON3354:
	local[0]= NIL;
arrayCON3351:
	w = local[0];
	local[0]= w;
arrayBLK3350:
	ctx->vsp=local; return(local[0]);}

/*row-major-aref*/
static pointer arrayF3231row_major_aref(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
arrayBLK3355:
	ctx->vsp=local; return(local[0]);}

/*list-dimensions*/
static pointer arrayF3232list_dimensions(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto arrayCON3358;
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	ctx->vsp=local+2;
	w=(pointer)arrayF3232list_dimensions(ctx,1,local+1); /*list-dimensions*/
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto arrayCON3357;
arrayCON3358:
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= w;
	goto arrayCON3357;
arrayCON3359:
	local[0]= NIL;
arrayCON3357:
	w = local[0];
	local[0]= w;
arrayBLK3356:
	ctx->vsp=local; return(local[0]);}

/*read-array*/
static pointer arrayF3233read_array(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= T;
	local[2]= T;
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,4,local+0); /*read*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)arrayF3232list_dimensions(ctx,1,local+1); /*list-dimensions*/
	local[1]= w;
	local[2]= fqv[30];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)arrayF3224make_array(ctx,3,local+1); /*make-array*/
	local[0]= w;
arrayBLK3360:
	ctx->vsp=local; return(local[0]);}

/*read-float-array*/
static pointer arrayF3234read_float_array(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= T;
	local[2]= T;
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,4,local+0); /*read*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w==NIL) goto arrayIF3362;
	local[1]= fqv[17];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= w;
	goto arrayIF3363;
arrayIF3362:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)arrayF3232list_dimensions(ctx,1,local+1); /*list-dimensions*/
	local[1]= w;
	local[2]= fqv[3];
	local[3]= fqv[4];
	local[4]= fqv[30];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)arrayF3224make_array(ctx,5,local+1); /*make-array*/
	local[1]= w;
arrayIF3363:
	w = local[1];
	local[0]= w;
arrayBLK3361:
	ctx->vsp=local; return(local[0]);}

/*read-integer-array*/
static pointer arrayF3235read_integer_array(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= T;
	local[2]= T;
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,4,local+0); /*read*/
	local[0]= w;
	local[1]= argv[2];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)NUMEQUAL(ctx,2,local+1); /*=*/
	if (w==NIL) goto arrayIF3365;
	local[1]= fqv[19];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)APPLY(ctx,2,local+1); /*apply*/
	local[1]= w;
	goto arrayIF3366;
arrayIF3365:
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)arrayF3232list_dimensions(ctx,1,local+1); /*list-dimensions*/
	local[1]= w;
	local[2]= fqv[3];
	local[3]= fqv[5];
	local[4]= fqv[30];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)arrayF3224make_array(ctx,5,local+1); /*make-array*/
	local[1]= w;
arrayIF3366:
	w = local[1];
	local[0]= w;
arrayBLK3364:
	ctx->vsp=local; return(local[0]);}

/*float-vector-p*/
static pointer arrayF3236float_vector_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[17]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
arrayBLK3367:
	ctx->vsp=local; return(local[0]);}

/*integer-vector-p*/
static pointer arrayF3237integer_vector_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[19]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
arrayBLK3368:
	ctx->vsp=local; return(local[0]);}

/*bit-vector-p*/
static pointer arrayF3238bit_vector_p(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[15]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
arrayBLK3369:
	ctx->vsp=local; return(local[0]);}

/*matrixp*/
static pointer arrayF3239matrixp(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= loadglobal(fqv[20]);
	ctx->vsp=local+2;
	w=(pointer)DERIVEDP(ctx,2,local+0); /*derivedp*/
	local[0]= w;
	if (w==NIL) goto arrayAND3371;
	local[0]= *(ovafptr(argv[0],fqv[31]));
	ctx->vsp=local+1;
	w=(pointer)arrayF3236float_vector_p(ctx,1,local+0); /*float-vector-p*/
	local[0]= w;
arrayAND3371:
	w = local[0];
	local[0]= w;
arrayBLK3370:
	ctx->vsp=local; return(local[0]);}

/*make-matrix*/
static pointer arrayF3240make_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto arrayENT3374;}
	local[0]= NIL;
arrayENT3374:
arrayENT3373:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	local[2]= fqv[3];
	local[3]= fqv[4];
	local[4]= fqv[30];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)arrayF3224make_array(ctx,5,local+1); /*make-array*/
	local[0]= w;
arrayBLK3372:
	ctx->vsp=local; return(local[0]);}

/*matrix-row*/
static pointer arrayF3241matrix_row(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)arrayF3227array_rank(ctx,1,local+0); /*array-rank*/
	local[0]= w;
	if (makeint((eusinteger_t)2L)!=local[0]) goto arrayIF3376;
	local[0]= *(ovafptr(argv[0],fqv[31]));
	local[1]= *(ovafptr(argv[0],fqv[32]));
	local[2]= argv[1];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	local[2]= *(ovafptr(argv[0],fqv[32]));
	local[3]= argv[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SUBSEQ(ctx,3,local+0); /*subseq*/
	local[0]= w;
	goto arrayIF3377;
arrayIF3376:
	local[0]= NIL;
arrayIF3377:
	w = local[0];
	local[0]= w;
arrayBLK3375:
	ctx->vsp=local; return(local[0]);}

/*matrix-column*/
static pointer arrayF3242matrix_column(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)arrayF3227array_rank(ctx,1,local+0); /*array-rank*/
	local[0]= w;
	if (makeint((eusinteger_t)2L)!=local[0]) goto arrayIF3379;
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)GETCLASS(ctx,1,local+3); /*class*/
	local[3]= w;
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)INSTANTIATE(ctx,2,local+3); /*instantiate*/
	local[3]= w;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= local[0];
arrayWHL3381:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto arrayWHX3382;
	local[6]= local[3];
	local[7]= local[4];
	local[8]= local[2];
	local[9]= argv[1];
	local[10]= local[4];
	local[11]= local[1];
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,2,local+10); /***/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)PLUS(ctx,2,local+9); /*+*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,2,local+8); /*aref*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,3,local+6); /*aset*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto arrayWHL3381;
arrayWHX3382:
	local[6]= NIL;
arrayBLK3383:
	w = NIL;
	w = local[3];
	local[0]= w;
	goto arrayIF3380;
arrayIF3379:
	local[0]= NIL;
arrayIF3380:
	w = local[0];
	local[0]= w;
arrayBLK3378:
	ctx->vsp=local; return(local[0]);}

/*set-matrix-row*/
static pointer arrayF3243set_matrix_row(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)arrayF3227array_rank(ctx,1,local+0); /*array-rank*/
	local[0]= w;
	if (makeint((eusinteger_t)2L)!=local[0]) goto arrayIF3385;
	local[0]= *(ovafptr(argv[0],fqv[31]));
	local[1]= argv[2];
	local[2]= fqv[33];
	local[3]= *(ovafptr(argv[0],fqv[32]));
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)TIMES(ctx,2,local+3); /***/
	local[3]= w;
	local[4]= fqv[34];
	local[5]= *(ovafptr(argv[0],fqv[32]));
	local[6]= argv[1];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)TIMES(ctx,2,local+5); /***/
	local[5]= w;
	ctx->vsp=local+6;
	w=(*ftab[3])(ctx,6,local+0,&ftab[3],fqv[35]); /*replace*/
	local[0]= w;
	goto arrayIF3386;
arrayIF3385:
	local[0]= NIL;
arrayIF3386:
	w = argv[0];
	local[0]= w;
arrayBLK3384:
	ctx->vsp=local; return(local[0]);}

/*set-matrix-column*/
static pointer arrayF3244set_matrix_column(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)arrayF3227array_rank(ctx,1,local+0); /*array-rank*/
	local[0]= w;
	if (makeint((eusinteger_t)2L)!=local[0]) goto arrayIF3388;
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= argv[0]->c.obj.iv[6];
	local[2]= argv[0]->c.obj.iv[1];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
arrayWHL3390:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto arrayWHX3391;
	local[5]= local[2];
	local[6]= argv[1];
	local[7]= local[3];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)PLUS(ctx,2,local+6); /*+*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= local[3];
	ctx->vsp=local+9;
	w=(pointer)ELT(ctx,2,local+7); /*elt*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ASET(ctx,3,local+5); /*aset*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto arrayWHL3390;
arrayWHX3391:
	local[5]= NIL;
arrayBLK3392:
	w = NIL;
	local[0]= w;
	goto arrayIF3389;
arrayIF3388:
	local[0]= NIL;
arrayIF3389:
	w = argv[0];
	local[0]= w;
arrayBLK3387:
	ctx->vsp=local; return(local[0]);}

/*replace-matrix*/
static pointer arrayF3245replace_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[1];
	local[1]= argv[1]->c.obj.iv[1];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[35]); /*replace*/
	w = argv[0];
	local[0]= w;
arrayBLK3393:
	ctx->vsp=local; return(local[0]);}

/*copy-matrix*/
static pointer arrayF3246copy_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0]->c.obj.iv[5];
	local[1]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+2;
	w=(pointer)arrayF3240make_matrix(ctx,2,local+0); /*make-matrix*/
	local[0]= w;
	local[1]= local[0]->c.obj.iv[1];
	local[2]= argv[0]->c.obj.iv[1];
	ctx->vsp=local+3;
	w=(*ftab[3])(ctx,2,local+1,&ftab[3],fqv[35]); /*replace*/
	w = local[0];
	local[0]= w;
arrayBLK3394:
	ctx->vsp=local; return(local[0]);}

/*scale-matrix*/
static pointer arrayF3247scale_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto arrayENT3397;}
	local[0]= argv[1];
	ctx->vsp=local+1;
	w=(pointer)arrayF3246copy_matrix(ctx,1,local+0); /*copy-matrix*/
	local[0]= w;
arrayENT3397:
arrayENT3396:
	if (n>3) maerror();
	local[1]= argv[0];
	local[2]= argv[1]->c.obj.iv[1];
	local[3]= local[0]->c.obj.iv[1];
	ctx->vsp=local+4;
	w=(pointer)SCALEVEC(ctx,3,local+1); /*scale*/
	w = local[0];
	local[0]= w;
arrayBLK3395:
	ctx->vsp=local; return(local[0]);}

/*matrix*/
static pointer arrayF3248matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
arrayRST3399:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-0);
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)LENGTH(ctx,1,local+1); /*length*/
	local[1]= w;
	local[2]= (pointer)get_sym_func(fqv[36]);
	local[3]= (pointer)get_sym_func(fqv[37]);
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)MAPCAR(ctx,2,local+3); /*mapcar*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,2,local+2); /*apply*/
	local[2]= w;
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)arrayF3240make_matrix(ctx,3,local+1); /*make-matrix*/
	local[0]= w;
arrayBLK3398:
	ctx->vsp=local; return(local[0]);}

/*acos*/
static pointer arrayF3249acos(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= makeflt(1.0000000000000000000000e+00);
	local[1]= argv[0];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MINUS(ctx,2,local+0); /*-*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)SQRT(ctx,1,local+0); /*sqrt*/
	local[0]= w;
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)ATAN(ctx,2,local+0); /*atan*/
	local[0]= w;
arrayBLK3400:
	ctx->vsp=local; return(local[0]);}

/*asin*/
static pointer arrayF3250asin(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeflt(1.0000000000000000000000e+00);
	local[2]= argv[0];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)TIMES(ctx,2,local+2); /***/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MINUS(ctx,2,local+1); /*-*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)SQRT(ctx,1,local+1); /*sqrt*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)ATAN(ctx,2,local+0); /*atan*/
	local[0]= w;
arrayBLK3401:
	ctx->vsp=local; return(local[0]);}

/*unit-matrix*/
static pointer arrayF3251unit_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	if (n>=1) { local[0]=(argv[0]); goto arrayENT3404;}
	local[0]= makeint((eusinteger_t)3L);
arrayENT3404:
arrayENT3403:
	if (n>1) maerror();
	local[1]= local[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)arrayF3240make_matrix(ctx,2,local+1); /*make-matrix*/
	local[1]= w;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
arrayWHL3405:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto arrayWHX3406;
	local[4]= local[1];
	local[5]= local[2];
	local[6]= local[2];
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)ASET(ctx,4,local+4); /*aset*/
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto arrayWHL3405;
arrayWHX3406:
	local[4]= NIL;
arrayBLK3407:
	w = NIL;
	w = local[1];
	local[0]= w;
arrayBLK3402:
	ctx->vsp=local; return(local[0]);}

/*m***/
static pointer arrayF3252m__(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
arrayRST3409:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)MATTIMES(ctx,2,local+3); /*m**/
	local[2] = w;
	local[3]= NIL;
	local[4]= local[0];
arrayWHL3410:
	if (local[4]==NIL) goto arrayWHX3411;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[5]= (w)->c.cons.car;
	w=local[4];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4] = (w)->c.cons.cdr;
	w = local[5];
	local[3] = w;
	local[5]= local[2];
	local[6]= local[3];
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)MATTIMES(ctx,3,local+5); /*m**/
	goto arrayWHL3410;
arrayWHX3411:
	local[5]= NIL;
arrayBLK3412:
	w = NIL;
	w = local[2];
	local[0]= w;
arrayBLK3408:
	ctx->vsp=local; return(local[0]);}

/*simultaneous-equation*/
static pointer arrayF3253simultaneous_equation(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)arrayF3229array_dimension(ctx,2,local+0); /*array-dimension*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)arrayF3251unit_matrix(ctx,1,local+0); /*unit-matrix*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)LU_DECOMPOSE(ctx,2,local+1); /*lu-decompose*/
	local[1]= w;
	local[2]= local[0];
	local[3]= local[1];
	local[4]= argv[1];
	ctx->vsp=local+5;
	w=(pointer)LU_SOLVE(ctx,3,local+2); /*lu-solve*/
	local[0]= w;
arrayBLK3413:
	ctx->vsp=local; return(local[0]);}

/*inverse-matrix*/
static pointer arrayF3254inverse_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)arrayF3229array_dimension(ctx,2,local+0); /*array-dimension*/
	local[0]= w;
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(pointer)arrayF3251unit_matrix(ctx,1,local+1); /*unit-matrix*/
	local[1]= w;
	local[2]= argv[0];
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)LU_DECOMPOSE(ctx,2,local+2); /*lu-decompose*/
	local[2]= w;
	local[3]= NIL;
	local[4]= local[0];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)arrayF3240make_matrix(ctx,2,local+4); /*make-matrix*/
	local[4]= w;
	local[5]= loadglobal(fqv[17]);
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,2,local+5); /*instantiate*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)0L);
	if (local[2]!=NIL) goto arrayIF3415;
	w = fqv[38];
	ctx->vsp=local+7;
	local[0]=w;
	goto arrayBLK3414;
	goto arrayIF3416;
arrayIF3415:
	local[7]= NIL;
arrayIF3416:
	local[7]= makeint((eusinteger_t)0L);
	local[8]= local[0];
arrayWHL3417:
	local[9]= local[7];
	w = local[8];
	if ((eusinteger_t)local[9] >= (eusinteger_t)w) goto arrayWHX3418;
	local[9]= local[5];
	local[10]= local[7];
	local[11]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,3,local+9); /*aset*/
	local[9]= local[1];
	local[10]= local[2];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)LU_SOLVE(ctx,3,local+9); /*lu-solve*/
	local[3] = w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[0];
arrayWHL3420:
	local[11]= local[9];
	w = local[10];
	if ((eusinteger_t)local[11] >= (eusinteger_t)w) goto arrayWHX3421;
	local[11]= local[4];
	local[12]= local[9];
	local[13]= local[7];
	local[14]= local[3];
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)AREF(ctx,2,local+14); /*aref*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)ASET(ctx,4,local+11); /*aset*/
	local[11]= local[9];
	ctx->vsp=local+12;
	w=(pointer)ADD1(ctx,1,local+11); /*1+*/
	local[9] = w;
	goto arrayWHL3420;
arrayWHX3421:
	local[11]= NIL;
arrayBLK3422:
	w = NIL;
	local[9]= local[5];
	local[10]= local[7];
	local[11]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+12;
	w=(pointer)ASET(ctx,3,local+9); /*aset*/
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)ADD1(ctx,1,local+9); /*1+*/
	local[7] = w;
	goto arrayWHL3417;
arrayWHX3418:
	local[9]= NIL;
arrayBLK3419:
	w = NIL;
	w = local[4];
	local[0]= w;
arrayBLK3414:
	ctx->vsp=local; return(local[0]);}

/*vector-x*/
static pointer arrayF3255vector_x(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)0L));
	  w=makeflt(local[0]->c.fvec.fv[i]);}
	local[0]= w;
arrayBLK3423:
	ctx->vsp=local; return(local[0]);}

/*vector-y*/
static pointer arrayF3256vector_y(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)1L));
	  w=makeflt(local[0]->c.fvec.fv[i]);}
	local[0]= w;
arrayBLK3424:
	ctx->vsp=local; return(local[0]);}

/*vector-z*/
static pointer arrayF3257vector_z(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	{ register eusinteger_t i=intval(makeint((eusinteger_t)2L));
	  w=makeflt(local[0]->c.fvec.fv[i]);}
	local[0]= w;
arrayBLK3425:
	ctx->vsp=local; return(local[0]);}

/*v=*/
static pointer arrayF3258v_(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= argv[1];
	ctx->vsp=local+2;
	w=(pointer)VDISTANCE(ctx,2,local+0); /*distance*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[4])(ctx,1,local+0,&ftab[4],fqv[39]); /*zerop*/
	local[0]= w;
arrayBLK3426:
	ctx->vsp=local; return(local[0]);}

/*euler-matrix*/
static pointer arrayF3259euler_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[40];
	ctx->vsp=local+2;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+0); /*rotation-matrix*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[1];
	local[3]= fqv[41];
	local[4]= NIL;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	local[1]= local[0];
	local[2]= argv[2];
	local[3]= fqv[40];
	local[4]= NIL;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	w = local[0];
	local[0]= w;
arrayBLK3427:
	ctx->vsp=local; return(local[0]);}

/*rpy-matrix*/
static pointer arrayF3260rpy_matrix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[42];
	ctx->vsp=local+2;
	w=(pointer)ROTATION_MATRIX(ctx,2,local+0); /*rotation-matrix*/
	local[0]= w;
	local[1]= local[0];
	local[2]= argv[1];
	local[3]= fqv[41];
	local[4]= T;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	local[1]= local[0];
	local[2]= argv[0];
	local[3]= fqv[40];
	local[4]= T;
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ROTMAT(ctx,5,local+1); /*rotate-matrix*/
	w = local[0];
	local[0]= w;
arrayBLK3428:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___array(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[43];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto arrayIF3429;
	local[0]= fqv[44];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[45],w);
	goto arrayIF3430;
arrayIF3429:
	local[0]= fqv[46];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
arrayIF3430:
	local[0]= fqv[47];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,arrayM3261vectorclass_elmtype,fqv[2],fqv[48],fqv[49]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,arrayM3263vectorclass_element_type,fqv[3],fqv[48],fqv[50]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,arrayM3265vector_elmtype,fqv[2],fqv[11],fqv[51]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,arrayM3267vector_element_type,fqv[3],fqv[11],fqv[52]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,arrayM3269array_element_type,fqv[3],fqv[20],fqv[53]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[54],module,arrayF3223fill_initial_contents,fqv[55]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[56],module,arrayF3224make_array,fqv[57]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[58],module,arrayF3225array_total_size,fqv[59]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[27],module,arrayF3226fill_pointer,fqv[60]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[61],module,arrayF3227array_rank,fqv[62]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[63],module,arrayF3228array_dimensions,fqv[64]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[65],module,arrayF3229array_dimension,fqv[66]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[67],module,arrayF3230array_vector,fqv[68]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[69],module,arrayF3231row_major_aref,fqv[70]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[71],module,arrayF3232list_dimensions,fqv[72]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[73],module,arrayF3233read_array,fqv[74]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[75],module,arrayF3234read_float_array,fqv[76]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[77],module,arrayF3235read_integer_array,fqv[78]);
	local[0]= makeint((eusinteger_t)35L);
	local[1]= makeint((eusinteger_t)65L);
	local[2]= fqv[73];
	ctx->vsp=local+3;
	w=(pointer)SETDISPMACRO(ctx,3,local+0); /*set-dispatch-macro-character*/
	local[0]= makeint((eusinteger_t)35L);
	local[1]= makeint((eusinteger_t)70L);
	local[2]= fqv[75];
	ctx->vsp=local+3;
	w=(pointer)SETDISPMACRO(ctx,3,local+0); /*set-dispatch-macro-character*/
	local[0]= makeint((eusinteger_t)35L);
	local[1]= makeint((eusinteger_t)73L);
	local[2]= fqv[77];
	ctx->vsp=local+3;
	w=(pointer)SETDISPMACRO(ctx,3,local+0); /*set-dispatch-macro-character*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[79],module,arrayF3236float_vector_p,fqv[80]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[81],module,arrayF3237integer_vector_p,fqv[82]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[83],module,arrayF3238bit_vector_p,fqv[84]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[85],module,arrayF3239matrixp,fqv[86]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[87],module,arrayF3240make_matrix,fqv[88]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[89],module,arrayF3241matrix_row,fqv[90]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[91],module,arrayF3242matrix_column,fqv[92]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[93],module,arrayF3243set_matrix_row,fqv[94]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[95],module,arrayF3244set_matrix_column,fqv[96]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[97],module,arrayF3245replace_matrix,fqv[98]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[99],module,arrayF3246copy_matrix,fqv[100]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[101],module,arrayF3247scale_matrix,fqv[102]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[103],module,arrayF3248matrix,fqv[104]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[105],module,arrayF3249acos,fqv[106]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[107],module,arrayF3250asin,fqv[108]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[109],module,arrayF3251unit_matrix,fqv[110]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[111],module,arrayF3252m__,fqv[112]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[113],module,arrayF3253simultaneous_equation,fqv[114]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[115],module,arrayF3254inverse_matrix,fqv[116]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[117],module,arrayF3255vector_x,fqv[118]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[119],module,arrayF3256vector_y,fqv[120]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[121],module,arrayF3257vector_z,fqv[122]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[123],module,arrayF3258v_,fqv[124]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[125],module,arrayF3259euler_matrix,fqv[126]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[127],module,arrayF3260rpy_matrix,fqv[128]);
	local[0]= fqv[129];
	local[1]= fqv[130];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[131]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<6; i++) ftab[i]=fcallx;
}
