
"use strict";

let Ptz = require('./Ptz.js');
let Axis = require('./Axis.js');

module.exports = {
  Ptz: Ptz,
  Axis: Axis,
};
