
"use strict";

let ConfigActionResult = require('./ConfigActionResult.js');
let ConfigResult = require('./ConfigResult.js');
let ConfigActionFeedback = require('./ConfigActionFeedback.js');
let ConfigGoal = require('./ConfigGoal.js');
let ConfigActionGoal = require('./ConfigActionGoal.js');
let ConfigFeedback = require('./ConfigFeedback.js');
let ConfigAction = require('./ConfigAction.js');
let ImagePoint = require('./ImagePoint.js');
let ObjectInImage = require('./ObjectInImage.js');

module.exports = {
  ConfigActionResult: ConfigActionResult,
  ConfigResult: ConfigResult,
  ConfigActionFeedback: ConfigActionFeedback,
  ConfigGoal: ConfigGoal,
  ConfigActionGoal: ConfigActionGoal,
  ConfigFeedback: ConfigFeedback,
  ConfigAction: ConfigAction,
  ImagePoint: ImagePoint,
  ObjectInImage: ObjectInImage,
};
