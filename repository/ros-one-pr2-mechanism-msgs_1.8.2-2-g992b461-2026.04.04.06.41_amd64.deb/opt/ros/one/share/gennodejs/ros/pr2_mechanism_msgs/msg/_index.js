
"use strict";

let SwitchControllerGoal = require('./SwitchControllerGoal.js');
let SwitchControllerResult = require('./SwitchControllerResult.js');
let SwitchControllerFeedback = require('./SwitchControllerFeedback.js');
let SwitchControllerActionGoal = require('./SwitchControllerActionGoal.js');
let SwitchControllerAction = require('./SwitchControllerAction.js');
let SwitchControllerActionFeedback = require('./SwitchControllerActionFeedback.js');
let SwitchControllerActionResult = require('./SwitchControllerActionResult.js');
let ActuatorStatistics = require('./ActuatorStatistics.js');
let ControllerStatistics = require('./ControllerStatistics.js');
let JointStatistics = require('./JointStatistics.js');
let MechanismStatistics = require('./MechanismStatistics.js');

module.exports = {
  SwitchControllerGoal: SwitchControllerGoal,
  SwitchControllerResult: SwitchControllerResult,
  SwitchControllerFeedback: SwitchControllerFeedback,
  SwitchControllerActionGoal: SwitchControllerActionGoal,
  SwitchControllerAction: SwitchControllerAction,
  SwitchControllerActionFeedback: SwitchControllerActionFeedback,
  SwitchControllerActionResult: SwitchControllerActionResult,
  ActuatorStatistics: ActuatorStatistics,
  ControllerStatistics: ControllerStatistics,
  JointStatistics: JointStatistics,
  MechanismStatistics: MechanismStatistics,
};
