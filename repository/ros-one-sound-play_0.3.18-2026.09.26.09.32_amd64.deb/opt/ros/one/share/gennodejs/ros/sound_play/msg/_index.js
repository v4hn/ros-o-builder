
"use strict";

let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestResult: SoundRequestResult,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequest: SoundRequest,
};
