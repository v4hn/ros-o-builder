(cl:in-package app_manager-srv)
(cl:export '(NAME-VAL
          NAME
          STOPPED-VAL
          STOPPED
          TIMEOUT-VAL
          TIMEOUT
          ERROR_CODE-VAL
          ERROR_CODE
          MESSAGE-VAL
          MESSAGE
))