// Auto-generated. Do not edit!

// (in-package app_manager.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

let ExchangeApp = require('../msg/ExchangeApp.js');

//-----------------------------------------------------------

class GetInstallationStateRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.remote_update = null;
    }
    else {
      if (initObj.hasOwnProperty('remote_update')) {
        this.remote_update = initObj.remote_update
      }
      else {
        this.remote_update = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetInstallationStateRequest
    // Serialize message field [remote_update]
    bufferOffset = _serializer.bool(obj.remote_update, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetInstallationStateRequest
    let len;
    let data = new GetInstallationStateRequest(null);
    // Deserialize message field [remote_update]
    data.remote_update = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    return 1;
  }

  static datatype() {
    // Returns string type for a service object
    return 'app_manager/GetInstallationStateRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f7e64723808960ca985ba81f45f1b8a7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    bool remote_update
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetInstallationStateRequest(null);
    if (msg.remote_update !== undefined) {
      resolved.remote_update = msg.remote_update;
    }
    else {
      resolved.remote_update = false
    }

    return resolved;
    }
};

class GetInstallationStateResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.installed_apps = null;
      this.available_apps = null;
    }
    else {
      if (initObj.hasOwnProperty('installed_apps')) {
        this.installed_apps = initObj.installed_apps
      }
      else {
        this.installed_apps = [];
      }
      if (initObj.hasOwnProperty('available_apps')) {
        this.available_apps = initObj.available_apps
      }
      else {
        this.available_apps = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type GetInstallationStateResponse
    // Serialize message field [installed_apps]
    // Serialize the length for message field [installed_apps]
    bufferOffset = _serializer.uint32(obj.installed_apps.length, buffer, bufferOffset);
    obj.installed_apps.forEach((val) => {
      bufferOffset = ExchangeApp.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [available_apps]
    // Serialize the length for message field [available_apps]
    bufferOffset = _serializer.uint32(obj.available_apps.length, buffer, bufferOffset);
    obj.available_apps.forEach((val) => {
      bufferOffset = ExchangeApp.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type GetInstallationStateResponse
    let len;
    let data = new GetInstallationStateResponse(null);
    // Deserialize message field [installed_apps]
    // Deserialize array length for message field [installed_apps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.installed_apps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.installed_apps[i] = ExchangeApp.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [available_apps]
    // Deserialize array length for message field [available_apps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.available_apps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.available_apps[i] = ExchangeApp.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.installed_apps.forEach((val) => {
      length += ExchangeApp.getMessageSize(val);
    });
    object.available_apps.forEach((val) => {
      length += ExchangeApp.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a service object
    return 'app_manager/GetInstallationStateResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '46d45bbda08250199267aff8c0ee8c41';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    ExchangeApp[] installed_apps
    ExchangeApp[] available_apps
    
    ================================================================================
    MSG: app_manager/ExchangeApp
    # app name
    string name
    # user-friendly display name of application
    string display_name
    # the version of the package currently installed
    string version
    # latest version of the package avaliable
    string latest_version
    # the detailed description of the app
    string description
    # icon for showing app
    Icon icon
    # hidden apps are not show - used for cases where multiple apps are in a deb
    bool hidden
    ================================================================================
    MSG: app_manager/Icon
    # Image data format.  "jpeg" or "png"
    string format
    
    # Image data.
    uint8[] data
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new GetInstallationStateResponse(null);
    if (msg.installed_apps !== undefined) {
      resolved.installed_apps = new Array(msg.installed_apps.length);
      for (let i = 0; i < resolved.installed_apps.length; ++i) {
        resolved.installed_apps[i] = ExchangeApp.Resolve(msg.installed_apps[i]);
      }
    }
    else {
      resolved.installed_apps = []
    }

    if (msg.available_apps !== undefined) {
      resolved.available_apps = new Array(msg.available_apps.length);
      for (let i = 0; i < resolved.available_apps.length; ++i) {
        resolved.available_apps[i] = ExchangeApp.Resolve(msg.available_apps[i]);
      }
    }
    else {
      resolved.available_apps = []
    }

    return resolved;
    }
};

module.exports = {
  Request: GetInstallationStateRequest,
  Response: GetInstallationStateResponse,
  md5sum() { return '28f0a7294f6241e2423a9382e3c76987'; },
  datatype() { return 'app_manager/GetInstallationState'; }
};
