// Auto-generated. Do not edit!

// (in-package app_manager.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let App = require('./App.js');

//-----------------------------------------------------------

class AppList {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.running_apps = null;
      this.available_apps = null;
    }
    else {
      if (initObj.hasOwnProperty('running_apps')) {
        this.running_apps = initObj.running_apps
      }
      else {
        this.running_apps = [];
      }
      if (initObj.hasOwnProperty('available_apps')) {
        this.available_apps = initObj.available_apps
      }
      else {
        this.available_apps = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type AppList
    // Serialize message field [running_apps]
    // Serialize the length for message field [running_apps]
    bufferOffset = _serializer.uint32(obj.running_apps.length, buffer, bufferOffset);
    obj.running_apps.forEach((val) => {
      bufferOffset = App.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [available_apps]
    // Serialize the length for message field [available_apps]
    bufferOffset = _serializer.uint32(obj.available_apps.length, buffer, bufferOffset);
    obj.available_apps.forEach((val) => {
      bufferOffset = App.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type AppList
    let len;
    let data = new AppList(null);
    // Deserialize message field [running_apps]
    // Deserialize array length for message field [running_apps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.running_apps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.running_apps[i] = App.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [available_apps]
    // Deserialize array length for message field [available_apps]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.available_apps = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.available_apps[i] = App.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.running_apps.forEach((val) => {
      length += App.getMessageSize(val);
    });
    object.available_apps.forEach((val) => {
      length += App.getMessageSize(val);
    });
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'app_manager/AppList';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '8a71ede6bf51909653c7c551f462cb30';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    App[] running_apps
    App[] available_apps
    
    ================================================================================
    MSG: app_manager/App
    # app name
    string name
    # user-friendly display name of application
    string display_name
    # icon for showing app
    Icon icon
    # ordered list (by preference) of client applications to interact with this robot app.  
    ClientApp[] client_apps
    
    ================================================================================
    MSG: app_manager/Icon
    # Image data format.  "jpeg" or "png"
    string format
    
    # Image data.
    uint8[] data
    
    ================================================================================
    MSG: app_manager/ClientApp
    # like "android" or "web" or "linux"
    string client_type
    
    # like "intent = ros.android.teleop" and "accelerometer = true", used to choose which ClientApp to use
    KeyValue[] manager_data
    
    # parameters which just get passed through to the client app.
    KeyValue[] app_data
    
    ================================================================================
    MSG: app_manager/KeyValue
    string key
    string value
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new AppList(null);
    if (msg.running_apps !== undefined) {
      resolved.running_apps = new Array(msg.running_apps.length);
      for (let i = 0; i < resolved.running_apps.length; ++i) {
        resolved.running_apps[i] = App.Resolve(msg.running_apps[i]);
      }
    }
    else {
      resolved.running_apps = []
    }

    if (msg.available_apps !== undefined) {
      resolved.available_apps = new Array(msg.available_apps.length);
      for (let i = 0; i < resolved.available_apps.length; ++i) {
        resolved.available_apps[i] = App.Resolve(msg.available_apps[i]);
      }
    }
    else {
      resolved.available_apps = []
    }

    return resolved;
    }
};

module.exports = AppList;
