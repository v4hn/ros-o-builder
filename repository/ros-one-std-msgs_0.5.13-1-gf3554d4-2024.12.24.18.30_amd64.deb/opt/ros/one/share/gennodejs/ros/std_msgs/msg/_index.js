
"use strict";

let UInt8MultiArray = require('./UInt8MultiArray.js');
let Float64 = require('./Float64.js');
let UInt32MultiArray = require('./UInt32MultiArray.js');
let Int32 = require('./Int32.js');
let UInt32 = require('./UInt32.js');
let UInt8 = require('./UInt8.js');
let MultiArrayDimension = require('./MultiArrayDimension.js');
let Float32MultiArray = require('./Float32MultiArray.js');
let String = require('./String.js');
let Time = require('./Time.js');
let Byte = require('./Byte.js');
let UInt16 = require('./UInt16.js');
let Int64 = require('./Int64.js');
let UInt16MultiArray = require('./UInt16MultiArray.js');
let Int16MultiArray = require('./Int16MultiArray.js');
let MultiArrayLayout = require('./MultiArrayLayout.js');
let Duration = require('./Duration.js');
let Int32MultiArray = require('./Int32MultiArray.js');
let Int8MultiArray = require('./Int8MultiArray.js');
let Int8 = require('./Int8.js');
let Int16 = require('./Int16.js');
let UInt64MultiArray = require('./UInt64MultiArray.js');
let Int64MultiArray = require('./Int64MultiArray.js');
let Header = require('./Header.js');
let Char = require('./Char.js');
let Float64MultiArray = require('./Float64MultiArray.js');
let Bool = require('./Bool.js');
let Float32 = require('./Float32.js');
let UInt64 = require('./UInt64.js');
let Empty = require('./Empty.js');
let ByteMultiArray = require('./ByteMultiArray.js');
let ColorRGBA = require('./ColorRGBA.js');

module.exports = {
  UInt8MultiArray: UInt8MultiArray,
  Float64: Float64,
  UInt32MultiArray: UInt32MultiArray,
  Int32: Int32,
  UInt32: UInt32,
  UInt8: UInt8,
  MultiArrayDimension: MultiArrayDimension,
  Float32MultiArray: Float32MultiArray,
  String: String,
  Time: Time,
  Byte: Byte,
  UInt16: UInt16,
  Int64: Int64,
  UInt16MultiArray: UInt16MultiArray,
  Int16MultiArray: Int16MultiArray,
  MultiArrayLayout: MultiArrayLayout,
  Duration: Duration,
  Int32MultiArray: Int32MultiArray,
  Int8MultiArray: Int8MultiArray,
  Int8: Int8,
  Int16: Int16,
  UInt64MultiArray: UInt64MultiArray,
  Int64MultiArray: Int64MultiArray,
  Header: Header,
  Char: Char,
  Float64MultiArray: Float64MultiArray,
  Bool: Bool,
  Float32: Float32,
  UInt64: UInt64,
  Empty: Empty,
  ByteMultiArray: ByteMultiArray,
  ColorRGBA: ColorRGBA,
};
