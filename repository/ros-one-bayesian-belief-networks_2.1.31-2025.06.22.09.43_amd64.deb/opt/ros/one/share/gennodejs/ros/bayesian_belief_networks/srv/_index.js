
"use strict";

let Query = require('./Query.js')

module.exports = {
  Query: Query,
};
