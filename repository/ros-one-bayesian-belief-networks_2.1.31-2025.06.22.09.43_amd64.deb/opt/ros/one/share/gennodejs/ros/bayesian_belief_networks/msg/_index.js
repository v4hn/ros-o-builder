
"use strict";

let Result = require('./Result.js');
let Observation = require('./Observation.js');

module.exports = {
  Result: Result,
  Observation: Observation,
};
