// Auto-generated. Do not edit!

// (in-package bayesian_belief_networks.srv)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Observation = require('../msg/Observation.js');

//-----------------------------------------------------------

let Result = require('../msg/Result.js');

//-----------------------------------------------------------

class QueryRequest {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.query = null;
    }
    else {
      if (initObj.hasOwnProperty('query')) {
        this.query = initObj.query
      }
      else {
        this.query = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type QueryRequest
    // Serialize message field [query]
    // Serialize the length for message field [query]
    bufferOffset = _serializer.uint32(obj.query.length, buffer, bufferOffset);
    obj.query.forEach((val) => {
      bufferOffset = Observation.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type QueryRequest
    let len;
    let data = new QueryRequest(null);
    // Deserialize message field [query]
    // Deserialize array length for message field [query]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.query = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.query[i] = Observation.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.query.forEach((val) => {
      length += Observation.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'bayesian_belief_networks/QueryRequest';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c82ad1bda0500c7fa7fed33d8deb2a3f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Observation[] query
    
    ================================================================================
    MSG: bayesian_belief_networks/Observation
    string node
    string evidence
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new QueryRequest(null);
    if (msg.query !== undefined) {
      resolved.query = new Array(msg.query.length);
      for (let i = 0; i < resolved.query.length; ++i) {
        resolved.query[i] = Observation.Resolve(msg.query[i]);
      }
    }
    else {
      resolved.query = []
    }

    return resolved;
    }
};

class QueryResponse {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.results = null;
    }
    else {
      if (initObj.hasOwnProperty('results')) {
        this.results = initObj.results
      }
      else {
        this.results = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type QueryResponse
    // Serialize message field [results]
    // Serialize the length for message field [results]
    bufferOffset = _serializer.uint32(obj.results.length, buffer, bufferOffset);
    obj.results.forEach((val) => {
      bufferOffset = Result.serialize(val, buffer, bufferOffset);
    });
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type QueryResponse
    let len;
    let data = new QueryResponse(null);
    // Deserialize message field [results]
    // Deserialize array length for message field [results]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.results = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.results[i] = Result.deserialize(buffer, bufferOffset)
    }
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.results.forEach((val) => {
      length += Result.getMessageSize(val);
    });
    return length + 4;
  }

  static datatype() {
    // Returns string type for a service object
    return 'bayesian_belief_networks/QueryResponse';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'f41c31876c3be91ef922fc26aa614079';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Result[] results
    
    ================================================================================
    MSG: bayesian_belief_networks/Result
    string node
    string Value
    float64 Marginal
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new QueryResponse(null);
    if (msg.results !== undefined) {
      resolved.results = new Array(msg.results.length);
      for (let i = 0; i < resolved.results.length; ++i) {
        resolved.results[i] = Result.Resolve(msg.results[i]);
      }
    }
    else {
      resolved.results = []
    }

    return resolved;
    }
};

module.exports = {
  Request: QueryRequest,
  Response: QueryResponse,
  md5sum() { return '5cc4ca012e1b2c83f69c62071ca032f1'; },
  datatype() { return 'bayesian_belief_networks/Query'; }
};
