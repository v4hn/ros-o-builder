
"use strict";

let SparseOccupancyGridCell = require('./SparseOccupancyGridCell.js');
let SimpleOccupancyGridArray = require('./SimpleOccupancyGridArray.js');
let SparseOccupancyGridArray = require('./SparseOccupancyGridArray.js');
let Object = require('./Object.js');
let PosedCameraInfo = require('./PosedCameraInfo.js');
let PolygonArray = require('./PolygonArray.js');
let PointsArray = require('./PointsArray.js');
let BoundingBoxArrayWithCameraInfo = require('./BoundingBoxArrayWithCameraInfo.js');
let Accuracy = require('./Accuracy.js');
let Line = require('./Line.js');
let SparseOccupancyGridColumn = require('./SparseOccupancyGridColumn.js');
let RotatedRect = require('./RotatedRect.js');
let ModelCoefficientsArray = require('./ModelCoefficientsArray.js');
let Segment = require('./Segment.js');
let SparseImage = require('./SparseImage.js');
let ClassificationResult = require('./ClassificationResult.js');
let PanoramaInfo = require('./PanoramaInfo.js');
let ImageDifferenceValue = require('./ImageDifferenceValue.js');
let SparseOccupancyGrid = require('./SparseOccupancyGrid.js');
let BoundingBoxArray = require('./BoundingBoxArray.js');
let ContactSensor = require('./ContactSensor.js');
let BoundingBoxMovement = require('./BoundingBoxMovement.js');
let ContactSensorArray = require('./ContactSensorArray.js');
let WeightedPoseArray = require('./WeightedPoseArray.js');
let LabelArray = require('./LabelArray.js');
let PeoplePose = require('./PeoplePose.js');
let ClipResult = require('./ClipResult.js');
let ColorHistogram = require('./ColorHistogram.js');
let DepthErrorResult = require('./DepthErrorResult.js');
let BoundingBox = require('./BoundingBox.js');
let PlotData = require('./PlotData.js');
let QueryAndProbability = require('./QueryAndProbability.js');
let Torus = require('./Torus.js');
let HandPose = require('./HandPose.js');
let ParallelEdgeArray = require('./ParallelEdgeArray.js');
let RectArray = require('./RectArray.js');
let RotatedRectStamped = require('./RotatedRectStamped.js');
let HumanSkeletonArray = require('./HumanSkeletonArray.js');
let TrackerStatus = require('./TrackerStatus.js');
let Circle2DArray = require('./Circle2DArray.js');
let Int32Stamped = require('./Int32Stamped.js');
let BoolStamped = require('./BoolStamped.js');
let TimeRange = require('./TimeRange.js');
let TrackingStatus = require('./TrackingStatus.js');
let ExifGPSInfo = require('./ExifGPSInfo.js');
let SegmentArray = require('./SegmentArray.js');
let Histogram = require('./Histogram.js');
let DepthCalibrationParameter = require('./DepthCalibrationParameter.js');
let SnapItRequest = require('./SnapItRequest.js');
let SegmentStamped = require('./SegmentStamped.js');
let SimpleHandle = require('./SimpleHandle.js');
let HandPoseArray = require('./HandPoseArray.js');
let PlotDataArray = require('./PlotDataArray.js');
let Label = require('./Label.js');
let SimpleOccupancyGrid = require('./SimpleOccupancyGrid.js');
let LineArray = require('./LineArray.js');
let HistogramWithRangeBin = require('./HistogramWithRangeBin.js');
let HumanSkeleton = require('./HumanSkeleton.js');
let HeightmapConfig = require('./HeightmapConfig.js');
let PeoplePoseArray = require('./PeoplePoseArray.js');
let TorusArray = require('./TorusArray.js');
let ColorHistogramArray = require('./ColorHistogramArray.js');
let VQAResult = require('./VQAResult.js');
let Circle2D = require('./Circle2D.js');
let Rect = require('./Rect.js');
let ICPResult = require('./ICPResult.js');
let HistogramWithRangeArray = require('./HistogramWithRangeArray.js');
let HistogramWithRange = require('./HistogramWithRange.js');
let QuestionAndAnswerText = require('./QuestionAndAnswerText.js');
let ExifTags = require('./ExifTags.js');
let ObjectArray = require('./ObjectArray.js');
let VectorArray = require('./VectorArray.js');
let SlicedPointCloud = require('./SlicedPointCloud.js');
let ClusterPointIndices = require('./ClusterPointIndices.js');
let Spectrum = require('./Spectrum.js');
let ParallelEdge = require('./ParallelEdge.js');
let ClassificationTaskActionResult = require('./ClassificationTaskActionResult.js');
let VQATaskActionGoal = require('./VQATaskActionGoal.js');
let VQATaskActionResult = require('./VQATaskActionResult.js');
let VQATaskFeedback = require('./VQATaskFeedback.js');
let VQATaskGoal = require('./VQATaskGoal.js');
let ClassificationTaskResult = require('./ClassificationTaskResult.js');
let ClassificationTaskGoal = require('./ClassificationTaskGoal.js');
let VQATaskResult = require('./VQATaskResult.js');
let VQATaskActionFeedback = require('./VQATaskActionFeedback.js');
let VQATaskAction = require('./VQATaskAction.js');
let ClassificationTaskActionFeedback = require('./ClassificationTaskActionFeedback.js');
let ClassificationTaskFeedback = require('./ClassificationTaskFeedback.js');
let ClassificationTaskAction = require('./ClassificationTaskAction.js');
let ClassificationTaskActionGoal = require('./ClassificationTaskActionGoal.js');

module.exports = {
  SparseOccupancyGridCell: SparseOccupancyGridCell,
  SimpleOccupancyGridArray: SimpleOccupancyGridArray,
  SparseOccupancyGridArray: SparseOccupancyGridArray,
  Object: Object,
  PosedCameraInfo: PosedCameraInfo,
  PolygonArray: PolygonArray,
  PointsArray: PointsArray,
  BoundingBoxArrayWithCameraInfo: BoundingBoxArrayWithCameraInfo,
  Accuracy: Accuracy,
  Line: Line,
  SparseOccupancyGridColumn: SparseOccupancyGridColumn,
  RotatedRect: RotatedRect,
  ModelCoefficientsArray: ModelCoefficientsArray,
  Segment: Segment,
  SparseImage: SparseImage,
  ClassificationResult: ClassificationResult,
  PanoramaInfo: PanoramaInfo,
  ImageDifferenceValue: ImageDifferenceValue,
  SparseOccupancyGrid: SparseOccupancyGrid,
  BoundingBoxArray: BoundingBoxArray,
  ContactSensor: ContactSensor,
  BoundingBoxMovement: BoundingBoxMovement,
  ContactSensorArray: ContactSensorArray,
  WeightedPoseArray: WeightedPoseArray,
  LabelArray: LabelArray,
  PeoplePose: PeoplePose,
  ClipResult: ClipResult,
  ColorHistogram: ColorHistogram,
  DepthErrorResult: DepthErrorResult,
  BoundingBox: BoundingBox,
  PlotData: PlotData,
  QueryAndProbability: QueryAndProbability,
  Torus: Torus,
  HandPose: HandPose,
  ParallelEdgeArray: ParallelEdgeArray,
  RectArray: RectArray,
  RotatedRectStamped: RotatedRectStamped,
  HumanSkeletonArray: HumanSkeletonArray,
  TrackerStatus: TrackerStatus,
  Circle2DArray: Circle2DArray,
  Int32Stamped: Int32Stamped,
  BoolStamped: BoolStamped,
  TimeRange: TimeRange,
  TrackingStatus: TrackingStatus,
  ExifGPSInfo: ExifGPSInfo,
  SegmentArray: SegmentArray,
  Histogram: Histogram,
  DepthCalibrationParameter: DepthCalibrationParameter,
  SnapItRequest: SnapItRequest,
  SegmentStamped: SegmentStamped,
  SimpleHandle: SimpleHandle,
  HandPoseArray: HandPoseArray,
  PlotDataArray: PlotDataArray,
  Label: Label,
  SimpleOccupancyGrid: SimpleOccupancyGrid,
  LineArray: LineArray,
  HistogramWithRangeBin: HistogramWithRangeBin,
  HumanSkeleton: HumanSkeleton,
  HeightmapConfig: HeightmapConfig,
  PeoplePoseArray: PeoplePoseArray,
  TorusArray: TorusArray,
  ColorHistogramArray: ColorHistogramArray,
  VQAResult: VQAResult,
  Circle2D: Circle2D,
  Rect: Rect,
  ICPResult: ICPResult,
  HistogramWithRangeArray: HistogramWithRangeArray,
  HistogramWithRange: HistogramWithRange,
  QuestionAndAnswerText: QuestionAndAnswerText,
  ExifTags: ExifTags,
  ObjectArray: ObjectArray,
  VectorArray: VectorArray,
  SlicedPointCloud: SlicedPointCloud,
  ClusterPointIndices: ClusterPointIndices,
  Spectrum: Spectrum,
  ParallelEdge: ParallelEdge,
  ClassificationTaskActionResult: ClassificationTaskActionResult,
  VQATaskActionGoal: VQATaskActionGoal,
  VQATaskActionResult: VQATaskActionResult,
  VQATaskFeedback: VQATaskFeedback,
  VQATaskGoal: VQATaskGoal,
  ClassificationTaskResult: ClassificationTaskResult,
  ClassificationTaskGoal: ClassificationTaskGoal,
  VQATaskResult: VQATaskResult,
  VQATaskActionFeedback: VQATaskActionFeedback,
  VQATaskAction: VQATaskAction,
  ClassificationTaskActionFeedback: ClassificationTaskActionFeedback,
  ClassificationTaskFeedback: ClassificationTaskFeedback,
  ClassificationTaskAction: ClassificationTaskAction,
  ClassificationTaskActionGoal: ClassificationTaskActionGoal,
};
