// Auto-generated. Do not edit!

// (in-package jsk_recognition_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let ExifGPSInfo = require('./ExifGPSInfo.js');

//-----------------------------------------------------------

class ExifTags {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.interop_index = null;
      this.image_width = null;
      this.image_height = null;
      this.bits_per_sample = null;
      this.photometric_interpretation = null;
      this.image_description = null;
      this.make = null;
      this.model = null;
      this.strip_offsets = null;
      this.orientation = null;
      this.samples_per_pixel = null;
      this.rows_per_strip = null;
      this.strip_byte_counts = null;
      this.x_resolution = null;
      this.y_resolution = null;
      this.planar_configuration = null;
      this.resolution_unit = null;
      this.transfer_function = null;
      this.software = null;
      this.date_time = null;
      this.artist = null;
      this.white_point = null;
      this.primary_chromaticities = null;
      this.tile_width = null;
      this.tile_length = null;
      this.jpg_from_raw_start = null;
      this.jpg_from_raw_length = null;
      this.ycb_cr_Coefficients = null;
      this.ycb_cr_sub_sampling = null;
      this.ycb_cr_positioning = null;
      this.reference_black_white = null;
      this.copyright = null;
      this.exposure_time = null;
      this.f_number = null;
      this.exposure_program = null;
      this.gps_info = null;
      this.iso = null;
      this.sensitivity_type = null;
      this.standard_output_sensitivity = null;
      this.recommended_exposure_index = null;
      this.iso_speed = null;
      this.iso_speed_latitudeyyy = null;
      this.iso_speed_latitudezzz = null;
      this.exif_version = null;
      this.date_time_original = null;
      this.date_time_digitized = null;
      this.offset_time = null;
      this.offset_time_original = null;
      this.offset_time_digitized = null;
      this.components_configuration = null;
      this.compressed_bits_per_pixel = null;
      this.shutter_speed_value = null;
      this.aperture_value = null;
      this.brightness_value = null;
      this.exposure_bias_value = null;
      this.max_aperture_value = null;
      this.subject_distance = null;
      this.metering_mode = null;
      this.light_source = null;
      this.flash = null;
      this.focal_length = null;
      this.subject_area = null;
      this.user_comment = null;
      this.subsec_time = null;
      this.subsec_time_original = null;
      this.subsec_time_digitized = null;
      this.temperature = null;
      this.humidity = null;
      this.pressure = null;
      this.water_depth = null;
      this.acceleration = null;
      this.camera_elevation_angle = null;
      this.flash_pix_version = null;
      this.color_space = null;
      this.exif_image_width = null;
      this.exif_image_height = null;
      this.related_sound_file = null;
      this.flash_energy = null;
      this.focal_plane_x_resolution = null;
      this.focal_plane_y_resolution = null;
      this.focal_plane_resolution_unit = null;
      this.subject_location = null;
      this.exposure_index = null;
      this.sensing_method = null;
      this.scene_type = null;
      this.custom_rendered = null;
      this.exposure_mode = null;
      this.white_balance = null;
      this.digital_zoom_ratio = null;
      this.focal_length_in_35mm_film = null;
      this.scene_capture_type = null;
      this.gain_control = null;
      this.contrast = null;
      this.saturation = null;
      this.sharpness = null;
      this.subject_distance_range = null;
      this.image_unique_id = null;
      this.camera_owner_name = null;
      this.body_serial_number = null;
      this.lens_specification = null;
      this.lens_make = null;
      this.lens_model = null;
      this.lens_serial_number = null;
      this.composite_image = null;
      this.composite_image_count = null;
      this.gamma = null;
    }
    else {
      if (initObj.hasOwnProperty('interop_index')) {
        this.interop_index = initObj.interop_index
      }
      else {
        this.interop_index = '';
      }
      if (initObj.hasOwnProperty('image_width')) {
        this.image_width = initObj.image_width
      }
      else {
        this.image_width = 0;
      }
      if (initObj.hasOwnProperty('image_height')) {
        this.image_height = initObj.image_height
      }
      else {
        this.image_height = 0;
      }
      if (initObj.hasOwnProperty('bits_per_sample')) {
        this.bits_per_sample = initObj.bits_per_sample
      }
      else {
        this.bits_per_sample = [];
      }
      if (initObj.hasOwnProperty('photometric_interpretation')) {
        this.photometric_interpretation = initObj.photometric_interpretation
      }
      else {
        this.photometric_interpretation = 0;
      }
      if (initObj.hasOwnProperty('image_description')) {
        this.image_description = initObj.image_description
      }
      else {
        this.image_description = '';
      }
      if (initObj.hasOwnProperty('make')) {
        this.make = initObj.make
      }
      else {
        this.make = '';
      }
      if (initObj.hasOwnProperty('model')) {
        this.model = initObj.model
      }
      else {
        this.model = '';
      }
      if (initObj.hasOwnProperty('strip_offsets')) {
        this.strip_offsets = initObj.strip_offsets
      }
      else {
        this.strip_offsets = 0;
      }
      if (initObj.hasOwnProperty('orientation')) {
        this.orientation = initObj.orientation
      }
      else {
        this.orientation = 0;
      }
      if (initObj.hasOwnProperty('samples_per_pixel')) {
        this.samples_per_pixel = initObj.samples_per_pixel
      }
      else {
        this.samples_per_pixel = 0;
      }
      if (initObj.hasOwnProperty('rows_per_strip')) {
        this.rows_per_strip = initObj.rows_per_strip
      }
      else {
        this.rows_per_strip = 0;
      }
      if (initObj.hasOwnProperty('strip_byte_counts')) {
        this.strip_byte_counts = initObj.strip_byte_counts
      }
      else {
        this.strip_byte_counts = 0;
      }
      if (initObj.hasOwnProperty('x_resolution')) {
        this.x_resolution = initObj.x_resolution
      }
      else {
        this.x_resolution = 0.0;
      }
      if (initObj.hasOwnProperty('y_resolution')) {
        this.y_resolution = initObj.y_resolution
      }
      else {
        this.y_resolution = 0.0;
      }
      if (initObj.hasOwnProperty('planar_configuration')) {
        this.planar_configuration = initObj.planar_configuration
      }
      else {
        this.planar_configuration = 0;
      }
      if (initObj.hasOwnProperty('resolution_unit')) {
        this.resolution_unit = initObj.resolution_unit
      }
      else {
        this.resolution_unit = 0;
      }
      if (initObj.hasOwnProperty('transfer_function')) {
        this.transfer_function = initObj.transfer_function
      }
      else {
        this.transfer_function = new Array(768).fill(0);
      }
      if (initObj.hasOwnProperty('software')) {
        this.software = initObj.software
      }
      else {
        this.software = '';
      }
      if (initObj.hasOwnProperty('date_time')) {
        this.date_time = initObj.date_time
      }
      else {
        this.date_time = '';
      }
      if (initObj.hasOwnProperty('artist')) {
        this.artist = initObj.artist
      }
      else {
        this.artist = '';
      }
      if (initObj.hasOwnProperty('white_point')) {
        this.white_point = initObj.white_point
      }
      else {
        this.white_point = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('primary_chromaticities')) {
        this.primary_chromaticities = initObj.primary_chromaticities
      }
      else {
        this.primary_chromaticities = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('tile_width')) {
        this.tile_width = initObj.tile_width
      }
      else {
        this.tile_width = 0;
      }
      if (initObj.hasOwnProperty('tile_length')) {
        this.tile_length = initObj.tile_length
      }
      else {
        this.tile_length = 0;
      }
      if (initObj.hasOwnProperty('jpg_from_raw_start')) {
        this.jpg_from_raw_start = initObj.jpg_from_raw_start
      }
      else {
        this.jpg_from_raw_start = 0;
      }
      if (initObj.hasOwnProperty('jpg_from_raw_length')) {
        this.jpg_from_raw_length = initObj.jpg_from_raw_length
      }
      else {
        this.jpg_from_raw_length = 0;
      }
      if (initObj.hasOwnProperty('ycb_cr_Coefficients')) {
        this.ycb_cr_Coefficients = initObj.ycb_cr_Coefficients
      }
      else {
        this.ycb_cr_Coefficients = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('ycb_cr_sub_sampling')) {
        this.ycb_cr_sub_sampling = initObj.ycb_cr_sub_sampling
      }
      else {
        this.ycb_cr_sub_sampling = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('ycb_cr_positioning')) {
        this.ycb_cr_positioning = initObj.ycb_cr_positioning
      }
      else {
        this.ycb_cr_positioning = 0;
      }
      if (initObj.hasOwnProperty('reference_black_white')) {
        this.reference_black_white = initObj.reference_black_white
      }
      else {
        this.reference_black_white = new Array(6).fill(0);
      }
      if (initObj.hasOwnProperty('copyright')) {
        this.copyright = initObj.copyright
      }
      else {
        this.copyright = '';
      }
      if (initObj.hasOwnProperty('exposure_time')) {
        this.exposure_time = initObj.exposure_time
      }
      else {
        this.exposure_time = 0.0;
      }
      if (initObj.hasOwnProperty('f_number')) {
        this.f_number = initObj.f_number
      }
      else {
        this.f_number = 0.0;
      }
      if (initObj.hasOwnProperty('exposure_program')) {
        this.exposure_program = initObj.exposure_program
      }
      else {
        this.exposure_program = 0;
      }
      if (initObj.hasOwnProperty('gps_info')) {
        this.gps_info = initObj.gps_info
      }
      else {
        this.gps_info = new ExifGPSInfo();
      }
      if (initObj.hasOwnProperty('iso')) {
        this.iso = initObj.iso
      }
      else {
        this.iso = [];
      }
      if (initObj.hasOwnProperty('sensitivity_type')) {
        this.sensitivity_type = initObj.sensitivity_type
      }
      else {
        this.sensitivity_type = 0;
      }
      if (initObj.hasOwnProperty('standard_output_sensitivity')) {
        this.standard_output_sensitivity = initObj.standard_output_sensitivity
      }
      else {
        this.standard_output_sensitivity = 0;
      }
      if (initObj.hasOwnProperty('recommended_exposure_index')) {
        this.recommended_exposure_index = initObj.recommended_exposure_index
      }
      else {
        this.recommended_exposure_index = 0;
      }
      if (initObj.hasOwnProperty('iso_speed')) {
        this.iso_speed = initObj.iso_speed
      }
      else {
        this.iso_speed = 0;
      }
      if (initObj.hasOwnProperty('iso_speed_latitudeyyy')) {
        this.iso_speed_latitudeyyy = initObj.iso_speed_latitudeyyy
      }
      else {
        this.iso_speed_latitudeyyy = 0;
      }
      if (initObj.hasOwnProperty('iso_speed_latitudezzz')) {
        this.iso_speed_latitudezzz = initObj.iso_speed_latitudezzz
      }
      else {
        this.iso_speed_latitudezzz = 0;
      }
      if (initObj.hasOwnProperty('exif_version')) {
        this.exif_version = initObj.exif_version
      }
      else {
        this.exif_version = '';
      }
      if (initObj.hasOwnProperty('date_time_original')) {
        this.date_time_original = initObj.date_time_original
      }
      else {
        this.date_time_original = '';
      }
      if (initObj.hasOwnProperty('date_time_digitized')) {
        this.date_time_digitized = initObj.date_time_digitized
      }
      else {
        this.date_time_digitized = '';
      }
      if (initObj.hasOwnProperty('offset_time')) {
        this.offset_time = initObj.offset_time
      }
      else {
        this.offset_time = '';
      }
      if (initObj.hasOwnProperty('offset_time_original')) {
        this.offset_time_original = initObj.offset_time_original
      }
      else {
        this.offset_time_original = '';
      }
      if (initObj.hasOwnProperty('offset_time_digitized')) {
        this.offset_time_digitized = initObj.offset_time_digitized
      }
      else {
        this.offset_time_digitized = '';
      }
      if (initObj.hasOwnProperty('components_configuration')) {
        this.components_configuration = initObj.components_configuration
      }
      else {
        this.components_configuration = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('compressed_bits_per_pixel')) {
        this.compressed_bits_per_pixel = initObj.compressed_bits_per_pixel
      }
      else {
        this.compressed_bits_per_pixel = 0.0;
      }
      if (initObj.hasOwnProperty('shutter_speed_value')) {
        this.shutter_speed_value = initObj.shutter_speed_value
      }
      else {
        this.shutter_speed_value = 0.0;
      }
      if (initObj.hasOwnProperty('aperture_value')) {
        this.aperture_value = initObj.aperture_value
      }
      else {
        this.aperture_value = 0.0;
      }
      if (initObj.hasOwnProperty('brightness_value')) {
        this.brightness_value = initObj.brightness_value
      }
      else {
        this.brightness_value = 0.0;
      }
      if (initObj.hasOwnProperty('exposure_bias_value')) {
        this.exposure_bias_value = initObj.exposure_bias_value
      }
      else {
        this.exposure_bias_value = 0.0;
      }
      if (initObj.hasOwnProperty('max_aperture_value')) {
        this.max_aperture_value = initObj.max_aperture_value
      }
      else {
        this.max_aperture_value = 0.0;
      }
      if (initObj.hasOwnProperty('subject_distance')) {
        this.subject_distance = initObj.subject_distance
      }
      else {
        this.subject_distance = 0.0;
      }
      if (initObj.hasOwnProperty('metering_mode')) {
        this.metering_mode = initObj.metering_mode
      }
      else {
        this.metering_mode = 0;
      }
      if (initObj.hasOwnProperty('light_source')) {
        this.light_source = initObj.light_source
      }
      else {
        this.light_source = 0;
      }
      if (initObj.hasOwnProperty('flash')) {
        this.flash = initObj.flash
      }
      else {
        this.flash = 0;
      }
      if (initObj.hasOwnProperty('focal_length')) {
        this.focal_length = initObj.focal_length
      }
      else {
        this.focal_length = 0.0;
      }
      if (initObj.hasOwnProperty('subject_area')) {
        this.subject_area = initObj.subject_area
      }
      else {
        this.subject_area = [];
      }
      if (initObj.hasOwnProperty('user_comment')) {
        this.user_comment = initObj.user_comment
      }
      else {
        this.user_comment = '';
      }
      if (initObj.hasOwnProperty('subsec_time')) {
        this.subsec_time = initObj.subsec_time
      }
      else {
        this.subsec_time = '';
      }
      if (initObj.hasOwnProperty('subsec_time_original')) {
        this.subsec_time_original = initObj.subsec_time_original
      }
      else {
        this.subsec_time_original = '';
      }
      if (initObj.hasOwnProperty('subsec_time_digitized')) {
        this.subsec_time_digitized = initObj.subsec_time_digitized
      }
      else {
        this.subsec_time_digitized = '';
      }
      if (initObj.hasOwnProperty('temperature')) {
        this.temperature = initObj.temperature
      }
      else {
        this.temperature = 0.0;
      }
      if (initObj.hasOwnProperty('humidity')) {
        this.humidity = initObj.humidity
      }
      else {
        this.humidity = 0.0;
      }
      if (initObj.hasOwnProperty('pressure')) {
        this.pressure = initObj.pressure
      }
      else {
        this.pressure = 0.0;
      }
      if (initObj.hasOwnProperty('water_depth')) {
        this.water_depth = initObj.water_depth
      }
      else {
        this.water_depth = 0.0;
      }
      if (initObj.hasOwnProperty('acceleration')) {
        this.acceleration = initObj.acceleration
      }
      else {
        this.acceleration = 0.0;
      }
      if (initObj.hasOwnProperty('camera_elevation_angle')) {
        this.camera_elevation_angle = initObj.camera_elevation_angle
      }
      else {
        this.camera_elevation_angle = 0.0;
      }
      if (initObj.hasOwnProperty('flash_pix_version')) {
        this.flash_pix_version = initObj.flash_pix_version
      }
      else {
        this.flash_pix_version = '';
      }
      if (initObj.hasOwnProperty('color_space')) {
        this.color_space = initObj.color_space
      }
      else {
        this.color_space = 0;
      }
      if (initObj.hasOwnProperty('exif_image_width')) {
        this.exif_image_width = initObj.exif_image_width
      }
      else {
        this.exif_image_width = 0;
      }
      if (initObj.hasOwnProperty('exif_image_height')) {
        this.exif_image_height = initObj.exif_image_height
      }
      else {
        this.exif_image_height = 0;
      }
      if (initObj.hasOwnProperty('related_sound_file')) {
        this.related_sound_file = initObj.related_sound_file
      }
      else {
        this.related_sound_file = '';
      }
      if (initObj.hasOwnProperty('flash_energy')) {
        this.flash_energy = initObj.flash_energy
      }
      else {
        this.flash_energy = 0.0;
      }
      if (initObj.hasOwnProperty('focal_plane_x_resolution')) {
        this.focal_plane_x_resolution = initObj.focal_plane_x_resolution
      }
      else {
        this.focal_plane_x_resolution = 0.0;
      }
      if (initObj.hasOwnProperty('focal_plane_y_resolution')) {
        this.focal_plane_y_resolution = initObj.focal_plane_y_resolution
      }
      else {
        this.focal_plane_y_resolution = 0.0;
      }
      if (initObj.hasOwnProperty('focal_plane_resolution_unit')) {
        this.focal_plane_resolution_unit = initObj.focal_plane_resolution_unit
      }
      else {
        this.focal_plane_resolution_unit = 0;
      }
      if (initObj.hasOwnProperty('subject_location')) {
        this.subject_location = initObj.subject_location
      }
      else {
        this.subject_location = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('exposure_index')) {
        this.exposure_index = initObj.exposure_index
      }
      else {
        this.exposure_index = 0.0;
      }
      if (initObj.hasOwnProperty('sensing_method')) {
        this.sensing_method = initObj.sensing_method
      }
      else {
        this.sensing_method = 0;
      }
      if (initObj.hasOwnProperty('scene_type')) {
        this.scene_type = initObj.scene_type
      }
      else {
        this.scene_type = '';
      }
      if (initObj.hasOwnProperty('custom_rendered')) {
        this.custom_rendered = initObj.custom_rendered
      }
      else {
        this.custom_rendered = 0;
      }
      if (initObj.hasOwnProperty('exposure_mode')) {
        this.exposure_mode = initObj.exposure_mode
      }
      else {
        this.exposure_mode = 0;
      }
      if (initObj.hasOwnProperty('white_balance')) {
        this.white_balance = initObj.white_balance
      }
      else {
        this.white_balance = 0;
      }
      if (initObj.hasOwnProperty('digital_zoom_ratio')) {
        this.digital_zoom_ratio = initObj.digital_zoom_ratio
      }
      else {
        this.digital_zoom_ratio = 0.0;
      }
      if (initObj.hasOwnProperty('focal_length_in_35mm_film')) {
        this.focal_length_in_35mm_film = initObj.focal_length_in_35mm_film
      }
      else {
        this.focal_length_in_35mm_film = 0;
      }
      if (initObj.hasOwnProperty('scene_capture_type')) {
        this.scene_capture_type = initObj.scene_capture_type
      }
      else {
        this.scene_capture_type = 0;
      }
      if (initObj.hasOwnProperty('gain_control')) {
        this.gain_control = initObj.gain_control
      }
      else {
        this.gain_control = 0;
      }
      if (initObj.hasOwnProperty('contrast')) {
        this.contrast = initObj.contrast
      }
      else {
        this.contrast = 0;
      }
      if (initObj.hasOwnProperty('saturation')) {
        this.saturation = initObj.saturation
      }
      else {
        this.saturation = 0;
      }
      if (initObj.hasOwnProperty('sharpness')) {
        this.sharpness = initObj.sharpness
      }
      else {
        this.sharpness = 0;
      }
      if (initObj.hasOwnProperty('subject_distance_range')) {
        this.subject_distance_range = initObj.subject_distance_range
      }
      else {
        this.subject_distance_range = 0;
      }
      if (initObj.hasOwnProperty('image_unique_id')) {
        this.image_unique_id = initObj.image_unique_id
      }
      else {
        this.image_unique_id = '';
      }
      if (initObj.hasOwnProperty('camera_owner_name')) {
        this.camera_owner_name = initObj.camera_owner_name
      }
      else {
        this.camera_owner_name = '';
      }
      if (initObj.hasOwnProperty('body_serial_number')) {
        this.body_serial_number = initObj.body_serial_number
      }
      else {
        this.body_serial_number = '';
      }
      if (initObj.hasOwnProperty('lens_specification')) {
        this.lens_specification = initObj.lens_specification
      }
      else {
        this.lens_specification = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('lens_make')) {
        this.lens_make = initObj.lens_make
      }
      else {
        this.lens_make = '';
      }
      if (initObj.hasOwnProperty('lens_model')) {
        this.lens_model = initObj.lens_model
      }
      else {
        this.lens_model = '';
      }
      if (initObj.hasOwnProperty('lens_serial_number')) {
        this.lens_serial_number = initObj.lens_serial_number
      }
      else {
        this.lens_serial_number = '';
      }
      if (initObj.hasOwnProperty('composite_image')) {
        this.composite_image = initObj.composite_image
      }
      else {
        this.composite_image = 0;
      }
      if (initObj.hasOwnProperty('composite_image_count')) {
        this.composite_image_count = initObj.composite_image_count
      }
      else {
        this.composite_image_count = new Array(2).fill(0);
      }
      if (initObj.hasOwnProperty('gamma')) {
        this.gamma = initObj.gamma
      }
      else {
        this.gamma = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExifTags
    // Serialize message field [interop_index]
    bufferOffset = _serializer.string(obj.interop_index, buffer, bufferOffset);
    // Serialize message field [image_width]
    bufferOffset = _serializer.uint32(obj.image_width, buffer, bufferOffset);
    // Serialize message field [image_height]
    bufferOffset = _serializer.uint32(obj.image_height, buffer, bufferOffset);
    // Serialize message field [bits_per_sample]
    bufferOffset = _arraySerializer.uint16(obj.bits_per_sample, buffer, bufferOffset, null);
    // Serialize message field [photometric_interpretation]
    bufferOffset = _serializer.uint16(obj.photometric_interpretation, buffer, bufferOffset);
    // Serialize message field [image_description]
    bufferOffset = _serializer.string(obj.image_description, buffer, bufferOffset);
    // Serialize message field [make]
    bufferOffset = _serializer.string(obj.make, buffer, bufferOffset);
    // Serialize message field [model]
    bufferOffset = _serializer.string(obj.model, buffer, bufferOffset);
    // Serialize message field [strip_offsets]
    bufferOffset = _serializer.uint32(obj.strip_offsets, buffer, bufferOffset);
    // Serialize message field [orientation]
    bufferOffset = _serializer.uint16(obj.orientation, buffer, bufferOffset);
    // Serialize message field [samples_per_pixel]
    bufferOffset = _serializer.uint16(obj.samples_per_pixel, buffer, bufferOffset);
    // Serialize message field [rows_per_strip]
    bufferOffset = _serializer.uint32(obj.rows_per_strip, buffer, bufferOffset);
    // Serialize message field [strip_byte_counts]
    bufferOffset = _serializer.uint32(obj.strip_byte_counts, buffer, bufferOffset);
    // Serialize message field [x_resolution]
    bufferOffset = _serializer.float64(obj.x_resolution, buffer, bufferOffset);
    // Serialize message field [y_resolution]
    bufferOffset = _serializer.float64(obj.y_resolution, buffer, bufferOffset);
    // Serialize message field [planar_configuration]
    bufferOffset = _serializer.uint16(obj.planar_configuration, buffer, bufferOffset);
    // Serialize message field [resolution_unit]
    bufferOffset = _serializer.uint16(obj.resolution_unit, buffer, bufferOffset);
    // Check that the constant length array field [transfer_function] has the right length
    if (obj.transfer_function.length !== 768) {
      throw new Error('Unable to serialize array field transfer_function - length must be 768')
    }
    // Serialize message field [transfer_function]
    bufferOffset = _arraySerializer.uint16(obj.transfer_function, buffer, bufferOffset, 768);
    // Serialize message field [software]
    bufferOffset = _serializer.string(obj.software, buffer, bufferOffset);
    // Serialize message field [date_time]
    bufferOffset = _serializer.string(obj.date_time, buffer, bufferOffset);
    // Serialize message field [artist]
    bufferOffset = _serializer.string(obj.artist, buffer, bufferOffset);
    // Check that the constant length array field [white_point] has the right length
    if (obj.white_point.length !== 2) {
      throw new Error('Unable to serialize array field white_point - length must be 2')
    }
    // Serialize message field [white_point]
    bufferOffset = _arraySerializer.float64(obj.white_point, buffer, bufferOffset, 2);
    // Check that the constant length array field [primary_chromaticities] has the right length
    if (obj.primary_chromaticities.length !== 6) {
      throw new Error('Unable to serialize array field primary_chromaticities - length must be 6')
    }
    // Serialize message field [primary_chromaticities]
    bufferOffset = _arraySerializer.float64(obj.primary_chromaticities, buffer, bufferOffset, 6);
    // Serialize message field [tile_width]
    bufferOffset = _serializer.uint32(obj.tile_width, buffer, bufferOffset);
    // Serialize message field [tile_length]
    bufferOffset = _serializer.uint32(obj.tile_length, buffer, bufferOffset);
    // Serialize message field [jpg_from_raw_start]
    bufferOffset = _serializer.uint32(obj.jpg_from_raw_start, buffer, bufferOffset);
    // Serialize message field [jpg_from_raw_length]
    bufferOffset = _serializer.uint32(obj.jpg_from_raw_length, buffer, bufferOffset);
    // Check that the constant length array field [ycb_cr_Coefficients] has the right length
    if (obj.ycb_cr_Coefficients.length !== 3) {
      throw new Error('Unable to serialize array field ycb_cr_Coefficients - length must be 3')
    }
    // Serialize message field [ycb_cr_Coefficients]
    bufferOffset = _arraySerializer.float64(obj.ycb_cr_Coefficients, buffer, bufferOffset, 3);
    // Check that the constant length array field [ycb_cr_sub_sampling] has the right length
    if (obj.ycb_cr_sub_sampling.length !== 2) {
      throw new Error('Unable to serialize array field ycb_cr_sub_sampling - length must be 2')
    }
    // Serialize message field [ycb_cr_sub_sampling]
    bufferOffset = _arraySerializer.uint16(obj.ycb_cr_sub_sampling, buffer, bufferOffset, 2);
    // Serialize message field [ycb_cr_positioning]
    bufferOffset = _serializer.uint16(obj.ycb_cr_positioning, buffer, bufferOffset);
    // Check that the constant length array field [reference_black_white] has the right length
    if (obj.reference_black_white.length !== 6) {
      throw new Error('Unable to serialize array field reference_black_white - length must be 6')
    }
    // Serialize message field [reference_black_white]
    bufferOffset = _arraySerializer.float64(obj.reference_black_white, buffer, bufferOffset, 6);
    // Serialize message field [copyright]
    bufferOffset = _serializer.string(obj.copyright, buffer, bufferOffset);
    // Serialize message field [exposure_time]
    bufferOffset = _serializer.float64(obj.exposure_time, buffer, bufferOffset);
    // Serialize message field [f_number]
    bufferOffset = _serializer.float64(obj.f_number, buffer, bufferOffset);
    // Serialize message field [exposure_program]
    bufferOffset = _serializer.uint16(obj.exposure_program, buffer, bufferOffset);
    // Serialize message field [gps_info]
    bufferOffset = ExifGPSInfo.serialize(obj.gps_info, buffer, bufferOffset);
    // Serialize message field [iso]
    bufferOffset = _arraySerializer.uint16(obj.iso, buffer, bufferOffset, null);
    // Serialize message field [sensitivity_type]
    bufferOffset = _serializer.uint16(obj.sensitivity_type, buffer, bufferOffset);
    // Serialize message field [standard_output_sensitivity]
    bufferOffset = _serializer.uint32(obj.standard_output_sensitivity, buffer, bufferOffset);
    // Serialize message field [recommended_exposure_index]
    bufferOffset = _serializer.uint32(obj.recommended_exposure_index, buffer, bufferOffset);
    // Serialize message field [iso_speed]
    bufferOffset = _serializer.uint32(obj.iso_speed, buffer, bufferOffset);
    // Serialize message field [iso_speed_latitudeyyy]
    bufferOffset = _serializer.uint32(obj.iso_speed_latitudeyyy, buffer, bufferOffset);
    // Serialize message field [iso_speed_latitudezzz]
    bufferOffset = _serializer.uint32(obj.iso_speed_latitudezzz, buffer, bufferOffset);
    // Serialize message field [exif_version]
    bufferOffset = _serializer.string(obj.exif_version, buffer, bufferOffset);
    // Serialize message field [date_time_original]
    bufferOffset = _serializer.string(obj.date_time_original, buffer, bufferOffset);
    // Serialize message field [date_time_digitized]
    bufferOffset = _serializer.string(obj.date_time_digitized, buffer, bufferOffset);
    // Serialize message field [offset_time]
    bufferOffset = _serializer.string(obj.offset_time, buffer, bufferOffset);
    // Serialize message field [offset_time_original]
    bufferOffset = _serializer.string(obj.offset_time_original, buffer, bufferOffset);
    // Serialize message field [offset_time_digitized]
    bufferOffset = _serializer.string(obj.offset_time_digitized, buffer, bufferOffset);
    // Check that the constant length array field [components_configuration] has the right length
    if (obj.components_configuration.length !== 4) {
      throw new Error('Unable to serialize array field components_configuration - length must be 4')
    }
    // Serialize message field [components_configuration]
    bufferOffset = _arraySerializer.uint8(obj.components_configuration, buffer, bufferOffset, 4);
    // Serialize message field [compressed_bits_per_pixel]
    bufferOffset = _serializer.float64(obj.compressed_bits_per_pixel, buffer, bufferOffset);
    // Serialize message field [shutter_speed_value]
    bufferOffset = _serializer.float64(obj.shutter_speed_value, buffer, bufferOffset);
    // Serialize message field [aperture_value]
    bufferOffset = _serializer.float64(obj.aperture_value, buffer, bufferOffset);
    // Serialize message field [brightness_value]
    bufferOffset = _serializer.float64(obj.brightness_value, buffer, bufferOffset);
    // Serialize message field [exposure_bias_value]
    bufferOffset = _serializer.float64(obj.exposure_bias_value, buffer, bufferOffset);
    // Serialize message field [max_aperture_value]
    bufferOffset = _serializer.float64(obj.max_aperture_value, buffer, bufferOffset);
    // Serialize message field [subject_distance]
    bufferOffset = _serializer.float64(obj.subject_distance, buffer, bufferOffset);
    // Serialize message field [metering_mode]
    bufferOffset = _serializer.uint16(obj.metering_mode, buffer, bufferOffset);
    // Serialize message field [light_source]
    bufferOffset = _serializer.uint16(obj.light_source, buffer, bufferOffset);
    // Serialize message field [flash]
    bufferOffset = _serializer.uint16(obj.flash, buffer, bufferOffset);
    // Serialize message field [focal_length]
    bufferOffset = _serializer.float64(obj.focal_length, buffer, bufferOffset);
    // Serialize message field [subject_area]
    bufferOffset = _arraySerializer.uint16(obj.subject_area, buffer, bufferOffset, null);
    // Serialize message field [user_comment]
    bufferOffset = _serializer.string(obj.user_comment, buffer, bufferOffset);
    // Serialize message field [subsec_time]
    bufferOffset = _serializer.string(obj.subsec_time, buffer, bufferOffset);
    // Serialize message field [subsec_time_original]
    bufferOffset = _serializer.string(obj.subsec_time_original, buffer, bufferOffset);
    // Serialize message field [subsec_time_digitized]
    bufferOffset = _serializer.string(obj.subsec_time_digitized, buffer, bufferOffset);
    // Serialize message field [temperature]
    bufferOffset = _serializer.float64(obj.temperature, buffer, bufferOffset);
    // Serialize message field [humidity]
    bufferOffset = _serializer.float64(obj.humidity, buffer, bufferOffset);
    // Serialize message field [pressure]
    bufferOffset = _serializer.float64(obj.pressure, buffer, bufferOffset);
    // Serialize message field [water_depth]
    bufferOffset = _serializer.float64(obj.water_depth, buffer, bufferOffset);
    // Serialize message field [acceleration]
    bufferOffset = _serializer.float64(obj.acceleration, buffer, bufferOffset);
    // Serialize message field [camera_elevation_angle]
    bufferOffset = _serializer.float64(obj.camera_elevation_angle, buffer, bufferOffset);
    // Serialize message field [flash_pix_version]
    bufferOffset = _serializer.string(obj.flash_pix_version, buffer, bufferOffset);
    // Serialize message field [color_space]
    bufferOffset = _serializer.uint16(obj.color_space, buffer, bufferOffset);
    // Serialize message field [exif_image_width]
    bufferOffset = _serializer.uint16(obj.exif_image_width, buffer, bufferOffset);
    // Serialize message field [exif_image_height]
    bufferOffset = _serializer.uint16(obj.exif_image_height, buffer, bufferOffset);
    // Serialize message field [related_sound_file]
    bufferOffset = _serializer.string(obj.related_sound_file, buffer, bufferOffset);
    // Serialize message field [flash_energy]
    bufferOffset = _serializer.float64(obj.flash_energy, buffer, bufferOffset);
    // Serialize message field [focal_plane_x_resolution]
    bufferOffset = _serializer.float64(obj.focal_plane_x_resolution, buffer, bufferOffset);
    // Serialize message field [focal_plane_y_resolution]
    bufferOffset = _serializer.float64(obj.focal_plane_y_resolution, buffer, bufferOffset);
    // Serialize message field [focal_plane_resolution_unit]
    bufferOffset = _serializer.uint16(obj.focal_plane_resolution_unit, buffer, bufferOffset);
    // Check that the constant length array field [subject_location] has the right length
    if (obj.subject_location.length !== 2) {
      throw new Error('Unable to serialize array field subject_location - length must be 2')
    }
    // Serialize message field [subject_location]
    bufferOffset = _arraySerializer.uint16(obj.subject_location, buffer, bufferOffset, 2);
    // Serialize message field [exposure_index]
    bufferOffset = _serializer.float64(obj.exposure_index, buffer, bufferOffset);
    // Serialize message field [sensing_method]
    bufferOffset = _serializer.uint16(obj.sensing_method, buffer, bufferOffset);
    // Serialize message field [scene_type]
    bufferOffset = _serializer.string(obj.scene_type, buffer, bufferOffset);
    // Serialize message field [custom_rendered]
    bufferOffset = _serializer.uint16(obj.custom_rendered, buffer, bufferOffset);
    // Serialize message field [exposure_mode]
    bufferOffset = _serializer.uint16(obj.exposure_mode, buffer, bufferOffset);
    // Serialize message field [white_balance]
    bufferOffset = _serializer.uint16(obj.white_balance, buffer, bufferOffset);
    // Serialize message field [digital_zoom_ratio]
    bufferOffset = _serializer.float64(obj.digital_zoom_ratio, buffer, bufferOffset);
    // Serialize message field [focal_length_in_35mm_film]
    bufferOffset = _serializer.uint16(obj.focal_length_in_35mm_film, buffer, bufferOffset);
    // Serialize message field [scene_capture_type]
    bufferOffset = _serializer.uint16(obj.scene_capture_type, buffer, bufferOffset);
    // Serialize message field [gain_control]
    bufferOffset = _serializer.uint16(obj.gain_control, buffer, bufferOffset);
    // Serialize message field [contrast]
    bufferOffset = _serializer.uint16(obj.contrast, buffer, bufferOffset);
    // Serialize message field [saturation]
    bufferOffset = _serializer.uint16(obj.saturation, buffer, bufferOffset);
    // Serialize message field [sharpness]
    bufferOffset = _serializer.uint16(obj.sharpness, buffer, bufferOffset);
    // Serialize message field [subject_distance_range]
    bufferOffset = _serializer.uint16(obj.subject_distance_range, buffer, bufferOffset);
    // Serialize message field [image_unique_id]
    bufferOffset = _serializer.string(obj.image_unique_id, buffer, bufferOffset);
    // Serialize message field [camera_owner_name]
    bufferOffset = _serializer.string(obj.camera_owner_name, buffer, bufferOffset);
    // Serialize message field [body_serial_number]
    bufferOffset = _serializer.string(obj.body_serial_number, buffer, bufferOffset);
    // Check that the constant length array field [lens_specification] has the right length
    if (obj.lens_specification.length !== 4) {
      throw new Error('Unable to serialize array field lens_specification - length must be 4')
    }
    // Serialize message field [lens_specification]
    bufferOffset = _arraySerializer.float64(obj.lens_specification, buffer, bufferOffset, 4);
    // Serialize message field [lens_make]
    bufferOffset = _serializer.string(obj.lens_make, buffer, bufferOffset);
    // Serialize message field [lens_model]
    bufferOffset = _serializer.string(obj.lens_model, buffer, bufferOffset);
    // Serialize message field [lens_serial_number]
    bufferOffset = _serializer.string(obj.lens_serial_number, buffer, bufferOffset);
    // Serialize message field [composite_image]
    bufferOffset = _serializer.uint16(obj.composite_image, buffer, bufferOffset);
    // Check that the constant length array field [composite_image_count] has the right length
    if (obj.composite_image_count.length !== 2) {
      throw new Error('Unable to serialize array field composite_image_count - length must be 2')
    }
    // Serialize message field [composite_image_count]
    bufferOffset = _arraySerializer.uint16(obj.composite_image_count, buffer, bufferOffset, 2);
    // Serialize message field [gamma]
    bufferOffset = _serializer.float64(obj.gamma, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExifTags
    let len;
    let data = new ExifTags(null);
    // Deserialize message field [interop_index]
    data.interop_index = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [image_width]
    data.image_width = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [image_height]
    data.image_height = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [bits_per_sample]
    data.bits_per_sample = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [photometric_interpretation]
    data.photometric_interpretation = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [image_description]
    data.image_description = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [make]
    data.make = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [model]
    data.model = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [strip_offsets]
    data.strip_offsets = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [orientation]
    data.orientation = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [samples_per_pixel]
    data.samples_per_pixel = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [rows_per_strip]
    data.rows_per_strip = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [strip_byte_counts]
    data.strip_byte_counts = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [x_resolution]
    data.x_resolution = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [y_resolution]
    data.y_resolution = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [planar_configuration]
    data.planar_configuration = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [resolution_unit]
    data.resolution_unit = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [transfer_function]
    data.transfer_function = _arrayDeserializer.uint16(buffer, bufferOffset, 768)
    // Deserialize message field [software]
    data.software = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [date_time]
    data.date_time = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [artist]
    data.artist = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [white_point]
    data.white_point = _arrayDeserializer.float64(buffer, bufferOffset, 2)
    // Deserialize message field [primary_chromaticities]
    data.primary_chromaticities = _arrayDeserializer.float64(buffer, bufferOffset, 6)
    // Deserialize message field [tile_width]
    data.tile_width = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [tile_length]
    data.tile_length = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [jpg_from_raw_start]
    data.jpg_from_raw_start = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [jpg_from_raw_length]
    data.jpg_from_raw_length = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [ycb_cr_Coefficients]
    data.ycb_cr_Coefficients = _arrayDeserializer.float64(buffer, bufferOffset, 3)
    // Deserialize message field [ycb_cr_sub_sampling]
    data.ycb_cr_sub_sampling = _arrayDeserializer.uint16(buffer, bufferOffset, 2)
    // Deserialize message field [ycb_cr_positioning]
    data.ycb_cr_positioning = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [reference_black_white]
    data.reference_black_white = _arrayDeserializer.float64(buffer, bufferOffset, 6)
    // Deserialize message field [copyright]
    data.copyright = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [exposure_time]
    data.exposure_time = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [f_number]
    data.f_number = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [exposure_program]
    data.exposure_program = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [gps_info]
    data.gps_info = ExifGPSInfo.deserialize(buffer, bufferOffset);
    // Deserialize message field [iso]
    data.iso = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [sensitivity_type]
    data.sensitivity_type = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [standard_output_sensitivity]
    data.standard_output_sensitivity = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [recommended_exposure_index]
    data.recommended_exposure_index = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [iso_speed]
    data.iso_speed = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [iso_speed_latitudeyyy]
    data.iso_speed_latitudeyyy = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [iso_speed_latitudezzz]
    data.iso_speed_latitudezzz = _deserializer.uint32(buffer, bufferOffset);
    // Deserialize message field [exif_version]
    data.exif_version = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [date_time_original]
    data.date_time_original = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [date_time_digitized]
    data.date_time_digitized = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [offset_time]
    data.offset_time = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [offset_time_original]
    data.offset_time_original = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [offset_time_digitized]
    data.offset_time_digitized = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [components_configuration]
    data.components_configuration = _arrayDeserializer.uint8(buffer, bufferOffset, 4)
    // Deserialize message field [compressed_bits_per_pixel]
    data.compressed_bits_per_pixel = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [shutter_speed_value]
    data.shutter_speed_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [aperture_value]
    data.aperture_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [brightness_value]
    data.brightness_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [exposure_bias_value]
    data.exposure_bias_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [max_aperture_value]
    data.max_aperture_value = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [subject_distance]
    data.subject_distance = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [metering_mode]
    data.metering_mode = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [light_source]
    data.light_source = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [flash]
    data.flash = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [focal_length]
    data.focal_length = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [subject_area]
    data.subject_area = _arrayDeserializer.uint16(buffer, bufferOffset, null)
    // Deserialize message field [user_comment]
    data.user_comment = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [subsec_time]
    data.subsec_time = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [subsec_time_original]
    data.subsec_time_original = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [subsec_time_digitized]
    data.subsec_time_digitized = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [temperature]
    data.temperature = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [humidity]
    data.humidity = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [pressure]
    data.pressure = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [water_depth]
    data.water_depth = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [acceleration]
    data.acceleration = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [camera_elevation_angle]
    data.camera_elevation_angle = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [flash_pix_version]
    data.flash_pix_version = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [color_space]
    data.color_space = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [exif_image_width]
    data.exif_image_width = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [exif_image_height]
    data.exif_image_height = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [related_sound_file]
    data.related_sound_file = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [flash_energy]
    data.flash_energy = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [focal_plane_x_resolution]
    data.focal_plane_x_resolution = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [focal_plane_y_resolution]
    data.focal_plane_y_resolution = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [focal_plane_resolution_unit]
    data.focal_plane_resolution_unit = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [subject_location]
    data.subject_location = _arrayDeserializer.uint16(buffer, bufferOffset, 2)
    // Deserialize message field [exposure_index]
    data.exposure_index = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [sensing_method]
    data.sensing_method = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [scene_type]
    data.scene_type = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [custom_rendered]
    data.custom_rendered = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [exposure_mode]
    data.exposure_mode = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [white_balance]
    data.white_balance = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [digital_zoom_ratio]
    data.digital_zoom_ratio = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [focal_length_in_35mm_film]
    data.focal_length_in_35mm_film = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [scene_capture_type]
    data.scene_capture_type = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [gain_control]
    data.gain_control = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [contrast]
    data.contrast = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [saturation]
    data.saturation = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [sharpness]
    data.sharpness = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [subject_distance_range]
    data.subject_distance_range = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [image_unique_id]
    data.image_unique_id = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [camera_owner_name]
    data.camera_owner_name = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [body_serial_number]
    data.body_serial_number = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lens_specification]
    data.lens_specification = _arrayDeserializer.float64(buffer, bufferOffset, 4)
    // Deserialize message field [lens_make]
    data.lens_make = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lens_model]
    data.lens_model = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [lens_serial_number]
    data.lens_serial_number = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [composite_image]
    data.composite_image = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [composite_image_count]
    data.composite_image_count = _arrayDeserializer.uint16(buffer, bufferOffset, 2)
    // Deserialize message field [gamma]
    data.gamma = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.interop_index);
    length += 2 * object.bits_per_sample.length;
    length += _getByteLength(object.image_description);
    length += _getByteLength(object.make);
    length += _getByteLength(object.model);
    length += _getByteLength(object.software);
    length += _getByteLength(object.date_time);
    length += _getByteLength(object.artist);
    length += _getByteLength(object.copyright);
    length += ExifGPSInfo.getMessageSize(object.gps_info);
    length += 2 * object.iso.length;
    length += _getByteLength(object.exif_version);
    length += _getByteLength(object.date_time_original);
    length += _getByteLength(object.date_time_digitized);
    length += _getByteLength(object.offset_time);
    length += _getByteLength(object.offset_time_original);
    length += _getByteLength(object.offset_time_digitized);
    length += 2 * object.subject_area.length;
    length += _getByteLength(object.user_comment);
    length += _getByteLength(object.subsec_time);
    length += _getByteLength(object.subsec_time_original);
    length += _getByteLength(object.subsec_time_digitized);
    length += _getByteLength(object.flash_pix_version);
    length += _getByteLength(object.related_sound_file);
    length += _getByteLength(object.scene_type);
    length += _getByteLength(object.image_unique_id);
    length += _getByteLength(object.camera_owner_name);
    length += _getByteLength(object.body_serial_number);
    length += _getByteLength(object.lens_make);
    length += _getByteLength(object.lens_model);
    length += _getByteLength(object.lens_serial_number);
    return length + 2142;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_recognition_msgs/ExifTags';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '0db5f040080892d8197ca4a68428c05d';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # https://exiftool.org/TagNames/EXIF.html
    #
    # Tag ID	Tag Name	Writable	Group	Values / Notes
    #
    # 0x0001	InteropIndex	string!	InteropIFD
    string interop_index
    # 						'R03' = R03 - DCF option file (Adobe RGB)
    # 						'R98' = R98 - DCF basic file (sRGB)
    # 						'THM' = THM - DCF thumbnail file
    # 0x0002	InteropVersion	undef!:	InteropIFD
    # 0x000b	ProcessingSoftware	string	IFD0	(used by ACD Systems Digital Imaging)
    # 0x00fe	SubfileType	int32u!	IFD0	(called NewSubfileType by the TIFF specification)
    # 						0x0 = Full-resolution image
    # 						0x1 = Reduced-resolution image
    # 						0x2 = Single page of multi-page image
    # 						0x3 = Single page of multi-page reduced-resolution image
    # 						0x4 = Transparency mask
    # 						0x5 = Transparency mask of reduced-resolution image
    # 						0x6 = Transparency mask of multi-page image
    # 						0x7 = Transparency mask of reduced-resolution multi-page image
    # 						0x8 = Depth map
    # 						0x9 = Depth map of reduced-resolution image
    # 						0x10 = Enhanced image data
    # 						0x10001 = Alternate reduced-resolution image
    # 						0x10004 = Semantic Mask
    # 						0xffffffff = invalid
    # 						Bit 0 = Reduced resolution
    # 						Bit 1 = Single page
    # 						Bit 2 = Transparency mask
    # 						Bit 3 = TIFF/IT final page
    # 						Bit 4 = TIFF-FX mixed raster content
    # 0x00ff	OldSubfileType	int16u!	IFD0	(called SubfileType by the TIFF specification)
    # 						1 = Full-resolution image
    # 						2 = Reduced-resolution image
    # 						3 = Single page of multi-page image
    # 0x0100	ImageWidth	int32u!	IFD0	 
    uint32 image_width
    # 0x0101	ImageHeight	int32u!	IFD0	(called ImageLength by the EXIF spec.)
    uint32 image_height
    # 0x0102	BitsPerSample	int16u[n]!	IFD0
    uint16[] bits_per_sample
    # 0x0103	Compression	int16u!:	IFD0	--> EXIF Compression Values
    # 0x0106	PhotometricInterpretation	int16u!	IFD0
    # 						0 = WhiteIsZero
    # 						1 = BlackIsZero
    # 						2 = RGB
    # 						3 = RGB Palette
    # 						4 = Transparency Mask
    # 						5 = CMYK
    # 						6 = YCbCr
    # 						8 = CIELab
    # 						9 = ICCLab
    # 						10 = ITULab
    # 						32803 = Color Filter Array
    # 						32844 = Pixar LogL
    # 						32845 = Pixar LogLuv
    # 						32892 = Sequential Color Filter
    # 						34892 = Linear Raw
    # 						51177 = Depth Map
    # 						52527 = Semantic Mask
    uint16 photometric_interpretation
    # 0x0107	Thresholding	int16u!	IFD0
    # 						1 = No dithering or halftoning
    # 						2 = Ordered dither or halftone
    # 						3 = Randomized dither
    # 0x0108	CellWidth	int16u!	IFD0
    # 0x0109	CellLength	int16u!	IFD0
    # 0x010a	FillOrder	int16u!	IFD0
    # 						1 = Normal
    # 						2 = Reversed
    # 0x010d	DocumentName	string	IFD0
    # 0x010e	ImageDescription	string	IFD0
    string image_description
    # 0x010f	Make	string	IFD0
    string make
    # 0x0110	Model	string	IFD0
    string model
    # 0x0111	StripOffsets	(called StripOffsets in most locations, but it is PreviewImageStart in IFD0 of CR2 images and various IFD's of DNG images except for SubIFD2 where it is JpgFromRawStart)
    # 						PreviewImageStart	int32u*	IFD0
    # 						PreviewImageStart	int32u*	All
    # 						JpgFromRawStart	int32u*	SubIFD2
    uint32 strip_offsets
    # 0x0112	Orientation	int16u	IFD0	
    # 						1 = Horizontal (normal)
    # 						2 = Mirror horizontal
    # 						3 = Rotate 180
    # 						4 = Mirror vertical
    # 						5 = Mirror horizontal and rotate 270 CW
    # 						6 = Rotate 90 CW
    # 						7 = Mirror horizontal and rotate 90 CW
    # 						8 = Rotate 270 CW
    uint16 orientation
    # 0x0115	SamplesPerPixel	int16u!	IFD0
    uint16 samples_per_pixel
    # 0x0116	RowsPerStrip	int32u!	IFD0
    uint32 rows_per_strip
    # 0x0117	StripByteCounts	(called StripByteCounts in most locations, but it is PreviewImageLength in IFD0 of CR2 images and various IFD's of DNG images except for SubIFD2 where it is JpgFromRawLength)
    # 						PreviewImageLength	int32u*	IFD0
    # 						PreviewImageLength	int32u*	All
    # 						JpgFromRawLength	int32u*	SubIFD2
    uint32 strip_byte_counts
    # 0x0118	MinSampleValue	int16u	IFD0
    # 0x0119	MaxSampleValue	int16u	IFD0
    # 0x011a	XResolution	rational64u:	IFD0
    float64 x_resolution
    # 0x011b	YResolution	rational64u:	IFD0
    float64 y_resolution
    # 0x011c	PlanarConfiguration	int16u!	IFD0
    # 						1 = Chunky
    # 						2 = Planar
    uint16 planar_configuration
    # 0x011d	PageName	string	IFD0
    # 0x011e	XPosition	rational64u	IFD0
    # 0x011f	YPosition	rational64u	IFD0
    # 0x0120	FreeOffsets	no	-
    # 0x0121	FreeByteCounts	no	-
    # 0x0122	GrayResponseUnit	int16u	IFD0
    # 						1 = 0.1
    # 						2 = 0.001
    # 						3 = 0.0001
    # 						4 = 1e-05
    # 						5 = 1e-06
    # 0x0123	GrayResponseCurve	no	-
    # 0x0124	T4Options	no	-	Bit 0 = 2-Dimensional encoding
    # Bit 1 = Uncompressed
    # Bit 2 = Fill bits added
    # 0x0125	T6Options	no	-	Bit 1 = Uncompressed
    # 0x0128	ResolutionUnit	int16u:	IFD0	(the value 1 is not standard EXIF)
    # 						1 = None
    # 						2 = inches
    # 						3 = cm
    uint16 resolution_unit
    # 0x0129	PageNumber	int16u[2]	IFD0
    # 0x012c	ColorResponseUnit	no	-
    # 0x012d	TransferFunction	int16u[768]!	IFD0
    uint16[768] transfer_function
    # 0x0131	Software	string	IFD0
    string software
    # 0x0132	ModifyDate	string	IFD0	(called DateTime by the EXIF spec.)
    string date_time
    # 0x013b	Artist	string	IFD0	(becomes a list-type tag when the MWG module is loaded)
    string artist
    # 0x013c	HostComputer	string	IFD0	 
    # 0x013d	Predictor	int16u!	IFD0	
    # 						1 = None
    # 						2 = Horizontal differencing
    # 						3 = Floating point
    # 						34892 = Horizontal difference X2
    # 						34893 = Horizontal difference X4
    # 						34894 = Floating point X2
    # 						34895 = Floating point X4
    # 0x013e	WhitePoint	rational64u[2]	IFD0
    float64[2] white_point
    # 0x013f	PrimaryChromaticities	rational64u[6]	IFD0
    float64[6] primary_chromaticities
    # 0x0140	ColorMap	no	-	 
    # 0x0141	HalftoneHints	int16u[2]	IFD0
    # 0x0142	TileWidth	int32u!	IFD0
    uint32 tile_width
    # 0x0143	TileLength	int32u!	IFD0
    uint32 tile_length
    # 0x0144	TileOffsets	no	-
    # 0x0145	TileByteCounts	no	-
    # 0x0146	BadFaxLines	no	-
    # 0x0147	CleanFaxData	no	-
    # 						0 = Clean
    # 						1 = Regenerated
    # 						2 = Unclean
    # 0x0148	ConsecutiveBadFaxLines	no	-
    # 0x014a	SubIF	-	-	--> EXIF Tags
    # 		A100DataOffset	-no	IFD0	(the data offset in original Sony DSLR-A100 ARW images)
    # 0x014c	InkSet	int16u	IFD0
    # 						1 = CMYK
    # 						2 = Not CMYK
    # 0x014d	InkNames	no	-
    # 0x014e	NumberofInks	no	-
    # 0x0150	DotRange	no	-
    # 0x0151	TargetPrinter	string	IFD0
    # 0x0152	ExtraSamples	no	-
    # 						0 = Unspecified
    # 						1 = Associated Alpha
    # 						2 = Unassociated Alpha
    # 0x0153	SampleFormat	no	SubIFD	(SamplesPerPixel values)# [Values 0-3]
    # 						1 = Unsigned
    # 						2 = Signed
    # 						3 = Float
    # 						4 = Undefined
    # 						5 = Complex int
    # 						6 = Complex float
    # 0x0154	SMinSampleValue	no	-
    # 0x0155	SMaxSampleValue	no	-
    # 0x0156	TransferRange	no	-
    # 0x0157	ClipPath	no	-
    # 0x0158	XClipPathUnits	no	-
    # 0x0159	YClipPathUnits	no	-
    # 0x015a	Indexed	no	-
    # 						0 = Not indexed
    # 						1 = Indexed
    # 0x015b	JPEGTables	no	- 
    # 0x015f	OPIProxy	no	-
    # 						0 = Higher resolution image does not exist
    # 						1 = Higher resolution image exists
    # 0x0190	GlobalParametersIFD	-	-	--> EXIF Tags
    # 0x0191	ProfileType	no	-
    # 						0 = Unspecified
    # 						1 = Group 3 FAX
    # 0x0192	FaxProfile	no	-
    # 						0 = Unknown
    # 						1 = Minimal B&W lossless, S
    # 						2 = Extended B&W lossless, F
    # 						3 = Lossless JBIG B&W, J
    # 						4 = Lossy color and grayscale, C
    # 						5 = Lossless color and grayscale, L
    # 						6 = Mixed raster content, M
    # 						7 = Profile T
    # 						255 = Multi Profiles
    # 0x0193	CodingMethods	no	-
    # 						Bit 0 = Unspecified compression
    # 						Bit 1 = Modified Huffman
    # 						Bit 2 = Modified Read
    # 						Bit 3 = Modified MR
    # 						Bit 4 = JBIG
    # 						Bit 5 = Baseline JPEG
    # 						Bit 6 = JBIG color
    # 0x0194	VersionYear	no	-
    # 0x0195	ModeNumber	no	-
    # 0x01b1	Decode	no	-
    # 0x01b2	DefaultImageColor	no	-
    # 0x01b3	T82Options	no	-
    # 0x01b5	JPEGTables	no	-
    # 0x0200	JPEGProc	no	-
    # 						1 = Baseline
    # 						14 = Lossless
    # 0x0201	ThumbnailOffset	int32u*	IFD1	(ThumbnailOffset in IFD1 of JPEG and some TIFF-based images, IFD0 of MRW images and AVI and MOV videos, and the SubIFD in IFD1 of SRW images; PreviewImageStart in MakerNotes and IFD0 of ARW and SR2 images; JpgFromRawStart in SubIFD of NEF images and IFD2 of PEF images; and OtherImageStart in everything else)
    # 						ThumbnailOffset	int32u*	IFD0
    # 						ThumbnailOffset	int32u*	SubIFD
    # 						PreviewImageStart	int32u*	MakerNotes
    # 						PreviewImageStart	int32u*	IFD0
    # 						JpgFromRawStart	int32u*	SubIFD
    # 						JpgFromRawStart	int32u*	IFD2
    # 						OtherImageStart	int32u*	SubIFD1
    # 						OtherImageStart	int32u*	SubIFD2
    # 						OtherImageStart	no
    uint32 jpg_from_raw_start
    # 0x0202	ThumbnailLength	int32u*	IFD1	(ThumbnailLength in IFD1 of JPEG and some TIFF-based images, IFD0 of MRW images and AVI and MOV videos, and the SubIFD in IFD1 of SRW images; PreviewImageLength in MakerNotes and IFD0 of ARW and SR2 images; JpgFromRawLength in SubIFD of NEF images, and IFD2 of PEF images; and OtherImageLength in everything else)
    # 						ThumbnailLength	int32u*	IFD0
    # 						ThumbnailLength	int32u*	SubIFD
    # 						PreviewImageLength	int32u*	MakerNotes
    # 						PreviewImageLength	int32u*	IFD0
    # 						JpgFromRawLength	int32u*	SubIFD
    # 						JpgFromRawLength	int32u*	IFD2
    # 						OtherImageLength	int32u*	SubIFD1
    # 						OtherImageLength	int32u*	SubIFD2
    # 						OtherImageLength	no	
    uint32 jpg_from_raw_length
    # 0x0203	JPEGRestartInterval	no	-
    # 0x0205	JPEGLosslessPredictors	no	-
    # 0x0206	JPEGPointTransforms	no	-
    # 0x0207	JPEGQTables	no	-
    # 0x0208	JPEGDCTables	no	-
    # 0x0209	JPEGACTables	no	-
    # 0x0211	YCbCrCoefficients	rational64u[3]!	IFD0
    float64[3] ycb_cr_Coefficients
    # 0x0212	YCbCrSubSampling	int16u[2]!	IFD0	
    # 						'1 1' = YCbCr4:4:4 (1 1)
    # 						'1 2' = YCbCr4:4:0 (1 2)
    # 						'1 4' = YCbCr4:4:1 (1 4)
    # 						'2 1' = YCbCr4:2:2 (2 1)
    # 						'2 2' = YCbCr4:2:0 (2 2)
    # 						'2 4' = YCbCr4:2:1 (2 4)
    # 						'4 1' = YCbCr4:1:1 (4 1)
    # 						'4 2' = YCbCr4:1:0 (4 2)
    uint16[2] ycb_cr_sub_sampling
    # 0x0213	YCbCrPositioning	int16u!:	IFD0
    # 						1 = Centered
    # 						2 = Co-sited
    uint16 ycb_cr_positioning
    # 0x0214	ReferenceBlackWhite	rational64u[6]	IFD0
    float64[6] reference_black_white
    # 0x022f	StripRowCounts	no	-
    # 0x02bc	ApplicationNotes	int8u!	IFD0	--> XMP Tags
    # 0x03e7	USPTOMiscellaneous	no	-
    # 0x1000	RelatedImageFileFormat	string!	InteropIFD
    # 0x1001	RelatedImageWidth	int16u!	InteropIFD
    # 0x1002	RelatedImageHeight	int16u!	InteropIFD	(called RelatedImageLength by the DCF spec.)
    # 0x4746	Rating	int16u/	IFD0
    # 0x4747	XP_DIP_XML	no	-
    # 0x4748	StitchInfo	-	-	--> Microsoft Stitch Tags
    # 0x4749	RatingPercent	int16u/	IFD0
    # 0x7000	SonyRawFileType	no	-
    # 						0 = Sony Uncompressed 14-bit RAW
    # 						1 = Sony Uncompressed 12-bit RAW
    # 						2 = Sony Compressed RAW
    # 						3 = Sony Lossless Compressed RAW
    # 						4 = Sony Lossless Compressed RAW 2
    # 0x7010	SonyToneCurve	no	-
    # 0x7031	VignettingCorrection	int16s!	SubIFD	(found in Sony ARW images)
    # 						256 = Off
    # 						257 = Auto
    # 						272 = Auto (ILCE-1)
    # 						511 = No correction params available
    # 0x7032	VignettingCorrParams	int16s[17]!	SubIFD	(found in Sony ARW images)
    # 0x7034	ChromaticAberrationCorrection	int16s!	SubIFD	(found in Sony ARW images)
    # 						0 = Off
    # 						1 = Auto
    # 						255 = No correction params available
    # 0x7035	ChromaticAberrationCorrParams	int16s[33]!	SubIFD	(found in Sony ARW images)
    # 0x7036	DistortionCorrection	int16s!	SubIFD	(found in Sony ARW images)
    # 						0 = Off
    # 						1 = Auto
    # 						17 = Auto fixed by lens
    # 						255 = No correction params available
    # 0x7037	DistortionCorrParams	int16s[17]!	SubIFD	(found in Sony ARW images)
    # 0x74c7	SonyCropTopLeft	int32u[2]!	SubIFD
    # 0x74c8	SonyCropSize	int32u[2]!	SubIFD
    # 0x800d	ImageID	no	-
    # 0x80a3	WangTag1	no	-
    # 0x80a4	WangAnnotation	no	-
    # 0x80a5	WangTag3	no	-
    # 0x80a6	WangTag4	no	-
    # 0x80b9	ImageReferencePoints	no	-
    # 0x80ba	RegionXformTackPoint	no	-
    # 0x80bb	WarpQuadrilateral	no	-
    # 0x80bc	AffineTransformMat	no	-
    # 0x80e3	Matteing	no	-
    # 0x80e4	DataType	no	-
    # 0x80e5	ImageDepth	no	-
    # 0x80e6	TileDepth	no	-
    # 0x8214	ImageFullWidth	no	-
    # 0x8215	ImageFullHeight	no	-
    # 0x8216	TextureFormat	no	-
    # 0x8217	WrapModes	no	-
    # 0x8218	FovCot	no	-
    # 0x8219	MatrixWorldToScreen	no	-
    # 0x821a	MatrixWorldToCamera	no	-
    # 0x827d	Model2	no	-
    # 0x828d	CFARepeatPatternDim	int16u[2]!	SubIFD
    # 0x828e	CFAPattern2	int8u[n]!	SubIFD
    # 0x828f	BatteryLevel	no	-
    # 0x8290	KodakIFD	-	-	--> Kodak IFD Tags	(used in various types of Kodak images)
    # 0x8298	Copyright	string	IFD0	(may contain copyright notices for photographer and editor, separated by a newline. As per the EXIF specification, the newline is replaced by a null byte when writing to file, but this may be avoided by disabling the print conversion)
    string copyright
    # 0x829a	ExposureTime	rational64u	ExifIFD
    float64 exposure_time
    # 0x829d	FNumber	rational64u	ExifIFD
    float64 f_number
    # 0x82a5	MDFileTag	no	-	(tags 0x82a5-0x82ac are used in Molecular Dynamics GEL files)
    # 0x82a6	MDScalePixel	no	-
    # 0x82a7	MDColorTable	no	-
    # 0x82a8	MDLabName	no	-
    # 0x82a9	MDSampleInfo	no	-
    # 0x82aa	MDPrepDate	no	-
    # 0x82ab	MDPrepTime	no	-
    # 0x82ac	MDFileUnits	no	-
    # 0x830e	PixelScale	double[3]	IFD0
    # 0x8335	AdventScale	no	-
    # 0x8336	AdventRevision	no	-
    # 0x835c	UIC1Tag	no	-
    # 0x835d	UIC2Tag	no	-
    # 0x835e	UIC3Tag	no	-
    # 0x835f	UIC4Tag	no	-
    # 0x83bb	IPTC-NAA	int32u!	IFD0	--> IPTC Tags
    # 0x847e	IntergraphPacketData	no	-
    # 0x847f	IntergraphFlagRegisters	no	-
    # 0x8480	IntergraphMatrix	double[n]	IFD0
    # 0x8481	INGRReserved	no	-
    # 0x8482	ModelTiePoint	double[n]	IFD0
    # 0x84e0	Site	no	-
    # 0x84e1	ColorSequence	no	-
    # 0x84e2	IT8Header	no	-
    # 0x84e3	RasterPadding	no	-
    # 						0 = Byte
    # 						1 = Word
    # 						2 = Long Word
    # 						9 = Sector
    # 						10 = Long Sector
    # 0x84e4	BitsPerRunLength	no	-
    # 0x84e5	BitsPerExtendedRunLength	no	-
    # 0x84e6	ColorTable	no	-
    # 0x84e7	ImageColorIndicator	no	-
    # 						0 = Unspecified Image Color
    # 						1 = Specified Image Color
    # 0x84e8	BackgroundColorIndicator	no	-
    # 						0 = Unspecified Background Color
    # 						1 = Specified Background Color
    # 0x84e9	ImageColorValue	no	-
    # 0x84ea	BackgroundColorValue	no	-
    # 0x84eb	PixelIntensityRange	no	-
    # 0x84ec	TransparencyIndicator	no	-
    # 0x84ed	ColorCharacterization	no	-
    # 0x84ee	HCUsage	no	-
    # 						0 = CT
    # 						1 = Line Art
    # 						2 = Trap
    # 0x84ef	TrapIndicator	no	-
    # 0x84f0	CMYKEquivalent	no	-
    # 0x8546	SEMInfo	string	IFD0	(found in some scanning electron microscope images)
    # 0x8568	AFCP_IPTC	-	-	--> IPTC Tags
    # 0x85b8	PixelMagicJBIGOptions	no	-
    # 0x85d7	JPLCartoIFD	no	-
    # 0x85d8	ModelTransform	double[16]	IFD0
    # 0x8602	WB_GRGBLevels	no	-	(found in IFD0 of Leaf MOS images)
    # 0x8606	LeafData	-	-	--> Leaf Tags
    # 0x8649	PhotoshopSettings	-	IFD0	--> Photoshop Tags
    # 0x8769	ExifOffset	-	IFD0	--> EXIF Tags
    # 0x8773	ICC_Profile	-	IFD0	--> ICC_Profile Tags
    # 0x877f	TIFF_FXExtensions	no	-
    # 						Bit 0 = Resolution/Image Width
    # 						Bit 1 = N Layer Profile M
    # 						Bit 2 = Shared Data
    # 						Bit 3 = B&W JBIG2
    # 						Bit 4 = JBIG2 Profile M
    # 0x8780	MultiProfiles	no	
    # 						Bit 0 = Profile S
    # 						Bit 1 = Profile F
    # 						Bit 2 = Profile J
    # 						Bit 3 = Profile C
    # 						Bit 4 = Profile L
    # 						Bit 5 = Profile M
    # 						Bit 6 = Profile T
    # 						Bit 7 = Resolution/Image Width
    # 						Bit 8 = N Layer Profile M
    # 						Bit 9 = Shared Data
    # 						Bit 10 = JBIG2 Profile M
    # 0x8781	SharedData	no	-
    # 0x8782	T88Options	no	-
    # 0x87ac	ImageLayer	no	-
    # 0x87af	GeoTiffDirectory	int16u[0.5]	IFD0	(these "GeoTiff" tags may read and written as a block, but they aren't extracted unless specifically requested. Byte order changes are handled automatically when copying between TIFF images with different byte order)
    # 0x87b0	GeoTiffDoubleParams	double[0.125]	IFD0	 
    # 0x87b1	GeoTiffAsciiParams	string	IFD0	 
    # 0x87be	JBIGOptions	no	-	 
    # 0x8822	ExposureProgram	int16u	ExifIFD	(the value of 9 is not standard EXIF, but is used by the Canon EOS 7D)
    # 						0 = Not Defined
    # 						1 = Manual
    # 						2 = Program AE
    # 						3 = Aperture-priority AE
    # 						4 = Shutter speed priority AE
    # 						5 = Creative (Slow speed)
    # 						6 = Action (High speed)
    # 						7 = Portrait
    # 						8 = Landscape
    # 						9 = Bulb
    uint16 exposure_program
    # 0x8824	SpectralSensitivity	string	ExifIFD
    # 0x8825	GPSInfo	-	IFD0	--> GPS Tags
    ExifGPSInfo gps_info
    # 0x8827	ISO	int16u[n]	ExifIFD	(called ISOSpeedRatings by EXIF 2.2, then PhotographicSensitivity by the EXIF 2.3 spec.)
    uint16[] iso
    # 0x8828	Opto-ElectricConvFactor	no	-	(called OECF by the EXIF spec.)
    # 0x8829	Interlace	no	-	 
    # 0x882a	TimeZoneOffset	int16s[n]	ExifIFD	(1 or 2 values: 1. The time zone offset of DateTimeOriginal from GMT in hours, 2. If present, the time zone offset of ModifyDate)
    # 0x882b	SelfTimerMode	int16u	ExifIFD	 
    # 0x8830	SensitivityType	int16u	ExifIFD	(applies to EXIF:ISO tag)
    # 						0 = Unknown
    # 						1 = Standard Output Sensitivity
    # 						2 = Recommended Exposure Index
    # 						3 = ISO Speed
    # 						4 = Standard Output Sensitivity and Recommended Exposure Index
    # 						5 = Standard Output Sensitivity and ISO Speed
    # 						6 = Recommended Exposure Index and ISO Speed
    # 						7 = Standard Output Sensitivity, Recommended Exposure Index and ISO Speed
    uint16 sensitivity_type
    # 0x8831	StandardOutputSensitivity	int32u	ExifIFD
    uint32 standard_output_sensitivity
    # 0x8832	RecommendedExposureIndex	int32u	ExifIFD
    uint32 recommended_exposure_index
    # 0x8833	ISOSpeed	int32u	ExifIFD
    uint32 iso_speed
    # 0x8834	ISOSpeedLatitudeyyy	int32u	ExifIFD
    uint32 iso_speed_latitudeyyy
    # 0x8835	ISOSpeedLatitudezzz	int32u	ExifIFD
    uint32 iso_speed_latitudezzz
    # 0x885c	FaxRecvParams	no	-
    # 0x885d	FaxSubAddress	no	-
    # 0x885e	FaxRecvTime	no	-
    # 0x8871	FedexEDR	no	-
    # 0x888a	LeafSubIFD	-	-	--> Leaf SubIFD Tags
    # 0x9000	ExifVersion	undef:	ExifIFD
    string exif_version
    # 0x9003	DateTimeOriginal	string	ExifIFD	(date/time when original image was taken)
    string date_time_original
    # 0x9004	CreateDate	string	ExifIFD	(called DateTimeDigitized by the EXIF spec.)
    string date_time_digitized
    # 0x9009	GooglePlusUploadCode	undef[n]	ExifIFD
    # 0x9010	OffsetTime	string	ExifIFD	(time zone for ModifyDate)
    string offset_time
    # 0x9011	OffsetTimeOriginal	string	ExifIFD	(time zone for DateTimeOriginal)
    string offset_time_original
    # 0x9012	OffsetTimeDigitized	string	ExifIFD	(time zone for CreateDate)
    string offset_time_digitized
    # 0x9101	ComponentsConfiguration	undef[4]!:	ExifIFD
    # 						0 = -
    # 						1 = Y
    # 						2 = Cb
    # 						3 = Cr
    # 						4 = R
    # 						5 = G
    # 						6 = B
    uint8[4] components_configuration
    # 0x9102	CompressedBitsPerPixel	rational64u!	ExifIFD
    float64 compressed_bits_per_pixel
    # 0x9201	ShutterSpeedValue	rational64s	ExifIFD	(displayed in seconds, but stored as an APEX value)
    float64 shutter_speed_value
    # 0x9202	ApertureValue	rational64u	ExifIFD	(displayed as an F number, but stored as an APEX value)
    float64 aperture_value
    # 0x9203	BrightnessValue	rational64s	ExifIFD
    float64 brightness_value
    # 0x9204	ExposureCompensation	rational64s	ExifIFD	(called ExposureBiasValue by the EXIF spec.)
    float64 exposure_bias_value
    # 0x9205	MaxApertureValue	rational64u	ExifIFD	(displayed as an F number, but stored as an APEX value)
    float64 max_aperture_value
    # 0x9206	SubjectDistance	rational64u	ExifIFD
    float64 subject_distance
    # 0x9207	MeteringMode	int16u	ExifIFD
    # 						0 = Unknown
    # 						1 = Average
    # 						2 = Center-weighted average
    # 						3 = Spot
    # 						4 = Multi-spot
    # 						5 = Multi-segment
    # 						6 = Partial
    # 						255 = Other
    uint16 metering_mode
    # 0x9208	LightSource	int16u	ExifIFD	--> EXIF LightSource Values
    uint16 light_source
    # 0x9209	Flash	int16u	ExifIFD	--> EXIF Flash Values
    uint16 flash
    # 0x920a	FocalLength	rational64u	ExifIFD
    float64 focal_length
    # 0x920b	FlashEnergy	no	-
    # 0x920c	SpatialFrequencyResponse	no	-
    # 0x920d	Noise	no	-
    # 0x920e	FocalPlaneXResolution	no	-
    # 0x920f	FocalPlaneYResolution	no	-
    # 0x9210	FocalPlaneResolutionUnit	no	-
    # 						1 = None
    # 						2 = inches
    # 						3 = cm
    # 						4 = mm
    # 						5 = um
    # 0x9211	ImageNumber	int32u	ExifIFD
    # 0x9212	SecurityClassification	string	ExifIFD
    # 						'C' = Confidential
    # 						'R' = Restricted
    # 						'S' = Secret
    # 						'T' = Top Secret
    # 						'U' = Unclassified
    # 0x9213	ImageHistory	string	ExifIFD
    # 0x9214	SubjectArea	int16u[n]	ExifIFD
    uint16[] subject_area
    # 0x9215	ExposureIndex	no	-
    # 0x9216	TIFF-EPStandardID	no	-
    # 0x9217	SensingMethod	no	-
    # 						1 = Monochrome area
    # 						2 = One-chip color area
    # 						3 = Two-chip color area
    # 						4 = Three-chip color area
    # 						5 = Color sequential area
    # 						6 = Monochrome linear
    # 						7 = Trilinear
    # 						8 = Color sequential linear
    # 0x923a	CIP3DataFile	no	-
    # 0x923b	CIP3Sheet	no	-
    # 0x923c	CIP3Side	no	-
    # 0x923f	StoNits	no	-
    # 0x927c	MakerNoteApple	undef	ExifIFD	--> Apple Tags
    # 		MakerNoteNikon	undef	ExifIFD	--> Nikon Tags
    # 		MakerNoteCanon	undef	ExifIFD	--> Canon Tags
    # 		MakerNoteCasio	undef	ExifIFD	--> Casio Tags
    # 		MakerNoteCasio2	undef	ExifIFD	--> Casio Type2 Tags
    # 		MakerNoteDJI	undef	ExifIFD	--> DJI Tags
    # 		MakerNoteFLIR	undef	ExifIFD	--> FLIR Tags
    # 		MakerNoteFujiFilm	undef	ExifIFD	--> FujiFilm Tags
    # 		MakerNoteGE	undef	ExifIFD	--> GE Tags
    # 		MakerNoteGE2	undef	ExifIFD	--> FujiFilm Tags
    # 		MakerNoteHasselblad	undef	ExifIFD	--> Unknown Tags
    # 		MakerNoteHP	undef	ExifIFD	--> HP Tags
    # 		MakerNoteHP2	undef	ExifIFD	--> HP Type2 Tags
    # 		MakerNoteHP4	undef	ExifIFD	--> HP Type4 Tags
    # 		MakerNoteHP6	undef	ExifIFD	--> HP Type6 Tags
    # 		MakerNoteISL	undef	ExifIFD	--> Unknown Tags
    # 		MakerNoteJVC	undef	ExifIFD	--> JVC Tags
    # 		MakerNoteJVCText	undef	ExifIFD	--> JVC Text Tags
    # 		MakerNoteKodak1a	undef	ExifIFD	--> Kodak Tags
    # 		MakerNoteKodak1b	undef	ExifIFD	--> Kodak Tags
    # 		MakerNoteKodak2	undef	ExifIFD	--> Kodak Type2 Tags
    # 		MakerNoteKodak3	undef	ExifIFD	--> Kodak Type3 Tags
    # 		MakerNoteKodak4	undef	ExifIFD	--> Kodak Type4 Tags
    # 		MakerNoteKodak5	undef	ExifIFD	--> Kodak Type5 Tags
    # 		MakerNoteKodak6a	undef	ExifIFD	--> Kodak Type6 Tags
    # 		MakerNoteKodak6b	undef	ExifIFD	--> Kodak Type6 Tags
    # 		MakerNoteKodak7	undef	ExifIFD	--> Kodak Type7 Tags
    # 		MakerNoteKodak8a	undef	ExifIFD	--> Kodak Type8 Tags
    # 		MakerNoteKodak8b	undef	ExifIFD	--> Kodak Type8 Tags
    # 		MakerNoteKodak8c	undef	ExifIFD	--> Kodak Type8 Tags
    # 		MakerNoteKodak9	undef	ExifIFD	--> Kodak Type9 Tags
    # 		MakerNoteKodak10	undef	ExifIFD	--> Kodak Type10 Tags
    # 		MakerNoteKodak11	undef	ExifIFD	--> Kodak Type11 Tags
    # 		MakerNoteKodak12	undef	ExifIFD	--> Kodak Type11 Tags
    # 		MakerNoteKodakUnknown	undef	ExifIFD	--> Kodak Unknown Tags
    # 		MakerNoteKyocera	undef	ExifIFD	--> Unknown Tags
    # 		MakerNoteMinolta	undef	ExifIFD	--> Minolta Tags
    # 		MakerNoteMinolta2	undef	ExifIFD	--> Olympus Tags
    # 		MakerNoteMinolta3	undef	ExifIFD	(not EXIF-based)
    # 		MakerNoteMotorola	undef	ExifIFD	--> Motorola Tags
    # 		MakerNoteNikon2	undef	ExifIFD	--> Nikon Type2 Tags
    # 		MakerNoteNikon3	undef	ExifIFD	--> Nikon Tags
    # 		MakerNoteNintendo	undef	ExifIFD	--> Nintendo Tags
    # 		MakerNoteOlympus	undef	ExifIFD	--> Olympus Tags
    # 		MakerNoteOlympus2	undef	ExifIFD	--> Olympus Tags
    # 		MakerNoteLeica	undef	ExifIFD	--> Panasonic Tags
    # 		MakerNoteLeica2	undef	ExifIFD	--> Panasonic Leica2 Tags
    # 		MakerNoteLeica3	undef	ExifIFD	--> Panasonic Leica3 Tags
    # 		MakerNoteLeica4	undef	ExifIFD	--> Panasonic Leica4 Tags
    # 		MakerNoteLeica5	undef	ExifIFD	--> Panasonic Leica5 Tags
    # 		MakerNoteLeica6	undef	ExifIFD	--> Panasonic Leica6 Tags
    # 		MakerNoteLeica7	undef	ExifIFD	--> Panasonic Leica6 Tags
    # 		MakerNoteLeica8	undef	ExifIFD	--> Panasonic Leica5 Tags
    # 		MakerNoteLeica9	undef	ExifIFD	--> Panasonic Leica9 Tags
    # 		MakerNoteLeica10	undef	ExifIFD	--> Panasonic Tags
    # 		MakerNotePanasonic	undef	ExifIFD	--> Panasonic Tags
    # 		MakerNotePanasonic2	undef	ExifIFD	--> Panasonic Type2 Tags
    # 		MakerNotePanasonic3	undef	ExifIFD	--> Panasonic Tags
    # 		MakerNotePentax	undef	ExifIFD	--> Pentax Tags
    # 		MakerNotePentax2	undef	ExifIFD	--> Pentax Type2 Tags
    # 		MakerNotePentax3	undef	ExifIFD	--> Casio Type2 Tags
    # 		MakerNotePentax4	undef	ExifIFD	--> Pentax Type4 Tags
    # 		MakerNotePentax5	undef	ExifIFD	--> Pentax Tags
    # 		MakerNotePentax6	undef	ExifIFD	--> Pentax S1 Tags
    # 		MakerNotePhaseOne	undef	ExifIFD	--> PhaseOne Tags
    # 		MakerNoteReconyx	undef	ExifIFD	--> Reconyx Tags
    # 		MakerNoteReconyx2	undef	ExifIFD	--> Reconyx Type2 Tags
    # 		MakerNoteReconyx3	undef	ExifIFD	--> Reconyx Type3 Tags
    # 		MakerNoteRicohPentax	undef	ExifIFD	--> Pentax Tags
    # 		MakerNoteRicoh	undef	ExifIFD	--> Ricoh Tags
    # 		MakerNoteRicoh2	undef	ExifIFD	--> Ricoh Type2 Tags
    # 		MakerNoteRicohText	undef	ExifIFD	--> Ricoh Text Tags
    # 		MakerNoteSamsung1a	undef	ExifIFD	(Samsung "STMN" maker notes without PreviewImage)
    # 		undef	ExifIFD	--> Samsung Tags	MakerNoteSamsung1b
    # 		MakerNoteSamsung2	undef	ExifIFD	--> Samsung Type2 Tags
    # 		MakerNoteSanyo	undef	ExifIFD	--> Sanyo Tags
    # 		MakerNoteSanyoC4	undef	ExifIFD	--> Sanyo Tags
    # 		MakerNoteSanyoPatch	undef	ExifIFD	--> Sanyo Tags
    # 		MakerNoteSigma	undef	ExifIFD	--> Sigma Tags
    # 		MakerNoteSony	undef	ExifIFD	--> Sony Tags
    # 		MakerNoteSony2	undef	ExifIFD	--> Olympus Tags
    # 		MakerNoteSony3	undef	ExifIFD	--> Olympus Tags
    # 		MakerNoteSony4	undef	ExifIFD	--> Sony PIC Tags
    # 		MakerNoteSony5	undef	ExifIFD	--> Sony Tags
    # 		MakerNoteSonyEricsson	undef	ExifIFD	--> Sony Ericsson Tags
    # 		MakerNoteSonySRF	undef	ExifIFD	--> Sony SRF Tags
    # 		MakerNoteUnknownText	undef	ExifIFD	(unknown text-based maker notes)
    # 		MakerNoteUnknownBinary	undef	ExifIFD	(unknown binary maker notes)
    # 		MakerNoteUnknown	undef	ExifIFD	--> Unknown Tags
    # 0x9286	UserComment	undef	ExifIFD
    string user_comment
    # 0x9290	SubSecTime	string	ExifIFD	(fractional seconds for ModifyDate)
    string subsec_time
    # 0x9291	SubSecTimeOriginal	string	ExifIFD	(fractional seconds for DateTimeOriginal)
    string subsec_time_original
    # 0x9292	SubSecTimeDigitized	string	ExifIFD	(fractional seconds for CreateDate)
    string subsec_time_digitized
    # 0x932f	MSDocumentText	no	-	 
    # 0x9330	MSPropertySetStorage	no	-
    # 0x9331	MSDocumentTextPosition	no	-
    # 0x935c	ImageSourceData	undef!	IFD0	--> Photoshop DocumentData Tags
    # 0x9400	AmbientTemperature	rational64s	ExifIFD	(ambient temperature in degrees C, called Temperature by the EXIF spec.)
    float64 temperature
    # 0x9401	Humidity	rational64u	ExifIFD	(ambient relative humidity in percent)
    float64 humidity
    # 0x9402	Pressure	rational64u	ExifIFD	(air pressure in hPa or mbar)
    float64 pressure
    # 0x9403	WaterDepth	rational64s	ExifIFD	(depth under water in metres, negative for above water)
    float64 water_depth
    # 0x9404	Acceleration	rational64u	ExifIFD	(directionless camera acceleration in units of mGal, or 10-5 m/s2)
    float64 acceleration
    # 0x9405	CameraElevationAngle	rational64s	ExifIFD
    float64 camera_elevation_angle
    # 0x9c9b	XPTitle	int8u	IFD0	(tags 0x9c9b-0x9c9f are used by Windows Explorer; special characters in these values are converted to UTF-8 by default, or Windows Latin1 with the -L option. XPTitle is ignored by Windows Explorer if ImageDescription exists)
    # 0x9c9c	XPComment	int8u	IFD0
    # 0x9c9d	XPAuthor	int8u	IFD0	(ignored by Windows Explorer if Artist exists)
    # 0x9c9e	XPKeywords	int8u	IFD0
    # 0x9c9f	XPSubject	int8u	IFD0
    # 0xa000	FlashpixVersion	undef:	ExifIFD
    string flash_pix_version
    # 0xa001	ColorSpace	int16u:	ExifIFD	(the value of 0x2 is not standard EXIF. Instead, an Adobe RGB image is indicated by "Uncalibrated" with an InteropIndex of "R03". The values 0xfffd and 0xfffe are also non-standard, and are used by some Sony cameras)
    # 						0x1 = sRGB
    # 						0x2 = Adobe RGB
    # 						0xfffd = Wide Gamut RGB
    # 						0xfffe = ICC Profile
    # 						0xffff = Uncalibrated
    uint16 color_space
    # 0xa002	ExifImageWidth	int16u:	ExifIFD	(called PixelXDimension by the EXIF spec.)
    uint16 exif_image_width
    # 0xa003	ExifImageHeight	int16u:	ExifIFD	(called PixelYDimension by the EXIF spec.)
    uint16 exif_image_height
    # 0xa004	RelatedSoundFile	string	ExifIFD
    string related_sound_file
    # 0xa005	InteropOffset	-	-	--> EXIF Tags
    # 0xa010	SamsungRawPointersOffset	no	-
    # 0xa011	SamsungRawPointersLength	no	-
    # 0xa101	SamsungRawByteOrder	no	-
    # 0xa102	SamsungRawUnknown?	no	-
    # 0xa20b	FlashEnergy	rational64u	ExifIFD
    float64 flash_energy
    # 0xa20c	SpatialFrequencyResponse	no	-
    # 0xa20d	Noise	no	-	 
    # 0xa20e	FocalPlaneXResolution	rational64u	ExifIFD
    float64 focal_plane_x_resolution
    # 0xa20f	FocalPlaneYResolution	rational64u	ExifIFD
    float64 focal_plane_y_resolution
    # 0xa210	FocalPlaneResolutionUnit	int16u	ExifIFD	(values 1, 4 and 5 are not standard EXIF)
    # 						1 = None
    # 						2 = inches
    # 						3 = cm
    # 						4 = mm
    # 						5 = um
    uint16 focal_plane_resolution_unit
    # 0xa211	ImageNumber	no	-
    # 0xa212	SecurityClassification	no	-
    # 0xa213	ImageHistory	no	-
    # 0xa214	SubjectLocation	int16u[2]	ExifIFD
    uint16[2] subject_location
    # 0xa215	ExposureIndex	rational64u	ExifIFD
    float64 exposure_index
    # 0xa216	TIFF-EPStandardID	no	-
    # 0xa217	SensingMethod	int16u	ExifIFD
    # 						1 = Not defined
    # 						2 = One-chip color area
    # 						3 = Two-chip color area
    # 						4 = Three-chip color area
    # 						5 = Color sequential area
    # 						7 = Trilinear
    # 						8 = Color sequential linear
    uint16 sensing_method
    # 0xa300	FileSource	undef	ExifIFD
    # 						1 = Film Scanner
    # 						2 = Reflection Print Scanner
    # 						3 = Digital Camera
    # 						"\x03\x00\x00\x00" = Sigma Digital Camera
    # 0xa301	SceneType	undef	ExifIFD	1 = Directly photographed
    string scene_type
    # 0xa302	CFAPattern	undef	ExifIFD
    # 0xa401	CustomRendered	int16u	ExifIFD	(only 0 and 1 are standard EXIF, but other values are used by Apple iOS devices)
    # 						0 = Normal
    # 						1 = Custom
    # 						2 = HDR (no original saved)
    # 						3 = HDR (original saved)
    # 						4 = Original (for HDR)
    # 						6 = Panorama
    # 						7 = Portrait HDR
    # 						8 = Portrait
    uint16 custom_rendered
    # 0xa402	ExposureMode	int16u	ExifIFD
    # 						0 = Auto
    # 						1 = Manual
    # 						2 = Auto bracket
    uint16 exposure_mode
    # 0xa403	WhiteBalance	int16u	ExifIFD
    # 						0 = Auto
    # 						1 = Manual
    uint16 white_balance
    # 0xa404	DigitalZoomRatio	rational64u	ExifIFD
    float64 digital_zoom_ratio
    # 0xa405	FocalLengthIn35mmFormat	int16u	ExifIFD	(called FocalLengthIn35mmFilm by the EXIF spec.)
    uint16 focal_length_in_35mm_film
    # 0xa406	SceneCaptureType	int16u	ExifIFD	(the value of 4 is non-standard, and used by some Samsung models)
    # 						0 = Standard
    # 						1 = Landscape
    # 						2 = Portrait
    # 						3 = Night
    # 						4 = Other
    uint16 scene_capture_type
    # 0xa407	GainControl	int16u	ExifIFD
    # 						0 = None
    # 						1 = Low gain up
    # 						2 = High gain up
    # 						3 = Low gain down
    # 						4 = High gain down
    uint16 gain_control
    # 0xa408	Contrast	int16u	ExifIFD
    # 						0 = Normal
    # 						1 = Low
    # 						2 = High
    uint16 contrast
    # 0xa409	Saturation	int16u	ExifIFD
    # 						0 = Normal
    # 						1 = Low
    # 						2 = High
    uint16 saturation
    # 0xa40a	Sharpness	int16u	ExifIFD
    # 						0 = Normal
    # 						1 = Soft
    # 						2 = Hard
    uint16 sharpness
    # 0xa40b	DeviceSettingDescription	no	-	 
    # 0xa40c	SubjectDistanceRange	int16u	ExifIFD
    # 						0 = Unknown
    # 						1 = Macro
    # 						2 = Close
    # 						3 = Distant
    uint16 subject_distance_range
    # 0xa420	ImageUniqueID	string	ExifIFD
    string image_unique_id
    # 0xa430	OwnerName	string	ExifIFD	(called CameraOwnerName by the EXIF spec.)
    string camera_owner_name
    # 0xa431	SerialNumber	string	ExifIFD	(called BodySerialNumber by the EXIF spec.)
    string body_serial_number
    # 0xa432	LensInfo	rational64u[4]	ExifIFD	(4 rational values giving focal and aperture ranges, called LensSpecification by the EXIF spec.)
    float64[4] lens_specification
    # 0xa433	LensMake	string	ExifIFD
    string lens_make
    # 0xa434	LensModel	string	ExifIFD
    string lens_model
    # 0xa435	LensSerialNumber	string	ExifIFD
    string lens_serial_number
    # 0xa460	CompositeImage	int16u	ExifIFD
    # 						0 = Unknown
    # 						1 = Not a Composite Image
    # 						2 = General Composite Image
    # 						3 = Composite Image Captured While Shooting
    uint16 composite_image
    # 0xa461	CompositeImageCount	int16u[2]	ExifIFD	(2 values: 1. Number of source images, 2. Number of images used. Called SourceImageNumberOfCompositeImage by the EXIF spec.)
    # 0xa462	CompositeImageExposureTimes	undef	ExifIFD	(11 or more values: 1. Total exposure time period, 2. Total exposure of all source images, 3. Total exposure of all used images, 4. Max exposure time of source images, 5. Max exposure time of used images, 6. Min exposure time of source images, 7. Min exposure of used images, 8. Number of sequences, 9. Number of source images in sequence. 10-N. Exposure times of each source image. Called SourceExposureTimesOfCompositeImage by the EXIF spec.)
    uint16[2] composite_image_count
    # 0xa480	GDALMetadata	string	IFD0
    # 0xa481	GDALNoData	string	IFD0
    # 0xa500	Gamma	rational64u	ExifIFD
    float64 gamma
    # 0xafc0	ExpandSoftware	no	-
    # 0xafc1	ExpandLens	no	-
    # 0xafc2	ExpandFilm	no	-
    # 0xafc3	ExpandFilterLens	no	-
    # 0xafc4	ExpandScanner	no	-
    # 0xafc5	ExpandFlashLamp	no	-
    # 0xb4c3	HasselbladRawImage	no	-
    # 0xbc01	PixelFormat	no	-	(tags 0xbc** are used in Windows HD Photo (HDP and WDP) images. The actual PixelFormat values are 16-byte GUID's but the leading 15 bytes, '6fddc324-4e03-4bfe-b1853-d77768dc9', have been removed below to avoid unnecessary clutter)
    # 						0x5 = Black & White
    # 						0x8 = 8-bit Gray
    # 						0x9 = 16-bit BGR555
    # 						0xa = 16-bit BGR565
    # 						0xb = 16-bit Gray
    # 						0xc = 24-bit BGR
    # 						0xd = 24-bit RGB
    # 						0xe = 32-bit BGR
    # 						0xf = 32-bit BGRA
    # 						0x10 = 32-bit PBGRA
    # 						0x11 = 32-bit Gray Float
    # 						0x12 = 48-bit RGB Fixed Point
    # 						0x13 = 32-bit BGR101010
    # 						0x15 = 48-bit RGB
    # 						0x16 = 64-bit RGBA
    # 						0x17 = 64-bit PRGBA
    # 						0x18 = 96-bit RGB Fixed Point
    # 						0x19 = 128-bit RGBA Float
    # 						0x1a = 128-bit PRGBA Float
    # 						0x1b = 128-bit RGB Float
    # 						0x1c = 32-bit CMYK
    # 						0x1d = 64-bit RGBA Fixed Point
    # 						0x1e = 128-bit RGBA Fixed Point
    # 						0x1f = 64-bit CMYK
    # 						0x20 = 24-bit 3 Channels
    # 						0x21 = 32-bit 4 Channels
    # 						0x22 = 40-bit 5 Channels
    # 						0x23 = 48-bit 6 Channels
    # 						0x24 = 56-bit 7 Channels
    # 						0x25 = 64-bit 8 Channels
    # 						0x26 = 48-bit 3 Channels
    # 						0x27 = 64-bit 4 Channels
    # 						0x28 = 80-bit 5 Channels
    # 						0x29 = 96-bit 6 Channels
    # 						0x2a = 112-bit 7 Channels
    # 						0x2b = 128-bit 8 Channels
    # 						0x2c = 40-bit CMYK Alpha
    # 						0x2d = 80-bit CMYK Alpha
    # 						0x2e = 32-bit 3 Channels Alpha
    # 						0x2f = 40-bit 4 Channels Alpha
    # 						0x30 = 48-bit 5 Channels Alpha
    # 						0x31 = 56-bit 6 Channels Alpha
    # 						0x32 = 64-bit 7 Channels Alpha
    # 						0x33 = 72-bit 8 Channels Alpha
    # 						0x34 = 64-bit 3 Channels Alpha
    # 						0x35 = 80-bit 4 Channels Alpha
    # 						0x36 = 96-bit 5 Channels Alpha
    # 						0x37 = 112-bit 6 Channels Alpha
    # 						0x38 = 128-bit 7 Channels Alpha
    # 						0x39 = 144-bit 8 Channels Alpha
    # 						0x3a = 64-bit RGBA Half
    # 						0x3b = 48-bit RGB Half
    # 						0x3d = 32-bit RGBE
    # 						0x3e = 16-bit Gray Half
    # 						0x3f = 32-bit Gray Fixed Point
    # 0xbc02	Transformation	no	-	
    # 						0 = Horizontal (normal)
    # 						1 = Mirror vertical
    # 						2 = Mirror horizontal
    # 						3 = Rotate 180
    # 						4 = Rotate 90 CW
    # 						5 = Mirror horizontal and rotate 90 CW
    # 						6 = Mirror horizontal and rotate 270 CW
    # 						7 = Rotate 270 CW
    # 0xbc03	Uncompressed	no	-
    # 						0 = No
    # 						1 = Yes
    # 0xbc04	ImageType	no	-
    # 						Bit 0 = Preview
    # 						Bit 1 = Page
    # 0xbc80	ImageWidth	no	-
    # 0xbc81	ImageHeight	no	-
    # 0xbc82	WidthResolution	no	-
    # 0xbc83	HeightResolution	no	-
    # 0xbcc0	ImageOffset	no	-
    # 0xbcc1	ImageByteCount	no	-
    # 0xbcc2	AlphaOffset	no	-
    # 0xbcc3	AlphaByteCount	no	-
    # 0xbcc4	ImageDataDiscard	no	-
    # 						0 = Full Resolution
    # 						1 = Flexbits Discarded
    # 						2 = HighPass Frequency Data Discarded
    # 						3 = Highpass and LowPass Frequency Data Discarded
    # 0xbcc5	AlphaDataDiscard	no	-
    # 						0 = Full Resolution
    # 						1 = Flexbits Discarded
    # 						2 = HighPass Frequency Data Discarded
    # 						3 = Highpass and LowPass Frequency Data Discarded
    # 0xc427	OceScanjobDesc	no	-
    # 0xc428	OceApplicationSelector	no	-
    # 0xc429	OceIDNumber	no	-
    # 0xc42a	OceImageLogic	no	-
    # 0xc44f	Annotations	no	-
    # 0xc4a5	PrintIM	undef	IFD0	--> PrintIM Tags
    # 0xc51b	HasselbladExif	no	-
    # 0xc573	OriginalFileName	no	-	(used by some obscure software)
    # 0xc580	USPTOOriginalContentType	no	-
    # 						0 = Text or Drawing
    # 						1 = Grayscale
    # 						2 = Color
    # 0xc5e0	CR2CFAPattern	no	-
    # 						1 => '0 1 1 2' = [Red,Green][Green,Blue]
    # 						4 => '1 0 2 1' = [Green,Red][Blue,Green]
    # 						3 => '1 2 0 1' = [Green,Blue][Red,Green]
    # 						2 => '2 1 1 0' = [Blue,Green][Green,Red]
    # 0xc612	DNGVersion	int8u[4]!	IFD0	(tags 0xc612-0xcd3b are defined by the DNG specification unless otherwise noted. See https://helpx.adobe.com/photoshop/digital-negative.html for the specification)
    # 0xc613	DNGBackwardVersion	int8u[4]!	IFD0
    # 0xc614	UniqueCameraModel	string	IFD0
    # 0xc615	LocalizedCameraModel	string	IFD0
    # 0xc616	CFAPlaneColor	no	SubIFD
    # 0xc617	CFALayout	no	SubIFD
    # 						1 = Rectangular
    # 						2 = Even columns offset down 1/2 row
    # 						3 = Even columns offset up 1/2 row
    # 						4 = Even rows offset right 1/2 column
    # 						5 = Even rows offset left 1/2 column
    # 						6 = Even rows offset up by 1/2 row, even columns offset left by 1/2 column
    # 						7 = Even rows offset up by 1/2 row, even columns offset right by 1/2 column
    # 						8 = Even rows offset down by 1/2 row, even columns offset left by 1/2 column
    # 						9 = Even rows offset down by 1/2 row, even columns offset right by 1/2 column
    # 0xc618	LinearizationTable	int16u[n]!	SubIFD
    # 0xc619	BlackLevelRepeatDim	int16u[2]!	SubIFD
    # 0xc61a	BlackLevel	rational64u[n]!	SubIFD
    # 0xc61b	BlackLevelDeltaH	rational64s[n]!	SubIFD
    # 0xc61c	BlackLevelDeltaV	rational64s[n]!	SubIFD
    # 0xc61d	WhiteLevel	int32u[n]!	SubIFD
    # 0xc61e	DefaultScale	rational64u[2]!	SubIFD
    # 0xc61f	DefaultCropOrigin	int32u[2]!	SubIFD
    # 0xc620	DefaultCropSize	int32u[2]!	SubIFD
    # 0xc621	ColorMatrix1	rational64s[n]!	IFD0
    # 0xc622	ColorMatrix2	rational64s[n]!	IFD0
    # 0xc623	CameraCalibration1	rational64s[n]!	IFD0
    # 0xc624	CameraCalibration2	rational64s[n]!	IFD0
    # 0xc625	ReductionMatrix1	rational64s[n]!	IFD0
    # 0xc626	ReductionMatrix2	rational64s[n]!	IFD0
    # 0xc627	AnalogBalance	rational64u[n]!	IFD0
    # 0xc628	AsShotNeutral	rational64u[n]!	IFD0
    # 0xc629	AsShotWhiteXY	rational64u[2]!	IFD0
    # 0xc62a	BaselineExposure	rational64s!	IFD0
    # 0xc62b	BaselineNoise	rational64u!	IFD0
    # 0xc62c	BaselineSharpness	rational64u!	IFD0
    # 0xc62d	BayerGreenSplit	int32u!	SubIFD
    # 0xc62e	LinearResponseLimit	rational64u!	IFD0
    # 0xc62f	CameraSerialNumber	string	IFD0
    # 0xc630	DNGLensInfo	rational64u[4]	IFD0
    # 0xc631	ChromaBlurRadius	rational64u!	SubIFD
    # 0xc632	AntiAliasStrength	rational64u!	SubIFD
    # 0xc633	ShadowScale	rational64u!	IFD0
    # 0xc634	SR2Private	-	IFD0	--> Sony SR2Private Tags
    # 						DNGAdobeData	undef!	IFD0	--> DNG AdobeData Tags
    # 						MakerNotePentax	-	IFD0	--> Pentax Tags
    # 						MakerNotePentax5	-	IFD0	--> Pentax Tags
    # 						MakerNoteRicohPentax	-	IFD0	--> Pentax Tags
    # 						DNGPrivateData	-	IFD0
    # 0xc635	MakerNoteSafety	int16u	IFD0
    # 						0 = Unsafe
    # 						1 = Safe
    # 0xc640	RawImageSegmentation	no	-	(used in segmented Canon CR2 images. 3 numbers: 1. Number of segments minus one; 2. Pixel width of segments except last; 3. Pixel width of last segment)
    # 0xc65a	CalibrationIlluminant1	int16u!	IFD0	--> EXIF LightSource Values
    # 0xc65b	CalibrationIlluminant2	int16u!	IFD0	--> EXIF LightSource Values
    # 0xc65c	BestQualityScale	rational64u!	SubIFD
    # 0xc65d	RawDataUniqueID	int8u[16]!	IFD0
    # 0xc660	AliasLayerMetadata	no	-	(used by Alias Sketchbook Pro)
    # 0xc68b	OriginalRawFileName	string!	IFD0
    # 0xc68c	OriginalRawFileData	undef!	IFD0	--> DNG OriginalRaw Tags
    # 0xc68d	ActiveArea	int32u[4]!	SubIFD
    # 0xc68e	MaskedAreas	int32u[n]!	SubIFD
    # 0xc68f	AsShotICCProfile	undef!	IFD0	--> ICC_Profile Tags
    # 0xc690	AsShotPreProfileMatrix	rational64s[n]!	IFD0
    # 0xc691	CurrentICCProfile	undef!	IFD0	--> ICC_Profile Tags
    # 0xc692	CurrentPreProfileMatrix	rational64s[n]!	IFD0
    # 0xc6bf	ColorimetricReference	int16u!	IFD0
    # 0xc6c5	SRawType	no	IFD0
    # 0xc6d2	PanasonicTitle	undef	IFD0	(proprietary Panasonic tag used for baby/pet name, etc)
    # 0xc6d3	PanasonicTitle2	undef	IFD0	(proprietary Panasonic tag used for baby/pet name with age)
    # 0xc6f3	CameraCalibrationSig	string!	IFD0
    # 0xc6f4	ProfileCalibrationSig	string!	IFD0
    # 0xc6f5	ProfileIFD	-	IFD0	--> EXIF Tags
    # 0xc6f6	AsShotProfileName	string!	IFD0
    # 0xc6f7	NoiseReductionApplied	rational64u!	SubIFD
    # 0xc6f8	ProfileName	string!	IFD0
    # 0xc6f9	ProfileHueSatMapDims	int32u[3]!	IFD0
    # 0xc6fa	ProfileHueSatMapData1	float[n]!	IFD0
    # 0xc6fb	ProfileHueSatMapData2	float[n]!	IFD0
    # 0xc6fc	ProfileToneCurve	float[n]!	IFD0
    # 0xc6fd	ProfileEmbedPolicy	int32u!	IFD0
    # 						0 = Allow Copying
    # 						1 = Embed if Used
    # 						2 = Never Embed
    # 						3 = No Restrictions
    # 0xc6fe	ProfileCopyright	string!	IFD0
    # 0xc714	ForwardMatrix1	rational64s[n]!	IFD0
    # 0xc715	ForwardMatrix2	rational64s[n]!	IFD0
    # 0xc716	PreviewApplicationName	string!	IFD0
    # 0xc717	PreviewApplicationVersion	string!	IFD0
    # 0xc718	PreviewSettingsName	string!	IFD0
    # 0xc719	PreviewSettingsDigest	int8u!	IFD0
    # 0xc71a	PreviewColorSpace	int32u!	IFD0
    # 						0 = Unknown
    # 						1 = Gray Gamma 2.2
    # 						2 = sRGB
    # 						3 = Adobe RGB
    # 						4 = ProPhoto RGB
    # 0xc71b	PreviewDateTime	string!	IFD0
    # 0xc71c	RawImageDigest	int8u[16]!	IFD0
    # 0xc71d	OriginalRawFileDigest	int8u[16]!	IFD0
    # 0xc71e	SubTileBlockSize	no	-
    # 0xc71f	RowInterleaveFactor	no	-
    # 0xc725	ProfileLookTableDims	int32u[3]!	IFD0
    # 0xc726	ProfileLookTableData	float[n]!	IFD0
    # 0xc740	OpcodeList1	undef!	SubIFD
    # 						1 = WarpRectilinear
    # 						2 = WarpFisheye
    # 						3 = FixVignetteRadial
    # 						4 = FixBadPixelsConstant
    # 						5 = FixBadPixelsList
    # 						6 = TrimBounds
    # 						7 = MapTable
    # 						8 = MapPolynomial
    # 						9 = GainMap
    # 						10 = DeltaPerRow
    # 						11 = DeltaPerColumn
    # 						12 = ScalePerRow
    # 						13 = ScalePerColumn
    # 						14 = WarpRectilinear2
    # 0xc741	OpcodeList2	undef!	SubIFD	
    # 						1 = WarpRectilinear
    # 						2 = WarpFisheye
    # 						3 = FixVignetteRadial
    # 						4 = FixBadPixelsConstant
    # 						5 = FixBadPixelsList
    # 						6 = TrimBounds
    # 						7 = MapTable
    # 						8 = MapPolynomial
    # 						9 = GainMap
    # 						10 = DeltaPerRow
    # 						11 = DeltaPerColumn
    # 						12 = ScalePerRow
    # 						13 = ScalePerColumn
    # 						14 = WarpRectilinear2
    # 0xc74e	OpcodeList3	undef!	SubIFD	
    # 						1 = WarpRectilinear
    # 						2 = WarpFisheye
    # 						3 = FixVignetteRadial
    # 						4 = FixBadPixelsConstant
    # 						5 = FixBadPixelsList
    # 						6 = TrimBounds
    # 						7 = MapTable
    # 						8 = MapPolynomial
    # 						9 = GainMap
    # 						10 = DeltaPerRow
    # 						11 = DeltaPerColumn
    # 						12 = ScalePerRow
    # 						13 = ScalePerColumn
    # 						14 = WarpRectilinear2
    # 0xc761	NoiseProfile	double[n]!	SubIFD
    # 0xc763	TimeCodes	int8u[n]	IFD0
    # 0xc764	FrameRate	rational64s	IFD0
    # 0xc772	TStop	rational64u[n]	IFD0
    # 0xc789	ReelName	string	IFD0
    # 0xc791	OriginalDefaultFinalSize	int32u[2]!	IFD0
    # 0xc792	OriginalBestQualitySize	int32u[2]!	IFD0	(called OriginalBestQualityFinalSize by the DNG spec)
    # 0xc793	OriginalDefaultCropSize	rational64u[2]!	IFD0
    # 0xc7a1	CameraLabel	string	IFD0
    # 0xc7a3	ProfileHueSatMapEncoding	int32u!	IFD0
    # 						0 = Linear
    # 						1 = sRGB
    # 0xc7a4	ProfileLookTableEncoding	int32u!	IFD0
    # 						0 = Linear
    # 						1 = sRGB
    # 0xc7a5	BaselineExposureOffset	rational64s!	IFD0
    # 0xc7a6	DefaultBlackRender	int32u!	IFD0
    # 						0 = Auto
    # 						1 = None
    # 0xc7a7	NewRawImageDigest	int8u[16]!	IFD0
    # 0xc7a8	RawToPreviewGain	double!	IFD0
    # 0xc7aa	CacheVersion	int32u!	SubIFD2
    # 0xc7b5	DefaultUserCrop	rational64u[4]!	SubIFD
    # 0xc7d5	NikonNEFInfo	-	-	--> Nikon NEFInfo Tags
    # 0xc7e9	DepthFormat	int16u!	IFD0	(tags 0xc7e9-0xc7ee added by DNG 1.5.0.0)
    # 						0 = Unknown
    # 						1 = Linear
    # 						2 = Inverse
    # 0xc7ea	DepthNear	rational64u!	IFD0
    # 0xc7eb	DepthFar	rational64u!	IFD0
    # 0xc7ec	DepthUnits	int16u!	IFD0
    # 						0 = Unknown
    # 						1 = Meters
    # 0xc7ed	DepthMeasureType	int16u!	IFD0
    # 						0 = Unknown
    # 						1 = Optical Axis
    # 						2 = Optical Ray
    # 0xc7ee	EnhanceParams	string!	IFD0
    # 0xcd2d	ProfileGainTableMap	undef!	SubIFD
    # 0xcd2e	SemanticName	no	SubIFD
    # 0xcd30	SemanticInstanceIFD	no	SubIFD
    # 0xcd31	CalibrationIlluminant3	int16u!	IFD0	--> EXIF LightSource Values
    # 0xcd32	CameraCalibration3	rational64s[n]!	IFD0
    # 0xcd33	ColorMatrix3	rational64s[n]!	IFD0
    # 0xcd34	ForwardMatrix3	rational64s[n]!	IFD0
    # 0xcd35	IlluminantData1	undef!	IFD0
    # 0xcd36	IlluminantData2	undef!	IFD0
    # 0xcd37	IlluminantData3	undef!	IFD0
    # 0xcd38	MaskSubArea	no	SubIFD
    # 0xcd39	ProfileHueSatMapData3	float[n]!	IFD0
    # 0xcd3a	ReductionMatrix3	rational64s[n]!	IFD0
    # 0xcd3b	RGBTables	undef!	IFD0
    # 0xea1c	Padding	undef!	ExifIFD
    # 0xea1d	OffsetSchema	int32s!	ExifIFD	(Microsoft's ill-conceived maker note offset difference)
    # 0xfde8	OwnerName	string/	ExifIFD	(tags 0xfde8-0xfdea and 0xfe4c-0xfe58 are generated by Photoshop Camera RAW. Some names are the same as other EXIF tags, but ExifTool will avoid writing these unless they already exist in the file)
    # 0xfde9	SerialNumber	string/	ExifIFD
    # 0xfdea	Lens	string/	ExifIFD
    # 0xfe00	KDC_IFD	-	-	--> Kodak KDC_IFD Tags# (used in some Kodak KDC images)
    # 0xfe4c	RawFile	string/	ExifIFD
    # 0xfe4d	Converter	string/	ExifIFD
    # 0xfe4e	WhiteBalance	string/	ExifIFD
    # 0xfe51	Exposure	string/	ExifIFD
    # 0xfe52	Shadows	string/	ExifIFD
    # 0xfe53	Brightness	string/	ExifIFD
    # 0xfe54	Contrast	string/	ExifIFD
    # 0xfe55	Saturation	string/	ExifIFD
    # 0xfe56	Sharpness	string/	ExifIFD
    # 0xfe57	Smoothness	string/	ExifIFD
    # 0xfe58	MoireFilter	string/	ExifIFD
    
    ================================================================================
    MSG: jsk_recognition_msgs/ExifGPSInfo
    #
    # https://exiftool.org/TagNames/GPS.html
    #
    # Tag ID	Tag Name	Writable	Values / Notes
    # 0x0000	GPSVersionID	int8u[4]:
    uint8[4] gps_version_id
    # 0x0001	GPSLatitudeRef	string[2]	(tags 0x0001-0x0006 used for camera location according to MWG 2.0. ExifTool will also accept a number when writing GPSLatitudeRef, positive for north latitudes or negative for south, or a string containing N, North, S or South)
    # 						'N' = North
    # 						'S' = South
    string gps_latitude_ref
    # 0x0002	GPSLatitude	rational64u[3]
    float64[3] gps_latitude
    # 0x0003	GPSLongitudeRef	string[2]	(ExifTool will also accept a number when writing this tag, positive for east longitudes or negative for west, or a string containing E, East, W or West)
    # 						'E' = East
    # 						'W' = West
    string gps_longitude_ref
    # 0x0004	GPSLongitude	rational64u[3]
    float64[3] gps_longitude
    # 0x0005	GPSAltitudeRef	int8u	(ExifTool will also accept number when writing this tag, with negative numbers indicating below sea level)
    uint8 gps_altitude_ref
    # 						0 = Above Sea Level
    # 						1 = Below Sea Level
    # 0x0006	GPSAltitude	rational64u
    float64 gps_altitude
    # 0x0007	GPSTimeStamp	rational64u[3]	(UTC time of GPS fix. When writing, date is stripped off if present, and time is adjusted to UTC if it includes a timezone)
    float64 gps_time_stamp
    # 0x0008	GPSSatellites	string
    string gps_satellites
    # 0x0009	GPSStatus	string[2]
    # 						'A' = Measurement Active
    # 						'V' = Measurement Void
    string gps_status
    # 0x000a	GPSMeasureMode	string[2]
    # 						2 = 2-Dimensional Measurement
    # 						3 = 3-Dimensional Measurement
    string gps_measure_mode
    # 0x000b	GPSDOP	rational64u
    float64 gpf_sdop
    # 0x000c	GPSSpeedRef	string[2]
    # 						'K' = km/h
    # 						'M' = mph
    # 						'N' = knots
    string gps_speed_ref
    # 0x000d	GPSSpeed	rational64u
    float64 gps_speed
    # 0x000e	GPSTrackRef	string[2]
    # 						'M' = Magnetic North
    # 						'T' = True North
    string gps_track_ref
    # 0x000f	GPSTrack	rational64u
    float64 gps_track
    # 0x0010	GPSImgDirectionRef	string[2]
    # 						'M' = Magnetic North
    # 						'T' = True North
    string gps_img_direction_ref
    # 0x0011	GPSImgDirection	rational64u
    float64 gps_img_direction
    # 0x0012	GPSMapDatum	string
    string gps_map_datum
    # 0x0013	GPSDestLatitudeRef	string[2]	(tags 0x0013-0x001a used for subject location according to MWG 2.0)
    # 						'N' = North
    # 						'S' = South
    string gps_dest_latitude_ref
    # 0x0014	GPSDestLatitude	rational64u[3]
    float64[3] gps_dest_latitude
    # 0x0015	GPSDestLongitudeRef	string[2]
    # 						'E' = East
    # 						'W' = West
    string gps_dest_longitude_ref
    # 0x0016	GPSDestLongitude	rational64u[3]
    float64[3] gps_dest_longitude
    # 0x0017	GPSDestBearingRef	string[2]
    # 						'M' = Magnetic North
    # 						'T' = True North
    string gps_dest_bearing_ref
    # 0x0018	GPSDestBearing	rational64u
    float64 gps_dest_bearing
    # 0x0019	GPSDestDistanceRef	string[2]
    # 						'K' = Kilometers
    # 						'M' = Miles
    # 						'N' = Nautical Miles
    string gps_dest_distance_ref
    # 0x001a	GPSDestDistance	rational64u
    float64 gps_dest_distance
    # 0x001b	GPSProcessingMethod	undef	(values of "GPS", "CELLID", "WLAN" or "MANUAL" by the EXIF spec.)
    # 0x001c	GPSAreaInformation	undef
    # 0x001d	GPSDateStamp	string[11]	(when writing, time is stripped off if present, after adjusting date/time to UTC if time includes a timezone. Format is YYYY:mm:dd)
    string gps_date_stamp
    # 0x001e	GPSDifferential	int16u
    # 						0 = No Correction
    # 						1 = Differential Corrected
    uint16 gps_differential
    # 0x001f	GPSHPositioningError	rational64u
    float64 gps_hpositioning_error
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExifTags(null);
    if (msg.interop_index !== undefined) {
      resolved.interop_index = msg.interop_index;
    }
    else {
      resolved.interop_index = ''
    }

    if (msg.image_width !== undefined) {
      resolved.image_width = msg.image_width;
    }
    else {
      resolved.image_width = 0
    }

    if (msg.image_height !== undefined) {
      resolved.image_height = msg.image_height;
    }
    else {
      resolved.image_height = 0
    }

    if (msg.bits_per_sample !== undefined) {
      resolved.bits_per_sample = msg.bits_per_sample;
    }
    else {
      resolved.bits_per_sample = []
    }

    if (msg.photometric_interpretation !== undefined) {
      resolved.photometric_interpretation = msg.photometric_interpretation;
    }
    else {
      resolved.photometric_interpretation = 0
    }

    if (msg.image_description !== undefined) {
      resolved.image_description = msg.image_description;
    }
    else {
      resolved.image_description = ''
    }

    if (msg.make !== undefined) {
      resolved.make = msg.make;
    }
    else {
      resolved.make = ''
    }

    if (msg.model !== undefined) {
      resolved.model = msg.model;
    }
    else {
      resolved.model = ''
    }

    if (msg.strip_offsets !== undefined) {
      resolved.strip_offsets = msg.strip_offsets;
    }
    else {
      resolved.strip_offsets = 0
    }

    if (msg.orientation !== undefined) {
      resolved.orientation = msg.orientation;
    }
    else {
      resolved.orientation = 0
    }

    if (msg.samples_per_pixel !== undefined) {
      resolved.samples_per_pixel = msg.samples_per_pixel;
    }
    else {
      resolved.samples_per_pixel = 0
    }

    if (msg.rows_per_strip !== undefined) {
      resolved.rows_per_strip = msg.rows_per_strip;
    }
    else {
      resolved.rows_per_strip = 0
    }

    if (msg.strip_byte_counts !== undefined) {
      resolved.strip_byte_counts = msg.strip_byte_counts;
    }
    else {
      resolved.strip_byte_counts = 0
    }

    if (msg.x_resolution !== undefined) {
      resolved.x_resolution = msg.x_resolution;
    }
    else {
      resolved.x_resolution = 0.0
    }

    if (msg.y_resolution !== undefined) {
      resolved.y_resolution = msg.y_resolution;
    }
    else {
      resolved.y_resolution = 0.0
    }

    if (msg.planar_configuration !== undefined) {
      resolved.planar_configuration = msg.planar_configuration;
    }
    else {
      resolved.planar_configuration = 0
    }

    if (msg.resolution_unit !== undefined) {
      resolved.resolution_unit = msg.resolution_unit;
    }
    else {
      resolved.resolution_unit = 0
    }

    if (msg.transfer_function !== undefined) {
      resolved.transfer_function = msg.transfer_function;
    }
    else {
      resolved.transfer_function = new Array(768).fill(0)
    }

    if (msg.software !== undefined) {
      resolved.software = msg.software;
    }
    else {
      resolved.software = ''
    }

    if (msg.date_time !== undefined) {
      resolved.date_time = msg.date_time;
    }
    else {
      resolved.date_time = ''
    }

    if (msg.artist !== undefined) {
      resolved.artist = msg.artist;
    }
    else {
      resolved.artist = ''
    }

    if (msg.white_point !== undefined) {
      resolved.white_point = msg.white_point;
    }
    else {
      resolved.white_point = new Array(2).fill(0)
    }

    if (msg.primary_chromaticities !== undefined) {
      resolved.primary_chromaticities = msg.primary_chromaticities;
    }
    else {
      resolved.primary_chromaticities = new Array(6).fill(0)
    }

    if (msg.tile_width !== undefined) {
      resolved.tile_width = msg.tile_width;
    }
    else {
      resolved.tile_width = 0
    }

    if (msg.tile_length !== undefined) {
      resolved.tile_length = msg.tile_length;
    }
    else {
      resolved.tile_length = 0
    }

    if (msg.jpg_from_raw_start !== undefined) {
      resolved.jpg_from_raw_start = msg.jpg_from_raw_start;
    }
    else {
      resolved.jpg_from_raw_start = 0
    }

    if (msg.jpg_from_raw_length !== undefined) {
      resolved.jpg_from_raw_length = msg.jpg_from_raw_length;
    }
    else {
      resolved.jpg_from_raw_length = 0
    }

    if (msg.ycb_cr_Coefficients !== undefined) {
      resolved.ycb_cr_Coefficients = msg.ycb_cr_Coefficients;
    }
    else {
      resolved.ycb_cr_Coefficients = new Array(3).fill(0)
    }

    if (msg.ycb_cr_sub_sampling !== undefined) {
      resolved.ycb_cr_sub_sampling = msg.ycb_cr_sub_sampling;
    }
    else {
      resolved.ycb_cr_sub_sampling = new Array(2).fill(0)
    }

    if (msg.ycb_cr_positioning !== undefined) {
      resolved.ycb_cr_positioning = msg.ycb_cr_positioning;
    }
    else {
      resolved.ycb_cr_positioning = 0
    }

    if (msg.reference_black_white !== undefined) {
      resolved.reference_black_white = msg.reference_black_white;
    }
    else {
      resolved.reference_black_white = new Array(6).fill(0)
    }

    if (msg.copyright !== undefined) {
      resolved.copyright = msg.copyright;
    }
    else {
      resolved.copyright = ''
    }

    if (msg.exposure_time !== undefined) {
      resolved.exposure_time = msg.exposure_time;
    }
    else {
      resolved.exposure_time = 0.0
    }

    if (msg.f_number !== undefined) {
      resolved.f_number = msg.f_number;
    }
    else {
      resolved.f_number = 0.0
    }

    if (msg.exposure_program !== undefined) {
      resolved.exposure_program = msg.exposure_program;
    }
    else {
      resolved.exposure_program = 0
    }

    if (msg.gps_info !== undefined) {
      resolved.gps_info = ExifGPSInfo.Resolve(msg.gps_info)
    }
    else {
      resolved.gps_info = new ExifGPSInfo()
    }

    if (msg.iso !== undefined) {
      resolved.iso = msg.iso;
    }
    else {
      resolved.iso = []
    }

    if (msg.sensitivity_type !== undefined) {
      resolved.sensitivity_type = msg.sensitivity_type;
    }
    else {
      resolved.sensitivity_type = 0
    }

    if (msg.standard_output_sensitivity !== undefined) {
      resolved.standard_output_sensitivity = msg.standard_output_sensitivity;
    }
    else {
      resolved.standard_output_sensitivity = 0
    }

    if (msg.recommended_exposure_index !== undefined) {
      resolved.recommended_exposure_index = msg.recommended_exposure_index;
    }
    else {
      resolved.recommended_exposure_index = 0
    }

    if (msg.iso_speed !== undefined) {
      resolved.iso_speed = msg.iso_speed;
    }
    else {
      resolved.iso_speed = 0
    }

    if (msg.iso_speed_latitudeyyy !== undefined) {
      resolved.iso_speed_latitudeyyy = msg.iso_speed_latitudeyyy;
    }
    else {
      resolved.iso_speed_latitudeyyy = 0
    }

    if (msg.iso_speed_latitudezzz !== undefined) {
      resolved.iso_speed_latitudezzz = msg.iso_speed_latitudezzz;
    }
    else {
      resolved.iso_speed_latitudezzz = 0
    }

    if (msg.exif_version !== undefined) {
      resolved.exif_version = msg.exif_version;
    }
    else {
      resolved.exif_version = ''
    }

    if (msg.date_time_original !== undefined) {
      resolved.date_time_original = msg.date_time_original;
    }
    else {
      resolved.date_time_original = ''
    }

    if (msg.date_time_digitized !== undefined) {
      resolved.date_time_digitized = msg.date_time_digitized;
    }
    else {
      resolved.date_time_digitized = ''
    }

    if (msg.offset_time !== undefined) {
      resolved.offset_time = msg.offset_time;
    }
    else {
      resolved.offset_time = ''
    }

    if (msg.offset_time_original !== undefined) {
      resolved.offset_time_original = msg.offset_time_original;
    }
    else {
      resolved.offset_time_original = ''
    }

    if (msg.offset_time_digitized !== undefined) {
      resolved.offset_time_digitized = msg.offset_time_digitized;
    }
    else {
      resolved.offset_time_digitized = ''
    }

    if (msg.components_configuration !== undefined) {
      resolved.components_configuration = msg.components_configuration;
    }
    else {
      resolved.components_configuration = new Array(4).fill(0)
    }

    if (msg.compressed_bits_per_pixel !== undefined) {
      resolved.compressed_bits_per_pixel = msg.compressed_bits_per_pixel;
    }
    else {
      resolved.compressed_bits_per_pixel = 0.0
    }

    if (msg.shutter_speed_value !== undefined) {
      resolved.shutter_speed_value = msg.shutter_speed_value;
    }
    else {
      resolved.shutter_speed_value = 0.0
    }

    if (msg.aperture_value !== undefined) {
      resolved.aperture_value = msg.aperture_value;
    }
    else {
      resolved.aperture_value = 0.0
    }

    if (msg.brightness_value !== undefined) {
      resolved.brightness_value = msg.brightness_value;
    }
    else {
      resolved.brightness_value = 0.0
    }

    if (msg.exposure_bias_value !== undefined) {
      resolved.exposure_bias_value = msg.exposure_bias_value;
    }
    else {
      resolved.exposure_bias_value = 0.0
    }

    if (msg.max_aperture_value !== undefined) {
      resolved.max_aperture_value = msg.max_aperture_value;
    }
    else {
      resolved.max_aperture_value = 0.0
    }

    if (msg.subject_distance !== undefined) {
      resolved.subject_distance = msg.subject_distance;
    }
    else {
      resolved.subject_distance = 0.0
    }

    if (msg.metering_mode !== undefined) {
      resolved.metering_mode = msg.metering_mode;
    }
    else {
      resolved.metering_mode = 0
    }

    if (msg.light_source !== undefined) {
      resolved.light_source = msg.light_source;
    }
    else {
      resolved.light_source = 0
    }

    if (msg.flash !== undefined) {
      resolved.flash = msg.flash;
    }
    else {
      resolved.flash = 0
    }

    if (msg.focal_length !== undefined) {
      resolved.focal_length = msg.focal_length;
    }
    else {
      resolved.focal_length = 0.0
    }

    if (msg.subject_area !== undefined) {
      resolved.subject_area = msg.subject_area;
    }
    else {
      resolved.subject_area = []
    }

    if (msg.user_comment !== undefined) {
      resolved.user_comment = msg.user_comment;
    }
    else {
      resolved.user_comment = ''
    }

    if (msg.subsec_time !== undefined) {
      resolved.subsec_time = msg.subsec_time;
    }
    else {
      resolved.subsec_time = ''
    }

    if (msg.subsec_time_original !== undefined) {
      resolved.subsec_time_original = msg.subsec_time_original;
    }
    else {
      resolved.subsec_time_original = ''
    }

    if (msg.subsec_time_digitized !== undefined) {
      resolved.subsec_time_digitized = msg.subsec_time_digitized;
    }
    else {
      resolved.subsec_time_digitized = ''
    }

    if (msg.temperature !== undefined) {
      resolved.temperature = msg.temperature;
    }
    else {
      resolved.temperature = 0.0
    }

    if (msg.humidity !== undefined) {
      resolved.humidity = msg.humidity;
    }
    else {
      resolved.humidity = 0.0
    }

    if (msg.pressure !== undefined) {
      resolved.pressure = msg.pressure;
    }
    else {
      resolved.pressure = 0.0
    }

    if (msg.water_depth !== undefined) {
      resolved.water_depth = msg.water_depth;
    }
    else {
      resolved.water_depth = 0.0
    }

    if (msg.acceleration !== undefined) {
      resolved.acceleration = msg.acceleration;
    }
    else {
      resolved.acceleration = 0.0
    }

    if (msg.camera_elevation_angle !== undefined) {
      resolved.camera_elevation_angle = msg.camera_elevation_angle;
    }
    else {
      resolved.camera_elevation_angle = 0.0
    }

    if (msg.flash_pix_version !== undefined) {
      resolved.flash_pix_version = msg.flash_pix_version;
    }
    else {
      resolved.flash_pix_version = ''
    }

    if (msg.color_space !== undefined) {
      resolved.color_space = msg.color_space;
    }
    else {
      resolved.color_space = 0
    }

    if (msg.exif_image_width !== undefined) {
      resolved.exif_image_width = msg.exif_image_width;
    }
    else {
      resolved.exif_image_width = 0
    }

    if (msg.exif_image_height !== undefined) {
      resolved.exif_image_height = msg.exif_image_height;
    }
    else {
      resolved.exif_image_height = 0
    }

    if (msg.related_sound_file !== undefined) {
      resolved.related_sound_file = msg.related_sound_file;
    }
    else {
      resolved.related_sound_file = ''
    }

    if (msg.flash_energy !== undefined) {
      resolved.flash_energy = msg.flash_energy;
    }
    else {
      resolved.flash_energy = 0.0
    }

    if (msg.focal_plane_x_resolution !== undefined) {
      resolved.focal_plane_x_resolution = msg.focal_plane_x_resolution;
    }
    else {
      resolved.focal_plane_x_resolution = 0.0
    }

    if (msg.focal_plane_y_resolution !== undefined) {
      resolved.focal_plane_y_resolution = msg.focal_plane_y_resolution;
    }
    else {
      resolved.focal_plane_y_resolution = 0.0
    }

    if (msg.focal_plane_resolution_unit !== undefined) {
      resolved.focal_plane_resolution_unit = msg.focal_plane_resolution_unit;
    }
    else {
      resolved.focal_plane_resolution_unit = 0
    }

    if (msg.subject_location !== undefined) {
      resolved.subject_location = msg.subject_location;
    }
    else {
      resolved.subject_location = new Array(2).fill(0)
    }

    if (msg.exposure_index !== undefined) {
      resolved.exposure_index = msg.exposure_index;
    }
    else {
      resolved.exposure_index = 0.0
    }

    if (msg.sensing_method !== undefined) {
      resolved.sensing_method = msg.sensing_method;
    }
    else {
      resolved.sensing_method = 0
    }

    if (msg.scene_type !== undefined) {
      resolved.scene_type = msg.scene_type;
    }
    else {
      resolved.scene_type = ''
    }

    if (msg.custom_rendered !== undefined) {
      resolved.custom_rendered = msg.custom_rendered;
    }
    else {
      resolved.custom_rendered = 0
    }

    if (msg.exposure_mode !== undefined) {
      resolved.exposure_mode = msg.exposure_mode;
    }
    else {
      resolved.exposure_mode = 0
    }

    if (msg.white_balance !== undefined) {
      resolved.white_balance = msg.white_balance;
    }
    else {
      resolved.white_balance = 0
    }

    if (msg.digital_zoom_ratio !== undefined) {
      resolved.digital_zoom_ratio = msg.digital_zoom_ratio;
    }
    else {
      resolved.digital_zoom_ratio = 0.0
    }

    if (msg.focal_length_in_35mm_film !== undefined) {
      resolved.focal_length_in_35mm_film = msg.focal_length_in_35mm_film;
    }
    else {
      resolved.focal_length_in_35mm_film = 0
    }

    if (msg.scene_capture_type !== undefined) {
      resolved.scene_capture_type = msg.scene_capture_type;
    }
    else {
      resolved.scene_capture_type = 0
    }

    if (msg.gain_control !== undefined) {
      resolved.gain_control = msg.gain_control;
    }
    else {
      resolved.gain_control = 0
    }

    if (msg.contrast !== undefined) {
      resolved.contrast = msg.contrast;
    }
    else {
      resolved.contrast = 0
    }

    if (msg.saturation !== undefined) {
      resolved.saturation = msg.saturation;
    }
    else {
      resolved.saturation = 0
    }

    if (msg.sharpness !== undefined) {
      resolved.sharpness = msg.sharpness;
    }
    else {
      resolved.sharpness = 0
    }

    if (msg.subject_distance_range !== undefined) {
      resolved.subject_distance_range = msg.subject_distance_range;
    }
    else {
      resolved.subject_distance_range = 0
    }

    if (msg.image_unique_id !== undefined) {
      resolved.image_unique_id = msg.image_unique_id;
    }
    else {
      resolved.image_unique_id = ''
    }

    if (msg.camera_owner_name !== undefined) {
      resolved.camera_owner_name = msg.camera_owner_name;
    }
    else {
      resolved.camera_owner_name = ''
    }

    if (msg.body_serial_number !== undefined) {
      resolved.body_serial_number = msg.body_serial_number;
    }
    else {
      resolved.body_serial_number = ''
    }

    if (msg.lens_specification !== undefined) {
      resolved.lens_specification = msg.lens_specification;
    }
    else {
      resolved.lens_specification = new Array(4).fill(0)
    }

    if (msg.lens_make !== undefined) {
      resolved.lens_make = msg.lens_make;
    }
    else {
      resolved.lens_make = ''
    }

    if (msg.lens_model !== undefined) {
      resolved.lens_model = msg.lens_model;
    }
    else {
      resolved.lens_model = ''
    }

    if (msg.lens_serial_number !== undefined) {
      resolved.lens_serial_number = msg.lens_serial_number;
    }
    else {
      resolved.lens_serial_number = ''
    }

    if (msg.composite_image !== undefined) {
      resolved.composite_image = msg.composite_image;
    }
    else {
      resolved.composite_image = 0
    }

    if (msg.composite_image_count !== undefined) {
      resolved.composite_image_count = msg.composite_image_count;
    }
    else {
      resolved.composite_image_count = new Array(2).fill(0)
    }

    if (msg.gamma !== undefined) {
      resolved.gamma = msg.gamma;
    }
    else {
      resolved.gamma = 0.0
    }

    return resolved;
    }
};

module.exports = ExifTags;
