// Auto-generated. Do not edit!

// (in-package jsk_recognition_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let geometry_msgs = _finder('geometry_msgs');

//-----------------------------------------------------------

class HandPose {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.hand_score = null;
      this.finger_names = null;
      this.poses = null;
      this.point_scores = null;
    }
    else {
      if (initObj.hasOwnProperty('hand_score')) {
        this.hand_score = initObj.hand_score
      }
      else {
        this.hand_score = 0.0;
      }
      if (initObj.hasOwnProperty('finger_names')) {
        this.finger_names = initObj.finger_names
      }
      else {
        this.finger_names = [];
      }
      if (initObj.hasOwnProperty('poses')) {
        this.poses = initObj.poses
      }
      else {
        this.poses = [];
      }
      if (initObj.hasOwnProperty('point_scores')) {
        this.point_scores = initObj.point_scores
      }
      else {
        this.point_scores = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type HandPose
    // Serialize message field [hand_score]
    bufferOffset = _serializer.float32(obj.hand_score, buffer, bufferOffset);
    // Serialize message field [finger_names]
    bufferOffset = _arraySerializer.string(obj.finger_names, buffer, bufferOffset, null);
    // Serialize message field [poses]
    // Serialize the length for message field [poses]
    bufferOffset = _serializer.uint32(obj.poses.length, buffer, bufferOffset);
    obj.poses.forEach((val) => {
      bufferOffset = geometry_msgs.msg.Pose.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [point_scores]
    bufferOffset = _arraySerializer.float32(obj.point_scores, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type HandPose
    let len;
    let data = new HandPose(null);
    // Deserialize message field [hand_score]
    data.hand_score = _deserializer.float32(buffer, bufferOffset);
    // Deserialize message field [finger_names]
    data.finger_names = _arrayDeserializer.string(buffer, bufferOffset, null)
    // Deserialize message field [poses]
    // Deserialize array length for message field [poses]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.poses = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.poses[i] = geometry_msgs.msg.Pose.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [point_scores]
    data.point_scores = _arrayDeserializer.float32(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.finger_names.forEach((val) => {
      length += 4 + _getByteLength(val);
    });
    length += 56 * object.poses.length;
    length += 4 * object.point_scores.length;
    return length + 16;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_recognition_msgs/HandPose';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '851f5f45f1726b63464e90b860be75d5';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    float32 hand_score
    string[] finger_names
    geometry_msgs/Pose[] poses
    float32[] point_scores
    
    ================================================================================
    MSG: geometry_msgs/Pose
    # A representation of pose in free space, composed of position and orientation. 
    Point position
    Quaternion orientation
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Quaternion
    # This represents an orientation in free space in quaternion form.
    
    float64 x
    float64 y
    float64 z
    float64 w
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new HandPose(null);
    if (msg.hand_score !== undefined) {
      resolved.hand_score = msg.hand_score;
    }
    else {
      resolved.hand_score = 0.0
    }

    if (msg.finger_names !== undefined) {
      resolved.finger_names = msg.finger_names;
    }
    else {
      resolved.finger_names = []
    }

    if (msg.poses !== undefined) {
      resolved.poses = new Array(msg.poses.length);
      for (let i = 0; i < resolved.poses.length; ++i) {
        resolved.poses[i] = geometry_msgs.msg.Pose.Resolve(msg.poses[i]);
      }
    }
    else {
      resolved.poses = []
    }

    if (msg.point_scores !== undefined) {
      resolved.point_scores = msg.point_scores;
    }
    else {
      resolved.point_scores = []
    }

    return resolved;
    }
};

module.exports = HandPose;
