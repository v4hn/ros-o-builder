
"use strict";

let MotorTraceSample = require('./MotorTraceSample.js');
let MotorTemperature = require('./MotorTemperature.js');
let MotorTrace = require('./MotorTrace.js');
let ActuatorInfo = require('./ActuatorInfo.js');
let RawFTDataSample = require('./RawFTDataSample.js');
let BoardInfo = require('./BoardInfo.js');
let RawFTData = require('./RawFTData.js');

module.exports = {
  MotorTraceSample: MotorTraceSample,
  MotorTemperature: MotorTemperature,
  MotorTrace: MotorTrace,
  ActuatorInfo: ActuatorInfo,
  RawFTDataSample: RawFTDataSample,
  BoardInfo: BoardInfo,
  RawFTData: RawFTData,
};
