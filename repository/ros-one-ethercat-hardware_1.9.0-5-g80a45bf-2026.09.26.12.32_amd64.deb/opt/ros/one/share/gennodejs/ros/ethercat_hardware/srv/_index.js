
"use strict";

let SoftProcessorFirmwareRead = require('./SoftProcessorFirmwareRead.js')
let SoftProcessorFirmwareWrite = require('./SoftProcessorFirmwareWrite.js')
let SoftProcessorReset = require('./SoftProcessorReset.js')

module.exports = {
  SoftProcessorFirmwareRead: SoftProcessorFirmwareRead,
  SoftProcessorFirmwareWrite: SoftProcessorFirmwareWrite,
  SoftProcessorReset: SoftProcessorReset,
};
