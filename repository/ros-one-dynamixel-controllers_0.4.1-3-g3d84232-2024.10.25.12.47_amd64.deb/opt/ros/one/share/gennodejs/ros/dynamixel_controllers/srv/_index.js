
"use strict";

let SetTorqueLimit = require('./SetTorqueLimit.js')
let StartController = require('./StartController.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let StopController = require('./StopController.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let TorqueEnable = require('./TorqueEnable.js')
let RestartController = require('./RestartController.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let SetSpeed = require('./SetSpeed.js')

module.exports = {
  SetTorqueLimit: SetTorqueLimit,
  StartController: StartController,
  SetCompliancePunch: SetCompliancePunch,
  StopController: StopController,
  SetComplianceMargin: SetComplianceMargin,
  TorqueEnable: TorqueEnable,
  RestartController: RestartController,
  SetComplianceSlope: SetComplianceSlope,
  SetSpeed: SetSpeed,
};
