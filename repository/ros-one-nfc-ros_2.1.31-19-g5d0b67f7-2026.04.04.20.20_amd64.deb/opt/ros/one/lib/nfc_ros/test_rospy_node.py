#!/usr/bin/env bash

if [ "TRUE" = "TRUE" ]; then
	exec /opt/ros/one/share/nfc_ros/venv/bin/python /dev/fd/3 "$@" 3<<- EOF
	import re
	import sys

	from setproctitle import setproctitle

	program_path = "/opt/ros/one/share/nfc_ros/catkin_virtualenv_scripts/test_rospy_node.py"
	setproctitle(' '.join(["test_rospy_node.py"] + sys.argv[1:]))
	exec(open(program_path).read())
	EOF
else
	exec /opt/ros/one/share/nfc_ros/venv/bin/python /opt/ros/one/share/nfc_ros/catkin_virtualenv_scripts/test_rospy_node.py "$@"
fi
