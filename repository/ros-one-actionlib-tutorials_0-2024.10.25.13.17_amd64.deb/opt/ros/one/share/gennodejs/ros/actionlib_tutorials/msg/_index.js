
"use strict";

let AveragingActionResult = require('./AveragingActionResult.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let AveragingAction = require('./AveragingAction.js');
let FibonacciAction = require('./FibonacciAction.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let FibonacciResult = require('./FibonacciResult.js');
let AveragingGoal = require('./AveragingGoal.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let AveragingResult = require('./AveragingResult.js');

module.exports = {
  AveragingActionResult: AveragingActionResult,
  FibonacciActionFeedback: FibonacciActionFeedback,
  FibonacciGoal: FibonacciGoal,
  AveragingAction: AveragingAction,
  FibonacciAction: FibonacciAction,
  AveragingActionGoal: AveragingActionGoal,
  FibonacciFeedback: FibonacciFeedback,
  AveragingFeedback: AveragingFeedback,
  FibonacciActionGoal: FibonacciActionGoal,
  FibonacciActionResult: FibonacciActionResult,
  FibonacciResult: FibonacciResult,
  AveragingGoal: AveragingGoal,
  AveragingActionFeedback: AveragingActionFeedback,
  AveragingResult: AveragingResult,
};
