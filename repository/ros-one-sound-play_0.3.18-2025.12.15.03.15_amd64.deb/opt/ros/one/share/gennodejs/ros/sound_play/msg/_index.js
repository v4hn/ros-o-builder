
"use strict";

let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestAction: SoundRequestAction,
  SoundRequestResult: SoundRequestResult,
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequest: SoundRequest,
};
