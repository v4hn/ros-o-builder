
"use strict";

let RestartController = require('./RestartController.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let StopController = require('./StopController.js')
let SetSpeed = require('./SetSpeed.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let StartController = require('./StartController.js')
let TorqueEnable = require('./TorqueEnable.js')

module.exports = {
  RestartController: RestartController,
  SetCompliancePunch: SetCompliancePunch,
  SetComplianceSlope: SetComplianceSlope,
  StopController: StopController,
  SetSpeed: SetSpeed,
  SetTorqueLimit: SetTorqueLimit,
  SetComplianceMargin: SetComplianceMargin,
  StartController: StartController,
  TorqueEnable: TorqueEnable,
};
