
"use strict";

let ElectricCurrentStamped = require('./ElectricCurrentStamped.js');
let PowerSwitchState = require('./PowerSwitchState.js');
let Power = require('./Power.js');
let VoltageStamped = require('./VoltageStamped.js');
let ColorRGBAStamped = require('./ColorRGBAStamped.js');
let Brightness = require('./Brightness.js');
let PowerStamped = require('./PowerStamped.js');
let ElectricCurrent = require('./ElectricCurrent.js');
let PowerSwitchStateStamped = require('./PowerSwitchStateStamped.js');
let Voltage = require('./Voltage.js');
let BrightnessStamped = require('./BrightnessStamped.js');
let Heartbeat = require('./Heartbeat.js');
let ElectricCurrentMeasurement = require('./ElectricCurrentMeasurement.js');
let PowerMeasurement = require('./PowerMeasurement.js');
let VoltageMeasurement = require('./VoltageMeasurement.js');

module.exports = {
  ElectricCurrentStamped: ElectricCurrentStamped,
  PowerSwitchState: PowerSwitchState,
  Power: Power,
  VoltageStamped: VoltageStamped,
  ColorRGBAStamped: ColorRGBAStamped,
  Brightness: Brightness,
  PowerStamped: PowerStamped,
  ElectricCurrent: ElectricCurrent,
  PowerSwitchStateStamped: PowerSwitchStateStamped,
  Voltage: Voltage,
  BrightnessStamped: BrightnessStamped,
  Heartbeat: Heartbeat,
  ElectricCurrentMeasurement: ElectricCurrentMeasurement,
  PowerMeasurement: PowerMeasurement,
  VoltageMeasurement: VoltageMeasurement,
};
