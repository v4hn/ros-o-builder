
"use strict";

let TestChar = require('./TestChar.js');
let TestUInt8FixedSizeArray16 = require('./TestUInt8FixedSizeArray16.js');
let TestUInt8 = require('./TestUInt8.js');
let Num = require('./Num.js');
let TestHeaderTwo = require('./TestHeaderTwo.js');
let TestDurationArray = require('./TestDurationArray.js');
let TestHeader = require('./TestHeader.js');
let TestTimeArray = require('./TestTimeArray.js');
let TestHeaderArray = require('./TestHeaderArray.js');

module.exports = {
  TestChar: TestChar,
  TestUInt8FixedSizeArray16: TestUInt8FixedSizeArray16,
  TestUInt8: TestUInt8,
  Num: Num,
  TestHeaderTwo: TestHeaderTwo,
  TestDurationArray: TestDurationArray,
  TestHeader: TestHeader,
  TestTimeArray: TestTimeArray,
  TestHeaderArray: TestHeaderArray,
};
