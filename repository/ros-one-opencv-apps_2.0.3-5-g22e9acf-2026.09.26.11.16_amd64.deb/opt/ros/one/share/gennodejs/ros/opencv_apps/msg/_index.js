
"use strict";

let Rect = require('./Rect.js');
let Point2DArrayStamped = require('./Point2DArrayStamped.js');
let Face = require('./Face.js');
let RectArrayStamped = require('./RectArrayStamped.js');
let Moment = require('./Moment.js');
let Point2DArray = require('./Point2DArray.js');
let MomentArrayStamped = require('./MomentArrayStamped.js');
let RotatedRectArray = require('./RotatedRectArray.js');
let Circle = require('./Circle.js');
let ContourArrayStamped = require('./ContourArrayStamped.js');
let ContourArray = require('./ContourArray.js');
let RotatedRect = require('./RotatedRect.js');
let LineArray = require('./LineArray.js');
let Line = require('./Line.js');
let CircleArrayStamped = require('./CircleArrayStamped.js');
let RotatedRectArrayStamped = require('./RotatedRectArrayStamped.js');
let MomentArray = require('./MomentArray.js');
let Point2D = require('./Point2D.js');
let Flow = require('./Flow.js');
let Contour = require('./Contour.js');
let RotatedRectStamped = require('./RotatedRectStamped.js');
let FlowArrayStamped = require('./FlowArrayStamped.js');
let RectArray = require('./RectArray.js');
let Size = require('./Size.js');
let FaceArrayStamped = require('./FaceArrayStamped.js');
let FlowArray = require('./FlowArray.js');
let CircleArray = require('./CircleArray.js');
let FaceArray = require('./FaceArray.js');
let Point2DStamped = require('./Point2DStamped.js');
let LineArrayStamped = require('./LineArrayStamped.js');
let FlowStamped = require('./FlowStamped.js');

module.exports = {
  Rect: Rect,
  Point2DArrayStamped: Point2DArrayStamped,
  Face: Face,
  RectArrayStamped: RectArrayStamped,
  Moment: Moment,
  Point2DArray: Point2DArray,
  MomentArrayStamped: MomentArrayStamped,
  RotatedRectArray: RotatedRectArray,
  Circle: Circle,
  ContourArrayStamped: ContourArrayStamped,
  ContourArray: ContourArray,
  RotatedRect: RotatedRect,
  LineArray: LineArray,
  Line: Line,
  CircleArrayStamped: CircleArrayStamped,
  RotatedRectArrayStamped: RotatedRectArrayStamped,
  MomentArray: MomentArray,
  Point2D: Point2D,
  Flow: Flow,
  Contour: Contour,
  RotatedRectStamped: RotatedRectStamped,
  FlowArrayStamped: FlowArrayStamped,
  RectArray: RectArray,
  Size: Size,
  FaceArrayStamped: FaceArrayStamped,
  FlowArray: FlowArray,
  CircleArray: CircleArray,
  FaceArray: FaceArray,
  Point2DStamped: Point2DStamped,
  LineArrayStamped: LineArrayStamped,
  FlowStamped: FlowStamped,
};
