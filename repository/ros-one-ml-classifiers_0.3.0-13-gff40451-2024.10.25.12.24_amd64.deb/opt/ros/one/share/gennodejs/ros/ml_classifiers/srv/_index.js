
"use strict";

let ClearClassifier = require('./ClearClassifier.js')
let LoadClassifier = require('./LoadClassifier.js')
let TrainClassifier = require('./TrainClassifier.js')
let AddClassData = require('./AddClassData.js')
let ClassifyData = require('./ClassifyData.js')
let SaveClassifier = require('./SaveClassifier.js')
let CreateClassifier = require('./CreateClassifier.js')

module.exports = {
  ClearClassifier: ClearClassifier,
  LoadClassifier: LoadClassifier,
  TrainClassifier: TrainClassifier,
  AddClassData: AddClassData,
  ClassifyData: ClassifyData,
  SaveClassifier: SaveClassifier,
  CreateClassifier: CreateClassifier,
};
