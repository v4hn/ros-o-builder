# generated from rosbash/env-hooks/15.rosbash.zsh.em

if [ -z "$CATKIN_ENV_HOOK_WORKSPACE" ]; then
  CATKIN_ENV_HOOK_WORKSPACE="/opt/ros/one"
fi
. "$CATKIN_ENV_HOOK_WORKSPACE/share/rosbash/roszsh"
