
"use strict";

let DiscreteStructureEstimation = require('./DiscreteStructureEstimation.js')
let LinearGaussianStructureEstimation = require('./LinearGaussianStructureEstimation.js')
let DiscreteParameterEstimation = require('./DiscreteParameterEstimation.js')
let LinearGaussianParameterEstimation = require('./LinearGaussianParameterEstimation.js')
let DiscreteQuery = require('./DiscreteQuery.js')

module.exports = {
  DiscreteStructureEstimation: DiscreteStructureEstimation,
  LinearGaussianStructureEstimation: LinearGaussianStructureEstimation,
  DiscreteParameterEstimation: DiscreteParameterEstimation,
  LinearGaussianParameterEstimation: LinearGaussianParameterEstimation,
  DiscreteQuery: DiscreteQuery,
};
