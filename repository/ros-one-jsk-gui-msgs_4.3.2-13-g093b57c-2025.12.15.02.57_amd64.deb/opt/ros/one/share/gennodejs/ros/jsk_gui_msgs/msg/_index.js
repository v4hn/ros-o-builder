
"use strict";

let MagneticField = require('./MagneticField.js');
let Gravity = require('./Gravity.js');
let TouchEvent = require('./TouchEvent.js');
let AndroidSensor = require('./AndroidSensor.js');
let Action = require('./Action.js');
let MultiTouch = require('./MultiTouch.js');
let SlackMessage = require('./SlackMessage.js');
let Tablet = require('./Tablet.js');
let DeviceSensor = require('./DeviceSensor.js');
let Touch = require('./Touch.js');
let VoiceMessage = require('./VoiceMessage.js');

module.exports = {
  MagneticField: MagneticField,
  Gravity: Gravity,
  TouchEvent: TouchEvent,
  AndroidSensor: AndroidSensor,
  Action: Action,
  MultiTouch: MultiTouch,
  SlackMessage: SlackMessage,
  Tablet: Tablet,
  DeviceSensor: DeviceSensor,
  Touch: Touch,
  VoiceMessage: VoiceMessage,
};
