
"use strict";

let Insert = require('./Insert.js');
let SerialisedMessage = require('./SerialisedMessage.js');
let StringPair = require('./StringPair.js');
let StringPairList = require('./StringPairList.js');
let StringList = require('./StringList.js');
let MoveEntriesActionGoal = require('./MoveEntriesActionGoal.js');
let MoveEntriesGoal = require('./MoveEntriesGoal.js');
let MoveEntriesActionResult = require('./MoveEntriesActionResult.js');
let MoveEntriesAction = require('./MoveEntriesAction.js');
let MoveEntriesResult = require('./MoveEntriesResult.js');
let MoveEntriesFeedback = require('./MoveEntriesFeedback.js');
let MoveEntriesActionFeedback = require('./MoveEntriesActionFeedback.js');

module.exports = {
  Insert: Insert,
  SerialisedMessage: SerialisedMessage,
  StringPair: StringPair,
  StringPairList: StringPairList,
  StringList: StringList,
  MoveEntriesActionGoal: MoveEntriesActionGoal,
  MoveEntriesGoal: MoveEntriesGoal,
  MoveEntriesActionResult: MoveEntriesActionResult,
  MoveEntriesAction: MoveEntriesAction,
  MoveEntriesResult: MoveEntriesResult,
  MoveEntriesFeedback: MoveEntriesFeedback,
  MoveEntriesActionFeedback: MoveEntriesActionFeedback,
};
