
"use strict";

let CreateClassifier = require('./CreateClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let ClearClassifier = require('./ClearClassifier.js')
let TrainClassifier = require('./TrainClassifier.js')
let AddClassData = require('./AddClassData.js')
let SaveClassifier = require('./SaveClassifier.js')
let LoadClassifier = require('./LoadClassifier.js')

module.exports = {
  CreateClassifier: CreateClassifier,
  ClassifyData: ClassifyData,
  ClearClassifier: ClearClassifier,
  TrainClassifier: TrainClassifier,
  AddClassData: AddClassData,
  SaveClassifier: SaveClassifier,
  LoadClassifier: LoadClassifier,
};
