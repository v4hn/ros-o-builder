#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rtabmap::gui" for configuration "None"
set_property(TARGET rtabmap::gui APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(rtabmap::gui PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "Qt5::PrintSupport"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librtabmap_gui.so.0.23.3"
  IMPORTED_SONAME_NONE "librtabmap_gui.so.0.23"
  )

list(APPEND _cmake_import_check_targets rtabmap::gui )
list(APPEND _cmake_import_check_files_for_rtabmap::gui "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librtabmap_gui.so.0.23.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
