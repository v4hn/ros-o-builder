#----------------------------------------------------------------
# Generated CMake target import file for configuration "None".
#----------------------------------------------------------------

# Commands may need to know the format version.
set(CMAKE_IMPORT_FILE_VERSION 1)

# Import target "rtabmap::core" for configuration "None"
set_property(TARGET rtabmap::core APPEND PROPERTY IMPORTED_CONFIGURATIONS NONE)
set_target_properties(rtabmap::core PROPERTIES
  IMPORTED_LINK_DEPENDENT_LIBRARIES_NONE "g2o::core;g2o::solver_eigen;g2o::solver_pcg;g2o::types_slam2d;g2o::types_slam3d;g2o::types_sba;g2o::solver_csparse;g2o::csparse_extension;g2o::solver_cholmod;yaml-cpp;Boost::thread;Boost::program_options;Boost::chrono;gtsam"
  IMPORTED_LOCATION_NONE "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librtabmap_core.so.0.23.3"
  IMPORTED_SONAME_NONE "librtabmap_core.so.0.23"
  )

list(APPEND _cmake_import_check_targets rtabmap::core )
list(APPEND _cmake_import_check_files_for_rtabmap::core "${_IMPORT_PREFIX}/lib/x86_64-linux-gnu/librtabmap_core.so.0.23.3" )

# Commands beyond this point should not need to know the version.
set(CMAKE_IMPORT_FILE_VERSION)
