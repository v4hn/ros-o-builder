
"use strict";

let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let FibonacciResult = require('./FibonacciResult.js');
let FibonacciAction = require('./FibonacciAction.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let AveragingGoal = require('./AveragingGoal.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let AveragingAction = require('./AveragingAction.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let AveragingResult = require('./AveragingResult.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');
let AveragingActionResult = require('./AveragingActionResult.js');

module.exports = {
  FibonacciActionGoal: FibonacciActionGoal,
  FibonacciResult: FibonacciResult,
  FibonacciAction: FibonacciAction,
  FibonacciGoal: FibonacciGoal,
  AveragingGoal: AveragingGoal,
  AveragingActionFeedback: AveragingActionFeedback,
  FibonacciActionResult: FibonacciActionResult,
  FibonacciActionFeedback: FibonacciActionFeedback,
  AveragingFeedback: AveragingFeedback,
  AveragingAction: AveragingAction,
  AveragingActionGoal: AveragingActionGoal,
  AveragingResult: AveragingResult,
  FibonacciFeedback: FibonacciFeedback,
  AveragingActionResult: AveragingActionResult,
};
