
"use strict";

let SpeechRecognitionCandidates = require('./SpeechRecognitionCandidates.js');
let Grammar = require('./Grammar.js');
let Vocabulary = require('./Vocabulary.js');
let PhraseRule = require('./PhraseRule.js');

module.exports = {
  SpeechRecognitionCandidates: SpeechRecognitionCandidates,
  Grammar: Grammar,
  Vocabulary: Vocabulary,
  PhraseRule: PhraseRule,
};
