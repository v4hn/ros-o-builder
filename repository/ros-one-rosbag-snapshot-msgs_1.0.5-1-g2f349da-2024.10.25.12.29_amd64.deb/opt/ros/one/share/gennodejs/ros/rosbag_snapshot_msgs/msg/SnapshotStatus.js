// Auto-generated. Do not edit!

// (in-package rosbag_snapshot_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let rosgraph_msgs = _finder('rosgraph_msgs');

//-----------------------------------------------------------

class SnapshotStatus {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.topics = null;
      this.enabled = null;
    }
    else {
      if (initObj.hasOwnProperty('topics')) {
        this.topics = initObj.topics
      }
      else {
        this.topics = [];
      }
      if (initObj.hasOwnProperty('enabled')) {
        this.enabled = initObj.enabled
      }
      else {
        this.enabled = false;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type SnapshotStatus
    // Serialize message field [topics]
    // Serialize the length for message field [topics]
    bufferOffset = _serializer.uint32(obj.topics.length, buffer, bufferOffset);
    obj.topics.forEach((val) => {
      bufferOffset = rosgraph_msgs.msg.TopicStatistics.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [enabled]
    bufferOffset = _serializer.bool(obj.enabled, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type SnapshotStatus
    let len;
    let data = new SnapshotStatus(null);
    // Deserialize message field [topics]
    // Deserialize array length for message field [topics]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.topics = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.topics[i] = rosgraph_msgs.msg.TopicStatistics.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [enabled]
    data.enabled = _deserializer.bool(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.topics.forEach((val) => {
      length += rosgraph_msgs.msg.TopicStatistics.getMessageSize(val);
    });
    return length + 5;
  }

  static datatype() {
    // Returns string type for a message object
    return 'rosbag_snapshot_msgs/SnapshotStatus';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'da7b0d829f1bb54c3d787d81f6befe0f';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # Describes the current status of a running 'rosbag_snapshot' node
    
    # Information about the buffer of subscribed topics
    # The period, stamp, node_pub, and dropped_msgs fields are left empty
    rosgraph_msgs/TopicStatistics[] topics
    # If true, new messages are being added to the snapshot buffers
    # If false, snapshotter is currently paused or writing to a bag file
    bool enabled
    
    ================================================================================
    MSG: rosgraph_msgs/TopicStatistics
    # name of the topic
    string topic
    
    # node id of the publisher
    string node_pub
    
    # node id of the subscriber
    string node_sub
    
    # the statistics apply to this time window
    time window_start
    time window_stop
    
    # number of messages delivered during the window
    int32 delivered_msgs
    # numbers of messages dropped during the window
    int32 dropped_msgs
    
    # traffic during the window, in bytes
    int32 traffic
    
    # mean/stddev/max period between two messages
    duration period_mean
    duration period_stddev
    duration period_max
    
    # mean/stddev/max age of the message based on the
    # timestamp in the message header. In case the
    # message does not have a header, it will be 0.
    duration stamp_age_mean
    duration stamp_age_stddev
    duration stamp_age_max
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new SnapshotStatus(null);
    if (msg.topics !== undefined) {
      resolved.topics = new Array(msg.topics.length);
      for (let i = 0; i < resolved.topics.length; ++i) {
        resolved.topics[i] = rosgraph_msgs.msg.TopicStatistics.Resolve(msg.topics[i]);
      }
    }
    else {
      resolved.topics = []
    }

    if (msg.enabled !== undefined) {
      resolved.enabled = msg.enabled;
    }
    else {
      resolved.enabled = false
    }

    return resolved;
    }
};

module.exports = SnapshotStatus;
