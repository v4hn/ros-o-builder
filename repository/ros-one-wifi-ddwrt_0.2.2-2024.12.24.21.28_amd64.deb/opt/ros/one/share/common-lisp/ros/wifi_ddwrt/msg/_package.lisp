(cl:defpackage wifi_ddwrt-msg
  (:use )
  (:export
   "<NETWORK>"
   "NETWORK"
   "<SITESURVEY>"
   "SITESURVEY"
  ))

