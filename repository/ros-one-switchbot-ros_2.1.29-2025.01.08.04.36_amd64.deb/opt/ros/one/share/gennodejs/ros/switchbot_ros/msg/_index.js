
"use strict";

let PlugMini = require('./PlugMini.js');
let DeviceArray = require('./DeviceArray.js');
let Hub2 = require('./Hub2.js');
let Bot = require('./Bot.js');
let StripLight = require('./StripLight.js');
let Meter = require('./Meter.js');
let Device = require('./Device.js');
let MeterProCO2 = require('./MeterProCO2.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');

module.exports = {
  PlugMini: PlugMini,
  DeviceArray: DeviceArray,
  Hub2: Hub2,
  Bot: Bot,
  StripLight: StripLight,
  Meter: Meter,
  Device: Device,
  MeterProCO2: MeterProCO2,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandAction: SwitchBotCommandAction,
};
