(cl:in-package zdepth_image_transport-msg)
(cl:export '(HEADER-VAL
          HEADER
          FORMAT-VAL
          FORMAT
          DATA-VAL
          DATA
          WIDTH-VAL
          WIDTH
          HEIGHT-VAL
          HEIGHT
))