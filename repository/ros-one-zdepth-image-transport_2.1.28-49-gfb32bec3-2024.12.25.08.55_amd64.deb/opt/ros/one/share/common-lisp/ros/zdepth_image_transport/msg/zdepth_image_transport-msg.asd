
(cl:in-package :asdf)

(defsystem "zdepth_image_transport-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :std_msgs-msg
)
  :components ((:file "_package")
    (:file "ZDepthImage" :depends-on ("_package_ZDepthImage"))
    (:file "_package_ZDepthImage" :depends-on ("_package"))
  ))