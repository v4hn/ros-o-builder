# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${zdepth_image_transport_DIR}/.." "msg" zdepth_image_transport_MSG_INCLUDE_DIRS UNIQUE)
set(zdepth_image_transport_MSG_DEPENDENCIES std_msgs)
