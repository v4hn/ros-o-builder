set(zdepth_image_transport_MESSAGE_FILES "msg/ZDepthImage.msg")
set(zdepth_image_transport_SERVICE_FILES "")
