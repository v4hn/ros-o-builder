
"use strict";

let Bot = require('./Bot.js');
let Meter = require('./Meter.js');
let DeviceArray = require('./DeviceArray.js');
let Hub2 = require('./Hub2.js');
let Device = require('./Device.js');
let StripLight = require('./StripLight.js');
let PlugMini = require('./PlugMini.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');

module.exports = {
  Bot: Bot,
  Meter: Meter,
  DeviceArray: DeviceArray,
  Hub2: Hub2,
  Device: Device,
  StripLight: StripLight,
  PlugMini: PlugMini,
  SwitchBotCommandAction: SwitchBotCommandAction,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
};
