
"use strict";

let SoundRequestGoal = require('./SoundRequestGoal.js');
let SoundRequestActionGoal = require('./SoundRequestActionGoal.js');
let SoundRequestResult = require('./SoundRequestResult.js');
let SoundRequestAction = require('./SoundRequestAction.js');
let SoundRequestActionResult = require('./SoundRequestActionResult.js');
let SoundRequestFeedback = require('./SoundRequestFeedback.js');
let SoundRequestActionFeedback = require('./SoundRequestActionFeedback.js');
let SoundRequest = require('./SoundRequest.js');

module.exports = {
  SoundRequestGoal: SoundRequestGoal,
  SoundRequestActionGoal: SoundRequestActionGoal,
  SoundRequestResult: SoundRequestResult,
  SoundRequestAction: SoundRequestAction,
  SoundRequestActionResult: SoundRequestActionResult,
  SoundRequestFeedback: SoundRequestFeedback,
  SoundRequestActionFeedback: SoundRequestActionFeedback,
  SoundRequest: SoundRequest,
};
