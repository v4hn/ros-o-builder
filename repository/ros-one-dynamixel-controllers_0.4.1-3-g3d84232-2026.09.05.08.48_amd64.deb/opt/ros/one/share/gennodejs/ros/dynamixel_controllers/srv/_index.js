
"use strict";

let StopController = require('./StopController.js')
let TorqueEnable = require('./TorqueEnable.js')
let SetCompliancePunch = require('./SetCompliancePunch.js')
let SetComplianceMargin = require('./SetComplianceMargin.js')
let SetComplianceSlope = require('./SetComplianceSlope.js')
let RestartController = require('./RestartController.js')
let StartController = require('./StartController.js')
let SetTorqueLimit = require('./SetTorqueLimit.js')
let SetSpeed = require('./SetSpeed.js')

module.exports = {
  StopController: StopController,
  TorqueEnable: TorqueEnable,
  SetCompliancePunch: SetCompliancePunch,
  SetComplianceMargin: SetComplianceMargin,
  SetComplianceSlope: SetComplianceSlope,
  RestartController: RestartController,
  StartController: StartController,
  SetTorqueLimit: SetTorqueLimit,
  SetSpeed: SetSpeed,
};
