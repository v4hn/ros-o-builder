// Auto-generated. Do not edit!

// (in-package view_controller_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let CameraMovement = require('./CameraMovement.js');

//-----------------------------------------------------------

class CameraTrajectory {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.trajectory = null;
      this.target_frame = null;
      this.allow_free_yaw_axis = null;
      this.mouse_interaction_mode = null;
      this.interaction_disabled = null;
      this.render_frame_by_frame = null;
      this.frames_per_second = null;
    }
    else {
      if (initObj.hasOwnProperty('trajectory')) {
        this.trajectory = initObj.trajectory
      }
      else {
        this.trajectory = [];
      }
      if (initObj.hasOwnProperty('target_frame')) {
        this.target_frame = initObj.target_frame
      }
      else {
        this.target_frame = '';
      }
      if (initObj.hasOwnProperty('allow_free_yaw_axis')) {
        this.allow_free_yaw_axis = initObj.allow_free_yaw_axis
      }
      else {
        this.allow_free_yaw_axis = false;
      }
      if (initObj.hasOwnProperty('mouse_interaction_mode')) {
        this.mouse_interaction_mode = initObj.mouse_interaction_mode
      }
      else {
        this.mouse_interaction_mode = 0;
      }
      if (initObj.hasOwnProperty('interaction_disabled')) {
        this.interaction_disabled = initObj.interaction_disabled
      }
      else {
        this.interaction_disabled = false;
      }
      if (initObj.hasOwnProperty('render_frame_by_frame')) {
        this.render_frame_by_frame = initObj.render_frame_by_frame
      }
      else {
        this.render_frame_by_frame = false;
      }
      if (initObj.hasOwnProperty('frames_per_second')) {
        this.frames_per_second = initObj.frames_per_second
      }
      else {
        this.frames_per_second = 0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type CameraTrajectory
    // Serialize message field [trajectory]
    // Serialize the length for message field [trajectory]
    bufferOffset = _serializer.uint32(obj.trajectory.length, buffer, bufferOffset);
    obj.trajectory.forEach((val) => {
      bufferOffset = CameraMovement.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [target_frame]
    bufferOffset = _serializer.string(obj.target_frame, buffer, bufferOffset);
    // Serialize message field [allow_free_yaw_axis]
    bufferOffset = _serializer.bool(obj.allow_free_yaw_axis, buffer, bufferOffset);
    // Serialize message field [mouse_interaction_mode]
    bufferOffset = _serializer.uint8(obj.mouse_interaction_mode, buffer, bufferOffset);
    // Serialize message field [interaction_disabled]
    bufferOffset = _serializer.bool(obj.interaction_disabled, buffer, bufferOffset);
    // Serialize message field [render_frame_by_frame]
    bufferOffset = _serializer.bool(obj.render_frame_by_frame, buffer, bufferOffset);
    // Serialize message field [frames_per_second]
    bufferOffset = _serializer.int8(obj.frames_per_second, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type CameraTrajectory
    let len;
    let data = new CameraTrajectory(null);
    // Deserialize message field [trajectory]
    // Deserialize array length for message field [trajectory]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.trajectory = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.trajectory[i] = CameraMovement.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [target_frame]
    data.target_frame = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [allow_free_yaw_axis]
    data.allow_free_yaw_axis = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [mouse_interaction_mode]
    data.mouse_interaction_mode = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [interaction_disabled]
    data.interaction_disabled = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [render_frame_by_frame]
    data.render_frame_by_frame = _deserializer.bool(buffer, bufferOffset);
    // Deserialize message field [frames_per_second]
    data.frames_per_second = _deserializer.int8(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    object.trajectory.forEach((val) => {
      length += CameraMovement.getMessageSize(val);
    });
    length += _getByteLength(object.target_frame);
    return length + 13;
  }

  static datatype() {
    // Returns string type for a message object
    return 'view_controller_msgs/CameraTrajectory';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c56d6e838f60da69466a74c60cf627d7';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    # This message defines a trajectory to move a camera along at and several options how to do that.  
    
    # Array of camera poses and interpolation speeds defining a trajectory.
    CameraMovement[] trajectory
    
    # Sets this as the camera attached (fixed) frame before movement.
    # An empty string will leave the attached frame unchanged.
    string target_frame
    
    # A flag indicating if the camera yaw axis is fixed to +Z of the camera attached_frame.
    # (defaults to false)
    bool allow_free_yaw_axis
    
    # The interaction style that should be activated when movement is done.
    uint8 mouse_interaction_mode
    uint8 NO_CHANGE = 0 # Leaves the control style unchanged.
    uint8 ORBIT     = 1 # Activates the Orbit-style controller.
    uint8 FPS       = 2 # Activates the First-Person-Shooter-style controller.
    
    # A flag to enable or disable user interaction.
    # (defaults to false so that interaction is enabled)
    bool interaction_disabled
    
    # If false, the duration of the animated trajectory is equal to the time passed in the real world using ros::WallTime.
    #  This can lead to an inconsistent frame rate of the published camera view images if your computer is not fast enough.
    # If true, the trajectory is rendered frame by frame. This leads to:
    #  -> a consistent frame rate of the published camera view images,
    #  -> a video with the desired trajectory duration when composed of the camera view images,
    #  -> BUT the trajectory might be slower in real time, if your computer is not fast enough. 
    # (defaults to false)
    bool render_frame_by_frame
    
    # Desired frames per second when rendering frame by frame.
    int8 frames_per_second
    
    ================================================================================
    MSG: view_controller_msgs/CameraMovement
    # This message defines where to move a camera to and at which speeds.  
    
    # The target pose definition:
    
    # The frame-relative point to move the camera to.
    geometry_msgs/PointStamped eye
    
    # The frame-relative point for the focus (or pivot for an Orbit controller).
    # The camera points into the direction of the focus point at the end of the movement.
    geometry_msgs/PointStamped focus
    
    # The frame-relative vector that maps to "up" in the view plane.
    # In other words, a vector pointing to the top of the camera, in case you want to perform roll movements.
    geometry_msgs/Vector3Stamped up
    
    
    # Defines how long the transition from the current to the target camera pose should take.
    # Movements with a negative transition_duration will be ignored.
    duration transition_duration
    
    # The interpolation speed profile to use during this movement.
    uint8 interpolation_speed
    uint8 RISING    = 0 # Speed of the camera rises smoothly - resembles the first quarter of a sinus wave.
    uint8 DECLINING = 1 # Speed of the camera declines smoothly - resembles the second quarter of a sinus wave.
    uint8 FULL      = 2 # Camera is always at full speed - depending on transition_duration.
    uint8 WAVE      = 3 # RISING and DECLINING concatenated in one movement.
    
    ================================================================================
    MSG: geometry_msgs/PointStamped
    # This represents a Point with reference coordinate frame and timestamp
    Header header
    Point point
    
    ================================================================================
    MSG: std_msgs/Header
    # Standard metadata for higher-level stamped data types.
    # This is generally used to communicate timestamped data 
    # in a particular coordinate frame.
    # 
    # sequence ID: consecutively increasing ID 
    uint32 seq
    #Two-integer timestamp that is expressed as:
    # * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')
    # * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')
    # time-handling sugar is provided by the client library
    time stamp
    #Frame this data is associated with
    string frame_id
    
    ================================================================================
    MSG: geometry_msgs/Point
    # This contains the position of a point in free space
    float64 x
    float64 y
    float64 z
    
    ================================================================================
    MSG: geometry_msgs/Vector3Stamped
    # This represents a Vector3 with reference coordinate frame and timestamp
    Header header
    Vector3 vector
    
    ================================================================================
    MSG: geometry_msgs/Vector3
    # This represents a vector in free space. 
    # It is only meant to represent a direction. Therefore, it does not
    # make sense to apply a translation to it (e.g., when applying a 
    # generic rigid transformation to a Vector3, tf2 will only apply the
    # rotation). If you want your data to be translatable too, use the
    # geometry_msgs/Point message instead.
    
    float64 x
    float64 y
    float64 z
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new CameraTrajectory(null);
    if (msg.trajectory !== undefined) {
      resolved.trajectory = new Array(msg.trajectory.length);
      for (let i = 0; i < resolved.trajectory.length; ++i) {
        resolved.trajectory[i] = CameraMovement.Resolve(msg.trajectory[i]);
      }
    }
    else {
      resolved.trajectory = []
    }

    if (msg.target_frame !== undefined) {
      resolved.target_frame = msg.target_frame;
    }
    else {
      resolved.target_frame = ''
    }

    if (msg.allow_free_yaw_axis !== undefined) {
      resolved.allow_free_yaw_axis = msg.allow_free_yaw_axis;
    }
    else {
      resolved.allow_free_yaw_axis = false
    }

    if (msg.mouse_interaction_mode !== undefined) {
      resolved.mouse_interaction_mode = msg.mouse_interaction_mode;
    }
    else {
      resolved.mouse_interaction_mode = 0
    }

    if (msg.interaction_disabled !== undefined) {
      resolved.interaction_disabled = msg.interaction_disabled;
    }
    else {
      resolved.interaction_disabled = false
    }

    if (msg.render_frame_by_frame !== undefined) {
      resolved.render_frame_by_frame = msg.render_frame_by_frame;
    }
    else {
      resolved.render_frame_by_frame = false
    }

    if (msg.frames_per_second !== undefined) {
      resolved.frames_per_second = msg.frames_per_second;
    }
    else {
      resolved.frames_per_second = 0
    }

    return resolved;
    }
};

// Constants for message
CameraTrajectory.Constants = {
  NO_CHANGE: 0,
  ORBIT: 1,
  FPS: 2,
}

module.exports = CameraTrajectory;
