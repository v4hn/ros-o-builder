
"use strict";

let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');

module.exports = {
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorGoal: FaceDetectorGoal,
};
