
"use strict";

let Digital = require('./Digital.js');
let Analog = require('./Analog.js');
let IOStates = require('./IOStates.js');
let ToolDataMsg = require('./ToolDataMsg.js');
let RobotModeDataMsg = require('./RobotModeDataMsg.js');
let RobotStateRTMsg = require('./RobotStateRTMsg.js');
let MasterboardDataMsg = require('./MasterboardDataMsg.js');

module.exports = {
  Digital: Digital,
  Analog: Analog,
  IOStates: IOStates,
  ToolDataMsg: ToolDataMsg,
  RobotModeDataMsg: RobotModeDataMsg,
  RobotStateRTMsg: RobotStateRTMsg,
  MasterboardDataMsg: MasterboardDataMsg,
};
