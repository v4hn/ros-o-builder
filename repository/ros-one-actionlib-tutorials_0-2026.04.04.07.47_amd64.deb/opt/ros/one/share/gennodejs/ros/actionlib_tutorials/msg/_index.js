
"use strict";

let FibonacciActionFeedback = require('./FibonacciActionFeedback.js');
let FibonacciResult = require('./FibonacciResult.js');
let AveragingActionResult = require('./AveragingActionResult.js');
let AveragingAction = require('./AveragingAction.js');
let AveragingActionGoal = require('./AveragingActionGoal.js');
let FibonacciActionResult = require('./FibonacciActionResult.js');
let AveragingActionFeedback = require('./AveragingActionFeedback.js');
let AveragingResult = require('./AveragingResult.js');
let AveragingFeedback = require('./AveragingFeedback.js');
let AveragingGoal = require('./AveragingGoal.js');
let FibonacciGoal = require('./FibonacciGoal.js');
let FibonacciActionGoal = require('./FibonacciActionGoal.js');
let FibonacciFeedback = require('./FibonacciFeedback.js');
let FibonacciAction = require('./FibonacciAction.js');

module.exports = {
  FibonacciActionFeedback: FibonacciActionFeedback,
  FibonacciResult: FibonacciResult,
  AveragingActionResult: AveragingActionResult,
  AveragingAction: AveragingAction,
  AveragingActionGoal: AveragingActionGoal,
  FibonacciActionResult: FibonacciActionResult,
  AveragingActionFeedback: AveragingActionFeedback,
  AveragingResult: AveragingResult,
  AveragingFeedback: AveragingFeedback,
  AveragingGoal: AveragingGoal,
  FibonacciGoal: FibonacciGoal,
  FibonacciActionGoal: FibonacciActionGoal,
  FibonacciFeedback: FibonacciFeedback,
  FibonacciAction: FibonacciAction,
};
