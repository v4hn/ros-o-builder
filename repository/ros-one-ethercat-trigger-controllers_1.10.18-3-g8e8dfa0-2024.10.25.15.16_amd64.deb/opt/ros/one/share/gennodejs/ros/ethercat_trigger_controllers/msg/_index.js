
"use strict";

let MultiWaveform = require('./MultiWaveform.js');
let MultiWaveformTransition = require('./MultiWaveformTransition.js');

module.exports = {
  MultiWaveform: MultiWaveform,
  MultiWaveformTransition: MultiWaveformTransition,
};
