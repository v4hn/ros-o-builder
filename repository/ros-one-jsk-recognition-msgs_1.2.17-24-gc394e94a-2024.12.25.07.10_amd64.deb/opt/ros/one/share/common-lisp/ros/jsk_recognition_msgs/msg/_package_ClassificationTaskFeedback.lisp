(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(STATUS-VAL
          STATUS
))