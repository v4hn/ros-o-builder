; Auto-generated. Do not edit!


(cl:in-package jsk_recognition_msgs-msg)


;//! \htmlinclude ExifGPSInfo.msg.html

(cl:defclass <ExifGPSInfo> (roslisp-msg-protocol:ros-message)
  ((gps_version_id
    :reader gps_version_id
    :initarg :gps_version_id
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 4 :element-type 'cl:fixnum :initial-element 0))
   (gps_latitude_ref
    :reader gps_latitude_ref
    :initarg :gps_latitude_ref
    :type cl:string
    :initform "")
   (gps_latitude
    :reader gps_latitude
    :initarg :gps_latitude
    :type (cl:vector cl:float)
   :initform (cl:make-array 3 :element-type 'cl:float :initial-element 0.0))
   (gps_longitude_ref
    :reader gps_longitude_ref
    :initarg :gps_longitude_ref
    :type cl:string
    :initform "")
   (gps_longitude
    :reader gps_longitude
    :initarg :gps_longitude
    :type (cl:vector cl:float)
   :initform (cl:make-array 3 :element-type 'cl:float :initial-element 0.0))
   (gps_altitude_ref
    :reader gps_altitude_ref
    :initarg :gps_altitude_ref
    :type cl:fixnum
    :initform 0)
   (gps_altitude
    :reader gps_altitude
    :initarg :gps_altitude
    :type cl:float
    :initform 0.0)
   (gps_time_stamp
    :reader gps_time_stamp
    :initarg :gps_time_stamp
    :type cl:float
    :initform 0.0)
   (gps_satellites
    :reader gps_satellites
    :initarg :gps_satellites
    :type cl:string
    :initform "")
   (gps_status
    :reader gps_status
    :initarg :gps_status
    :type cl:string
    :initform "")
   (gps_measure_mode
    :reader gps_measure_mode
    :initarg :gps_measure_mode
    :type cl:string
    :initform "")
   (gpf_sdop
    :reader gpf_sdop
    :initarg :gpf_sdop
    :type cl:float
    :initform 0.0)
   (gps_speed_ref
    :reader gps_speed_ref
    :initarg :gps_speed_ref
    :type cl:string
    :initform "")
   (gps_speed
    :reader gps_speed
    :initarg :gps_speed
    :type cl:float
    :initform 0.0)
   (gps_track_ref
    :reader gps_track_ref
    :initarg :gps_track_ref
    :type cl:string
    :initform "")
   (gps_track
    :reader gps_track
    :initarg :gps_track
    :type cl:float
    :initform 0.0)
   (gps_img_direction_ref
    :reader gps_img_direction_ref
    :initarg :gps_img_direction_ref
    :type cl:string
    :initform "")
   (gps_img_direction
    :reader gps_img_direction
    :initarg :gps_img_direction
    :type cl:float
    :initform 0.0)
   (gps_map_datum
    :reader gps_map_datum
    :initarg :gps_map_datum
    :type cl:string
    :initform "")
   (gps_dest_latitude_ref
    :reader gps_dest_latitude_ref
    :initarg :gps_dest_latitude_ref
    :type cl:string
    :initform "")
   (gps_dest_latitude
    :reader gps_dest_latitude
    :initarg :gps_dest_latitude
    :type (cl:vector cl:float)
   :initform (cl:make-array 3 :element-type 'cl:float :initial-element 0.0))
   (gps_dest_longitude_ref
    :reader gps_dest_longitude_ref
    :initarg :gps_dest_longitude_ref
    :type cl:string
    :initform "")
   (gps_dest_longitude
    :reader gps_dest_longitude
    :initarg :gps_dest_longitude
    :type (cl:vector cl:float)
   :initform (cl:make-array 3 :element-type 'cl:float :initial-element 0.0))
   (gps_dest_bearing_ref
    :reader gps_dest_bearing_ref
    :initarg :gps_dest_bearing_ref
    :type cl:string
    :initform "")
   (gps_dest_bearing
    :reader gps_dest_bearing
    :initarg :gps_dest_bearing
    :type cl:float
    :initform 0.0)
   (gps_dest_distance_ref
    :reader gps_dest_distance_ref
    :initarg :gps_dest_distance_ref
    :type cl:string
    :initform "")
   (gps_dest_distance
    :reader gps_dest_distance
    :initarg :gps_dest_distance
    :type cl:float
    :initform 0.0)
   (gps_date_stamp
    :reader gps_date_stamp
    :initarg :gps_date_stamp
    :type cl:string
    :initform "")
   (gps_differential
    :reader gps_differential
    :initarg :gps_differential
    :type cl:fixnum
    :initform 0)
   (gps_hpositioning_error
    :reader gps_hpositioning_error
    :initarg :gps_hpositioning_error
    :type cl:float
    :initform 0.0))
)

(cl:defclass ExifGPSInfo (<ExifGPSInfo>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ExifGPSInfo>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ExifGPSInfo)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_recognition_msgs-msg:<ExifGPSInfo> is deprecated: use jsk_recognition_msgs-msg:ExifGPSInfo instead.")))

(cl:ensure-generic-function 'gps_version_id-val :lambda-list '(m))
(cl:defmethod gps_version_id-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_version_id-val is deprecated.  Use jsk_recognition_msgs-msg:gps_version_id instead.")
  (gps_version_id m))

(cl:ensure-generic-function 'gps_latitude_ref-val :lambda-list '(m))
(cl:defmethod gps_latitude_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_latitude_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_latitude_ref instead.")
  (gps_latitude_ref m))

(cl:ensure-generic-function 'gps_latitude-val :lambda-list '(m))
(cl:defmethod gps_latitude-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_latitude-val is deprecated.  Use jsk_recognition_msgs-msg:gps_latitude instead.")
  (gps_latitude m))

(cl:ensure-generic-function 'gps_longitude_ref-val :lambda-list '(m))
(cl:defmethod gps_longitude_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_longitude_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_longitude_ref instead.")
  (gps_longitude_ref m))

(cl:ensure-generic-function 'gps_longitude-val :lambda-list '(m))
(cl:defmethod gps_longitude-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_longitude-val is deprecated.  Use jsk_recognition_msgs-msg:gps_longitude instead.")
  (gps_longitude m))

(cl:ensure-generic-function 'gps_altitude_ref-val :lambda-list '(m))
(cl:defmethod gps_altitude_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_altitude_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_altitude_ref instead.")
  (gps_altitude_ref m))

(cl:ensure-generic-function 'gps_altitude-val :lambda-list '(m))
(cl:defmethod gps_altitude-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_altitude-val is deprecated.  Use jsk_recognition_msgs-msg:gps_altitude instead.")
  (gps_altitude m))

(cl:ensure-generic-function 'gps_time_stamp-val :lambda-list '(m))
(cl:defmethod gps_time_stamp-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_time_stamp-val is deprecated.  Use jsk_recognition_msgs-msg:gps_time_stamp instead.")
  (gps_time_stamp m))

(cl:ensure-generic-function 'gps_satellites-val :lambda-list '(m))
(cl:defmethod gps_satellites-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_satellites-val is deprecated.  Use jsk_recognition_msgs-msg:gps_satellites instead.")
  (gps_satellites m))

(cl:ensure-generic-function 'gps_status-val :lambda-list '(m))
(cl:defmethod gps_status-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_status-val is deprecated.  Use jsk_recognition_msgs-msg:gps_status instead.")
  (gps_status m))

(cl:ensure-generic-function 'gps_measure_mode-val :lambda-list '(m))
(cl:defmethod gps_measure_mode-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_measure_mode-val is deprecated.  Use jsk_recognition_msgs-msg:gps_measure_mode instead.")
  (gps_measure_mode m))

(cl:ensure-generic-function 'gpf_sdop-val :lambda-list '(m))
(cl:defmethod gpf_sdop-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gpf_sdop-val is deprecated.  Use jsk_recognition_msgs-msg:gpf_sdop instead.")
  (gpf_sdop m))

(cl:ensure-generic-function 'gps_speed_ref-val :lambda-list '(m))
(cl:defmethod gps_speed_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_speed_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_speed_ref instead.")
  (gps_speed_ref m))

(cl:ensure-generic-function 'gps_speed-val :lambda-list '(m))
(cl:defmethod gps_speed-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_speed-val is deprecated.  Use jsk_recognition_msgs-msg:gps_speed instead.")
  (gps_speed m))

(cl:ensure-generic-function 'gps_track_ref-val :lambda-list '(m))
(cl:defmethod gps_track_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_track_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_track_ref instead.")
  (gps_track_ref m))

(cl:ensure-generic-function 'gps_track-val :lambda-list '(m))
(cl:defmethod gps_track-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_track-val is deprecated.  Use jsk_recognition_msgs-msg:gps_track instead.")
  (gps_track m))

(cl:ensure-generic-function 'gps_img_direction_ref-val :lambda-list '(m))
(cl:defmethod gps_img_direction_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_img_direction_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_img_direction_ref instead.")
  (gps_img_direction_ref m))

(cl:ensure-generic-function 'gps_img_direction-val :lambda-list '(m))
(cl:defmethod gps_img_direction-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_img_direction-val is deprecated.  Use jsk_recognition_msgs-msg:gps_img_direction instead.")
  (gps_img_direction m))

(cl:ensure-generic-function 'gps_map_datum-val :lambda-list '(m))
(cl:defmethod gps_map_datum-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_map_datum-val is deprecated.  Use jsk_recognition_msgs-msg:gps_map_datum instead.")
  (gps_map_datum m))

(cl:ensure-generic-function 'gps_dest_latitude_ref-val :lambda-list '(m))
(cl:defmethod gps_dest_latitude_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_latitude_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_latitude_ref instead.")
  (gps_dest_latitude_ref m))

(cl:ensure-generic-function 'gps_dest_latitude-val :lambda-list '(m))
(cl:defmethod gps_dest_latitude-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_latitude-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_latitude instead.")
  (gps_dest_latitude m))

(cl:ensure-generic-function 'gps_dest_longitude_ref-val :lambda-list '(m))
(cl:defmethod gps_dest_longitude_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_longitude_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_longitude_ref instead.")
  (gps_dest_longitude_ref m))

(cl:ensure-generic-function 'gps_dest_longitude-val :lambda-list '(m))
(cl:defmethod gps_dest_longitude-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_longitude-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_longitude instead.")
  (gps_dest_longitude m))

(cl:ensure-generic-function 'gps_dest_bearing_ref-val :lambda-list '(m))
(cl:defmethod gps_dest_bearing_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_bearing_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_bearing_ref instead.")
  (gps_dest_bearing_ref m))

(cl:ensure-generic-function 'gps_dest_bearing-val :lambda-list '(m))
(cl:defmethod gps_dest_bearing-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_bearing-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_bearing instead.")
  (gps_dest_bearing m))

(cl:ensure-generic-function 'gps_dest_distance_ref-val :lambda-list '(m))
(cl:defmethod gps_dest_distance_ref-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_distance_ref-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_distance_ref instead.")
  (gps_dest_distance_ref m))

(cl:ensure-generic-function 'gps_dest_distance-val :lambda-list '(m))
(cl:defmethod gps_dest_distance-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_dest_distance-val is deprecated.  Use jsk_recognition_msgs-msg:gps_dest_distance instead.")
  (gps_dest_distance m))

(cl:ensure-generic-function 'gps_date_stamp-val :lambda-list '(m))
(cl:defmethod gps_date_stamp-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_date_stamp-val is deprecated.  Use jsk_recognition_msgs-msg:gps_date_stamp instead.")
  (gps_date_stamp m))

(cl:ensure-generic-function 'gps_differential-val :lambda-list '(m))
(cl:defmethod gps_differential-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_differential-val is deprecated.  Use jsk_recognition_msgs-msg:gps_differential instead.")
  (gps_differential m))

(cl:ensure-generic-function 'gps_hpositioning_error-val :lambda-list '(m))
(cl:defmethod gps_hpositioning_error-val ((m <ExifGPSInfo>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_hpositioning_error-val is deprecated.  Use jsk_recognition_msgs-msg:gps_hpositioning_error instead.")
  (gps_hpositioning_error m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ExifGPSInfo>) ostream)
  "Serializes a message object of type '<ExifGPSInfo>"
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'gps_version_id))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_latitude_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_latitude_ref))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'gps_latitude))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_longitude_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_longitude_ref))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'gps_longitude))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'gps_altitude_ref)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_altitude))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_time_stamp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_satellites))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_satellites))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_status))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_status))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_measure_mode))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_measure_mode))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gpf_sdop))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_speed_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_speed_ref))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_speed))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_track_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_track_ref))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_track))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_img_direction_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_img_direction_ref))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_img_direction))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_map_datum))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_map_datum))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_dest_latitude_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_dest_latitude_ref))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'gps_dest_latitude))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_dest_longitude_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_dest_longitude_ref))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'gps_dest_longitude))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_dest_bearing_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_dest_bearing_ref))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_dest_bearing))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_dest_distance_ref))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_dest_distance_ref))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_dest_distance))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'gps_date_stamp))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'gps_date_stamp))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'gps_differential)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'gps_differential)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gps_hpositioning_error))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ExifGPSInfo>) istream)
  "Deserializes a message object of type '<ExifGPSInfo>"
  (cl:setf (cl:slot-value msg 'gps_version_id) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'gps_version_id)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_latitude_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_latitude_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'gps_latitude) (cl:make-array 3))
  (cl:let ((vals (cl:slot-value msg 'gps_latitude)))
    (cl:dotimes (i 3)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_longitude_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_longitude_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'gps_longitude) (cl:make-array 3))
  (cl:let ((vals (cl:slot-value msg 'gps_longitude)))
    (cl:dotimes (i 3)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'gps_altitude_ref)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_altitude) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_time_stamp) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_satellites) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_satellites) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_status) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_status) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_measure_mode) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_measure_mode) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gpf_sdop) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_speed_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_speed_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_speed) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_track_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_track_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_track) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_img_direction_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_img_direction_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_img_direction) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_map_datum) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_map_datum) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_dest_latitude_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_dest_latitude_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'gps_dest_latitude) (cl:make-array 3))
  (cl:let ((vals (cl:slot-value msg 'gps_dest_latitude)))
    (cl:dotimes (i 3)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_dest_longitude_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_dest_longitude_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'gps_dest_longitude) (cl:make-array 3))
  (cl:let ((vals (cl:slot-value msg 'gps_dest_longitude)))
    (cl:dotimes (i 3)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_dest_bearing_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_dest_bearing_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_dest_bearing) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_dest_distance_ref) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_dest_distance_ref) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_dest_distance) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'gps_date_stamp) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'gps_date_stamp) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'gps_differential)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'gps_differential)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gps_hpositioning_error) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ExifGPSInfo>)))
  "Returns string type for a message object of type '<ExifGPSInfo>"
  "jsk_recognition_msgs/ExifGPSInfo")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ExifGPSInfo)))
  "Returns string type for a message object of type 'ExifGPSInfo"
  "jsk_recognition_msgs/ExifGPSInfo")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ExifGPSInfo>)))
  "Returns md5sum for a message object of type '<ExifGPSInfo>"
  "4d78b4fbebd5b498dabfce0a45f72762")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ExifGPSInfo)))
  "Returns md5sum for a message object of type 'ExifGPSInfo"
  "4d78b4fbebd5b498dabfce0a45f72762")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ExifGPSInfo>)))
  "Returns full string definition for message of type '<ExifGPSInfo>"
  (cl:format cl:nil "#~%# https://exiftool.org/TagNames/GPS.html~%#~%# Tag ID	Tag Name	Writable	Values / Notes~%# 0x0000	GPSVersionID	int8u[4]:~%uint8[4] gps_version_id~%# 0x0001	GPSLatitudeRef	string[2]	(tags 0x0001-0x0006 used for camera location according to MWG 2.0. ExifTool will also accept a number when writing GPSLatitudeRef, positive for north latitudes or negative for south, or a string containing N, North, S or South)~%# 						'N' = North~%# 						'S' = South~%string gps_latitude_ref~%# 0x0002	GPSLatitude	rational64u[3]~%float64[3] gps_latitude~%# 0x0003	GPSLongitudeRef	string[2]	(ExifTool will also accept a number when writing this tag, positive for east longitudes or negative for west, or a string containing E, East, W or West)~%# 						'E' = East~%# 						'W' = West~%string gps_longitude_ref~%# 0x0004	GPSLongitude	rational64u[3]~%float64[3] gps_longitude~%# 0x0005	GPSAltitudeRef	int8u	(ExifTool will also accept number when writing this tag, with negative numbers indicating below sea level)~%uint8 gps_altitude_ref~%# 						0 = Above Sea Level~%# 						1 = Below Sea Level~%# 0x0006	GPSAltitude	rational64u~%float64 gps_altitude~%# 0x0007	GPSTimeStamp	rational64u[3]	(UTC time of GPS fix. When writing, date is stripped off if present, and time is adjusted to UTC if it includes a timezone)~%float64 gps_time_stamp~%# 0x0008	GPSSatellites	string~%string gps_satellites~%# 0x0009	GPSStatus	string[2]~%# 						'A' = Measurement Active~%# 						'V' = Measurement Void~%string gps_status~%# 0x000a	GPSMeasureMode	string[2]~%# 						2 = 2-Dimensional Measurement~%# 						3 = 3-Dimensional Measurement~%string gps_measure_mode~%# 0x000b	GPSDOP	rational64u~%float64 gpf_sdop~%# 0x000c	GPSSpeedRef	string[2]~%# 						'K' = km/h~%# 						'M' = mph~%# 						'N' = knots~%string gps_speed_ref~%# 0x000d	GPSSpeed	rational64u~%float64 gps_speed~%# 0x000e	GPSTrackRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_track_ref~%# 0x000f	GPSTrack	rational64u~%float64 gps_track~%# 0x0010	GPSImgDirectionRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_img_direction_ref~%# 0x0011	GPSImgDirection	rational64u~%float64 gps_img_direction~%# 0x0012	GPSMapDatum	string~%string gps_map_datum~%# 0x0013	GPSDestLatitudeRef	string[2]	(tags 0x0013-0x001a used for subject location according to MWG 2.0)~%# 						'N' = North~%# 						'S' = South~%string gps_dest_latitude_ref~%# 0x0014	GPSDestLatitude	rational64u[3]~%float64[3] gps_dest_latitude~%# 0x0015	GPSDestLongitudeRef	string[2]~%# 						'E' = East~%# 						'W' = West~%string gps_dest_longitude_ref~%# 0x0016	GPSDestLongitude	rational64u[3]~%float64[3] gps_dest_longitude~%# 0x0017	GPSDestBearingRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_dest_bearing_ref~%# 0x0018	GPSDestBearing	rational64u~%float64 gps_dest_bearing~%# 0x0019	GPSDestDistanceRef	string[2]~%# 						'K' = Kilometers~%# 						'M' = Miles~%# 						'N' = Nautical Miles~%string gps_dest_distance_ref~%# 0x001a	GPSDestDistance	rational64u~%float64 gps_dest_distance~%# 0x001b	GPSProcessingMethod	undef	(values of \"GPS\", \"CELLID\", \"WLAN\" or \"MANUAL\" by the EXIF spec.)~%# 0x001c	GPSAreaInformation	undef~%# 0x001d	GPSDateStamp	string[11]	(when writing, time is stripped off if present, after adjusting date/time to UTC if time includes a timezone. Format is YYYY:mm:dd)~%string gps_date_stamp~%# 0x001e	GPSDifferential	int16u~%# 						0 = No Correction~%# 						1 = Differential Corrected~%uint16 gps_differential~%# 0x001f	GPSHPositioningError	rational64u~%float64 gps_hpositioning_error~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ExifGPSInfo)))
  "Returns full string definition for message of type 'ExifGPSInfo"
  (cl:format cl:nil "#~%# https://exiftool.org/TagNames/GPS.html~%#~%# Tag ID	Tag Name	Writable	Values / Notes~%# 0x0000	GPSVersionID	int8u[4]:~%uint8[4] gps_version_id~%# 0x0001	GPSLatitudeRef	string[2]	(tags 0x0001-0x0006 used for camera location according to MWG 2.0. ExifTool will also accept a number when writing GPSLatitudeRef, positive for north latitudes or negative for south, or a string containing N, North, S or South)~%# 						'N' = North~%# 						'S' = South~%string gps_latitude_ref~%# 0x0002	GPSLatitude	rational64u[3]~%float64[3] gps_latitude~%# 0x0003	GPSLongitudeRef	string[2]	(ExifTool will also accept a number when writing this tag, positive for east longitudes or negative for west, or a string containing E, East, W or West)~%# 						'E' = East~%# 						'W' = West~%string gps_longitude_ref~%# 0x0004	GPSLongitude	rational64u[3]~%float64[3] gps_longitude~%# 0x0005	GPSAltitudeRef	int8u	(ExifTool will also accept number when writing this tag, with negative numbers indicating below sea level)~%uint8 gps_altitude_ref~%# 						0 = Above Sea Level~%# 						1 = Below Sea Level~%# 0x0006	GPSAltitude	rational64u~%float64 gps_altitude~%# 0x0007	GPSTimeStamp	rational64u[3]	(UTC time of GPS fix. When writing, date is stripped off if present, and time is adjusted to UTC if it includes a timezone)~%float64 gps_time_stamp~%# 0x0008	GPSSatellites	string~%string gps_satellites~%# 0x0009	GPSStatus	string[2]~%# 						'A' = Measurement Active~%# 						'V' = Measurement Void~%string gps_status~%# 0x000a	GPSMeasureMode	string[2]~%# 						2 = 2-Dimensional Measurement~%# 						3 = 3-Dimensional Measurement~%string gps_measure_mode~%# 0x000b	GPSDOP	rational64u~%float64 gpf_sdop~%# 0x000c	GPSSpeedRef	string[2]~%# 						'K' = km/h~%# 						'M' = mph~%# 						'N' = knots~%string gps_speed_ref~%# 0x000d	GPSSpeed	rational64u~%float64 gps_speed~%# 0x000e	GPSTrackRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_track_ref~%# 0x000f	GPSTrack	rational64u~%float64 gps_track~%# 0x0010	GPSImgDirectionRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_img_direction_ref~%# 0x0011	GPSImgDirection	rational64u~%float64 gps_img_direction~%# 0x0012	GPSMapDatum	string~%string gps_map_datum~%# 0x0013	GPSDestLatitudeRef	string[2]	(tags 0x0013-0x001a used for subject location according to MWG 2.0)~%# 						'N' = North~%# 						'S' = South~%string gps_dest_latitude_ref~%# 0x0014	GPSDestLatitude	rational64u[3]~%float64[3] gps_dest_latitude~%# 0x0015	GPSDestLongitudeRef	string[2]~%# 						'E' = East~%# 						'W' = West~%string gps_dest_longitude_ref~%# 0x0016	GPSDestLongitude	rational64u[3]~%float64[3] gps_dest_longitude~%# 0x0017	GPSDestBearingRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_dest_bearing_ref~%# 0x0018	GPSDestBearing	rational64u~%float64 gps_dest_bearing~%# 0x0019	GPSDestDistanceRef	string[2]~%# 						'K' = Kilometers~%# 						'M' = Miles~%# 						'N' = Nautical Miles~%string gps_dest_distance_ref~%# 0x001a	GPSDestDistance	rational64u~%float64 gps_dest_distance~%# 0x001b	GPSProcessingMethod	undef	(values of \"GPS\", \"CELLID\", \"WLAN\" or \"MANUAL\" by the EXIF spec.)~%# 0x001c	GPSAreaInformation	undef~%# 0x001d	GPSDateStamp	string[11]	(when writing, time is stripped off if present, after adjusting date/time to UTC if time includes a timezone. Format is YYYY:mm:dd)~%string gps_date_stamp~%# 0x001e	GPSDifferential	int16u~%# 						0 = No Correction~%# 						1 = Differential Corrected~%uint16 gps_differential~%# 0x001f	GPSHPositioningError	rational64u~%float64 gps_hpositioning_error~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ExifGPSInfo>))
  (cl:+ 0
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'gps_version_id) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     4 (cl:length (cl:slot-value msg 'gps_latitude_ref))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'gps_latitude) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4 (cl:length (cl:slot-value msg 'gps_longitude_ref))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'gps_longitude) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     1
     8
     8
     4 (cl:length (cl:slot-value msg 'gps_satellites))
     4 (cl:length (cl:slot-value msg 'gps_status))
     4 (cl:length (cl:slot-value msg 'gps_measure_mode))
     8
     4 (cl:length (cl:slot-value msg 'gps_speed_ref))
     8
     4 (cl:length (cl:slot-value msg 'gps_track_ref))
     8
     4 (cl:length (cl:slot-value msg 'gps_img_direction_ref))
     8
     4 (cl:length (cl:slot-value msg 'gps_map_datum))
     4 (cl:length (cl:slot-value msg 'gps_dest_latitude_ref))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'gps_dest_latitude) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4 (cl:length (cl:slot-value msg 'gps_dest_longitude_ref))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'gps_dest_longitude) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4 (cl:length (cl:slot-value msg 'gps_dest_bearing_ref))
     8
     4 (cl:length (cl:slot-value msg 'gps_dest_distance_ref))
     8
     4 (cl:length (cl:slot-value msg 'gps_date_stamp))
     2
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ExifGPSInfo>))
  "Converts a ROS message object to a list"
  (cl:list 'ExifGPSInfo
    (cl:cons ':gps_version_id (gps_version_id msg))
    (cl:cons ':gps_latitude_ref (gps_latitude_ref msg))
    (cl:cons ':gps_latitude (gps_latitude msg))
    (cl:cons ':gps_longitude_ref (gps_longitude_ref msg))
    (cl:cons ':gps_longitude (gps_longitude msg))
    (cl:cons ':gps_altitude_ref (gps_altitude_ref msg))
    (cl:cons ':gps_altitude (gps_altitude msg))
    (cl:cons ':gps_time_stamp (gps_time_stamp msg))
    (cl:cons ':gps_satellites (gps_satellites msg))
    (cl:cons ':gps_status (gps_status msg))
    (cl:cons ':gps_measure_mode (gps_measure_mode msg))
    (cl:cons ':gpf_sdop (gpf_sdop msg))
    (cl:cons ':gps_speed_ref (gps_speed_ref msg))
    (cl:cons ':gps_speed (gps_speed msg))
    (cl:cons ':gps_track_ref (gps_track_ref msg))
    (cl:cons ':gps_track (gps_track msg))
    (cl:cons ':gps_img_direction_ref (gps_img_direction_ref msg))
    (cl:cons ':gps_img_direction (gps_img_direction msg))
    (cl:cons ':gps_map_datum (gps_map_datum msg))
    (cl:cons ':gps_dest_latitude_ref (gps_dest_latitude_ref msg))
    (cl:cons ':gps_dest_latitude (gps_dest_latitude msg))
    (cl:cons ':gps_dest_longitude_ref (gps_dest_longitude_ref msg))
    (cl:cons ':gps_dest_longitude (gps_dest_longitude msg))
    (cl:cons ':gps_dest_bearing_ref (gps_dest_bearing_ref msg))
    (cl:cons ':gps_dest_bearing (gps_dest_bearing msg))
    (cl:cons ':gps_dest_distance_ref (gps_dest_distance_ref msg))
    (cl:cons ':gps_dest_distance (gps_dest_distance msg))
    (cl:cons ':gps_date_stamp (gps_date_stamp msg))
    (cl:cons ':gps_differential (gps_differential msg))
    (cl:cons ':gps_hpositioning_error (gps_hpositioning_error msg))
))
