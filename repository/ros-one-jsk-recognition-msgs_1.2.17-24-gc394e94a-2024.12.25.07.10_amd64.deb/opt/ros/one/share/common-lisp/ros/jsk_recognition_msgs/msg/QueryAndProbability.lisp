; Auto-generated. Do not edit!


(cl:in-package jsk_recognition_msgs-msg)


;//! \htmlinclude QueryAndProbability.msg.html

(cl:defclass <QueryAndProbability> (roslisp-msg-protocol:ros-message)
  ((query
    :reader query
    :initarg :query
    :type cl:string
    :initform "")
   (probability
    :reader probability
    :initarg :probability
    :type cl:float
    :initform 0.0))
)

(cl:defclass QueryAndProbability (<QueryAndProbability>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <QueryAndProbability>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'QueryAndProbability)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_recognition_msgs-msg:<QueryAndProbability> is deprecated: use jsk_recognition_msgs-msg:QueryAndProbability instead.")))

(cl:ensure-generic-function 'query-val :lambda-list '(m))
(cl:defmethod query-val ((m <QueryAndProbability>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:query-val is deprecated.  Use jsk_recognition_msgs-msg:query instead.")
  (query m))

(cl:ensure-generic-function 'probability-val :lambda-list '(m))
(cl:defmethod probability-val ((m <QueryAndProbability>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:probability-val is deprecated.  Use jsk_recognition_msgs-msg:probability instead.")
  (probability m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <QueryAndProbability>) ostream)
  "Serializes a message object of type '<QueryAndProbability>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'query))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'query))
  (cl:let ((bits (roslisp-utils:encode-single-float-bits (cl:slot-value msg 'probability))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <QueryAndProbability>) istream)
  "Deserializes a message object of type '<QueryAndProbability>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'query) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'query) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'probability) (roslisp-utils:decode-single-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<QueryAndProbability>)))
  "Returns string type for a message object of type '<QueryAndProbability>"
  "jsk_recognition_msgs/QueryAndProbability")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'QueryAndProbability)))
  "Returns string type for a message object of type 'QueryAndProbability"
  "jsk_recognition_msgs/QueryAndProbability")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<QueryAndProbability>)))
  "Returns md5sum for a message object of type '<QueryAndProbability>"
  "32c813a28098765a725fe0e559bc6983")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'QueryAndProbability)))
  "Returns md5sum for a message object of type 'QueryAndProbability"
  "32c813a28098765a725fe0e559bc6983")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<QueryAndProbability>)))
  "Returns full string definition for message of type '<QueryAndProbability>"
  (cl:format cl:nil "string query~%float32 probability~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'QueryAndProbability)))
  "Returns full string definition for message of type 'QueryAndProbability"
  (cl:format cl:nil "string query~%float32 probability~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <QueryAndProbability>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'query))
     4
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <QueryAndProbability>))
  "Converts a ROS message object to a list"
  (cl:list 'QueryAndProbability
    (cl:cons ':query (query msg))
    (cl:cons ':probability (probability msg))
))
