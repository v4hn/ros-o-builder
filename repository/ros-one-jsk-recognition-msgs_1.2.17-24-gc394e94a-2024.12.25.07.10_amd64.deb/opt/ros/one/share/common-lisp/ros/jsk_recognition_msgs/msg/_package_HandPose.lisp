(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(HAND_SCORE-VAL
          HAND_SCORE
          FINGER_NAMES-VAL
          FINGER_NAMES
          POSES-VAL
          POSES
          POINT_SCORES-VAL
          POINT_SCORES
))