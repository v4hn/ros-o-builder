(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(RESULT-VAL
          RESULT
          DONE-VAL
          DONE
))