(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(IMAGE-VAL
          IMAGE
          RESULT-VAL
          RESULT
))