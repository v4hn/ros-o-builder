; Auto-generated. Do not edit!


(cl:in-package jsk_recognition_msgs-msg)


;//! \htmlinclude QuestionAndAnswerText.msg.html

(cl:defclass <QuestionAndAnswerText> (roslisp-msg-protocol:ros-message)
  ((question
    :reader question
    :initarg :question
    :type cl:string
    :initform "")
   (answer
    :reader answer
    :initarg :answer
    :type cl:string
    :initform ""))
)

(cl:defclass QuestionAndAnswerText (<QuestionAndAnswerText>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <QuestionAndAnswerText>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'QuestionAndAnswerText)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_recognition_msgs-msg:<QuestionAndAnswerText> is deprecated: use jsk_recognition_msgs-msg:QuestionAndAnswerText instead.")))

(cl:ensure-generic-function 'question-val :lambda-list '(m))
(cl:defmethod question-val ((m <QuestionAndAnswerText>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:question-val is deprecated.  Use jsk_recognition_msgs-msg:question instead.")
  (question m))

(cl:ensure-generic-function 'answer-val :lambda-list '(m))
(cl:defmethod answer-val ((m <QuestionAndAnswerText>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:answer-val is deprecated.  Use jsk_recognition_msgs-msg:answer instead.")
  (answer m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <QuestionAndAnswerText>) ostream)
  "Serializes a message object of type '<QuestionAndAnswerText>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'question))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'question))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'answer))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'answer))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <QuestionAndAnswerText>) istream)
  "Deserializes a message object of type '<QuestionAndAnswerText>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'question) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'question) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'answer) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'answer) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<QuestionAndAnswerText>)))
  "Returns string type for a message object of type '<QuestionAndAnswerText>"
  "jsk_recognition_msgs/QuestionAndAnswerText")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'QuestionAndAnswerText)))
  "Returns string type for a message object of type 'QuestionAndAnswerText"
  "jsk_recognition_msgs/QuestionAndAnswerText")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<QuestionAndAnswerText>)))
  "Returns md5sum for a message object of type '<QuestionAndAnswerText>"
  "a27d8629aeefd2b315942fe4a74ab143")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'QuestionAndAnswerText)))
  "Returns md5sum for a message object of type 'QuestionAndAnswerText"
  "a27d8629aeefd2b315942fe4a74ab143")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<QuestionAndAnswerText>)))
  "Returns full string definition for message of type '<QuestionAndAnswerText>"
  (cl:format cl:nil "string question~%string answer~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'QuestionAndAnswerText)))
  "Returns full string definition for message of type 'QuestionAndAnswerText"
  (cl:format cl:nil "string question~%string answer~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <QuestionAndAnswerText>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'question))
     4 (cl:length (cl:slot-value msg 'answer))
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <QuestionAndAnswerText>))
  "Converts a ROS message object to a list"
  (cl:list 'QuestionAndAnswerText
    (cl:cons ':question (question msg))
    (cl:cons ':answer (answer msg))
))
