(cl:in-package jsk_recognition_msgs-msg)
(cl:export '(QUERY-VAL
          QUERY
          PROBABILITY-VAL
          PROBABILITY
))