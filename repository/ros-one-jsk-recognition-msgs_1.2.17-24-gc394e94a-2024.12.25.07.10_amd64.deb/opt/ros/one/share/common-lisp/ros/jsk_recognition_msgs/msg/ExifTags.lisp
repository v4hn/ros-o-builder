; Auto-generated. Do not edit!


(cl:in-package jsk_recognition_msgs-msg)


;//! \htmlinclude ExifTags.msg.html

(cl:defclass <ExifTags> (roslisp-msg-protocol:ros-message)
  ((interop_index
    :reader interop_index
    :initarg :interop_index
    :type cl:string
    :initform "")
   (image_width
    :reader image_width
    :initarg :image_width
    :type cl:integer
    :initform 0)
   (image_height
    :reader image_height
    :initarg :image_height
    :type cl:integer
    :initform 0)
   (bits_per_sample
    :reader bits_per_sample
    :initarg :bits_per_sample
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0))
   (photometric_interpretation
    :reader photometric_interpretation
    :initarg :photometric_interpretation
    :type cl:fixnum
    :initform 0)
   (image_description
    :reader image_description
    :initarg :image_description
    :type cl:string
    :initform "")
   (make
    :reader make
    :initarg :make
    :type cl:string
    :initform "")
   (model
    :reader model
    :initarg :model
    :type cl:string
    :initform "")
   (strip_offsets
    :reader strip_offsets
    :initarg :strip_offsets
    :type cl:integer
    :initform 0)
   (orientation
    :reader orientation
    :initarg :orientation
    :type cl:fixnum
    :initform 0)
   (samples_per_pixel
    :reader samples_per_pixel
    :initarg :samples_per_pixel
    :type cl:fixnum
    :initform 0)
   (rows_per_strip
    :reader rows_per_strip
    :initarg :rows_per_strip
    :type cl:integer
    :initform 0)
   (strip_byte_counts
    :reader strip_byte_counts
    :initarg :strip_byte_counts
    :type cl:integer
    :initform 0)
   (x_resolution
    :reader x_resolution
    :initarg :x_resolution
    :type cl:float
    :initform 0.0)
   (y_resolution
    :reader y_resolution
    :initarg :y_resolution
    :type cl:float
    :initform 0.0)
   (planar_configuration
    :reader planar_configuration
    :initarg :planar_configuration
    :type cl:fixnum
    :initform 0)
   (resolution_unit
    :reader resolution_unit
    :initarg :resolution_unit
    :type cl:fixnum
    :initform 0)
   (transfer_function
    :reader transfer_function
    :initarg :transfer_function
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 768 :element-type 'cl:fixnum :initial-element 0))
   (software
    :reader software
    :initarg :software
    :type cl:string
    :initform "")
   (date_time
    :reader date_time
    :initarg :date_time
    :type cl:string
    :initform "")
   (artist
    :reader artist
    :initarg :artist
    :type cl:string
    :initform "")
   (white_point
    :reader white_point
    :initarg :white_point
    :type (cl:vector cl:float)
   :initform (cl:make-array 2 :element-type 'cl:float :initial-element 0.0))
   (primary_chromaticities
    :reader primary_chromaticities
    :initarg :primary_chromaticities
    :type (cl:vector cl:float)
   :initform (cl:make-array 6 :element-type 'cl:float :initial-element 0.0))
   (tile_width
    :reader tile_width
    :initarg :tile_width
    :type cl:integer
    :initform 0)
   (tile_length
    :reader tile_length
    :initarg :tile_length
    :type cl:integer
    :initform 0)
   (jpg_from_raw_start
    :reader jpg_from_raw_start
    :initarg :jpg_from_raw_start
    :type cl:integer
    :initform 0)
   (jpg_from_raw_length
    :reader jpg_from_raw_length
    :initarg :jpg_from_raw_length
    :type cl:integer
    :initform 0)
   (ycb_cr_Coefficients
    :reader ycb_cr_Coefficients
    :initarg :ycb_cr_Coefficients
    :type (cl:vector cl:float)
   :initform (cl:make-array 3 :element-type 'cl:float :initial-element 0.0))
   (ycb_cr_sub_sampling
    :reader ycb_cr_sub_sampling
    :initarg :ycb_cr_sub_sampling
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 2 :element-type 'cl:fixnum :initial-element 0))
   (ycb_cr_positioning
    :reader ycb_cr_positioning
    :initarg :ycb_cr_positioning
    :type cl:fixnum
    :initform 0)
   (reference_black_white
    :reader reference_black_white
    :initarg :reference_black_white
    :type (cl:vector cl:float)
   :initform (cl:make-array 6 :element-type 'cl:float :initial-element 0.0))
   (copyright
    :reader copyright
    :initarg :copyright
    :type cl:string
    :initform "")
   (exposure_time
    :reader exposure_time
    :initarg :exposure_time
    :type cl:float
    :initform 0.0)
   (f_number
    :reader f_number
    :initarg :f_number
    :type cl:float
    :initform 0.0)
   (exposure_program
    :reader exposure_program
    :initarg :exposure_program
    :type cl:fixnum
    :initform 0)
   (gps_info
    :reader gps_info
    :initarg :gps_info
    :type jsk_recognition_msgs-msg:ExifGPSInfo
    :initform (cl:make-instance 'jsk_recognition_msgs-msg:ExifGPSInfo))
   (iso
    :reader iso
    :initarg :iso
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0))
   (sensitivity_type
    :reader sensitivity_type
    :initarg :sensitivity_type
    :type cl:fixnum
    :initform 0)
   (standard_output_sensitivity
    :reader standard_output_sensitivity
    :initarg :standard_output_sensitivity
    :type cl:integer
    :initform 0)
   (recommended_exposure_index
    :reader recommended_exposure_index
    :initarg :recommended_exposure_index
    :type cl:integer
    :initform 0)
   (iso_speed
    :reader iso_speed
    :initarg :iso_speed
    :type cl:integer
    :initform 0)
   (iso_speed_latitudeyyy
    :reader iso_speed_latitudeyyy
    :initarg :iso_speed_latitudeyyy
    :type cl:integer
    :initform 0)
   (iso_speed_latitudezzz
    :reader iso_speed_latitudezzz
    :initarg :iso_speed_latitudezzz
    :type cl:integer
    :initform 0)
   (exif_version
    :reader exif_version
    :initarg :exif_version
    :type cl:string
    :initform "")
   (date_time_original
    :reader date_time_original
    :initarg :date_time_original
    :type cl:string
    :initform "")
   (date_time_digitized
    :reader date_time_digitized
    :initarg :date_time_digitized
    :type cl:string
    :initform "")
   (offset_time
    :reader offset_time
    :initarg :offset_time
    :type cl:string
    :initform "")
   (offset_time_original
    :reader offset_time_original
    :initarg :offset_time_original
    :type cl:string
    :initform "")
   (offset_time_digitized
    :reader offset_time_digitized
    :initarg :offset_time_digitized
    :type cl:string
    :initform "")
   (components_configuration
    :reader components_configuration
    :initarg :components_configuration
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 4 :element-type 'cl:fixnum :initial-element 0))
   (compressed_bits_per_pixel
    :reader compressed_bits_per_pixel
    :initarg :compressed_bits_per_pixel
    :type cl:float
    :initform 0.0)
   (shutter_speed_value
    :reader shutter_speed_value
    :initarg :shutter_speed_value
    :type cl:float
    :initform 0.0)
   (aperture_value
    :reader aperture_value
    :initarg :aperture_value
    :type cl:float
    :initform 0.0)
   (brightness_value
    :reader brightness_value
    :initarg :brightness_value
    :type cl:float
    :initform 0.0)
   (exposure_bias_value
    :reader exposure_bias_value
    :initarg :exposure_bias_value
    :type cl:float
    :initform 0.0)
   (max_aperture_value
    :reader max_aperture_value
    :initarg :max_aperture_value
    :type cl:float
    :initform 0.0)
   (subject_distance
    :reader subject_distance
    :initarg :subject_distance
    :type cl:float
    :initform 0.0)
   (metering_mode
    :reader metering_mode
    :initarg :metering_mode
    :type cl:fixnum
    :initform 0)
   (light_source
    :reader light_source
    :initarg :light_source
    :type cl:fixnum
    :initform 0)
   (flash
    :reader flash
    :initarg :flash
    :type cl:fixnum
    :initform 0)
   (focal_length
    :reader focal_length
    :initarg :focal_length
    :type cl:float
    :initform 0.0)
   (subject_area
    :reader subject_area
    :initarg :subject_area
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 0 :element-type 'cl:fixnum :initial-element 0))
   (user_comment
    :reader user_comment
    :initarg :user_comment
    :type cl:string
    :initform "")
   (subsec_time
    :reader subsec_time
    :initarg :subsec_time
    :type cl:string
    :initform "")
   (subsec_time_original
    :reader subsec_time_original
    :initarg :subsec_time_original
    :type cl:string
    :initform "")
   (subsec_time_digitized
    :reader subsec_time_digitized
    :initarg :subsec_time_digitized
    :type cl:string
    :initform "")
   (temperature
    :reader temperature
    :initarg :temperature
    :type cl:float
    :initform 0.0)
   (humidity
    :reader humidity
    :initarg :humidity
    :type cl:float
    :initform 0.0)
   (pressure
    :reader pressure
    :initarg :pressure
    :type cl:float
    :initform 0.0)
   (water_depth
    :reader water_depth
    :initarg :water_depth
    :type cl:float
    :initform 0.0)
   (acceleration
    :reader acceleration
    :initarg :acceleration
    :type cl:float
    :initform 0.0)
   (camera_elevation_angle
    :reader camera_elevation_angle
    :initarg :camera_elevation_angle
    :type cl:float
    :initform 0.0)
   (flash_pix_version
    :reader flash_pix_version
    :initarg :flash_pix_version
    :type cl:string
    :initform "")
   (color_space
    :reader color_space
    :initarg :color_space
    :type cl:fixnum
    :initform 0)
   (exif_image_width
    :reader exif_image_width
    :initarg :exif_image_width
    :type cl:fixnum
    :initform 0)
   (exif_image_height
    :reader exif_image_height
    :initarg :exif_image_height
    :type cl:fixnum
    :initform 0)
   (related_sound_file
    :reader related_sound_file
    :initarg :related_sound_file
    :type cl:string
    :initform "")
   (flash_energy
    :reader flash_energy
    :initarg :flash_energy
    :type cl:float
    :initform 0.0)
   (focal_plane_x_resolution
    :reader focal_plane_x_resolution
    :initarg :focal_plane_x_resolution
    :type cl:float
    :initform 0.0)
   (focal_plane_y_resolution
    :reader focal_plane_y_resolution
    :initarg :focal_plane_y_resolution
    :type cl:float
    :initform 0.0)
   (focal_plane_resolution_unit
    :reader focal_plane_resolution_unit
    :initarg :focal_plane_resolution_unit
    :type cl:fixnum
    :initform 0)
   (subject_location
    :reader subject_location
    :initarg :subject_location
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 2 :element-type 'cl:fixnum :initial-element 0))
   (exposure_index
    :reader exposure_index
    :initarg :exposure_index
    :type cl:float
    :initform 0.0)
   (sensing_method
    :reader sensing_method
    :initarg :sensing_method
    :type cl:fixnum
    :initform 0)
   (scene_type
    :reader scene_type
    :initarg :scene_type
    :type cl:string
    :initform "")
   (custom_rendered
    :reader custom_rendered
    :initarg :custom_rendered
    :type cl:fixnum
    :initform 0)
   (exposure_mode
    :reader exposure_mode
    :initarg :exposure_mode
    :type cl:fixnum
    :initform 0)
   (white_balance
    :reader white_balance
    :initarg :white_balance
    :type cl:fixnum
    :initform 0)
   (digital_zoom_ratio
    :reader digital_zoom_ratio
    :initarg :digital_zoom_ratio
    :type cl:float
    :initform 0.0)
   (focal_length_in_35mm_film
    :reader focal_length_in_35mm_film
    :initarg :focal_length_in_35mm_film
    :type cl:fixnum
    :initform 0)
   (scene_capture_type
    :reader scene_capture_type
    :initarg :scene_capture_type
    :type cl:fixnum
    :initform 0)
   (gain_control
    :reader gain_control
    :initarg :gain_control
    :type cl:fixnum
    :initform 0)
   (contrast
    :reader contrast
    :initarg :contrast
    :type cl:fixnum
    :initform 0)
   (saturation
    :reader saturation
    :initarg :saturation
    :type cl:fixnum
    :initform 0)
   (sharpness
    :reader sharpness
    :initarg :sharpness
    :type cl:fixnum
    :initform 0)
   (subject_distance_range
    :reader subject_distance_range
    :initarg :subject_distance_range
    :type cl:fixnum
    :initform 0)
   (image_unique_id
    :reader image_unique_id
    :initarg :image_unique_id
    :type cl:string
    :initform "")
   (camera_owner_name
    :reader camera_owner_name
    :initarg :camera_owner_name
    :type cl:string
    :initform "")
   (body_serial_number
    :reader body_serial_number
    :initarg :body_serial_number
    :type cl:string
    :initform "")
   (lens_specification
    :reader lens_specification
    :initarg :lens_specification
    :type (cl:vector cl:float)
   :initform (cl:make-array 4 :element-type 'cl:float :initial-element 0.0))
   (lens_make
    :reader lens_make
    :initarg :lens_make
    :type cl:string
    :initform "")
   (lens_model
    :reader lens_model
    :initarg :lens_model
    :type cl:string
    :initform "")
   (lens_serial_number
    :reader lens_serial_number
    :initarg :lens_serial_number
    :type cl:string
    :initform "")
   (composite_image
    :reader composite_image
    :initarg :composite_image
    :type cl:fixnum
    :initform 0)
   (composite_image_count
    :reader composite_image_count
    :initarg :composite_image_count
    :type (cl:vector cl:fixnum)
   :initform (cl:make-array 2 :element-type 'cl:fixnum :initial-element 0))
   (gamma
    :reader gamma
    :initarg :gamma
    :type cl:float
    :initform 0.0))
)

(cl:defclass ExifTags (<ExifTags>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <ExifTags>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'ExifTags)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name jsk_recognition_msgs-msg:<ExifTags> is deprecated: use jsk_recognition_msgs-msg:ExifTags instead.")))

(cl:ensure-generic-function 'interop_index-val :lambda-list '(m))
(cl:defmethod interop_index-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:interop_index-val is deprecated.  Use jsk_recognition_msgs-msg:interop_index instead.")
  (interop_index m))

(cl:ensure-generic-function 'image_width-val :lambda-list '(m))
(cl:defmethod image_width-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:image_width-val is deprecated.  Use jsk_recognition_msgs-msg:image_width instead.")
  (image_width m))

(cl:ensure-generic-function 'image_height-val :lambda-list '(m))
(cl:defmethod image_height-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:image_height-val is deprecated.  Use jsk_recognition_msgs-msg:image_height instead.")
  (image_height m))

(cl:ensure-generic-function 'bits_per_sample-val :lambda-list '(m))
(cl:defmethod bits_per_sample-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:bits_per_sample-val is deprecated.  Use jsk_recognition_msgs-msg:bits_per_sample instead.")
  (bits_per_sample m))

(cl:ensure-generic-function 'photometric_interpretation-val :lambda-list '(m))
(cl:defmethod photometric_interpretation-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:photometric_interpretation-val is deprecated.  Use jsk_recognition_msgs-msg:photometric_interpretation instead.")
  (photometric_interpretation m))

(cl:ensure-generic-function 'image_description-val :lambda-list '(m))
(cl:defmethod image_description-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:image_description-val is deprecated.  Use jsk_recognition_msgs-msg:image_description instead.")
  (image_description m))

(cl:ensure-generic-function 'make-val :lambda-list '(m))
(cl:defmethod make-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:make-val is deprecated.  Use jsk_recognition_msgs-msg:make instead.")
  (make m))

(cl:ensure-generic-function 'model-val :lambda-list '(m))
(cl:defmethod model-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:model-val is deprecated.  Use jsk_recognition_msgs-msg:model instead.")
  (model m))

(cl:ensure-generic-function 'strip_offsets-val :lambda-list '(m))
(cl:defmethod strip_offsets-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:strip_offsets-val is deprecated.  Use jsk_recognition_msgs-msg:strip_offsets instead.")
  (strip_offsets m))

(cl:ensure-generic-function 'orientation-val :lambda-list '(m))
(cl:defmethod orientation-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:orientation-val is deprecated.  Use jsk_recognition_msgs-msg:orientation instead.")
  (orientation m))

(cl:ensure-generic-function 'samples_per_pixel-val :lambda-list '(m))
(cl:defmethod samples_per_pixel-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:samples_per_pixel-val is deprecated.  Use jsk_recognition_msgs-msg:samples_per_pixel instead.")
  (samples_per_pixel m))

(cl:ensure-generic-function 'rows_per_strip-val :lambda-list '(m))
(cl:defmethod rows_per_strip-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:rows_per_strip-val is deprecated.  Use jsk_recognition_msgs-msg:rows_per_strip instead.")
  (rows_per_strip m))

(cl:ensure-generic-function 'strip_byte_counts-val :lambda-list '(m))
(cl:defmethod strip_byte_counts-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:strip_byte_counts-val is deprecated.  Use jsk_recognition_msgs-msg:strip_byte_counts instead.")
  (strip_byte_counts m))

(cl:ensure-generic-function 'x_resolution-val :lambda-list '(m))
(cl:defmethod x_resolution-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:x_resolution-val is deprecated.  Use jsk_recognition_msgs-msg:x_resolution instead.")
  (x_resolution m))

(cl:ensure-generic-function 'y_resolution-val :lambda-list '(m))
(cl:defmethod y_resolution-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:y_resolution-val is deprecated.  Use jsk_recognition_msgs-msg:y_resolution instead.")
  (y_resolution m))

(cl:ensure-generic-function 'planar_configuration-val :lambda-list '(m))
(cl:defmethod planar_configuration-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:planar_configuration-val is deprecated.  Use jsk_recognition_msgs-msg:planar_configuration instead.")
  (planar_configuration m))

(cl:ensure-generic-function 'resolution_unit-val :lambda-list '(m))
(cl:defmethod resolution_unit-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:resolution_unit-val is deprecated.  Use jsk_recognition_msgs-msg:resolution_unit instead.")
  (resolution_unit m))

(cl:ensure-generic-function 'transfer_function-val :lambda-list '(m))
(cl:defmethod transfer_function-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:transfer_function-val is deprecated.  Use jsk_recognition_msgs-msg:transfer_function instead.")
  (transfer_function m))

(cl:ensure-generic-function 'software-val :lambda-list '(m))
(cl:defmethod software-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:software-val is deprecated.  Use jsk_recognition_msgs-msg:software instead.")
  (software m))

(cl:ensure-generic-function 'date_time-val :lambda-list '(m))
(cl:defmethod date_time-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:date_time-val is deprecated.  Use jsk_recognition_msgs-msg:date_time instead.")
  (date_time m))

(cl:ensure-generic-function 'artist-val :lambda-list '(m))
(cl:defmethod artist-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:artist-val is deprecated.  Use jsk_recognition_msgs-msg:artist instead.")
  (artist m))

(cl:ensure-generic-function 'white_point-val :lambda-list '(m))
(cl:defmethod white_point-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:white_point-val is deprecated.  Use jsk_recognition_msgs-msg:white_point instead.")
  (white_point m))

(cl:ensure-generic-function 'primary_chromaticities-val :lambda-list '(m))
(cl:defmethod primary_chromaticities-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:primary_chromaticities-val is deprecated.  Use jsk_recognition_msgs-msg:primary_chromaticities instead.")
  (primary_chromaticities m))

(cl:ensure-generic-function 'tile_width-val :lambda-list '(m))
(cl:defmethod tile_width-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:tile_width-val is deprecated.  Use jsk_recognition_msgs-msg:tile_width instead.")
  (tile_width m))

(cl:ensure-generic-function 'tile_length-val :lambda-list '(m))
(cl:defmethod tile_length-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:tile_length-val is deprecated.  Use jsk_recognition_msgs-msg:tile_length instead.")
  (tile_length m))

(cl:ensure-generic-function 'jpg_from_raw_start-val :lambda-list '(m))
(cl:defmethod jpg_from_raw_start-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:jpg_from_raw_start-val is deprecated.  Use jsk_recognition_msgs-msg:jpg_from_raw_start instead.")
  (jpg_from_raw_start m))

(cl:ensure-generic-function 'jpg_from_raw_length-val :lambda-list '(m))
(cl:defmethod jpg_from_raw_length-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:jpg_from_raw_length-val is deprecated.  Use jsk_recognition_msgs-msg:jpg_from_raw_length instead.")
  (jpg_from_raw_length m))

(cl:ensure-generic-function 'ycb_cr_Coefficients-val :lambda-list '(m))
(cl:defmethod ycb_cr_Coefficients-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:ycb_cr_Coefficients-val is deprecated.  Use jsk_recognition_msgs-msg:ycb_cr_Coefficients instead.")
  (ycb_cr_Coefficients m))

(cl:ensure-generic-function 'ycb_cr_sub_sampling-val :lambda-list '(m))
(cl:defmethod ycb_cr_sub_sampling-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:ycb_cr_sub_sampling-val is deprecated.  Use jsk_recognition_msgs-msg:ycb_cr_sub_sampling instead.")
  (ycb_cr_sub_sampling m))

(cl:ensure-generic-function 'ycb_cr_positioning-val :lambda-list '(m))
(cl:defmethod ycb_cr_positioning-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:ycb_cr_positioning-val is deprecated.  Use jsk_recognition_msgs-msg:ycb_cr_positioning instead.")
  (ycb_cr_positioning m))

(cl:ensure-generic-function 'reference_black_white-val :lambda-list '(m))
(cl:defmethod reference_black_white-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:reference_black_white-val is deprecated.  Use jsk_recognition_msgs-msg:reference_black_white instead.")
  (reference_black_white m))

(cl:ensure-generic-function 'copyright-val :lambda-list '(m))
(cl:defmethod copyright-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:copyright-val is deprecated.  Use jsk_recognition_msgs-msg:copyright instead.")
  (copyright m))

(cl:ensure-generic-function 'exposure_time-val :lambda-list '(m))
(cl:defmethod exposure_time-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exposure_time-val is deprecated.  Use jsk_recognition_msgs-msg:exposure_time instead.")
  (exposure_time m))

(cl:ensure-generic-function 'f_number-val :lambda-list '(m))
(cl:defmethod f_number-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:f_number-val is deprecated.  Use jsk_recognition_msgs-msg:f_number instead.")
  (f_number m))

(cl:ensure-generic-function 'exposure_program-val :lambda-list '(m))
(cl:defmethod exposure_program-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exposure_program-val is deprecated.  Use jsk_recognition_msgs-msg:exposure_program instead.")
  (exposure_program m))

(cl:ensure-generic-function 'gps_info-val :lambda-list '(m))
(cl:defmethod gps_info-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gps_info-val is deprecated.  Use jsk_recognition_msgs-msg:gps_info instead.")
  (gps_info m))

(cl:ensure-generic-function 'iso-val :lambda-list '(m))
(cl:defmethod iso-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:iso-val is deprecated.  Use jsk_recognition_msgs-msg:iso instead.")
  (iso m))

(cl:ensure-generic-function 'sensitivity_type-val :lambda-list '(m))
(cl:defmethod sensitivity_type-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:sensitivity_type-val is deprecated.  Use jsk_recognition_msgs-msg:sensitivity_type instead.")
  (sensitivity_type m))

(cl:ensure-generic-function 'standard_output_sensitivity-val :lambda-list '(m))
(cl:defmethod standard_output_sensitivity-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:standard_output_sensitivity-val is deprecated.  Use jsk_recognition_msgs-msg:standard_output_sensitivity instead.")
  (standard_output_sensitivity m))

(cl:ensure-generic-function 'recommended_exposure_index-val :lambda-list '(m))
(cl:defmethod recommended_exposure_index-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:recommended_exposure_index-val is deprecated.  Use jsk_recognition_msgs-msg:recommended_exposure_index instead.")
  (recommended_exposure_index m))

(cl:ensure-generic-function 'iso_speed-val :lambda-list '(m))
(cl:defmethod iso_speed-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:iso_speed-val is deprecated.  Use jsk_recognition_msgs-msg:iso_speed instead.")
  (iso_speed m))

(cl:ensure-generic-function 'iso_speed_latitudeyyy-val :lambda-list '(m))
(cl:defmethod iso_speed_latitudeyyy-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:iso_speed_latitudeyyy-val is deprecated.  Use jsk_recognition_msgs-msg:iso_speed_latitudeyyy instead.")
  (iso_speed_latitudeyyy m))

(cl:ensure-generic-function 'iso_speed_latitudezzz-val :lambda-list '(m))
(cl:defmethod iso_speed_latitudezzz-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:iso_speed_latitudezzz-val is deprecated.  Use jsk_recognition_msgs-msg:iso_speed_latitudezzz instead.")
  (iso_speed_latitudezzz m))

(cl:ensure-generic-function 'exif_version-val :lambda-list '(m))
(cl:defmethod exif_version-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exif_version-val is deprecated.  Use jsk_recognition_msgs-msg:exif_version instead.")
  (exif_version m))

(cl:ensure-generic-function 'date_time_original-val :lambda-list '(m))
(cl:defmethod date_time_original-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:date_time_original-val is deprecated.  Use jsk_recognition_msgs-msg:date_time_original instead.")
  (date_time_original m))

(cl:ensure-generic-function 'date_time_digitized-val :lambda-list '(m))
(cl:defmethod date_time_digitized-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:date_time_digitized-val is deprecated.  Use jsk_recognition_msgs-msg:date_time_digitized instead.")
  (date_time_digitized m))

(cl:ensure-generic-function 'offset_time-val :lambda-list '(m))
(cl:defmethod offset_time-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:offset_time-val is deprecated.  Use jsk_recognition_msgs-msg:offset_time instead.")
  (offset_time m))

(cl:ensure-generic-function 'offset_time_original-val :lambda-list '(m))
(cl:defmethod offset_time_original-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:offset_time_original-val is deprecated.  Use jsk_recognition_msgs-msg:offset_time_original instead.")
  (offset_time_original m))

(cl:ensure-generic-function 'offset_time_digitized-val :lambda-list '(m))
(cl:defmethod offset_time_digitized-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:offset_time_digitized-val is deprecated.  Use jsk_recognition_msgs-msg:offset_time_digitized instead.")
  (offset_time_digitized m))

(cl:ensure-generic-function 'components_configuration-val :lambda-list '(m))
(cl:defmethod components_configuration-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:components_configuration-val is deprecated.  Use jsk_recognition_msgs-msg:components_configuration instead.")
  (components_configuration m))

(cl:ensure-generic-function 'compressed_bits_per_pixel-val :lambda-list '(m))
(cl:defmethod compressed_bits_per_pixel-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:compressed_bits_per_pixel-val is deprecated.  Use jsk_recognition_msgs-msg:compressed_bits_per_pixel instead.")
  (compressed_bits_per_pixel m))

(cl:ensure-generic-function 'shutter_speed_value-val :lambda-list '(m))
(cl:defmethod shutter_speed_value-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:shutter_speed_value-val is deprecated.  Use jsk_recognition_msgs-msg:shutter_speed_value instead.")
  (shutter_speed_value m))

(cl:ensure-generic-function 'aperture_value-val :lambda-list '(m))
(cl:defmethod aperture_value-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:aperture_value-val is deprecated.  Use jsk_recognition_msgs-msg:aperture_value instead.")
  (aperture_value m))

(cl:ensure-generic-function 'brightness_value-val :lambda-list '(m))
(cl:defmethod brightness_value-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:brightness_value-val is deprecated.  Use jsk_recognition_msgs-msg:brightness_value instead.")
  (brightness_value m))

(cl:ensure-generic-function 'exposure_bias_value-val :lambda-list '(m))
(cl:defmethod exposure_bias_value-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exposure_bias_value-val is deprecated.  Use jsk_recognition_msgs-msg:exposure_bias_value instead.")
  (exposure_bias_value m))

(cl:ensure-generic-function 'max_aperture_value-val :lambda-list '(m))
(cl:defmethod max_aperture_value-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:max_aperture_value-val is deprecated.  Use jsk_recognition_msgs-msg:max_aperture_value instead.")
  (max_aperture_value m))

(cl:ensure-generic-function 'subject_distance-val :lambda-list '(m))
(cl:defmethod subject_distance-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subject_distance-val is deprecated.  Use jsk_recognition_msgs-msg:subject_distance instead.")
  (subject_distance m))

(cl:ensure-generic-function 'metering_mode-val :lambda-list '(m))
(cl:defmethod metering_mode-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:metering_mode-val is deprecated.  Use jsk_recognition_msgs-msg:metering_mode instead.")
  (metering_mode m))

(cl:ensure-generic-function 'light_source-val :lambda-list '(m))
(cl:defmethod light_source-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:light_source-val is deprecated.  Use jsk_recognition_msgs-msg:light_source instead.")
  (light_source m))

(cl:ensure-generic-function 'flash-val :lambda-list '(m))
(cl:defmethod flash-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:flash-val is deprecated.  Use jsk_recognition_msgs-msg:flash instead.")
  (flash m))

(cl:ensure-generic-function 'focal_length-val :lambda-list '(m))
(cl:defmethod focal_length-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:focal_length-val is deprecated.  Use jsk_recognition_msgs-msg:focal_length instead.")
  (focal_length m))

(cl:ensure-generic-function 'subject_area-val :lambda-list '(m))
(cl:defmethod subject_area-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subject_area-val is deprecated.  Use jsk_recognition_msgs-msg:subject_area instead.")
  (subject_area m))

(cl:ensure-generic-function 'user_comment-val :lambda-list '(m))
(cl:defmethod user_comment-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:user_comment-val is deprecated.  Use jsk_recognition_msgs-msg:user_comment instead.")
  (user_comment m))

(cl:ensure-generic-function 'subsec_time-val :lambda-list '(m))
(cl:defmethod subsec_time-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subsec_time-val is deprecated.  Use jsk_recognition_msgs-msg:subsec_time instead.")
  (subsec_time m))

(cl:ensure-generic-function 'subsec_time_original-val :lambda-list '(m))
(cl:defmethod subsec_time_original-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subsec_time_original-val is deprecated.  Use jsk_recognition_msgs-msg:subsec_time_original instead.")
  (subsec_time_original m))

(cl:ensure-generic-function 'subsec_time_digitized-val :lambda-list '(m))
(cl:defmethod subsec_time_digitized-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subsec_time_digitized-val is deprecated.  Use jsk_recognition_msgs-msg:subsec_time_digitized instead.")
  (subsec_time_digitized m))

(cl:ensure-generic-function 'temperature-val :lambda-list '(m))
(cl:defmethod temperature-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:temperature-val is deprecated.  Use jsk_recognition_msgs-msg:temperature instead.")
  (temperature m))

(cl:ensure-generic-function 'humidity-val :lambda-list '(m))
(cl:defmethod humidity-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:humidity-val is deprecated.  Use jsk_recognition_msgs-msg:humidity instead.")
  (humidity m))

(cl:ensure-generic-function 'pressure-val :lambda-list '(m))
(cl:defmethod pressure-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:pressure-val is deprecated.  Use jsk_recognition_msgs-msg:pressure instead.")
  (pressure m))

(cl:ensure-generic-function 'water_depth-val :lambda-list '(m))
(cl:defmethod water_depth-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:water_depth-val is deprecated.  Use jsk_recognition_msgs-msg:water_depth instead.")
  (water_depth m))

(cl:ensure-generic-function 'acceleration-val :lambda-list '(m))
(cl:defmethod acceleration-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:acceleration-val is deprecated.  Use jsk_recognition_msgs-msg:acceleration instead.")
  (acceleration m))

(cl:ensure-generic-function 'camera_elevation_angle-val :lambda-list '(m))
(cl:defmethod camera_elevation_angle-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:camera_elevation_angle-val is deprecated.  Use jsk_recognition_msgs-msg:camera_elevation_angle instead.")
  (camera_elevation_angle m))

(cl:ensure-generic-function 'flash_pix_version-val :lambda-list '(m))
(cl:defmethod flash_pix_version-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:flash_pix_version-val is deprecated.  Use jsk_recognition_msgs-msg:flash_pix_version instead.")
  (flash_pix_version m))

(cl:ensure-generic-function 'color_space-val :lambda-list '(m))
(cl:defmethod color_space-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:color_space-val is deprecated.  Use jsk_recognition_msgs-msg:color_space instead.")
  (color_space m))

(cl:ensure-generic-function 'exif_image_width-val :lambda-list '(m))
(cl:defmethod exif_image_width-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exif_image_width-val is deprecated.  Use jsk_recognition_msgs-msg:exif_image_width instead.")
  (exif_image_width m))

(cl:ensure-generic-function 'exif_image_height-val :lambda-list '(m))
(cl:defmethod exif_image_height-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exif_image_height-val is deprecated.  Use jsk_recognition_msgs-msg:exif_image_height instead.")
  (exif_image_height m))

(cl:ensure-generic-function 'related_sound_file-val :lambda-list '(m))
(cl:defmethod related_sound_file-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:related_sound_file-val is deprecated.  Use jsk_recognition_msgs-msg:related_sound_file instead.")
  (related_sound_file m))

(cl:ensure-generic-function 'flash_energy-val :lambda-list '(m))
(cl:defmethod flash_energy-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:flash_energy-val is deprecated.  Use jsk_recognition_msgs-msg:flash_energy instead.")
  (flash_energy m))

(cl:ensure-generic-function 'focal_plane_x_resolution-val :lambda-list '(m))
(cl:defmethod focal_plane_x_resolution-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:focal_plane_x_resolution-val is deprecated.  Use jsk_recognition_msgs-msg:focal_plane_x_resolution instead.")
  (focal_plane_x_resolution m))

(cl:ensure-generic-function 'focal_plane_y_resolution-val :lambda-list '(m))
(cl:defmethod focal_plane_y_resolution-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:focal_plane_y_resolution-val is deprecated.  Use jsk_recognition_msgs-msg:focal_plane_y_resolution instead.")
  (focal_plane_y_resolution m))

(cl:ensure-generic-function 'focal_plane_resolution_unit-val :lambda-list '(m))
(cl:defmethod focal_plane_resolution_unit-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:focal_plane_resolution_unit-val is deprecated.  Use jsk_recognition_msgs-msg:focal_plane_resolution_unit instead.")
  (focal_plane_resolution_unit m))

(cl:ensure-generic-function 'subject_location-val :lambda-list '(m))
(cl:defmethod subject_location-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subject_location-val is deprecated.  Use jsk_recognition_msgs-msg:subject_location instead.")
  (subject_location m))

(cl:ensure-generic-function 'exposure_index-val :lambda-list '(m))
(cl:defmethod exposure_index-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exposure_index-val is deprecated.  Use jsk_recognition_msgs-msg:exposure_index instead.")
  (exposure_index m))

(cl:ensure-generic-function 'sensing_method-val :lambda-list '(m))
(cl:defmethod sensing_method-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:sensing_method-val is deprecated.  Use jsk_recognition_msgs-msg:sensing_method instead.")
  (sensing_method m))

(cl:ensure-generic-function 'scene_type-val :lambda-list '(m))
(cl:defmethod scene_type-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:scene_type-val is deprecated.  Use jsk_recognition_msgs-msg:scene_type instead.")
  (scene_type m))

(cl:ensure-generic-function 'custom_rendered-val :lambda-list '(m))
(cl:defmethod custom_rendered-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:custom_rendered-val is deprecated.  Use jsk_recognition_msgs-msg:custom_rendered instead.")
  (custom_rendered m))

(cl:ensure-generic-function 'exposure_mode-val :lambda-list '(m))
(cl:defmethod exposure_mode-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:exposure_mode-val is deprecated.  Use jsk_recognition_msgs-msg:exposure_mode instead.")
  (exposure_mode m))

(cl:ensure-generic-function 'white_balance-val :lambda-list '(m))
(cl:defmethod white_balance-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:white_balance-val is deprecated.  Use jsk_recognition_msgs-msg:white_balance instead.")
  (white_balance m))

(cl:ensure-generic-function 'digital_zoom_ratio-val :lambda-list '(m))
(cl:defmethod digital_zoom_ratio-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:digital_zoom_ratio-val is deprecated.  Use jsk_recognition_msgs-msg:digital_zoom_ratio instead.")
  (digital_zoom_ratio m))

(cl:ensure-generic-function 'focal_length_in_35mm_film-val :lambda-list '(m))
(cl:defmethod focal_length_in_35mm_film-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:focal_length_in_35mm_film-val is deprecated.  Use jsk_recognition_msgs-msg:focal_length_in_35mm_film instead.")
  (focal_length_in_35mm_film m))

(cl:ensure-generic-function 'scene_capture_type-val :lambda-list '(m))
(cl:defmethod scene_capture_type-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:scene_capture_type-val is deprecated.  Use jsk_recognition_msgs-msg:scene_capture_type instead.")
  (scene_capture_type m))

(cl:ensure-generic-function 'gain_control-val :lambda-list '(m))
(cl:defmethod gain_control-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gain_control-val is deprecated.  Use jsk_recognition_msgs-msg:gain_control instead.")
  (gain_control m))

(cl:ensure-generic-function 'contrast-val :lambda-list '(m))
(cl:defmethod contrast-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:contrast-val is deprecated.  Use jsk_recognition_msgs-msg:contrast instead.")
  (contrast m))

(cl:ensure-generic-function 'saturation-val :lambda-list '(m))
(cl:defmethod saturation-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:saturation-val is deprecated.  Use jsk_recognition_msgs-msg:saturation instead.")
  (saturation m))

(cl:ensure-generic-function 'sharpness-val :lambda-list '(m))
(cl:defmethod sharpness-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:sharpness-val is deprecated.  Use jsk_recognition_msgs-msg:sharpness instead.")
  (sharpness m))

(cl:ensure-generic-function 'subject_distance_range-val :lambda-list '(m))
(cl:defmethod subject_distance_range-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:subject_distance_range-val is deprecated.  Use jsk_recognition_msgs-msg:subject_distance_range instead.")
  (subject_distance_range m))

(cl:ensure-generic-function 'image_unique_id-val :lambda-list '(m))
(cl:defmethod image_unique_id-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:image_unique_id-val is deprecated.  Use jsk_recognition_msgs-msg:image_unique_id instead.")
  (image_unique_id m))

(cl:ensure-generic-function 'camera_owner_name-val :lambda-list '(m))
(cl:defmethod camera_owner_name-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:camera_owner_name-val is deprecated.  Use jsk_recognition_msgs-msg:camera_owner_name instead.")
  (camera_owner_name m))

(cl:ensure-generic-function 'body_serial_number-val :lambda-list '(m))
(cl:defmethod body_serial_number-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:body_serial_number-val is deprecated.  Use jsk_recognition_msgs-msg:body_serial_number instead.")
  (body_serial_number m))

(cl:ensure-generic-function 'lens_specification-val :lambda-list '(m))
(cl:defmethod lens_specification-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:lens_specification-val is deprecated.  Use jsk_recognition_msgs-msg:lens_specification instead.")
  (lens_specification m))

(cl:ensure-generic-function 'lens_make-val :lambda-list '(m))
(cl:defmethod lens_make-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:lens_make-val is deprecated.  Use jsk_recognition_msgs-msg:lens_make instead.")
  (lens_make m))

(cl:ensure-generic-function 'lens_model-val :lambda-list '(m))
(cl:defmethod lens_model-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:lens_model-val is deprecated.  Use jsk_recognition_msgs-msg:lens_model instead.")
  (lens_model m))

(cl:ensure-generic-function 'lens_serial_number-val :lambda-list '(m))
(cl:defmethod lens_serial_number-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:lens_serial_number-val is deprecated.  Use jsk_recognition_msgs-msg:lens_serial_number instead.")
  (lens_serial_number m))

(cl:ensure-generic-function 'composite_image-val :lambda-list '(m))
(cl:defmethod composite_image-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:composite_image-val is deprecated.  Use jsk_recognition_msgs-msg:composite_image instead.")
  (composite_image m))

(cl:ensure-generic-function 'composite_image_count-val :lambda-list '(m))
(cl:defmethod composite_image_count-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:composite_image_count-val is deprecated.  Use jsk_recognition_msgs-msg:composite_image_count instead.")
  (composite_image_count m))

(cl:ensure-generic-function 'gamma-val :lambda-list '(m))
(cl:defmethod gamma-val ((m <ExifTags>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader jsk_recognition_msgs-msg:gamma-val is deprecated.  Use jsk_recognition_msgs-msg:gamma instead.")
  (gamma m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <ExifTags>) ostream)
  "Serializes a message object of type '<ExifTags>"
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'interop_index))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'interop_index))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'image_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'image_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'image_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'image_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'image_height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'image_height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'image_height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'image_height)) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'bits_per_sample))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'bits_per_sample))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'photometric_interpretation)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'photometric_interpretation)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'image_description))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'image_description))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'make))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'make))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'model))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'model))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'strip_offsets)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'strip_offsets)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'strip_offsets)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'strip_offsets)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'orientation)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'orientation)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'samples_per_pixel)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'samples_per_pixel)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'rows_per_strip)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'rows_per_strip)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'rows_per_strip)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'rows_per_strip)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'strip_byte_counts)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'strip_byte_counts)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'strip_byte_counts)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'strip_byte_counts)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'x_resolution))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'y_resolution))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'planar_configuration)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'planar_configuration)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'resolution_unit)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'resolution_unit)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'transfer_function))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'software))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'software))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'date_time))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'date_time))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'artist))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'artist))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'white_point))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'primary_chromaticities))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'tile_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'tile_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'tile_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'tile_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'tile_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'tile_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'tile_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'tile_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'jpg_from_raw_start)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'jpg_from_raw_start)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'jpg_from_raw_start)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'jpg_from_raw_start)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'jpg_from_raw_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'jpg_from_raw_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'jpg_from_raw_length)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'jpg_from_raw_length)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'ycb_cr_Coefficients))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'ycb_cr_sub_sampling))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ycb_cr_positioning)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ycb_cr_positioning)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'reference_black_white))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'copyright))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'copyright))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'exposure_time))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'f_number))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exposure_program)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exposure_program)) ostream)
  (roslisp-msg-protocol:serialize (cl:slot-value msg 'gps_info) ostream)
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'iso))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'iso))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'sensitivity_type)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'sensitivity_type)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'standard_output_sensitivity)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'standard_output_sensitivity)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'standard_output_sensitivity)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'standard_output_sensitivity)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'recommended_exposure_index)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'recommended_exposure_index)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'recommended_exposure_index)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'recommended_exposure_index)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'iso_speed)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'iso_speed)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'iso_speed)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'iso_speed)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'iso_speed_latitudeyyy)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'iso_speed_latitudeyyy)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'iso_speed_latitudeyyy)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'iso_speed_latitudeyyy)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'iso_speed_latitudezzz)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'iso_speed_latitudezzz)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'iso_speed_latitudezzz)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'iso_speed_latitudezzz)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'exif_version))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'exif_version))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'date_time_original))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'date_time_original))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'date_time_digitized))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'date_time_digitized))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'offset_time))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'offset_time))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'offset_time_original))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'offset_time_original))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'offset_time_digitized))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'offset_time_digitized))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream))
   (cl:slot-value msg 'components_configuration))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'compressed_bits_per_pixel))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'shutter_speed_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'aperture_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'brightness_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'exposure_bias_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'max_aperture_value))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'subject_distance))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'metering_mode)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'metering_mode)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'light_source)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'light_source)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'flash)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'flash)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'focal_length))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'subject_area))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'subject_area))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'user_comment))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'user_comment))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'subsec_time))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'subsec_time))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'subsec_time_original))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'subsec_time_original))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'subsec_time_digitized))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'subsec_time_digitized))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'temperature))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'humidity))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'pressure))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'water_depth))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'acceleration))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'camera_elevation_angle))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'flash_pix_version))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'flash_pix_version))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'color_space)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'color_space)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exif_image_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exif_image_width)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exif_image_height)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exif_image_height)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'related_sound_file))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'related_sound_file))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'flash_energy))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'focal_plane_x_resolution))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'focal_plane_y_resolution))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'focal_plane_resolution_unit)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'focal_plane_resolution_unit)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'subject_location))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'exposure_index))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'sensing_method)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'sensing_method)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'scene_type))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'scene_type))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'custom_rendered)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'custom_rendered)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exposure_mode)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exposure_mode)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'white_balance)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'white_balance)) ostream)
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'digital_zoom_ratio))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'focal_length_in_35mm_film)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'focal_length_in_35mm_film)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'scene_capture_type)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'scene_capture_type)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'gain_control)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'gain_control)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'contrast)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'contrast)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'saturation)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'saturation)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'sharpness)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'sharpness)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'subject_distance_range)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'subject_distance_range)) ostream)
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'image_unique_id))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'image_unique_id))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'camera_owner_name))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'camera_owner_name))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'body_serial_number))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'body_serial_number))
  (cl:map cl:nil #'(cl:lambda (ele) (cl:let ((bits (roslisp-utils:encode-double-float-bits ele)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream)))
   (cl:slot-value msg 'lens_specification))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'lens_make))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'lens_make))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'lens_model))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'lens_model))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'lens_serial_number))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'lens_serial_number))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'composite_image)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'composite_image)) ostream)
  (cl:map cl:nil #'(cl:lambda (ele) (cl:write-byte (cl:ldb (cl:byte 8 0) ele) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 8) ele) ostream))
   (cl:slot-value msg 'composite_image_count))
  (cl:let ((bits (roslisp-utils:encode-double-float-bits (cl:slot-value msg 'gamma))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 32) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 40) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 48) bits) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 56) bits) ostream))
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <ExifTags>) istream)
  "Deserializes a message object of type '<ExifTags>"
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'interop_index) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'interop_index) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'image_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'image_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'image_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'image_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'image_height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'image_height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'image_height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'image_height)) (cl:read-byte istream))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'bits_per_sample) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'bits_per_sample)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'photometric_interpretation)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'photometric_interpretation)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'image_description) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'image_description) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'make) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'make) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'model) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'model) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'strip_offsets)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'strip_offsets)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'strip_offsets)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'strip_offsets)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'orientation)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'orientation)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'samples_per_pixel)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'samples_per_pixel)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'rows_per_strip)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'rows_per_strip)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'rows_per_strip)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'rows_per_strip)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'strip_byte_counts)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'strip_byte_counts)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'strip_byte_counts)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'strip_byte_counts)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'x_resolution) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'y_resolution) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'planar_configuration)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'planar_configuration)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'resolution_unit)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'resolution_unit)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'transfer_function) (cl:make-array 768))
  (cl:let ((vals (cl:slot-value msg 'transfer_function)))
    (cl:dotimes (i 768)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'software) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'software) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'date_time) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'date_time) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'artist) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'artist) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'white_point) (cl:make-array 2))
  (cl:let ((vals (cl:slot-value msg 'white_point)))
    (cl:dotimes (i 2)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  (cl:setf (cl:slot-value msg 'primary_chromaticities) (cl:make-array 6))
  (cl:let ((vals (cl:slot-value msg 'primary_chromaticities)))
    (cl:dotimes (i 6)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'tile_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'tile_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'tile_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'tile_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'tile_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'tile_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'tile_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'tile_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'jpg_from_raw_start)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'jpg_from_raw_start)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'jpg_from_raw_start)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'jpg_from_raw_start)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'jpg_from_raw_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'jpg_from_raw_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'jpg_from_raw_length)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'jpg_from_raw_length)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'ycb_cr_Coefficients) (cl:make-array 3))
  (cl:let ((vals (cl:slot-value msg 'ycb_cr_Coefficients)))
    (cl:dotimes (i 3)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
  (cl:setf (cl:slot-value msg 'ycb_cr_sub_sampling) (cl:make-array 2))
  (cl:let ((vals (cl:slot-value msg 'ycb_cr_sub_sampling)))
    (cl:dotimes (i 2)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'ycb_cr_positioning)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'ycb_cr_positioning)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'reference_black_white) (cl:make-array 6))
  (cl:let ((vals (cl:slot-value msg 'reference_black_white)))
    (cl:dotimes (i 6)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'copyright) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'copyright) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'exposure_time) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'f_number) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exposure_program)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exposure_program)) (cl:read-byte istream))
  (roslisp-msg-protocol:deserialize (cl:slot-value msg 'gps_info) istream)
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'iso) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'iso)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'sensitivity_type)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'sensitivity_type)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'standard_output_sensitivity)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'standard_output_sensitivity)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'standard_output_sensitivity)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'standard_output_sensitivity)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'recommended_exposure_index)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'recommended_exposure_index)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'recommended_exposure_index)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'recommended_exposure_index)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'iso_speed)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'iso_speed)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'iso_speed)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'iso_speed)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'iso_speed_latitudeyyy)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'iso_speed_latitudeyyy)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'iso_speed_latitudeyyy)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'iso_speed_latitudeyyy)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'iso_speed_latitudezzz)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'iso_speed_latitudezzz)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) (cl:slot-value msg 'iso_speed_latitudezzz)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) (cl:slot-value msg 'iso_speed_latitudezzz)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'exif_version) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'exif_version) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'date_time_original) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'date_time_original) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'date_time_digitized) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'date_time_digitized) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'offset_time) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'offset_time) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'offset_time_original) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'offset_time_original) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'offset_time_digitized) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'offset_time_digitized) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'components_configuration) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'components_configuration)))
    (cl:dotimes (i 4)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'compressed_bits_per_pixel) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'shutter_speed_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'aperture_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'brightness_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'exposure_bias_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'max_aperture_value) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'subject_distance) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'metering_mode)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'metering_mode)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'light_source)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'light_source)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'flash)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'flash)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'focal_length) (roslisp-utils:decode-double-float-bits bits)))
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'subject_area) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'subject_area)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'user_comment) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'user_comment) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'subsec_time) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'subsec_time) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'subsec_time_original) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'subsec_time_original) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'subsec_time_digitized) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'subsec_time_digitized) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'temperature) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'humidity) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'pressure) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'water_depth) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'acceleration) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'camera_elevation_angle) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'flash_pix_version) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'flash_pix_version) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'color_space)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'color_space)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exif_image_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exif_image_width)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exif_image_height)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exif_image_height)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'related_sound_file) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'related_sound_file) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'flash_energy) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'focal_plane_x_resolution) (roslisp-utils:decode-double-float-bits bits)))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'focal_plane_y_resolution) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'focal_plane_resolution_unit)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'focal_plane_resolution_unit)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'subject_location) (cl:make-array 2))
  (cl:let ((vals (cl:slot-value msg 'subject_location)))
    (cl:dotimes (i 2)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'exposure_index) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'sensing_method)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'sensing_method)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'scene_type) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'scene_type) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'custom_rendered)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'custom_rendered)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'exposure_mode)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'exposure_mode)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'white_balance)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'white_balance)) (cl:read-byte istream))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'digital_zoom_ratio) (roslisp-utils:decode-double-float-bits bits)))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'focal_length_in_35mm_film)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'focal_length_in_35mm_film)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'scene_capture_type)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'scene_capture_type)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'gain_control)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'gain_control)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'contrast)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'contrast)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'saturation)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'saturation)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'sharpness)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'sharpness)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'subject_distance_range)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'subject_distance_range)) (cl:read-byte istream))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'image_unique_id) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'image_unique_id) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'camera_owner_name) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'camera_owner_name) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'body_serial_number) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'body_serial_number) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
  (cl:setf (cl:slot-value msg 'lens_specification) (cl:make-array 4))
  (cl:let ((vals (cl:slot-value msg 'lens_specification)))
    (cl:dotimes (i 4)
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:aref vals i) (roslisp-utils:decode-double-float-bits bits)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'lens_make) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'lens_make) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'lens_model) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'lens_model) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'lens_serial_number) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'lens_serial_number) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'composite_image)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:slot-value msg 'composite_image)) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'composite_image_count) (cl:make-array 2))
  (cl:let ((vals (cl:slot-value msg 'composite_image_count)))
    (cl:dotimes (i 2)
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:aref vals i)) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) (cl:aref vals i)) (cl:read-byte istream))))
    (cl:let ((bits 0))
      (cl:setf (cl:ldb (cl:byte 8 0) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 32) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 40) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 48) bits) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 56) bits) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'gamma) (roslisp-utils:decode-double-float-bits bits)))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<ExifTags>)))
  "Returns string type for a message object of type '<ExifTags>"
  "jsk_recognition_msgs/ExifTags")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'ExifTags)))
  "Returns string type for a message object of type 'ExifTags"
  "jsk_recognition_msgs/ExifTags")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<ExifTags>)))
  "Returns md5sum for a message object of type '<ExifTags>"
  "0db5f040080892d8197ca4a68428c05d")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'ExifTags)))
  "Returns md5sum for a message object of type 'ExifTags"
  "0db5f040080892d8197ca4a68428c05d")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<ExifTags>)))
  "Returns full string definition for message of type '<ExifTags>"
  (cl:format cl:nil "# https://exiftool.org/TagNames/EXIF.html~%#~%# Tag ID	Tag Name	Writable	Group	Values / Notes~%#~%# 0x0001	InteropIndex	string!	InteropIFD~%string interop_index~%# 						'R03' = R03 - DCF option file (Adobe RGB)~%# 						'R98' = R98 - DCF basic file (sRGB)~%# 						'THM' = THM - DCF thumbnail file~%# 0x0002	InteropVersion	undef!:	InteropIFD~%# 0x000b	ProcessingSoftware	string	IFD0	(used by ACD Systems Digital Imaging)~%# 0x00fe	SubfileType	int32u!	IFD0	(called NewSubfileType by the TIFF specification)~%# 						0x0 = Full-resolution image~%# 						0x1 = Reduced-resolution image~%# 						0x2 = Single page of multi-page image~%# 						0x3 = Single page of multi-page reduced-resolution image~%# 						0x4 = Transparency mask~%# 						0x5 = Transparency mask of reduced-resolution image~%# 						0x6 = Transparency mask of multi-page image~%# 						0x7 = Transparency mask of reduced-resolution multi-page image~%# 						0x8 = Depth map~%# 						0x9 = Depth map of reduced-resolution image~%# 						0x10 = Enhanced image data~%# 						0x10001 = Alternate reduced-resolution image~%# 						0x10004 = Semantic Mask~%# 						0xffffffff = invalid~%# 						Bit 0 = Reduced resolution~%# 						Bit 1 = Single page~%# 						Bit 2 = Transparency mask~%# 						Bit 3 = TIFF/IT final page~%# 						Bit 4 = TIFF-FX mixed raster content~%# 0x00ff	OldSubfileType	int16u!	IFD0	(called SubfileType by the TIFF specification)~%# 						1 = Full-resolution image~%# 						2 = Reduced-resolution image~%# 						3 = Single page of multi-page image~%# 0x0100	ImageWidth	int32u!	IFD0	 ~%uint32 image_width~%# 0x0101	ImageHeight	int32u!	IFD0	(called ImageLength by the EXIF spec.)~%uint32 image_height~%# 0x0102	BitsPerSample	int16u[n]!	IFD0~%uint16[] bits_per_sample~%# 0x0103	Compression	int16u!:	IFD0	--> EXIF Compression Values~%# 0x0106	PhotometricInterpretation	int16u!	IFD0~%# 						0 = WhiteIsZero~%# 						1 = BlackIsZero~%# 						2 = RGB~%# 						3 = RGB Palette~%# 						4 = Transparency Mask~%# 						5 = CMYK~%# 						6 = YCbCr~%# 						8 = CIELab~%# 						9 = ICCLab~%# 						10 = ITULab~%# 						32803 = Color Filter Array~%# 						32844 = Pixar LogL~%# 						32845 = Pixar LogLuv~%# 						32892 = Sequential Color Filter~%# 						34892 = Linear Raw~%# 						51177 = Depth Map~%# 						52527 = Semantic Mask~%uint16 photometric_interpretation~%# 0x0107	Thresholding	int16u!	IFD0~%# 						1 = No dithering or halftoning~%# 						2 = Ordered dither or halftone~%# 						3 = Randomized dither~%# 0x0108	CellWidth	int16u!	IFD0~%# 0x0109	CellLength	int16u!	IFD0~%# 0x010a	FillOrder	int16u!	IFD0~%# 						1 = Normal~%# 						2 = Reversed~%# 0x010d	DocumentName	string	IFD0~%# 0x010e	ImageDescription	string	IFD0~%string image_description~%# 0x010f	Make	string	IFD0~%string make~%# 0x0110	Model	string	IFD0~%string model~%# 0x0111	StripOffsets	(called StripOffsets in most locations, but it is PreviewImageStart in IFD0 of CR2 images and various IFD's of DNG images except for SubIFD2 where it is JpgFromRawStart)~%# 						PreviewImageStart	int32u*	IFD0~%# 						PreviewImageStart	int32u*	All~%# 						JpgFromRawStart	int32u*	SubIFD2~%uint32 strip_offsets~%# 0x0112	Orientation	int16u	IFD0	~%# 						1 = Horizontal (normal)~%# 						2 = Mirror horizontal~%# 						3 = Rotate 180~%# 						4 = Mirror vertical~%# 						5 = Mirror horizontal and rotate 270 CW~%# 						6 = Rotate 90 CW~%# 						7 = Mirror horizontal and rotate 90 CW~%# 						8 = Rotate 270 CW~%uint16 orientation~%# 0x0115	SamplesPerPixel	int16u!	IFD0~%uint16 samples_per_pixel~%# 0x0116	RowsPerStrip	int32u!	IFD0~%uint32 rows_per_strip~%# 0x0117	StripByteCounts	(called StripByteCounts in most locations, but it is PreviewImageLength in IFD0 of CR2 images and various IFD's of DNG images except for SubIFD2 where it is JpgFromRawLength)~%# 						PreviewImageLength	int32u*	IFD0~%# 						PreviewImageLength	int32u*	All~%# 						JpgFromRawLength	int32u*	SubIFD2~%uint32 strip_byte_counts~%# 0x0118	MinSampleValue	int16u	IFD0~%# 0x0119	MaxSampleValue	int16u	IFD0~%# 0x011a	XResolution	rational64u:	IFD0~%float64 x_resolution~%# 0x011b	YResolution	rational64u:	IFD0~%float64 y_resolution~%# 0x011c	PlanarConfiguration	int16u!	IFD0~%# 						1 = Chunky~%# 						2 = Planar~%uint16 planar_configuration~%# 0x011d	PageName	string	IFD0~%# 0x011e	XPosition	rational64u	IFD0~%# 0x011f	YPosition	rational64u	IFD0~%# 0x0120	FreeOffsets	no	-~%# 0x0121	FreeByteCounts	no	-~%# 0x0122	GrayResponseUnit	int16u	IFD0~%# 						1 = 0.1~%# 						2 = 0.001~%# 						3 = 0.0001~%# 						4 = 1e-05~%# 						5 = 1e-06~%# 0x0123	GrayResponseCurve	no	-~%# 0x0124	T4Options	no	-	Bit 0 = 2-Dimensional encoding~%# Bit 1 = Uncompressed~%# Bit 2 = Fill bits added~%# 0x0125	T6Options	no	-	Bit 1 = Uncompressed~%# 0x0128	ResolutionUnit	int16u:	IFD0	(the value 1 is not standard EXIF)~%# 						1 = None~%# 						2 = inches~%# 						3 = cm~%uint16 resolution_unit~%# 0x0129	PageNumber	int16u[2]	IFD0~%# 0x012c	ColorResponseUnit	no	-~%# 0x012d	TransferFunction	int16u[768]!	IFD0~%uint16[768] transfer_function~%# 0x0131	Software	string	IFD0~%string software~%# 0x0132	ModifyDate	string	IFD0	(called DateTime by the EXIF spec.)~%string date_time~%# 0x013b	Artist	string	IFD0	(becomes a list-type tag when the MWG module is loaded)~%string artist~%# 0x013c	HostComputer	string	IFD0	 ~%# 0x013d	Predictor	int16u!	IFD0	~%# 						1 = None~%# 						2 = Horizontal differencing~%# 						3 = Floating point~%# 						34892 = Horizontal difference X2~%# 						34893 = Horizontal difference X4~%# 						34894 = Floating point X2~%# 						34895 = Floating point X4~%# 0x013e	WhitePoint	rational64u[2]	IFD0~%float64[2] white_point~%# 0x013f	PrimaryChromaticities	rational64u[6]	IFD0~%float64[6] primary_chromaticities~%# 0x0140	ColorMap	no	-	 ~%# 0x0141	HalftoneHints	int16u[2]	IFD0~%# 0x0142	TileWidth	int32u!	IFD0~%uint32 tile_width~%# 0x0143	TileLength	int32u!	IFD0~%uint32 tile_length~%# 0x0144	TileOffsets	no	-~%# 0x0145	TileByteCounts	no	-~%# 0x0146	BadFaxLines	no	-~%# 0x0147	CleanFaxData	no	-~%# 						0 = Clean~%# 						1 = Regenerated~%# 						2 = Unclean~%# 0x0148	ConsecutiveBadFaxLines	no	-~%# 0x014a	SubIF	-	-	--> EXIF Tags~%# 		A100DataOffset	-no	IFD0	(the data offset in original Sony DSLR-A100 ARW images)~%# 0x014c	InkSet	int16u	IFD0~%# 						1 = CMYK~%# 						2 = Not CMYK~%# 0x014d	InkNames	no	-~%# 0x014e	NumberofInks	no	-~%# 0x0150	DotRange	no	-~%# 0x0151	TargetPrinter	string	IFD0~%# 0x0152	ExtraSamples	no	-~%# 						0 = Unspecified~%# 						1 = Associated Alpha~%# 						2 = Unassociated Alpha~%# 0x0153	SampleFormat	no	SubIFD	(SamplesPerPixel values)# [Values 0-3]~%# 						1 = Unsigned~%# 						2 = Signed~%# 						3 = Float~%# 						4 = Undefined~%# 						5 = Complex int~%# 						6 = Complex float~%# 0x0154	SMinSampleValue	no	-~%# 0x0155	SMaxSampleValue	no	-~%# 0x0156	TransferRange	no	-~%# 0x0157	ClipPath	no	-~%# 0x0158	XClipPathUnits	no	-~%# 0x0159	YClipPathUnits	no	-~%# 0x015a	Indexed	no	-~%# 						0 = Not indexed~%# 						1 = Indexed~%# 0x015b	JPEGTables	no	- ~%# 0x015f	OPIProxy	no	-~%# 						0 = Higher resolution image does not exist~%# 						1 = Higher resolution image exists~%# 0x0190	GlobalParametersIFD	-	-	--> EXIF Tags~%# 0x0191	ProfileType	no	-~%# 						0 = Unspecified~%# 						1 = Group 3 FAX~%# 0x0192	FaxProfile	no	-~%# 						0 = Unknown~%# 						1 = Minimal B&W lossless, S~%# 						2 = Extended B&W lossless, F~%# 						3 = Lossless JBIG B&W, J~%# 						4 = Lossy color and grayscale, C~%# 						5 = Lossless color and grayscale, L~%# 						6 = Mixed raster content, M~%# 						7 = Profile T~%# 						255 = Multi Profiles~%# 0x0193	CodingMethods	no	-~%# 						Bit 0 = Unspecified compression~%# 						Bit 1 = Modified Huffman~%# 						Bit 2 = Modified Read~%# 						Bit 3 = Modified MR~%# 						Bit 4 = JBIG~%# 						Bit 5 = Baseline JPEG~%# 						Bit 6 = JBIG color~%# 0x0194	VersionYear	no	-~%# 0x0195	ModeNumber	no	-~%# 0x01b1	Decode	no	-~%# 0x01b2	DefaultImageColor	no	-~%# 0x01b3	T82Options	no	-~%# 0x01b5	JPEGTables	no	-~%# 0x0200	JPEGProc	no	-~%# 						1 = Baseline~%# 						14 = Lossless~%# 0x0201	ThumbnailOffset	int32u*	IFD1	(ThumbnailOffset in IFD1 of JPEG and some TIFF-based images, IFD0 of MRW images and AVI and MOV videos, and the SubIFD in IFD1 of SRW images; PreviewImageStart in MakerNotes and IFD0 of ARW and SR2 images; JpgFromRawStart in SubIFD of NEF images and IFD2 of PEF images; and OtherImageStart in everything else)~%# 						ThumbnailOffset	int32u*	IFD0~%# 						ThumbnailOffset	int32u*	SubIFD~%# 						PreviewImageStart	int32u*	MakerNotes~%# 						PreviewImageStart	int32u*	IFD0~%# 						JpgFromRawStart	int32u*	SubIFD~%# 						JpgFromRawStart	int32u*	IFD2~%# 						OtherImageStart	int32u*	SubIFD1~%# 						OtherImageStart	int32u*	SubIFD2~%# 						OtherImageStart	no~%uint32 jpg_from_raw_start~%# 0x0202	ThumbnailLength	int32u*	IFD1	(ThumbnailLength in IFD1 of JPEG and some TIFF-based images, IFD0 of MRW images and AVI and MOV videos, and the SubIFD in IFD1 of SRW images; PreviewImageLength in MakerNotes and IFD0 of ARW and SR2 images; JpgFromRawLength in SubIFD of NEF images, and IFD2 of PEF images; and OtherImageLength in everything else)~%# 						ThumbnailLength	int32u*	IFD0~%# 						ThumbnailLength	int32u*	SubIFD~%# 						PreviewImageLength	int32u*	MakerNotes~%# 						PreviewImageLength	int32u*	IFD0~%# 						JpgFromRawLength	int32u*	SubIFD~%# 						JpgFromRawLength	int32u*	IFD2~%# 						OtherImageLength	int32u*	SubIFD1~%# 						OtherImageLength	int32u*	SubIFD2~%# 						OtherImageLength	no	~%uint32 jpg_from_raw_length~%# 0x0203	JPEGRestartInterval	no	-~%# 0x0205	JPEGLosslessPredictors	no	-~%# 0x0206	JPEGPointTransforms	no	-~%# 0x0207	JPEGQTables	no	-~%# 0x0208	JPEGDCTables	no	-~%# 0x0209	JPEGACTables	no	-~%# 0x0211	YCbCrCoefficients	rational64u[3]!	IFD0~%float64[3] ycb_cr_Coefficients~%# 0x0212	YCbCrSubSampling	int16u[2]!	IFD0	~%# 						'1 1' = YCbCr4:4:4 (1 1)~%# 						'1 2' = YCbCr4:4:0 (1 2)~%# 						'1 4' = YCbCr4:4:1 (1 4)~%# 						'2 1' = YCbCr4:2:2 (2 1)~%# 						'2 2' = YCbCr4:2:0 (2 2)~%# 						'2 4' = YCbCr4:2:1 (2 4)~%# 						'4 1' = YCbCr4:1:1 (4 1)~%# 						'4 2' = YCbCr4:1:0 (4 2)~%uint16[2] ycb_cr_sub_sampling~%# 0x0213	YCbCrPositioning	int16u!:	IFD0~%# 						1 = Centered~%# 						2 = Co-sited~%uint16 ycb_cr_positioning~%# 0x0214	ReferenceBlackWhite	rational64u[6]	IFD0~%float64[6] reference_black_white~%# 0x022f	StripRowCounts	no	-~%# 0x02bc	ApplicationNotes	int8u!	IFD0	--> XMP Tags~%# 0x03e7	USPTOMiscellaneous	no	-~%# 0x1000	RelatedImageFileFormat	string!	InteropIFD~%# 0x1001	RelatedImageWidth	int16u!	InteropIFD~%# 0x1002	RelatedImageHeight	int16u!	InteropIFD	(called RelatedImageLength by the DCF spec.)~%# 0x4746	Rating	int16u/	IFD0~%# 0x4747	XP_DIP_XML	no	-~%# 0x4748	StitchInfo	-	-	--> Microsoft Stitch Tags~%# 0x4749	RatingPercent	int16u/	IFD0~%# 0x7000	SonyRawFileType	no	-~%# 						0 = Sony Uncompressed 14-bit RAW~%# 						1 = Sony Uncompressed 12-bit RAW~%# 						2 = Sony Compressed RAW~%# 						3 = Sony Lossless Compressed RAW~%# 						4 = Sony Lossless Compressed RAW 2~%# 0x7010	SonyToneCurve	no	-~%# 0x7031	VignettingCorrection	int16s!	SubIFD	(found in Sony ARW images)~%# 						256 = Off~%# 						257 = Auto~%# 						272 = Auto (ILCE-1)~%# 						511 = No correction params available~%# 0x7032	VignettingCorrParams	int16s[17]!	SubIFD	(found in Sony ARW images)~%# 0x7034	ChromaticAberrationCorrection	int16s!	SubIFD	(found in Sony ARW images)~%# 						0 = Off~%# 						1 = Auto~%# 						255 = No correction params available~%# 0x7035	ChromaticAberrationCorrParams	int16s[33]!	SubIFD	(found in Sony ARW images)~%# 0x7036	DistortionCorrection	int16s!	SubIFD	(found in Sony ARW images)~%# 						0 = Off~%# 						1 = Auto~%# 						17 = Auto fixed by lens~%# 						255 = No correction params available~%# 0x7037	DistortionCorrParams	int16s[17]!	SubIFD	(found in Sony ARW images)~%# 0x74c7	SonyCropTopLeft	int32u[2]!	SubIFD~%# 0x74c8	SonyCropSize	int32u[2]!	SubIFD~%# 0x800d	ImageID	no	-~%# 0x80a3	WangTag1	no	-~%# 0x80a4	WangAnnotation	no	-~%# 0x80a5	WangTag3	no	-~%# 0x80a6	WangTag4	no	-~%# 0x80b9	ImageReferencePoints	no	-~%# 0x80ba	RegionXformTackPoint	no	-~%# 0x80bb	WarpQuadrilateral	no	-~%# 0x80bc	AffineTransformMat	no	-~%# 0x80e3	Matteing	no	-~%# 0x80e4	DataType	no	-~%# 0x80e5	ImageDepth	no	-~%# 0x80e6	TileDepth	no	-~%# 0x8214	ImageFullWidth	no	-~%# 0x8215	ImageFullHeight	no	-~%# 0x8216	TextureFormat	no	-~%# 0x8217	WrapModes	no	-~%# 0x8218	FovCot	no	-~%# 0x8219	MatrixWorldToScreen	no	-~%# 0x821a	MatrixWorldToCamera	no	-~%# 0x827d	Model2	no	-~%# 0x828d	CFARepeatPatternDim	int16u[2]!	SubIFD~%# 0x828e	CFAPattern2	int8u[n]!	SubIFD~%# 0x828f	BatteryLevel	no	-~%# 0x8290	KodakIFD	-	-	--> Kodak IFD Tags	(used in various types of Kodak images)~%# 0x8298	Copyright	string	IFD0	(may contain copyright notices for photographer and editor, separated by a newline. As per the EXIF specification, the newline is replaced by a null byte when writing to file, but this may be avoided by disabling the print conversion)~%string copyright~%# 0x829a	ExposureTime	rational64u	ExifIFD~%float64 exposure_time~%# 0x829d	FNumber	rational64u	ExifIFD~%float64 f_number~%# 0x82a5	MDFileTag	no	-	(tags 0x82a5-0x82ac are used in Molecular Dynamics GEL files)~%# 0x82a6	MDScalePixel	no	-~%# 0x82a7	MDColorTable	no	-~%# 0x82a8	MDLabName	no	-~%# 0x82a9	MDSampleInfo	no	-~%# 0x82aa	MDPrepDate	no	-~%# 0x82ab	MDPrepTime	no	-~%# 0x82ac	MDFileUnits	no	-~%# 0x830e	PixelScale	double[3]	IFD0~%# 0x8335	AdventScale	no	-~%# 0x8336	AdventRevision	no	-~%# 0x835c	UIC1Tag	no	-~%# 0x835d	UIC2Tag	no	-~%# 0x835e	UIC3Tag	no	-~%# 0x835f	UIC4Tag	no	-~%# 0x83bb	IPTC-NAA	int32u!	IFD0	--> IPTC Tags~%# 0x847e	IntergraphPacketData	no	-~%# 0x847f	IntergraphFlagRegisters	no	-~%# 0x8480	IntergraphMatrix	double[n]	IFD0~%# 0x8481	INGRReserved	no	-~%# 0x8482	ModelTiePoint	double[n]	IFD0~%# 0x84e0	Site	no	-~%# 0x84e1	ColorSequence	no	-~%# 0x84e2	IT8Header	no	-~%# 0x84e3	RasterPadding	no	-~%# 						0 = Byte~%# 						1 = Word~%# 						2 = Long Word~%# 						9 = Sector~%# 						10 = Long Sector~%# 0x84e4	BitsPerRunLength	no	-~%# 0x84e5	BitsPerExtendedRunLength	no	-~%# 0x84e6	ColorTable	no	-~%# 0x84e7	ImageColorIndicator	no	-~%# 						0 = Unspecified Image Color~%# 						1 = Specified Image Color~%# 0x84e8	BackgroundColorIndicator	no	-~%# 						0 = Unspecified Background Color~%# 						1 = Specified Background Color~%# 0x84e9	ImageColorValue	no	-~%# 0x84ea	BackgroundColorValue	no	-~%# 0x84eb	PixelIntensityRange	no	-~%# 0x84ec	TransparencyIndicator	no	-~%# 0x84ed	ColorCharacterization	no	-~%# 0x84ee	HCUsage	no	-~%# 						0 = CT~%# 						1 = Line Art~%# 						2 = Trap~%# 0x84ef	TrapIndicator	no	-~%# 0x84f0	CMYKEquivalent	no	-~%# 0x8546	SEMInfo	string	IFD0	(found in some scanning electron microscope images)~%# 0x8568	AFCP_IPTC	-	-	--> IPTC Tags~%# 0x85b8	PixelMagicJBIGOptions	no	-~%# 0x85d7	JPLCartoIFD	no	-~%# 0x85d8	ModelTransform	double[16]	IFD0~%# 0x8602	WB_GRGBLevels	no	-	(found in IFD0 of Leaf MOS images)~%# 0x8606	LeafData	-	-	--> Leaf Tags~%# 0x8649	PhotoshopSettings	-	IFD0	--> Photoshop Tags~%# 0x8769	ExifOffset	-	IFD0	--> EXIF Tags~%# 0x8773	ICC_Profile	-	IFD0	--> ICC_Profile Tags~%# 0x877f	TIFF_FXExtensions	no	-~%# 						Bit 0 = Resolution/Image Width~%# 						Bit 1 = N Layer Profile M~%# 						Bit 2 = Shared Data~%# 						Bit 3 = B&W JBIG2~%# 						Bit 4 = JBIG2 Profile M~%# 0x8780	MultiProfiles	no	~%# 						Bit 0 = Profile S~%# 						Bit 1 = Profile F~%# 						Bit 2 = Profile J~%# 						Bit 3 = Profile C~%# 						Bit 4 = Profile L~%# 						Bit 5 = Profile M~%# 						Bit 6 = Profile T~%# 						Bit 7 = Resolution/Image Width~%# 						Bit 8 = N Layer Profile M~%# 						Bit 9 = Shared Data~%# 						Bit 10 = JBIG2 Profile M~%# 0x8781	SharedData	no	-~%# 0x8782	T88Options	no	-~%# 0x87ac	ImageLayer	no	-~%# 0x87af	GeoTiffDirectory	int16u[0.5]	IFD0	(these \"GeoTiff\" tags may read and written as a block, but they aren't extracted unless specifically requested. Byte order changes are handled automatically when copying between TIFF images with different byte order)~%# 0x87b0	GeoTiffDoubleParams	double[0.125]	IFD0	 ~%# 0x87b1	GeoTiffAsciiParams	string	IFD0	 ~%# 0x87be	JBIGOptions	no	-	 ~%# 0x8822	ExposureProgram	int16u	ExifIFD	(the value of 9 is not standard EXIF, but is used by the Canon EOS 7D)~%# 						0 = Not Defined~%# 						1 = Manual~%# 						2 = Program AE~%# 						3 = Aperture-priority AE~%# 						4 = Shutter speed priority AE~%# 						5 = Creative (Slow speed)~%# 						6 = Action (High speed)~%# 						7 = Portrait~%# 						8 = Landscape~%# 						9 = Bulb~%uint16 exposure_program~%# 0x8824	SpectralSensitivity	string	ExifIFD~%# 0x8825	GPSInfo	-	IFD0	--> GPS Tags~%ExifGPSInfo gps_info~%# 0x8827	ISO	int16u[n]	ExifIFD	(called ISOSpeedRatings by EXIF 2.2, then PhotographicSensitivity by the EXIF 2.3 spec.)~%uint16[] iso~%# 0x8828	Opto-ElectricConvFactor	no	-	(called OECF by the EXIF spec.)~%# 0x8829	Interlace	no	-	 ~%# 0x882a	TimeZoneOffset	int16s[n]	ExifIFD	(1 or 2 values: 1. The time zone offset of DateTimeOriginal from GMT in hours, 2. If present, the time zone offset of ModifyDate)~%# 0x882b	SelfTimerMode	int16u	ExifIFD	 ~%# 0x8830	SensitivityType	int16u	ExifIFD	(applies to EXIF:ISO tag)~%# 						0 = Unknown~%# 						1 = Standard Output Sensitivity~%# 						2 = Recommended Exposure Index~%# 						3 = ISO Speed~%# 						4 = Standard Output Sensitivity and Recommended Exposure Index~%# 						5 = Standard Output Sensitivity and ISO Speed~%# 						6 = Recommended Exposure Index and ISO Speed~%# 						7 = Standard Output Sensitivity, Recommended Exposure Index and ISO Speed~%uint16 sensitivity_type~%# 0x8831	StandardOutputSensitivity	int32u	ExifIFD~%uint32 standard_output_sensitivity~%# 0x8832	RecommendedExposureIndex	int32u	ExifIFD~%uint32 recommended_exposure_index~%# 0x8833	ISOSpeed	int32u	ExifIFD~%uint32 iso_speed~%# 0x8834	ISOSpeedLatitudeyyy	int32u	ExifIFD~%uint32 iso_speed_latitudeyyy~%# 0x8835	ISOSpeedLatitudezzz	int32u	ExifIFD~%uint32 iso_speed_latitudezzz~%# 0x885c	FaxRecvParams	no	-~%# 0x885d	FaxSubAddress	no	-~%# 0x885e	FaxRecvTime	no	-~%# 0x8871	FedexEDR	no	-~%# 0x888a	LeafSubIFD	-	-	--> Leaf SubIFD Tags~%# 0x9000	ExifVersion	undef:	ExifIFD~%string exif_version~%# 0x9003	DateTimeOriginal	string	ExifIFD	(date/time when original image was taken)~%string date_time_original~%# 0x9004	CreateDate	string	ExifIFD	(called DateTimeDigitized by the EXIF spec.)~%string date_time_digitized~%# 0x9009	GooglePlusUploadCode	undef[n]	ExifIFD~%# 0x9010	OffsetTime	string	ExifIFD	(time zone for ModifyDate)~%string offset_time~%# 0x9011	OffsetTimeOriginal	string	ExifIFD	(time zone for DateTimeOriginal)~%string offset_time_original~%# 0x9012	OffsetTimeDigitized	string	ExifIFD	(time zone for CreateDate)~%string offset_time_digitized~%# 0x9101	ComponentsConfiguration	undef[4]!:	ExifIFD~%# 						0 = -~%# 						1 = Y~%# 						2 = Cb~%# 						3 = Cr~%# 						4 = R~%# 						5 = G~%# 						6 = B~%uint8[4] components_configuration~%# 0x9102	CompressedBitsPerPixel	rational64u!	ExifIFD~%float64 compressed_bits_per_pixel~%# 0x9201	ShutterSpeedValue	rational64s	ExifIFD	(displayed in seconds, but stored as an APEX value)~%float64 shutter_speed_value~%# 0x9202	ApertureValue	rational64u	ExifIFD	(displayed as an F number, but stored as an APEX value)~%float64 aperture_value~%# 0x9203	BrightnessValue	rational64s	ExifIFD~%float64 brightness_value~%# 0x9204	ExposureCompensation	rational64s	ExifIFD	(called ExposureBiasValue by the EXIF spec.)~%float64 exposure_bias_value~%# 0x9205	MaxApertureValue	rational64u	ExifIFD	(displayed as an F number, but stored as an APEX value)~%float64 max_aperture_value~%# 0x9206	SubjectDistance	rational64u	ExifIFD~%float64 subject_distance~%# 0x9207	MeteringMode	int16u	ExifIFD~%# 						0 = Unknown~%# 						1 = Average~%# 						2 = Center-weighted average~%# 						3 = Spot~%# 						4 = Multi-spot~%# 						5 = Multi-segment~%# 						6 = Partial~%# 						255 = Other~%uint16 metering_mode~%# 0x9208	LightSource	int16u	ExifIFD	--> EXIF LightSource Values~%uint16 light_source~%# 0x9209	Flash	int16u	ExifIFD	--> EXIF Flash Values~%uint16 flash~%# 0x920a	FocalLength	rational64u	ExifIFD~%float64 focal_length~%# 0x920b	FlashEnergy	no	-~%# 0x920c	SpatialFrequencyResponse	no	-~%# 0x920d	Noise	no	-~%# 0x920e	FocalPlaneXResolution	no	-~%# 0x920f	FocalPlaneYResolution	no	-~%# 0x9210	FocalPlaneResolutionUnit	no	-~%# 						1 = None~%# 						2 = inches~%# 						3 = cm~%# 						4 = mm~%# 						5 = um~%# 0x9211	ImageNumber	int32u	ExifIFD~%# 0x9212	SecurityClassification	string	ExifIFD~%# 						'C' = Confidential~%# 						'R' = Restricted~%# 						'S' = Secret~%# 						'T' = Top Secret~%# 						'U' = Unclassified~%# 0x9213	ImageHistory	string	ExifIFD~%# 0x9214	SubjectArea	int16u[n]	ExifIFD~%uint16[] subject_area~%# 0x9215	ExposureIndex	no	-~%# 0x9216	TIFF-EPStandardID	no	-~%# 0x9217	SensingMethod	no	-~%# 						1 = Monochrome area~%# 						2 = One-chip color area~%# 						3 = Two-chip color area~%# 						4 = Three-chip color area~%# 						5 = Color sequential area~%# 						6 = Monochrome linear~%# 						7 = Trilinear~%# 						8 = Color sequential linear~%# 0x923a	CIP3DataFile	no	-~%# 0x923b	CIP3Sheet	no	-~%# 0x923c	CIP3Side	no	-~%# 0x923f	StoNits	no	-~%# 0x927c	MakerNoteApple	undef	ExifIFD	--> Apple Tags~%# 		MakerNoteNikon	undef	ExifIFD	--> Nikon Tags~%# 		MakerNoteCanon	undef	ExifIFD	--> Canon Tags~%# 		MakerNoteCasio	undef	ExifIFD	--> Casio Tags~%# 		MakerNoteCasio2	undef	ExifIFD	--> Casio Type2 Tags~%# 		MakerNoteDJI	undef	ExifIFD	--> DJI Tags~%# 		MakerNoteFLIR	undef	ExifIFD	--> FLIR Tags~%# 		MakerNoteFujiFilm	undef	ExifIFD	--> FujiFilm Tags~%# 		MakerNoteGE	undef	ExifIFD	--> GE Tags~%# 		MakerNoteGE2	undef	ExifIFD	--> FujiFilm Tags~%# 		MakerNoteHasselblad	undef	ExifIFD	--> Unknown Tags~%# 		MakerNoteHP	undef	ExifIFD	--> HP Tags~%# 		MakerNoteHP2	undef	ExifIFD	--> HP Type2 Tags~%# 		MakerNoteHP4	undef	ExifIFD	--> HP Type4 Tags~%# 		MakerNoteHP6	undef	ExifIFD	--> HP Type6 Tags~%# 		MakerNoteISL	undef	ExifIFD	--> Unknown Tags~%# 		MakerNoteJVC	undef	ExifIFD	--> JVC Tags~%# 		MakerNoteJVCText	undef	ExifIFD	--> JVC Text Tags~%# 		MakerNoteKodak1a	undef	ExifIFD	--> Kodak Tags~%# 		MakerNoteKodak1b	undef	ExifIFD	--> Kodak Tags~%# 		MakerNoteKodak2	undef	ExifIFD	--> Kodak Type2 Tags~%# 		MakerNoteKodak3	undef	ExifIFD	--> Kodak Type3 Tags~%# 		MakerNoteKodak4	undef	ExifIFD	--> Kodak Type4 Tags~%# 		MakerNoteKodak5	undef	ExifIFD	--> Kodak Type5 Tags~%# 		MakerNoteKodak6a	undef	ExifIFD	--> Kodak Type6 Tags~%# 		MakerNoteKodak6b	undef	ExifIFD	--> Kodak Type6 Tags~%# 		MakerNoteKodak7	undef	ExifIFD	--> Kodak Type7 Tags~%# 		MakerNoteKodak8a	undef	ExifIFD	--> Kodak Type8 Tags~%# 		MakerNoteKodak8b	undef	ExifIFD	--> Kodak Type8 Tags~%# 		MakerNoteKodak8c	undef	ExifIFD	--> Kodak Type8 Tags~%# 		MakerNoteKodak9	undef	ExifIFD	--> Kodak Type9 Tags~%# 		MakerNoteKodak10	undef	ExifIFD	--> Kodak Type10 Tags~%# 		MakerNoteKodak11	undef	ExifIFD	--> Kodak Type11 Tags~%# 		MakerNoteKodak12	undef	ExifIFD	--> Kodak Type11 Tags~%# 		MakerNoteKodakUnknown	undef	ExifIFD	--> Kodak Unknown Tags~%# 		MakerNoteKyocera	undef	ExifIFD	--> Unknown Tags~%# 		MakerNoteMinolta	undef	ExifIFD	--> Minolta Tags~%# 		MakerNoteMinolta2	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteMinolta3	undef	ExifIFD	(not EXIF-based)~%# 		MakerNoteMotorola	undef	ExifIFD	--> Motorola Tags~%# 		MakerNoteNikon2	undef	ExifIFD	--> Nikon Type2 Tags~%# 		MakerNoteNikon3	undef	ExifIFD	--> Nikon Tags~%# 		MakerNoteNintendo	undef	ExifIFD	--> Nintendo Tags~%# 		MakerNoteOlympus	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteOlympus2	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteLeica	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNoteLeica2	undef	ExifIFD	--> Panasonic Leica2 Tags~%# 		MakerNoteLeica3	undef	ExifIFD	--> Panasonic Leica3 Tags~%# 		MakerNoteLeica4	undef	ExifIFD	--> Panasonic Leica4 Tags~%# 		MakerNoteLeica5	undef	ExifIFD	--> Panasonic Leica5 Tags~%# 		MakerNoteLeica6	undef	ExifIFD	--> Panasonic Leica6 Tags~%# 		MakerNoteLeica7	undef	ExifIFD	--> Panasonic Leica6 Tags~%# 		MakerNoteLeica8	undef	ExifIFD	--> Panasonic Leica5 Tags~%# 		MakerNoteLeica9	undef	ExifIFD	--> Panasonic Leica9 Tags~%# 		MakerNoteLeica10	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNotePanasonic	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNotePanasonic2	undef	ExifIFD	--> Panasonic Type2 Tags~%# 		MakerNotePanasonic3	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNotePentax	undef	ExifIFD	--> Pentax Tags~%# 		MakerNotePentax2	undef	ExifIFD	--> Pentax Type2 Tags~%# 		MakerNotePentax3	undef	ExifIFD	--> Casio Type2 Tags~%# 		MakerNotePentax4	undef	ExifIFD	--> Pentax Type4 Tags~%# 		MakerNotePentax5	undef	ExifIFD	--> Pentax Tags~%# 		MakerNotePentax6	undef	ExifIFD	--> Pentax S1 Tags~%# 		MakerNotePhaseOne	undef	ExifIFD	--> PhaseOne Tags~%# 		MakerNoteReconyx	undef	ExifIFD	--> Reconyx Tags~%# 		MakerNoteReconyx2	undef	ExifIFD	--> Reconyx Type2 Tags~%# 		MakerNoteReconyx3	undef	ExifIFD	--> Reconyx Type3 Tags~%# 		MakerNoteRicohPentax	undef	ExifIFD	--> Pentax Tags~%# 		MakerNoteRicoh	undef	ExifIFD	--> Ricoh Tags~%# 		MakerNoteRicoh2	undef	ExifIFD	--> Ricoh Type2 Tags~%# 		MakerNoteRicohText	undef	ExifIFD	--> Ricoh Text Tags~%# 		MakerNoteSamsung1a	undef	ExifIFD	(Samsung \"STMN\" maker notes without PreviewImage)~%# 		undef	ExifIFD	--> Samsung Tags	MakerNoteSamsung1b~%# 		MakerNoteSamsung2	undef	ExifIFD	--> Samsung Type2 Tags~%# 		MakerNoteSanyo	undef	ExifIFD	--> Sanyo Tags~%# 		MakerNoteSanyoC4	undef	ExifIFD	--> Sanyo Tags~%# 		MakerNoteSanyoPatch	undef	ExifIFD	--> Sanyo Tags~%# 		MakerNoteSigma	undef	ExifIFD	--> Sigma Tags~%# 		MakerNoteSony	undef	ExifIFD	--> Sony Tags~%# 		MakerNoteSony2	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteSony3	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteSony4	undef	ExifIFD	--> Sony PIC Tags~%# 		MakerNoteSony5	undef	ExifIFD	--> Sony Tags~%# 		MakerNoteSonyEricsson	undef	ExifIFD	--> Sony Ericsson Tags~%# 		MakerNoteSonySRF	undef	ExifIFD	--> Sony SRF Tags~%# 		MakerNoteUnknownText	undef	ExifIFD	(unknown text-based maker notes)~%# 		MakerNoteUnknownBinary	undef	ExifIFD	(unknown binary maker notes)~%# 		MakerNoteUnknown	undef	ExifIFD	--> Unknown Tags~%# 0x9286	UserComment	undef	ExifIFD~%string user_comment~%# 0x9290	SubSecTime	string	ExifIFD	(fractional seconds for ModifyDate)~%string subsec_time~%# 0x9291	SubSecTimeOriginal	string	ExifIFD	(fractional seconds for DateTimeOriginal)~%string subsec_time_original~%# 0x9292	SubSecTimeDigitized	string	ExifIFD	(fractional seconds for CreateDate)~%string subsec_time_digitized~%# 0x932f	MSDocumentText	no	-	 ~%# 0x9330	MSPropertySetStorage	no	-~%# 0x9331	MSDocumentTextPosition	no	-~%# 0x935c	ImageSourceData	undef!	IFD0	--> Photoshop DocumentData Tags~%# 0x9400	AmbientTemperature	rational64s	ExifIFD	(ambient temperature in degrees C, called Temperature by the EXIF spec.)~%float64 temperature~%# 0x9401	Humidity	rational64u	ExifIFD	(ambient relative humidity in percent)~%float64 humidity~%# 0x9402	Pressure	rational64u	ExifIFD	(air pressure in hPa or mbar)~%float64 pressure~%# 0x9403	WaterDepth	rational64s	ExifIFD	(depth under water in metres, negative for above water)~%float64 water_depth~%# 0x9404	Acceleration	rational64u	ExifIFD	(directionless camera acceleration in units of mGal, or 10-5 m/s2)~%float64 acceleration~%# 0x9405	CameraElevationAngle	rational64s	ExifIFD~%float64 camera_elevation_angle~%# 0x9c9b	XPTitle	int8u	IFD0	(tags 0x9c9b-0x9c9f are used by Windows Explorer; special characters in these values are converted to UTF-8 by default, or Windows Latin1 with the -L option. XPTitle is ignored by Windows Explorer if ImageDescription exists)~%# 0x9c9c	XPComment	int8u	IFD0~%# 0x9c9d	XPAuthor	int8u	IFD0	(ignored by Windows Explorer if Artist exists)~%# 0x9c9e	XPKeywords	int8u	IFD0~%# 0x9c9f	XPSubject	int8u	IFD0~%# 0xa000	FlashpixVersion	undef:	ExifIFD~%string flash_pix_version~%# 0xa001	ColorSpace	int16u:	ExifIFD	(the value of 0x2 is not standard EXIF. Instead, an Adobe RGB image is indicated by \"Uncalibrated\" with an InteropIndex of \"R03\". The values 0xfffd and 0xfffe are also non-standard, and are used by some Sony cameras)~%# 						0x1 = sRGB~%# 						0x2 = Adobe RGB~%# 						0xfffd = Wide Gamut RGB~%# 						0xfffe = ICC Profile~%# 						0xffff = Uncalibrated~%uint16 color_space~%# 0xa002	ExifImageWidth	int16u:	ExifIFD	(called PixelXDimension by the EXIF spec.)~%uint16 exif_image_width~%# 0xa003	ExifImageHeight	int16u:	ExifIFD	(called PixelYDimension by the EXIF spec.)~%uint16 exif_image_height~%# 0xa004	RelatedSoundFile	string	ExifIFD~%string related_sound_file~%# 0xa005	InteropOffset	-	-	--> EXIF Tags~%# 0xa010	SamsungRawPointersOffset	no	-~%# 0xa011	SamsungRawPointersLength	no	-~%# 0xa101	SamsungRawByteOrder	no	-~%# 0xa102	SamsungRawUnknown?	no	-~%# 0xa20b	FlashEnergy	rational64u	ExifIFD~%float64 flash_energy~%# 0xa20c	SpatialFrequencyResponse	no	-~%# 0xa20d	Noise	no	-	 ~%# 0xa20e	FocalPlaneXResolution	rational64u	ExifIFD~%float64 focal_plane_x_resolution~%# 0xa20f	FocalPlaneYResolution	rational64u	ExifIFD~%float64 focal_plane_y_resolution~%# 0xa210	FocalPlaneResolutionUnit	int16u	ExifIFD	(values 1, 4 and 5 are not standard EXIF)~%# 						1 = None~%# 						2 = inches~%# 						3 = cm~%# 						4 = mm~%# 						5 = um~%uint16 focal_plane_resolution_unit~%# 0xa211	ImageNumber	no	-~%# 0xa212	SecurityClassification	no	-~%# 0xa213	ImageHistory	no	-~%# 0xa214	SubjectLocation	int16u[2]	ExifIFD~%uint16[2] subject_location~%# 0xa215	ExposureIndex	rational64u	ExifIFD~%float64 exposure_index~%# 0xa216	TIFF-EPStandardID	no	-~%# 0xa217	SensingMethod	int16u	ExifIFD~%# 						1 = Not defined~%# 						2 = One-chip color area~%# 						3 = Two-chip color area~%# 						4 = Three-chip color area~%# 						5 = Color sequential area~%# 						7 = Trilinear~%# 						8 = Color sequential linear~%uint16 sensing_method~%# 0xa300	FileSource	undef	ExifIFD~%# 						1 = Film Scanner~%# 						2 = Reflection Print Scanner~%# 						3 = Digital Camera~%# 						\"\\x03\\x00\\x00\\x00\" = Sigma Digital Camera~%# 0xa301	SceneType	undef	ExifIFD	1 = Directly photographed~%string scene_type~%# 0xa302	CFAPattern	undef	ExifIFD~%# 0xa401	CustomRendered	int16u	ExifIFD	(only 0 and 1 are standard EXIF, but other values are used by Apple iOS devices)~%# 						0 = Normal~%# 						1 = Custom~%# 						2 = HDR (no original saved)~%# 						3 = HDR (original saved)~%# 						4 = Original (for HDR)~%# 						6 = Panorama~%# 						7 = Portrait HDR~%# 						8 = Portrait~%uint16 custom_rendered~%# 0xa402	ExposureMode	int16u	ExifIFD~%# 						0 = Auto~%# 						1 = Manual~%# 						2 = Auto bracket~%uint16 exposure_mode~%# 0xa403	WhiteBalance	int16u	ExifIFD~%# 						0 = Auto~%# 						1 = Manual~%uint16 white_balance~%# 0xa404	DigitalZoomRatio	rational64u	ExifIFD~%float64 digital_zoom_ratio~%# 0xa405	FocalLengthIn35mmFormat	int16u	ExifIFD	(called FocalLengthIn35mmFilm by the EXIF spec.)~%uint16 focal_length_in_35mm_film~%# 0xa406	SceneCaptureType	int16u	ExifIFD	(the value of 4 is non-standard, and used by some Samsung models)~%# 						0 = Standard~%# 						1 = Landscape~%# 						2 = Portrait~%# 						3 = Night~%# 						4 = Other~%uint16 scene_capture_type~%# 0xa407	GainControl	int16u	ExifIFD~%# 						0 = None~%# 						1 = Low gain up~%# 						2 = High gain up~%# 						3 = Low gain down~%# 						4 = High gain down~%uint16 gain_control~%# 0xa408	Contrast	int16u	ExifIFD~%# 						0 = Normal~%# 						1 = Low~%# 						2 = High~%uint16 contrast~%# 0xa409	Saturation	int16u	ExifIFD~%# 						0 = Normal~%# 						1 = Low~%# 						2 = High~%uint16 saturation~%# 0xa40a	Sharpness	int16u	ExifIFD~%# 						0 = Normal~%# 						1 = Soft~%# 						2 = Hard~%uint16 sharpness~%# 0xa40b	DeviceSettingDescription	no	-	 ~%# 0xa40c	SubjectDistanceRange	int16u	ExifIFD~%# 						0 = Unknown~%# 						1 = Macro~%# 						2 = Close~%# 						3 = Distant~%uint16 subject_distance_range~%# 0xa420	ImageUniqueID	string	ExifIFD~%string image_unique_id~%# 0xa430	OwnerName	string	ExifIFD	(called CameraOwnerName by the EXIF spec.)~%string camera_owner_name~%# 0xa431	SerialNumber	string	ExifIFD	(called BodySerialNumber by the EXIF spec.)~%string body_serial_number~%# 0xa432	LensInfo	rational64u[4]	ExifIFD	(4 rational values giving focal and aperture ranges, called LensSpecification by the EXIF spec.)~%float64[4] lens_specification~%# 0xa433	LensMake	string	ExifIFD~%string lens_make~%# 0xa434	LensModel	string	ExifIFD~%string lens_model~%# 0xa435	LensSerialNumber	string	ExifIFD~%string lens_serial_number~%# 0xa460	CompositeImage	int16u	ExifIFD~%# 						0 = Unknown~%# 						1 = Not a Composite Image~%# 						2 = General Composite Image~%# 						3 = Composite Image Captured While Shooting~%uint16 composite_image~%# 0xa461	CompositeImageCount	int16u[2]	ExifIFD	(2 values: 1. Number of source images, 2. Number of images used. Called SourceImageNumberOfCompositeImage by the EXIF spec.)~%# 0xa462	CompositeImageExposureTimes	undef	ExifIFD	(11 or more values: 1. Total exposure time period, 2. Total exposure of all source images, 3. Total exposure of all used images, 4. Max exposure time of source images, 5. Max exposure time of used images, 6. Min exposure time of source images, 7. Min exposure of used images, 8. Number of sequences, 9. Number of source images in sequence. 10-N. Exposure times of each source image. Called SourceExposureTimesOfCompositeImage by the EXIF spec.)~%uint16[2] composite_image_count~%# 0xa480	GDALMetadata	string	IFD0~%# 0xa481	GDALNoData	string	IFD0~%# 0xa500	Gamma	rational64u	ExifIFD~%float64 gamma~%# 0xafc0	ExpandSoftware	no	-~%# 0xafc1	ExpandLens	no	-~%# 0xafc2	ExpandFilm	no	-~%# 0xafc3	ExpandFilterLens	no	-~%# 0xafc4	ExpandScanner	no	-~%# 0xafc5	ExpandFlashLamp	no	-~%# 0xb4c3	HasselbladRawImage	no	-~%# 0xbc01	PixelFormat	no	-	(tags 0xbc** are used in Windows HD Photo (HDP and WDP) images. The actual PixelFormat values are 16-byte GUID's but the leading 15 bytes, '6fddc324-4e03-4bfe-b1853-d77768dc9', have been removed below to avoid unnecessary clutter)~%# 						0x5 = Black & White~%# 						0x8 = 8-bit Gray~%# 						0x9 = 16-bit BGR555~%# 						0xa = 16-bit BGR565~%# 						0xb = 16-bit Gray~%# 						0xc = 24-bit BGR~%# 						0xd = 24-bit RGB~%# 						0xe = 32-bit BGR~%# 						0xf = 32-bit BGRA~%# 						0x10 = 32-bit PBGRA~%# 						0x11 = 32-bit Gray Float~%# 						0x12 = 48-bit RGB Fixed Point~%# 						0x13 = 32-bit BGR101010~%# 						0x15 = 48-bit RGB~%# 						0x16 = 64-bit RGBA~%# 						0x17 = 64-bit PRGBA~%# 						0x18 = 96-bit RGB Fixed Point~%# 						0x19 = 128-bit RGBA Float~%# 						0x1a = 128-bit PRGBA Float~%# 						0x1b = 128-bit RGB Float~%# 						0x1c = 32-bit CMYK~%# 						0x1d = 64-bit RGBA Fixed Point~%# 						0x1e = 128-bit RGBA Fixed Point~%# 						0x1f = 64-bit CMYK~%# 						0x20 = 24-bit 3 Channels~%# 						0x21 = 32-bit 4 Channels~%# 						0x22 = 40-bit 5 Channels~%# 						0x23 = 48-bit 6 Channels~%# 						0x24 = 56-bit 7 Channels~%# 						0x25 = 64-bit 8 Channels~%# 						0x26 = 48-bit 3 Channels~%# 						0x27 = 64-bit 4 Channels~%# 						0x28 = 80-bit 5 Channels~%# 						0x29 = 96-bit 6 Channels~%# 						0x2a = 112-bit 7 Channels~%# 						0x2b = 128-bit 8 Channels~%# 						0x2c = 40-bit CMYK Alpha~%# 						0x2d = 80-bit CMYK Alpha~%# 						0x2e = 32-bit 3 Channels Alpha~%# 						0x2f = 40-bit 4 Channels Alpha~%# 						0x30 = 48-bit 5 Channels Alpha~%# 						0x31 = 56-bit 6 Channels Alpha~%# 						0x32 = 64-bit 7 Channels Alpha~%# 						0x33 = 72-bit 8 Channels Alpha~%# 						0x34 = 64-bit 3 Channels Alpha~%# 						0x35 = 80-bit 4 Channels Alpha~%# 						0x36 = 96-bit 5 Channels Alpha~%# 						0x37 = 112-bit 6 Channels Alpha~%# 						0x38 = 128-bit 7 Channels Alpha~%# 						0x39 = 144-bit 8 Channels Alpha~%# 						0x3a = 64-bit RGBA Half~%# 						0x3b = 48-bit RGB Half~%# 						0x3d = 32-bit RGBE~%# 						0x3e = 16-bit Gray Half~%# 						0x3f = 32-bit Gray Fixed Point~%# 0xbc02	Transformation	no	-	~%# 						0 = Horizontal (normal)~%# 						1 = Mirror vertical~%# 						2 = Mirror horizontal~%# 						3 = Rotate 180~%# 						4 = Rotate 90 CW~%# 						5 = Mirror horizontal and rotate 90 CW~%# 						6 = Mirror horizontal and rotate 270 CW~%# 						7 = Rotate 270 CW~%# 0xbc03	Uncompressed	no	-~%# 						0 = No~%# 						1 = Yes~%# 0xbc04	ImageType	no	-~%# 						Bit 0 = Preview~%# 						Bit 1 = Page~%# 0xbc80	ImageWidth	no	-~%# 0xbc81	ImageHeight	no	-~%# 0xbc82	WidthResolution	no	-~%# 0xbc83	HeightResolution	no	-~%# 0xbcc0	ImageOffset	no	-~%# 0xbcc1	ImageByteCount	no	-~%# 0xbcc2	AlphaOffset	no	-~%# 0xbcc3	AlphaByteCount	no	-~%# 0xbcc4	ImageDataDiscard	no	-~%# 						0 = Full Resolution~%# 						1 = Flexbits Discarded~%# 						2 = HighPass Frequency Data Discarded~%# 						3 = Highpass and LowPass Frequency Data Discarded~%# 0xbcc5	AlphaDataDiscard	no	-~%# 						0 = Full Resolution~%# 						1 = Flexbits Discarded~%# 						2 = HighPass Frequency Data Discarded~%# 						3 = Highpass and LowPass Frequency Data Discarded~%# 0xc427	OceScanjobDesc	no	-~%# 0xc428	OceApplicationSelector	no	-~%# 0xc429	OceIDNumber	no	-~%# 0xc42a	OceImageLogic	no	-~%# 0xc44f	Annotations	no	-~%# 0xc4a5	PrintIM	undef	IFD0	--> PrintIM Tags~%# 0xc51b	HasselbladExif	no	-~%# 0xc573	OriginalFileName	no	-	(used by some obscure software)~%# 0xc580	USPTOOriginalContentType	no	-~%# 						0 = Text or Drawing~%# 						1 = Grayscale~%# 						2 = Color~%# 0xc5e0	CR2CFAPattern	no	-~%# 						1 => '0 1 1 2' = [Red,Green][Green,Blue]~%# 						4 => '1 0 2 1' = [Green,Red][Blue,Green]~%# 						3 => '1 2 0 1' = [Green,Blue][Red,Green]~%# 						2 => '2 1 1 0' = [Blue,Green][Green,Red]~%# 0xc612	DNGVersion	int8u[4]!	IFD0	(tags 0xc612-0xcd3b are defined by the DNG specification unless otherwise noted. See https://helpx.adobe.com/photoshop/digital-negative.html for the specification)~%# 0xc613	DNGBackwardVersion	int8u[4]!	IFD0~%# 0xc614	UniqueCameraModel	string	IFD0~%# 0xc615	LocalizedCameraModel	string	IFD0~%# 0xc616	CFAPlaneColor	no	SubIFD~%# 0xc617	CFALayout	no	SubIFD~%# 						1 = Rectangular~%# 						2 = Even columns offset down 1/2 row~%# 						3 = Even columns offset up 1/2 row~%# 						4 = Even rows offset right 1/2 column~%# 						5 = Even rows offset left 1/2 column~%# 						6 = Even rows offset up by 1/2 row, even columns offset left by 1/2 column~%# 						7 = Even rows offset up by 1/2 row, even columns offset right by 1/2 column~%# 						8 = Even rows offset down by 1/2 row, even columns offset left by 1/2 column~%# 						9 = Even rows offset down by 1/2 row, even columns offset right by 1/2 column~%# 0xc618	LinearizationTable	int16u[n]!	SubIFD~%# 0xc619	BlackLevelRepeatDim	int16u[2]!	SubIFD~%# 0xc61a	BlackLevel	rational64u[n]!	SubIFD~%# 0xc61b	BlackLevelDeltaH	rational64s[n]!	SubIFD~%# 0xc61c	BlackLevelDeltaV	rational64s[n]!	SubIFD~%# 0xc61d	WhiteLevel	int32u[n]!	SubIFD~%# 0xc61e	DefaultScale	rational64u[2]!	SubIFD~%# 0xc61f	DefaultCropOrigin	int32u[2]!	SubIFD~%# 0xc620	DefaultCropSize	int32u[2]!	SubIFD~%# 0xc621	ColorMatrix1	rational64s[n]!	IFD0~%# 0xc622	ColorMatrix2	rational64s[n]!	IFD0~%# 0xc623	CameraCalibration1	rational64s[n]!	IFD0~%# 0xc624	CameraCalibration2	rational64s[n]!	IFD0~%# 0xc625	ReductionMatrix1	rational64s[n]!	IFD0~%# 0xc626	ReductionMatrix2	rational64s[n]!	IFD0~%# 0xc627	AnalogBalance	rational64u[n]!	IFD0~%# 0xc628	AsShotNeutral	rational64u[n]!	IFD0~%# 0xc629	AsShotWhiteXY	rational64u[2]!	IFD0~%# 0xc62a	BaselineExposure	rational64s!	IFD0~%# 0xc62b	BaselineNoise	rational64u!	IFD0~%# 0xc62c	BaselineSharpness	rational64u!	IFD0~%# 0xc62d	BayerGreenSplit	int32u!	SubIFD~%# 0xc62e	LinearResponseLimit	rational64u!	IFD0~%# 0xc62f	CameraSerialNumber	string	IFD0~%# 0xc630	DNGLensInfo	rational64u[4]	IFD0~%# 0xc631	ChromaBlurRadius	rational64u!	SubIFD~%# 0xc632	AntiAliasStrength	rational64u!	SubIFD~%# 0xc633	ShadowScale	rational64u!	IFD0~%# 0xc634	SR2Private	-	IFD0	--> Sony SR2Private Tags~%# 						DNGAdobeData	undef!	IFD0	--> DNG AdobeData Tags~%# 						MakerNotePentax	-	IFD0	--> Pentax Tags~%# 						MakerNotePentax5	-	IFD0	--> Pentax Tags~%# 						MakerNoteRicohPentax	-	IFD0	--> Pentax Tags~%# 						DNGPrivateData	-	IFD0~%# 0xc635	MakerNoteSafety	int16u	IFD0~%# 						0 = Unsafe~%# 						1 = Safe~%# 0xc640	RawImageSegmentation	no	-	(used in segmented Canon CR2 images. 3 numbers: 1. Number of segments minus one; 2. Pixel width of segments except last; 3. Pixel width of last segment)~%# 0xc65a	CalibrationIlluminant1	int16u!	IFD0	--> EXIF LightSource Values~%# 0xc65b	CalibrationIlluminant2	int16u!	IFD0	--> EXIF LightSource Values~%# 0xc65c	BestQualityScale	rational64u!	SubIFD~%# 0xc65d	RawDataUniqueID	int8u[16]!	IFD0~%# 0xc660	AliasLayerMetadata	no	-	(used by Alias Sketchbook Pro)~%# 0xc68b	OriginalRawFileName	string!	IFD0~%# 0xc68c	OriginalRawFileData	undef!	IFD0	--> DNG OriginalRaw Tags~%# 0xc68d	ActiveArea	int32u[4]!	SubIFD~%# 0xc68e	MaskedAreas	int32u[n]!	SubIFD~%# 0xc68f	AsShotICCProfile	undef!	IFD0	--> ICC_Profile Tags~%# 0xc690	AsShotPreProfileMatrix	rational64s[n]!	IFD0~%# 0xc691	CurrentICCProfile	undef!	IFD0	--> ICC_Profile Tags~%# 0xc692	CurrentPreProfileMatrix	rational64s[n]!	IFD0~%# 0xc6bf	ColorimetricReference	int16u!	IFD0~%# 0xc6c5	SRawType	no	IFD0~%# 0xc6d2	PanasonicTitle	undef	IFD0	(proprietary Panasonic tag used for baby/pet name, etc)~%# 0xc6d3	PanasonicTitle2	undef	IFD0	(proprietary Panasonic tag used for baby/pet name with age)~%# 0xc6f3	CameraCalibrationSig	string!	IFD0~%# 0xc6f4	ProfileCalibrationSig	string!	IFD0~%# 0xc6f5	ProfileIFD	-	IFD0	--> EXIF Tags~%# 0xc6f6	AsShotProfileName	string!	IFD0~%# 0xc6f7	NoiseReductionApplied	rational64u!	SubIFD~%# 0xc6f8	ProfileName	string!	IFD0~%# 0xc6f9	ProfileHueSatMapDims	int32u[3]!	IFD0~%# 0xc6fa	ProfileHueSatMapData1	float[n]!	IFD0~%# 0xc6fb	ProfileHueSatMapData2	float[n]!	IFD0~%# 0xc6fc	ProfileToneCurve	float[n]!	IFD0~%# 0xc6fd	ProfileEmbedPolicy	int32u!	IFD0~%# 						0 = Allow Copying~%# 						1 = Embed if Used~%# 						2 = Never Embed~%# 						3 = No Restrictions~%# 0xc6fe	ProfileCopyright	string!	IFD0~%# 0xc714	ForwardMatrix1	rational64s[n]!	IFD0~%# 0xc715	ForwardMatrix2	rational64s[n]!	IFD0~%# 0xc716	PreviewApplicationName	string!	IFD0~%# 0xc717	PreviewApplicationVersion	string!	IFD0~%# 0xc718	PreviewSettingsName	string!	IFD0~%# 0xc719	PreviewSettingsDigest	int8u!	IFD0~%# 0xc71a	PreviewColorSpace	int32u!	IFD0~%# 						0 = Unknown~%# 						1 = Gray Gamma 2.2~%# 						2 = sRGB~%# 						3 = Adobe RGB~%# 						4 = ProPhoto RGB~%# 0xc71b	PreviewDateTime	string!	IFD0~%# 0xc71c	RawImageDigest	int8u[16]!	IFD0~%# 0xc71d	OriginalRawFileDigest	int8u[16]!	IFD0~%# 0xc71e	SubTileBlockSize	no	-~%# 0xc71f	RowInterleaveFactor	no	-~%# 0xc725	ProfileLookTableDims	int32u[3]!	IFD0~%# 0xc726	ProfileLookTableData	float[n]!	IFD0~%# 0xc740	OpcodeList1	undef!	SubIFD~%# 						1 = WarpRectilinear~%# 						2 = WarpFisheye~%# 						3 = FixVignetteRadial~%# 						4 = FixBadPixelsConstant~%# 						5 = FixBadPixelsList~%# 						6 = TrimBounds~%# 						7 = MapTable~%# 						8 = MapPolynomial~%# 						9 = GainMap~%# 						10 = DeltaPerRow~%# 						11 = DeltaPerColumn~%# 						12 = ScalePerRow~%# 						13 = ScalePerColumn~%# 						14 = WarpRectilinear2~%# 0xc741	OpcodeList2	undef!	SubIFD	~%# 						1 = WarpRectilinear~%# 						2 = WarpFisheye~%# 						3 = FixVignetteRadial~%# 						4 = FixBadPixelsConstant~%# 						5 = FixBadPixelsList~%# 						6 = TrimBounds~%# 						7 = MapTable~%# 						8 = MapPolynomial~%# 						9 = GainMap~%# 						10 = DeltaPerRow~%# 						11 = DeltaPerColumn~%# 						12 = ScalePerRow~%# 						13 = ScalePerColumn~%# 						14 = WarpRectilinear2~%# 0xc74e	OpcodeList3	undef!	SubIFD	~%# 						1 = WarpRectilinear~%# 						2 = WarpFisheye~%# 						3 = FixVignetteRadial~%# 						4 = FixBadPixelsConstant~%# 						5 = FixBadPixelsList~%# 						6 = TrimBounds~%# 						7 = MapTable~%# 						8 = MapPolynomial~%# 						9 = GainMap~%# 						10 = DeltaPerRow~%# 						11 = DeltaPerColumn~%# 						12 = ScalePerRow~%# 						13 = ScalePerColumn~%# 						14 = WarpRectilinear2~%# 0xc761	NoiseProfile	double[n]!	SubIFD~%# 0xc763	TimeCodes	int8u[n]	IFD0~%# 0xc764	FrameRate	rational64s	IFD0~%# 0xc772	TStop	rational64u[n]	IFD0~%# 0xc789	ReelName	string	IFD0~%# 0xc791	OriginalDefaultFinalSize	int32u[2]!	IFD0~%# 0xc792	OriginalBestQualitySize	int32u[2]!	IFD0	(called OriginalBestQualityFinalSize by the DNG spec)~%# 0xc793	OriginalDefaultCropSize	rational64u[2]!	IFD0~%# 0xc7a1	CameraLabel	string	IFD0~%# 0xc7a3	ProfileHueSatMapEncoding	int32u!	IFD0~%# 						0 = Linear~%# 						1 = sRGB~%# 0xc7a4	ProfileLookTableEncoding	int32u!	IFD0~%# 						0 = Linear~%# 						1 = sRGB~%# 0xc7a5	BaselineExposureOffset	rational64s!	IFD0~%# 0xc7a6	DefaultBlackRender	int32u!	IFD0~%# 						0 = Auto~%# 						1 = None~%# 0xc7a7	NewRawImageDigest	int8u[16]!	IFD0~%# 0xc7a8	RawToPreviewGain	double!	IFD0~%# 0xc7aa	CacheVersion	int32u!	SubIFD2~%# 0xc7b5	DefaultUserCrop	rational64u[4]!	SubIFD~%# 0xc7d5	NikonNEFInfo	-	-	--> Nikon NEFInfo Tags~%# 0xc7e9	DepthFormat	int16u!	IFD0	(tags 0xc7e9-0xc7ee added by DNG 1.5.0.0)~%# 						0 = Unknown~%# 						1 = Linear~%# 						2 = Inverse~%# 0xc7ea	DepthNear	rational64u!	IFD0~%# 0xc7eb	DepthFar	rational64u!	IFD0~%# 0xc7ec	DepthUnits	int16u!	IFD0~%# 						0 = Unknown~%# 						1 = Meters~%# 0xc7ed	DepthMeasureType	int16u!	IFD0~%# 						0 = Unknown~%# 						1 = Optical Axis~%# 						2 = Optical Ray~%# 0xc7ee	EnhanceParams	string!	IFD0~%# 0xcd2d	ProfileGainTableMap	undef!	SubIFD~%# 0xcd2e	SemanticName	no	SubIFD~%# 0xcd30	SemanticInstanceIFD	no	SubIFD~%# 0xcd31	CalibrationIlluminant3	int16u!	IFD0	--> EXIF LightSource Values~%# 0xcd32	CameraCalibration3	rational64s[n]!	IFD0~%# 0xcd33	ColorMatrix3	rational64s[n]!	IFD0~%# 0xcd34	ForwardMatrix3	rational64s[n]!	IFD0~%# 0xcd35	IlluminantData1	undef!	IFD0~%# 0xcd36	IlluminantData2	undef!	IFD0~%# 0xcd37	IlluminantData3	undef!	IFD0~%# 0xcd38	MaskSubArea	no	SubIFD~%# 0xcd39	ProfileHueSatMapData3	float[n]!	IFD0~%# 0xcd3a	ReductionMatrix3	rational64s[n]!	IFD0~%# 0xcd3b	RGBTables	undef!	IFD0~%# 0xea1c	Padding	undef!	ExifIFD~%# 0xea1d	OffsetSchema	int32s!	ExifIFD	(Microsoft's ill-conceived maker note offset difference)~%# 0xfde8	OwnerName	string/	ExifIFD	(tags 0xfde8-0xfdea and 0xfe4c-0xfe58 are generated by Photoshop Camera RAW. Some names are the same as other EXIF tags, but ExifTool will avoid writing these unless they already exist in the file)~%# 0xfde9	SerialNumber	string/	ExifIFD~%# 0xfdea	Lens	string/	ExifIFD~%# 0xfe00	KDC_IFD	-	-	--> Kodak KDC_IFD Tags# (used in some Kodak KDC images)~%# 0xfe4c	RawFile	string/	ExifIFD~%# 0xfe4d	Converter	string/	ExifIFD~%# 0xfe4e	WhiteBalance	string/	ExifIFD~%# 0xfe51	Exposure	string/	ExifIFD~%# 0xfe52	Shadows	string/	ExifIFD~%# 0xfe53	Brightness	string/	ExifIFD~%# 0xfe54	Contrast	string/	ExifIFD~%# 0xfe55	Saturation	string/	ExifIFD~%# 0xfe56	Sharpness	string/	ExifIFD~%# 0xfe57	Smoothness	string/	ExifIFD~%# 0xfe58	MoireFilter	string/	ExifIFD~%~%================================================================================~%MSG: jsk_recognition_msgs/ExifGPSInfo~%#~%# https://exiftool.org/TagNames/GPS.html~%#~%# Tag ID	Tag Name	Writable	Values / Notes~%# 0x0000	GPSVersionID	int8u[4]:~%uint8[4] gps_version_id~%# 0x0001	GPSLatitudeRef	string[2]	(tags 0x0001-0x0006 used for camera location according to MWG 2.0. ExifTool will also accept a number when writing GPSLatitudeRef, positive for north latitudes or negative for south, or a string containing N, North, S or South)~%# 						'N' = North~%# 						'S' = South~%string gps_latitude_ref~%# 0x0002	GPSLatitude	rational64u[3]~%float64[3] gps_latitude~%# 0x0003	GPSLongitudeRef	string[2]	(ExifTool will also accept a number when writing this tag, positive for east longitudes or negative for west, or a string containing E, East, W or West)~%# 						'E' = East~%# 						'W' = West~%string gps_longitude_ref~%# 0x0004	GPSLongitude	rational64u[3]~%float64[3] gps_longitude~%# 0x0005	GPSAltitudeRef	int8u	(ExifTool will also accept number when writing this tag, with negative numbers indicating below sea level)~%uint8 gps_altitude_ref~%# 						0 = Above Sea Level~%# 						1 = Below Sea Level~%# 0x0006	GPSAltitude	rational64u~%float64 gps_altitude~%# 0x0007	GPSTimeStamp	rational64u[3]	(UTC time of GPS fix. When writing, date is stripped off if present, and time is adjusted to UTC if it includes a timezone)~%float64 gps_time_stamp~%# 0x0008	GPSSatellites	string~%string gps_satellites~%# 0x0009	GPSStatus	string[2]~%# 						'A' = Measurement Active~%# 						'V' = Measurement Void~%string gps_status~%# 0x000a	GPSMeasureMode	string[2]~%# 						2 = 2-Dimensional Measurement~%# 						3 = 3-Dimensional Measurement~%string gps_measure_mode~%# 0x000b	GPSDOP	rational64u~%float64 gpf_sdop~%# 0x000c	GPSSpeedRef	string[2]~%# 						'K' = km/h~%# 						'M' = mph~%# 						'N' = knots~%string gps_speed_ref~%# 0x000d	GPSSpeed	rational64u~%float64 gps_speed~%# 0x000e	GPSTrackRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_track_ref~%# 0x000f	GPSTrack	rational64u~%float64 gps_track~%# 0x0010	GPSImgDirectionRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_img_direction_ref~%# 0x0011	GPSImgDirection	rational64u~%float64 gps_img_direction~%# 0x0012	GPSMapDatum	string~%string gps_map_datum~%# 0x0013	GPSDestLatitudeRef	string[2]	(tags 0x0013-0x001a used for subject location according to MWG 2.0)~%# 						'N' = North~%# 						'S' = South~%string gps_dest_latitude_ref~%# 0x0014	GPSDestLatitude	rational64u[3]~%float64[3] gps_dest_latitude~%# 0x0015	GPSDestLongitudeRef	string[2]~%# 						'E' = East~%# 						'W' = West~%string gps_dest_longitude_ref~%# 0x0016	GPSDestLongitude	rational64u[3]~%float64[3] gps_dest_longitude~%# 0x0017	GPSDestBearingRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_dest_bearing_ref~%# 0x0018	GPSDestBearing	rational64u~%float64 gps_dest_bearing~%# 0x0019	GPSDestDistanceRef	string[2]~%# 						'K' = Kilometers~%# 						'M' = Miles~%# 						'N' = Nautical Miles~%string gps_dest_distance_ref~%# 0x001a	GPSDestDistance	rational64u~%float64 gps_dest_distance~%# 0x001b	GPSProcessingMethod	undef	(values of \"GPS\", \"CELLID\", \"WLAN\" or \"MANUAL\" by the EXIF spec.)~%# 0x001c	GPSAreaInformation	undef~%# 0x001d	GPSDateStamp	string[11]	(when writing, time is stripped off if present, after adjusting date/time to UTC if time includes a timezone. Format is YYYY:mm:dd)~%string gps_date_stamp~%# 0x001e	GPSDifferential	int16u~%# 						0 = No Correction~%# 						1 = Differential Corrected~%uint16 gps_differential~%# 0x001f	GPSHPositioningError	rational64u~%float64 gps_hpositioning_error~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'ExifTags)))
  "Returns full string definition for message of type 'ExifTags"
  (cl:format cl:nil "# https://exiftool.org/TagNames/EXIF.html~%#~%# Tag ID	Tag Name	Writable	Group	Values / Notes~%#~%# 0x0001	InteropIndex	string!	InteropIFD~%string interop_index~%# 						'R03' = R03 - DCF option file (Adobe RGB)~%# 						'R98' = R98 - DCF basic file (sRGB)~%# 						'THM' = THM - DCF thumbnail file~%# 0x0002	InteropVersion	undef!:	InteropIFD~%# 0x000b	ProcessingSoftware	string	IFD0	(used by ACD Systems Digital Imaging)~%# 0x00fe	SubfileType	int32u!	IFD0	(called NewSubfileType by the TIFF specification)~%# 						0x0 = Full-resolution image~%# 						0x1 = Reduced-resolution image~%# 						0x2 = Single page of multi-page image~%# 						0x3 = Single page of multi-page reduced-resolution image~%# 						0x4 = Transparency mask~%# 						0x5 = Transparency mask of reduced-resolution image~%# 						0x6 = Transparency mask of multi-page image~%# 						0x7 = Transparency mask of reduced-resolution multi-page image~%# 						0x8 = Depth map~%# 						0x9 = Depth map of reduced-resolution image~%# 						0x10 = Enhanced image data~%# 						0x10001 = Alternate reduced-resolution image~%# 						0x10004 = Semantic Mask~%# 						0xffffffff = invalid~%# 						Bit 0 = Reduced resolution~%# 						Bit 1 = Single page~%# 						Bit 2 = Transparency mask~%# 						Bit 3 = TIFF/IT final page~%# 						Bit 4 = TIFF-FX mixed raster content~%# 0x00ff	OldSubfileType	int16u!	IFD0	(called SubfileType by the TIFF specification)~%# 						1 = Full-resolution image~%# 						2 = Reduced-resolution image~%# 						3 = Single page of multi-page image~%# 0x0100	ImageWidth	int32u!	IFD0	 ~%uint32 image_width~%# 0x0101	ImageHeight	int32u!	IFD0	(called ImageLength by the EXIF spec.)~%uint32 image_height~%# 0x0102	BitsPerSample	int16u[n]!	IFD0~%uint16[] bits_per_sample~%# 0x0103	Compression	int16u!:	IFD0	--> EXIF Compression Values~%# 0x0106	PhotometricInterpretation	int16u!	IFD0~%# 						0 = WhiteIsZero~%# 						1 = BlackIsZero~%# 						2 = RGB~%# 						3 = RGB Palette~%# 						4 = Transparency Mask~%# 						5 = CMYK~%# 						6 = YCbCr~%# 						8 = CIELab~%# 						9 = ICCLab~%# 						10 = ITULab~%# 						32803 = Color Filter Array~%# 						32844 = Pixar LogL~%# 						32845 = Pixar LogLuv~%# 						32892 = Sequential Color Filter~%# 						34892 = Linear Raw~%# 						51177 = Depth Map~%# 						52527 = Semantic Mask~%uint16 photometric_interpretation~%# 0x0107	Thresholding	int16u!	IFD0~%# 						1 = No dithering or halftoning~%# 						2 = Ordered dither or halftone~%# 						3 = Randomized dither~%# 0x0108	CellWidth	int16u!	IFD0~%# 0x0109	CellLength	int16u!	IFD0~%# 0x010a	FillOrder	int16u!	IFD0~%# 						1 = Normal~%# 						2 = Reversed~%# 0x010d	DocumentName	string	IFD0~%# 0x010e	ImageDescription	string	IFD0~%string image_description~%# 0x010f	Make	string	IFD0~%string make~%# 0x0110	Model	string	IFD0~%string model~%# 0x0111	StripOffsets	(called StripOffsets in most locations, but it is PreviewImageStart in IFD0 of CR2 images and various IFD's of DNG images except for SubIFD2 where it is JpgFromRawStart)~%# 						PreviewImageStart	int32u*	IFD0~%# 						PreviewImageStart	int32u*	All~%# 						JpgFromRawStart	int32u*	SubIFD2~%uint32 strip_offsets~%# 0x0112	Orientation	int16u	IFD0	~%# 						1 = Horizontal (normal)~%# 						2 = Mirror horizontal~%# 						3 = Rotate 180~%# 						4 = Mirror vertical~%# 						5 = Mirror horizontal and rotate 270 CW~%# 						6 = Rotate 90 CW~%# 						7 = Mirror horizontal and rotate 90 CW~%# 						8 = Rotate 270 CW~%uint16 orientation~%# 0x0115	SamplesPerPixel	int16u!	IFD0~%uint16 samples_per_pixel~%# 0x0116	RowsPerStrip	int32u!	IFD0~%uint32 rows_per_strip~%# 0x0117	StripByteCounts	(called StripByteCounts in most locations, but it is PreviewImageLength in IFD0 of CR2 images and various IFD's of DNG images except for SubIFD2 where it is JpgFromRawLength)~%# 						PreviewImageLength	int32u*	IFD0~%# 						PreviewImageLength	int32u*	All~%# 						JpgFromRawLength	int32u*	SubIFD2~%uint32 strip_byte_counts~%# 0x0118	MinSampleValue	int16u	IFD0~%# 0x0119	MaxSampleValue	int16u	IFD0~%# 0x011a	XResolution	rational64u:	IFD0~%float64 x_resolution~%# 0x011b	YResolution	rational64u:	IFD0~%float64 y_resolution~%# 0x011c	PlanarConfiguration	int16u!	IFD0~%# 						1 = Chunky~%# 						2 = Planar~%uint16 planar_configuration~%# 0x011d	PageName	string	IFD0~%# 0x011e	XPosition	rational64u	IFD0~%# 0x011f	YPosition	rational64u	IFD0~%# 0x0120	FreeOffsets	no	-~%# 0x0121	FreeByteCounts	no	-~%# 0x0122	GrayResponseUnit	int16u	IFD0~%# 						1 = 0.1~%# 						2 = 0.001~%# 						3 = 0.0001~%# 						4 = 1e-05~%# 						5 = 1e-06~%# 0x0123	GrayResponseCurve	no	-~%# 0x0124	T4Options	no	-	Bit 0 = 2-Dimensional encoding~%# Bit 1 = Uncompressed~%# Bit 2 = Fill bits added~%# 0x0125	T6Options	no	-	Bit 1 = Uncompressed~%# 0x0128	ResolutionUnit	int16u:	IFD0	(the value 1 is not standard EXIF)~%# 						1 = None~%# 						2 = inches~%# 						3 = cm~%uint16 resolution_unit~%# 0x0129	PageNumber	int16u[2]	IFD0~%# 0x012c	ColorResponseUnit	no	-~%# 0x012d	TransferFunction	int16u[768]!	IFD0~%uint16[768] transfer_function~%# 0x0131	Software	string	IFD0~%string software~%# 0x0132	ModifyDate	string	IFD0	(called DateTime by the EXIF spec.)~%string date_time~%# 0x013b	Artist	string	IFD0	(becomes a list-type tag when the MWG module is loaded)~%string artist~%# 0x013c	HostComputer	string	IFD0	 ~%# 0x013d	Predictor	int16u!	IFD0	~%# 						1 = None~%# 						2 = Horizontal differencing~%# 						3 = Floating point~%# 						34892 = Horizontal difference X2~%# 						34893 = Horizontal difference X4~%# 						34894 = Floating point X2~%# 						34895 = Floating point X4~%# 0x013e	WhitePoint	rational64u[2]	IFD0~%float64[2] white_point~%# 0x013f	PrimaryChromaticities	rational64u[6]	IFD0~%float64[6] primary_chromaticities~%# 0x0140	ColorMap	no	-	 ~%# 0x0141	HalftoneHints	int16u[2]	IFD0~%# 0x0142	TileWidth	int32u!	IFD0~%uint32 tile_width~%# 0x0143	TileLength	int32u!	IFD0~%uint32 tile_length~%# 0x0144	TileOffsets	no	-~%# 0x0145	TileByteCounts	no	-~%# 0x0146	BadFaxLines	no	-~%# 0x0147	CleanFaxData	no	-~%# 						0 = Clean~%# 						1 = Regenerated~%# 						2 = Unclean~%# 0x0148	ConsecutiveBadFaxLines	no	-~%# 0x014a	SubIF	-	-	--> EXIF Tags~%# 		A100DataOffset	-no	IFD0	(the data offset in original Sony DSLR-A100 ARW images)~%# 0x014c	InkSet	int16u	IFD0~%# 						1 = CMYK~%# 						2 = Not CMYK~%# 0x014d	InkNames	no	-~%# 0x014e	NumberofInks	no	-~%# 0x0150	DotRange	no	-~%# 0x0151	TargetPrinter	string	IFD0~%# 0x0152	ExtraSamples	no	-~%# 						0 = Unspecified~%# 						1 = Associated Alpha~%# 						2 = Unassociated Alpha~%# 0x0153	SampleFormat	no	SubIFD	(SamplesPerPixel values)# [Values 0-3]~%# 						1 = Unsigned~%# 						2 = Signed~%# 						3 = Float~%# 						4 = Undefined~%# 						5 = Complex int~%# 						6 = Complex float~%# 0x0154	SMinSampleValue	no	-~%# 0x0155	SMaxSampleValue	no	-~%# 0x0156	TransferRange	no	-~%# 0x0157	ClipPath	no	-~%# 0x0158	XClipPathUnits	no	-~%# 0x0159	YClipPathUnits	no	-~%# 0x015a	Indexed	no	-~%# 						0 = Not indexed~%# 						1 = Indexed~%# 0x015b	JPEGTables	no	- ~%# 0x015f	OPIProxy	no	-~%# 						0 = Higher resolution image does not exist~%# 						1 = Higher resolution image exists~%# 0x0190	GlobalParametersIFD	-	-	--> EXIF Tags~%# 0x0191	ProfileType	no	-~%# 						0 = Unspecified~%# 						1 = Group 3 FAX~%# 0x0192	FaxProfile	no	-~%# 						0 = Unknown~%# 						1 = Minimal B&W lossless, S~%# 						2 = Extended B&W lossless, F~%# 						3 = Lossless JBIG B&W, J~%# 						4 = Lossy color and grayscale, C~%# 						5 = Lossless color and grayscale, L~%# 						6 = Mixed raster content, M~%# 						7 = Profile T~%# 						255 = Multi Profiles~%# 0x0193	CodingMethods	no	-~%# 						Bit 0 = Unspecified compression~%# 						Bit 1 = Modified Huffman~%# 						Bit 2 = Modified Read~%# 						Bit 3 = Modified MR~%# 						Bit 4 = JBIG~%# 						Bit 5 = Baseline JPEG~%# 						Bit 6 = JBIG color~%# 0x0194	VersionYear	no	-~%# 0x0195	ModeNumber	no	-~%# 0x01b1	Decode	no	-~%# 0x01b2	DefaultImageColor	no	-~%# 0x01b3	T82Options	no	-~%# 0x01b5	JPEGTables	no	-~%# 0x0200	JPEGProc	no	-~%# 						1 = Baseline~%# 						14 = Lossless~%# 0x0201	ThumbnailOffset	int32u*	IFD1	(ThumbnailOffset in IFD1 of JPEG and some TIFF-based images, IFD0 of MRW images and AVI and MOV videos, and the SubIFD in IFD1 of SRW images; PreviewImageStart in MakerNotes and IFD0 of ARW and SR2 images; JpgFromRawStart in SubIFD of NEF images and IFD2 of PEF images; and OtherImageStart in everything else)~%# 						ThumbnailOffset	int32u*	IFD0~%# 						ThumbnailOffset	int32u*	SubIFD~%# 						PreviewImageStart	int32u*	MakerNotes~%# 						PreviewImageStart	int32u*	IFD0~%# 						JpgFromRawStart	int32u*	SubIFD~%# 						JpgFromRawStart	int32u*	IFD2~%# 						OtherImageStart	int32u*	SubIFD1~%# 						OtherImageStart	int32u*	SubIFD2~%# 						OtherImageStart	no~%uint32 jpg_from_raw_start~%# 0x0202	ThumbnailLength	int32u*	IFD1	(ThumbnailLength in IFD1 of JPEG and some TIFF-based images, IFD0 of MRW images and AVI and MOV videos, and the SubIFD in IFD1 of SRW images; PreviewImageLength in MakerNotes and IFD0 of ARW and SR2 images; JpgFromRawLength in SubIFD of NEF images, and IFD2 of PEF images; and OtherImageLength in everything else)~%# 						ThumbnailLength	int32u*	IFD0~%# 						ThumbnailLength	int32u*	SubIFD~%# 						PreviewImageLength	int32u*	MakerNotes~%# 						PreviewImageLength	int32u*	IFD0~%# 						JpgFromRawLength	int32u*	SubIFD~%# 						JpgFromRawLength	int32u*	IFD2~%# 						OtherImageLength	int32u*	SubIFD1~%# 						OtherImageLength	int32u*	SubIFD2~%# 						OtherImageLength	no	~%uint32 jpg_from_raw_length~%# 0x0203	JPEGRestartInterval	no	-~%# 0x0205	JPEGLosslessPredictors	no	-~%# 0x0206	JPEGPointTransforms	no	-~%# 0x0207	JPEGQTables	no	-~%# 0x0208	JPEGDCTables	no	-~%# 0x0209	JPEGACTables	no	-~%# 0x0211	YCbCrCoefficients	rational64u[3]!	IFD0~%float64[3] ycb_cr_Coefficients~%# 0x0212	YCbCrSubSampling	int16u[2]!	IFD0	~%# 						'1 1' = YCbCr4:4:4 (1 1)~%# 						'1 2' = YCbCr4:4:0 (1 2)~%# 						'1 4' = YCbCr4:4:1 (1 4)~%# 						'2 1' = YCbCr4:2:2 (2 1)~%# 						'2 2' = YCbCr4:2:0 (2 2)~%# 						'2 4' = YCbCr4:2:1 (2 4)~%# 						'4 1' = YCbCr4:1:1 (4 1)~%# 						'4 2' = YCbCr4:1:0 (4 2)~%uint16[2] ycb_cr_sub_sampling~%# 0x0213	YCbCrPositioning	int16u!:	IFD0~%# 						1 = Centered~%# 						2 = Co-sited~%uint16 ycb_cr_positioning~%# 0x0214	ReferenceBlackWhite	rational64u[6]	IFD0~%float64[6] reference_black_white~%# 0x022f	StripRowCounts	no	-~%# 0x02bc	ApplicationNotes	int8u!	IFD0	--> XMP Tags~%# 0x03e7	USPTOMiscellaneous	no	-~%# 0x1000	RelatedImageFileFormat	string!	InteropIFD~%# 0x1001	RelatedImageWidth	int16u!	InteropIFD~%# 0x1002	RelatedImageHeight	int16u!	InteropIFD	(called RelatedImageLength by the DCF spec.)~%# 0x4746	Rating	int16u/	IFD0~%# 0x4747	XP_DIP_XML	no	-~%# 0x4748	StitchInfo	-	-	--> Microsoft Stitch Tags~%# 0x4749	RatingPercent	int16u/	IFD0~%# 0x7000	SonyRawFileType	no	-~%# 						0 = Sony Uncompressed 14-bit RAW~%# 						1 = Sony Uncompressed 12-bit RAW~%# 						2 = Sony Compressed RAW~%# 						3 = Sony Lossless Compressed RAW~%# 						4 = Sony Lossless Compressed RAW 2~%# 0x7010	SonyToneCurve	no	-~%# 0x7031	VignettingCorrection	int16s!	SubIFD	(found in Sony ARW images)~%# 						256 = Off~%# 						257 = Auto~%# 						272 = Auto (ILCE-1)~%# 						511 = No correction params available~%# 0x7032	VignettingCorrParams	int16s[17]!	SubIFD	(found in Sony ARW images)~%# 0x7034	ChromaticAberrationCorrection	int16s!	SubIFD	(found in Sony ARW images)~%# 						0 = Off~%# 						1 = Auto~%# 						255 = No correction params available~%# 0x7035	ChromaticAberrationCorrParams	int16s[33]!	SubIFD	(found in Sony ARW images)~%# 0x7036	DistortionCorrection	int16s!	SubIFD	(found in Sony ARW images)~%# 						0 = Off~%# 						1 = Auto~%# 						17 = Auto fixed by lens~%# 						255 = No correction params available~%# 0x7037	DistortionCorrParams	int16s[17]!	SubIFD	(found in Sony ARW images)~%# 0x74c7	SonyCropTopLeft	int32u[2]!	SubIFD~%# 0x74c8	SonyCropSize	int32u[2]!	SubIFD~%# 0x800d	ImageID	no	-~%# 0x80a3	WangTag1	no	-~%# 0x80a4	WangAnnotation	no	-~%# 0x80a5	WangTag3	no	-~%# 0x80a6	WangTag4	no	-~%# 0x80b9	ImageReferencePoints	no	-~%# 0x80ba	RegionXformTackPoint	no	-~%# 0x80bb	WarpQuadrilateral	no	-~%# 0x80bc	AffineTransformMat	no	-~%# 0x80e3	Matteing	no	-~%# 0x80e4	DataType	no	-~%# 0x80e5	ImageDepth	no	-~%# 0x80e6	TileDepth	no	-~%# 0x8214	ImageFullWidth	no	-~%# 0x8215	ImageFullHeight	no	-~%# 0x8216	TextureFormat	no	-~%# 0x8217	WrapModes	no	-~%# 0x8218	FovCot	no	-~%# 0x8219	MatrixWorldToScreen	no	-~%# 0x821a	MatrixWorldToCamera	no	-~%# 0x827d	Model2	no	-~%# 0x828d	CFARepeatPatternDim	int16u[2]!	SubIFD~%# 0x828e	CFAPattern2	int8u[n]!	SubIFD~%# 0x828f	BatteryLevel	no	-~%# 0x8290	KodakIFD	-	-	--> Kodak IFD Tags	(used in various types of Kodak images)~%# 0x8298	Copyright	string	IFD0	(may contain copyright notices for photographer and editor, separated by a newline. As per the EXIF specification, the newline is replaced by a null byte when writing to file, but this may be avoided by disabling the print conversion)~%string copyright~%# 0x829a	ExposureTime	rational64u	ExifIFD~%float64 exposure_time~%# 0x829d	FNumber	rational64u	ExifIFD~%float64 f_number~%# 0x82a5	MDFileTag	no	-	(tags 0x82a5-0x82ac are used in Molecular Dynamics GEL files)~%# 0x82a6	MDScalePixel	no	-~%# 0x82a7	MDColorTable	no	-~%# 0x82a8	MDLabName	no	-~%# 0x82a9	MDSampleInfo	no	-~%# 0x82aa	MDPrepDate	no	-~%# 0x82ab	MDPrepTime	no	-~%# 0x82ac	MDFileUnits	no	-~%# 0x830e	PixelScale	double[3]	IFD0~%# 0x8335	AdventScale	no	-~%# 0x8336	AdventRevision	no	-~%# 0x835c	UIC1Tag	no	-~%# 0x835d	UIC2Tag	no	-~%# 0x835e	UIC3Tag	no	-~%# 0x835f	UIC4Tag	no	-~%# 0x83bb	IPTC-NAA	int32u!	IFD0	--> IPTC Tags~%# 0x847e	IntergraphPacketData	no	-~%# 0x847f	IntergraphFlagRegisters	no	-~%# 0x8480	IntergraphMatrix	double[n]	IFD0~%# 0x8481	INGRReserved	no	-~%# 0x8482	ModelTiePoint	double[n]	IFD0~%# 0x84e0	Site	no	-~%# 0x84e1	ColorSequence	no	-~%# 0x84e2	IT8Header	no	-~%# 0x84e3	RasterPadding	no	-~%# 						0 = Byte~%# 						1 = Word~%# 						2 = Long Word~%# 						9 = Sector~%# 						10 = Long Sector~%# 0x84e4	BitsPerRunLength	no	-~%# 0x84e5	BitsPerExtendedRunLength	no	-~%# 0x84e6	ColorTable	no	-~%# 0x84e7	ImageColorIndicator	no	-~%# 						0 = Unspecified Image Color~%# 						1 = Specified Image Color~%# 0x84e8	BackgroundColorIndicator	no	-~%# 						0 = Unspecified Background Color~%# 						1 = Specified Background Color~%# 0x84e9	ImageColorValue	no	-~%# 0x84ea	BackgroundColorValue	no	-~%# 0x84eb	PixelIntensityRange	no	-~%# 0x84ec	TransparencyIndicator	no	-~%# 0x84ed	ColorCharacterization	no	-~%# 0x84ee	HCUsage	no	-~%# 						0 = CT~%# 						1 = Line Art~%# 						2 = Trap~%# 0x84ef	TrapIndicator	no	-~%# 0x84f0	CMYKEquivalent	no	-~%# 0x8546	SEMInfo	string	IFD0	(found in some scanning electron microscope images)~%# 0x8568	AFCP_IPTC	-	-	--> IPTC Tags~%# 0x85b8	PixelMagicJBIGOptions	no	-~%# 0x85d7	JPLCartoIFD	no	-~%# 0x85d8	ModelTransform	double[16]	IFD0~%# 0x8602	WB_GRGBLevels	no	-	(found in IFD0 of Leaf MOS images)~%# 0x8606	LeafData	-	-	--> Leaf Tags~%# 0x8649	PhotoshopSettings	-	IFD0	--> Photoshop Tags~%# 0x8769	ExifOffset	-	IFD0	--> EXIF Tags~%# 0x8773	ICC_Profile	-	IFD0	--> ICC_Profile Tags~%# 0x877f	TIFF_FXExtensions	no	-~%# 						Bit 0 = Resolution/Image Width~%# 						Bit 1 = N Layer Profile M~%# 						Bit 2 = Shared Data~%# 						Bit 3 = B&W JBIG2~%# 						Bit 4 = JBIG2 Profile M~%# 0x8780	MultiProfiles	no	~%# 						Bit 0 = Profile S~%# 						Bit 1 = Profile F~%# 						Bit 2 = Profile J~%# 						Bit 3 = Profile C~%# 						Bit 4 = Profile L~%# 						Bit 5 = Profile M~%# 						Bit 6 = Profile T~%# 						Bit 7 = Resolution/Image Width~%# 						Bit 8 = N Layer Profile M~%# 						Bit 9 = Shared Data~%# 						Bit 10 = JBIG2 Profile M~%# 0x8781	SharedData	no	-~%# 0x8782	T88Options	no	-~%# 0x87ac	ImageLayer	no	-~%# 0x87af	GeoTiffDirectory	int16u[0.5]	IFD0	(these \"GeoTiff\" tags may read and written as a block, but they aren't extracted unless specifically requested. Byte order changes are handled automatically when copying between TIFF images with different byte order)~%# 0x87b0	GeoTiffDoubleParams	double[0.125]	IFD0	 ~%# 0x87b1	GeoTiffAsciiParams	string	IFD0	 ~%# 0x87be	JBIGOptions	no	-	 ~%# 0x8822	ExposureProgram	int16u	ExifIFD	(the value of 9 is not standard EXIF, but is used by the Canon EOS 7D)~%# 						0 = Not Defined~%# 						1 = Manual~%# 						2 = Program AE~%# 						3 = Aperture-priority AE~%# 						4 = Shutter speed priority AE~%# 						5 = Creative (Slow speed)~%# 						6 = Action (High speed)~%# 						7 = Portrait~%# 						8 = Landscape~%# 						9 = Bulb~%uint16 exposure_program~%# 0x8824	SpectralSensitivity	string	ExifIFD~%# 0x8825	GPSInfo	-	IFD0	--> GPS Tags~%ExifGPSInfo gps_info~%# 0x8827	ISO	int16u[n]	ExifIFD	(called ISOSpeedRatings by EXIF 2.2, then PhotographicSensitivity by the EXIF 2.3 spec.)~%uint16[] iso~%# 0x8828	Opto-ElectricConvFactor	no	-	(called OECF by the EXIF spec.)~%# 0x8829	Interlace	no	-	 ~%# 0x882a	TimeZoneOffset	int16s[n]	ExifIFD	(1 or 2 values: 1. The time zone offset of DateTimeOriginal from GMT in hours, 2. If present, the time zone offset of ModifyDate)~%# 0x882b	SelfTimerMode	int16u	ExifIFD	 ~%# 0x8830	SensitivityType	int16u	ExifIFD	(applies to EXIF:ISO tag)~%# 						0 = Unknown~%# 						1 = Standard Output Sensitivity~%# 						2 = Recommended Exposure Index~%# 						3 = ISO Speed~%# 						4 = Standard Output Sensitivity and Recommended Exposure Index~%# 						5 = Standard Output Sensitivity and ISO Speed~%# 						6 = Recommended Exposure Index and ISO Speed~%# 						7 = Standard Output Sensitivity, Recommended Exposure Index and ISO Speed~%uint16 sensitivity_type~%# 0x8831	StandardOutputSensitivity	int32u	ExifIFD~%uint32 standard_output_sensitivity~%# 0x8832	RecommendedExposureIndex	int32u	ExifIFD~%uint32 recommended_exposure_index~%# 0x8833	ISOSpeed	int32u	ExifIFD~%uint32 iso_speed~%# 0x8834	ISOSpeedLatitudeyyy	int32u	ExifIFD~%uint32 iso_speed_latitudeyyy~%# 0x8835	ISOSpeedLatitudezzz	int32u	ExifIFD~%uint32 iso_speed_latitudezzz~%# 0x885c	FaxRecvParams	no	-~%# 0x885d	FaxSubAddress	no	-~%# 0x885e	FaxRecvTime	no	-~%# 0x8871	FedexEDR	no	-~%# 0x888a	LeafSubIFD	-	-	--> Leaf SubIFD Tags~%# 0x9000	ExifVersion	undef:	ExifIFD~%string exif_version~%# 0x9003	DateTimeOriginal	string	ExifIFD	(date/time when original image was taken)~%string date_time_original~%# 0x9004	CreateDate	string	ExifIFD	(called DateTimeDigitized by the EXIF spec.)~%string date_time_digitized~%# 0x9009	GooglePlusUploadCode	undef[n]	ExifIFD~%# 0x9010	OffsetTime	string	ExifIFD	(time zone for ModifyDate)~%string offset_time~%# 0x9011	OffsetTimeOriginal	string	ExifIFD	(time zone for DateTimeOriginal)~%string offset_time_original~%# 0x9012	OffsetTimeDigitized	string	ExifIFD	(time zone for CreateDate)~%string offset_time_digitized~%# 0x9101	ComponentsConfiguration	undef[4]!:	ExifIFD~%# 						0 = -~%# 						1 = Y~%# 						2 = Cb~%# 						3 = Cr~%# 						4 = R~%# 						5 = G~%# 						6 = B~%uint8[4] components_configuration~%# 0x9102	CompressedBitsPerPixel	rational64u!	ExifIFD~%float64 compressed_bits_per_pixel~%# 0x9201	ShutterSpeedValue	rational64s	ExifIFD	(displayed in seconds, but stored as an APEX value)~%float64 shutter_speed_value~%# 0x9202	ApertureValue	rational64u	ExifIFD	(displayed as an F number, but stored as an APEX value)~%float64 aperture_value~%# 0x9203	BrightnessValue	rational64s	ExifIFD~%float64 brightness_value~%# 0x9204	ExposureCompensation	rational64s	ExifIFD	(called ExposureBiasValue by the EXIF spec.)~%float64 exposure_bias_value~%# 0x9205	MaxApertureValue	rational64u	ExifIFD	(displayed as an F number, but stored as an APEX value)~%float64 max_aperture_value~%# 0x9206	SubjectDistance	rational64u	ExifIFD~%float64 subject_distance~%# 0x9207	MeteringMode	int16u	ExifIFD~%# 						0 = Unknown~%# 						1 = Average~%# 						2 = Center-weighted average~%# 						3 = Spot~%# 						4 = Multi-spot~%# 						5 = Multi-segment~%# 						6 = Partial~%# 						255 = Other~%uint16 metering_mode~%# 0x9208	LightSource	int16u	ExifIFD	--> EXIF LightSource Values~%uint16 light_source~%# 0x9209	Flash	int16u	ExifIFD	--> EXIF Flash Values~%uint16 flash~%# 0x920a	FocalLength	rational64u	ExifIFD~%float64 focal_length~%# 0x920b	FlashEnergy	no	-~%# 0x920c	SpatialFrequencyResponse	no	-~%# 0x920d	Noise	no	-~%# 0x920e	FocalPlaneXResolution	no	-~%# 0x920f	FocalPlaneYResolution	no	-~%# 0x9210	FocalPlaneResolutionUnit	no	-~%# 						1 = None~%# 						2 = inches~%# 						3 = cm~%# 						4 = mm~%# 						5 = um~%# 0x9211	ImageNumber	int32u	ExifIFD~%# 0x9212	SecurityClassification	string	ExifIFD~%# 						'C' = Confidential~%# 						'R' = Restricted~%# 						'S' = Secret~%# 						'T' = Top Secret~%# 						'U' = Unclassified~%# 0x9213	ImageHistory	string	ExifIFD~%# 0x9214	SubjectArea	int16u[n]	ExifIFD~%uint16[] subject_area~%# 0x9215	ExposureIndex	no	-~%# 0x9216	TIFF-EPStandardID	no	-~%# 0x9217	SensingMethod	no	-~%# 						1 = Monochrome area~%# 						2 = One-chip color area~%# 						3 = Two-chip color area~%# 						4 = Three-chip color area~%# 						5 = Color sequential area~%# 						6 = Monochrome linear~%# 						7 = Trilinear~%# 						8 = Color sequential linear~%# 0x923a	CIP3DataFile	no	-~%# 0x923b	CIP3Sheet	no	-~%# 0x923c	CIP3Side	no	-~%# 0x923f	StoNits	no	-~%# 0x927c	MakerNoteApple	undef	ExifIFD	--> Apple Tags~%# 		MakerNoteNikon	undef	ExifIFD	--> Nikon Tags~%# 		MakerNoteCanon	undef	ExifIFD	--> Canon Tags~%# 		MakerNoteCasio	undef	ExifIFD	--> Casio Tags~%# 		MakerNoteCasio2	undef	ExifIFD	--> Casio Type2 Tags~%# 		MakerNoteDJI	undef	ExifIFD	--> DJI Tags~%# 		MakerNoteFLIR	undef	ExifIFD	--> FLIR Tags~%# 		MakerNoteFujiFilm	undef	ExifIFD	--> FujiFilm Tags~%# 		MakerNoteGE	undef	ExifIFD	--> GE Tags~%# 		MakerNoteGE2	undef	ExifIFD	--> FujiFilm Tags~%# 		MakerNoteHasselblad	undef	ExifIFD	--> Unknown Tags~%# 		MakerNoteHP	undef	ExifIFD	--> HP Tags~%# 		MakerNoteHP2	undef	ExifIFD	--> HP Type2 Tags~%# 		MakerNoteHP4	undef	ExifIFD	--> HP Type4 Tags~%# 		MakerNoteHP6	undef	ExifIFD	--> HP Type6 Tags~%# 		MakerNoteISL	undef	ExifIFD	--> Unknown Tags~%# 		MakerNoteJVC	undef	ExifIFD	--> JVC Tags~%# 		MakerNoteJVCText	undef	ExifIFD	--> JVC Text Tags~%# 		MakerNoteKodak1a	undef	ExifIFD	--> Kodak Tags~%# 		MakerNoteKodak1b	undef	ExifIFD	--> Kodak Tags~%# 		MakerNoteKodak2	undef	ExifIFD	--> Kodak Type2 Tags~%# 		MakerNoteKodak3	undef	ExifIFD	--> Kodak Type3 Tags~%# 		MakerNoteKodak4	undef	ExifIFD	--> Kodak Type4 Tags~%# 		MakerNoteKodak5	undef	ExifIFD	--> Kodak Type5 Tags~%# 		MakerNoteKodak6a	undef	ExifIFD	--> Kodak Type6 Tags~%# 		MakerNoteKodak6b	undef	ExifIFD	--> Kodak Type6 Tags~%# 		MakerNoteKodak7	undef	ExifIFD	--> Kodak Type7 Tags~%# 		MakerNoteKodak8a	undef	ExifIFD	--> Kodak Type8 Tags~%# 		MakerNoteKodak8b	undef	ExifIFD	--> Kodak Type8 Tags~%# 		MakerNoteKodak8c	undef	ExifIFD	--> Kodak Type8 Tags~%# 		MakerNoteKodak9	undef	ExifIFD	--> Kodak Type9 Tags~%# 		MakerNoteKodak10	undef	ExifIFD	--> Kodak Type10 Tags~%# 		MakerNoteKodak11	undef	ExifIFD	--> Kodak Type11 Tags~%# 		MakerNoteKodak12	undef	ExifIFD	--> Kodak Type11 Tags~%# 		MakerNoteKodakUnknown	undef	ExifIFD	--> Kodak Unknown Tags~%# 		MakerNoteKyocera	undef	ExifIFD	--> Unknown Tags~%# 		MakerNoteMinolta	undef	ExifIFD	--> Minolta Tags~%# 		MakerNoteMinolta2	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteMinolta3	undef	ExifIFD	(not EXIF-based)~%# 		MakerNoteMotorola	undef	ExifIFD	--> Motorola Tags~%# 		MakerNoteNikon2	undef	ExifIFD	--> Nikon Type2 Tags~%# 		MakerNoteNikon3	undef	ExifIFD	--> Nikon Tags~%# 		MakerNoteNintendo	undef	ExifIFD	--> Nintendo Tags~%# 		MakerNoteOlympus	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteOlympus2	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteLeica	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNoteLeica2	undef	ExifIFD	--> Panasonic Leica2 Tags~%# 		MakerNoteLeica3	undef	ExifIFD	--> Panasonic Leica3 Tags~%# 		MakerNoteLeica4	undef	ExifIFD	--> Panasonic Leica4 Tags~%# 		MakerNoteLeica5	undef	ExifIFD	--> Panasonic Leica5 Tags~%# 		MakerNoteLeica6	undef	ExifIFD	--> Panasonic Leica6 Tags~%# 		MakerNoteLeica7	undef	ExifIFD	--> Panasonic Leica6 Tags~%# 		MakerNoteLeica8	undef	ExifIFD	--> Panasonic Leica5 Tags~%# 		MakerNoteLeica9	undef	ExifIFD	--> Panasonic Leica9 Tags~%# 		MakerNoteLeica10	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNotePanasonic	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNotePanasonic2	undef	ExifIFD	--> Panasonic Type2 Tags~%# 		MakerNotePanasonic3	undef	ExifIFD	--> Panasonic Tags~%# 		MakerNotePentax	undef	ExifIFD	--> Pentax Tags~%# 		MakerNotePentax2	undef	ExifIFD	--> Pentax Type2 Tags~%# 		MakerNotePentax3	undef	ExifIFD	--> Casio Type2 Tags~%# 		MakerNotePentax4	undef	ExifIFD	--> Pentax Type4 Tags~%# 		MakerNotePentax5	undef	ExifIFD	--> Pentax Tags~%# 		MakerNotePentax6	undef	ExifIFD	--> Pentax S1 Tags~%# 		MakerNotePhaseOne	undef	ExifIFD	--> PhaseOne Tags~%# 		MakerNoteReconyx	undef	ExifIFD	--> Reconyx Tags~%# 		MakerNoteReconyx2	undef	ExifIFD	--> Reconyx Type2 Tags~%# 		MakerNoteReconyx3	undef	ExifIFD	--> Reconyx Type3 Tags~%# 		MakerNoteRicohPentax	undef	ExifIFD	--> Pentax Tags~%# 		MakerNoteRicoh	undef	ExifIFD	--> Ricoh Tags~%# 		MakerNoteRicoh2	undef	ExifIFD	--> Ricoh Type2 Tags~%# 		MakerNoteRicohText	undef	ExifIFD	--> Ricoh Text Tags~%# 		MakerNoteSamsung1a	undef	ExifIFD	(Samsung \"STMN\" maker notes without PreviewImage)~%# 		undef	ExifIFD	--> Samsung Tags	MakerNoteSamsung1b~%# 		MakerNoteSamsung2	undef	ExifIFD	--> Samsung Type2 Tags~%# 		MakerNoteSanyo	undef	ExifIFD	--> Sanyo Tags~%# 		MakerNoteSanyoC4	undef	ExifIFD	--> Sanyo Tags~%# 		MakerNoteSanyoPatch	undef	ExifIFD	--> Sanyo Tags~%# 		MakerNoteSigma	undef	ExifIFD	--> Sigma Tags~%# 		MakerNoteSony	undef	ExifIFD	--> Sony Tags~%# 		MakerNoteSony2	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteSony3	undef	ExifIFD	--> Olympus Tags~%# 		MakerNoteSony4	undef	ExifIFD	--> Sony PIC Tags~%# 		MakerNoteSony5	undef	ExifIFD	--> Sony Tags~%# 		MakerNoteSonyEricsson	undef	ExifIFD	--> Sony Ericsson Tags~%# 		MakerNoteSonySRF	undef	ExifIFD	--> Sony SRF Tags~%# 		MakerNoteUnknownText	undef	ExifIFD	(unknown text-based maker notes)~%# 		MakerNoteUnknownBinary	undef	ExifIFD	(unknown binary maker notes)~%# 		MakerNoteUnknown	undef	ExifIFD	--> Unknown Tags~%# 0x9286	UserComment	undef	ExifIFD~%string user_comment~%# 0x9290	SubSecTime	string	ExifIFD	(fractional seconds for ModifyDate)~%string subsec_time~%# 0x9291	SubSecTimeOriginal	string	ExifIFD	(fractional seconds for DateTimeOriginal)~%string subsec_time_original~%# 0x9292	SubSecTimeDigitized	string	ExifIFD	(fractional seconds for CreateDate)~%string subsec_time_digitized~%# 0x932f	MSDocumentText	no	-	 ~%# 0x9330	MSPropertySetStorage	no	-~%# 0x9331	MSDocumentTextPosition	no	-~%# 0x935c	ImageSourceData	undef!	IFD0	--> Photoshop DocumentData Tags~%# 0x9400	AmbientTemperature	rational64s	ExifIFD	(ambient temperature in degrees C, called Temperature by the EXIF spec.)~%float64 temperature~%# 0x9401	Humidity	rational64u	ExifIFD	(ambient relative humidity in percent)~%float64 humidity~%# 0x9402	Pressure	rational64u	ExifIFD	(air pressure in hPa or mbar)~%float64 pressure~%# 0x9403	WaterDepth	rational64s	ExifIFD	(depth under water in metres, negative for above water)~%float64 water_depth~%# 0x9404	Acceleration	rational64u	ExifIFD	(directionless camera acceleration in units of mGal, or 10-5 m/s2)~%float64 acceleration~%# 0x9405	CameraElevationAngle	rational64s	ExifIFD~%float64 camera_elevation_angle~%# 0x9c9b	XPTitle	int8u	IFD0	(tags 0x9c9b-0x9c9f are used by Windows Explorer; special characters in these values are converted to UTF-8 by default, or Windows Latin1 with the -L option. XPTitle is ignored by Windows Explorer if ImageDescription exists)~%# 0x9c9c	XPComment	int8u	IFD0~%# 0x9c9d	XPAuthor	int8u	IFD0	(ignored by Windows Explorer if Artist exists)~%# 0x9c9e	XPKeywords	int8u	IFD0~%# 0x9c9f	XPSubject	int8u	IFD0~%# 0xa000	FlashpixVersion	undef:	ExifIFD~%string flash_pix_version~%# 0xa001	ColorSpace	int16u:	ExifIFD	(the value of 0x2 is not standard EXIF. Instead, an Adobe RGB image is indicated by \"Uncalibrated\" with an InteropIndex of \"R03\". The values 0xfffd and 0xfffe are also non-standard, and are used by some Sony cameras)~%# 						0x1 = sRGB~%# 						0x2 = Adobe RGB~%# 						0xfffd = Wide Gamut RGB~%# 						0xfffe = ICC Profile~%# 						0xffff = Uncalibrated~%uint16 color_space~%# 0xa002	ExifImageWidth	int16u:	ExifIFD	(called PixelXDimension by the EXIF spec.)~%uint16 exif_image_width~%# 0xa003	ExifImageHeight	int16u:	ExifIFD	(called PixelYDimension by the EXIF spec.)~%uint16 exif_image_height~%# 0xa004	RelatedSoundFile	string	ExifIFD~%string related_sound_file~%# 0xa005	InteropOffset	-	-	--> EXIF Tags~%# 0xa010	SamsungRawPointersOffset	no	-~%# 0xa011	SamsungRawPointersLength	no	-~%# 0xa101	SamsungRawByteOrder	no	-~%# 0xa102	SamsungRawUnknown?	no	-~%# 0xa20b	FlashEnergy	rational64u	ExifIFD~%float64 flash_energy~%# 0xa20c	SpatialFrequencyResponse	no	-~%# 0xa20d	Noise	no	-	 ~%# 0xa20e	FocalPlaneXResolution	rational64u	ExifIFD~%float64 focal_plane_x_resolution~%# 0xa20f	FocalPlaneYResolution	rational64u	ExifIFD~%float64 focal_plane_y_resolution~%# 0xa210	FocalPlaneResolutionUnit	int16u	ExifIFD	(values 1, 4 and 5 are not standard EXIF)~%# 						1 = None~%# 						2 = inches~%# 						3 = cm~%# 						4 = mm~%# 						5 = um~%uint16 focal_plane_resolution_unit~%# 0xa211	ImageNumber	no	-~%# 0xa212	SecurityClassification	no	-~%# 0xa213	ImageHistory	no	-~%# 0xa214	SubjectLocation	int16u[2]	ExifIFD~%uint16[2] subject_location~%# 0xa215	ExposureIndex	rational64u	ExifIFD~%float64 exposure_index~%# 0xa216	TIFF-EPStandardID	no	-~%# 0xa217	SensingMethod	int16u	ExifIFD~%# 						1 = Not defined~%# 						2 = One-chip color area~%# 						3 = Two-chip color area~%# 						4 = Three-chip color area~%# 						5 = Color sequential area~%# 						7 = Trilinear~%# 						8 = Color sequential linear~%uint16 sensing_method~%# 0xa300	FileSource	undef	ExifIFD~%# 						1 = Film Scanner~%# 						2 = Reflection Print Scanner~%# 						3 = Digital Camera~%# 						\"\\x03\\x00\\x00\\x00\" = Sigma Digital Camera~%# 0xa301	SceneType	undef	ExifIFD	1 = Directly photographed~%string scene_type~%# 0xa302	CFAPattern	undef	ExifIFD~%# 0xa401	CustomRendered	int16u	ExifIFD	(only 0 and 1 are standard EXIF, but other values are used by Apple iOS devices)~%# 						0 = Normal~%# 						1 = Custom~%# 						2 = HDR (no original saved)~%# 						3 = HDR (original saved)~%# 						4 = Original (for HDR)~%# 						6 = Panorama~%# 						7 = Portrait HDR~%# 						8 = Portrait~%uint16 custom_rendered~%# 0xa402	ExposureMode	int16u	ExifIFD~%# 						0 = Auto~%# 						1 = Manual~%# 						2 = Auto bracket~%uint16 exposure_mode~%# 0xa403	WhiteBalance	int16u	ExifIFD~%# 						0 = Auto~%# 						1 = Manual~%uint16 white_balance~%# 0xa404	DigitalZoomRatio	rational64u	ExifIFD~%float64 digital_zoom_ratio~%# 0xa405	FocalLengthIn35mmFormat	int16u	ExifIFD	(called FocalLengthIn35mmFilm by the EXIF spec.)~%uint16 focal_length_in_35mm_film~%# 0xa406	SceneCaptureType	int16u	ExifIFD	(the value of 4 is non-standard, and used by some Samsung models)~%# 						0 = Standard~%# 						1 = Landscape~%# 						2 = Portrait~%# 						3 = Night~%# 						4 = Other~%uint16 scene_capture_type~%# 0xa407	GainControl	int16u	ExifIFD~%# 						0 = None~%# 						1 = Low gain up~%# 						2 = High gain up~%# 						3 = Low gain down~%# 						4 = High gain down~%uint16 gain_control~%# 0xa408	Contrast	int16u	ExifIFD~%# 						0 = Normal~%# 						1 = Low~%# 						2 = High~%uint16 contrast~%# 0xa409	Saturation	int16u	ExifIFD~%# 						0 = Normal~%# 						1 = Low~%# 						2 = High~%uint16 saturation~%# 0xa40a	Sharpness	int16u	ExifIFD~%# 						0 = Normal~%# 						1 = Soft~%# 						2 = Hard~%uint16 sharpness~%# 0xa40b	DeviceSettingDescription	no	-	 ~%# 0xa40c	SubjectDistanceRange	int16u	ExifIFD~%# 						0 = Unknown~%# 						1 = Macro~%# 						2 = Close~%# 						3 = Distant~%uint16 subject_distance_range~%# 0xa420	ImageUniqueID	string	ExifIFD~%string image_unique_id~%# 0xa430	OwnerName	string	ExifIFD	(called CameraOwnerName by the EXIF spec.)~%string camera_owner_name~%# 0xa431	SerialNumber	string	ExifIFD	(called BodySerialNumber by the EXIF spec.)~%string body_serial_number~%# 0xa432	LensInfo	rational64u[4]	ExifIFD	(4 rational values giving focal and aperture ranges, called LensSpecification by the EXIF spec.)~%float64[4] lens_specification~%# 0xa433	LensMake	string	ExifIFD~%string lens_make~%# 0xa434	LensModel	string	ExifIFD~%string lens_model~%# 0xa435	LensSerialNumber	string	ExifIFD~%string lens_serial_number~%# 0xa460	CompositeImage	int16u	ExifIFD~%# 						0 = Unknown~%# 						1 = Not a Composite Image~%# 						2 = General Composite Image~%# 						3 = Composite Image Captured While Shooting~%uint16 composite_image~%# 0xa461	CompositeImageCount	int16u[2]	ExifIFD	(2 values: 1. Number of source images, 2. Number of images used. Called SourceImageNumberOfCompositeImage by the EXIF spec.)~%# 0xa462	CompositeImageExposureTimes	undef	ExifIFD	(11 or more values: 1. Total exposure time period, 2. Total exposure of all source images, 3. Total exposure of all used images, 4. Max exposure time of source images, 5. Max exposure time of used images, 6. Min exposure time of source images, 7. Min exposure of used images, 8. Number of sequences, 9. Number of source images in sequence. 10-N. Exposure times of each source image. Called SourceExposureTimesOfCompositeImage by the EXIF spec.)~%uint16[2] composite_image_count~%# 0xa480	GDALMetadata	string	IFD0~%# 0xa481	GDALNoData	string	IFD0~%# 0xa500	Gamma	rational64u	ExifIFD~%float64 gamma~%# 0xafc0	ExpandSoftware	no	-~%# 0xafc1	ExpandLens	no	-~%# 0xafc2	ExpandFilm	no	-~%# 0xafc3	ExpandFilterLens	no	-~%# 0xafc4	ExpandScanner	no	-~%# 0xafc5	ExpandFlashLamp	no	-~%# 0xb4c3	HasselbladRawImage	no	-~%# 0xbc01	PixelFormat	no	-	(tags 0xbc** are used in Windows HD Photo (HDP and WDP) images. The actual PixelFormat values are 16-byte GUID's but the leading 15 bytes, '6fddc324-4e03-4bfe-b1853-d77768dc9', have been removed below to avoid unnecessary clutter)~%# 						0x5 = Black & White~%# 						0x8 = 8-bit Gray~%# 						0x9 = 16-bit BGR555~%# 						0xa = 16-bit BGR565~%# 						0xb = 16-bit Gray~%# 						0xc = 24-bit BGR~%# 						0xd = 24-bit RGB~%# 						0xe = 32-bit BGR~%# 						0xf = 32-bit BGRA~%# 						0x10 = 32-bit PBGRA~%# 						0x11 = 32-bit Gray Float~%# 						0x12 = 48-bit RGB Fixed Point~%# 						0x13 = 32-bit BGR101010~%# 						0x15 = 48-bit RGB~%# 						0x16 = 64-bit RGBA~%# 						0x17 = 64-bit PRGBA~%# 						0x18 = 96-bit RGB Fixed Point~%# 						0x19 = 128-bit RGBA Float~%# 						0x1a = 128-bit PRGBA Float~%# 						0x1b = 128-bit RGB Float~%# 						0x1c = 32-bit CMYK~%# 						0x1d = 64-bit RGBA Fixed Point~%# 						0x1e = 128-bit RGBA Fixed Point~%# 						0x1f = 64-bit CMYK~%# 						0x20 = 24-bit 3 Channels~%# 						0x21 = 32-bit 4 Channels~%# 						0x22 = 40-bit 5 Channels~%# 						0x23 = 48-bit 6 Channels~%# 						0x24 = 56-bit 7 Channels~%# 						0x25 = 64-bit 8 Channels~%# 						0x26 = 48-bit 3 Channels~%# 						0x27 = 64-bit 4 Channels~%# 						0x28 = 80-bit 5 Channels~%# 						0x29 = 96-bit 6 Channels~%# 						0x2a = 112-bit 7 Channels~%# 						0x2b = 128-bit 8 Channels~%# 						0x2c = 40-bit CMYK Alpha~%# 						0x2d = 80-bit CMYK Alpha~%# 						0x2e = 32-bit 3 Channels Alpha~%# 						0x2f = 40-bit 4 Channels Alpha~%# 						0x30 = 48-bit 5 Channels Alpha~%# 						0x31 = 56-bit 6 Channels Alpha~%# 						0x32 = 64-bit 7 Channels Alpha~%# 						0x33 = 72-bit 8 Channels Alpha~%# 						0x34 = 64-bit 3 Channels Alpha~%# 						0x35 = 80-bit 4 Channels Alpha~%# 						0x36 = 96-bit 5 Channels Alpha~%# 						0x37 = 112-bit 6 Channels Alpha~%# 						0x38 = 128-bit 7 Channels Alpha~%# 						0x39 = 144-bit 8 Channels Alpha~%# 						0x3a = 64-bit RGBA Half~%# 						0x3b = 48-bit RGB Half~%# 						0x3d = 32-bit RGBE~%# 						0x3e = 16-bit Gray Half~%# 						0x3f = 32-bit Gray Fixed Point~%# 0xbc02	Transformation	no	-	~%# 						0 = Horizontal (normal)~%# 						1 = Mirror vertical~%# 						2 = Mirror horizontal~%# 						3 = Rotate 180~%# 						4 = Rotate 90 CW~%# 						5 = Mirror horizontal and rotate 90 CW~%# 						6 = Mirror horizontal and rotate 270 CW~%# 						7 = Rotate 270 CW~%# 0xbc03	Uncompressed	no	-~%# 						0 = No~%# 						1 = Yes~%# 0xbc04	ImageType	no	-~%# 						Bit 0 = Preview~%# 						Bit 1 = Page~%# 0xbc80	ImageWidth	no	-~%# 0xbc81	ImageHeight	no	-~%# 0xbc82	WidthResolution	no	-~%# 0xbc83	HeightResolution	no	-~%# 0xbcc0	ImageOffset	no	-~%# 0xbcc1	ImageByteCount	no	-~%# 0xbcc2	AlphaOffset	no	-~%# 0xbcc3	AlphaByteCount	no	-~%# 0xbcc4	ImageDataDiscard	no	-~%# 						0 = Full Resolution~%# 						1 = Flexbits Discarded~%# 						2 = HighPass Frequency Data Discarded~%# 						3 = Highpass and LowPass Frequency Data Discarded~%# 0xbcc5	AlphaDataDiscard	no	-~%# 						0 = Full Resolution~%# 						1 = Flexbits Discarded~%# 						2 = HighPass Frequency Data Discarded~%# 						3 = Highpass and LowPass Frequency Data Discarded~%# 0xc427	OceScanjobDesc	no	-~%# 0xc428	OceApplicationSelector	no	-~%# 0xc429	OceIDNumber	no	-~%# 0xc42a	OceImageLogic	no	-~%# 0xc44f	Annotations	no	-~%# 0xc4a5	PrintIM	undef	IFD0	--> PrintIM Tags~%# 0xc51b	HasselbladExif	no	-~%# 0xc573	OriginalFileName	no	-	(used by some obscure software)~%# 0xc580	USPTOOriginalContentType	no	-~%# 						0 = Text or Drawing~%# 						1 = Grayscale~%# 						2 = Color~%# 0xc5e0	CR2CFAPattern	no	-~%# 						1 => '0 1 1 2' = [Red,Green][Green,Blue]~%# 						4 => '1 0 2 1' = [Green,Red][Blue,Green]~%# 						3 => '1 2 0 1' = [Green,Blue][Red,Green]~%# 						2 => '2 1 1 0' = [Blue,Green][Green,Red]~%# 0xc612	DNGVersion	int8u[4]!	IFD0	(tags 0xc612-0xcd3b are defined by the DNG specification unless otherwise noted. See https://helpx.adobe.com/photoshop/digital-negative.html for the specification)~%# 0xc613	DNGBackwardVersion	int8u[4]!	IFD0~%# 0xc614	UniqueCameraModel	string	IFD0~%# 0xc615	LocalizedCameraModel	string	IFD0~%# 0xc616	CFAPlaneColor	no	SubIFD~%# 0xc617	CFALayout	no	SubIFD~%# 						1 = Rectangular~%# 						2 = Even columns offset down 1/2 row~%# 						3 = Even columns offset up 1/2 row~%# 						4 = Even rows offset right 1/2 column~%# 						5 = Even rows offset left 1/2 column~%# 						6 = Even rows offset up by 1/2 row, even columns offset left by 1/2 column~%# 						7 = Even rows offset up by 1/2 row, even columns offset right by 1/2 column~%# 						8 = Even rows offset down by 1/2 row, even columns offset left by 1/2 column~%# 						9 = Even rows offset down by 1/2 row, even columns offset right by 1/2 column~%# 0xc618	LinearizationTable	int16u[n]!	SubIFD~%# 0xc619	BlackLevelRepeatDim	int16u[2]!	SubIFD~%# 0xc61a	BlackLevel	rational64u[n]!	SubIFD~%# 0xc61b	BlackLevelDeltaH	rational64s[n]!	SubIFD~%# 0xc61c	BlackLevelDeltaV	rational64s[n]!	SubIFD~%# 0xc61d	WhiteLevel	int32u[n]!	SubIFD~%# 0xc61e	DefaultScale	rational64u[2]!	SubIFD~%# 0xc61f	DefaultCropOrigin	int32u[2]!	SubIFD~%# 0xc620	DefaultCropSize	int32u[2]!	SubIFD~%# 0xc621	ColorMatrix1	rational64s[n]!	IFD0~%# 0xc622	ColorMatrix2	rational64s[n]!	IFD0~%# 0xc623	CameraCalibration1	rational64s[n]!	IFD0~%# 0xc624	CameraCalibration2	rational64s[n]!	IFD0~%# 0xc625	ReductionMatrix1	rational64s[n]!	IFD0~%# 0xc626	ReductionMatrix2	rational64s[n]!	IFD0~%# 0xc627	AnalogBalance	rational64u[n]!	IFD0~%# 0xc628	AsShotNeutral	rational64u[n]!	IFD0~%# 0xc629	AsShotWhiteXY	rational64u[2]!	IFD0~%# 0xc62a	BaselineExposure	rational64s!	IFD0~%# 0xc62b	BaselineNoise	rational64u!	IFD0~%# 0xc62c	BaselineSharpness	rational64u!	IFD0~%# 0xc62d	BayerGreenSplit	int32u!	SubIFD~%# 0xc62e	LinearResponseLimit	rational64u!	IFD0~%# 0xc62f	CameraSerialNumber	string	IFD0~%# 0xc630	DNGLensInfo	rational64u[4]	IFD0~%# 0xc631	ChromaBlurRadius	rational64u!	SubIFD~%# 0xc632	AntiAliasStrength	rational64u!	SubIFD~%# 0xc633	ShadowScale	rational64u!	IFD0~%# 0xc634	SR2Private	-	IFD0	--> Sony SR2Private Tags~%# 						DNGAdobeData	undef!	IFD0	--> DNG AdobeData Tags~%# 						MakerNotePentax	-	IFD0	--> Pentax Tags~%# 						MakerNotePentax5	-	IFD0	--> Pentax Tags~%# 						MakerNoteRicohPentax	-	IFD0	--> Pentax Tags~%# 						DNGPrivateData	-	IFD0~%# 0xc635	MakerNoteSafety	int16u	IFD0~%# 						0 = Unsafe~%# 						1 = Safe~%# 0xc640	RawImageSegmentation	no	-	(used in segmented Canon CR2 images. 3 numbers: 1. Number of segments minus one; 2. Pixel width of segments except last; 3. Pixel width of last segment)~%# 0xc65a	CalibrationIlluminant1	int16u!	IFD0	--> EXIF LightSource Values~%# 0xc65b	CalibrationIlluminant2	int16u!	IFD0	--> EXIF LightSource Values~%# 0xc65c	BestQualityScale	rational64u!	SubIFD~%# 0xc65d	RawDataUniqueID	int8u[16]!	IFD0~%# 0xc660	AliasLayerMetadata	no	-	(used by Alias Sketchbook Pro)~%# 0xc68b	OriginalRawFileName	string!	IFD0~%# 0xc68c	OriginalRawFileData	undef!	IFD0	--> DNG OriginalRaw Tags~%# 0xc68d	ActiveArea	int32u[4]!	SubIFD~%# 0xc68e	MaskedAreas	int32u[n]!	SubIFD~%# 0xc68f	AsShotICCProfile	undef!	IFD0	--> ICC_Profile Tags~%# 0xc690	AsShotPreProfileMatrix	rational64s[n]!	IFD0~%# 0xc691	CurrentICCProfile	undef!	IFD0	--> ICC_Profile Tags~%# 0xc692	CurrentPreProfileMatrix	rational64s[n]!	IFD0~%# 0xc6bf	ColorimetricReference	int16u!	IFD0~%# 0xc6c5	SRawType	no	IFD0~%# 0xc6d2	PanasonicTitle	undef	IFD0	(proprietary Panasonic tag used for baby/pet name, etc)~%# 0xc6d3	PanasonicTitle2	undef	IFD0	(proprietary Panasonic tag used for baby/pet name with age)~%# 0xc6f3	CameraCalibrationSig	string!	IFD0~%# 0xc6f4	ProfileCalibrationSig	string!	IFD0~%# 0xc6f5	ProfileIFD	-	IFD0	--> EXIF Tags~%# 0xc6f6	AsShotProfileName	string!	IFD0~%# 0xc6f7	NoiseReductionApplied	rational64u!	SubIFD~%# 0xc6f8	ProfileName	string!	IFD0~%# 0xc6f9	ProfileHueSatMapDims	int32u[3]!	IFD0~%# 0xc6fa	ProfileHueSatMapData1	float[n]!	IFD0~%# 0xc6fb	ProfileHueSatMapData2	float[n]!	IFD0~%# 0xc6fc	ProfileToneCurve	float[n]!	IFD0~%# 0xc6fd	ProfileEmbedPolicy	int32u!	IFD0~%# 						0 = Allow Copying~%# 						1 = Embed if Used~%# 						2 = Never Embed~%# 						3 = No Restrictions~%# 0xc6fe	ProfileCopyright	string!	IFD0~%# 0xc714	ForwardMatrix1	rational64s[n]!	IFD0~%# 0xc715	ForwardMatrix2	rational64s[n]!	IFD0~%# 0xc716	PreviewApplicationName	string!	IFD0~%# 0xc717	PreviewApplicationVersion	string!	IFD0~%# 0xc718	PreviewSettingsName	string!	IFD0~%# 0xc719	PreviewSettingsDigest	int8u!	IFD0~%# 0xc71a	PreviewColorSpace	int32u!	IFD0~%# 						0 = Unknown~%# 						1 = Gray Gamma 2.2~%# 						2 = sRGB~%# 						3 = Adobe RGB~%# 						4 = ProPhoto RGB~%# 0xc71b	PreviewDateTime	string!	IFD0~%# 0xc71c	RawImageDigest	int8u[16]!	IFD0~%# 0xc71d	OriginalRawFileDigest	int8u[16]!	IFD0~%# 0xc71e	SubTileBlockSize	no	-~%# 0xc71f	RowInterleaveFactor	no	-~%# 0xc725	ProfileLookTableDims	int32u[3]!	IFD0~%# 0xc726	ProfileLookTableData	float[n]!	IFD0~%# 0xc740	OpcodeList1	undef!	SubIFD~%# 						1 = WarpRectilinear~%# 						2 = WarpFisheye~%# 						3 = FixVignetteRadial~%# 						4 = FixBadPixelsConstant~%# 						5 = FixBadPixelsList~%# 						6 = TrimBounds~%# 						7 = MapTable~%# 						8 = MapPolynomial~%# 						9 = GainMap~%# 						10 = DeltaPerRow~%# 						11 = DeltaPerColumn~%# 						12 = ScalePerRow~%# 						13 = ScalePerColumn~%# 						14 = WarpRectilinear2~%# 0xc741	OpcodeList2	undef!	SubIFD	~%# 						1 = WarpRectilinear~%# 						2 = WarpFisheye~%# 						3 = FixVignetteRadial~%# 						4 = FixBadPixelsConstant~%# 						5 = FixBadPixelsList~%# 						6 = TrimBounds~%# 						7 = MapTable~%# 						8 = MapPolynomial~%# 						9 = GainMap~%# 						10 = DeltaPerRow~%# 						11 = DeltaPerColumn~%# 						12 = ScalePerRow~%# 						13 = ScalePerColumn~%# 						14 = WarpRectilinear2~%# 0xc74e	OpcodeList3	undef!	SubIFD	~%# 						1 = WarpRectilinear~%# 						2 = WarpFisheye~%# 						3 = FixVignetteRadial~%# 						4 = FixBadPixelsConstant~%# 						5 = FixBadPixelsList~%# 						6 = TrimBounds~%# 						7 = MapTable~%# 						8 = MapPolynomial~%# 						9 = GainMap~%# 						10 = DeltaPerRow~%# 						11 = DeltaPerColumn~%# 						12 = ScalePerRow~%# 						13 = ScalePerColumn~%# 						14 = WarpRectilinear2~%# 0xc761	NoiseProfile	double[n]!	SubIFD~%# 0xc763	TimeCodes	int8u[n]	IFD0~%# 0xc764	FrameRate	rational64s	IFD0~%# 0xc772	TStop	rational64u[n]	IFD0~%# 0xc789	ReelName	string	IFD0~%# 0xc791	OriginalDefaultFinalSize	int32u[2]!	IFD0~%# 0xc792	OriginalBestQualitySize	int32u[2]!	IFD0	(called OriginalBestQualityFinalSize by the DNG spec)~%# 0xc793	OriginalDefaultCropSize	rational64u[2]!	IFD0~%# 0xc7a1	CameraLabel	string	IFD0~%# 0xc7a3	ProfileHueSatMapEncoding	int32u!	IFD0~%# 						0 = Linear~%# 						1 = sRGB~%# 0xc7a4	ProfileLookTableEncoding	int32u!	IFD0~%# 						0 = Linear~%# 						1 = sRGB~%# 0xc7a5	BaselineExposureOffset	rational64s!	IFD0~%# 0xc7a6	DefaultBlackRender	int32u!	IFD0~%# 						0 = Auto~%# 						1 = None~%# 0xc7a7	NewRawImageDigest	int8u[16]!	IFD0~%# 0xc7a8	RawToPreviewGain	double!	IFD0~%# 0xc7aa	CacheVersion	int32u!	SubIFD2~%# 0xc7b5	DefaultUserCrop	rational64u[4]!	SubIFD~%# 0xc7d5	NikonNEFInfo	-	-	--> Nikon NEFInfo Tags~%# 0xc7e9	DepthFormat	int16u!	IFD0	(tags 0xc7e9-0xc7ee added by DNG 1.5.0.0)~%# 						0 = Unknown~%# 						1 = Linear~%# 						2 = Inverse~%# 0xc7ea	DepthNear	rational64u!	IFD0~%# 0xc7eb	DepthFar	rational64u!	IFD0~%# 0xc7ec	DepthUnits	int16u!	IFD0~%# 						0 = Unknown~%# 						1 = Meters~%# 0xc7ed	DepthMeasureType	int16u!	IFD0~%# 						0 = Unknown~%# 						1 = Optical Axis~%# 						2 = Optical Ray~%# 0xc7ee	EnhanceParams	string!	IFD0~%# 0xcd2d	ProfileGainTableMap	undef!	SubIFD~%# 0xcd2e	SemanticName	no	SubIFD~%# 0xcd30	SemanticInstanceIFD	no	SubIFD~%# 0xcd31	CalibrationIlluminant3	int16u!	IFD0	--> EXIF LightSource Values~%# 0xcd32	CameraCalibration3	rational64s[n]!	IFD0~%# 0xcd33	ColorMatrix3	rational64s[n]!	IFD0~%# 0xcd34	ForwardMatrix3	rational64s[n]!	IFD0~%# 0xcd35	IlluminantData1	undef!	IFD0~%# 0xcd36	IlluminantData2	undef!	IFD0~%# 0xcd37	IlluminantData3	undef!	IFD0~%# 0xcd38	MaskSubArea	no	SubIFD~%# 0xcd39	ProfileHueSatMapData3	float[n]!	IFD0~%# 0xcd3a	ReductionMatrix3	rational64s[n]!	IFD0~%# 0xcd3b	RGBTables	undef!	IFD0~%# 0xea1c	Padding	undef!	ExifIFD~%# 0xea1d	OffsetSchema	int32s!	ExifIFD	(Microsoft's ill-conceived maker note offset difference)~%# 0xfde8	OwnerName	string/	ExifIFD	(tags 0xfde8-0xfdea and 0xfe4c-0xfe58 are generated by Photoshop Camera RAW. Some names are the same as other EXIF tags, but ExifTool will avoid writing these unless they already exist in the file)~%# 0xfde9	SerialNumber	string/	ExifIFD~%# 0xfdea	Lens	string/	ExifIFD~%# 0xfe00	KDC_IFD	-	-	--> Kodak KDC_IFD Tags# (used in some Kodak KDC images)~%# 0xfe4c	RawFile	string/	ExifIFD~%# 0xfe4d	Converter	string/	ExifIFD~%# 0xfe4e	WhiteBalance	string/	ExifIFD~%# 0xfe51	Exposure	string/	ExifIFD~%# 0xfe52	Shadows	string/	ExifIFD~%# 0xfe53	Brightness	string/	ExifIFD~%# 0xfe54	Contrast	string/	ExifIFD~%# 0xfe55	Saturation	string/	ExifIFD~%# 0xfe56	Sharpness	string/	ExifIFD~%# 0xfe57	Smoothness	string/	ExifIFD~%# 0xfe58	MoireFilter	string/	ExifIFD~%~%================================================================================~%MSG: jsk_recognition_msgs/ExifGPSInfo~%#~%# https://exiftool.org/TagNames/GPS.html~%#~%# Tag ID	Tag Name	Writable	Values / Notes~%# 0x0000	GPSVersionID	int8u[4]:~%uint8[4] gps_version_id~%# 0x0001	GPSLatitudeRef	string[2]	(tags 0x0001-0x0006 used for camera location according to MWG 2.0. ExifTool will also accept a number when writing GPSLatitudeRef, positive for north latitudes or negative for south, or a string containing N, North, S or South)~%# 						'N' = North~%# 						'S' = South~%string gps_latitude_ref~%# 0x0002	GPSLatitude	rational64u[3]~%float64[3] gps_latitude~%# 0x0003	GPSLongitudeRef	string[2]	(ExifTool will also accept a number when writing this tag, positive for east longitudes or negative for west, or a string containing E, East, W or West)~%# 						'E' = East~%# 						'W' = West~%string gps_longitude_ref~%# 0x0004	GPSLongitude	rational64u[3]~%float64[3] gps_longitude~%# 0x0005	GPSAltitudeRef	int8u	(ExifTool will also accept number when writing this tag, with negative numbers indicating below sea level)~%uint8 gps_altitude_ref~%# 						0 = Above Sea Level~%# 						1 = Below Sea Level~%# 0x0006	GPSAltitude	rational64u~%float64 gps_altitude~%# 0x0007	GPSTimeStamp	rational64u[3]	(UTC time of GPS fix. When writing, date is stripped off if present, and time is adjusted to UTC if it includes a timezone)~%float64 gps_time_stamp~%# 0x0008	GPSSatellites	string~%string gps_satellites~%# 0x0009	GPSStatus	string[2]~%# 						'A' = Measurement Active~%# 						'V' = Measurement Void~%string gps_status~%# 0x000a	GPSMeasureMode	string[2]~%# 						2 = 2-Dimensional Measurement~%# 						3 = 3-Dimensional Measurement~%string gps_measure_mode~%# 0x000b	GPSDOP	rational64u~%float64 gpf_sdop~%# 0x000c	GPSSpeedRef	string[2]~%# 						'K' = km/h~%# 						'M' = mph~%# 						'N' = knots~%string gps_speed_ref~%# 0x000d	GPSSpeed	rational64u~%float64 gps_speed~%# 0x000e	GPSTrackRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_track_ref~%# 0x000f	GPSTrack	rational64u~%float64 gps_track~%# 0x0010	GPSImgDirectionRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_img_direction_ref~%# 0x0011	GPSImgDirection	rational64u~%float64 gps_img_direction~%# 0x0012	GPSMapDatum	string~%string gps_map_datum~%# 0x0013	GPSDestLatitudeRef	string[2]	(tags 0x0013-0x001a used for subject location according to MWG 2.0)~%# 						'N' = North~%# 						'S' = South~%string gps_dest_latitude_ref~%# 0x0014	GPSDestLatitude	rational64u[3]~%float64[3] gps_dest_latitude~%# 0x0015	GPSDestLongitudeRef	string[2]~%# 						'E' = East~%# 						'W' = West~%string gps_dest_longitude_ref~%# 0x0016	GPSDestLongitude	rational64u[3]~%float64[3] gps_dest_longitude~%# 0x0017	GPSDestBearingRef	string[2]~%# 						'M' = Magnetic North~%# 						'T' = True North~%string gps_dest_bearing_ref~%# 0x0018	GPSDestBearing	rational64u~%float64 gps_dest_bearing~%# 0x0019	GPSDestDistanceRef	string[2]~%# 						'K' = Kilometers~%# 						'M' = Miles~%# 						'N' = Nautical Miles~%string gps_dest_distance_ref~%# 0x001a	GPSDestDistance	rational64u~%float64 gps_dest_distance~%# 0x001b	GPSProcessingMethod	undef	(values of \"GPS\", \"CELLID\", \"WLAN\" or \"MANUAL\" by the EXIF spec.)~%# 0x001c	GPSAreaInformation	undef~%# 0x001d	GPSDateStamp	string[11]	(when writing, time is stripped off if present, after adjusting date/time to UTC if time includes a timezone. Format is YYYY:mm:dd)~%string gps_date_stamp~%# 0x001e	GPSDifferential	int16u~%# 						0 = No Correction~%# 						1 = Differential Corrected~%uint16 gps_differential~%# 0x001f	GPSHPositioningError	rational64u~%float64 gps_hpositioning_error~%~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <ExifTags>))
  (cl:+ 0
     4 (cl:length (cl:slot-value msg 'interop_index))
     4
     4
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'bits_per_sample) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     2
     4 (cl:length (cl:slot-value msg 'image_description))
     4 (cl:length (cl:slot-value msg 'make))
     4 (cl:length (cl:slot-value msg 'model))
     4
     2
     2
     4
     4
     8
     8
     2
     2
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'transfer_function) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     4 (cl:length (cl:slot-value msg 'software))
     4 (cl:length (cl:slot-value msg 'date_time))
     4 (cl:length (cl:slot-value msg 'artist))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'white_point) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'primary_chromaticities) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4
     4
     4
     4
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'ycb_cr_Coefficients) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'ycb_cr_sub_sampling) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     2
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'reference_black_white) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4 (cl:length (cl:slot-value msg 'copyright))
     8
     8
     2
     (roslisp-msg-protocol:serialization-length (cl:slot-value msg 'gps_info))
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'iso) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     2
     4
     4
     4
     4
     4
     4 (cl:length (cl:slot-value msg 'exif_version))
     4 (cl:length (cl:slot-value msg 'date_time_original))
     4 (cl:length (cl:slot-value msg 'date_time_digitized))
     4 (cl:length (cl:slot-value msg 'offset_time))
     4 (cl:length (cl:slot-value msg 'offset_time_original))
     4 (cl:length (cl:slot-value msg 'offset_time_digitized))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'components_configuration) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 1)))
     8
     8
     8
     8
     8
     8
     8
     2
     2
     2
     8
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'subject_area) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     4 (cl:length (cl:slot-value msg 'user_comment))
     4 (cl:length (cl:slot-value msg 'subsec_time))
     4 (cl:length (cl:slot-value msg 'subsec_time_original))
     4 (cl:length (cl:slot-value msg 'subsec_time_digitized))
     8
     8
     8
     8
     8
     8
     4 (cl:length (cl:slot-value msg 'flash_pix_version))
     2
     2
     2
     4 (cl:length (cl:slot-value msg 'related_sound_file))
     8
     8
     8
     2
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'subject_location) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     8
     2
     4 (cl:length (cl:slot-value msg 'scene_type))
     2
     2
     2
     8
     2
     2
     2
     2
     2
     2
     2
     4 (cl:length (cl:slot-value msg 'image_unique_id))
     4 (cl:length (cl:slot-value msg 'camera_owner_name))
     4 (cl:length (cl:slot-value msg 'body_serial_number))
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'lens_specification) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 8)))
     4 (cl:length (cl:slot-value msg 'lens_make))
     4 (cl:length (cl:slot-value msg 'lens_model))
     4 (cl:length (cl:slot-value msg 'lens_serial_number))
     2
     0 (cl:reduce #'cl:+ (cl:slot-value msg 'composite_image_count) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ 2)))
     8
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <ExifTags>))
  "Converts a ROS message object to a list"
  (cl:list 'ExifTags
    (cl:cons ':interop_index (interop_index msg))
    (cl:cons ':image_width (image_width msg))
    (cl:cons ':image_height (image_height msg))
    (cl:cons ':bits_per_sample (bits_per_sample msg))
    (cl:cons ':photometric_interpretation (photometric_interpretation msg))
    (cl:cons ':image_description (image_description msg))
    (cl:cons ':make (make msg))
    (cl:cons ':model (model msg))
    (cl:cons ':strip_offsets (strip_offsets msg))
    (cl:cons ':orientation (orientation msg))
    (cl:cons ':samples_per_pixel (samples_per_pixel msg))
    (cl:cons ':rows_per_strip (rows_per_strip msg))
    (cl:cons ':strip_byte_counts (strip_byte_counts msg))
    (cl:cons ':x_resolution (x_resolution msg))
    (cl:cons ':y_resolution (y_resolution msg))
    (cl:cons ':planar_configuration (planar_configuration msg))
    (cl:cons ':resolution_unit (resolution_unit msg))
    (cl:cons ':transfer_function (transfer_function msg))
    (cl:cons ':software (software msg))
    (cl:cons ':date_time (date_time msg))
    (cl:cons ':artist (artist msg))
    (cl:cons ':white_point (white_point msg))
    (cl:cons ':primary_chromaticities (primary_chromaticities msg))
    (cl:cons ':tile_width (tile_width msg))
    (cl:cons ':tile_length (tile_length msg))
    (cl:cons ':jpg_from_raw_start (jpg_from_raw_start msg))
    (cl:cons ':jpg_from_raw_length (jpg_from_raw_length msg))
    (cl:cons ':ycb_cr_Coefficients (ycb_cr_Coefficients msg))
    (cl:cons ':ycb_cr_sub_sampling (ycb_cr_sub_sampling msg))
    (cl:cons ':ycb_cr_positioning (ycb_cr_positioning msg))
    (cl:cons ':reference_black_white (reference_black_white msg))
    (cl:cons ':copyright (copyright msg))
    (cl:cons ':exposure_time (exposure_time msg))
    (cl:cons ':f_number (f_number msg))
    (cl:cons ':exposure_program (exposure_program msg))
    (cl:cons ':gps_info (gps_info msg))
    (cl:cons ':iso (iso msg))
    (cl:cons ':sensitivity_type (sensitivity_type msg))
    (cl:cons ':standard_output_sensitivity (standard_output_sensitivity msg))
    (cl:cons ':recommended_exposure_index (recommended_exposure_index msg))
    (cl:cons ':iso_speed (iso_speed msg))
    (cl:cons ':iso_speed_latitudeyyy (iso_speed_latitudeyyy msg))
    (cl:cons ':iso_speed_latitudezzz (iso_speed_latitudezzz msg))
    (cl:cons ':exif_version (exif_version msg))
    (cl:cons ':date_time_original (date_time_original msg))
    (cl:cons ':date_time_digitized (date_time_digitized msg))
    (cl:cons ':offset_time (offset_time msg))
    (cl:cons ':offset_time_original (offset_time_original msg))
    (cl:cons ':offset_time_digitized (offset_time_digitized msg))
    (cl:cons ':components_configuration (components_configuration msg))
    (cl:cons ':compressed_bits_per_pixel (compressed_bits_per_pixel msg))
    (cl:cons ':shutter_speed_value (shutter_speed_value msg))
    (cl:cons ':aperture_value (aperture_value msg))
    (cl:cons ':brightness_value (brightness_value msg))
    (cl:cons ':exposure_bias_value (exposure_bias_value msg))
    (cl:cons ':max_aperture_value (max_aperture_value msg))
    (cl:cons ':subject_distance (subject_distance msg))
    (cl:cons ':metering_mode (metering_mode msg))
    (cl:cons ':light_source (light_source msg))
    (cl:cons ':flash (flash msg))
    (cl:cons ':focal_length (focal_length msg))
    (cl:cons ':subject_area (subject_area msg))
    (cl:cons ':user_comment (user_comment msg))
    (cl:cons ':subsec_time (subsec_time msg))
    (cl:cons ':subsec_time_original (subsec_time_original msg))
    (cl:cons ':subsec_time_digitized (subsec_time_digitized msg))
    (cl:cons ':temperature (temperature msg))
    (cl:cons ':humidity (humidity msg))
    (cl:cons ':pressure (pressure msg))
    (cl:cons ':water_depth (water_depth msg))
    (cl:cons ':acceleration (acceleration msg))
    (cl:cons ':camera_elevation_angle (camera_elevation_angle msg))
    (cl:cons ':flash_pix_version (flash_pix_version msg))
    (cl:cons ':color_space (color_space msg))
    (cl:cons ':exif_image_width (exif_image_width msg))
    (cl:cons ':exif_image_height (exif_image_height msg))
    (cl:cons ':related_sound_file (related_sound_file msg))
    (cl:cons ':flash_energy (flash_energy msg))
    (cl:cons ':focal_plane_x_resolution (focal_plane_x_resolution msg))
    (cl:cons ':focal_plane_y_resolution (focal_plane_y_resolution msg))
    (cl:cons ':focal_plane_resolution_unit (focal_plane_resolution_unit msg))
    (cl:cons ':subject_location (subject_location msg))
    (cl:cons ':exposure_index (exposure_index msg))
    (cl:cons ':sensing_method (sensing_method msg))
    (cl:cons ':scene_type (scene_type msg))
    (cl:cons ':custom_rendered (custom_rendered msg))
    (cl:cons ':exposure_mode (exposure_mode msg))
    (cl:cons ':white_balance (white_balance msg))
    (cl:cons ':digital_zoom_ratio (digital_zoom_ratio msg))
    (cl:cons ':focal_length_in_35mm_film (focal_length_in_35mm_film msg))
    (cl:cons ':scene_capture_type (scene_capture_type msg))
    (cl:cons ':gain_control (gain_control msg))
    (cl:cons ':contrast (contrast msg))
    (cl:cons ':saturation (saturation msg))
    (cl:cons ':sharpness (sharpness msg))
    (cl:cons ':subject_distance_range (subject_distance_range msg))
    (cl:cons ':image_unique_id (image_unique_id msg))
    (cl:cons ':camera_owner_name (camera_owner_name msg))
    (cl:cons ':body_serial_number (body_serial_number msg))
    (cl:cons ':lens_specification (lens_specification msg))
    (cl:cons ':lens_make (lens_make msg))
    (cl:cons ':lens_model (lens_model msg))
    (cl:cons ':lens_serial_number (lens_serial_number msg))
    (cl:cons ':composite_image (composite_image msg))
    (cl:cons ':composite_image_count (composite_image_count msg))
    (cl:cons ':gamma (gamma msg))
))
