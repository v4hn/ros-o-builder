
"use strict";

let ObjectRecognitionActionResult = require('./ObjectRecognitionActionResult.js');
let ObjectRecognitionGoal = require('./ObjectRecognitionGoal.js');
let ObjectRecognitionActionGoal = require('./ObjectRecognitionActionGoal.js');
let ObjectRecognitionActionFeedback = require('./ObjectRecognitionActionFeedback.js');
let ObjectRecognitionAction = require('./ObjectRecognitionAction.js');
let ObjectRecognitionResult = require('./ObjectRecognitionResult.js');
let ObjectRecognitionFeedback = require('./ObjectRecognitionFeedback.js');
let RecognizedObjectArray = require('./RecognizedObjectArray.js');
let RecognizedObject = require('./RecognizedObject.js');
let ObjectInformation = require('./ObjectInformation.js');
let ObjectType = require('./ObjectType.js');
let TableArray = require('./TableArray.js');
let Table = require('./Table.js');

module.exports = {
  ObjectRecognitionActionResult: ObjectRecognitionActionResult,
  ObjectRecognitionGoal: ObjectRecognitionGoal,
  ObjectRecognitionActionGoal: ObjectRecognitionActionGoal,
  ObjectRecognitionActionFeedback: ObjectRecognitionActionFeedback,
  ObjectRecognitionAction: ObjectRecognitionAction,
  ObjectRecognitionResult: ObjectRecognitionResult,
  ObjectRecognitionFeedback: ObjectRecognitionFeedback,
  RecognizedObjectArray: RecognizedObjectArray,
  RecognizedObject: RecognizedObject,
  ObjectInformation: ObjectInformation,
  ObjectType: ObjectType,
  TableArray: TableArray,
  Table: Table,
};
