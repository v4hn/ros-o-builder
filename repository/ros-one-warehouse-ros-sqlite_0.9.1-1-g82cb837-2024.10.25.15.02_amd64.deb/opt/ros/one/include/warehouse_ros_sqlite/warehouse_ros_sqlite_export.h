
#ifndef WAREHOUSE_ROS_SQLITE_EXPORT_H
#define WAREHOUSE_ROS_SQLITE_EXPORT_H

#ifdef WAREHOUSE_ROS_SQLITE_STATIC_DEFINE
#  define WAREHOUSE_ROS_SQLITE_EXPORT
#  define WAREHOUSE_ROS_SQLITE_NO_EXPORT
#else
#  ifndef WAREHOUSE_ROS_SQLITE_EXPORT
#    ifdef warehouse_ros_sqlite_EXPORTS
        /* We are building this library */
#      define WAREHOUSE_ROS_SQLITE_EXPORT __attribute__((visibility("default")))
#    else
        /* We are using this library */
#      define WAREHOUSE_ROS_SQLITE_EXPORT __attribute__((visibility("default")))
#    endif
#  endif

#  ifndef WAREHOUSE_ROS_SQLITE_NO_EXPORT
#    define WAREHOUSE_ROS_SQLITE_NO_EXPORT __attribute__((visibility("hidden")))
#  endif
#endif

#ifndef WAREHOUSE_ROS_SQLITE_DEPRECATED
#  define WAREHOUSE_ROS_SQLITE_DEPRECATED __attribute__ ((__deprecated__))
#endif

#ifndef WAREHOUSE_ROS_SQLITE_DEPRECATED_EXPORT
#  define WAREHOUSE_ROS_SQLITE_DEPRECATED_EXPORT WAREHOUSE_ROS_SQLITE_EXPORT WAREHOUSE_ROS_SQLITE_DEPRECATED
#endif

#ifndef WAREHOUSE_ROS_SQLITE_DEPRECATED_NO_EXPORT
#  define WAREHOUSE_ROS_SQLITE_DEPRECATED_NO_EXPORT WAREHOUSE_ROS_SQLITE_NO_EXPORT WAREHOUSE_ROS_SQLITE_DEPRECATED
#endif

/* NOLINTNEXTLINE(readability-avoid-unconditional-preprocessor-if) */
#if 0 /* DEFINE_NO_DEPRECATED */
#  ifndef WAREHOUSE_ROS_SQLITE_NO_DEPRECATED
#    define WAREHOUSE_ROS_SQLITE_NO_DEPRECATED
#  endif
#endif

#endif /* WAREHOUSE_ROS_SQLITE_EXPORT_H */
