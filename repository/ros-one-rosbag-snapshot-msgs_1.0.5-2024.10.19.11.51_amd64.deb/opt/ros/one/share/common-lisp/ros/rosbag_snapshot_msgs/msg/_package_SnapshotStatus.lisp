(cl:in-package rosbag_snapshot_msgs-msg)
(cl:export '(TOPICS-VAL
          TOPICS
          ENABLED-VAL
          ENABLED
))