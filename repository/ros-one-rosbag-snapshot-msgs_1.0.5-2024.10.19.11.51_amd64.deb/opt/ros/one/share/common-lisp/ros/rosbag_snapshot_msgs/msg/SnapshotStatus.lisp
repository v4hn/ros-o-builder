; Auto-generated. Do not edit!


(cl:in-package rosbag_snapshot_msgs-msg)


;//! \htmlinclude SnapshotStatus.msg.html

(cl:defclass <SnapshotStatus> (roslisp-msg-protocol:ros-message)
  ((topics
    :reader topics
    :initarg :topics
    :type (cl:vector rosgraph_msgs-msg:TopicStatistics)
   :initform (cl:make-array 0 :element-type 'rosgraph_msgs-msg:TopicStatistics :initial-element (cl:make-instance 'rosgraph_msgs-msg:TopicStatistics)))
   (enabled
    :reader enabled
    :initarg :enabled
    :type cl:boolean
    :initform cl:nil))
)

(cl:defclass SnapshotStatus (<SnapshotStatus>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <SnapshotStatus>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'SnapshotStatus)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name rosbag_snapshot_msgs-msg:<SnapshotStatus> is deprecated: use rosbag_snapshot_msgs-msg:SnapshotStatus instead.")))

(cl:ensure-generic-function 'topics-val :lambda-list '(m))
(cl:defmethod topics-val ((m <SnapshotStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-msg:topics-val is deprecated.  Use rosbag_snapshot_msgs-msg:topics instead.")
  (topics m))

(cl:ensure-generic-function 'enabled-val :lambda-list '(m))
(cl:defmethod enabled-val ((m <SnapshotStatus>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader rosbag_snapshot_msgs-msg:enabled-val is deprecated.  Use rosbag_snapshot_msgs-msg:enabled instead.")
  (enabled m))
(cl:defmethod roslisp-msg-protocol:serialize ((msg <SnapshotStatus>) ostream)
  "Serializes a message object of type '<SnapshotStatus>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'topics))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'topics))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'enabled) 1 0)) ostream)
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <SnapshotStatus>) istream)
  "Deserializes a message object of type '<SnapshotStatus>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'topics) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'topics)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'rosgraph_msgs-msg:TopicStatistics))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
    (cl:setf (cl:slot-value msg 'enabled) (cl:not (cl:zerop (cl:read-byte istream))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<SnapshotStatus>)))
  "Returns string type for a message object of type '<SnapshotStatus>"
  "rosbag_snapshot_msgs/SnapshotStatus")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'SnapshotStatus)))
  "Returns string type for a message object of type 'SnapshotStatus"
  "rosbag_snapshot_msgs/SnapshotStatus")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<SnapshotStatus>)))
  "Returns md5sum for a message object of type '<SnapshotStatus>"
  "da7b0d829f1bb54c3d787d81f6befe0f")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'SnapshotStatus)))
  "Returns md5sum for a message object of type 'SnapshotStatus"
  "da7b0d829f1bb54c3d787d81f6befe0f")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<SnapshotStatus>)))
  "Returns full string definition for message of type '<SnapshotStatus>"
  (cl:format cl:nil "# Describes the current status of a running 'rosbag_snapshot' node~%~%# Information about the buffer of subscribed topics~%# The period, stamp, node_pub, and dropped_msgs fields are left empty~%rosgraph_msgs/TopicStatistics[] topics~%# If true, new messages are being added to the snapshot buffers~%# If false, snapshotter is currently paused or writing to a bag file~%bool enabled~%~%================================================================================~%MSG: rosgraph_msgs/TopicStatistics~%# name of the topic~%string topic~%~%# node id of the publisher~%string node_pub~%~%# node id of the subscriber~%string node_sub~%~%# the statistics apply to this time window~%time window_start~%time window_stop~%~%# number of messages delivered during the window~%int32 delivered_msgs~%# numbers of messages dropped during the window~%int32 dropped_msgs~%~%# traffic during the window, in bytes~%int32 traffic~%~%# mean/stddev/max period between two messages~%duration period_mean~%duration period_stddev~%duration period_max~%~%# mean/stddev/max age of the message based on the~%# timestamp in the message header. In case the~%# message does not have a header, it will be 0.~%duration stamp_age_mean~%duration stamp_age_stddev~%duration stamp_age_max~%~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'SnapshotStatus)))
  "Returns full string definition for message of type 'SnapshotStatus"
  (cl:format cl:nil "# Describes the current status of a running 'rosbag_snapshot' node~%~%# Information about the buffer of subscribed topics~%# The period, stamp, node_pub, and dropped_msgs fields are left empty~%rosgraph_msgs/TopicStatistics[] topics~%# If true, new messages are being added to the snapshot buffers~%# If false, snapshotter is currently paused or writing to a bag file~%bool enabled~%~%================================================================================~%MSG: rosgraph_msgs/TopicStatistics~%# name of the topic~%string topic~%~%# node id of the publisher~%string node_pub~%~%# node id of the subscriber~%string node_sub~%~%# the statistics apply to this time window~%time window_start~%time window_stop~%~%# number of messages delivered during the window~%int32 delivered_msgs~%# numbers of messages dropped during the window~%int32 dropped_msgs~%~%# traffic during the window, in bytes~%int32 traffic~%~%# mean/stddev/max period between two messages~%duration period_mean~%duration period_stddev~%duration period_max~%~%# mean/stddev/max age of the message based on the~%# timestamp in the message header. In case the~%# message does not have a header, it will be 0.~%duration stamp_age_mean~%duration stamp_age_stddev~%duration stamp_age_max~%~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <SnapshotStatus>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'topics) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <SnapshotStatus>))
  "Converts a ROS message object to a list"
  (cl:list 'SnapshotStatus
    (cl:cons ':topics (topics msg))
    (cl:cons ':enabled (enabled msg))
))
