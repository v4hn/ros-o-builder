
(cl:in-package :asdf)

(defsystem "rosbag_snapshot_msgs-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :rosgraph_msgs-msg
)
  :components ((:file "_package")
    (:file "SnapshotStatus" :depends-on ("_package_SnapshotStatus"))
    (:file "_package_SnapshotStatus" :depends-on ("_package"))
  ))