
(cl:in-package :asdf)

(defsystem "rosbag_snapshot_msgs-srv"
  :depends-on (:roslisp-msg-protocol :roslisp-utils )
  :components ((:file "_package")
    (:file "TriggerSnapshot" :depends-on ("_package_TriggerSnapshot"))
    (:file "_package_TriggerSnapshot" :depends-on ("_package"))
  ))