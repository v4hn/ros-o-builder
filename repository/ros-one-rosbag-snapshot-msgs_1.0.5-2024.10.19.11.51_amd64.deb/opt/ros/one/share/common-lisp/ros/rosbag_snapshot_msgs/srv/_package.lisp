(cl:defpackage rosbag_snapshot_msgs-srv
  (:use )
  (:export
   "TRIGGERSNAPSHOT"
   "<TRIGGERSNAPSHOT-REQUEST>"
   "TRIGGERSNAPSHOT-REQUEST"
   "<TRIGGERSNAPSHOT-RESPONSE>"
   "TRIGGERSNAPSHOT-RESPONSE"
  ))

