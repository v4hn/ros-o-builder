
"use strict";

let ActuatorInfo = require('./ActuatorInfo.js');
let RawFTData = require('./RawFTData.js');
let MotorTraceSample = require('./MotorTraceSample.js');
let MotorTrace = require('./MotorTrace.js');
let RawFTDataSample = require('./RawFTDataSample.js');
let BoardInfo = require('./BoardInfo.js');
let MotorTemperature = require('./MotorTemperature.js');

module.exports = {
  ActuatorInfo: ActuatorInfo,
  RawFTData: RawFTData,
  MotorTraceSample: MotorTraceSample,
  MotorTrace: MotorTrace,
  RawFTDataSample: RawFTDataSample,
  BoardInfo: BoardInfo,
  MotorTemperature: MotorTemperature,
};
