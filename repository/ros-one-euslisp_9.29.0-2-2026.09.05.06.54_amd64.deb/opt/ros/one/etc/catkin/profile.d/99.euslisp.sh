export ARCHDIR=Linux64
export EUSDIR="/opt/ros/one/share/euslisp/jskeus/eus/"
export LD_LIBRARY_PATH="$EUSDIR/$ARCHDIR/lib:$LD_LIBRARY_PATH"
export PATH="$EUSDIR/$ARCHDIR/bin:$PATH"
