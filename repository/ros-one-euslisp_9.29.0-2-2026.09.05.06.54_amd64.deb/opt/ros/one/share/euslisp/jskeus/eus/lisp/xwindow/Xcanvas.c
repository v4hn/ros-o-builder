/* ./Xcanvas.c :  entry=Xcanvas */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Sep 5 06:56:26 UTC 2026) */
#include "eus.h"
#include "Xcanvas.h"
#pragma init (register_Xcanvas)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___Xcanvas();
extern pointer build_quote_vector();
static int register_Xcanvas()
  { add_module_initializer("___Xcanvas", ___Xcanvas);}


/*:create*/
static pointer XcanvasM2819canvas_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XcanvasRST2821:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[0]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[1]));
	local[4]= fqv[2];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= loadglobal(fqv[3]);
	ctx->vsp=local+2;
	w=(pointer)INSTANTIATE(ctx,1,local+1); /*instantiate*/
	local[1]= w;
	local[2]= local[1];
	local[3]= fqv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	w = local[1];
	argv[0]->c.obj.iv[15] = w;
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[6];
	local[5]= argv[0];
	local[6]= fqv[7];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)65535L);
	local[10]= makeint((eusinteger_t)4096L);
	local[11]= makeint((eusinteger_t)4096L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[10];
	local[5]= argv[0];
	local[6]= fqv[7];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)4096L);
	local[10]= makeint((eusinteger_t)4096L);
	local[11]= makeint((eusinteger_t)65535L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[11];
	local[5]= argv[0];
	local[6]= fqv[7];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)4096L);
	local[10]= makeint((eusinteger_t)65535L);
	local[11]= makeint((eusinteger_t)4096L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[12];
	local[5]= argv[0];
	local[6]= fqv[13];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[14];
	local[5]= argv[0];
	local[6]= fqv[15];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)65535L);
	local[10]= makeint((eusinteger_t)65535L);
	local[11]= makeint((eusinteger_t)65535L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[16];
	local[5]= argv[0];
	local[6]= fqv[15];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)49152L);
	local[10]= makeint((eusinteger_t)49152L);
	local[11]= makeint((eusinteger_t)49152L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[17];
	local[5]= argv[0];
	local[6]= fqv[15];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)16384L);
	local[10]= makeint((eusinteger_t)16384L);
	local[11]= makeint((eusinteger_t)16384L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	local[1]= argv[0]->c.obj.iv[15];
	local[2]= fqv[4];
	local[3]= loadglobal(fqv[5]);
	local[4]= fqv[18];
	local[5]= argv[0];
	local[6]= fqv[15];
	local[7]= loadglobal(fqv[8]);
	local[8]= fqv[9];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,5,local+7); /*send*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,2,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,6,local+1); /*send*/
	w = argv[0];
	local[0]= w;
XcanvasBLK2820:
	ctx->vsp=local; return(local[0]);}

/*:selection*/
static pointer XcanvasM2822canvas_selection(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= argv[0]->c.obj.iv[13];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,2,local+0); /*list*/
	local[0]= w;
XcanvasBLK2823:
	ctx->vsp=local; return(local[0]);}

/*:adjust-corners*/
static pointer XcanvasM2824canvas_adjust_corners(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[13];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MIN(ctx,2,local+0); /*min*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[13];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKINTVECTOR(ctx,2,local+0); /*integer-vector*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[13];
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAX(ctx,2,local+1); /*max*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[12];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[13];
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,2,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)MAX(ctx,2,local+2); /*max*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MKINTVECTOR(ctx,2,local+1); /*integer-vector*/
	local[1]= w;
	local[2]= local[1];
	local[3]= local[0];
	argv[0]->c.obj.iv[13] = local[2];
	argv[0]->c.obj.iv[12] = local[3];
	w = NIL;
	local[0]= w;
XcanvasBLK2825:
	ctx->vsp=local; return(local[0]);}

/*:draw-selection-rectangle*/
static pointer XcanvasM2826canvas_draw_selection_rectangle(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[12];
	local[1]= makeint((eusinteger_t)0L);
	ctx->vsp=local+2;
	w=(pointer)AREF(ctx,2,local+0); /*aref*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[13];
	local[2]= makeint((eusinteger_t)0L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MIN(ctx,2,local+0); /*min*/
	local[0]= w;
	local[1]= argv[0]->c.obj.iv[12];
	local[2]= makeint((eusinteger_t)1L);
	ctx->vsp=local+3;
	w=(pointer)AREF(ctx,2,local+1); /*aref*/
	local[1]= w;
	local[2]= argv[0]->c.obj.iv[13];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MIN(ctx,2,local+1); /*min*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)MKINTVECTOR(ctx,2,local+0); /*integer-vector*/
	local[0]= w;
	local[1]= argv[0];
	local[2]= fqv[19];
	local[3]= local[0];
	local[4]= argv[0]->c.obj.iv[13];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[12];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)MINUS(ctx,2,local+4); /*-*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ABS(ctx,1,local+4); /*abs*/
	local[4]= w;
	local[5]= argv[0]->c.obj.iv[13];
	local[6]= makeint((eusinteger_t)1L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,2,local+5); /*aref*/
	local[5]= w;
	local[6]= argv[0]->c.obj.iv[12];
	local[7]= makeint((eusinteger_t)1L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,5,local+1); /*send*/
	local[0]= w;
XcanvasBLK2827:
	ctx->vsp=local; return(local[0]);}

/*:buttonpress*/
static pointer XcanvasM2828canvas_buttonpress(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	local[3]= loadglobal(fqv[20]);
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,1,local+3,&ftab[0],fqv[21]); /*event-button*/
	local[3]= w;
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)2L);
	ctx->vsp=local+6;
	w=(pointer)LSEQP(ctx,2,local+4); /*<=*/
	if (w==NIL) goto XcanvasCON2831;
	local[4]= argv[0];
	local[5]= fqv[22];
	local[6]= fqv[23];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= argv[0]->c.obj.iv[3];
	local[5]= fqv[24];
	local[6]= makeint((eusinteger_t)127L);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= loadglobal(fqv[20]);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[25]); /*event-pos*/
	argv[0]->c.obj.iv[12] = w;
	local[4]= argv[0]->c.obj.iv[12];
	ctx->vsp=local+5;
	w=(pointer)COPYSEQ(ctx,1,local+4); /*copy-seq*/
	argv[0]->c.obj.iv[13] = w;
	local[4]= argv[0];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	argv[0]->c.obj.iv[14] = T;
	local[4]= argv[0]->c.obj.iv[14];
	goto XcanvasCON2830;
XcanvasCON2831:
	local[4]= local[3];
	local[5]= makeint((eusinteger_t)3L);
	ctx->vsp=local+6;
	w=(pointer)EQ(ctx,2,local+4); /*eql*/
	if (w==NIL) goto XcanvasCON2832;
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= fqv[27];
	local[6]= loadglobal(fqv[20]);
	ctx->vsp=local+7;
	w=(*ftab[2])(ctx,1,local+6,&ftab[2],fqv[28]); /*event-x-root*/
	local[6]= w;
	local[7]= loadglobal(fqv[20]);
	ctx->vsp=local+8;
	w=(*ftab[3])(ctx,1,local+7,&ftab[3],fqv[29]); /*event-y-root*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,4,local+4); /*send*/
	local[4]= w;
	goto XcanvasCON2830;
XcanvasCON2832:
	local[4]= NIL;
XcanvasCON2830:
	w = local[4];
	local[3]= w;
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XcanvasBLK2829:
	ctx->vsp=local; return(local[0]);}

/*:motionnotify*/
static pointer XcanvasM2833canvas_motionnotify(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	if (argv[0]->c.obj.iv[14]==NIL) goto XcanvasIF2835;
	local[3]= loadglobal(fqv[20]);
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,1,local+3,&ftab[4],fqv[30]); /*event-state*/
	local[3]= w;
	local[4]= fqv[31];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[32]); /*member*/
	if (w==NIL) goto XcanvasCON2838;
	local[4]= argv[0];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= loadglobal(fqv[20]);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[25]); /*event-pos*/
	argv[0]->c.obj.iv[13] = w;
	local[4]= argv[0];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	goto XcanvasCON2837;
XcanvasCON2838:
	local[4]= fqv[33];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[32]); /*member*/
	if (w==NIL) goto XcanvasCON2839;
	local[4]= argv[0]->c.obj.iv[15];
	local[5]= fqv[34];
	local[6]= loadglobal(fqv[20]);
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XcanvasCON2837;
XcanvasCON2839:
	local[4]= NIL;
XcanvasCON2837:
	w = local[4];
	local[3]= w;
	goto XcanvasIF2836;
XcanvasIF2835:
	local[3]= NIL;
XcanvasIF2836:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XcanvasBLK2834:
	ctx->vsp=local; return(local[0]);}

/*:buttonrelease*/
static pointer XcanvasM2840canvas_buttonrelease(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	w = argv[2];
	ctx->vsp=local+0;
	bindspecial(ctx,fqv[20],w);
	if (argv[0]->c.obj.iv[14]==NIL) goto XcanvasCON2843;
	local[3]= loadglobal(fqv[20]);
	ctx->vsp=local+4;
	w=(*ftab[4])(ctx,1,local+3,&ftab[4],fqv[30]); /*event-state*/
	local[3]= w;
	local[4]= fqv[35];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[32]); /*member*/
	if (w==NIL) goto XcanvasCON2845;
	local[4]= fqv[33];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[32]); /*member*/
	if (w==NIL) goto XcanvasCON2845;
	local[4]= argv[0];
	local[5]= fqv[36];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[22];
	local[6]= fqv[37];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XcanvasCON2844;
XcanvasCON2845:
	local[4]= fqv[33];
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(*ftab[5])(ctx,2,local+4,&ftab[5],fqv[32]); /*member*/
	if (w==NIL) goto XcanvasCON2846;
	local[4]= argv[0]->c.obj.iv[15];
	storeglobal(fqv[38],local[4]);
	goto XcanvasCON2844;
XcanvasCON2846:
	local[4]= argv[0];
	local[5]= fqv[26];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= argv[0];
	local[5]= fqv[22];
	local[6]= fqv[37];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= loadglobal(fqv[20]);
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,1,local+4,&ftab[1],fqv[25]); /*event-pos*/
	argv[0]->c.obj.iv[13] = w;
	argv[0]->c.obj.iv[14] = NIL;
	local[4]= argv[0]->c.obj.iv[14];
	goto XcanvasCON2844;
XcanvasCON2847:
	local[4]= NIL;
XcanvasCON2844:
	w = local[4];
	local[3]= w;
	goto XcanvasCON2842;
XcanvasCON2843:
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[1]));
	local[5]= fqv[39];
	local[6]= loadglobal(fqv[20]);
	ctx->vsp=local+7;
	w=(pointer)SENDMESSAGE(ctx,4,local+3); /*send-message*/
	local[3]= w;
	goto XcanvasCON2842;
XcanvasCON2848:
	local[3]= NIL;
XcanvasCON2842:
	ctx->vsp=local+4;
	unbindx(ctx,1);
	w = local[3];
	local[0]= w;
XcanvasBLK2841:
	ctx->vsp=local; return(local[0]);}

/*:clear-event*/
static pointer XcanvasM2849canvas_clear_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[36];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XcanvasBLK2850:
	ctx->vsp=local; return(local[0]);}

/*:color-event*/
static pointer XcanvasM2851canvas_color_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[24];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XcanvasBLK2852:
	ctx->vsp=local; return(local[0]);}

/*:background-event*/
static pointer XcanvasM2853canvas_background_event(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[40];
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XcanvasBLK2854:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XcanvasM2855graph_canvas_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XcanvasRST2857:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[41], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XcanvasKEY2858;
	local[1] = makeflt(1.0000000000000000000000e+00);
XcanvasKEY2858:
	if (n & (1<<1)) goto XcanvasKEY2859;
	local[2] = makeflt(-1.0000000000000000000000e+00);
XcanvasKEY2859:
	if (n & (1<<2)) goto XcanvasKEY2860;
	local[3] = loadglobal(fqv[42]);
XcanvasKEY2860:
	if (n & (1<<3)) goto XcanvasKEY2861;
	local[4] = makeint((eusinteger_t)1L);
XcanvasKEY2861:
	if (n & (1<<4)) goto XcanvasKEY2862;
	local[5] = NIL;
XcanvasKEY2862:
	if (n & (1<<5)) goto XcanvasKEY2863;
	local[6] = loadglobal(fqv[43]);
XcanvasKEY2863:
	local[7]= (pointer)get_sym_func(fqv[0]);
	local[8]= argv[0];
	local[9]= *(ovafptr(argv[1],fqv[1]));
	local[10]= fqv[2];
	local[11]= fqv[40];
	local[12]= local[3];
	local[13]= local[0];
	ctx->vsp=local+14;
	w=(pointer)APPLY(ctx,7,local+7); /*apply*/
	local[7]= argv[0];
	local[8]= fqv[44];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[45];
	local[9]= local[1];
	local[10]= local[2];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[46];
	local[9]= local[4];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	if (local[5]==NIL) goto XcanvasCON2865;
	local[7]= argv[0];
	local[8]= fqv[47];
	local[9]= local[5];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	goto XcanvasCON2864;
XcanvasCON2865:
	if (local[6]==NIL) goto XcanvasCON2866;
	local[7]= local[4];
	local[8]= fqv[48];
	local[9]= local[6];
	local[10]= loadglobal(fqv[49]);
	ctx->vsp=local+11;
	w=(pointer)DERIVEDP(ctx,2,local+9); /*derivedp*/
	if (w==NIL) goto XcanvasIF2867;
	local[9]= local[6];
	goto XcanvasIF2868;
XcanvasIF2867:
	local[9]= local[6];
	ctx->vsp=local+10;
	w=(*ftab[6])(ctx,1,local+9,&ftab[6],fqv[50]); /*make-color-gc*/
	local[9]= w;
XcanvasIF2868:
	ctx->vsp=local+10;
	w=(*ftab[7])(ctx,3,local+7,&ftab[7],fqv[51]); /*make-array*/
	argv[0]->c.obj.iv[23] = w;
	local[7]= argv[0]->c.obj.iv[23];
	goto XcanvasCON2864;
XcanvasCON2866:
	local[7]= NIL;
XcanvasCON2864:
	argv[0]->c.obj.iv[24] = makeint((eusinteger_t)0L);
	local[7]= argv[0];
	local[8]= fqv[36];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	w = argv[0];
	local[0]= w;
XcanvasBLK2856:
	ctx->vsp=local; return(local[0]);}

/*:new-pixmap*/
static pointer XcanvasM2869graph_canvas_new_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XcanvasENT2873;}
	local[0]= argv[0]->c.obj.iv[5];
XcanvasENT2873:
	if (n>=4) { local[1]=(argv[3]); goto XcanvasENT2872;}
	local[1]= argv[0]->c.obj.iv[6];
XcanvasENT2872:
XcanvasENT2871:
	if (n>4) maerror();
	local[2]= loadglobal(fqv[52]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[2];
	local[5]= fqv[53];
	local[6]= local[0];
	local[7]= fqv[54];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	argv[0]->c.obj.iv[16] = w;
	w = argv[0];
	local[0]= w;
XcanvasBLK2870:
	ctx->vsp=local; return(local[0]);}

/*:range*/
static pointer XcanvasM2874graph_canvas_range(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	if (n>=4) { local[0]=(argv[3]); goto XcanvasENT2877;}
	local[0]= makeflt(0.0000000000000000000000e+00);
XcanvasENT2877:
XcanvasENT2876:
	if (n>4) maerror();
	argv[0]->c.obj.iv[17] = argv[2];
	argv[0]->c.obj.iv[18] = local[0];
	w = argv[0];
	local[0]= w;
XcanvasBLK2875:
	ctx->vsp=local; return(local[0]);}

/*:lines*/
static pointer XcanvasM2878graph_canvas_lines(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= fqv[48];
	local[2]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+3;
	w=(*ftab[7])(ctx,3,local+0,&ftab[7],fqv[51]); /*make-array*/
	argv[0]->c.obj.iv[19] = w;
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
XcanvasBLK2879:
	ctx->vsp=local; return(local[0]);}

/*:colors*/
static pointer XcanvasM2880graph_canvas_colors(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+1;
	w=(pointer)LENGTH(ctx,1,local+0); /*length*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(*ftab[7])(ctx,1,local+0,&ftab[7],fqv[51]); /*make-array*/
	argv[0]->c.obj.iv[23] = w;
	local[0]= NIL;
	local[1]= makeint((eusinteger_t)0L);
	local[2]= argv[0]->c.obj.iv[19];
	ctx->vsp=local+3;
	w=(pointer)LENGTH(ctx,1,local+2); /*length*/
	local[2]= w;
XcanvasWHL2882:
	local[3]= local[1];
	w = local[2];
	if ((eusinteger_t)local[3] >= (eusinteger_t)w) goto XcanvasWHX2883;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[2] = (w)->c.cons.cdr;
	w = local[3];
	local[0] = w;
	local[3]= argv[0]->c.obj.iv[23];
	local[4]= local[1];
	local[5]= local[0];
	local[6]= loadglobal(fqv[49]);
	ctx->vsp=local+7;
	w=(pointer)DERIVEDP(ctx,2,local+5); /*derivedp*/
	if (w==NIL) goto XcanvasIF2885;
	local[5]= local[0];
	goto XcanvasIF2886;
XcanvasIF2885:
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(*ftab[6])(ctx,1,local+5,&ftab[6],fqv[50]); /*make-color-gc*/
	local[5]= w;
XcanvasIF2886:
	ctx->vsp=local+6;
	w=(pointer)ASET(ctx,3,local+3); /*aset*/
	local[3]= local[1];
	ctx->vsp=local+4;
	w=(pointer)ADD1(ctx,1,local+3); /*1+*/
	local[1] = w;
	goto XcanvasWHL2882;
XcanvasWHX2883:
	local[3]= NIL;
XcanvasBLK2884:
	w = NIL;
	local[0]= w;
XcanvasBLK2881:
	ctx->vsp=local; return(local[0]);}

/*:graph*/
static pointer XcanvasM2887graph_canvas_graph(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XcanvasRST2889:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	argv[0]->c.obj.iv[20] = local[0];
	local[1]= (pointer)get_sym_func(fqv[0]);
	local[2]= argv[0];
	local[3]= *(ovafptr(argv[1],fqv[1]));
	local[4]= fqv[55];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)APPLY(ctx,5,local+1); /*apply*/
	local[1]= argv[0]->c.obj.iv[16];
	local[2]= fqv[56];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = argv[0];
	local[0]= w;
XcanvasBLK2888:
	ctx->vsp=local; return(local[0]);}

/*:incremental-graph*/
static pointer XcanvasM2890graph_canvas_incremental_graph(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= loadglobal(fqv[57]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= argv[0]->c.obj.iv[3]->c.obj.iv[2];
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)0L);
	local[6]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+7;
	w=(pointer)SUB1(ctx,1,local+6); /*1-*/
	local[6]= w;
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	ctx->vsp=local+10;
	w=(*ftab[8])(ctx,10,local+0,&ftab[8],fqv[58]); /*copyarea*/
	local[0]= loadglobal(fqv[57]);
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= argv[0]->c.obj.iv[5];
	ctx->vsp=local+3;
	w=(pointer)SUB1(ctx,1,local+2); /*1-*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= argv[0]->c.obj.iv[6];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(*ftab[9])(ctx,7,local+0,&ftab[9],fqv[59]); /*cleararea*/
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= makeint((eusinteger_t)0L);
	local[5]= argv[2];
	ctx->vsp=local+6;
	w=(pointer)LENGTH(ctx,1,local+5); /*length*/
	local[5]= w;
XcanvasWHL2892:
	local[6]= local[4];
	w = local[5];
	if ((eusinteger_t)local[6] >= (eusinteger_t)w) goto XcanvasWHX2893;
	local[6]= argv[0]->c.obj.iv[19];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[2] = w;
	local[6]= argv[2];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[0] = w;
	local[6]= argv[0]->c.obj.iv[6];
	local[7]= argv[0]->c.obj.iv[6];
	local[8]= local[0];
	ctx->vsp=local+9;
	w=(pointer)EUSFLOAT(ctx,1,local+8); /*float*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[17];
	local[10]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)ROUND(ctx,1,local+7); /*round*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)MINUS(ctx,2,local+6); /*-*/
	local[1] = w;
	local[6]= argv[0]->c.obj.iv[23];
	local[7]= local[4];
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,2,local+6); /*aref*/
	local[3] = w;
	local[6]= argv[0];
	local[7]= fqv[60];
	local[8]= argv[0]->c.obj.iv[5];
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= local[2];
	local[10]= argv[0]->c.obj.iv[5];
	local[11]= local[1];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,7,local+6); /*send*/
	local[6]= argv[0]->c.obj.iv[19];
	local[7]= local[4];
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)ASET(ctx,3,local+6); /*aset*/
	local[6]= local[4];
	ctx->vsp=local+7;
	w=(pointer)ADD1(ctx,1,local+6); /*1+*/
	local[4] = w;
	goto XcanvasWHL2892;
XcanvasWHX2893:
	local[6]= NIL;
XcanvasBLK2894:
	w = NIL;
	local[4]= argv[0]->c.obj.iv[24];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	argv[0]->c.obj.iv[24] = w;
	local[4]= argv[0]->c.obj.iv[24];
	local[5]= makeint((eusinteger_t)10L);
	ctx->vsp=local+6;
	w=(pointer)MOD(ctx,2,local+4); /*mod*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[10])(ctx,1,local+4,&ftab[10],fqv[61]); /*zerop*/
	if (w==NIL) goto XcanvasIF2895;
	local[4]= argv[0]->c.obj.iv[16];
	local[5]= fqv[56];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	goto XcanvasIF2896;
XcanvasIF2895:
	local[4]= NIL;
XcanvasIF2896:
	w = local[4];
	local[0]= w;
XcanvasBLK2891:
	ctx->vsp=local; return(local[0]);}

/*:clear*/
static pointer XcanvasM2897graph_canvas_clear(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	argv[0]->c.obj.iv[20] = NIL;
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[1]));
	local[2]= fqv[36];
	ctx->vsp=local+3;
	w=(pointer)SENDMESSAGE(ctx,3,local+0); /*send-message*/
	local[0]= argv[0]->c.obj.iv[16];
	local[1]= fqv[56];
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
XcanvasBLK2898:
	ctx->vsp=local; return(local[0]);}

/*:resize*/
static pointer XcanvasM2899graph_canvas_resize(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= fqv[44];
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0];
	local[1]= *(ovafptr(argv[1],fqv[1]));
	local[2]= fqv[62];
	local[3]= argv[2];
	local[4]= argv[3];
	ctx->vsp=local+5;
	w=(pointer)SENDMESSAGE(ctx,5,local+0); /*send-message*/
	local[0]= argv[0];
	local[1]= fqv[63];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
XcanvasBLK2900:
	ctx->vsp=local; return(local[0]);}

/*:redraw*/
static pointer XcanvasM2901graph_canvas_redraw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[20]==NIL) goto XcanvasIF2903;
	local[0]= (pointer)get_sym_func(fqv[64]);
	local[1]= argv[0];
	local[2]= fqv[55];
	local[3]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,4,local+0); /*apply*/
	local[0]= w;
	goto XcanvasIF2904;
XcanvasIF2903:
	local[0]= NIL;
XcanvasIF2904:
	w = local[0];
	local[0]= w;
XcanvasBLK2902:
	ctx->vsp=local; return(local[0]);}

/*:create*/
static pointer XcanvasM2905pixmap_scroller_create(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
XcanvasRST2907:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[65], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto XcanvasKEY2908;
	local[1] = NIL;
XcanvasKEY2908:
	local[2]= (pointer)get_sym_func(fqv[0]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[1]));
	local[5]= fqv[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,5,local+2); /*apply*/
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= argv[0]->c.obj.iv[6];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)PRINT(ctx,1,local+2); /*print*/
	local[2]= loadglobal(fqv[66]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[2];
	local[5]= fqv[67];
	local[6]= argv[0];
	local[7]= fqv[53];
	local[8]= argv[0]->c.obj.iv[5];
	local[9]= makeint((eusinteger_t)15L);
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,2,local+8); /*-*/
	local[8]= w;
	local[9]= fqv[54];
	local[10]= argv[0]->c.obj.iv[6];
	local[11]= makeint((eusinteger_t)15L);
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,8,local+3); /*send*/
	w = local[2];
	argv[0]->c.obj.iv[25] = w;
	local[2]= loadglobal(fqv[68]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[2];
	local[5]= fqv[67];
	local[6]= argv[0];
	local[7]= fqv[53];
	local[8]= makeint((eusinteger_t)10L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	argv[0]->c.obj.iv[26] = w;
	local[2]= loadglobal(fqv[69]);
	ctx->vsp=local+3;
	w=(pointer)INSTANTIATE(ctx,1,local+2); /*instantiate*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[2];
	local[5]= fqv[67];
	local[6]= argv[0];
	local[7]= fqv[54];
	local[8]= makeint((eusinteger_t)10L);
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,6,local+3); /*send*/
	w = local[2];
	argv[0]->c.obj.iv[27] = w;
	local[2]= argv[0];
	local[3]= fqv[70];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	if (local[1]==NIL) goto XcanvasIF2909;
	local[2]= argv[0];
	local[3]= fqv[71];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto XcanvasIF2910;
XcanvasIF2909:
	local[2]= NIL;
XcanvasIF2910:
	w = argv[0];
	local[0]= w;
XcanvasBLK2906:
	ctx->vsp=local; return(local[0]);}

/*:reset-subwindows*/
static pointer XcanvasM2911pixmap_scroller_reset_subwindows(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[62];
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= makeint((eusinteger_t)15L);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= makeint((eusinteger_t)15L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[26];
	local[1]= fqv[72];
	local[2]= argv[0]->c.obj.iv[5];
	local[3]= makeint((eusinteger_t)13L);
	ctx->vsp=local+4;
	w=(pointer)MINUS(ctx,2,local+2); /*-*/
	local[2]= w;
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= argv[0]->c.obj.iv[27];
	local[1]= fqv[72];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= argv[0]->c.obj.iv[6];
	local[4]= makeint((eusinteger_t)13L);
	ctx->vsp=local+5;
	w=(pointer)MINUS(ctx,2,local+3); /*-*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	w = argv[0];
	local[0]= w;
XcanvasBLK2912:
	ctx->vsp=local; return(local[0]);}

/*:set-pixmap*/
static pointer XcanvasM2913pixmap_scroller_set_pixmap(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	argv[0]->c.obj.iv[28] = argv[2];
	argv[0]->c.obj.iv[29] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[30] = makeint((eusinteger_t)0L);
	local[0]= argv[2];
	local[1]= fqv[53];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[31] = w;
	local[0]= argv[2];
	local[1]= fqv[54];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	argv[0]->c.obj.iv[32] = w;
	local[0]= argv[0]->c.obj.iv[25];
	local[1]= fqv[56];
	local[2]= argv[0]->c.obj.iv[28];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	w = argv[0]->c.obj.iv[28];
	local[0]= w;
XcanvasBLK2914:
	ctx->vsp=local; return(local[0]);}

/*:scroll*/
static pointer XcanvasM2915pixmap_scroller_scroll(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto XcanvasENT2918;}
	local[0]= makeint((eusinteger_t)1L);
XcanvasENT2918:
XcanvasENT2917:
	if (n>3) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)NUMEQUAL(ctx,2,local+5); /*=*/
	if (w==NIL) goto XcanvasCON2920;
	w = NIL;
	ctx->vsp=local+5;
	local[0]=w;
	goto XcanvasBLK2916;
	goto XcanvasCON2919;
XcanvasCON2920:
	local[5]= local[0];
	local[6]= makeint((eusinteger_t)0L);
	ctx->vsp=local+7;
	w=(pointer)GREATERP(ctx,2,local+5); /*>*/
	if (w==NIL) goto XcanvasCON2921;
	local[2] = local[0];
	local[3] = makeint((eusinteger_t)0L);
	local[5]= argv[0];
	local[6]= fqv[54];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)16L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)MINUS(ctx,2,local+5); /*-*/
	local[4] = w;
	local[5]= local[4];
	goto XcanvasCON2919;
XcanvasCON2921:
	local[2] = makeint((eusinteger_t)0L);
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)ABS(ctx,1,local+5); /*abs*/
	local[3] = w;
	local[4] = makeint((eusinteger_t)0L);
	local[5]= local[4];
	goto XcanvasCON2919;
XcanvasCON2922:
	local[5]= NIL;
XcanvasCON2919:
	local[5]= argv[0];
	local[6]= fqv[54];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= makeint((eusinteger_t)16L);
	ctx->vsp=local+7;
	w=(pointer)QUOTIENT(ctx,2,local+5); /*/*/
	local[5]= w;
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)ABS(ctx,1,local+6); /*abs*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)MIN(ctx,2,local+5); /*min*/
	local[0] = w;
	local[5]= T;
	local[6]= fqv[73];
	local[7]= local[0];
	local[8]= local[2];
	local[9]= local[3];
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)XFORMAT(ctx,6,local+5); /*format*/
	local[5]= argv[0]->c.obj.iv[25];
	local[6]= fqv[56];
	local[7]= argv[0]->c.obj.iv[25];
	local[8]= fqv[74];
	local[9]= makeint((eusinteger_t)2L);
	local[10]= fqv[75];
	local[11]= makeint((eusinteger_t)2L);
	local[12]= local[2];
	local[13]= makeint((eusinteger_t)12L);
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)PLUS(ctx,2,local+11); /*+*/
	local[11]= w;
	local[12]= fqv[53];
	local[13]= argv[0]->c.obj.iv[5];
	local[14]= fqv[54];
	local[15]= argv[0];
	local[16]= fqv[54];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,2,local+15); /*send*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)16L);
	ctx->vsp=local+17;
	w=(pointer)QUOTIENT(ctx,2,local+15); /*/*/
	local[15]= w;
	local[16]= local[0];
	ctx->vsp=local+17;
	w=(pointer)MINUS(ctx,2,local+15); /*-*/
	local[15]= w;
	local[16]= makeint((eusinteger_t)12L);
	ctx->vsp=local+17;
	w=(pointer)TIMES(ctx,2,local+15); /***/
	local[15]= w;
	local[16]= fqv[76];
	local[17]= makeint((eusinteger_t)2L);
	local[18]= fqv[77];
	local[19]= makeint((eusinteger_t)2L);
	local[20]= local[3];
	local[21]= makeint((eusinteger_t)12L);
	ctx->vsp=local+22;
	w=(pointer)TIMES(ctx,2,local+20); /***/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)PLUS(ctx,2,local+19); /*+*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,15,local+5); /*send*/
	local[5]= argv[0]->c.obj.iv[25];
	local[6]= fqv[78];
	local[7]= fqv[76];
	local[8]= makeint((eusinteger_t)2L);
	local[9]= fqv[77];
	local[10]= makeint((eusinteger_t)2L);
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)12L);
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,2,local+11); /***/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)PLUS(ctx,2,local+10); /*+*/
	local[10]= w;
	local[11]= fqv[53];
	local[12]= argv[0]->c.obj.iv[5];
	local[13]= fqv[54];
	local[14]= local[0];
	local[15]= makeint((eusinteger_t)12L);
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,10,local+5); /*send*/
	local[0]= w;
XcanvasBLK2916:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___Xcanvas(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[79];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto XcanvasIF2923;
	local[0]= fqv[80];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[81],w);
	goto XcanvasIF2924;
XcanvasIF2923:
	local[0]= fqv[82];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
XcanvasIF2924:
	local[0]= fqv[83];
	local[1]= fqv[84];
	ctx->vsp=local+2;
	w=(*ftab[11])(ctx,2,local+0,&ftab[11],fqv[85]); /*require*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2819canvas_create,fqv[2],fqv[86],fqv[87]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2822canvas_selection,fqv[88],fqv[86],fqv[89]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2824canvas_adjust_corners,fqv[90],fqv[86],fqv[91]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2826canvas_draw_selection_rectangle,fqv[26],fqv[86],fqv[92]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2828canvas_buttonpress,fqv[93],fqv[86],fqv[94]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2833canvas_motionnotify,fqv[34],fqv[86],fqv[95]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2840canvas_buttonrelease,fqv[39],fqv[86],fqv[96]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2849canvas_clear_event,fqv[13],fqv[86],fqv[97]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2851canvas_color_event,fqv[7],fqv[86],fqv[98]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2853canvas_background_event,fqv[15],fqv[86],fqv[99]);
	local[0]= fqv[100];
	local[1]= fqv[101];
	local[2]= fqv[100];
	local[3]= fqv[102];
	local[4]= loadglobal(fqv[86]);
	local[5]= fqv[103];
	local[6]= fqv[104];
	local[7]= fqv[105];
	local[8]= NIL;
	local[9]= fqv[106];
	local[10]= NIL;
	local[11]= fqv[107];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[108];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[12])(ctx,13,local+2,&ftab[12],fqv[109]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2855graph_canvas_create,fqv[2],fqv[100],fqv[110]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2869graph_canvas_new_pixmap,fqv[44],fqv[100],fqv[111]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2874graph_canvas_range,fqv[45],fqv[100],fqv[112]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2878graph_canvas_lines,fqv[46],fqv[100],fqv[113]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2880graph_canvas_colors,fqv[47],fqv[100],fqv[114]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2887graph_canvas_graph,fqv[55],fqv[100],fqv[115]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2890graph_canvas_incremental_graph,fqv[116],fqv[100],fqv[117]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2897graph_canvas_clear,fqv[36],fqv[100],fqv[118]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2899graph_canvas_resize,fqv[62],fqv[100],fqv[119]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2901graph_canvas_redraw,fqv[120],fqv[100],fqv[121]);
	local[0]= fqv[122];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	local[0]= fqv[123];
	local[1]= fqv[101];
	local[2]= fqv[123];
	local[3]= fqv[102];
	local[4]= loadglobal(fqv[124]);
	local[5]= fqv[103];
	local[6]= fqv[125];
	local[7]= fqv[105];
	local[8]= NIL;
	local[9]= fqv[106];
	local[10]= NIL;
	local[11]= fqv[107];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[108];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[12])(ctx,13,local+2,&ftab[12],fqv[109]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2905pixmap_scroller_create,fqv[2],fqv[123],fqv[126]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2911pixmap_scroller_reset_subwindows,fqv[70],fqv[123],fqv[127]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2913pixmap_scroller_set_pixmap,fqv[71],fqv[123],fqv[128]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,XcanvasM2915pixmap_scroller_scroll,fqv[129],fqv[123],fqv[130]);
	local[0]= fqv[131];
	local[1]= fqv[132];
	ctx->vsp=local+2;
	w=(*ftab[13])(ctx,2,local+0,&ftab[13],fqv[133]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<14; i++) ftab[i]=fcallx;
}
