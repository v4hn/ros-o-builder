char *makedate="Sat Sep 5 06:56:26 UTC 2026";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";
