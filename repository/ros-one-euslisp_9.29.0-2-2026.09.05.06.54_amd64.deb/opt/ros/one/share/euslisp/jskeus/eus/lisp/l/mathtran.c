/* ./mathtran.c :  entry=mathtran */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Sep 5 06:56:26 UTC 2026) */
#include "eus.h"
#include "mathtran.h"
#pragma init (register_mathtran)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___mathtran();
extern pointer build_quote_vector();
static int register_mathtran()
  { add_module_initializer("___mathtran", ___mathtran);}

static pointer mathtranF3762expression();
static pointer mathtranF3763infix2prefix();
static pointer mathtranF3764read_aref();

/*expression*/
static pointer mathtranF3762expression(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto mathtranENT3767;}
	local[0]= NIL;
mathtranENT3767:
mathtranENT3766:
	if (n>2) maerror();
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	ctx->vsp=local+4;
	local[4]= makeclosure(codevec,quotevec,mathtranFLET3768,env,argv,local);
	ctx->vsp=local+5;
	local[5]= makeclosure(codevec,quotevec,mathtranFLET3769,env,argv,local);
	ctx->vsp=local+6;
	local[6]= makeclosure(codevec,quotevec,mathtranFLET3770,env,argv,local);
	ctx->vsp=local+7;
	local[7]= makeclosure(codevec,quotevec,mathtranFLET3771,env,argv,local);
	ctx->vsp=local+8;
	local[8]= makeclosure(codevec,quotevec,mathtranFLET3772,env,argv,local);
	ctx->vsp=local+9;
	local[9]= makeclosure(codevec,quotevec,mathtranFLET3773,env,argv,local);
	ctx->vsp=local+10;
	local[10]= makeclosure(codevec,quotevec,mathtranFLET3774,env,argv,local);
	ctx->vsp=local+11;
	local[11]= makeclosure(codevec,quotevec,mathtranFLET3775,env,argv,local);
	local[12]= argv[0];
	w = local[10];
	ctx->vsp=local+13;
	w=mathtranFLET3774(ctx,1,local+12,w);
	local[12]= w;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[12];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w = local[2];
	if (argv[0]==NIL) goto mathtranIF3776;
	local[12]= fqv[0];
	ctx->vsp=local+13;
	w=(pointer)SIGERROR(ctx,1,local+12); /*error*/
	local[12]= w;
	goto mathtranIF3777;
mathtranIF3776:
	local[12]= NIL;
mathtranIF3777:
	local[12]= local[2];
	w = local[11];
	ctx->vsp=local+13;
	w=mathtranFLET3775(ctx,1,local+12,w);
	local[0]= w;
mathtranBLK3765:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3768(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	local[1]= env->c.clo.env2[3];
	local[2]= fqv[1];
	local[3]= (pointer)get_sym_func(fqv[2]);
	ctx->vsp=local+4;
	w=(*ftab[0])(ctx,4,local+0,&ftab[0],fqv[3]); /*assoc*/
	local[0]= w;
	if (local[0]==NIL) goto mathtranCON3779;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.cdr;
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	ctx->vsp=local+3;
	w=(pointer)ADD1(ctx,1,local+2); /*1+*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)RPLACA2(ctx,2,local+1); /*rplaca2*/
	w=local[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
	goto mathtranCON3778;
mathtranCON3779:
	ctx->vsp=local+1;
	w=(pointer)GENSYM(ctx,0,local+1); /*gensym*/
	local[0] = w;
	local[1]= argv[0];
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,3,local+1); /*list*/
	local[1]= w;
	w = env->c.clo.env2[3];
	ctx->vsp=local+2;
	env->c.clo.env2[3] = cons(ctx,local[1],w);
	local[1]= local[0];
	goto mathtranCON3778;
mathtranCON3780:
	local[1]= NIL;
mathtranCON3778:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3769(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[0];
	local[0]= w;
	local[1]= NIL;
	local[2]= NIL;
	w = local[0];
	if (!iscons(w)) goto mathtranCON3782;
	local[3]= local[0];
	w = env->c.clo.env2[8];
	ctx->vsp=local+4;
	w=mathtranFLET3772(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	if (local[2]==NIL) goto mathtranIF3783;
	local[3]= fqv[4];
	ctx->vsp=local+4;
	w=(pointer)SIGERROR(ctx,1,local+3); /*error*/
	local[3]= w;
	goto mathtranIF3784;
mathtranIF3783:
	local[3]= NIL;
mathtranIF3784:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3781;
mathtranCON3782:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.car;
	if (!iscons(w)) goto mathtranCON3785;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (fqv[6]!=local[3]) goto mathtranCON3787;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w = env->c.clo.env2[9];
	ctx->vsp=local+4;
	w=mathtranFLET3773(ctx,1,local+3,w);
	local[1] = w;
	local[3]= fqv[6];
	local[4]= local[0];
	w = local[1];
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[2] = cons(ctx,local[3],w);
	if (env->c.clo.env2[0]!=NIL) goto mathtranIF3788;
	local[3]= local[2];
	w = env->c.clo.env2[4];
	ctx->vsp=local+4;
	w=mathtranFLET3768(ctx,1,local+3,w);
	local[2] = w;
	local[3]= local[2];
	goto mathtranIF3789;
mathtranIF3788:
	local[3]= NIL;
mathtranIF3789:
	local[3]= local[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3786;
mathtranCON3787:
	local[3]= local[0];
	local[4]= local[1];
	w = env->c.clo.env2[9];
	ctx->vsp=local+5;
	w=mathtranFLET3773(ctx,1,local+4,w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	w = env->c.clo.env2[4];
	ctx->vsp=local+4;
	w=mathtranFLET3768(ctx,1,local+3,w);
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3786;
mathtranCON3790:
	local[3]= NIL;
mathtranCON3786:
	goto mathtranCON3781;
mathtranCON3785:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3781;
mathtranCON3791:
	local[3]= NIL;
mathtranCON3781:
	w = local[3];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3770(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	w = env->c.clo.env2[5];
	ctx->vsp=local+4;
	w=mathtranFLET3769(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (fqv[7]!=local[3]) goto mathtranCON3793;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w = env->c.clo.env2[5];
	ctx->vsp=local+4;
	w=mathtranFLET3769(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	w = local[1];
	w = local[1];
	if (!isint(w)) goto mathtranCON3795;
	local[3]= local[1];
	local[4]= makeint((eusinteger_t)10L);
	ctx->vsp=local+5;
	w=(pointer)LESSP(ctx,2,local+3); /*<*/
	if (w==NIL) goto mathtranCON3795;
	local[3]= fqv[8];
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,1,local+3); /*list*/
	local[2] = w;
	w = local[0];
	if (!!iscons(w)) goto mathtranCON3797;
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[1];
mathtranWHL3798:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto mathtranWHX3799;
	local[5]= local[2];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto mathtranWHL3798;
mathtranWHX3799:
	local[5]= NIL;
mathtranBLK3800:
	w = NIL;
	local[3]= local[2];
	w = env->c.clo.env2[4];
	ctx->vsp=local+4;
	w=mathtranFLET3768(ctx,1,local+3,w);
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3796;
mathtranCON3797:
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[1];
mathtranWHL3802:
	local[5]= local[3];
	w = local[4];
	if ((eusinteger_t)local[5] >= (eusinteger_t)w) goto mathtranWHX3803;
	local[5]= local[2];
	local[6]= fqv[9];
	ctx->vsp=local+7;
	w=(pointer)LIST(ctx,1,local+6); /*list*/
	local[6]= w;
	ctx->vsp=local+7;
	w=(pointer)NCONC(ctx,2,local+5); /*nconc*/
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)ADD1(ctx,1,local+5); /*1+*/
	local[3] = w;
	goto mathtranWHL3802;
mathtranWHX3803:
	local[5]= NIL;
mathtranBLK3804:
	w = NIL;
	local[3]= fqv[10];
	local[4]= fqv[9];
	local[5]= local[0];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,1,local+5); /*list*/
	ctx->vsp=local+5;
	w = cons(ctx,local[4],w);
	ctx->vsp=local+4;
	local[3]= cons(ctx,local[3],w);
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3796;
mathtranCON3801:
	local[3]= NIL;
mathtranCON3796:
	goto mathtranCON3794;
mathtranCON3795:
	local[3]= fqv[11];
	local[4]= local[0];
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3794;
mathtranCON3805:
	local[3]= NIL;
mathtranCON3794:
	goto mathtranCON3792;
mathtranCON3793:
	w = local[0];
	if (!numberp(w)) goto mathtranCON3806;
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3792;
mathtranCON3806:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3792;
mathtranCON3807:
	local[3]= NIL;
mathtranCON3792:
	w = local[3];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3771(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	w = env->c.clo.env2[6];
	ctx->vsp=local+4;
	w=mathtranFLET3770(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	local[3]= local[1];
	w = fqv[12];
	if (memq(local[3],w)==NIL) goto mathtranCON3809;
mathtranWHL3810:
	local[3]= local[1];
	w = fqv[13];
	if (memq(local[3],w)==NIL) goto mathtranWHX3811;
	local[3]= local[1];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[0] = w;
mathtranWHL3813:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	if (local[1]!=local[3]) goto mathtranWHX3814;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w = env->c.clo.env2[6];
	ctx->vsp=local+4;
	w=mathtranFLET3770(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w = local[2];
	local[3]= local[0];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	goto mathtranWHL3813;
mathtranWHX3814:
	local[3]= NIL;
mathtranBLK3815:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	goto mathtranWHL3810;
mathtranWHX3811:
	local[3]= NIL;
mathtranBLK3812:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3808;
mathtranCON3809:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[3]= w;
	goto mathtranCON3808;
mathtranCON3816:
	local[3]= NIL;
mathtranCON3808:
	w = local[3];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3772(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0]= (w)->c.cons.car;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= local[0];
	w = fqv[14];
	if (memq(local[3],w)==NIL) goto mathtranIF3817;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	local[3]= argv[0];
	goto mathtranIF3818;
mathtranIF3817:
	local[3]= NIL;
mathtranIF3818:
	local[3]= argv[0];
	w = env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=mathtranFLET3771(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1] = (w)->c.cons.car;
	w = local[1];
	local[3]= local[0];
	if (fqv[15]!=local[3]) goto mathtranIF3819;
	local[3]= local[0];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[1] = w;
	local[3]= local[1];
	goto mathtranIF3820;
mathtranIF3819:
	local[3]= NIL;
mathtranIF3820:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w = fqv[16];
	if (memq(local[3],w)==NIL) goto mathtranIF3821;
	local[3]= fqv[17];
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[1] = w;
mathtranWHL3823:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	local[3]= local[0];
	w = fqv[18];
	if (memq(local[3],w)==NIL) goto mathtranWHX3824;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.cdr;
	w = env->c.clo.env2[7];
	ctx->vsp=local+4;
	w=mathtranFLET3771(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w = local[2];
	local[3]= local[0];
	if (fqv[15]!=local[3]) goto mathtranIF3826;
	local[3]= fqv[15];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[2] = w;
	local[3]= local[2];
	goto mathtranIF3827;
mathtranIF3826:
	local[3]= NIL;
mathtranIF3827:
	local[3]= local[1];
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,1,local+4); /*list*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)NCONC(ctx,2,local+3); /*nconc*/
	goto mathtranWHL3823;
mathtranWHX3824:
	local[3]= NIL;
mathtranBLK3825:
	goto mathtranIF3822;
mathtranIF3821:
	local[3]= NIL;
mathtranIF3822:
	local[3]= local[1];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3773(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
mathtranWHL3828:
	if (argv[0]==NIL) goto mathtranWHX3829;
	local[2]= argv[0];
	w = env->c.clo.env2[8];
	ctx->vsp=local+3;
	w=mathtranFLET3772(ctx,1,local+2,w);
	local[2]= w;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	local[2]= local[0];
	w = local[1];
	ctx->vsp=local+3;
	local[1] = cons(ctx,local[2],w);
	goto mathtranWHL3828;
mathtranWHX3829:
	local[2]= NIL;
mathtranBLK3830:
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3774(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= argv[0];
	w = env->c.clo.env2[8];
	ctx->vsp=local+4;
	w=mathtranFLET3772(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[0] = (w)->c.cons.car;
	w = local[0];
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	w = fqv[19];
	if (memq(local[3],w)==NIL) goto mathtranIF3831;
	local[3]= argv[0];
	w = env->c.clo.env2[8];
	ctx->vsp=local+4;
	w=mathtranFLET3772(ctx,1,local+3,w);
	local[3]= w;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.car;
	w = local[2];
	local[3]= local[1];
	local[4]= fqv[20];
	ctx->vsp=local+5;
	w=(*ftab[0])(ctx,2,local+3,&ftab[0],fqv[3]); /*assoc*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)LIST(ctx,3,local+3); /*list*/
	local[0] = w;
	local[3]= local[0];
	goto mathtranIF3832;
mathtranIF3831:
	local[3]= NIL;
mathtranIF3832:
	local[3]= local[0];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(*ftab[1])(ctx,2,local+3,&ftab[1],fqv[5]); /*values*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer mathtranFLET3775(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	argv[0] = w;
	local[0]= NIL;
	local[1]= NIL;
	local[2]= env->c.clo.env2[3];
mathtranWHL3833:
	if (local[2]==NIL) goto mathtranWHX3834;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	local[4]= makeint((eusinteger_t)1L);
	ctx->vsp=local+5;
	w=(pointer)GREATERP(ctx,2,local+3); /*>*/
	if (w==NIL) goto mathtranIF3836;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto mathtranIF3837;
mathtranIF3836:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)NSUBST(ctx,3,local+3); /*nsubst*/
	local[3]= w;
mathtranIF3837:
	goto mathtranWHL3833;
mathtranWHX3834:
	local[3]= NIL;
mathtranBLK3835:
	w = NIL;
	if (local[0]==NIL) goto mathtranIF3838;
	local[1]= fqv[21];
	local[2]= local[0];
	w = argv[0];
	ctx->vsp=local+3;
	w = cons(ctx,local[2],w);
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	goto mathtranIF3839;
mathtranIF3838:
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[1]= (w)->c.cons.car;
mathtranIF3839:
	w = local[1];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*infix2prefix*/
static pointer mathtranF3763infix2prefix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto mathtranENT3842;}
	local[0]= NIL;
mathtranENT3842:
mathtranENT3841:
	if (n>2) maerror();
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)READ(ctx,1,local+1); /*read*/
	local[1]= w;
	w = local[1];
	if (!issymbol(w)) goto mathtranCON3844;
	local[2]= local[1];
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(pointer)READ(ctx,1,local+3); /*read*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(pointer)LIST(ctx,2,local+2); /*list*/
	local[2]= w;
	local[3]= T;
	ctx->vsp=local+4;
	w=(pointer)mathtranF3762expression(ctx,2,local+2); /*expression*/
	local[2]= w;
	goto mathtranCON3843;
mathtranCON3844:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	if (fqv[22]!=local[2]) goto mathtranCON3845;
	local[2]= fqv[23];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.cdr;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)mathtranF3762expression(ctx,2,local+4); /*expression*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	goto mathtranCON3843;
mathtranCON3845:
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2]= (w)->c.cons.car;
	if (fqv[22]!=local[2]) goto mathtranCON3846;
	local[2]= fqv[24];
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[1];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,2,local+3); /*list*/
	local[3]= w;
	local[4]= T;
	ctx->vsp=local+5;
	w=(pointer)mathtranF3762expression(ctx,2,local+3); /*expression*/
	local[3]= w;
	local[4]= local[1];
	ctx->vsp=local+5;
	w=(*ftab[2])(ctx,1,local+4,&ftab[2],fqv[25]); /*cdddr*/
	local[4]= w;
	local[5]= NIL;
	ctx->vsp=local+6;
	w=(pointer)mathtranF3762expression(ctx,2,local+4); /*expression*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)LIST(ctx,3,local+2); /*list*/
	local[2]= w;
	goto mathtranCON3843;
mathtranCON3846:
	local[2]= local[1];
	local[3]= NIL;
	ctx->vsp=local+4;
	w=(pointer)mathtranF3762expression(ctx,2,local+2); /*expression*/
	local[2]= w;
	goto mathtranCON3843;
mathtranCON3847:
	local[2]= NIL;
mathtranCON3843:
	w = local[2];
	local[0]= w;
mathtranBLK3840:
	ctx->vsp=local; return(local[0]);}

/*read-aref*/
static pointer mathtranF3764read_aref(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<1) maerror();
	if (n>=2) { local[0]=(argv[1]); goto mathtranENT3850;}
	local[0]= NIL;
mathtranENT3850:
mathtranENT3849:
	if (n>2) maerror();
	local[1]= fqv[6];
	local[2]= makeint((eusinteger_t)93L);
	local[3]= argv[0];
	ctx->vsp=local+4;
	w=(*ftab[3])(ctx,2,local+2,&ftab[3],fqv[26]); /*read-delimited-list*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
mathtranBLK3848:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___mathtran(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[27];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto mathtranIF3851;
	local[0]= fqv[28];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[29],w);
	goto mathtranIF3852;
mathtranIF3851:
	local[0]= fqv[30];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
mathtranIF3852:
	ctx->vsp=local+0;
	compfun(ctx,fqv[31],module,mathtranF3762expression,fqv[32]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[33],module,mathtranF3763infix2prefix,fqv[34]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[35],module,mathtranF3764read_aref,fqv[36]);
	local[0]= makeint((eusinteger_t)37L);
	local[1]= fqv[33];
	ctx->vsp=local+2;
	w=(pointer)SETMACROCH(ctx,2,local+0); /*set-macro-character*/
	local[0]= makeint((eusinteger_t)91L);
	local[1]= fqv[35];
	ctx->vsp=local+2;
	w=(pointer)SETMACROCH(ctx,2,local+0); /*set-macro-character*/
	local[0]= makeint((eusinteger_t)93L);
	local[1]= makeint((eusinteger_t)41L);
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[37]); /*set-syntax-from-char*/
	local[0]= fqv[38];
	local[1]= fqv[39];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,2,local+0,&ftab[5],fqv[40]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<6; i++) ftab[i]=fcallx;
}
