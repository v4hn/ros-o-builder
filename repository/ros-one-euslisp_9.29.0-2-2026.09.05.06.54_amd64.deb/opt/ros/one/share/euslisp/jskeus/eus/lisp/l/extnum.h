#define QUOTE_STRINGS_SIZE 5
static char *quote_strings[QUOTE_STRINGS_SIZE]={
    ":init",
    "ratio",
    "\"(self class num denom)\"",
    "complex",
    "\"(self class re im)\"",
  };
