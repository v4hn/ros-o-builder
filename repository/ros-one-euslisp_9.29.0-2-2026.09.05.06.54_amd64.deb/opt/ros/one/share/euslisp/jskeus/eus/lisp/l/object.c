/* ./object.c :  entry=object */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Sat Sep 5 06:56:26 UTC 2026) */
#include "eus.h"
#include "object.h"
#pragma init (register_object)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___object();
extern pointer build_quote_vector();
static int register_object()
  { add_module_initializer("___object", ___object);}

static pointer objectF2688metaclass_name();
static pointer objectF2689metaclass_vars();

/*metaclass-name*/
static pointer objectF2688metaclass_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = *(ovafptr(argv[0],fqv[0]));
	local[0]= w;
objectBLK2690:
	ctx->vsp=local; return(local[0]);}

/*metaclass-vars*/
static pointer objectF2689metaclass_vars(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w = *(ovafptr(argv[0],fqv[1]));
	local[0]= w;
objectBLK2691:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer objectM2692object_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2695;}
	local[0]= T;
objectENT2695:
objectENT2694:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= local[0];
	local[3]= fqv[2];
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)GETCLASS(ctx,1,local+4); /*class*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)objectF2688metaclass_name(ctx,1,local+4); /*metaclass-name*/
	local[4]= w;
	local[5]= argv[0];
	ctx->vsp=local+6;
	w=(pointer)ADDRESS(ctx,1,local+5); /*system:address*/
	local[5]= w;
	ctx->vsp=local+6;
	w=(pointer)XFORMAT(ctx,4,local+2); /*format*/
	local[2]= NIL;
	local[3]= local[1];
objectWHL2696:
	if (local[3]==NIL) goto objectWHX2697;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[4]= (w)->c.cons.car;
	w=local[3];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3] = (w)->c.cons.cdr;
	w = local[4];
	local[2] = w;
	local[4]= local[0];
	local[5]= fqv[3];
	local[6]= local[2];
	ctx->vsp=local+7;
	w=(pointer)XFORMAT(ctx,3,local+4); /*format*/
	goto objectWHL2696;
objectWHX2697:
	local[4]= NIL;
objectBLK2698:
	w = NIL;
	local[2]= fqv[4];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)PRINC(ctx,2,local+2); /*princ*/
	w = argv[0];
	local[0]= w;
objectBLK2693:
	ctx->vsp=local; return(local[0]);}

/*:warning*/
static pointer objectM2699object_warning(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
objectRST2701:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	local[1]= (pointer)get_sym_func(fqv[5]);
	local[2]= argv[2];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)APPLY(ctx,3,local+1); /*apply*/
	local[0]= w;
objectBLK2700:
	ctx->vsp=local; return(local[0]);}

/*:error*/
static pointer objectM2702object_error(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
objectRST2704:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= (pointer)get_sym_func(fqv[6]);
	local[2]= argv[0];
	local[3]= fqv[7];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)APPLY(ctx,4,local+1); /*apply*/
	local[1]= fqv[8];
	ctx->vsp=local+2;
	w=(*ftab[0])(ctx,1,local+1,&ftab[0],fqv[9]); /*reploop*/
	local[0]= w;
objectBLK2703:
	ctx->vsp=local; return(local[0]);}

/*:slots*/
static pointer objectM2705object_slots(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	ctx->vsp=local+1;
	w=(pointer)objectF2689metaclass_vars(ctx,1,local+0); /*metaclass-vars*/
	local[0]= w;
	local[1]= NIL;
	local[2]= makeint((eusinteger_t)0L);
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)LENGTH(ctx,1,local+3); /*length*/
	local[3]= w;
objectWHL2707:
	local[4]= local[2];
	w = local[3];
	if ((eusinteger_t)local[4] >= (eusinteger_t)w) goto objectWHX2708;
	local[4]= local[0];
	local[5]= local[2];
	ctx->vsp=local+6;
	w=(pointer)ELT(ctx,2,local+4); /*elt*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= argv[0];
	ctx->vsp=local+7;
	w=(pointer)GETCLASS(ctx,1,local+6); /*class*/
	local[6]= w;
	local[7]= local[2];
	ctx->vsp=local+8;
	w=(pointer)SLOT(ctx,3,local+5); /*slot*/
	ctx->vsp=local+5;
	local[4]= cons(ctx,local[4],w);
	w = local[1];
	ctx->vsp=local+5;
	local[1] = cons(ctx,local[4],w);
	local[4]= local[2];
	ctx->vsp=local+5;
	w=(pointer)ADD1(ctx,1,local+4); /*1+*/
	local[2] = w;
	goto objectWHL2707;
objectWHX2708:
	local[4]= NIL;
objectBLK2709:
	w = NIL;
	local[2]= local[1];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
objectBLK2706:
	ctx->vsp=local; return(local[0]);}

/*:methods*/
static pointer objectM2710object_methods(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2713;}
	local[0]= fqv[10];
objectENT2713:
objectENT2712:
	if (n>3) maerror();
	local[1]= (pointer)get_sym_func(fqv[11]);
	local[2]= argv[0];
	ctx->vsp=local+3;
	w=(pointer)GETCLASS(ctx,1,local+2); /*class*/
	local[2]= w;
	local[3]= fqv[12];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[0]= w;
objectBLK2711:
	ctx->vsp=local; return(local[0]);}

/*:super*/
static pointer objectM2714object_super(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)GETCLASS(ctx,1,local+0); /*class*/
	local[0]= w;
	local[1]= fqv[13];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
objectBLK2715:
	ctx->vsp=local; return(local[0]);}

/*:get-val*/
static pointer objectM2716object_get_val(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)GETCLASS(ctx,1,local+1); /*class*/
	local[1]= w;
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SLOT(ctx,3,local+0); /*slot*/
	local[0]= w;
objectBLK2717:
	ctx->vsp=local; return(local[0]);}

/*:set-val*/
static pointer objectM2718object_set_val(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(pointer)GETCLASS(ctx,1,local+1); /*class*/
	local[1]= w;
	local[2]= argv[2];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SETSLOT(ctx,4,local+0); /*setslot*/
	local[0]= w;
objectBLK2719:
	ctx->vsp=local; return(local[0]);}

/*:plist*/
static pointer objectM2720propertied_object_plist(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2723;}
	local[0]= NIL;
objectENT2723:
objectENT2722:
	if (n>3) maerror();
	if (local[0]==NIL) goto objectIF2724;
	argv[0]->c.obj.iv[0] = local[0];
	local[1]= argv[0]->c.obj.iv[0];
	goto objectIF2725;
objectIF2724:
	local[1]= argv[0]->c.obj.iv[0];
objectIF2725:
	w = local[1];
	local[0]= w;
objectBLK2721:
	ctx->vsp=local; return(local[0]);}

/*:get*/
static pointer objectM2726propertied_object_get(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w = (w)->c.cons.cdr;
	local[0]= w;
objectBLK2727:
	ctx->vsp=local; return(local[0]);}

/*:put*/
static pointer objectM2728propertied_object_put(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	if (local[0]==NIL) goto objectIF2730;
	local[1]= local[0];
	local[2]= fqv[14];
	local[3]= argv[3];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
	goto objectIF2731;
objectIF2730:
	local[1]= argv[2];
	w = argv[3];
	ctx->vsp=local+2;
	local[1]= cons(ctx,local[1],w);
	w = argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	argv[0]->c.obj.iv[0] = cons(ctx,local[1],w);
	local[1]= argv[0]->c.obj.iv[0];
objectIF2731:
	w = argv[3];
	local[0]= w;
objectBLK2729:
	ctx->vsp=local; return(local[0]);}

/*:name*/
static pointer objectM2732propertied_object_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2735;}
	local[0]= NIL;
objectENT2735:
objectENT2734:
	if (n>3) maerror();
	if (local[0]==NIL) goto objectIF2736;
	local[1]= argv[0];
	local[2]= fqv[15];
	local[3]= fqv[16];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,4,local+1); /*send*/
	local[1]= w;
	goto objectIF2737;
objectIF2736:
	local[1]= argv[0];
	local[2]= fqv[17];
	local[3]= fqv[16];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	local[1]= w;
objectIF2737:
	w = local[1];
	local[0]= w;
objectBLK2733:
	ctx->vsp=local; return(local[0]);}

/*:remprop*/
static pointer objectM2738propertied_object_remprop(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+2;
	w=(pointer)ASSQ(ctx,2,local+0); /*assq*/
	local[0]= w;
	if (local[0]==NIL) goto objectIF2740;
	local[1]= local[0];
	local[2]= argv[0]->c.obj.iv[0];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[18]); /*delete*/
	argv[0]->c.obj.iv[0] = w;
	local[1]= argv[0]->c.obj.iv[0];
	goto objectIF2741;
objectIF2740:
	local[1]= NIL;
objectIF2741:
	w = local[1];
	local[0]= w;
objectBLK2739:
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer objectM2742propertied_object_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2745;}
	local[0]= T;
objectENT2745:
objectENT2744:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= NIL;
	local[3]= argv[0];
	local[4]= fqv[16];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	if (local[3]==NIL) goto objectIF2746;
	local[4]= (pointer)get_sym_func(fqv[19]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[20]));
	local[7]= fqv[21];
	local[8]= local[0];
	local[9]= local[3];
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,7,local+4); /*apply*/
	local[4]= w;
	goto objectIF2747;
objectIF2746:
	local[4]= (pointer)get_sym_func(fqv[19]);
	local[5]= argv[0];
	local[6]= *(ovafptr(argv[1],fqv[20]));
	local[7]= fqv[21];
	local[8]= local[0];
	local[9]= local[1];
	ctx->vsp=local+10;
	w=(pointer)APPLY(ctx,6,local+4); /*apply*/
	local[4]= w;
objectIF2747:
	w = local[4];
	local[0]= w;
objectBLK2743:
	ctx->vsp=local; return(local[0]);}

/*:new*/
static pointer objectM2748metaclass_new(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	ctx->vsp=local+1;
	w=(pointer)INSTANTIATE(ctx,1,local+0); /*instantiate*/
	local[0]= w;
objectBLK2749:
	ctx->vsp=local; return(local[0]);}

/*:super*/
static pointer objectM2750metaclass_super(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[2];
	local[0]= w;
objectBLK2751:
	ctx->vsp=local; return(local[0]);}

/*:methods*/
static pointer objectM2752metaclass_methods(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[7];
	local[0]= w;
objectBLK2753:
	ctx->vsp=local; return(local[0]);}

/*:method*/
static pointer objectM2754metaclass_method(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[2];
	local[1]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+2;
	w=(*ftab[2])(ctx,2,local+0,&ftab[2],fqv[22]); /*assoc*/
	local[0]= w;
objectBLK2755:
	ctx->vsp=local; return(local[0]);}

/*:method-names*/
static pointer objectM2756metaclass_method_names(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2759;}
	local[0]= fqv[23];
objectENT2759:
objectENT2758:
	if (n>3) maerror();
	local[1]= local[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,1,local+1,&ftab[3],fqv[24]); /*string*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,1,local+1,&ftab[4],fqv[25]); /*string-upcase*/
	local[0] = w;
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,objectCLO2760,env,argv,local);
	local[2]= argv[0]->c.obj.iv[7];
	ctx->vsp=local+3;
	w=(pointer)MAPCAN(ctx,2,local+1); /*mapcan*/
	local[0]= w;
objectBLK2757:
	ctx->vsp=local; return(local[0]);}

/*:all-methods*/
static pointer objectM2761metaclass_all_methods(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	if (argv[0]->c.obj.iv[2]==NIL) goto objectIF2763;
	local[0]= argv[0]->c.obj.iv[7];
	local[1]= argv[0]->c.obj.iv[2];
	local[2]= fqv[26];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(pointer)APPEND(ctx,2,local+0); /*append*/
	local[0]= w;
	goto objectIF2764;
objectIF2763:
	local[0]= argv[0]->c.obj.iv[7];
objectIF2764:
	w = local[0];
	local[0]= w;
objectBLK2762:
	ctx->vsp=local; return(local[0]);}

/*:all-method-names*/
static pointer objectM2765metaclass_all_method_names(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2768;}
	local[0]= fqv[27];
objectENT2768:
objectENT2767:
	if (n>3) maerror();
	local[1]= argv[0]->c.obj.iv[1];
	local[2]= argv[0];
	local[3]= fqv[28];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)LIST(ctx,2,local+1); /*list*/
	local[1]= w;
	if (argv[0]->c.obj.iv[2]==NIL) goto objectIF2769;
	local[2]= argv[0]->c.obj.iv[2];
	local[3]= fqv[12];
	local[4]= local[0];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= w;
	goto objectIF2770;
objectIF2769:
	local[2]= NIL;
objectIF2770:
	local[3]= local[1];
	w = local[2];
	ctx->vsp=local+4;
	w = cons(ctx,local[3],w);
	local[0]= w;
objectBLK2766:
	ctx->vsp=local; return(local[0]);}

/*:slots*/
static pointer objectM2771metaclass_slots(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[4];
	local[0]= w;
objectBLK2772:
	ctx->vsp=local; return(local[0]);}

/*:name*/
static pointer objectM2773metaclass_name(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[1];
	local[0]= w;
objectBLK2774:
	ctx->vsp=local; return(local[0]);}

/*:cid*/
static pointer objectM2775metaclass_cid(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
objectBLK2776:
	ctx->vsp=local; return(local[0]);}

/*:cix*/
static pointer objectM2777metaclass_cix(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[3];
	local[0]= w;
objectBLK2778:
	ctx->vsp=local; return(local[0]);}

/*:sub*/
static pointer objectM2779metaclass_sub(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	ctx->vsp=local+2;
	w=(pointer)LISTALLCLASSES(ctx,0,local+2); /*system:list-all-classes*/
	local[2]= w;
objectWHL2781:
	if (local[2]==NIL) goto objectWHX2782;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[13];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	ctx->vsp=local+5;
	w=(pointer)EQ(ctx,2,local+3); /*eql*/
	if (w==NIL) goto objectIF2784;
	local[3]= local[1];
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	local[3]= local[0];
	goto objectIF2785;
objectIF2784:
	local[3]= NIL;
objectIF2785:
	goto objectWHL2781;
objectWHX2782:
	local[3]= NIL;
objectBLK2783:
	w = NIL;
	w = local[0];
	local[0]= w;
objectBLK2780:
	ctx->vsp=local; return(local[0]);}

/*:subclasses*/
static pointer objectM2786metaclass_subclasses(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0];
	local[1]= fqv[29];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
objectBLK2787:
	ctx->vsp=local; return(local[0]);}

/*:hierarchy*/
static pointer objectM2788metaclass_hierarchy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0];
	local[3]= fqv[29];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
objectWHL2790:
	if (local[2]==NIL) goto objectWHX2791;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[30];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	w = local[0];
	ctx->vsp=local+4;
	local[0] = cons(ctx,local[3],w);
	goto objectWHL2790;
objectWHX2791:
	local[3]= NIL;
objectBLK2792:
	w = NIL;
	local[1]= argv[0];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	ctx->vsp=local+2;
	w = cons(ctx,local[1],w);
	local[0]= w;
objectBLK2789:
	ctx->vsp=local; return(local[0]);}

/*:superclasses*/
static pointer objectM2793metaclass_superclasses(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= NIL;
	local[1]= argv[0];
	local[2]= fqv[13];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,2,local+1); /*send*/
	local[1]= w;
objectWHL2795:
	if (local[1]==NIL) goto objectWHX2796;
	local[2]= local[1];
	w = local[0];
	ctx->vsp=local+3;
	local[0] = cons(ctx,local[2],w);
	local[2]= local[1];
	local[3]= fqv[13];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[1] = w;
	goto objectWHL2795;
objectWHX2796:
	local[2]= NIL;
objectBLK2797:
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(pointer)NREVERSE(ctx,1,local+2); /*nreverse*/
	local[0]= w;
objectBLK2794:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer objectCLO2760(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	w=argv[0];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	argv[0] = (w)->c.cons.car;
	local[0]= env->c.clo.env2[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[5])(ctx,1,local+1,&ftab[5],fqv[31]); /*symbol-name*/
	local[1]= w;
	ctx->vsp=local+2;
	w=(*ftab[6])(ctx,2,local+0,&ftab[6],fqv[32]); /*substringp*/
	if (w==NIL) goto objectIF2798;
	local[0]= argv[0];
	w = NIL;
	ctx->vsp=local+1;
	local[0]= cons(ctx,local[0],w);
	goto objectIF2799;
objectIF2798:
	local[0]= NIL;
objectIF2799:
	w = local[0];
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:prin1*/
static pointer objectM2800load_module_prin1(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto objectENT2803;}
	local[0]= T;
objectENT2803:
objectENT2802:
	ctx->vsp=local+1;
	local[1]= minilist(ctx,&argv[n],n-3);
	local[2]= (pointer)get_sym_func(fqv[19]);
	local[3]= argv[0];
	local[4]= *(ovafptr(argv[1],fqv[20]));
	local[5]= fqv[21];
	local[6]= local[0];
	local[7]= loadglobal(fqv[24]);
	local[8]= fqv[33];
	local[9]= argv[0]->c.obj.iv[5];
	local[10]= fqv[34];
	ctx->vsp=local+11;
	w=(pointer)CONCATENATE(ctx,4,local+7); /*concatenate*/
	local[7]= w;
	local[8]= local[1];
	ctx->vsp=local+9;
	w=(pointer)APPLY(ctx,7,local+2); /*apply*/
	local[0]= w;
objectBLK2801:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___object(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[35];
	ctx->vsp=local+1;
	w=(pointer)LIST(ctx,1,local+0); /*list*/
	local[0]= fqv[36];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto objectIF2804;
	local[0]= fqv[37];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[38],w);
	goto objectIF2805;
objectIF2804:
	local[0]= fqv[39];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
objectIF2805:
	local[0]= fqv[40];
	ctx->vsp=local+1;
	w=(pointer)EXPORT(ctx,1,local+0); /*export*/
	ctx->vsp=local+0;
	compfun(ctx,fqv[41],module,objectF2688metaclass_name,fqv[42]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[43],module,objectF2689metaclass_vars,fqv[44]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2692object_prin1,fqv[21],fqv[45],fqv[46]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2699object_warning,fqv[7],fqv[45],fqv[47]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2702object_error,fqv[48],fqv[45],fqv[49]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2705object_slots,fqv[50],fqv[45],fqv[51]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2710object_methods,fqv[52],fqv[45],fqv[53]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2714object_super,fqv[13],fqv[45],fqv[54]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2716object_get_val,fqv[55],fqv[45],fqv[56]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2718object_set_val,fqv[57],fqv[45],fqv[58]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2720propertied_object_plist,fqv[59],fqv[60],fqv[61]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2726propertied_object_get,fqv[17],fqv[60],fqv[62]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2728propertied_object_put,fqv[15],fqv[60],fqv[63]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2732propertied_object_name,fqv[16],fqv[60],fqv[64]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2738propertied_object_remprop,fqv[65],fqv[60],fqv[66]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2742propertied_object_prin1,fqv[21],fqv[60],fqv[67]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2748metaclass_new,fqv[68],fqv[69],fqv[70]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2750metaclass_super,fqv[13],fqv[69],fqv[71]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2752metaclass_methods,fqv[52],fqv[69],fqv[72]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2754metaclass_method,fqv[73],fqv[69],fqv[74]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2756metaclass_method_names,fqv[28],fqv[69],fqv[75]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2761metaclass_all_methods,fqv[26],fqv[69],fqv[76]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2765metaclass_all_method_names,fqv[12],fqv[69],fqv[77]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2771metaclass_slots,fqv[50],fqv[69],fqv[78]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2773metaclass_name,fqv[16],fqv[69],fqv[79]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2775metaclass_cid,fqv[80],fqv[69],fqv[81]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2777metaclass_cix,fqv[82],fqv[69],fqv[83]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2779metaclass_sub,fqv[29],fqv[69],fqv[84]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2786metaclass_subclasses,fqv[85],fqv[69],fqv[86]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2788metaclass_hierarchy,fqv[30],fqv[69],fqv[87]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2793metaclass_superclasses,fqv[88],fqv[69],fqv[89]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,objectM2800load_module_prin1,fqv[21],fqv[90],fqv[91]);
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<7; i++) ftab[i]=fcallx;
}
