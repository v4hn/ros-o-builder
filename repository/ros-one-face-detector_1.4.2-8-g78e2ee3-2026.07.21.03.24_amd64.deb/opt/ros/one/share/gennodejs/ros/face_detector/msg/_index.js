
"use strict";

let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');

module.exports = {
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorResult: FaceDetectorResult,
  FaceDetectorGoal: FaceDetectorGoal,
};
