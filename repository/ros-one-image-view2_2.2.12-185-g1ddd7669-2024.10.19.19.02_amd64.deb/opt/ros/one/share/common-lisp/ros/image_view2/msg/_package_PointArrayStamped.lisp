(cl:in-package image_view2-msg)
(cl:export '(HEADER-VAL
          HEADER
          POINTS-VAL
          POINTS
))