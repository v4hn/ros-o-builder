
(cl:in-package :asdf)

(defsystem "image_view2-msg"
  :depends-on (:roslisp-msg-protocol :roslisp-utils :geometry_msgs-msg
               :std_msgs-msg
)
  :components ((:file "_package")
    (:file "ImageMarker2" :depends-on ("_package_ImageMarker2"))
    (:file "_package_ImageMarker2" :depends-on ("_package"))
    (:file "MouseEvent" :depends-on ("_package_MouseEvent"))
    (:file "_package_MouseEvent" :depends-on ("_package"))
    (:file "PointArrayStamped" :depends-on ("_package_PointArrayStamped"))
    (:file "_package_PointArrayStamped" :depends-on ("_package"))
  ))