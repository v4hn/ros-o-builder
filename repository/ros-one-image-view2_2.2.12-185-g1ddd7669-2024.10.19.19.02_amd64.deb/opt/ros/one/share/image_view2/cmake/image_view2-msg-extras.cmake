set(image_view2_MESSAGE_FILES "msg/ImageMarker2.msg;msg/PointArrayStamped.msg;msg/MouseEvent.msg")
set(image_view2_SERVICE_FILES "srv/ChangeMode.srv")
