char *makedate="Sat Oct 24 07:01:59 UTC 2026";
#if Linux
char *gitrevision="6db5aab3";
#else
char *gitrevision="";
#endif
char *compilehost="sbuild";
