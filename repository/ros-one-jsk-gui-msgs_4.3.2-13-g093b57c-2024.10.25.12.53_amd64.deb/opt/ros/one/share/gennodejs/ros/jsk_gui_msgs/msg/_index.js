
"use strict";

let VoiceMessage = require('./VoiceMessage.js');
let Tablet = require('./Tablet.js');
let Gravity = require('./Gravity.js');
let MultiTouch = require('./MultiTouch.js');
let AndroidSensor = require('./AndroidSensor.js');
let DeviceSensor = require('./DeviceSensor.js');
let Touch = require('./Touch.js');
let SlackMessage = require('./SlackMessage.js');
let TouchEvent = require('./TouchEvent.js');
let MagneticField = require('./MagneticField.js');
let Action = require('./Action.js');

module.exports = {
  VoiceMessage: VoiceMessage,
  Tablet: Tablet,
  Gravity: Gravity,
  MultiTouch: MultiTouch,
  AndroidSensor: AndroidSensor,
  DeviceSensor: DeviceSensor,
  Touch: Touch,
  SlackMessage: SlackMessage,
  TouchEvent: TouchEvent,
  MagneticField: MagneticField,
  Action: Action,
};
