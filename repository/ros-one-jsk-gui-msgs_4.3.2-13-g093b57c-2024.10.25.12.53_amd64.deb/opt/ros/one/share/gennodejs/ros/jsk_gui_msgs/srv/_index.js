
"use strict";

let YesNo = require('./YesNo.js')
let Query = require('./Query.js')

module.exports = {
  YesNo: YesNo,
  Query: Query,
};
