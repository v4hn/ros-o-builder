
"use strict";

let Feature0DDetect = require('./Feature0DDetect.js')
let Detect = require('./Detect.js')
let Feature1DDetect = require('./Feature1DDetect.js')
let TargetObj = require('./TargetObj.js')

module.exports = {
  Feature0DDetect: Feature0DDetect,
  Detect: Detect,
  Feature1DDetect: Feature1DDetect,
  TargetObj: TargetObj,
};
