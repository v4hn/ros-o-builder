(cl:defpackage view_controller_msgs-msg
  (:use )
  (:export
   "<CAMERAMOVEMENT>"
   "CAMERAMOVEMENT"
   "<CAMERAPLACEMENT>"
   "CAMERAPLACEMENT"
   "<CAMERATRAJECTORY>"
   "CAMERATRAJECTORY"
  ))

