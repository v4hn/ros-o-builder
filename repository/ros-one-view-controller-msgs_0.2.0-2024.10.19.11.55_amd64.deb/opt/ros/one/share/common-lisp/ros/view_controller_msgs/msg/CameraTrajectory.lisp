; Auto-generated. Do not edit!


(cl:in-package view_controller_msgs-msg)


;//! \htmlinclude CameraTrajectory.msg.html

(cl:defclass <CameraTrajectory> (roslisp-msg-protocol:ros-message)
  ((trajectory
    :reader trajectory
    :initarg :trajectory
    :type (cl:vector view_controller_msgs-msg:CameraMovement)
   :initform (cl:make-array 0 :element-type 'view_controller_msgs-msg:CameraMovement :initial-element (cl:make-instance 'view_controller_msgs-msg:CameraMovement)))
   (target_frame
    :reader target_frame
    :initarg :target_frame
    :type cl:string
    :initform "")
   (allow_free_yaw_axis
    :reader allow_free_yaw_axis
    :initarg :allow_free_yaw_axis
    :type cl:boolean
    :initform cl:nil)
   (mouse_interaction_mode
    :reader mouse_interaction_mode
    :initarg :mouse_interaction_mode
    :type cl:fixnum
    :initform 0)
   (interaction_disabled
    :reader interaction_disabled
    :initarg :interaction_disabled
    :type cl:boolean
    :initform cl:nil)
   (render_frame_by_frame
    :reader render_frame_by_frame
    :initarg :render_frame_by_frame
    :type cl:boolean
    :initform cl:nil)
   (frames_per_second
    :reader frames_per_second
    :initarg :frames_per_second
    :type cl:fixnum
    :initform 0))
)

(cl:defclass CameraTrajectory (<CameraTrajectory>)
  ())

(cl:defmethod cl:initialize-instance :after ((m <CameraTrajectory>) cl:&rest args)
  (cl:declare (cl:ignorable args))
  (cl:unless (cl:typep m 'CameraTrajectory)
    (roslisp-msg-protocol:msg-deprecation-warning "using old message class name view_controller_msgs-msg:<CameraTrajectory> is deprecated: use view_controller_msgs-msg:CameraTrajectory instead.")))

(cl:ensure-generic-function 'trajectory-val :lambda-list '(m))
(cl:defmethod trajectory-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:trajectory-val is deprecated.  Use view_controller_msgs-msg:trajectory instead.")
  (trajectory m))

(cl:ensure-generic-function 'target_frame-val :lambda-list '(m))
(cl:defmethod target_frame-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:target_frame-val is deprecated.  Use view_controller_msgs-msg:target_frame instead.")
  (target_frame m))

(cl:ensure-generic-function 'allow_free_yaw_axis-val :lambda-list '(m))
(cl:defmethod allow_free_yaw_axis-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:allow_free_yaw_axis-val is deprecated.  Use view_controller_msgs-msg:allow_free_yaw_axis instead.")
  (allow_free_yaw_axis m))

(cl:ensure-generic-function 'mouse_interaction_mode-val :lambda-list '(m))
(cl:defmethod mouse_interaction_mode-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:mouse_interaction_mode-val is deprecated.  Use view_controller_msgs-msg:mouse_interaction_mode instead.")
  (mouse_interaction_mode m))

(cl:ensure-generic-function 'interaction_disabled-val :lambda-list '(m))
(cl:defmethod interaction_disabled-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:interaction_disabled-val is deprecated.  Use view_controller_msgs-msg:interaction_disabled instead.")
  (interaction_disabled m))

(cl:ensure-generic-function 'render_frame_by_frame-val :lambda-list '(m))
(cl:defmethod render_frame_by_frame-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:render_frame_by_frame-val is deprecated.  Use view_controller_msgs-msg:render_frame_by_frame instead.")
  (render_frame_by_frame m))

(cl:ensure-generic-function 'frames_per_second-val :lambda-list '(m))
(cl:defmethod frames_per_second-val ((m <CameraTrajectory>))
  (roslisp-msg-protocol:msg-deprecation-warning "Using old-style slot reader view_controller_msgs-msg:frames_per_second-val is deprecated.  Use view_controller_msgs-msg:frames_per_second instead.")
  (frames_per_second m))
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql '<CameraTrajectory>)))
    "Constants for message type '<CameraTrajectory>"
  '((:NO_CHANGE . 0)
    (:ORBIT . 1)
    (:FPS . 2))
)
(cl:defmethod roslisp-msg-protocol:symbol-codes ((msg-type (cl:eql 'CameraTrajectory)))
    "Constants for message type 'CameraTrajectory"
  '((:NO_CHANGE . 0)
    (:ORBIT . 1)
    (:FPS . 2))
)
(cl:defmethod roslisp-msg-protocol:serialize ((msg <CameraTrajectory>) ostream)
  "Serializes a message object of type '<CameraTrajectory>"
  (cl:let ((__ros_arr_len (cl:length (cl:slot-value msg 'trajectory))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_arr_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_arr_len) ostream))
  (cl:map cl:nil #'(cl:lambda (ele) (roslisp-msg-protocol:serialize ele ostream))
   (cl:slot-value msg 'trajectory))
  (cl:let ((__ros_str_len (cl:length (cl:slot-value msg 'target_frame))))
    (cl:write-byte (cl:ldb (cl:byte 8 0) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 8) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 16) __ros_str_len) ostream)
    (cl:write-byte (cl:ldb (cl:byte 8 24) __ros_str_len) ostream))
  (cl:map cl:nil #'(cl:lambda (c) (cl:write-byte (cl:char-code c) ostream)) (cl:slot-value msg 'target_frame))
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'allow_free_yaw_axis) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'mouse_interaction_mode)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'interaction_disabled) 1 0)) ostream)
  (cl:write-byte (cl:ldb (cl:byte 8 0) (cl:if (cl:slot-value msg 'render_frame_by_frame) 1 0)) ostream)
  (cl:let* ((signed (cl:slot-value msg 'frames_per_second)) (unsigned (cl:if (cl:< signed 0) (cl:+ signed 256) signed)))
    (cl:write-byte (cl:ldb (cl:byte 8 0) unsigned) ostream)
    )
)
(cl:defmethod roslisp-msg-protocol:deserialize ((msg <CameraTrajectory>) istream)
  "Deserializes a message object of type '<CameraTrajectory>"
  (cl:let ((__ros_arr_len 0))
    (cl:setf (cl:ldb (cl:byte 8 0) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 8) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 16) __ros_arr_len) (cl:read-byte istream))
    (cl:setf (cl:ldb (cl:byte 8 24) __ros_arr_len) (cl:read-byte istream))
  (cl:setf (cl:slot-value msg 'trajectory) (cl:make-array __ros_arr_len))
  (cl:let ((vals (cl:slot-value msg 'trajectory)))
    (cl:dotimes (i __ros_arr_len)
    (cl:setf (cl:aref vals i) (cl:make-instance 'view_controller_msgs-msg:CameraMovement))
  (roslisp-msg-protocol:deserialize (cl:aref vals i) istream))))
    (cl:let ((__ros_str_len 0))
      (cl:setf (cl:ldb (cl:byte 8 0) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 8) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 16) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:ldb (cl:byte 8 24) __ros_str_len) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'target_frame) (cl:make-string __ros_str_len))
      (cl:dotimes (__ros_str_idx __ros_str_len msg)
        (cl:setf (cl:char (cl:slot-value msg 'target_frame) __ros_str_idx) (cl:code-char (cl:read-byte istream)))))
    (cl:setf (cl:slot-value msg 'allow_free_yaw_axis) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:ldb (cl:byte 8 0) (cl:slot-value msg 'mouse_interaction_mode)) (cl:read-byte istream))
    (cl:setf (cl:slot-value msg 'interaction_disabled) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:setf (cl:slot-value msg 'render_frame_by_frame) (cl:not (cl:zerop (cl:read-byte istream))))
    (cl:let ((unsigned 0))
      (cl:setf (cl:ldb (cl:byte 8 0) unsigned) (cl:read-byte istream))
      (cl:setf (cl:slot-value msg 'frames_per_second) (cl:if (cl:< unsigned 128) unsigned (cl:- unsigned 256))))
  msg
)
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql '<CameraTrajectory>)))
  "Returns string type for a message object of type '<CameraTrajectory>"
  "view_controller_msgs/CameraTrajectory")
(cl:defmethod roslisp-msg-protocol:ros-datatype ((msg (cl:eql 'CameraTrajectory)))
  "Returns string type for a message object of type 'CameraTrajectory"
  "view_controller_msgs/CameraTrajectory")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql '<CameraTrajectory>)))
  "Returns md5sum for a message object of type '<CameraTrajectory>"
  "c56d6e838f60da69466a74c60cf627d7")
(cl:defmethod roslisp-msg-protocol:md5sum ((type (cl:eql 'CameraTrajectory)))
  "Returns md5sum for a message object of type 'CameraTrajectory"
  "c56d6e838f60da69466a74c60cf627d7")
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql '<CameraTrajectory>)))
  "Returns full string definition for message of type '<CameraTrajectory>"
  (cl:format cl:nil "# This message defines a trajectory to move a camera along at and several options how to do that.  ~%~%# Array of camera poses and interpolation speeds defining a trajectory.~%CameraMovement[] trajectory~%~%# Sets this as the camera attached (fixed) frame before movement.~%# An empty string will leave the attached frame unchanged.~%string target_frame~%~%# A flag indicating if the camera yaw axis is fixed to +Z of the camera attached_frame.~%# (defaults to false)~%bool allow_free_yaw_axis~%~%# The interaction style that should be activated when movement is done.~%uint8 mouse_interaction_mode~%uint8 NO_CHANGE = 0 # Leaves the control style unchanged.~%uint8 ORBIT     = 1 # Activates the Orbit-style controller.~%uint8 FPS       = 2 # Activates the First-Person-Shooter-style controller.~%~%# A flag to enable or disable user interaction.~%# (defaults to false so that interaction is enabled)~%bool interaction_disabled~%~%# If false, the duration of the animated trajectory is equal to the time passed in the real world using ros::WallTime.~%#  This can lead to an inconsistent frame rate of the published camera view images if your computer is not fast enough.~%# If true, the trajectory is rendered frame by frame. This leads to:~%#  -> a consistent frame rate of the published camera view images,~%#  -> a video with the desired trajectory duration when composed of the camera view images,~%#  -> BUT the trajectory might be slower in real time, if your computer is not fast enough. ~%# (defaults to false)~%bool render_frame_by_frame~%~%# Desired frames per second when rendering frame by frame.~%int8 frames_per_second~%~%================================================================================~%MSG: view_controller_msgs/CameraMovement~%# This message defines where to move a camera to and at which speeds.  ~%~%# The target pose definition:~%~%# The frame-relative point to move the camera to.~%geometry_msgs/PointStamped eye~%~%# The frame-relative point for the focus (or pivot for an Orbit controller).~%# The camera points into the direction of the focus point at the end of the movement.~%geometry_msgs/PointStamped focus~%~%# The frame-relative vector that maps to \"up\" in the view plane.~%# In other words, a vector pointing to the top of the camera, in case you want to perform roll movements.~%geometry_msgs/Vector3Stamped up~%~%~%# Defines how long the transition from the current to the target camera pose should take.~%# Movements with a negative transition_duration will be ignored.~%duration transition_duration~%~%# The interpolation speed profile to use during this movement.~%uint8 interpolation_speed~%uint8 RISING    = 0 # Speed of the camera rises smoothly - resembles the first quarter of a sinus wave.~%uint8 DECLINING = 1 # Speed of the camera declines smoothly - resembles the second quarter of a sinus wave.~%uint8 FULL      = 2 # Camera is always at full speed - depending on transition_duration.~%uint8 WAVE      = 3 # RISING and DECLINING concatenated in one movement.~%~%================================================================================~%MSG: geometry_msgs/PointStamped~%# This represents a Point with reference coordinate frame and timestamp~%Header header~%Point point~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Vector3Stamped~%# This represents a Vector3 with reference coordinate frame and timestamp~%Header header~%Vector3 vector~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:message-definition ((type (cl:eql 'CameraTrajectory)))
  "Returns full string definition for message of type 'CameraTrajectory"
  (cl:format cl:nil "# This message defines a trajectory to move a camera along at and several options how to do that.  ~%~%# Array of camera poses and interpolation speeds defining a trajectory.~%CameraMovement[] trajectory~%~%# Sets this as the camera attached (fixed) frame before movement.~%# An empty string will leave the attached frame unchanged.~%string target_frame~%~%# A flag indicating if the camera yaw axis is fixed to +Z of the camera attached_frame.~%# (defaults to false)~%bool allow_free_yaw_axis~%~%# The interaction style that should be activated when movement is done.~%uint8 mouse_interaction_mode~%uint8 NO_CHANGE = 0 # Leaves the control style unchanged.~%uint8 ORBIT     = 1 # Activates the Orbit-style controller.~%uint8 FPS       = 2 # Activates the First-Person-Shooter-style controller.~%~%# A flag to enable or disable user interaction.~%# (defaults to false so that interaction is enabled)~%bool interaction_disabled~%~%# If false, the duration of the animated trajectory is equal to the time passed in the real world using ros::WallTime.~%#  This can lead to an inconsistent frame rate of the published camera view images if your computer is not fast enough.~%# If true, the trajectory is rendered frame by frame. This leads to:~%#  -> a consistent frame rate of the published camera view images,~%#  -> a video with the desired trajectory duration when composed of the camera view images,~%#  -> BUT the trajectory might be slower in real time, if your computer is not fast enough. ~%# (defaults to false)~%bool render_frame_by_frame~%~%# Desired frames per second when rendering frame by frame.~%int8 frames_per_second~%~%================================================================================~%MSG: view_controller_msgs/CameraMovement~%# This message defines where to move a camera to and at which speeds.  ~%~%# The target pose definition:~%~%# The frame-relative point to move the camera to.~%geometry_msgs/PointStamped eye~%~%# The frame-relative point for the focus (or pivot for an Orbit controller).~%# The camera points into the direction of the focus point at the end of the movement.~%geometry_msgs/PointStamped focus~%~%# The frame-relative vector that maps to \"up\" in the view plane.~%# In other words, a vector pointing to the top of the camera, in case you want to perform roll movements.~%geometry_msgs/Vector3Stamped up~%~%~%# Defines how long the transition from the current to the target camera pose should take.~%# Movements with a negative transition_duration will be ignored.~%duration transition_duration~%~%# The interpolation speed profile to use during this movement.~%uint8 interpolation_speed~%uint8 RISING    = 0 # Speed of the camera rises smoothly - resembles the first quarter of a sinus wave.~%uint8 DECLINING = 1 # Speed of the camera declines smoothly - resembles the second quarter of a sinus wave.~%uint8 FULL      = 2 # Camera is always at full speed - depending on transition_duration.~%uint8 WAVE      = 3 # RISING and DECLINING concatenated in one movement.~%~%================================================================================~%MSG: geometry_msgs/PointStamped~%# This represents a Point with reference coordinate frame and timestamp~%Header header~%Point point~%~%================================================================================~%MSG: std_msgs/Header~%# Standard metadata for higher-level stamped data types.~%# This is generally used to communicate timestamped data ~%# in a particular coordinate frame.~%# ~%# sequence ID: consecutively increasing ID ~%uint32 seq~%#Two-integer timestamp that is expressed as:~%# * stamp.sec: seconds (stamp_secs) since epoch (in Python the variable is called 'secs')~%# * stamp.nsec: nanoseconds since stamp_secs (in Python the variable is called 'nsecs')~%# time-handling sugar is provided by the client library~%time stamp~%#Frame this data is associated with~%string frame_id~%~%================================================================================~%MSG: geometry_msgs/Point~%# This contains the position of a point in free space~%float64 x~%float64 y~%float64 z~%~%================================================================================~%MSG: geometry_msgs/Vector3Stamped~%# This represents a Vector3 with reference coordinate frame and timestamp~%Header header~%Vector3 vector~%~%================================================================================~%MSG: geometry_msgs/Vector3~%# This represents a vector in free space. ~%# It is only meant to represent a direction. Therefore, it does not~%# make sense to apply a translation to it (e.g., when applying a ~%# generic rigid transformation to a Vector3, tf2 will only apply the~%# rotation). If you want your data to be translatable too, use the~%# geometry_msgs/Point message instead.~%~%float64 x~%float64 y~%float64 z~%~%"))
(cl:defmethod roslisp-msg-protocol:serialization-length ((msg <CameraTrajectory>))
  (cl:+ 0
     4 (cl:reduce #'cl:+ (cl:slot-value msg 'trajectory) :key #'(cl:lambda (ele) (cl:declare (cl:ignorable ele)) (cl:+ (roslisp-msg-protocol:serialization-length ele))))
     4 (cl:length (cl:slot-value msg 'target_frame))
     1
     1
     1
     1
     1
))
(cl:defmethod roslisp-msg-protocol:ros-message-to-list ((msg <CameraTrajectory>))
  "Converts a ROS message object to a list"
  (cl:list 'CameraTrajectory
    (cl:cons ':trajectory (trajectory msg))
    (cl:cons ':target_frame (target_frame msg))
    (cl:cons ':allow_free_yaw_axis (allow_free_yaw_axis msg))
    (cl:cons ':mouse_interaction_mode (mouse_interaction_mode msg))
    (cl:cons ':interaction_disabled (interaction_disabled msg))
    (cl:cons ':render_frame_by_frame (render_frame_by_frame msg))
    (cl:cons ':frames_per_second (frames_per_second msg))
))
