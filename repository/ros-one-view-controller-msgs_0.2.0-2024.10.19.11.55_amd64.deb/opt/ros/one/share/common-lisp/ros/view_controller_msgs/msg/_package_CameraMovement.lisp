(cl:in-package view_controller_msgs-msg)
(cl:export '(EYE-VAL
          EYE
          FOCUS-VAL
          FOCUS
          UP-VAL
          UP
          TRANSITION_DURATION-VAL
          TRANSITION_DURATION
          INTERPOLATION_SPEED-VAL
          INTERPOLATION_SPEED
))