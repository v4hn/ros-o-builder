set(view_controller_msgs_MESSAGE_FILES "msg/CameraPlacement.msg;msg/CameraMovement.msg;msg/CameraTrajectory.msg")
set(view_controller_msgs_SERVICE_FILES "")
