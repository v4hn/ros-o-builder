// Auto-generated. Do not edit!

// (in-package opencv_apps.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;
let Flow = require('./Flow.js');

//-----------------------------------------------------------

class FlowArray {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.flow = null;
      this.status = null;
    }
    else {
      if (initObj.hasOwnProperty('flow')) {
        this.flow = initObj.flow
      }
      else {
        this.flow = [];
      }
      if (initObj.hasOwnProperty('status')) {
        this.status = initObj.status
      }
      else {
        this.status = [];
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type FlowArray
    // Serialize message field [flow]
    // Serialize the length for message field [flow]
    bufferOffset = _serializer.uint32(obj.flow.length, buffer, bufferOffset);
    obj.flow.forEach((val) => {
      bufferOffset = Flow.serialize(val, buffer, bufferOffset);
    });
    // Serialize message field [status]
    bufferOffset = _arraySerializer.bool(obj.status, buffer, bufferOffset, null);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type FlowArray
    let len;
    let data = new FlowArray(null);
    // Deserialize message field [flow]
    // Deserialize array length for message field [flow]
    len = _deserializer.uint32(buffer, bufferOffset);
    data.flow = new Array(len);
    for (let i = 0; i < len; ++i) {
      data.flow[i] = Flow.deserialize(buffer, bufferOffset)
    }
    // Deserialize message field [status]
    data.status = _arrayDeserializer.bool(buffer, bufferOffset, null)
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += 32 * object.flow.length;
    length += object.status.length;
    return length + 8;
  }

  static datatype() {
    // Returns string type for a message object
    return 'opencv_apps/FlowArray';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return 'c760118371fbbe84c1e111ca333b84eb';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    Flow[] flow
    bool[] status
    
    ================================================================================
    MSG: opencv_apps/Flow
    Point2D point
    Point2D velocity
    
    ================================================================================
    MSG: opencv_apps/Point2D
    float64 x
    float64 y
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new FlowArray(null);
    if (msg.flow !== undefined) {
      resolved.flow = new Array(msg.flow.length);
      for (let i = 0; i < resolved.flow.length; ++i) {
        resolved.flow[i] = Flow.Resolve(msg.flow[i]);
      }
    }
    else {
      resolved.flow = []
    }

    if (msg.status !== undefined) {
      resolved.status = msg.status;
    }
    else {
      resolved.status = []
    }

    return resolved;
    }
};

module.exports = FlowArray;
