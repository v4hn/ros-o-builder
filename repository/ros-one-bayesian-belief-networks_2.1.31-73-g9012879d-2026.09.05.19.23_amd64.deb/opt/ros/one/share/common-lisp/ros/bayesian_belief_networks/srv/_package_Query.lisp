(cl:in-package bayesian_belief_networks-srv)
(cl:export '(QUERY-VAL
          QUERY
          RESULTS-VAL
          RESULTS
))