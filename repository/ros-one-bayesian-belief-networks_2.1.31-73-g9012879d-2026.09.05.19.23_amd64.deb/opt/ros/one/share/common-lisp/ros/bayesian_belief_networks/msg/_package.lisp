(cl:defpackage bayesian_belief_networks-msg
  (:use )
  (:export
   "<OBSERVATION>"
   "OBSERVATION"
   "<RESULT>"
   "RESULT"
  ))

