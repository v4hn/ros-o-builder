(cl:in-package bayesian_belief_networks-msg)
(cl:export '(NODE-VAL
          NODE
          EVIDENCE-VAL
          EVIDENCE
))