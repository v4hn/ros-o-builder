
"use strict";

let Observation = require('./Observation.js');
let Result = require('./Result.js');

module.exports = {
  Observation: Observation,
  Result: Result,
};
