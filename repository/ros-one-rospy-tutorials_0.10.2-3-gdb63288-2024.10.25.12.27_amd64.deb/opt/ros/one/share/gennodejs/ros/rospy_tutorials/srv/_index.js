
"use strict";

let BadTwoInts = require('./BadTwoInts.js')
let AddTwoInts = require('./AddTwoInts.js')

module.exports = {
  BadTwoInts: BadTwoInts,
  AddTwoInts: AddTwoInts,
};
