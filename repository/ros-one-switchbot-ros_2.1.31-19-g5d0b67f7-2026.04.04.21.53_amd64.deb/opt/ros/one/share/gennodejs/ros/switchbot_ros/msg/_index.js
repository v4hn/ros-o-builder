
"use strict";

let Hub2 = require('./Hub2.js');
let Device = require('./Device.js');
let PlugMini = require('./PlugMini.js');
let DeviceArray = require('./DeviceArray.js');
let MeterProCO2 = require('./MeterProCO2.js');
let Meter = require('./Meter.js');
let Bot = require('./Bot.js');
let StripLight = require('./StripLight.js');
let SwitchBotCommandActionResult = require('./SwitchBotCommandActionResult.js');
let SwitchBotCommandResult = require('./SwitchBotCommandResult.js');
let SwitchBotCommandActionGoal = require('./SwitchBotCommandActionGoal.js');
let SwitchBotCommandAction = require('./SwitchBotCommandAction.js');
let SwitchBotCommandGoal = require('./SwitchBotCommandGoal.js');
let SwitchBotCommandActionFeedback = require('./SwitchBotCommandActionFeedback.js');
let SwitchBotCommandFeedback = require('./SwitchBotCommandFeedback.js');

module.exports = {
  Hub2: Hub2,
  Device: Device,
  PlugMini: PlugMini,
  DeviceArray: DeviceArray,
  MeterProCO2: MeterProCO2,
  Meter: Meter,
  Bot: Bot,
  StripLight: StripLight,
  SwitchBotCommandActionResult: SwitchBotCommandActionResult,
  SwitchBotCommandResult: SwitchBotCommandResult,
  SwitchBotCommandActionGoal: SwitchBotCommandActionGoal,
  SwitchBotCommandAction: SwitchBotCommandAction,
  SwitchBotCommandGoal: SwitchBotCommandGoal,
  SwitchBotCommandActionFeedback: SwitchBotCommandActionFeedback,
  SwitchBotCommandFeedback: SwitchBotCommandFeedback,
};
