(cl:in-package switchbot_ros-msg)
(cl:export '(HEADER-VAL
          HEADER
          TEMPERATURE-VAL
          TEMPERATURE
          HUMIDITY-VAL
          HUMIDITY
          BATTERY-VAL
          BATTERY
          CO2PPM-VAL
          CO2PPM
))