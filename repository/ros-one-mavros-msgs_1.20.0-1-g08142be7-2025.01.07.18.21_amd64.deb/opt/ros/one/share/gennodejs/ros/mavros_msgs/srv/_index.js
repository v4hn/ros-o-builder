
"use strict";

let FileRename = require('./FileRename.js')
let WaypointClear = require('./WaypointClear.js')
let FileTruncate = require('./FileTruncate.js')
let FileRemoveDir = require('./FileRemoveDir.js')
let CommandBool = require('./CommandBool.js')
let LogRequestList = require('./LogRequestList.js')
let MessageInterval = require('./MessageInterval.js')
let CommandTriggerControl = require('./CommandTriggerControl.js')
let CommandVtolTransition = require('./CommandVtolTransition.js')
let WaypointPush = require('./WaypointPush.js')
let CommandAck = require('./CommandAck.js')
let ParamPull = require('./ParamPull.js')
let MountConfigure = require('./MountConfigure.js')
let FileWrite = require('./FileWrite.js')
let WaypointPull = require('./WaypointPull.js')
let StreamRate = require('./StreamRate.js')
let ParamSet = require('./ParamSet.js')
let ParamPush = require('./ParamPush.js')
let FileRead = require('./FileRead.js')
let SetMavFrame = require('./SetMavFrame.js')
let CommandLong = require('./CommandLong.js')
let LogRequestEnd = require('./LogRequestEnd.js')
let FileClose = require('./FileClose.js')
let CommandInt = require('./CommandInt.js')
let SetMode = require('./SetMode.js')
let CommandTriggerInterval = require('./CommandTriggerInterval.js')
let FileRemove = require('./FileRemove.js')
let CommandTOL = require('./CommandTOL.js')
let ParamGet = require('./ParamGet.js')
let FileMakeDir = require('./FileMakeDir.js')
let FileOpen = require('./FileOpen.js')
let FileChecksum = require('./FileChecksum.js')
let FileList = require('./FileList.js')
let LogRequestData = require('./LogRequestData.js')
let VehicleInfoGet = require('./VehicleInfoGet.js')
let CommandHome = require('./CommandHome.js')
let WaypointSetCurrent = require('./WaypointSetCurrent.js')

module.exports = {
  FileRename: FileRename,
  WaypointClear: WaypointClear,
  FileTruncate: FileTruncate,
  FileRemoveDir: FileRemoveDir,
  CommandBool: CommandBool,
  LogRequestList: LogRequestList,
  MessageInterval: MessageInterval,
  CommandTriggerControl: CommandTriggerControl,
  CommandVtolTransition: CommandVtolTransition,
  WaypointPush: WaypointPush,
  CommandAck: CommandAck,
  ParamPull: ParamPull,
  MountConfigure: MountConfigure,
  FileWrite: FileWrite,
  WaypointPull: WaypointPull,
  StreamRate: StreamRate,
  ParamSet: ParamSet,
  ParamPush: ParamPush,
  FileRead: FileRead,
  SetMavFrame: SetMavFrame,
  CommandLong: CommandLong,
  LogRequestEnd: LogRequestEnd,
  FileClose: FileClose,
  CommandInt: CommandInt,
  SetMode: SetMode,
  CommandTriggerInterval: CommandTriggerInterval,
  FileRemove: FileRemove,
  CommandTOL: CommandTOL,
  ParamGet: ParamGet,
  FileMakeDir: FileMakeDir,
  FileOpen: FileOpen,
  FileChecksum: FileChecksum,
  FileList: FileList,
  LogRequestData: LogRequestData,
  VehicleInfoGet: VehicleInfoGet,
  CommandHome: CommandHome,
  WaypointSetCurrent: WaypointSetCurrent,
};
