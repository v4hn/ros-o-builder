
"use strict";

let LoadClassifier = require('./LoadClassifier.js')
let AddClassData = require('./AddClassData.js')
let CreateClassifier = require('./CreateClassifier.js')
let ClearClassifier = require('./ClearClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let TrainClassifier = require('./TrainClassifier.js')
let SaveClassifier = require('./SaveClassifier.js')

module.exports = {
  LoadClassifier: LoadClassifier,
  AddClassData: AddClassData,
  CreateClassifier: CreateClassifier,
  ClearClassifier: ClearClassifier,
  ClassifyData: ClassifyData,
  TrainClassifier: TrainClassifier,
  SaveClassifier: SaveClassifier,
};
