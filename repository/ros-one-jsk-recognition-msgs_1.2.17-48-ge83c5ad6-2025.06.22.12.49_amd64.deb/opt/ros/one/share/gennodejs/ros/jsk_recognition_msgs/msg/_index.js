
"use strict";

let ImageDifferenceValue = require('./ImageDifferenceValue.js');
let TrackerStatus = require('./TrackerStatus.js');
let HistogramWithRangeArray = require('./HistogramWithRangeArray.js');
let SlicedPointCloud = require('./SlicedPointCloud.js');
let RotatedRect = require('./RotatedRect.js');
let SparseOccupancyGridColumn = require('./SparseOccupancyGridColumn.js');
let LineArray = require('./LineArray.js');
let SegmentArray = require('./SegmentArray.js');
let RectArray = require('./RectArray.js');
let SnapItRequest = require('./SnapItRequest.js');
let BoolStamped = require('./BoolStamped.js');
let TrackingStatus = require('./TrackingStatus.js');
let ICPResult = require('./ICPResult.js');
let PointsArray = require('./PointsArray.js');
let HeightmapConfig = require('./HeightmapConfig.js');
let SimpleOccupancyGrid = require('./SimpleOccupancyGrid.js');
let HumanSkeletonArray = require('./HumanSkeletonArray.js');
let VectorArray = require('./VectorArray.js');
let ParallelEdgeArray = require('./ParallelEdgeArray.js');
let ContactSensor = require('./ContactSensor.js');
let SimpleHandle = require('./SimpleHandle.js');
let ExifGPSInfo = require('./ExifGPSInfo.js');
let HandPoseArray = require('./HandPoseArray.js');
let PlotDataArray = require('./PlotDataArray.js');
let BoundingBoxArray = require('./BoundingBoxArray.js');
let PlotData = require('./PlotData.js');
let Rect = require('./Rect.js');
let ClassificationResult = require('./ClassificationResult.js');
let SparseImage = require('./SparseImage.js');
let Torus = require('./Torus.js');
let SparseOccupancyGrid = require('./SparseOccupancyGrid.js');
let PeoplePoseArray = require('./PeoplePoseArray.js');
let ExifTags = require('./ExifTags.js');
let BoundingBox = require('./BoundingBox.js');
let Line = require('./Line.js');
let Int32Stamped = require('./Int32Stamped.js');
let DepthErrorResult = require('./DepthErrorResult.js');
let Accuracy = require('./Accuracy.js');
let QueryAndProbability = require('./QueryAndProbability.js');
let ParallelEdge = require('./ParallelEdge.js');
let SimpleOccupancyGridArray = require('./SimpleOccupancyGridArray.js');
let Circle2D = require('./Circle2D.js');
let VQAResult = require('./VQAResult.js');
let PeoplePose = require('./PeoplePose.js');
let HandPose = require('./HandPose.js');
let BoundingBoxMovement = require('./BoundingBoxMovement.js');
let HistogramWithRangeBin = require('./HistogramWithRangeBin.js');
let HistogramWithRange = require('./HistogramWithRange.js');
let SparseOccupancyGridCell = require('./SparseOccupancyGridCell.js');
let ModelCoefficientsArray = require('./ModelCoefficientsArray.js');
let ColorHistogram = require('./ColorHistogram.js');
let PolygonArray = require('./PolygonArray.js');
let PanoramaInfo = require('./PanoramaInfo.js');
let SparseOccupancyGridArray = require('./SparseOccupancyGridArray.js');
let ClusterPointIndices = require('./ClusterPointIndices.js');
let QuestionAndAnswerText = require('./QuestionAndAnswerText.js');
let RotatedRectStamped = require('./RotatedRectStamped.js');
let WeightedPoseArray = require('./WeightedPoseArray.js');
let PosedCameraInfo = require('./PosedCameraInfo.js');
let ClipResult = require('./ClipResult.js');
let TorusArray = require('./TorusArray.js');
let Histogram = require('./Histogram.js');
let TimeRange = require('./TimeRange.js');
let ObjectArray = require('./ObjectArray.js');
let DepthCalibrationParameter = require('./DepthCalibrationParameter.js');
let ContactSensorArray = require('./ContactSensorArray.js');
let LabelArray = require('./LabelArray.js');
let Object = require('./Object.js');
let BoundingBoxArrayWithCameraInfo = require('./BoundingBoxArrayWithCameraInfo.js');
let ColorHistogramArray = require('./ColorHistogramArray.js');
let HumanSkeleton = require('./HumanSkeleton.js');
let Spectrum = require('./Spectrum.js');
let Segment = require('./Segment.js');
let Label = require('./Label.js');
let SegmentStamped = require('./SegmentStamped.js');
let Circle2DArray = require('./Circle2DArray.js');
let ClassificationTaskActionFeedback = require('./ClassificationTaskActionFeedback.js');
let ClassificationTaskActionGoal = require('./ClassificationTaskActionGoal.js');
let ClassificationTaskFeedback = require('./ClassificationTaskFeedback.js');
let ClassificationTaskAction = require('./ClassificationTaskAction.js');
let VQATaskActionFeedback = require('./VQATaskActionFeedback.js');
let ClassificationTaskGoal = require('./ClassificationTaskGoal.js');
let VQATaskAction = require('./VQATaskAction.js');
let VQATaskFeedback = require('./VQATaskFeedback.js');
let VQATaskResult = require('./VQATaskResult.js');
let VQATaskActionResult = require('./VQATaskActionResult.js');
let VQATaskActionGoal = require('./VQATaskActionGoal.js');
let ClassificationTaskResult = require('./ClassificationTaskResult.js');
let VQATaskGoal = require('./VQATaskGoal.js');
let ClassificationTaskActionResult = require('./ClassificationTaskActionResult.js');

module.exports = {
  ImageDifferenceValue: ImageDifferenceValue,
  TrackerStatus: TrackerStatus,
  HistogramWithRangeArray: HistogramWithRangeArray,
  SlicedPointCloud: SlicedPointCloud,
  RotatedRect: RotatedRect,
  SparseOccupancyGridColumn: SparseOccupancyGridColumn,
  LineArray: LineArray,
  SegmentArray: SegmentArray,
  RectArray: RectArray,
  SnapItRequest: SnapItRequest,
  BoolStamped: BoolStamped,
  TrackingStatus: TrackingStatus,
  ICPResult: ICPResult,
  PointsArray: PointsArray,
  HeightmapConfig: HeightmapConfig,
  SimpleOccupancyGrid: SimpleOccupancyGrid,
  HumanSkeletonArray: HumanSkeletonArray,
  VectorArray: VectorArray,
  ParallelEdgeArray: ParallelEdgeArray,
  ContactSensor: ContactSensor,
  SimpleHandle: SimpleHandle,
  ExifGPSInfo: ExifGPSInfo,
  HandPoseArray: HandPoseArray,
  PlotDataArray: PlotDataArray,
  BoundingBoxArray: BoundingBoxArray,
  PlotData: PlotData,
  Rect: Rect,
  ClassificationResult: ClassificationResult,
  SparseImage: SparseImage,
  Torus: Torus,
  SparseOccupancyGrid: SparseOccupancyGrid,
  PeoplePoseArray: PeoplePoseArray,
  ExifTags: ExifTags,
  BoundingBox: BoundingBox,
  Line: Line,
  Int32Stamped: Int32Stamped,
  DepthErrorResult: DepthErrorResult,
  Accuracy: Accuracy,
  QueryAndProbability: QueryAndProbability,
  ParallelEdge: ParallelEdge,
  SimpleOccupancyGridArray: SimpleOccupancyGridArray,
  Circle2D: Circle2D,
  VQAResult: VQAResult,
  PeoplePose: PeoplePose,
  HandPose: HandPose,
  BoundingBoxMovement: BoundingBoxMovement,
  HistogramWithRangeBin: HistogramWithRangeBin,
  HistogramWithRange: HistogramWithRange,
  SparseOccupancyGridCell: SparseOccupancyGridCell,
  ModelCoefficientsArray: ModelCoefficientsArray,
  ColorHistogram: ColorHistogram,
  PolygonArray: PolygonArray,
  PanoramaInfo: PanoramaInfo,
  SparseOccupancyGridArray: SparseOccupancyGridArray,
  ClusterPointIndices: ClusterPointIndices,
  QuestionAndAnswerText: QuestionAndAnswerText,
  RotatedRectStamped: RotatedRectStamped,
  WeightedPoseArray: WeightedPoseArray,
  PosedCameraInfo: PosedCameraInfo,
  ClipResult: ClipResult,
  TorusArray: TorusArray,
  Histogram: Histogram,
  TimeRange: TimeRange,
  ObjectArray: ObjectArray,
  DepthCalibrationParameter: DepthCalibrationParameter,
  ContactSensorArray: ContactSensorArray,
  LabelArray: LabelArray,
  Object: Object,
  BoundingBoxArrayWithCameraInfo: BoundingBoxArrayWithCameraInfo,
  ColorHistogramArray: ColorHistogramArray,
  HumanSkeleton: HumanSkeleton,
  Spectrum: Spectrum,
  Segment: Segment,
  Label: Label,
  SegmentStamped: SegmentStamped,
  Circle2DArray: Circle2DArray,
  ClassificationTaskActionFeedback: ClassificationTaskActionFeedback,
  ClassificationTaskActionGoal: ClassificationTaskActionGoal,
  ClassificationTaskFeedback: ClassificationTaskFeedback,
  ClassificationTaskAction: ClassificationTaskAction,
  VQATaskActionFeedback: VQATaskActionFeedback,
  ClassificationTaskGoal: ClassificationTaskGoal,
  VQATaskAction: VQATaskAction,
  VQATaskFeedback: VQATaskFeedback,
  VQATaskResult: VQATaskResult,
  VQATaskActionResult: VQATaskActionResult,
  VQATaskActionGoal: VQATaskActionGoal,
  ClassificationTaskResult: ClassificationTaskResult,
  VQATaskGoal: VQATaskGoal,
  ClassificationTaskActionResult: ClassificationTaskActionResult,
};
