// Auto-generated. Do not edit!

// (in-package jsk_recognition_msgs.msg)


"use strict";

const _serializer = _ros_msg_utils.Serialize;
const _arraySerializer = _serializer.Array;
const _deserializer = _ros_msg_utils.Deserialize;
const _arrayDeserializer = _deserializer.Array;
const _finder = _ros_msg_utils.Find;
const _getByteLength = _ros_msg_utils.getByteLength;

//-----------------------------------------------------------

class ExifGPSInfo {
  constructor(initObj={}) {
    if (initObj === null) {
      // initObj === null is a special case for deserialization where we don't initialize fields
      this.gps_version_id = null;
      this.gps_latitude_ref = null;
      this.gps_latitude = null;
      this.gps_longitude_ref = null;
      this.gps_longitude = null;
      this.gps_altitude_ref = null;
      this.gps_altitude = null;
      this.gps_time_stamp = null;
      this.gps_satellites = null;
      this.gps_status = null;
      this.gps_measure_mode = null;
      this.gpf_sdop = null;
      this.gps_speed_ref = null;
      this.gps_speed = null;
      this.gps_track_ref = null;
      this.gps_track = null;
      this.gps_img_direction_ref = null;
      this.gps_img_direction = null;
      this.gps_map_datum = null;
      this.gps_dest_latitude_ref = null;
      this.gps_dest_latitude = null;
      this.gps_dest_longitude_ref = null;
      this.gps_dest_longitude = null;
      this.gps_dest_bearing_ref = null;
      this.gps_dest_bearing = null;
      this.gps_dest_distance_ref = null;
      this.gps_dest_distance = null;
      this.gps_date_stamp = null;
      this.gps_differential = null;
      this.gps_hpositioning_error = null;
    }
    else {
      if (initObj.hasOwnProperty('gps_version_id')) {
        this.gps_version_id = initObj.gps_version_id
      }
      else {
        this.gps_version_id = new Array(4).fill(0);
      }
      if (initObj.hasOwnProperty('gps_latitude_ref')) {
        this.gps_latitude_ref = initObj.gps_latitude_ref
      }
      else {
        this.gps_latitude_ref = '';
      }
      if (initObj.hasOwnProperty('gps_latitude')) {
        this.gps_latitude = initObj.gps_latitude
      }
      else {
        this.gps_latitude = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('gps_longitude_ref')) {
        this.gps_longitude_ref = initObj.gps_longitude_ref
      }
      else {
        this.gps_longitude_ref = '';
      }
      if (initObj.hasOwnProperty('gps_longitude')) {
        this.gps_longitude = initObj.gps_longitude
      }
      else {
        this.gps_longitude = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('gps_altitude_ref')) {
        this.gps_altitude_ref = initObj.gps_altitude_ref
      }
      else {
        this.gps_altitude_ref = 0;
      }
      if (initObj.hasOwnProperty('gps_altitude')) {
        this.gps_altitude = initObj.gps_altitude
      }
      else {
        this.gps_altitude = 0.0;
      }
      if (initObj.hasOwnProperty('gps_time_stamp')) {
        this.gps_time_stamp = initObj.gps_time_stamp
      }
      else {
        this.gps_time_stamp = 0.0;
      }
      if (initObj.hasOwnProperty('gps_satellites')) {
        this.gps_satellites = initObj.gps_satellites
      }
      else {
        this.gps_satellites = '';
      }
      if (initObj.hasOwnProperty('gps_status')) {
        this.gps_status = initObj.gps_status
      }
      else {
        this.gps_status = '';
      }
      if (initObj.hasOwnProperty('gps_measure_mode')) {
        this.gps_measure_mode = initObj.gps_measure_mode
      }
      else {
        this.gps_measure_mode = '';
      }
      if (initObj.hasOwnProperty('gpf_sdop')) {
        this.gpf_sdop = initObj.gpf_sdop
      }
      else {
        this.gpf_sdop = 0.0;
      }
      if (initObj.hasOwnProperty('gps_speed_ref')) {
        this.gps_speed_ref = initObj.gps_speed_ref
      }
      else {
        this.gps_speed_ref = '';
      }
      if (initObj.hasOwnProperty('gps_speed')) {
        this.gps_speed = initObj.gps_speed
      }
      else {
        this.gps_speed = 0.0;
      }
      if (initObj.hasOwnProperty('gps_track_ref')) {
        this.gps_track_ref = initObj.gps_track_ref
      }
      else {
        this.gps_track_ref = '';
      }
      if (initObj.hasOwnProperty('gps_track')) {
        this.gps_track = initObj.gps_track
      }
      else {
        this.gps_track = 0.0;
      }
      if (initObj.hasOwnProperty('gps_img_direction_ref')) {
        this.gps_img_direction_ref = initObj.gps_img_direction_ref
      }
      else {
        this.gps_img_direction_ref = '';
      }
      if (initObj.hasOwnProperty('gps_img_direction')) {
        this.gps_img_direction = initObj.gps_img_direction
      }
      else {
        this.gps_img_direction = 0.0;
      }
      if (initObj.hasOwnProperty('gps_map_datum')) {
        this.gps_map_datum = initObj.gps_map_datum
      }
      else {
        this.gps_map_datum = '';
      }
      if (initObj.hasOwnProperty('gps_dest_latitude_ref')) {
        this.gps_dest_latitude_ref = initObj.gps_dest_latitude_ref
      }
      else {
        this.gps_dest_latitude_ref = '';
      }
      if (initObj.hasOwnProperty('gps_dest_latitude')) {
        this.gps_dest_latitude = initObj.gps_dest_latitude
      }
      else {
        this.gps_dest_latitude = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('gps_dest_longitude_ref')) {
        this.gps_dest_longitude_ref = initObj.gps_dest_longitude_ref
      }
      else {
        this.gps_dest_longitude_ref = '';
      }
      if (initObj.hasOwnProperty('gps_dest_longitude')) {
        this.gps_dest_longitude = initObj.gps_dest_longitude
      }
      else {
        this.gps_dest_longitude = new Array(3).fill(0);
      }
      if (initObj.hasOwnProperty('gps_dest_bearing_ref')) {
        this.gps_dest_bearing_ref = initObj.gps_dest_bearing_ref
      }
      else {
        this.gps_dest_bearing_ref = '';
      }
      if (initObj.hasOwnProperty('gps_dest_bearing')) {
        this.gps_dest_bearing = initObj.gps_dest_bearing
      }
      else {
        this.gps_dest_bearing = 0.0;
      }
      if (initObj.hasOwnProperty('gps_dest_distance_ref')) {
        this.gps_dest_distance_ref = initObj.gps_dest_distance_ref
      }
      else {
        this.gps_dest_distance_ref = '';
      }
      if (initObj.hasOwnProperty('gps_dest_distance')) {
        this.gps_dest_distance = initObj.gps_dest_distance
      }
      else {
        this.gps_dest_distance = 0.0;
      }
      if (initObj.hasOwnProperty('gps_date_stamp')) {
        this.gps_date_stamp = initObj.gps_date_stamp
      }
      else {
        this.gps_date_stamp = '';
      }
      if (initObj.hasOwnProperty('gps_differential')) {
        this.gps_differential = initObj.gps_differential
      }
      else {
        this.gps_differential = 0;
      }
      if (initObj.hasOwnProperty('gps_hpositioning_error')) {
        this.gps_hpositioning_error = initObj.gps_hpositioning_error
      }
      else {
        this.gps_hpositioning_error = 0.0;
      }
    }
  }

  static serialize(obj, buffer, bufferOffset) {
    // Serializes a message object of type ExifGPSInfo
    // Check that the constant length array field [gps_version_id] has the right length
    if (obj.gps_version_id.length !== 4) {
      throw new Error('Unable to serialize array field gps_version_id - length must be 4')
    }
    // Serialize message field [gps_version_id]
    bufferOffset = _arraySerializer.uint8(obj.gps_version_id, buffer, bufferOffset, 4);
    // Serialize message field [gps_latitude_ref]
    bufferOffset = _serializer.string(obj.gps_latitude_ref, buffer, bufferOffset);
    // Check that the constant length array field [gps_latitude] has the right length
    if (obj.gps_latitude.length !== 3) {
      throw new Error('Unable to serialize array field gps_latitude - length must be 3')
    }
    // Serialize message field [gps_latitude]
    bufferOffset = _arraySerializer.float64(obj.gps_latitude, buffer, bufferOffset, 3);
    // Serialize message field [gps_longitude_ref]
    bufferOffset = _serializer.string(obj.gps_longitude_ref, buffer, bufferOffset);
    // Check that the constant length array field [gps_longitude] has the right length
    if (obj.gps_longitude.length !== 3) {
      throw new Error('Unable to serialize array field gps_longitude - length must be 3')
    }
    // Serialize message field [gps_longitude]
    bufferOffset = _arraySerializer.float64(obj.gps_longitude, buffer, bufferOffset, 3);
    // Serialize message field [gps_altitude_ref]
    bufferOffset = _serializer.uint8(obj.gps_altitude_ref, buffer, bufferOffset);
    // Serialize message field [gps_altitude]
    bufferOffset = _serializer.float64(obj.gps_altitude, buffer, bufferOffset);
    // Serialize message field [gps_time_stamp]
    bufferOffset = _serializer.float64(obj.gps_time_stamp, buffer, bufferOffset);
    // Serialize message field [gps_satellites]
    bufferOffset = _serializer.string(obj.gps_satellites, buffer, bufferOffset);
    // Serialize message field [gps_status]
    bufferOffset = _serializer.string(obj.gps_status, buffer, bufferOffset);
    // Serialize message field [gps_measure_mode]
    bufferOffset = _serializer.string(obj.gps_measure_mode, buffer, bufferOffset);
    // Serialize message field [gpf_sdop]
    bufferOffset = _serializer.float64(obj.gpf_sdop, buffer, bufferOffset);
    // Serialize message field [gps_speed_ref]
    bufferOffset = _serializer.string(obj.gps_speed_ref, buffer, bufferOffset);
    // Serialize message field [gps_speed]
    bufferOffset = _serializer.float64(obj.gps_speed, buffer, bufferOffset);
    // Serialize message field [gps_track_ref]
    bufferOffset = _serializer.string(obj.gps_track_ref, buffer, bufferOffset);
    // Serialize message field [gps_track]
    bufferOffset = _serializer.float64(obj.gps_track, buffer, bufferOffset);
    // Serialize message field [gps_img_direction_ref]
    bufferOffset = _serializer.string(obj.gps_img_direction_ref, buffer, bufferOffset);
    // Serialize message field [gps_img_direction]
    bufferOffset = _serializer.float64(obj.gps_img_direction, buffer, bufferOffset);
    // Serialize message field [gps_map_datum]
    bufferOffset = _serializer.string(obj.gps_map_datum, buffer, bufferOffset);
    // Serialize message field [gps_dest_latitude_ref]
    bufferOffset = _serializer.string(obj.gps_dest_latitude_ref, buffer, bufferOffset);
    // Check that the constant length array field [gps_dest_latitude] has the right length
    if (obj.gps_dest_latitude.length !== 3) {
      throw new Error('Unable to serialize array field gps_dest_latitude - length must be 3')
    }
    // Serialize message field [gps_dest_latitude]
    bufferOffset = _arraySerializer.float64(obj.gps_dest_latitude, buffer, bufferOffset, 3);
    // Serialize message field [gps_dest_longitude_ref]
    bufferOffset = _serializer.string(obj.gps_dest_longitude_ref, buffer, bufferOffset);
    // Check that the constant length array field [gps_dest_longitude] has the right length
    if (obj.gps_dest_longitude.length !== 3) {
      throw new Error('Unable to serialize array field gps_dest_longitude - length must be 3')
    }
    // Serialize message field [gps_dest_longitude]
    bufferOffset = _arraySerializer.float64(obj.gps_dest_longitude, buffer, bufferOffset, 3);
    // Serialize message field [gps_dest_bearing_ref]
    bufferOffset = _serializer.string(obj.gps_dest_bearing_ref, buffer, bufferOffset);
    // Serialize message field [gps_dest_bearing]
    bufferOffset = _serializer.float64(obj.gps_dest_bearing, buffer, bufferOffset);
    // Serialize message field [gps_dest_distance_ref]
    bufferOffset = _serializer.string(obj.gps_dest_distance_ref, buffer, bufferOffset);
    // Serialize message field [gps_dest_distance]
    bufferOffset = _serializer.float64(obj.gps_dest_distance, buffer, bufferOffset);
    // Serialize message field [gps_date_stamp]
    bufferOffset = _serializer.string(obj.gps_date_stamp, buffer, bufferOffset);
    // Serialize message field [gps_differential]
    bufferOffset = _serializer.uint16(obj.gps_differential, buffer, bufferOffset);
    // Serialize message field [gps_hpositioning_error]
    bufferOffset = _serializer.float64(obj.gps_hpositioning_error, buffer, bufferOffset);
    return bufferOffset;
  }

  static deserialize(buffer, bufferOffset=[0]) {
    //deserializes a message object of type ExifGPSInfo
    let len;
    let data = new ExifGPSInfo(null);
    // Deserialize message field [gps_version_id]
    data.gps_version_id = _arrayDeserializer.uint8(buffer, bufferOffset, 4)
    // Deserialize message field [gps_latitude_ref]
    data.gps_latitude_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_latitude]
    data.gps_latitude = _arrayDeserializer.float64(buffer, bufferOffset, 3)
    // Deserialize message field [gps_longitude_ref]
    data.gps_longitude_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_longitude]
    data.gps_longitude = _arrayDeserializer.float64(buffer, bufferOffset, 3)
    // Deserialize message field [gps_altitude_ref]
    data.gps_altitude_ref = _deserializer.uint8(buffer, bufferOffset);
    // Deserialize message field [gps_altitude]
    data.gps_altitude = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_time_stamp]
    data.gps_time_stamp = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_satellites]
    data.gps_satellites = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_status]
    data.gps_status = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_measure_mode]
    data.gps_measure_mode = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gpf_sdop]
    data.gpf_sdop = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_speed_ref]
    data.gps_speed_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_speed]
    data.gps_speed = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_track_ref]
    data.gps_track_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_track]
    data.gps_track = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_img_direction_ref]
    data.gps_img_direction_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_img_direction]
    data.gps_img_direction = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_map_datum]
    data.gps_map_datum = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_dest_latitude_ref]
    data.gps_dest_latitude_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_dest_latitude]
    data.gps_dest_latitude = _arrayDeserializer.float64(buffer, bufferOffset, 3)
    // Deserialize message field [gps_dest_longitude_ref]
    data.gps_dest_longitude_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_dest_longitude]
    data.gps_dest_longitude = _arrayDeserializer.float64(buffer, bufferOffset, 3)
    // Deserialize message field [gps_dest_bearing_ref]
    data.gps_dest_bearing_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_dest_bearing]
    data.gps_dest_bearing = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_dest_distance_ref]
    data.gps_dest_distance_ref = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_dest_distance]
    data.gps_dest_distance = _deserializer.float64(buffer, bufferOffset);
    // Deserialize message field [gps_date_stamp]
    data.gps_date_stamp = _deserializer.string(buffer, bufferOffset);
    // Deserialize message field [gps_differential]
    data.gps_differential = _deserializer.uint16(buffer, bufferOffset);
    // Deserialize message field [gps_hpositioning_error]
    data.gps_hpositioning_error = _deserializer.float64(buffer, bufferOffset);
    return data;
  }

  static getMessageSize(object) {
    let length = 0;
    length += _getByteLength(object.gps_latitude_ref);
    length += _getByteLength(object.gps_longitude_ref);
    length += _getByteLength(object.gps_satellites);
    length += _getByteLength(object.gps_status);
    length += _getByteLength(object.gps_measure_mode);
    length += _getByteLength(object.gps_speed_ref);
    length += _getByteLength(object.gps_track_ref);
    length += _getByteLength(object.gps_img_direction_ref);
    length += _getByteLength(object.gps_map_datum);
    length += _getByteLength(object.gps_dest_latitude_ref);
    length += _getByteLength(object.gps_dest_longitude_ref);
    length += _getByteLength(object.gps_dest_bearing_ref);
    length += _getByteLength(object.gps_dest_distance_ref);
    length += _getByteLength(object.gps_date_stamp);
    return length + 231;
  }

  static datatype() {
    // Returns string type for a message object
    return 'jsk_recognition_msgs/ExifGPSInfo';
  }

  static md5sum() {
    //Returns md5sum for a message object
    return '4d78b4fbebd5b498dabfce0a45f72762';
  }

  static messageDefinition() {
    // Returns full string definition for message
    return `
    #
    # https://exiftool.org/TagNames/GPS.html
    #
    # Tag ID	Tag Name	Writable	Values / Notes
    # 0x0000	GPSVersionID	int8u[4]:
    uint8[4] gps_version_id
    # 0x0001	GPSLatitudeRef	string[2]	(tags 0x0001-0x0006 used for camera location according to MWG 2.0. ExifTool will also accept a number when writing GPSLatitudeRef, positive for north latitudes or negative for south, or a string containing N, North, S or South)
    # 						'N' = North
    # 						'S' = South
    string gps_latitude_ref
    # 0x0002	GPSLatitude	rational64u[3]
    float64[3] gps_latitude
    # 0x0003	GPSLongitudeRef	string[2]	(ExifTool will also accept a number when writing this tag, positive for east longitudes or negative for west, or a string containing E, East, W or West)
    # 						'E' = East
    # 						'W' = West
    string gps_longitude_ref
    # 0x0004	GPSLongitude	rational64u[3]
    float64[3] gps_longitude
    # 0x0005	GPSAltitudeRef	int8u	(ExifTool will also accept number when writing this tag, with negative numbers indicating below sea level)
    uint8 gps_altitude_ref
    # 						0 = Above Sea Level
    # 						1 = Below Sea Level
    # 0x0006	GPSAltitude	rational64u
    float64 gps_altitude
    # 0x0007	GPSTimeStamp	rational64u[3]	(UTC time of GPS fix. When writing, date is stripped off if present, and time is adjusted to UTC if it includes a timezone)
    float64 gps_time_stamp
    # 0x0008	GPSSatellites	string
    string gps_satellites
    # 0x0009	GPSStatus	string[2]
    # 						'A' = Measurement Active
    # 						'V' = Measurement Void
    string gps_status
    # 0x000a	GPSMeasureMode	string[2]
    # 						2 = 2-Dimensional Measurement
    # 						3 = 3-Dimensional Measurement
    string gps_measure_mode
    # 0x000b	GPSDOP	rational64u
    float64 gpf_sdop
    # 0x000c	GPSSpeedRef	string[2]
    # 						'K' = km/h
    # 						'M' = mph
    # 						'N' = knots
    string gps_speed_ref
    # 0x000d	GPSSpeed	rational64u
    float64 gps_speed
    # 0x000e	GPSTrackRef	string[2]
    # 						'M' = Magnetic North
    # 						'T' = True North
    string gps_track_ref
    # 0x000f	GPSTrack	rational64u
    float64 gps_track
    # 0x0010	GPSImgDirectionRef	string[2]
    # 						'M' = Magnetic North
    # 						'T' = True North
    string gps_img_direction_ref
    # 0x0011	GPSImgDirection	rational64u
    float64 gps_img_direction
    # 0x0012	GPSMapDatum	string
    string gps_map_datum
    # 0x0013	GPSDestLatitudeRef	string[2]	(tags 0x0013-0x001a used for subject location according to MWG 2.0)
    # 						'N' = North
    # 						'S' = South
    string gps_dest_latitude_ref
    # 0x0014	GPSDestLatitude	rational64u[3]
    float64[3] gps_dest_latitude
    # 0x0015	GPSDestLongitudeRef	string[2]
    # 						'E' = East
    # 						'W' = West
    string gps_dest_longitude_ref
    # 0x0016	GPSDestLongitude	rational64u[3]
    float64[3] gps_dest_longitude
    # 0x0017	GPSDestBearingRef	string[2]
    # 						'M' = Magnetic North
    # 						'T' = True North
    string gps_dest_bearing_ref
    # 0x0018	GPSDestBearing	rational64u
    float64 gps_dest_bearing
    # 0x0019	GPSDestDistanceRef	string[2]
    # 						'K' = Kilometers
    # 						'M' = Miles
    # 						'N' = Nautical Miles
    string gps_dest_distance_ref
    # 0x001a	GPSDestDistance	rational64u
    float64 gps_dest_distance
    # 0x001b	GPSProcessingMethod	undef	(values of "GPS", "CELLID", "WLAN" or "MANUAL" by the EXIF spec.)
    # 0x001c	GPSAreaInformation	undef
    # 0x001d	GPSDateStamp	string[11]	(when writing, time is stripped off if present, after adjusting date/time to UTC if time includes a timezone. Format is YYYY:mm:dd)
    string gps_date_stamp
    # 0x001e	GPSDifferential	int16u
    # 						0 = No Correction
    # 						1 = Differential Corrected
    uint16 gps_differential
    # 0x001f	GPSHPositioningError	rational64u
    float64 gps_hpositioning_error
    
    
    `;
  }

  static Resolve(msg) {
    // deep-construct a valid message object instance of whatever was passed in
    if (typeof msg !== 'object' || msg === null) {
      msg = {};
    }
    const resolved = new ExifGPSInfo(null);
    if (msg.gps_version_id !== undefined) {
      resolved.gps_version_id = msg.gps_version_id;
    }
    else {
      resolved.gps_version_id = new Array(4).fill(0)
    }

    if (msg.gps_latitude_ref !== undefined) {
      resolved.gps_latitude_ref = msg.gps_latitude_ref;
    }
    else {
      resolved.gps_latitude_ref = ''
    }

    if (msg.gps_latitude !== undefined) {
      resolved.gps_latitude = msg.gps_latitude;
    }
    else {
      resolved.gps_latitude = new Array(3).fill(0)
    }

    if (msg.gps_longitude_ref !== undefined) {
      resolved.gps_longitude_ref = msg.gps_longitude_ref;
    }
    else {
      resolved.gps_longitude_ref = ''
    }

    if (msg.gps_longitude !== undefined) {
      resolved.gps_longitude = msg.gps_longitude;
    }
    else {
      resolved.gps_longitude = new Array(3).fill(0)
    }

    if (msg.gps_altitude_ref !== undefined) {
      resolved.gps_altitude_ref = msg.gps_altitude_ref;
    }
    else {
      resolved.gps_altitude_ref = 0
    }

    if (msg.gps_altitude !== undefined) {
      resolved.gps_altitude = msg.gps_altitude;
    }
    else {
      resolved.gps_altitude = 0.0
    }

    if (msg.gps_time_stamp !== undefined) {
      resolved.gps_time_stamp = msg.gps_time_stamp;
    }
    else {
      resolved.gps_time_stamp = 0.0
    }

    if (msg.gps_satellites !== undefined) {
      resolved.gps_satellites = msg.gps_satellites;
    }
    else {
      resolved.gps_satellites = ''
    }

    if (msg.gps_status !== undefined) {
      resolved.gps_status = msg.gps_status;
    }
    else {
      resolved.gps_status = ''
    }

    if (msg.gps_measure_mode !== undefined) {
      resolved.gps_measure_mode = msg.gps_measure_mode;
    }
    else {
      resolved.gps_measure_mode = ''
    }

    if (msg.gpf_sdop !== undefined) {
      resolved.gpf_sdop = msg.gpf_sdop;
    }
    else {
      resolved.gpf_sdop = 0.0
    }

    if (msg.gps_speed_ref !== undefined) {
      resolved.gps_speed_ref = msg.gps_speed_ref;
    }
    else {
      resolved.gps_speed_ref = ''
    }

    if (msg.gps_speed !== undefined) {
      resolved.gps_speed = msg.gps_speed;
    }
    else {
      resolved.gps_speed = 0.0
    }

    if (msg.gps_track_ref !== undefined) {
      resolved.gps_track_ref = msg.gps_track_ref;
    }
    else {
      resolved.gps_track_ref = ''
    }

    if (msg.gps_track !== undefined) {
      resolved.gps_track = msg.gps_track;
    }
    else {
      resolved.gps_track = 0.0
    }

    if (msg.gps_img_direction_ref !== undefined) {
      resolved.gps_img_direction_ref = msg.gps_img_direction_ref;
    }
    else {
      resolved.gps_img_direction_ref = ''
    }

    if (msg.gps_img_direction !== undefined) {
      resolved.gps_img_direction = msg.gps_img_direction;
    }
    else {
      resolved.gps_img_direction = 0.0
    }

    if (msg.gps_map_datum !== undefined) {
      resolved.gps_map_datum = msg.gps_map_datum;
    }
    else {
      resolved.gps_map_datum = ''
    }

    if (msg.gps_dest_latitude_ref !== undefined) {
      resolved.gps_dest_latitude_ref = msg.gps_dest_latitude_ref;
    }
    else {
      resolved.gps_dest_latitude_ref = ''
    }

    if (msg.gps_dest_latitude !== undefined) {
      resolved.gps_dest_latitude = msg.gps_dest_latitude;
    }
    else {
      resolved.gps_dest_latitude = new Array(3).fill(0)
    }

    if (msg.gps_dest_longitude_ref !== undefined) {
      resolved.gps_dest_longitude_ref = msg.gps_dest_longitude_ref;
    }
    else {
      resolved.gps_dest_longitude_ref = ''
    }

    if (msg.gps_dest_longitude !== undefined) {
      resolved.gps_dest_longitude = msg.gps_dest_longitude;
    }
    else {
      resolved.gps_dest_longitude = new Array(3).fill(0)
    }

    if (msg.gps_dest_bearing_ref !== undefined) {
      resolved.gps_dest_bearing_ref = msg.gps_dest_bearing_ref;
    }
    else {
      resolved.gps_dest_bearing_ref = ''
    }

    if (msg.gps_dest_bearing !== undefined) {
      resolved.gps_dest_bearing = msg.gps_dest_bearing;
    }
    else {
      resolved.gps_dest_bearing = 0.0
    }

    if (msg.gps_dest_distance_ref !== undefined) {
      resolved.gps_dest_distance_ref = msg.gps_dest_distance_ref;
    }
    else {
      resolved.gps_dest_distance_ref = ''
    }

    if (msg.gps_dest_distance !== undefined) {
      resolved.gps_dest_distance = msg.gps_dest_distance;
    }
    else {
      resolved.gps_dest_distance = 0.0
    }

    if (msg.gps_date_stamp !== undefined) {
      resolved.gps_date_stamp = msg.gps_date_stamp;
    }
    else {
      resolved.gps_date_stamp = ''
    }

    if (msg.gps_differential !== undefined) {
      resolved.gps_differential = msg.gps_differential;
    }
    else {
      resolved.gps_differential = 0
    }

    if (msg.gps_hpositioning_error !== undefined) {
      resolved.gps_hpositioning_error = msg.gps_hpositioning_error;
    }
    else {
      resolved.gps_hpositioning_error = 0.0
    }

    return resolved;
    }
};

module.exports = ExifGPSInfo;
