
"use strict";

let SetForceMode = require('./SetForceMode.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')
let SetPayload = require('./SetPayload.js')
let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetIO = require('./SetIO.js')

module.exports = {
  SetForceMode: SetForceMode,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
  SetPayload: SetPayload,
  SetSpeedSliderFraction: SetSpeedSliderFraction,
  SetAnalogOutput: SetAnalogOutput,
  SetIO: SetIO,
};
