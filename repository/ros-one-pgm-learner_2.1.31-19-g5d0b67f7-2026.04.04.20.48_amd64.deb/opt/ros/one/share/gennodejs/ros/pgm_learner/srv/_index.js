
"use strict";

let LinearGaussianParameterEstimation = require('./LinearGaussianParameterEstimation.js')
let LinearGaussianStructureEstimation = require('./LinearGaussianStructureEstimation.js')
let DiscreteQuery = require('./DiscreteQuery.js')
let DiscreteParameterEstimation = require('./DiscreteParameterEstimation.js')
let DiscreteStructureEstimation = require('./DiscreteStructureEstimation.js')

module.exports = {
  LinearGaussianParameterEstimation: LinearGaussianParameterEstimation,
  LinearGaussianStructureEstimation: LinearGaussianStructureEstimation,
  DiscreteQuery: DiscreteQuery,
  DiscreteParameterEstimation: DiscreteParameterEstimation,
  DiscreteStructureEstimation: DiscreteStructureEstimation,
};
