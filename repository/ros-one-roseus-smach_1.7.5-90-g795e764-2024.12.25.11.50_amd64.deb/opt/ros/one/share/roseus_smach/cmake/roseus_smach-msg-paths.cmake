# generated from genmsg/cmake/pkg-msg-paths.cmake.installspace.in

_prepend_path("${roseus_smach_DIR}/.." "msg;msg" roseus_smach_MSG_INCLUDE_DIRS UNIQUE)
set(roseus_smach_MSG_DEPENDENCIES actionlib_msgs;std_msgs)
