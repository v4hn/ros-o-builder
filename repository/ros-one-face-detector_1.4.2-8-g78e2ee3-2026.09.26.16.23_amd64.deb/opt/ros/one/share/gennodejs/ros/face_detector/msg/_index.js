
"use strict";

let FaceDetectorActionFeedback = require('./FaceDetectorActionFeedback.js');
let FaceDetectorFeedback = require('./FaceDetectorFeedback.js');
let FaceDetectorGoal = require('./FaceDetectorGoal.js');
let FaceDetectorActionResult = require('./FaceDetectorActionResult.js');
let FaceDetectorAction = require('./FaceDetectorAction.js');
let FaceDetectorActionGoal = require('./FaceDetectorActionGoal.js');
let FaceDetectorResult = require('./FaceDetectorResult.js');

module.exports = {
  FaceDetectorActionFeedback: FaceDetectorActionFeedback,
  FaceDetectorFeedback: FaceDetectorFeedback,
  FaceDetectorGoal: FaceDetectorGoal,
  FaceDetectorActionResult: FaceDetectorActionResult,
  FaceDetectorAction: FaceDetectorAction,
  FaceDetectorActionGoal: FaceDetectorActionGoal,
  FaceDetectorResult: FaceDetectorResult,
};
