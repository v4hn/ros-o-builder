
"use strict";

let AssocTF = require('./AssocTF.js')
let DeleteTF = require('./DeleteTF.js')
let SetDynamicTF = require('./SetDynamicTF.js')
let DissocTF = require('./DissocTF.js')

module.exports = {
  AssocTF: AssocTF,
  DeleteTF: DeleteTF,
  SetDynamicTF: SetDynamicTF,
  DissocTF: DissocTF,
};
