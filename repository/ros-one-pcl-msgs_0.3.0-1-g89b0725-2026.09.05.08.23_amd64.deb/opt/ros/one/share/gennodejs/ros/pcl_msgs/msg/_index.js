
"use strict";

let PointIndices = require('./PointIndices.js');
let PolygonMesh = require('./PolygonMesh.js');
let ModelCoefficients = require('./ModelCoefficients.js');
let Vertices = require('./Vertices.js');

module.exports = {
  PointIndices: PointIndices,
  PolygonMesh: PolygonMesh,
  ModelCoefficients: ModelCoefficients,
  Vertices: Vertices,
};
