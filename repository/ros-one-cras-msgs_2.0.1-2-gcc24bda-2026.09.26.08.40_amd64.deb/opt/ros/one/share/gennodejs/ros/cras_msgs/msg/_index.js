
"use strict";

let BrightnessStamped = require('./BrightnessStamped.js');
let Brightness = require('./Brightness.js');
let ColorRGBAStamped = require('./ColorRGBAStamped.js');
let Power = require('./Power.js');
let PowerSwitchStateStamped = require('./PowerSwitchStateStamped.js');
let ElectricCurrentStamped = require('./ElectricCurrentStamped.js');
let PowerSwitchState = require('./PowerSwitchState.js');
let ElectricCurrent = require('./ElectricCurrent.js');
let Voltage = require('./Voltage.js');
let Heartbeat = require('./Heartbeat.js');
let PowerStamped = require('./PowerStamped.js');
let VoltageStamped = require('./VoltageStamped.js');
let PowerMeasurement = require('./PowerMeasurement.js');
let ElectricCurrentMeasurement = require('./ElectricCurrentMeasurement.js');
let VoltageMeasurement = require('./VoltageMeasurement.js');

module.exports = {
  BrightnessStamped: BrightnessStamped,
  Brightness: Brightness,
  ColorRGBAStamped: ColorRGBAStamped,
  Power: Power,
  PowerSwitchStateStamped: PowerSwitchStateStamped,
  ElectricCurrentStamped: ElectricCurrentStamped,
  PowerSwitchState: PowerSwitchState,
  ElectricCurrent: ElectricCurrent,
  Voltage: Voltage,
  Heartbeat: Heartbeat,
  PowerStamped: PowerStamped,
  VoltageStamped: VoltageStamped,
  PowerMeasurement: PowerMeasurement,
  ElectricCurrentMeasurement: ElectricCurrentMeasurement,
  VoltageMeasurement: VoltageMeasurement,
};
