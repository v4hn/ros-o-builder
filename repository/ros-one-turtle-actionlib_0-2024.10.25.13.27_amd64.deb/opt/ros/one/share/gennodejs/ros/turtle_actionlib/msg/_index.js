
"use strict";

let Velocity = require('./Velocity.js');
let ShapeAction = require('./ShapeAction.js');
let ShapeActionFeedback = require('./ShapeActionFeedback.js');
let ShapeActionResult = require('./ShapeActionResult.js');
let ShapeGoal = require('./ShapeGoal.js');
let ShapeResult = require('./ShapeResult.js');
let ShapeActionGoal = require('./ShapeActionGoal.js');
let ShapeFeedback = require('./ShapeFeedback.js');

module.exports = {
  Velocity: Velocity,
  ShapeAction: ShapeAction,
  ShapeActionFeedback: ShapeActionFeedback,
  ShapeActionResult: ShapeActionResult,
  ShapeGoal: ShapeGoal,
  ShapeResult: ShapeResult,
  ShapeActionGoal: ShapeActionGoal,
  ShapeFeedback: ShapeFeedback,
};
