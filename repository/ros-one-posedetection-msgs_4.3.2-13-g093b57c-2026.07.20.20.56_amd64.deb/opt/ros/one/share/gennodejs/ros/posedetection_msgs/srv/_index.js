
"use strict";

let TargetObj = require('./TargetObj.js')
let Feature0DDetect = require('./Feature0DDetect.js')
let Feature1DDetect = require('./Feature1DDetect.js')
let Detect = require('./Detect.js')

module.exports = {
  TargetObj: TargetObj,
  Feature0DDetect: Feature0DDetect,
  Feature1DDetect: Feature1DDetect,
  Detect: Detect,
};
