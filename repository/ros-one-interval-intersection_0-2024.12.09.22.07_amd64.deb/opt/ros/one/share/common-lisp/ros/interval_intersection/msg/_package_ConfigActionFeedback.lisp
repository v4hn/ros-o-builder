(cl:in-package interval_intersection-msg)
(cl:export '(HEADER-VAL
          HEADER
          STATUS-VAL
          STATUS
          FEEDBACK-VAL
          FEEDBACK
))