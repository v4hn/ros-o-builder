
"use strict";

let IsProgramRunning = require('./IsProgramRunning.js')
let GetLoadedProgram = require('./GetLoadedProgram.js')
let GetSafetyMode = require('./GetSafetyMode.js')
let AddToLog = require('./AddToLog.js')
let RawRequest = require('./RawRequest.js')
let IsProgramSaved = require('./IsProgramSaved.js')
let Load = require('./Load.js')
let GetRobotMode = require('./GetRobotMode.js')
let IsInRemoteControl = require('./IsInRemoteControl.js')
let Popup = require('./Popup.js')
let GetProgramState = require('./GetProgramState.js')

module.exports = {
  IsProgramRunning: IsProgramRunning,
  GetLoadedProgram: GetLoadedProgram,
  GetSafetyMode: GetSafetyMode,
  AddToLog: AddToLog,
  RawRequest: RawRequest,
  IsProgramSaved: IsProgramSaved,
  Load: Load,
  GetRobotMode: GetRobotMode,
  IsInRemoteControl: IsInRemoteControl,
  Popup: Popup,
  GetProgramState: GetProgramState,
};
