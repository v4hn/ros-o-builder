
"use strict";

let AndroidSensor = require('./AndroidSensor.js');
let Tablet = require('./Tablet.js');
let Touch = require('./Touch.js');
let MagneticField = require('./MagneticField.js');
let DeviceSensor = require('./DeviceSensor.js');
let Action = require('./Action.js');
let VoiceMessage = require('./VoiceMessage.js');
let TouchEvent = require('./TouchEvent.js');
let Gravity = require('./Gravity.js');
let MultiTouch = require('./MultiTouch.js');
let SlackMessage = require('./SlackMessage.js');

module.exports = {
  AndroidSensor: AndroidSensor,
  Tablet: Tablet,
  Touch: Touch,
  MagneticField: MagneticField,
  DeviceSensor: DeviceSensor,
  Action: Action,
  VoiceMessage: VoiceMessage,
  TouchEvent: TouchEvent,
  Gravity: Gravity,
  MultiTouch: MultiTouch,
  SlackMessage: SlackMessage,
};
