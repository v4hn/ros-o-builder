
"use strict";

let SetParam = require('./SetParam.js')
let MongoUpdate = require('./MongoUpdate.js')
let MongoInsert = require('./MongoInsert.js')
let MongoFind = require('./MongoFind.js')
let GetParam = require('./GetParam.js')

module.exports = {
  SetParam: SetParam,
  MongoUpdate: MongoUpdate,
  MongoInsert: MongoInsert,
  MongoFind: MongoFind,
  GetParam: GetParam,
};
