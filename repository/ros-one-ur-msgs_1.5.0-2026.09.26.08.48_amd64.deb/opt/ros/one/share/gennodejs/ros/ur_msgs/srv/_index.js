
"use strict";

let SetPayload = require('./SetPayload.js')
let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')
let SetForceMode = require('./SetForceMode.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetIO = require('./SetIO.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')

module.exports = {
  SetPayload: SetPayload,
  SetSpeedSliderFraction: SetSpeedSliderFraction,
  SetForceMode: SetForceMode,
  SetAnalogOutput: SetAnalogOutput,
  SetIO: SetIO,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
};
