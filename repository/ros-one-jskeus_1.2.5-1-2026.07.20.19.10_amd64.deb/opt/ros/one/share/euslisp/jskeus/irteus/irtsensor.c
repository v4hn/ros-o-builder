/* ./irtsensor.c :  entry=irtsensor */
/* compiled by EusLisp 9.29(6db5aab3) for Linux64 created on sbuild(Mon Jul 20 19:03:13 UTC 2026) */
#include "eus.h"
#include "irtsensor.h"
#pragma init (register_irtsensor)
extern double fabs();
extern pointer fcallx();
static void init_ftab();
extern pointer loadglobal(),storeglobal();
static pointer module,*qv,codevec,quotevec;
extern pointer ___irtsensor();
extern pointer build_quote_vector();
static int register_irtsensor()
  { add_module_initializer("___irtsensor", ___irtsensor);}

static pointer irtsensoF2647make_camera_from_param();

/*:profile*/
static pointer irtsensoM2648sensor_model_profile(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtsensoENT2651;}
	local[0]= NIL;
irtsensoENT2651:
irtsensoENT2650:
	if (n>3) maerror();
	if (local[0]==NIL) goto irtsensoIF2652;
	argv[0]->c.obj.iv[17] = local[0];
	local[1]= argv[0]->c.obj.iv[17];
	goto irtsensoIF2653;
irtsensoIF2652:
	local[1]= NIL;
irtsensoIF2653:
	w = argv[0]->c.obj.iv[17];
	local[0]= w;
irtsensoBLK2649:
	ctx->vsp=local; return(local[0]);}

/*:signal*/
static pointer irtsensoM2654sensor_model_signal(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[0];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtsensoBLK2655:
	ctx->vsp=local; return(local[0]);}

/*:simulate*/
static pointer irtsensoM2656sensor_model_simulate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[2];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtsensoBLK2657:
	ctx->vsp=local; return(local[0]);}

/*:read*/
static pointer irtsensoM2658sensor_model_read(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtsensoBLK2659:
	ctx->vsp=local; return(local[0]);}

/*:draw-sensor*/
static pointer irtsensoM2660sensor_model_draw_sensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= fqv[3];
	ctx->vsp=local+1;
	w=(*ftab[0])(ctx,1,local+0,&ftab[0],fqv[1]); /*warn*/
	local[0]= w;
irtsensoBLK2661:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtsensoM2662sensor_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[4], &argv[3], n-3, local+0, 1);
	if (n & (1<<0)) goto irtsensoKEY2664;
	local[0] = NIL;
irtsensoKEY2664:
	local[1]= argv[0];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[1])(ctx,2,local+1,&ftab[1],fqv[5]); /*replace-object*/
	local[1]= argv[0];
	local[2]= fqv[6];
	local[3]= local[0];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,3,local+1); /*send*/
	w = argv[2];
	local[0]= w;
irtsensoBLK2663:
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtsensoM2665bumper_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtsensoRST2667:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[7], &argv[3], n-3, local+1, 0);
	if (n & (1<<0)) goto irtsensoKEY2668;
	local[1] = makeint((eusinteger_t)20L);
irtsensoKEY2668:
	if (n & (1<<1)) goto irtsensoKEY2669;
	local[2] = NIL;
irtsensoKEY2669:
	argv[0]->c.obj.iv[16] = makeint((eusinteger_t)0L);
	argv[0]->c.obj.iv[18] = local[1];
	local[3]= (pointer)get_sym_func(fqv[8]);
	local[4]= argv[0];
	local[5]= *(ovafptr(argv[1],fqv[9]));
	local[6]= fqv[10];
	local[7]= argv[2];
	local[8]= fqv[6];
	local[9]= local[2];
	local[10]= local[0];
	ctx->vsp=local+11;
	w=(pointer)APPLY(ctx,8,local+3); /*apply*/
	local[0]= w;
irtsensoBLK2666:
	ctx->vsp=local; return(local[0]);}

/*:simulate*/
static pointer irtsensoM2670bumper_model_simulate(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	if (argv[2]!=NIL) goto irtsensoIF2672;
	w = NIL;
	ctx->vsp=local+1;
	local[0]=w;
	goto irtsensoBLK2671;
	goto irtsensoIF2673;
irtsensoIF2672:
	local[1]= NIL;
irtsensoIF2673:
	w = argv[2];
	if (!!iscons(w)) goto irtsensoIF2674;
	local[1]= argv[2];
	ctx->vsp=local+2;
	w=(pointer)LIST(ctx,1,local+1); /*list*/
	argv[2] = w;
	local[1]= argv[2];
	goto irtsensoIF2675;
irtsensoIF2674:
	local[1]= NIL;
irtsensoIF2675:
	ctx->vsp=local+1;
	local[1]= makeclosure(codevec,quotevec,irtsensoCLO2678,env,argv,local);
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(*ftab[2])(ctx,2,local+1,&ftab[2],fqv[11]); /*some*/
	if (w==NIL) goto irtsensoIF2676;
	local[1]= makeint((eusinteger_t)1L);
	goto irtsensoIF2677;
irtsensoIF2676:
	local[1]= makeint((eusinteger_t)0L);
irtsensoIF2677:
	argv[0]->c.obj.iv[16] = local[1];
	w = argv[0]->c.obj.iv[16];
	local[0]= w;
irtsensoBLK2671:
	ctx->vsp=local; return(local[0]);}

/*:draw*/
static pointer irtsensoM2679bumper_model_draw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= fqv[12];
	local[2]= argv[2];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtsensoBLK2680:
	ctx->vsp=local; return(local[0]);}

/*:draw-sensor*/
static pointer irtsensoM2681bumper_model_draw_sensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[13];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= argv[0]->c.obj.iv[16];
	local[1]= makeint((eusinteger_t)1L);
	ctx->vsp=local+2;
	w=(pointer)NUMEQUAL(ctx,2,local+0); /*=*/
	if (w==NIL) goto irtsensoIF2683;
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= fqv[16];
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
	goto irtsensoIF2684;
irtsensoIF2683:
	local[0]= argv[0];
	local[1]= fqv[15];
	local[2]= argv[0];
	local[3]= fqv[14];
	ctx->vsp=local+4;
	w=(pointer)GETPROP(ctx,2,local+2); /*get*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	local[0]= w;
irtsensoIF2684:
	local[0]= argv[2];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[3])(ctx,2,local+0,&ftab[3],fqv[17]); /*gl::draw-glbody*/
	local[0]= argv[0];
	local[1]= argv[0];
	local[2]= fqv[14];
	ctx->vsp=local+3;
	w=(pointer)GETPROP(ctx,2,local+1); /*get*/
	local[1]= w;
	local[2]= fqv[13];
	ctx->vsp=local+3;
	w=(pointer)PUTPROP(ctx,3,local+0); /*putprop*/
	local[0]= w;
irtsensoBLK2682:
	ctx->vsp=local; return(local[0]);}

/*closure or cleaner*/
static pointer irtsensoCLO2678(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=1) maerror();
	local[0]= env->c.clo.env1[0];
	local[1]= argv[0];
	ctx->vsp=local+2;
	w=(*ftab[4])(ctx,2,local+0,&ftab[4],fqv[18]); /*collision-distance*/
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	env->c.clo.env2[0] = (w)->c.cons.car;
	local[0]= env->c.clo.env2[0];
	local[1]= env->c.clo.env1[0]->c.obj.iv[18];
	ctx->vsp=local+2;
	w=(pointer)LESSP(ctx,2,local+0); /*<*/
	local[0]= w;
	ctx->vsp=local; return(local[0]);}

/*:init*/
static pointer irtsensoM2685camera_model_init(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
irtsensoRST2687:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-3);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[19], &argv[3], n-3, local+1, 1);
	if (n & (1<<0)) goto irtsensoKEY2688;
	local[1] = makeint((eusinteger_t)320L);
irtsensoKEY2688:
	if (n & (1<<1)) goto irtsensoKEY2689;
	local[2] = makeint((eusinteger_t)240L);
irtsensoKEY2689:
	if (n & (1<<2)) goto irtsensoKEY2690;
	local[3] = fqv[20];
irtsensoKEY2690:
	if (n & (1<<3)) goto irtsensoKEY2691;
	local[4] = makeflt(1.0000000000000000000000e+02);
irtsensoKEY2691:
	if (n & (1<<4)) goto irtsensoKEY2692;
	local[5] = makeflt(1.0000000000000000000000e+02);
irtsensoKEY2692:
	if (n & (1<<5)) goto irtsensoKEY2693;
	local[6] = makeflt(1.0000000000000000000000e+04);
irtsensoKEY2693:
	local[7]= (pointer)get_sym_func(fqv[8]);
	local[8]= argv[0];
	local[9]= *(ovafptr(argv[1],fqv[9]));
	local[10]= fqv[10];
	local[11]= argv[2];
	local[12]= local[0];
	ctx->vsp=local+13;
	w=(pointer)APPLY(ctx,6,local+7); /*apply*/
	argv[0]->c.obj.iv[20] = local[1];
	argv[0]->c.obj.iv[21] = local[2];
	local[7]= loadglobal(fqv[21]);
	ctx->vsp=local+8;
	w=(pointer)INSTANTIATE(ctx,1,local+7); /*instantiate*/
	local[7]= w;
	local[8]= (pointer)get_sym_func(fqv[22]);
	local[9]= local[7];
	local[10]= fqv[10];
	local[11]= fqv[23];
	local[12]= argv[0];
	local[13]= fqv[24];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,2,local+12); /*send*/
	local[12]= w;
	local[13]= fqv[25];
	local[14]= argv[0];
	local[15]= fqv[26];
	local[16]= argv[0];
	local[17]= fqv[27];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,2,local+16); /*send*/
	local[16]= w;
	local[17]= makeint((eusinteger_t)2L);
	ctx->vsp=local+18;
	w=(*ftab[5])(ctx,2,local+16,&ftab[5],fqv[28]); /*matrix-column*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)VMINUS(ctx,1,local+16); /*v-*/
	local[16]= w;
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	local[15]= fqv[29];
	local[16]= local[3];
	local[17]= fqv[30];
	local[18]= local[4];
	local[19]= fqv[31];
	local[20]= local[5];
	local[21]= fqv[32];
	local[22]= local[6];
	local[23]= fqv[33];
	local[24]= makeflt(1.0000000000000000000000e+00);
	local[25]= local[0];
	ctx->vsp=local+26;
	w=(pointer)APPLY(ctx,18,local+8); /*apply*/
	w = local[7];
	argv[0]->c.obj.iv[18] = w;
	local[7]= argv[0]->c.obj.iv[18];
	local[8]= fqv[33];
	local[9]= local[4];
	local[10]= local[1];
	local[11]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+12;
	w=(pointer)TIMES(ctx,3,local+9); /***/
	local[9]= w;
	local[10]= local[4];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[4];
	local[11]= local[2];
	local[12]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+13;
	w=(pointer)TIMES(ctx,3,local+10); /***/
	local[10]= w;
	local[11]= local[4];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,4,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[34];
	local[9]= argv[0]->c.obj.iv[18];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= argv[0];
	local[8]= fqv[35];
	local[9]= makeint((eusinteger_t)4L);
	local[10]= makeint((eusinteger_t)4L);
	local[11]= local[4];
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[1];
	local[14]= makeint((eusinteger_t)2L);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)MKFLTVEC(ctx,4,local+11); /*float-vector*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= local[4];
	local[14]= local[2];
	local[15]= makeint((eusinteger_t)2L);
	ctx->vsp=local+16;
	w=(pointer)QUOTIENT(ctx,2,local+14); /*/*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,4,local+12); /*float-vector*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)1L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,4,local+13); /*float-vector*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)1L);
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,4,local+14); /*float-vector*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)LIST(ctx,4,local+11); /*list*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[6])(ctx,3,local+9,&ftab[6],fqv[36]); /*make-matrix*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	w = argv[0];
	local[0]= w;
irtsensoBLK2686:
	ctx->vsp=local; return(local[0]);}

/*:create-viewer*/
static pointer irtsensoM2694camera_model_create_viewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	if (n>=3) { local[0]=(argv[2]); goto irtsensoENT2697;}
	local[0]= NIL;
irtsensoENT2697:
irtsensoENT2696:
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[37], &argv[3], n-3, local+1, 0);
	if (n & (1<<0)) goto irtsensoKEY2698;
	local[1] = NIL;
irtsensoKEY2698:
	local[2]= fqv[38];
	ctx->vsp=local+3;
	w=(pointer)BOUNDP(ctx,1,local+2); /*boundp*/
	if (w!=NIL) goto irtsensoIF2699;
	ctx->vsp=local+2;
	w=(*ftab[7])(ctx,0,local+2,&ftab[7],fqv[39]); /*make-irtviewer*/
	local[2]= w;
	goto irtsensoIF2700;
irtsensoIF2699:
	local[2]= NIL;
irtsensoIF2700:
	if (local[0]!=NIL) goto irtsensoIF2701;
	local[2]= fqv[40];
	local[3]= argv[0]->c.obj.iv[20];
	local[4]= fqv[41];
	local[5]= argv[0]->c.obj.iv[21];
	local[6]= fqv[42];
	local[7]= argv[0];
	local[8]= fqv[42];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,2,local+7); /*send*/
	local[7]= w;
	local[8]= fqv[43];
	if (local[1]==NIL) goto irtsensoIF2703;
	local[9]= loadglobal(fqv[44]);
	goto irtsensoIF2704;
irtsensoIF2703:
	local[9]= loadglobal(fqv[45]);
irtsensoIF2704:
	ctx->vsp=local+10;
	w=(pointer)INSTANTIATE(ctx,1,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= fqv[46];
	local[12]= fqv[47];
	local[13]= loadglobal(fqv[38]);
	local[14]= fqv[48];
	local[15]= fqv[43];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= *(ovafptr(w,fqv[49]));
	local[14]= fqv[50];
	local[15]= NIL;
	local[16]= fqv[51];
	local[17]= argv[0];
	local[18]= fqv[6];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)XFORMAT(ctx,3,local+15); /*format*/
	local[15]= w;
	local[16]= fqv[52];
	local[17]= argv[0]->c.obj.iv[20];
	local[18]= fqv[53];
	local[19]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,10,local+10); /*send*/
	w = local[9];
	local[9]= w;
	local[10]= fqv[50];
	local[11]= NIL;
	local[12]= fqv[54];
	local[13]= argv[0];
	local[14]= fqv[6];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)XFORMAT(ctx,3,local+11); /*format*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[8])(ctx,10,local+2,&ftab[8],fqv[55]); /*view*/
	local[0] = w;
	local[2]= local[0];
	local[3]= fqv[43];
	local[4]= fqv[56];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[2]= makeflt(9.9999999999999977795540e-02);
	local[3]= makeflt(9.9999999999999977795540e-02);
	local[4]= makeflt(9.9999999999999977795540e-02);
	local[5]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,4,local+2); /*float-vector*/
	local[2]= w;
	local[3]= makeflt(1.0000000000000000000000e+00);
	local[4]= makeflt(1.0000000000000000000000e+00);
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+7;
	w=(pointer)MKFLTVEC(ctx,4,local+3); /*float-vector*/
	local[3]= w;
	local[4]= makeflt(9.9999999999999977795540e-02);
	local[5]= makeflt(9.9999999999999977795540e-02);
	local[6]= makeflt(9.9999999999999977795540e-02);
	local[7]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+8;
	w=(pointer)MKFLTVEC(ctx,4,local+4); /*float-vector*/
	local[4]= w;
	local[5]= makeflt(1.0000000000000000000000e+00);
	local[6]= makeflt(6.9999999999999973354647e-01);
	local[7]= makeflt(3.9999999999999991118216e-01);
	local[8]= makeflt(2.5000000000000000000000e-01);
	local[9]= NIL;
	local[10]= NIL;
	local[11]= NIL;
	local[12]= NIL;
	local[13]= loadglobal(fqv[57]);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,1,local+13); /*instantiate*/
	local[13]= w;
	local[14]= local[13];
	local[15]= fqv[46];
	local[16]= makeint((eusinteger_t)0L);
	local[17]= fqv[58];
	local[18]= local[5];
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= fqv[59];
	local[20]= local[5];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	local[21]= fqv[60];
	local[22]= local[5];
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[61];
	local[24]= makeflt(4.0000000000000000000000e+03);
	local[25]= makeflt(3.0000000000000000000000e+03);
	local[26]= makeflt(0.0000000000000000000000e+00);
	local[27]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+28;
	w=(pointer)MKFLTVEC(ctx,4,local+24); /*float-vector*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,11,local+14); /*send*/
	w = local[13];
	local[9] = w;
	local[13]= loadglobal(fqv[57]);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,1,local+13); /*instantiate*/
	local[13]= w;
	local[14]= local[13];
	local[15]= fqv[46];
	local[16]= makeint((eusinteger_t)1L);
	local[17]= fqv[58];
	local[18]= local[6];
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= fqv[59];
	local[20]= local[6];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	local[21]= fqv[60];
	local[22]= local[6];
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[61];
	local[24]= makeflt(-4.0000000000000000000000e+03);
	local[25]= makeflt(-2.0000000000000000000000e+03);
	local[26]= makeflt(-2.0000000000000000000000e+03);
	local[27]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+28;
	w=(pointer)MKFLTVEC(ctx,4,local+24); /*float-vector*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,11,local+14); /*send*/
	w = local[13];
	local[10] = w;
	local[13]= loadglobal(fqv[57]);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,1,local+13); /*instantiate*/
	local[13]= w;
	local[14]= local[13];
	local[15]= fqv[46];
	local[16]= makeint((eusinteger_t)2L);
	local[17]= fqv[58];
	local[18]= local[7];
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= fqv[59];
	local[20]= local[7];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	local[21]= fqv[60];
	local[22]= local[7];
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[61];
	local[24]= makeflt(-2.0000000000000000000000e+03);
	local[25]= makeflt(-2.0000000000000000000000e+03);
	local[26]= makeflt(2.5000000000000000000000e+03);
	local[27]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+28;
	w=(pointer)MKFLTVEC(ctx,4,local+24); /*float-vector*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,11,local+14); /*send*/
	w = local[13];
	local[11] = w;
	local[13]= loadglobal(fqv[57]);
	ctx->vsp=local+14;
	w=(pointer)INSTANTIATE(ctx,1,local+13); /*instantiate*/
	local[13]= w;
	local[14]= local[13];
	local[15]= fqv[46];
	local[16]= makeint((eusinteger_t)3L);
	local[17]= fqv[58];
	local[18]= local[8];
	local[19]= local[2];
	ctx->vsp=local+20;
	w=(pointer)SCALEVEC(ctx,2,local+18); /*scale*/
	local[18]= w;
	local[19]= fqv[59];
	local[20]= local[8];
	local[21]= local[3];
	ctx->vsp=local+22;
	w=(pointer)SCALEVEC(ctx,2,local+20); /*scale*/
	local[20]= w;
	local[21]= fqv[60];
	local[22]= local[8];
	local[23]= local[4];
	ctx->vsp=local+24;
	w=(pointer)SCALEVEC(ctx,2,local+22); /*scale*/
	local[22]= w;
	local[23]= fqv[61];
	local[24]= makeflt(0.0000000000000000000000e+00);
	local[25]= makeflt(0.0000000000000000000000e+00);
	local[26]= makeflt(0.0000000000000000000000e+00);
	local[27]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+28;
	w=(pointer)MKFLTVEC(ctx,4,local+24); /*float-vector*/
	local[24]= w;
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,11,local+14); /*send*/
	w = local[13];
	local[12] = w;
	local[13]= local[9];
	local[14]= fqv[62];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= local[10];
	local[14]= fqv[62];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= local[11];
	local[14]= fqv[62];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= local[12];
	local[14]= fqv[62];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[2]= w;
	goto irtsensoIF2702;
irtsensoIF2701:
	local[2]= NIL;
irtsensoIF2702:
	argv[0]->c.obj.iv[19] = local[0];
	w = argv[0]->c.obj.iv[19];
	local[0]= w;
irtsensoBLK2695:
	ctx->vsp=local; return(local[0]);}

/*:width*/
static pointer irtsensoM2705camera_model_width(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[20];
	local[0]= w;
irtsensoBLK2706:
	ctx->vsp=local; return(local[0]);}

/*:height*/
static pointer irtsensoM2707camera_model_height(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	w = argv[0]->c.obj.iv[21];
	local[0]= w;
irtsensoBLK2708:
	ctx->vsp=local; return(local[0]);}

/*:viewing*/
static pointer irtsensoM2709camera_model_viewing(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtsensoRST2711:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[18];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,2,local+1,&ftab[9],fqv[63]); /*forward-message-to*/
	local[0]= w;
irtsensoBLK2710:
	ctx->vsp=local; return(local[0]);}

/*:image-viewer*/
static pointer irtsensoM2712camera_model_image_viewer(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtsensoRST2714:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	local[1]= argv[0]->c.obj.iv[19];
	local[2]= local[0];
	ctx->vsp=local+3;
	w=(*ftab[9])(ctx,2,local+1,&ftab[9],fqv[63]); /*forward-message-to*/
	local[0]= w;
irtsensoBLK2713:
	ctx->vsp=local; return(local[0]);}

/*:fovy*/
static pointer irtsensoM2715camera_model_fovy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[18];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= makeint((eusinteger_t)2L);
	local[2]= argv[0]->c.obj.iv[20];
	local[3]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+4;
	w=(pointer)QUOTIENT(ctx,2,local+2); /*/*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	ctx->vsp=local+4;
	w=(*ftab[10])(ctx,2,local+2,&ftab[10],fqv[65]); /*atan2*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)TIMES(ctx,2,local+1); /***/
	local[0]= w;
irtsensoBLK2716:
	ctx->vsp=local; return(local[0]);}

/*:cx*/
static pointer irtsensoM2717camera_model_cx(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[18];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[0]= w;
irtsensoBLK2718:
	ctx->vsp=local; return(local[0]);}

/*:cy*/
static pointer irtsensoM2719camera_model_cy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[18];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[0]= w;
irtsensoBLK2720:
	ctx->vsp=local; return(local[0]);}

/*:fx*/
static pointer irtsensoM2721camera_model_fx(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[18];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)0L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[0]= w;
irtsensoBLK2722:
	ctx->vsp=local; return(local[0]);}

/*:fy*/
static pointer irtsensoM2723camera_model_fy(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=2) maerror();
	local[0]= argv[0]->c.obj.iv[18];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)1L);
	local[3]= makeint((eusinteger_t)1L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[0]= w;
irtsensoBLK2724:
	ctx->vsp=local; return(local[0]);}

/*:screen-point*/
static pointer irtsensoM2725camera_model_screen_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[0]->c.obj.iv[18];
	local[3]= fqv[66];
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= fqv[67];
	local[6]= argv[2];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,3,local+4); /*send*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,3,local+2); /*send*/
	local[0] = w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,2,local+2); /*aref*/
	local[1] = w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,2,local+4); /*aref*/
	local[4]= w;
	local[5]= local[1];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(pointer)ASET(ctx,3,local+2); /*aset*/
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)0L);
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)SUBSEQ(ctx,3,local+2); /*subseq*/
	ctx->vsp=local+2;
	local[0]=w;
	goto irtsensoBLK2726;
	w = local[2];
	local[0]= w;
irtsensoBLK2726:
	ctx->vsp=local; return(local[0]);}

/*:3d-point*/
static pointer irtsensoM2727camera_model_3d_point(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=5) maerror();
	local[0]= argv[0]->c.obj.iv[18];
	local[1]= fqv[64];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	local[1]= local[0];
	local[2]= makeint((eusinteger_t)0L);
	local[3]= makeint((eusinteger_t)2L);
	ctx->vsp=local+4;
	w=(pointer)AREF(ctx,3,local+1); /*aref*/
	local[1]= w;
	local[2]= local[0];
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)2L);
	ctx->vsp=local+5;
	w=(pointer)AREF(ctx,3,local+2); /*aref*/
	local[2]= w;
	local[3]= local[0];
	local[4]= makeint((eusinteger_t)0L);
	local[5]= makeint((eusinteger_t)0L);
	ctx->vsp=local+6;
	w=(pointer)AREF(ctx,3,local+3); /*aref*/
	local[3]= w;
	local[4]= local[0];
	local[5]= makeint((eusinteger_t)0L);
	local[6]= makeint((eusinteger_t)3L);
	ctx->vsp=local+7;
	w=(pointer)AREF(ctx,3,local+4); /*aref*/
	local[4]= w;
	local[5]= local[3];
	ctx->vsp=local+6;
	w=(pointer)QUOTIENT(ctx,2,local+4); /*/*/
	local[4]= w;
	local[5]= makeint((eusinteger_t)4L);
	local[6]= makeint((eusinteger_t)4L);
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)0L);
	local[10]= local[1];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,4,local+7); /*list*/
	local[7]= w;
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= local[2];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,1,local+11); /*-*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(pointer)LIST(ctx,4,local+8); /*list*/
	local[8]= w;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)LIST(ctx,4,local+9); /*list*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeflt(-1.0000000000000000000000e+00);
	local[13]= local[4];
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)LIST(ctx,4,local+10); /*list*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)LIST(ctx,4,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(*ftab[6])(ctx,3,local+5,&ftab[6],fqv[36]); /*make-matrix*/
	local[5]= w;
	local[6]= NIL;
	local[7]= NIL;
	local[8]= local[5];
	local[9]= argv[2];
	local[10]= argv[3];
	local[11]= argv[4];
	local[12]= makeint((eusinteger_t)1L);
	ctx->vsp=local+13;
	w=(pointer)MKFLTVEC(ctx,4,local+9); /*float-vector*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)TRANSFORM(ctx,2,local+8); /*transform*/
	local[6] = w;
	local[8]= local[6];
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)ELT(ctx,2,local+8); /*elt*/
	local[7] = w;
	local[8]= makeflt(1.0000000000000000000000e+00);
	local[9]= local[7];
	ctx->vsp=local+10;
	w=(pointer)QUOTIENT(ctx,2,local+8); /*/*/
	local[8]= w;
	local[9]= local[6];
	local[10]= makeint((eusinteger_t)0L);
	local[11]= makeint((eusinteger_t)3L);
	ctx->vsp=local+12;
	w=(pointer)SUBSEQ(ctx,3,local+9); /*subseq*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)SCALEVEC(ctx,2,local+8); /*scale*/
	local[0]= w;
irtsensoBLK2728:
	ctx->vsp=local; return(local[0]);}

/*:ray*/
static pointer irtsensoM2729camera_model_ray(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= NIL;
	local[3]= NIL;
	local[4]= argv[0]->c.obj.iv[18];
	local[5]= fqv[64];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= local[4];
	local[6]= makeint((eusinteger_t)0L);
	local[7]= makeint((eusinteger_t)2L);
	ctx->vsp=local+8;
	w=(pointer)AREF(ctx,3,local+5); /*aref*/
	local[5]= w;
	local[6]= local[4];
	local[7]= makeint((eusinteger_t)1L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= local[4];
	local[8]= makeint((eusinteger_t)0L);
	local[9]= makeint((eusinteger_t)3L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[4];
	local[9]= makeint((eusinteger_t)1L);
	local[10]= makeint((eusinteger_t)3L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[18];
	local[10]= fqv[30];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= argv[0]->c.obj.iv[18];
	local[11]= fqv[33];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= argv[2];
	local[12]= local[5];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[0] = w;
	local[11]= argv[3];
	local[12]= local[6];
	ctx->vsp=local+13;
	w=(pointer)MINUS(ctx,2,local+11); /*-*/
	local[1] = w;
	local[11]= local[0];
	local[12]= argv[0]->c.obj.iv[20];
	local[13]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[2] = w;
	local[11]= local[1];
	local[12]= argv[0]->c.obj.iv[21];
	local[13]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[3] = w;
	local[11]= argv[0];
	local[12]= fqv[68];
	local[13]= local[10];
	local[14]= makeint((eusinteger_t)0L);
	ctx->vsp=local+15;
	w=(pointer)ELT(ctx,2,local+13); /*elt*/
	local[13]= w;
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,2,local+13); /***/
	local[13]= w;
	local[14]= local[10];
	local[15]= makeint((eusinteger_t)1L);
	ctx->vsp=local+16;
	w=(pointer)ELT(ctx,2,local+14); /*elt*/
	local[14]= w;
	local[15]= local[3];
	ctx->vsp=local+16;
	w=(pointer)TIMES(ctx,2,local+14); /***/
	local[14]= w;
	local[15]= local[9];
	ctx->vsp=local+16;
	w=(pointer)MKFLTVEC(ctx,3,local+13); /*float-vector*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	ctx->vsp=local+12;
	w=(*ftab[11])(ctx,1,local+11,&ftab[11],fqv[69]); /*normalize-vector*/
	local[0]= w;
irtsensoBLK2730:
	ctx->vsp=local; return(local[0]);}

/*:draw-on*/
static pointer irtsensoM2731camera_model_draw_on(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
irtsensoRST2733:
	ctx->vsp=local+0;
	local[0]= minilist(ctx,&argv[n],n-2);
	ctx->vsp=local+1;
	n=parsekeyparams(fqv[70], &argv[2], n-2, local+1, 1);
	if (n & (1<<0)) goto irtsensoKEY2734;
	local[1] = loadglobal(fqv[71]);
irtsensoKEY2734:
	local[2]= (pointer)get_sym_func(fqv[22]);
	local[3]= argv[0];
	local[4]= fqv[12];
	local[5]= local[1];
	local[6]= local[0];
	ctx->vsp=local+7;
	w=(pointer)APPLY(ctx,5,local+2); /*apply*/
	local[0]= w;
irtsensoBLK2732:
	ctx->vsp=local; return(local[0]);}

/*:draw-sensor*/
static pointer irtsensoM2735camera_model_draw_sensor(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[72], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtsensoKEY2737;
	local[0] = NIL;
irtsensoKEY2737:
	if (n & (1<<1)) goto irtsensoKEY2738;
	local[1] = makeint((eusinteger_t)1L);
irtsensoKEY2738:
	if (n & (1<<2)) goto irtsensoKEY2739;
	local[3]= makeint((eusinteger_t)1L);
	local[4]= makeint((eusinteger_t)1L);
	local[5]= makeint((eusinteger_t)1L);
	ctx->vsp=local+6;
	w=(pointer)MKFLTVEC(ctx,3,local+3); /*float-vector*/
	local[2] = w;
irtsensoKEY2739:
	local[3]= argv[0];
	local[4]= fqv[32];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= argv[0];
	local[5]= fqv[31];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[30];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[2];
	local[7]= fqv[43];
	local[8]= fqv[73];
	ctx->vsp=local+9;
	w=(pointer)SEND(ctx,3,local+6); /*send*/
	local[6]= w;
	local[7]= argv[2];
	local[8]= fqv[43];
	local[9]= fqv[74];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,3,local+7); /*send*/
	local[7]= w;
	local[8]= argv[0];
	local[9]= fqv[75];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= local[4];
	local[10]= local[5];
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	local[10]= local[3];
	local[11]= local[5];
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	local[11]= argv[0];
	local[12]= fqv[33];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,2,local+11); /*send*/
	local[11]= w;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[12]= (w)->c.cons.car;
	w=local[11];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	w=(w)->c.cons.cdr;
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[13]= (w)->c.cons.car;
	local[14]= argv[2];
	local[15]= fqv[43];
	local[16]= fqv[73];
	local[17]= local[1];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= argv[2];
	local[15]= fqv[43];
	local[16]= fqv[74];
	local[17]= local[2];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+15;
	w=(*ftab[12])(ctx,1,local+14,&ftab[12],fqv[76]); /*gl:gldisable*/
	local[14]= argv[2];
	local[15]= fqv[43];
	local[16]= fqv[77];
	local[17]= argv[0];
	local[18]= fqv[75];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	local[18]= argv[0];
	local[19]= fqv[75];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,2,local+18); /*send*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)-200L);
	local[20]= argv[0];
	local[21]= fqv[78];
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,2,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SCALEVEC(ctx,2,local+19); /*scale*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(pointer)VPLUS(ctx,2,local+18); /*v+*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,5,local+14); /*send*/
	local[14]= NIL;
	local[15]= local[12];
	w = local[13];
	ctx->vsp=local+16;
	local[15]= cons(ctx,local[15],w);
	local[16]= local[12];
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,1,local+17); /*-*/
	ctx->vsp=local+17;
	local[16]= cons(ctx,local[16],w);
	local[17]= local[12];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,1,local+17); /*-*/
	local[17]= w;
	w = local[13];
	ctx->vsp=local+18;
	local[17]= cons(ctx,local[17],w);
	local[18]= local[12];
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,1,local+18); /*-*/
	local[18]= w;
	local[19]= local[13];
	ctx->vsp=local+20;
	w=(pointer)MINUS(ctx,1,local+19); /*-*/
	ctx->vsp=local+19;
	local[18]= cons(ctx,local[18],w);
	ctx->vsp=local+19;
	w=(pointer)LIST(ctx,4,local+15); /*list*/
	local[15]= w;
irtsensoWHL2740:
	if (local[15]==NIL) goto irtsensoWHX2741;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[16]= (w)->c.cons.car;
	w=local[15];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[15] = (w)->c.cons.cdr;
	w = local[16];
	local[14] = w;
	local[16]= argv[2];
	local[17]= fqv[43];
	local[18]= fqv[77];
	local[19]= argv[0];
	local[20]= fqv[26];
	local[21]= local[10];
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[22]= (w)->c.cons.car;
	ctx->vsp=local+23;
	w=(pointer)TIMES(ctx,2,local+21); /***/
	local[21]= w;
	local[22]= local[10];
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.cdr;
	ctx->vsp=local+24;
	w=(pointer)TIMES(ctx,2,local+22); /***/
	local[22]= w;
	local[23]= local[3];
	ctx->vsp=local+24;
	w=(pointer)MKFLTVEC(ctx,3,local+21); /*float-vector*/
	local[21]= w;
	ctx->vsp=local+22;
	w=(pointer)SEND(ctx,3,local+19); /*send*/
	local[19]= w;
	local[20]= argv[0];
	local[21]= fqv[26];
	local[22]= local[9];
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[23]= (w)->c.cons.car;
	ctx->vsp=local+24;
	w=(pointer)TIMES(ctx,2,local+22); /***/
	local[22]= w;
	local[23]= local[9];
	w=local[14];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[24]= (w)->c.cons.cdr;
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	local[24]= local[4];
	ctx->vsp=local+25;
	w=(pointer)MKFLTVEC(ctx,3,local+22); /*float-vector*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,3,local+20); /*send*/
	local[20]= w;
	ctx->vsp=local+21;
	w=(pointer)SEND(ctx,5,local+16); /*send*/
	goto irtsensoWHL2740;
irtsensoWHX2741:
	local[16]= NIL;
irtsensoBLK2742:
	w = NIL;
	local[14]= makeint((eusinteger_t)2929L);
	ctx->vsp=local+15;
	w=(*ftab[13])(ctx,1,local+14,&ftab[13],fqv[79]); /*gl:glenable*/
	local[14]= argv[2];
	local[15]= fqv[43];
	local[16]= fqv[73];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= argv[2];
	local[15]= fqv[43];
	local[16]= fqv[74];
	local[17]= local[7];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,4,local+14); /*send*/
	local[14]= argv[2];
	local[15]= argv[0];
	ctx->vsp=local+16;
	w=(*ftab[3])(ctx,2,local+14,&ftab[3],fqv[17]); /*gl::draw-glbody*/
	if (local[0]==NIL) goto irtsensoIF2743;
	local[14]= argv[2];
	local[15]= fqv[43];
	local[16]= fqv[80];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	goto irtsensoIF2744;
irtsensoIF2743:
	local[14]= NIL;
irtsensoIF2744:
	w = local[14];
	local[0]= w;
irtsensoBLK2736:
	ctx->vsp=local; return(local[0]);}

/*:draw-objects*/
static pointer irtsensoM2745camera_model_draw_objects(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=3) maerror();
	if (argv[0]->c.obj.iv[19]!=NIL) goto irtsensoIF2747;
	local[0]= argv[0];
	local[1]= fqv[81];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= w;
	goto irtsensoIF2748;
irtsensoIF2747:
	local[0]= NIL;
irtsensoIF2748:
	local[0]= argv[0];
	local[1]= fqv[82];
	local[2]= argv[0]->c.obj.iv[19];
	local[3]= argv[2];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,4,local+0); /*send*/
	local[0]= w;
irtsensoBLK2746:
	ctx->vsp=local; return(local[0]);}

/*:draw-objects-raw*/
static pointer irtsensoM2749camera_model_draw_objects_raw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= NIL;
	local[1]= NIL;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,1,local+2,&ftab[14],fqv[83]); /*x::draw-things*/
	local[2]= w;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= argv[0]->c.obj.iv[18];
	local[6]= fqv[64];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= local[5];
	local[7]= makeint((eusinteger_t)0L);
	local[8]= makeint((eusinteger_t)2L);
	ctx->vsp=local+9;
	w=(pointer)AREF(ctx,3,local+6); /*aref*/
	local[6]= w;
	local[7]= local[5];
	local[8]= makeint((eusinteger_t)1L);
	local[9]= makeint((eusinteger_t)2L);
	ctx->vsp=local+10;
	w=(pointer)AREF(ctx,3,local+7); /*aref*/
	local[7]= w;
	local[8]= local[5];
	local[9]= makeint((eusinteger_t)0L);
	local[10]= makeint((eusinteger_t)0L);
	ctx->vsp=local+11;
	w=(pointer)AREF(ctx,3,local+8); /*aref*/
	local[8]= w;
	local[9]= argv[2];
	local[10]= fqv[43];
	local[11]= fqv[56];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[0]->c.obj.iv[20];
	local[10]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+11;
	w=(pointer)GREATERP(ctx,2,local+9); /*>*/
	if (w==NIL) goto irtsensoIF2751;
	local[9]= makeint((eusinteger_t)0L);
	local[10]= argv[0]->c.obj.iv[20];
	local[11]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+12;
	w=(pointer)MINUS(ctx,2,local+10); /*-*/
	local[10]= w;
	local[11]= makeint((eusinteger_t)2L);
	ctx->vsp=local+12;
	w=(pointer)QUOTIENT(ctx,2,local+10); /*/*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,1,local+10); /*-*/
	local[10]= w;
	local[11]= argv[0]->c.obj.iv[20];
	local[12]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,4,local+9,&ftab[15],fqv[84]); /*gl:glviewport*/
	local[9]= w;
	goto irtsensoIF2752;
irtsensoIF2751:
	local[9]= argv[0]->c.obj.iv[21];
	local[10]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+11;
	w=(pointer)MINUS(ctx,2,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)2L);
	ctx->vsp=local+11;
	w=(pointer)QUOTIENT(ctx,2,local+9); /*/*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(pointer)MINUS(ctx,1,local+9); /*-*/
	local[9]= w;
	local[10]= makeint((eusinteger_t)0L);
	local[11]= argv[0]->c.obj.iv[21];
	local[12]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+13;
	w=(*ftab[15])(ctx,4,local+9,&ftab[15],fqv[84]); /*gl:glviewport*/
	local[9]= w;
irtsensoIF2752:
	local[9]= makeint((eusinteger_t)5889L);
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,1,local+9,&ftab[16],fqv[85]); /*gl:glmatrixmode*/
	ctx->vsp=local+9;
	w=(*ftab[17])(ctx,0,local+9,&ftab[17],fqv[86]); /*gl:glloadidentity*/
	local[9]= loadglobal(fqv[87]);
	local[10]= makeint((eusinteger_t)16L);
	ctx->vsp=local+11;
	w=(pointer)INSTANTIATE(ctx,2,local+9); /*instantiate*/
	local[9]= w;
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)0L);
	local[12]= makeflt(1.0000000000000000000000e+00);
	local[13]= argv[0];
	local[14]= fqv[88];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,2,local+13); /*send*/
	local[13]= w;
	local[14]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TAN(ctx,1,local+13); /*tan*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)5L);
	local[12]= local[9];
	local[13]= makeint((eusinteger_t)0L);
	ctx->vsp=local+14;
	w=(pointer)ELT(ctx,2,local+12); /*elt*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)8L);
	local[12]= makeint((eusinteger_t)2L);
	local[13]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+14;
	w=(pointer)SUB1(ctx,1,local+13); /*1-*/
	local[13]= w;
	local[14]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= local[6];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[20];
	local[14]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto irtsensoIF2753;
	local[13]= argv[0]->c.obj.iv[20];
	goto irtsensoIF2754;
irtsensoIF2753:
	local[13]= argv[0]->c.obj.iv[21];
irtsensoIF2754:
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)9L);
	local[12]= makeint((eusinteger_t)-2L);
	local[13]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+14;
	w=(pointer)SUB1(ctx,1,local+13); /*1-*/
	local[13]= w;
	local[14]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+15;
	w=(pointer)QUOTIENT(ctx,2,local+13); /*/*/
	local[13]= w;
	local[14]= local[7];
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)TIMES(ctx,2,local+12); /***/
	local[12]= w;
	local[13]= argv[0]->c.obj.iv[20];
	local[14]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+15;
	w=(pointer)GREATERP(ctx,2,local+13); /*>*/
	if (w==NIL) goto irtsensoIF2755;
	local[13]= argv[0]->c.obj.iv[20];
	goto irtsensoIF2756;
irtsensoIF2755:
	local[13]= argv[0]->c.obj.iv[21];
irtsensoIF2756:
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)10L);
	local[12]= argv[0];
	local[13]= fqv[42];
	local[14]= fqv[32];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[42];
	local[15]= fqv[31];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)PLUS(ctx,2,local+12); /*+*/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[42];
	local[15]= fqv[31];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[42];
	local[16]= fqv[32];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)14L);
	local[12]= makeint((eusinteger_t)2L);
	local[13]= argv[0];
	local[14]= fqv[42];
	local[15]= fqv[32];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[42];
	local[16]= fqv[31];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)TIMES(ctx,3,local+12); /***/
	local[12]= w;
	local[13]= argv[0];
	local[14]= fqv[42];
	local[15]= fqv[31];
	ctx->vsp=local+16;
	w=(pointer)SEND(ctx,3,local+13); /*send*/
	local[13]= w;
	local[14]= argv[0];
	local[15]= fqv[42];
	local[16]= fqv[32];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,3,local+14); /*send*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(pointer)MINUS(ctx,2,local+13); /*-*/
	local[13]= w;
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	local[11]= makeint((eusinteger_t)11L);
	local[12]= makeint((eusinteger_t)-1L);
	ctx->vsp=local+13;
	w=(pointer)SETELT(ctx,3,local+10); /*setelt*/
	local[10]= local[9];
	ctx->vsp=local+11;
	w=(*ftab[18])(ctx,1,local+10,&ftab[18],fqv[89]); /*gl:glmultmatrixd*/
	local[9]= argv[0];
	local[10]= fqv[24];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[3] = w;
	local[9]= local[3];
	local[10]= argv[0];
	local[11]= fqv[42];
	local[12]= fqv[78];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,3,local+10); /*send*/
	local[10]= w;
	ctx->vsp=local+11;
	w=(pointer)VMINUS(ctx,2,local+9); /*v-*/
	local[4] = w;
	local[9]= loadglobal(fqv[90]);
	local[10]= local[3];
	local[11]= local[4];
	local[12]= argv[0];
	local[13]= fqv[42];
	local[14]= fqv[29];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,3,local+12); /*send*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)VMINUS(ctx,1,local+12); /*v-*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)CONCATENATE(ctx,4,local+9); /*concatenate*/
	local[9]= w;
	ctx->vsp=local+10;
	w=(*ftab[19])(ctx,1,local+9,&ftab[19],fqv[91]); /*gl:glulookatfv*/
	local[9]= makeint((eusinteger_t)5888L);
	ctx->vsp=local+10;
	w=(*ftab[16])(ctx,1,local+9,&ftab[16],fqv[85]); /*gl:glmatrixmode*/
	local[9]= argv[2];
	local[10]= fqv[43];
	local[11]= fqv[92];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[9]= argv[2];
	local[10]= fqv[43];
	local[11]= fqv[74];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[1] = w;
	local[9]= argv[2];
	local[10]= fqv[43];
	local[11]= fqv[74];
	local[12]= local[1];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,4,local+9); /*send*/
	local[9]= makeint((eusinteger_t)2896L);
	ctx->vsp=local+10;
	w=(*ftab[13])(ctx,1,local+9,&ftab[13],fqv[79]); /*gl:glenable*/
	local[9]= NIL;
	local[10]= local[2];
irtsensoWHL2757:
	if (local[10]==NIL) goto irtsensoWHX2758;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[11]= (w)->c.cons.car;
	w=local[10];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[10] = (w)->c.cons.cdr;
	w = local[11];
	local[9] = w;
	local[11]= local[9];
	local[12]= fqv[93];
	ctx->vsp=local+13;
	w=(*ftab[20])(ctx,2,local+11,&ftab[20],fqv[94]); /*find-method*/
	if (w==NIL) goto irtsensoCON2761;
	local[11]= local[9];
	local[12]= fqv[93];
	local[13]= argv[2];
	ctx->vsp=local+14;
	w=(pointer)SEND(ctx,3,local+11); /*send*/
	local[11]= w;
	goto irtsensoCON2760;
irtsensoCON2761:
	local[11]= local[9];
	local[12]= loadglobal(fqv[95]);
	ctx->vsp=local+13;
	w=(pointer)DERIVEDP(ctx,2,local+11); /*derivedp*/
	if (w==NIL) goto irtsensoCON2762;
	local[11]= argv[2];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(*ftab[3])(ctx,2,local+11,&ftab[3],fqv[17]); /*gl::draw-glbody*/
	local[11]= w;
	goto irtsensoCON2760;
irtsensoCON2762:
	local[11]= local[9];
	local[12]= fqv[96];
	ctx->vsp=local+13;
	w=(*ftab[20])(ctx,2,local+11,&ftab[20],fqv[94]); /*find-method*/
	if (w==NIL) goto irtsensoCON2763;
	local[11]= local[9];
	local[12]= fqv[96];
	local[13]= fqv[48];
	local[14]= argv[2];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,4,local+11); /*send*/
	local[11]= w;
	goto irtsensoCON2760;
irtsensoCON2763:
	local[11]= fqv[97];
	local[12]= local[9];
	ctx->vsp=local+13;
	w=(*ftab[0])(ctx,2,local+11,&ftab[0],fqv[1]); /*warn*/
	local[11]= w;
	goto irtsensoCON2760;
irtsensoCON2764:
	local[11]= NIL;
irtsensoCON2760:
	goto irtsensoWHL2757;
irtsensoWHX2758:
	local[11]= NIL;
irtsensoBLK2759:
	w = NIL;
	local[9]= argv[2];
	local[10]= fqv[43];
	local[11]= fqv[80];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,3,local+9); /*send*/
	local[0]= w;
irtsensoBLK2750:
	ctx->vsp=local; return(local[0]);}

/*:get-image*/
static pointer irtsensoM2765camera_model_get_image(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<2) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[98], &argv[2], n-2, local+0, 0);
	if (n & (1<<0)) goto irtsensoKEY2767;
	local[0] = NIL;
irtsensoKEY2767:
	if (n & (1<<1)) goto irtsensoKEY2768;
	local[1] = NIL;
irtsensoKEY2768:
	local[2]= NIL;
	local[3]= NIL;
	local[4]= NIL;
	local[5]= NIL;
	if (local[0]==NIL) goto irtsensoIF2769;
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[6])(ctx,2,local+6,&ftab[6],fqv[36]); /*make-matrix*/
	local[2] = w;
	local[6]= local[2];
	goto irtsensoIF2770;
irtsensoIF2769:
	local[6]= NIL;
irtsensoIF2770:
	if (local[1]==NIL) goto irtsensoIF2771;
	local[6]= argv[0]->c.obj.iv[20];
	local[7]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+8;
	w=(pointer)TIMES(ctx,2,local+6); /***/
	local[6]= w;
	local[7]= makeint((eusinteger_t)3L);
	ctx->vsp=local+8;
	w=(*ftab[6])(ctx,2,local+6,&ftab[6],fqv[36]); /*make-matrix*/
	local[3] = w;
	local[6]= local[3];
	goto irtsensoIF2772;
irtsensoIF2771:
	local[6]= NIL;
irtsensoIF2772:
	local[6]= argv[0];
	local[7]= fqv[99];
	local[8]= argv[0]->c.obj.iv[19];
	local[9]= fqv[100];
	local[10]= local[2];
	local[11]= fqv[101];
	local[12]= local[3];
	ctx->vsp=local+13;
	w=(pointer)SEND(ctx,7,local+6); /*send*/
	local[4] = w;
	if (local[0]==NIL) goto irtsensoCON2774;
	if (local[1]==NIL) goto irtsensoCON2774;
	local[6]= loadglobal(fqv[102]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[10];
	local[9]= fqv[53];
	local[10]= argv[0]->c.obj.iv[21];
	local[11]= fqv[52];
	local[12]= argv[0]->c.obj.iv[20];
	local[13]= fqv[100];
	local[14]= local[2];
	local[15]= fqv[101];
	local[16]= local[3];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,10,local+7); /*send*/
	w = local[6];
	local[5] = w;
	local[6]= local[5];
	goto irtsensoCON2773;
irtsensoCON2774:
	if (local[0]==NIL) goto irtsensoCON2775;
	local[6]= loadglobal(fqv[102]);
	ctx->vsp=local+7;
	w=(pointer)INSTANTIATE(ctx,1,local+6); /*instantiate*/
	local[6]= w;
	local[7]= local[6];
	local[8]= fqv[10];
	local[9]= fqv[53];
	local[10]= argv[0]->c.obj.iv[21];
	local[11]= fqv[52];
	local[12]= argv[0]->c.obj.iv[20];
	local[13]= fqv[100];
	local[14]= local[2];
	ctx->vsp=local+15;
	w=(pointer)SEND(ctx,8,local+7); /*send*/
	w = local[6];
	local[5] = w;
	local[6]= local[5];
	goto irtsensoCON2773;
irtsensoCON2775:
	local[6]= NIL;
irtsensoCON2773:
	if (local[0]==NIL) goto irtsensoIF2776;
	local[6]= local[4];
	w = local[5];
	ctx->vsp=local+7;
	local[6]= cons(ctx,local[6],w);
	goto irtsensoIF2777;
irtsensoIF2776:
	local[6]= local[4];
irtsensoIF2777:
	w = local[6];
	local[0]= w;
irtsensoBLK2766:
	ctx->vsp=local; return(local[0]);}

/*:get-image-raw*/
static pointer irtsensoM2778camera_model_get_image_raw(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<3) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[103], &argv[3], n-3, local+0, 0);
	if (n & (1<<0)) goto irtsensoKEY2780;
	local[0] = NIL;
irtsensoKEY2780:
	if (n & (1<<1)) goto irtsensoKEY2781;
	local[1] = NIL;
irtsensoKEY2781:
	local[2]= argv[2];
	local[3]= fqv[43];
	ctx->vsp=local+4;
	w=(pointer)SEND(ctx,2,local+2); /*send*/
	local[2]= w;
	local[3]= local[2];
	local[4]= fqv[52];
	ctx->vsp=local+5;
	w=(pointer)SEND(ctx,2,local+3); /*send*/
	local[3]= w;
	local[4]= local[2];
	local[5]= fqv[53];
	ctx->vsp=local+6;
	w=(pointer)SEND(ctx,2,local+4); /*send*/
	local[4]= w;
	local[5]= argv[0];
	local[6]= fqv[104];
	ctx->vsp=local+7;
	w=(pointer)SEND(ctx,2,local+5); /*send*/
	local[5]= w;
	local[6]= argv[0];
	local[7]= fqv[105];
	ctx->vsp=local+8;
	w=(pointer)SEND(ctx,2,local+6); /*send*/
	local[6]= w;
	local[7]= local[3];
	local[8]= local[4];
	ctx->vsp=local+9;
	w=(pointer)TIMES(ctx,2,local+7); /***/
	local[7]= w;
	local[8]= argv[0]->c.obj.iv[18];
	local[9]= fqv[88];
	ctx->vsp=local+10;
	w=(pointer)SEND(ctx,2,local+8); /*send*/
	local[8]= w;
	local[9]= argv[0]->c.obj.iv[18];
	local[10]= fqv[31];
	ctx->vsp=local+11;
	w=(pointer)SEND(ctx,2,local+9); /*send*/
	local[9]= w;
	local[10]= argv[0]->c.obj.iv[18];
	local[11]= fqv[32];
	ctx->vsp=local+12;
	w=(pointer)SEND(ctx,2,local+10); /*send*/
	local[10]= w;
	local[11]= local[4];
	local[12]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= local[8];
	local[13]= makeflt(2.0000000000000000000000e+00);
	ctx->vsp=local+14;
	w=(pointer)QUOTIENT(ctx,2,local+12); /*/*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)TAN(ctx,1,local+12); /*tan*/
	local[12]= w;
	ctx->vsp=local+13;
	w=(pointer)QUOTIENT(ctx,2,local+11); /*/*/
	local[11]= w;
	local[12]= makeint((eusinteger_t)0L);
	local[13]= makeint((eusinteger_t)0L);
	local[14]= makeint((eusinteger_t)0L);
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	ctx->vsp=local+17;
	w=(pointer)MKFLTVEC(ctx,3,local+14); /*float-vector*/
	local[14]= w;
	local[15]= makeint((eusinteger_t)0L);
	local[16]= makeint((eusinteger_t)0L);
	local[17]= makeint((eusinteger_t)0L);
	ctx->vsp=local+18;
	w=(pointer)MKFLTVEC(ctx,3,local+15); /*float-vector*/
	local[15]= w;
	local[16]= NIL;
	local[17]= NIL;
	local[18]= NIL;
	local[19]= NIL;
	local[20]= NIL;
	if (local[0]==NIL) goto irtsensoIF2782;
	local[21]= local[3];
	local[22]= argv[0]->c.obj.iv[20];
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto irtsensoAND2786;
	local[21]= local[4];
	local[22]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+23;
	w=(pointer)NUMEQUAL(ctx,2,local+21); /*=*/
	if (w==NIL) goto irtsensoAND2786;
	goto irtsensoIF2784;
irtsensoAND2786:
	local[21]= fqv[106];
	local[22]= local[3];
	local[23]= argv[0]->c.obj.iv[20];
	local[24]= local[4];
	local[25]= argv[0]->c.obj.iv[21];
	ctx->vsp=local+26;
	w=(*ftab[0])(ctx,5,local+21,&ftab[0],fqv[1]); /*warn*/
	w = NIL;
	ctx->vsp=local+21;
	local[0]=w;
	goto irtsensoBLK2779;
	goto irtsensoIF2785;
irtsensoIF2784:
	local[21]= NIL;
irtsensoIF2785:
	local[21]= local[7];
	local[22]= fqv[107];
	local[23]= fqv[108];
	ctx->vsp=local+24;
	w=(*ftab[21])(ctx,3,local+21,&ftab[21],fqv[109]); /*make-array*/
	local[19] = w;
	local[16] = local[0]->c.obj.iv[1];
	local[21]= local[16];
	local[22]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(*ftab[22])(ctx,2,local+21,&ftab[22],fqv[110]); /*fill*/
	if (local[1]==NIL) goto irtsensoIF2787;
	local[18] = local[1]->c.obj.iv[1];
	local[21]= local[18];
	local[22]= makeflt(0.0000000000000000000000e+00);
	ctx->vsp=local+23;
	w=(*ftab[22])(ctx,2,local+21,&ftab[22],fqv[110]); /*fill*/
	local[21]= w;
	goto irtsensoIF2788;
irtsensoIF2787:
	local[21]= NIL;
irtsensoIF2788:
	goto irtsensoIF2783;
irtsensoIF2782:
	local[21]= NIL;
irtsensoIF2783:
	local[21]= local[2];
	local[22]= fqv[111];
	local[23]= fqv[112];
	local[24]= local[19];
	ctx->vsp=local+25;
	w=(pointer)SEND(ctx,4,local+21); /*send*/
	local[20] = w;
	if (local[0]==NIL) goto irtsensoIF2789;
	local[21]= local[20];
	local[22]= fqv[113];
	ctx->vsp=local+23;
	w=(pointer)SEND(ctx,2,local+21); /*send*/
	local[17] = w;
	local[21]= makeint((eusinteger_t)0L);
	local[22]= local[4];
irtsensoWHL2791:
	local[23]= local[21];
	w = local[22];
	if ((eusinteger_t)local[23] >= (eusinteger_t)w) goto irtsensoWHX2792;
	local[23]= makeint((eusinteger_t)0L);
	local[24]= local[3];
irtsensoWHL2794:
	local[25]= local[23];
	w = local[24];
	if ((eusinteger_t)local[25] >= (eusinteger_t)w) goto irtsensoWHX2795;
	local[25]= local[19];
	local[26]= local[13];
	ctx->vsp=local+27;
	w=(pointer)ELT(ctx,2,local+25); /*elt*/
	local[25]= w;
	local[26]= makeflt(1.0000000000000000000000e+00);
	ctx->vsp=local+27;
	w=(pointer)LESSP(ctx,2,local+25); /*<*/
	if (w==NIL) goto irtsensoIF2797;
	local[25]= local[10];
	local[26]= local[9];
	ctx->vsp=local+27;
	w=(pointer)TIMES(ctx,2,local+25); /***/
	local[25]= w;
	local[26]= local[19];
	local[27]= local[13];
	ctx->vsp=local+28;
	w=(pointer)ELT(ctx,2,local+26); /*elt*/
	local[26]= w;
	local[27]= local[10];
	local[28]= local[9];
	ctx->vsp=local+29;
	w=(pointer)MINUS(ctx,2,local+27); /*-*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,2,local+26); /***/
	local[26]= w;
	local[27]= local[10];
	ctx->vsp=local+28;
	w=(pointer)MINUS(ctx,2,local+26); /*-*/
	local[26]= w;
	ctx->vsp=local+27;
	w=(pointer)QUOTIENT(ctx,2,local+25); /*/*/
	local[25]= w;
	local[26]= makeint((eusinteger_t)3L);
	local[27]= local[4];
	local[28]= local[21];
	local[29]= makeint((eusinteger_t)1L);
	ctx->vsp=local+30;
	w=(pointer)MINUS(ctx,3,local+27); /*-*/
	local[27]= w;
	local[28]= local[3];
	ctx->vsp=local+29;
	w=(pointer)TIMES(ctx,2,local+27); /***/
	local[27]= w;
	local[28]= local[23];
	ctx->vsp=local+29;
	w=(pointer)PLUS(ctx,2,local+27); /*+*/
	local[27]= w;
	ctx->vsp=local+28;
	w=(pointer)TIMES(ctx,2,local+26); /***/
	local[12] = w;
	local[26]= local[14];
	local[27]= makeint((eusinteger_t)0L);
	local[28]= local[5];
	local[29]= local[23];
	ctx->vsp=local+30;
	w=(pointer)MINUS(ctx,2,local+28); /*-*/
	local[28]= w;
	local[29]= local[25];
	local[30]= local[11];
	ctx->vsp=local+31;
	w=(pointer)QUOTIENT(ctx,2,local+29); /*/*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)TIMES(ctx,2,local+28); /***/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SETELT(ctx,3,local+26); /*setelt*/
	local[26]= local[14];
	local[27]= makeint((eusinteger_t)1L);
	local[28]= local[6];
	local[29]= local[4];
	local[30]= local[21];
	local[31]= makeint((eusinteger_t)1L);
	ctx->vsp=local+32;
	w=(pointer)MINUS(ctx,3,local+29); /*-*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)MINUS(ctx,2,local+28); /*-*/
	local[28]= w;
	local[29]= local[25];
	local[30]= local[11];
	ctx->vsp=local+31;
	w=(pointer)QUOTIENT(ctx,2,local+29); /*/*/
	local[29]= w;
	ctx->vsp=local+30;
	w=(pointer)TIMES(ctx,2,local+28); /***/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SETELT(ctx,3,local+26); /*setelt*/
	local[26]= local[14];
	local[27]= makeint((eusinteger_t)2L);
	local[28]= local[25];
	ctx->vsp=local+29;
	w=(pointer)MINUS(ctx,1,local+28); /*-*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SETELT(ctx,3,local+26); /*setelt*/
	local[26]= local[16];
	local[27]= local[14];
	local[28]= local[12];
	ctx->vsp=local+29;
	w=(pointer)VECREPLACE(ctx,3,local+26); /*system::vector-replace*/
	if (local[1]==NIL) goto irtsensoIF2799;
	local[26]= local[15];
	local[27]= makeint((eusinteger_t)0L);
	local[28]= local[17];
	local[29]= local[12];
	local[30]= fqv[114];
	ctx->vsp=local+31;
	w=(pointer)PEEK(ctx,3,local+28); /*system:peek*/
	local[28]= w;
	local[29]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+30;
	w=(pointer)QUOTIENT(ctx,2,local+28); /*/*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SETELT(ctx,3,local+26); /*setelt*/
	local[26]= local[15];
	local[27]= makeint((eusinteger_t)1L);
	local[28]= local[17];
	local[29]= local[12];
	local[30]= makeint((eusinteger_t)1L);
	ctx->vsp=local+31;
	w=(pointer)PLUS(ctx,2,local+29); /*+*/
	local[29]= w;
	local[30]= fqv[114];
	ctx->vsp=local+31;
	w=(pointer)PEEK(ctx,3,local+28); /*system:peek*/
	local[28]= w;
	local[29]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+30;
	w=(pointer)QUOTIENT(ctx,2,local+28); /*/*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SETELT(ctx,3,local+26); /*setelt*/
	local[26]= local[15];
	local[27]= makeint((eusinteger_t)2L);
	local[28]= local[17];
	local[29]= local[12];
	local[30]= makeint((eusinteger_t)2L);
	ctx->vsp=local+31;
	w=(pointer)PLUS(ctx,2,local+29); /*+*/
	local[29]= w;
	local[30]= fqv[114];
	ctx->vsp=local+31;
	w=(pointer)PEEK(ctx,3,local+28); /*system:peek*/
	local[28]= w;
	local[29]= makeflt(2.5500000000000000000000e+02);
	ctx->vsp=local+30;
	w=(pointer)QUOTIENT(ctx,2,local+28); /*/*/
	local[28]= w;
	ctx->vsp=local+29;
	w=(pointer)SETELT(ctx,3,local+26); /*setelt*/
	local[26]= local[18];
	local[27]= local[15];
	local[28]= local[12];
	ctx->vsp=local+29;
	w=(pointer)VECREPLACE(ctx,3,local+26); /*system::vector-replace*/
	local[26]= w;
	goto irtsensoIF2800;
irtsensoIF2799:
	local[26]= NIL;
irtsensoIF2800:
	w = local[26];
	local[25]= w;
	goto irtsensoIF2798;
irtsensoIF2797:
	local[25]= NIL;
irtsensoIF2798:
	local[25]= local[13];
	local[26]= makeint((eusinteger_t)1L);
	ctx->vsp=local+27;
	w=(pointer)PLUS(ctx,2,local+25); /*+*/
	local[13] = w;
	local[25]= local[23];
	ctx->vsp=local+26;
	w=(pointer)ADD1(ctx,1,local+25); /*1+*/
	local[23] = w;
	goto irtsensoWHL2794;
irtsensoWHX2795:
	local[25]= NIL;
irtsensoBLK2796:
	w = NIL;
	local[23]= local[21];
	ctx->vsp=local+24;
	w=(pointer)ADD1(ctx,1,local+23); /*1+*/
	local[21] = w;
	goto irtsensoWHL2791;
irtsensoWHX2792:
	local[23]= NIL;
irtsensoBLK2793:
	w = NIL;
	local[21]= w;
	goto irtsensoIF2790;
irtsensoIF2789:
	local[21]= NIL;
irtsensoIF2790:
	w = local[20];
	local[0]= w;
irtsensoBLK2779:
	ctx->vsp=local; return(local[0]);}

/*:select-drawmode*/
static pointer irtsensoM2801camera_model_select_drawmode(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n!=4) maerror();
	local[0]= argv[0]->c.obj.iv[19];
	local[1]= fqv[43];
	ctx->vsp=local+2;
	w=(pointer)SEND(ctx,2,local+0); /*send*/
	local[0]= *(ovafptr(w,fqv[49]));
	local[1]= NIL;
	local[2]= argv[3];
	ctx->vsp=local+3;
	w=(*ftab[14])(ctx,1,local+2,&ftab[14],fqv[83]); /*x::draw-things*/
	local[2]= w;
irtsensoWHL2803:
	if (local[2]==NIL) goto irtsensoWHX2804;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[3]= (w)->c.cons.car;
	w=local[2];
	if (!iscons(w) && w!=NIL) error(E_NOLIST);
	local[2] = (w)->c.cons.cdr;
	w = local[3];
	local[1] = w;
	local[3]= local[1];
	local[4]= fqv[115];
	ctx->vsp=local+5;
	w=(pointer)GETPROP(ctx,2,local+3); /*get*/
	local[3]= w;
	local[4]= local[1];
	local[5]= fqv[116];
	ctx->vsp=local+6;
	w=(pointer)GETPROP(ctx,2,local+4); /*get*/
	local[4]= w;
	ctx->vsp=local+5;
	w=(*ftab[23])(ctx,1,local+4,&ftab[23],fqv[117]); /*gl::delete-displaylist-id*/
	local[4]= local[1];
	local[5]= NIL;
	local[6]= fqv[116];
	ctx->vsp=local+7;
	w=(pointer)PUTPROP(ctx,3,local+4); /*putprop*/
	local[4]= argv[2];
	local[5]= local[4];
	if (fqv[118]!=local[5]) goto irtsensoIF2806;
	local[5]= local[0];
	local[6]= local[3];
	ctx->vsp=local+7;
	w=(pointer)ASSQ(ctx,2,local+5); /*assq*/
	if (w!=NIL) goto irtsensoIF2808;
	local[5]= local[1];
	local[6]= local[3];
	local[7]= local[0];
	w = T;
	ctx->vsp=local+8;
	local[7]= cons(ctx,local[7],w);
	ctx->vsp=local+8;
	w=(pointer)LIST(ctx,1,local+7); /*list*/
	local[7]= w;
	ctx->vsp=local+8;
	w=(pointer)APPEND(ctx,2,local+6); /*append*/
	local[6]= w;
	local[7]= fqv[115];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	local[5]= w;
	goto irtsensoIF2809;
irtsensoIF2808:
	local[5]= NIL;
irtsensoIF2809:
	goto irtsensoIF2807;
irtsensoIF2806:
	if (T==NIL) goto irtsensoIF2810;
	local[5]= local[1];
	local[6]= NIL;
	local[7]= fqv[115];
	ctx->vsp=local+8;
	w=(pointer)PUTPROP(ctx,3,local+5); /*putprop*/
	local[5]= w;
	goto irtsensoIF2811;
irtsensoIF2810:
	local[5]= NIL;
irtsensoIF2811:
irtsensoIF2807:
	w = local[5];
	goto irtsensoWHL2803;
irtsensoWHX2804:
	local[3]= NIL;
irtsensoBLK2805:
	w = NIL;
	local[0]= w;
irtsensoBLK2802:
	ctx->vsp=local; return(local[0]);}

/*make-camera-from-param*/
static pointer irtsensoF2647make_camera_from_param(ctx,n,argv,env)
register context *ctx;
register int n; register pointer argv[]; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv=qv;
  numunion nu;
	if (n<0) maerror();
	ctx->vsp=local+0;
	n=parsekeyparams(fqv[119], &argv[0], n-0, local+0, 0);
	if (n & (1<<0)) goto irtsensoKEY2813;
	local[0] = NIL;
irtsensoKEY2813:
	if (n & (1<<1)) goto irtsensoKEY2814;
	local[1] = NIL;
irtsensoKEY2814:
	if (n & (1<<2)) goto irtsensoKEY2815;
	local[2] = NIL;
irtsensoKEY2815:
	if (n & (1<<3)) goto irtsensoKEY2816;
	local[3] = NIL;
irtsensoKEY2816:
	if (n & (1<<4)) goto irtsensoKEY2817;
	local[4] = NIL;
irtsensoKEY2817:
	if (n & (1<<5)) goto irtsensoKEY2818;
	local[5] = NIL;
irtsensoKEY2818:
	if (n & (1<<6)) goto irtsensoKEY2819;
	local[6] = makeint((eusinteger_t)0L);
irtsensoKEY2819:
	if (n & (1<<7)) goto irtsensoKEY2820;
	local[7] = makeint((eusinteger_t)0L);
irtsensoKEY2820:
	if (n & (1<<8)) goto irtsensoKEY2821;
	local[8] = NIL;
irtsensoKEY2821:
	if (n & (1<<9)) goto irtsensoKEY2822;
	local[9] = NIL;
irtsensoKEY2822:
	if (n & (1<<10)) goto irtsensoKEY2823;
	local[10] = NIL;
irtsensoKEY2823:
	if (n & (1<<11)) goto irtsensoKEY2824;
	local[11] = NIL;
irtsensoKEY2824:
	local[12]= makeint((eusinteger_t)40L);
	local[13]= makeint((eusinteger_t)30L);
	local[14]= makeint((eusinteger_t)30L);
	ctx->vsp=local+15;
	w=(*ftab[24])(ctx,3,local+12,&ftab[24],fqv[120]); /*make-cube*/
	local[12]= w;
	local[13]= makeint((eusinteger_t)2L);
	local[14]= makeint((eusinteger_t)30L);
	ctx->vsp=local+15;
	w=(*ftab[25])(ctx,2,local+13,&ftab[25],fqv[121]); /*make-cylinder*/
	local[13]= w;
	local[14]= fqv[122];
	local[15]= makeflt(1.5707963267948965579990e+00);
	local[16]= fqv[40];
	ctx->vsp=local+17;
	w=(pointer)SEND(ctx,4,local+13); /*send*/
	local[13]= w;
	local[14]= makeint((eusinteger_t)13L);
	local[15]= makeint((eusinteger_t)25L);
	ctx->vsp=local+16;
	w=(*ftab[25])(ctx,2,local+14,&ftab[25],fqv[121]); /*make-cylinder*/
	local[14]= w;
	ctx->vsp=local+15;
	w=(*ftab[26])(ctx,3,local+12,&ftab[26],fqv[123]); /*body+*/
	local[12]= w;
	local[13]= NIL;
	local[14]= makeflt(1.0000000000000000000000e+00);
	local[15]= loadglobal(fqv[124]);
	ctx->vsp=local+16;
	w=(pointer)INSTANTIATE(ctx,1,local+15); /*instantiate*/
	local[15]= w;
	local[16]= local[15];
	local[17]= fqv[10];
	local[18]= local[12];
	local[19]= fqv[52];
	local[20]= local[0];
	local[21]= fqv[53];
	local[22]= local[1];
	local[23]= fqv[30];
	local[24]= local[14];
	local[25]= fqv[6];
	local[26]= local[9];
	ctx->vsp=local+27;
	w=(pointer)SEND(ctx,11,local+16); /*send*/
	w = local[15];
	local[13] = w;
	local[15]= *(ovafptr(local[13],fqv[125]));
	local[16]= fqv[33];
	local[17]= local[14];
	local[18]= local[0];
	local[19]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+20;
	w=(pointer)TIMES(ctx,3,local+17); /***/
	local[17]= w;
	local[18]= local[2];
	ctx->vsp=local+19;
	w=(pointer)QUOTIENT(ctx,2,local+17); /*/*/
	local[17]= w;
	local[18]= local[14];
	local[19]= local[1];
	local[20]= makeflt(5.0000000000000000000000e-01);
	ctx->vsp=local+21;
	w=(pointer)TIMES(ctx,3,local+18); /***/
	local[18]= w;
	local[19]= local[3];
	ctx->vsp=local+20;
	w=(pointer)QUOTIENT(ctx,2,local+18); /*/*/
	local[18]= w;
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,4,local+15); /*send*/
	local[15]= local[13];
	local[16]= fqv[35];
	local[17]= makeint((eusinteger_t)4L);
	local[18]= makeint((eusinteger_t)4L);
	local[19]= local[2];
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[4];
	local[22]= local[2];
	local[23]= local[6];
	ctx->vsp=local+24;
	w=(pointer)TIMES(ctx,2,local+22); /***/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)MKFLTVEC(ctx,4,local+19); /*float-vector*/
	local[19]= w;
	local[20]= makeint((eusinteger_t)0L);
	local[21]= local[3];
	local[22]= local[5];
	local[23]= local[3];
	local[24]= local[7];
	ctx->vsp=local+25;
	w=(pointer)TIMES(ctx,2,local+23); /***/
	local[23]= w;
	ctx->vsp=local+24;
	w=(pointer)MKFLTVEC(ctx,4,local+20); /*float-vector*/
	local[20]= w;
	local[21]= makeint((eusinteger_t)0L);
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)1L);
	local[24]= makeint((eusinteger_t)0L);
	ctx->vsp=local+25;
	w=(pointer)MKFLTVEC(ctx,4,local+21); /*float-vector*/
	local[21]= w;
	local[22]= makeint((eusinteger_t)0L);
	local[23]= makeint((eusinteger_t)0L);
	local[24]= makeint((eusinteger_t)0L);
	local[25]= makeint((eusinteger_t)1L);
	ctx->vsp=local+26;
	w=(pointer)MKFLTVEC(ctx,4,local+22); /*float-vector*/
	local[22]= w;
	ctx->vsp=local+23;
	w=(pointer)LIST(ctx,4,local+19); /*list*/
	local[19]= w;
	ctx->vsp=local+20;
	w=(*ftab[6])(ctx,3,local+17,&ftab[6],fqv[36]); /*make-matrix*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	if (local[8]==NIL) goto irtsensoIF2825;
	local[15]= local[13];
	local[16]= fqv[126];
	local[17]= local[8];
	local[18]= fqv[127];
	ctx->vsp=local+19;
	w=(pointer)SEND(ctx,2,local+17); /*send*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	goto irtsensoIF2826;
irtsensoIF2825:
	local[15]= NIL;
irtsensoIF2826:
	local[15]= local[13];
	local[16]= fqv[128];
	local[17]= local[6];
	ctx->vsp=local+18;
	w=(pointer)MINUS(ctx,1,local+17); /*-*/
	local[17]= w;
	local[18]= local[7];
	ctx->vsp=local+19;
	w=(pointer)MINUS(ctx,1,local+18); /*-*/
	local[18]= w;
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)MKFLTVEC(ctx,3,local+17); /*float-vector*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= *(ovafptr(local[13],fqv[125]));
	local[16]= fqv[128];
	local[17]= local[6];
	local[18]= local[7];
	local[19]= makeint((eusinteger_t)0L);
	ctx->vsp=local+20;
	w=(pointer)MKFLTVEC(ctx,3,local+17); /*float-vector*/
	local[17]= w;
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	if (local[8]==NIL) goto irtsensoIF2827;
	local[15]= local[8];
	local[16]= fqv[34];
	local[17]= local[13];
	ctx->vsp=local+18;
	w=(pointer)SEND(ctx,3,local+15); /*send*/
	local[15]= w;
	goto irtsensoIF2828;
irtsensoIF2827:
	local[15]= NIL;
irtsensoIF2828:
	if (local[10]==NIL) goto irtsensoIF2829;
	local[15]= local[13];
	local[16]= fqv[81];
	local[17]= NIL;
	local[18]= fqv[129];
	local[19]= local[11];
	ctx->vsp=local+20;
	w=(pointer)SEND(ctx,5,local+15); /*send*/
	local[15]= w;
	goto irtsensoIF2830;
irtsensoIF2829:
	local[15]= NIL;
irtsensoIF2830:
	w = local[13];
	local[0]= w;
irtsensoBLK2812:
	ctx->vsp=local; return(local[0]);}

/* initializer*/
pointer ___irtsensor(ctx,n,argv,env)
register context *ctx; int n; pointer *argv; pointer env;
{ register pointer *local=ctx->vsp, w, *fqv;
  register int i;
  numunion nu;
  module=argv[0];
  quotevec=build_quote_vector(ctx,QUOTE_STRINGS_SIZE, quote_strings);
  module->c.code.quotevec=quotevec;
  codevec=module->c.code.codevec;
  fqv=qv=quotevec->c.vec.v;
  init_ftab();
	local[0]= fqv[130];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtsensoIF2831;
	local[0]= fqv[131];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[132],w);
	goto irtsensoIF2832;
irtsensoIF2831:
	local[0]= fqv[133];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtsensoIF2832:
	local[0]= fqv[134];
	local[1]= fqv[135];
	local[2]= fqv[134];
	local[3]= fqv[136];
	local[4]= loadglobal(fqv[137]);
	local[5]= fqv[138];
	local[6]= fqv[139];
	local[7]= fqv[140];
	local[8]= NIL;
	local[9]= fqv[107];
	local[10]= NIL;
	local[11]= fqv[141];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[142];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[27])(ctx,13,local+2,&ftab[27],fqv[143]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2648sensor_model_profile,fqv[144],fqv[134],fqv[145]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2654sensor_model_signal,fqv[146],fqv[134],fqv[147]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2656sensor_model_simulate,fqv[148],fqv[134],fqv[149]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2658sensor_model_read,fqv[150],fqv[134],fqv[151]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2660sensor_model_draw_sensor,fqv[12],fqv[134],fqv[152]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2662sensor_model_init,fqv[10],fqv[134],fqv[153]);
	local[0]= fqv[154];
	local[1]= fqv[135];
	local[2]= fqv[154];
	local[3]= fqv[136];
	local[4]= loadglobal(fqv[134]);
	local[5]= fqv[138];
	local[6]= fqv[155];
	local[7]= fqv[140];
	local[8]= NIL;
	local[9]= fqv[107];
	local[10]= NIL;
	local[11]= fqv[141];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[142];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[27])(ctx,13,local+2,&ftab[27],fqv[143]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2665bumper_model_init,fqv[10],fqv[154],fqv[156]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2670bumper_model_simulate,fqv[148],fqv[154],fqv[157]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2679bumper_model_draw,fqv[93],fqv[154],fqv[158]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2681bumper_model_draw_sensor,fqv[12],fqv[154],fqv[159]);
	local[0]= fqv[124];
	local[1]= fqv[135];
	local[2]= fqv[124];
	local[3]= fqv[136];
	local[4]= loadglobal(fqv[134]);
	local[5]= fqv[138];
	local[6]= fqv[160];
	local[7]= fqv[140];
	local[8]= NIL;
	local[9]= fqv[107];
	local[10]= NIL;
	local[11]= fqv[141];
	local[12]= makeint((eusinteger_t)-1L);
	local[13]= fqv[142];
	local[14]= NIL;
	ctx->vsp=local+15;
	w=(*ftab[27])(ctx,13,local+2,&ftab[27],fqv[143]); /*make-class*/
	local[2]= w;
	ctx->vsp=local+3;
	w=(pointer)SEND(ctx,3,local+0); /*send*/
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2685camera_model_init,fqv[10],fqv[124],fqv[161]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2694camera_model_create_viewer,fqv[81],fqv[124],fqv[162]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2705camera_model_width,fqv[52],fqv[124],fqv[163]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2707camera_model_height,fqv[53],fqv[124],fqv[164]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2709camera_model_viewing,fqv[42],fqv[124],fqv[165]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2712camera_model_image_viewer,fqv[166],fqv[124],fqv[167]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2715camera_model_fovy,fqv[88],fqv[124],fqv[168]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2717camera_model_cx,fqv[104],fqv[124],fqv[169]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2719camera_model_cy,fqv[105],fqv[124],fqv[170]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2721camera_model_fx,fqv[171],fqv[124],fqv[172]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2723camera_model_fy,fqv[173],fqv[124],fqv[174]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2725camera_model_screen_point,fqv[175],fqv[124],fqv[176]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2727camera_model_3d_point,fqv[177],fqv[124],fqv[178]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2729camera_model_ray,fqv[179],fqv[124],fqv[180]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2731camera_model_draw_on,fqv[96],fqv[124],fqv[181]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2735camera_model_draw_sensor,fqv[12],fqv[124],fqv[182]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2745camera_model_draw_objects,fqv[183],fqv[124],fqv[184]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2749camera_model_draw_objects_raw,fqv[82],fqv[124],fqv[185]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2765camera_model_get_image,fqv[186],fqv[124],fqv[187]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2778camera_model_get_image_raw,fqv[99],fqv[124],fqv[188]);
	ctx->vsp=local+0;
	addcmethod(ctx,module,irtsensoM2801camera_model_select_drawmode,fqv[189],fqv[124],fqv[190]);
	ctx->vsp=local+0;
	compfun(ctx,fqv[191],module,irtsensoF2647make_camera_from_param,fqv[192]);
	local[0]= fqv[193];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	if (w==NIL) goto irtsensoIF2833;
	local[0]= fqv[194];
	ctx->vsp=local+1;
	w=(pointer)FINDPACKAGE(ctx,1,local+0); /*find-package*/
	local[0]= w;
	storeglobal(fqv[132],w);
	goto irtsensoIF2834;
irtsensoIF2833:
	local[0]= fqv[195];
	ctx->vsp=local+1;
	w=(pointer)SIGERROR(ctx,1,local+0); /*error*/
	local[0]= w;
irtsensoIF2834:
	local[0]= fqv[196];
	local[1]= fqv[197];
	ctx->vsp=local+2;
	w=(*ftab[28])(ctx,2,local+0,&ftab[28],fqv[198]); /*provide*/
	local[0]= NIL;
	ctx->vsp=local; return(local[0]);}
static void init_ftab()
{  register int i;
  for (i=0; i<29; i++) ftab[i]=fcallx;
}
