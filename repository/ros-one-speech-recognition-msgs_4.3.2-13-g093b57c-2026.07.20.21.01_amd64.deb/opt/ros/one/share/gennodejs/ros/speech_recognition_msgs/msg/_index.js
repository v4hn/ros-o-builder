
"use strict";

let SpeechRecognitionCandidates = require('./SpeechRecognitionCandidates.js');
let PhraseRule = require('./PhraseRule.js');
let Grammar = require('./Grammar.js');
let Vocabulary = require('./Vocabulary.js');

module.exports = {
  SpeechRecognitionCandidates: SpeechRecognitionCandidates,
  PhraseRule: PhraseRule,
  Grammar: Grammar,
  Vocabulary: Vocabulary,
};
