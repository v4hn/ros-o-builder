
"use strict";

let GetGeographicMap = require('./GetGeographicMap.js')
let GetRoutePlan = require('./GetRoutePlan.js')
let GetGeoPath = require('./GetGeoPath.js')
let UpdateGeographicMap = require('./UpdateGeographicMap.js')

module.exports = {
  GetGeographicMap: GetGeographicMap,
  GetRoutePlan: GetRoutePlan,
  GetGeoPath: GetGeoPath,
  UpdateGeographicMap: UpdateGeographicMap,
};
