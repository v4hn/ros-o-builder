
"use strict";

let AddClassData = require('./AddClassData.js')
let ClearClassifier = require('./ClearClassifier.js')
let CreateClassifier = require('./CreateClassifier.js')
let TrainClassifier = require('./TrainClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let LoadClassifier = require('./LoadClassifier.js')
let SaveClassifier = require('./SaveClassifier.js')

module.exports = {
  AddClassData: AddClassData,
  ClearClassifier: ClearClassifier,
  CreateClassifier: CreateClassifier,
  TrainClassifier: TrainClassifier,
  ClassifyData: ClassifyData,
  LoadClassifier: LoadClassifier,
  SaveClassifier: SaveClassifier,
};
