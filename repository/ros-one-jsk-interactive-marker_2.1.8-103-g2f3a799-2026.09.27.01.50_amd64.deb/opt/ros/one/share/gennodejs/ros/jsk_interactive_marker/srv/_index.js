
"use strict";

let SetTransformableMarkerPose = require('./SetTransformableMarkerPose.js')
let GetMarkerDimensions = require('./GetMarkerDimensions.js')
let RemoveParentMarker = require('./RemoveParentMarker.js')
let SetTransformableMarkerFocus = require('./SetTransformableMarkerFocus.js')
let SetPose = require('./SetPose.js')
let MarkerSetPose = require('./MarkerSetPose.js')
let GetTransformableMarkerExistence = require('./GetTransformableMarkerExistence.js')
let SetTransformableMarkerColor = require('./SetTransformableMarkerColor.js')
let GetTransformableMarkerPose = require('./GetTransformableMarkerPose.js')
let GetType = require('./GetType.js')
let GetTransformableMarkerFocus = require('./GetTransformableMarkerFocus.js')
let SnapFootPrint = require('./SnapFootPrint.js')
let GetTransformableMarkerColor = require('./GetTransformableMarkerColor.js')
let SetMarkerDimensions = require('./SetMarkerDimensions.js')
let IndexRequest = require('./IndexRequest.js')
let GetJointState = require('./GetJointState.js')
let SetHeuristic = require('./SetHeuristic.js')
let SetParentMarker = require('./SetParentMarker.js')

module.exports = {
  SetTransformableMarkerPose: SetTransformableMarkerPose,
  GetMarkerDimensions: GetMarkerDimensions,
  RemoveParentMarker: RemoveParentMarker,
  SetTransformableMarkerFocus: SetTransformableMarkerFocus,
  SetPose: SetPose,
  MarkerSetPose: MarkerSetPose,
  GetTransformableMarkerExistence: GetTransformableMarkerExistence,
  SetTransformableMarkerColor: SetTransformableMarkerColor,
  GetTransformableMarkerPose: GetTransformableMarkerPose,
  GetType: GetType,
  GetTransformableMarkerFocus: GetTransformableMarkerFocus,
  SnapFootPrint: SnapFootPrint,
  GetTransformableMarkerColor: GetTransformableMarkerColor,
  SetMarkerDimensions: SetMarkerDimensions,
  IndexRequest: IndexRequest,
  GetJointState: GetJointState,
  SetHeuristic: SetHeuristic,
  SetParentMarker: SetParentMarker,
};
