
"use strict";

let SetSpeedSliderFraction = require('./SetSpeedSliderFraction.js')
let SetPayload = require('./SetPayload.js')
let SetAnalogOutput = require('./SetAnalogOutput.js')
let SetForceMode = require('./SetForceMode.js')
let SetIO = require('./SetIO.js')
let GetRobotSoftwareVersion = require('./GetRobotSoftwareVersion.js')

module.exports = {
  SetSpeedSliderFraction: SetSpeedSliderFraction,
  SetPayload: SetPayload,
  SetAnalogOutput: SetAnalogOutput,
  SetForceMode: SetForceMode,
  SetIO: SetIO,
  GetRobotSoftwareVersion: GetRobotSoftwareVersion,
};
