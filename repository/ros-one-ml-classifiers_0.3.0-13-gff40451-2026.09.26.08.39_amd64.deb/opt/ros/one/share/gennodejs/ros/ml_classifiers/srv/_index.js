
"use strict";

let AddClassData = require('./AddClassData.js')
let ClearClassifier = require('./ClearClassifier.js')
let ClassifyData = require('./ClassifyData.js')
let TrainClassifier = require('./TrainClassifier.js')
let CreateClassifier = require('./CreateClassifier.js')
let SaveClassifier = require('./SaveClassifier.js')
let LoadClassifier = require('./LoadClassifier.js')

module.exports = {
  AddClassData: AddClassData,
  ClearClassifier: ClearClassifier,
  ClassifyData: ClassifyData,
  TrainClassifier: TrainClassifier,
  CreateClassifier: CreateClassifier,
  SaveClassifier: SaveClassifier,
  LoadClassifier: LoadClassifier,
};
